package org.dream.dreamlock.server.concurrency;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.dream.utils.distributelock.codec.Monitor;

import io.netty.channel.Channel;

/**
 * 
 * @author boyce
 *
 */
public class ChannelHub {
	private static Map<UUID, ClientChannel> hub = new HashMap<>();

	public static synchronized void registerChannel(UUID clientId, Channel ch) {
		if (hub.get(clientId) == null) {
			ClientChannel cch = new ClientChannel();
			cch.clientId = clientId;
			hub.put(clientId, cch);
		}
		hub.get(clientId).addChannel(ch);
	}

	private static class ClientChannel {
		UUID clientId;
		List<Channel> channels = new ArrayList<>();

		public void addChannel(Channel ch) {
			channels.remove(ch);
			channels.add(ch);
		}

		public void removeChannel(Channel ch) {
			channels.remove(ch);
		}

		@Override
		public String toString() {
			return clientId + ":" + channels;
		}
	}

	public static synchronized void deregister(UUID clientId, Channel ch) {
		if (hub.get(clientId) != null) {
			hub.get(clientId).removeChannel(ch);
		}
	}

	public static void notifyUnlock(int cmdId, Monitor m) {
		Monitor resp = new Monitor();
		resp.cmdId = cmdId;
		resp.clientId = m.clientId;
		resp.monitor = m.monitor;
		resp.remoteThreadId = m.remoteThreadId;
		m.channel.writeAndFlush(resp);
	}
}
