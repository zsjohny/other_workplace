package org.dream.config.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.config.model.TradingTimeModel;

/**
 * 交易时间配置Dao
 * 
 * @author wangd
 *
 */
public interface TradingTimeDao {

    public void createTradingTime(TradingTimeModel tradingTimeModel);

    public void updateTradingTime(TradingTimeModel tradingTimeModel);

    /**
     * 获得全部的交易时间
     * 
     * @return
     */
    public List<TradingTimeModel> getAll();

    /**
     * 根据市场id，查询全部的交易时间
     * 
     * @param exchangeId
     * @return
     */
    public List<TradingTimeModel> getByExchangeId(@Param(value = "exchangeId") Integer exchangeId);

    /**
     * 删除
     * 
     * @param ids
     *            要删除的id，不能为空
     */
    public void deleteByIds(@Param(value = "ids") List<Integer> ids);

    /**
     * 分页查询
     * 
     * @param varietyId
     * @param status
     * @param limit
     * @param size
     * @return
     */
    public List<TradingTimeModel> querypaging(@Param(value = "varietyId") Integer varietyId,
	    @Param(value = "action") Integer action, @Param(value = "remark") String remark,
	    @Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

    public int querypaging_count(@Param(value = "varietyId") Integer exchangeId,
	    @Param(value = "action") Integer action, @Param(value = "remark") String remark);
    
}
