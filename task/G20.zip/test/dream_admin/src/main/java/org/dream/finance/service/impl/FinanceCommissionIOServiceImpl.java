package org.dream.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.finance.service.BasicCommissionIOService;
import org.dream.finance.service.FinanceCommissionIOService;
import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class FinanceCommissionIOServiceImpl implements FinanceCommissionIOService {
	@Autowired
	private BasicCommissionIOService commissionIOService;

	@Override
	public Response findCommissionIOByPage(FinanceCommissionIOModel commissionIOModel, Integer page, Integer pageSize) {
		return commissionIOService.findCommissionIOByPage(commissionIOModel, page, pageSize);
	}

	@Override
	public Response updateCommissionIO(String ioIds, Integer status) {
		String[] ioIdsArray = ioIds.split(",");
		List<Integer> ioIdList = new ArrayList<Integer>();
		for (int i = 0; i < ioIdsArray.length; i++) {
			ioIdList.add(Integer.valueOf(ioIdsArray[i]));
		}
		return commissionIOService.updateCommissionIO(ioIdList, status);
	}

}
