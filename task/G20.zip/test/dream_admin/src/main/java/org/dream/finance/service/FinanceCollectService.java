package org.dream.finance.service;

import org.dream.model.finance.FinanceCollectModel;
import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.model.finance.FinanceIOManageModel;

public interface FinanceCollectService {

	public FinanceCollectModel findCollectMoneyFlow(Integer id, Integer level, String createTimeStart, String createTimeEnd,
			Integer userId, String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, String flow);
	
	public FinanceCollectModel findCollect(FinanceIOManageModel model, Integer id, Integer level);
	
	public FinanceCollectModel findCollectTransfer(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId);
	
	public FinanceCollectModel findCollectCommission(FinanceCommissionIOModel commissionIOModel);
}
