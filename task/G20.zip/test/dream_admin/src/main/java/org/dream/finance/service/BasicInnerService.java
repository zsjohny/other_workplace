package org.dream.finance.service;

public interface BasicInnerService {
	public void innerDepositMoney(Integer userId, Double money);

	public void innerDepositScore(Integer userId, Double score);

	public void innerExtractMoney(Integer userId, Double money);

	public void innerExtractScore(Integer userId, Double score);
}
