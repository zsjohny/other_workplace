package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceBankModel;

public interface FinanceBankDao {
	// V2
	public List<FinanceBankModel> findByPage(@Param("model") FinanceBankModel bankModel,
			@Param("offset") Integer offset, @Param("offset") Integer pageSize);

	public Integer findRows(FinanceBankModel bankModel);

	public FinanceBankModel find(FinanceBankModel bankModel);

	public Integer save(FinanceBankModel bankModel);

	public Integer update(FinanceBankModel bankModel);

	public List<FinanceBankModel> findAll();

	// *******************************************************************************
	public FinanceBankModel findBank(@Param(value = "bankId") Integer bankId, @Param(value = "status") Integer status);

	public void saveFinanceBank(FinanceBankModel bankModel);

	public void updateFinanceBank(FinanceBankModel bankModel);

	public List<FinanceBankModel> querypaging(@Param(value = "name") String name, @Param(value = "icon") String icon,
			@Param(value = "index") Integer index, @Param(value = "status") Integer status,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer querypaging_count(@Param(value = "name") String name, @Param(value = "icon") String icon,
			@Param(value = "index") Integer index, @Param(value = "status") Integer status);

	public FinanceBankModel check(FinanceBankModel bankModel);
}
