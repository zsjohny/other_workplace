package org.dream.finance.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.dream.admin.model.AdminUserModel;
import org.dream.finance.dao.FinanceCertDao;
import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.dao.FinanceTransferDao;
import org.dream.finance.service.AlipayTransferService;
import org.dream.finance.service.BasicFinanceService;
import org.dream.finance.service.FinanceService;
import org.dream.finance.util.alipay.HttpProtocolHandler;
import org.dream.finance.util.alipay.HttpRequest;
import org.dream.finance.util.alipay.HttpResponse;
import org.dream.finance.util.alipay.HttpResultType;
import org.dream.finance.util.alipay.ParamUtil;
import org.dream.finance.util.alipay.SecurityUtil;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.concurrent.Executors;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.controller.BaseController;
import org.dream.utils.math.Arith;
import org.dream.utils.mvc.Response;
import org.dream.utils.prop.SpringProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Controller
@RequestMapping("/finance")
public class AlipayTransferController extends BaseController implements InitializingBean, DisposableBean {
	private Logger logger = LoggerFactory.getLogger(AlipayTransferController.class);
	private static final Integer ERROR_CODE = 600;
	private static final String REDIS_KEY = "admin:filter:alipay_transfer";
	@Autowired
	private SpringProperties springProperties;
	@Autowired
	private FinanceService financeService;
	@Autowired
	private FinanceIODao financeIODao;
	@Autowired
	private FinanceCertDao certDao;
	@Autowired
	private FinanceTransferDao transferDao;
	@Autowired
	private AlipayTransferService transferService;
	@Autowired
	private RedisTemplate<String, Integer> redisTemplate;
	@Autowired
	private BasicFinanceService basicFinanceService;

	ScheduledExecutorService pool = Executors.newScheduledThreadPool(8, "支付宝转账定时任务");

	// V3
	@RequestMapping("/alipayTransfer1")
	@ResponseBody
	public Response transfer1(String ioIds, HttpServletRequest request) {
		if (StringUtils.isBlank(ioIds)) {
			logger.info("支付宝转账:批量转账ioId为空");
			return Response.response(ResponseCode.ERROR_CODE, "批量转账ID不能为空");
		}
		Integer channelId = getDataId(request);
		FinanceCertModel model = new FinanceCertModel();
		model.setChannelId(channelId);
		model.setPlatform(FinancePayType.ALIPAY.getPlatform());
		model.setType(1);
		model.setStatus(0);
		final FinanceCertModel certModel = certDao.find(model);
		if (certModel == null) {
			logger.info("支付宝转账:渠道{}的支付宝转账证书未找到", channelId);
			return Response.response(ResponseCode.ERROR_CODE, "支付宝转账证书未找到");
		}

		return Response.response(ResponseCode.SUCCESS_CODE, "支付宝转账操作成功");
	}
	// ******************************************************************************

	// V2
	// ********************************************************************************
	@RequestMapping("/alipayTransfer")
	@ResponseBody
	public Response transfer(String ioIds, HttpServletRequest req) {
		if (StringUtils.isBlank(ioIds)) {
			return Response.response(ERROR_CODE, "批量转账ID不能为空");
		}
		Integer channelId = getDataId(req);
		FinanceCertModel model = new FinanceCertModel();
		model.setChannelId(channelId);
		model.setPlatform("alipay");
		model.setType(1);
		model.setStatus(0);
		final FinanceCertModel certModel = certDao.find(model);
		if (certModel == null) {
			logger.info("支付宝转账:渠道{}的支付宝转账证书未找到", channelId);
			return Response.response(ResponseCode.ERROR_CODE, "支付宝转账证书未找到");
		}
		JSONObject parameter = JSON.parseObject(certModel.getParameter());
		String account = parameter.getString("account");
		String partner = parameter.getString("partner");
		String md5Key = parameter.getString("md5Key");

		String redisKey = null;
		String[] ioIdsArray = null;
		List<FinanceTransferModel> list = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			HttpSession session = req.getSession();
			AdminUserModel loginUser = (AdminUserModel) session.getAttribute("user");
			String operator = loginUser.getUserAccount();
			list = financeService.saveTransfer(ioIds, FinanceTransferType.AILPAY, FinancePayType.ALIPAY, operator);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + id;
				redisTemplate.delete(redisKey);
			}
		}
		String r1 = "文件下载失败！该批次正在处理中，请稍候尝试下载！";
		String r2 = "文件下载失败！文件下载失败，请稍后重试。";
		for (FinanceTransferModel transferModel : list) {
			Double money = transferModel.getMoney();
			Double commission = transferModel.getCommission();
			Double transferMoney = Arith.subtract(money, commission);
			String realName = transferModel.getRealName();
			String cardNo = transferModel.getCardNo();
			String bankName = transferModel.getBankName();
			final String selfOrderId = transferModel.getSelfOrderId();
			String bptb_pay_file = ParamUtil.getStrFile(transferMoney, account, realName, cardNo, bankName,
					selfOrderId);
			String file_digest_type = "MD5";
			String digest_bptb_pay_file = null;
			try {
				digest_bptb_pay_file = SecurityUtil.getAbstract(bptb_pay_file.getBytes("GBK"), file_digest_type);
			} catch (IOException e) {
				e.printStackTrace();
			}
			Map<String, String> sParaTemp = new HashMap<String, String>();
			sParaTemp.put("service", "bptb_pay_file");
			sParaTemp.put("partner", partner);
			sParaTemp.put("_input_charset", ParamUtil.input_charset);
			sParaTemp.put("file_digest_type", file_digest_type);
			sParaTemp.put("digest_bptb_pay_file", digest_bptb_pay_file);
			sParaTemp.put("bussiness_type", "T0");

			Map<String, String> sPara = ParamUtil.buildRequestPara(sParaTemp, md5Key);
			HttpProtocolHandler httpProtocolHandler = HttpProtocolHandler.getInstance();
			HttpRequest request = new HttpRequest(HttpResultType.BYTES);
			request.setCharset(ParamUtil.input_charset);
			request.setParameters(ParamUtil.generatNameValuePair(sPara));
			String ALIPAY_GATEWAY_NEW = springProperties.getProperty("admin.alipay.transfer_url");
			request.setUrl(ALIPAY_GATEWAY_NEW + "_input_charset=" + ParamUtil.input_charset);
			String strFilePath = springProperties.getProperty("admin.alipay.temp_file").replace("${fileName}",
					selfOrderId);
			try {
				File upload = new File(strFilePath);
				FileUtils.writeStringToFile(upload, bptb_pay_file, "GBK");
				logger.info("发送支付宝转账报文：\r\n{}", bptb_pay_file);
				HttpResponse response = httpProtocolHandler.execute(request, "bptb_pay_file", strFilePath);
				upload.delete();
				String strResult = response.getStringResult();
				if (!strResult.contains("成功")) {
					basicFinanceService.transferNotify(transferModel.getId(), selfOrderId, null, transferMoney, 5,
							null);
					transferModel.setStatus(5);
					transferDao.update(transferModel);
					logger.info("支付宝转账:转账失败{}", strResult);
					return Response.response(ResponseCode.ERROR_CODE, "支付宝转账失败");
				}
			} catch (IOException e) {
				logger.error("{}", e);
			}

			// 为每个支付宝转账新建一个定时任务
			final Integer transferId = transferModel.getId();
			pool.schedule(new Callable<Object>() {
				@Override
				public Object call() throws Exception {
					logger.info("对转账ID为{}的提现进行转账定时任务", transferId);
					Response result = transferService.alipayResult(certModel.getParameter(), selfOrderId, transferId);
					if (result == null) {
						pool.schedule(this, 300, TimeUnit.SECONDS);
					}
					return null;
				}
			}, 1, TimeUnit.SECONDS);
		}
		return Response.response(ResponseCode.SUCCESS_CODE, "支付宝转账操作成功");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("初始化支付宝转账定时任务。。。");
		List<Map<String, Object>> list = transferDao.findTransferParam(2, FinanceTransferType.AILPAY.getTypeDetail(),
				"alipay");
		// List<Map<String, Object>> list =
		for (Map<String, Object> map : list) {
			final Integer transferId = (Integer) (map.get("id"));
			final String parameter = map.get("parameter").toString();
			final String selfOrderId = map.get("selfOrderId").toString();
			pool.schedule(new Callable<Object>() {
				@Override
				public Object call() throws Exception {
					logger.info("对转账ID为{}的提现进行支付宝转账定时任务", transferId);
					Response result = transferService.alipayResult(parameter, selfOrderId, transferId);
					if (result == null)
						pool.schedule(this, 300, TimeUnit.SECONDS);
					return null;
				}
			}, 1, TimeUnit.SECONDS);
		}
	}

	@Override
	public void destroy() throws Exception {
		logger.info("关闭支付宝转账定时任务线程池。。。");
		pool.shutdown();
	}
}
