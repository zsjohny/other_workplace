package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.ChannelExchangeModel;

public interface ChannelExchangeDao {

	public List<ChannelExchangeModel> getExchangesByChannelId(@Param("channelId") Integer channelId);

	public void insert(ChannelExchangeModel exchangeModel);

	public List<ChannelExchangeModel> qureypaging(@Param("channelId") Integer channelId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param("channelId") Integer channelId);

}
