package org.dream.sms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.sms.SmsSenderTemplate;

public interface SmsSenderTemplateDao {

	public void createSenderTemplate(SmsSenderTemplate smsSenderTemplate);

	public void updateSenderTemplate(SmsSenderTemplate smsSenderTemplate);

	public List<SmsSenderTemplate> getAll(@Param(value = "isDelete") Integer isDelete,
			@Param(value = "channelId") Integer channelId, @Param(value = "templateId") Integer templateId);

	public SmsSenderTemplate getById(@Param(value = "id") Integer id, @Param(value = "isDelete") Integer isDelete);

	public SmsSenderTemplate getSenderTemplate(@Param(value = "id") Integer id);

	public List<SmsSenderTemplate> pagingQuery(@Param(value = "templateId") Integer templateId,
			@Param(value = "isDelete") Integer isDelete, @Param(value = "channelId") Integer channelId,
			@Param(value = "type") Integer type, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer pagingQuery_count(@Param(value = "templateId") Integer templateId,
			@Param(value = "isDelete") Integer isDelete, @Param(value = "channelId") Integer channelId,
			@Param(value = "type") Integer type);

	public void remove(@Param(value = "id") Integer id);

	public void removeByTemplateId(@Param(value = "templateId") Integer templateId);

	public SmsSenderTemplate findSenderTemplate(@Param(value = "templateId") Integer templateId,
			@Param(value = "channelId") Integer channelId, @Param(value = "type") Integer type);
}
