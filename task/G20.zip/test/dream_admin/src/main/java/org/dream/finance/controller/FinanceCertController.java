package org.dream.finance.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dream.finance.service.FinanceCertService;
import org.dream.model.finance.FinanceCertModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.dream.utils.validate.ValidateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Controller
@RequestMapping("/finance")
public class FinanceCertController extends BaseController {
	private Logger logger = LoggerFactory.getLogger(FinanceCertController.class);
	@Autowired
	private FinanceCertService certService;
	@Autowired
	private CommonsMultipartResolver multipartResolver;

	// V3
	@RequestMapping("/findCertByPage")
	@ResponseBody
	public Response findCertByPage(FinanceCertModel certModel, Integer page, Integer pageSize,
			HttpServletRequest request) {
		Integer channelId = getDataId(request);
		certModel.setChannelId(channelId);
		return certService.findCertByPage(certModel, page, pageSize);
	}

	@RequestMapping("/findPayPlatformByCert")
	@ResponseBody
	public Response findPayPlatformByCert(FinanceCertModel certModel, HttpServletRequest request) {
		certModel.setChannelId(getDataId(request));
		return Response.success(certService.findPayPlatformByCert(certModel));
	}
	// ************************************************************************

	// V2
	@RequestMapping("/findCert")
	@ResponseBody
	public Response findCert(FinanceCertModel certModel, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		certModel.setChannelId(channelId);
		return certService.findCert(certModel);
	}

	private String byte2Hex(byte[] srcBytes) {
		StringBuilder hexRetSB = new StringBuilder();
		for (byte b : srcBytes) {
			String hexString = Integer.toHexString(0x00ff & b);
			hexRetSB.append(hexString.length() == 1 ? 0 : "").append(hexString);
		}
		return hexRetSB.toString();
	}

	private void uploadCert(FinanceCertModel certModel, HttpServletRequest request) throws IOException {
		if (multipartResolver.isMultipart(request)) {
			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			Collection<MultipartFile> flies = multiRequest.getFileMap().values();
			Map<String, String> cert = new HashMap<>();
			for (MultipartFile file : flies) {
				cert.put(file.getName(), byte2Hex(file.getBytes()));
			}
			JSONObject object = JSONObject.parseObject(certModel.getParameter());
			object.putAll(cert);
			certModel.setParameter(object.toJSONString());
		}
	}

	@RequestMapping("/saveCert")
	@ResponseBody
	public Response saveCert(FinanceCertModel certModel, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		uploadCert(certModel, request);
		Integer channelId = getDataId(request);
		certModel.setChannelId(channelId);
		return certService.saveCert(certModel);
	}

	@RequestMapping("/updateCert")
	@ResponseBody
	public Response updateCert(FinanceCertModel certModel, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		uploadCert(certModel, request);
		return certService.updateCert(certModel);
	}
	// ***********************************************************************************
}
