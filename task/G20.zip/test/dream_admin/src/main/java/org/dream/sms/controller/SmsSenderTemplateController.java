package org.dream.sms.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.sms.SmsSenderTemplate;
import org.dream.sms.service.SmsSenderTemplateService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import io.netty.util.internal.StringUtil;

/**
 * 短信渠道接口
 * 
 * @author zjj
 *
 */
@Controller
@RequestMapping(value = "/smsSenderTemplate")
public class SmsSenderTemplateController extends BaseController {

	@Autowired
	SmsSenderTemplateService smsSenderTemplateService;

	/**
	 * 添加短信渠道
	 * 
	 * @param id
	 * @param templateId
	 * @param type
	 * @param status
	 * @param extraParam
	 * @return
	 */

	@RequestMapping(value = "/addSenderTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response addSenderTemplate(Integer templateId, Integer type, String extraParam, String template,
			HttpServletRequest request) {
		Assert.notNull(templateId, "添加模板id不能为空");
		Assert.notNull(type, "添加类型不能为空");
		SmsSenderTemplate senderTemplate = new SmsSenderTemplate();
		if (smsSenderTemplateService.hasSenderTemplate(templateId, super.getDataId(request), type)) {
			return Response.error("已存在该发送渠道下该短信模板");
		}
		senderTemplate.setTemplateId(templateId);
		senderTemplate.setType(type);
		senderTemplate.setTemplate(template);
		senderTemplate.setExtraParam(extraParam);
		senderTemplate.setChannelId(super.getDataId(request));
		smsSenderTemplateService.addSenderTemplate(senderTemplate);
		return Response.success();

	}

	/**
	 * 修改渠道
	 * 
	 * @param id
	 * @param templateId
	 * @param type
	 * @param status
	 * @param extraParam
	 * @return
	 */

	@RequestMapping(value = "/updateSenderTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateSenderTemplate(Integer id, Integer templateId, Integer type, String extraParam,
			String template, HttpServletRequest request) {
		Assert.notNull(id, "修改的短信渠道id不能为空");
		Assert.notNull(templateId, "修改模板id不能为空");
		Assert.notNull(type, "修改类型不能为空");
		SmsSenderTemplate senderTemplate = new SmsSenderTemplate();
		senderTemplate.setId(id);
		if (StringUtils.isBlank(template)) {
			return Response.error("修改模板不能为空");
		}
		if (smsSenderTemplateService.hasSenderTemplate(templateId, super.getDataId(request), type)) {
			SmsSenderTemplate smsSenderTemplate = smsSenderTemplateService.findSenderTemplate(templateId,
					super.getDataId(request), type);
			if (smsSenderTemplate.getId() != id) {
				return Response.error("已存在该发送渠道下该短信模板");
			}
		}
		senderTemplate.setTemplateId(templateId);
		senderTemplate.setTemplate(template);
		senderTemplate.setType(type);
		senderTemplate.setExtraParam(extraParam);
		smsSenderTemplateService.updateSenderTemplate(senderTemplate);
		return Response.success();
	}

	/**
	 * 获取全部短信渠道
	 * 
	 * @return
	 */

	@RequestMapping(value = "/getSenderTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response getSenderTemplate(HttpServletRequest request) {
		return Response.success(smsSenderTemplateService.getSenderTemplate(super.getDataId(request)));

	}

	/**
	 * 根据id获取短信渠道
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getSenderTemplateById", method = { RequestMethod.POST })
	@ResponseBody
	public Response getSenderTemplateById(Integer id) {
		SmsSenderTemplate senderTemplate = smsSenderTemplateService.getById(id);
		return Response.success(senderTemplate);

	}

	/**
	 * 分页查询
	 * 
	 * @param page
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/pagingQuery", method = { RequestMethod.POST })
	@ResponseBody
	public Response querypaging(Integer templateId, Integer type, Integer page, Integer pageSize,
			HttpServletRequest request) {
		Page<SmsSenderTemplate> resultPage = smsSenderTemplateService.pagingQuery(templateId, super.getDataId(request),
				type, page, pageSize);
		return Response.success(resultPage);

	}

	/**
	 * 通过改变isDelete来表示是否删除 进行软删除
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/remove", method = { RequestMethod.POST })
	@ResponseBody
	public Response remove(Integer id) {
		Assert.notNull(id, "需要删除的id不能为空");
		SmsSenderTemplate senderTemplate = new SmsSenderTemplate();
		senderTemplate.setId(id);
		smsSenderTemplateService.remove(id);
		return Response.success();
	}

}