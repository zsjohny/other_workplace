package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.model.finance.FinanceUserBankModel;

public interface FinanceChannelPayDao {
	// V2
	public List<FinanceChannelPayModel> findByPage(@Param("model") FinanceChannelPayModel channelPayModel,
			@Param(value = "offset") Integer offset, @Param(value = "pageSize") Integer pageSize);

	public Integer findByPage_count(@Param("model") FinanceChannelPayModel channelPayModel);

	public FinanceChannelPayModel find(FinanceChannelPayModel channelPayModel);

	public List<FinanceBankModel> findBankList(Integer channelId, Integer status);

	// ***************************************
	public void save(FinanceChannelPayModel channelPayModel);

	public void remove(@Param(value = "id") Integer id);

	public void update(FinanceChannelPayModel channelPayModel);

	public List<FinanceChannelPayModel> querypaging(@Param(value = "channelId") Integer channelId,
			@Param(value = "bankId") Integer bankId, @Param(value = "limitSingle") Double limitSingle,
			@Param(value = "limitDay") Double limitDay, @Param(value = "payRule") String payRule,
			@Param(value = "status") Integer status, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer querypaging_count(@Param(value = "channelId") Integer channelId,
			@Param(value = "bankId") Integer bankId, @Param(value = "limitSingle") Double limitSingle,
			@Param(value = "limitDay") Double limitDay, @Param(value = "payRule") String payRule,
			@Param(value = "status") Integer status);
}
