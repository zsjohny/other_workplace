package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceIOService;
import org.dream.finance.service.FinanceService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceIOController extends BaseController {
	@Autowired
	private FinanceService financeService;
	@Autowired
	private FinanceIOService ioService;

	@RequestMapping("/findDrawDetail")
	@ResponseBody
	public Response findDrawDetail(Integer id, HttpServletRequest request) {
		return Response.response(ResponseCode.SUCCESS_CODE, "查询审核详情成功", ioService.findIODetail(id));
	}

	@RequestMapping("/findDrawByPage")
	@ResponseBody
	public Response findDrawByPage(FinanceIOManageModel model, Integer page, Integer pageSize,
			HttpServletRequest request) {
		model.setType(-1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceIOManageModel> list = financeService.findIOByPage(model, id, level, page, pageSize);
		return Response.success(list);
	}

	@RequestMapping("/findDepositByPage")
	@ResponseBody
	public Response findDepositByPage(FinanceIOManageModel model, Integer page, Integer pageSize,
			HttpServletRequest request) {
		model.setType(1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceIOManageModel> list = financeService.findIOByPage(model, id, level, page, pageSize);
		return Response.success(list);
	}

	@RequestMapping("/findDrawCheckByPage")
	@ResponseBody
	public Response findDrawCheckByPage(FinanceIOManageModel model, Integer page, Integer pageSize,
			HttpServletRequest request) {
		model.setType(-1);
		model.setStatus(0);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceIOManageModel> list = financeService.findIOByPage(model, id, level, page, pageSize);
		return Response.success(list);
	}

	@RequestMapping("/findDrawCheckedByPage")
	@ResponseBody
	public Response findDrawCheckedByPage(FinanceIOManageModel model, Integer page, Integer pageSize,
			HttpServletRequest request) {
		model.setType(-1);
		model.setStatus(1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceIOManageModel> list = financeService.findIOByPage(model, id, level, page, pageSize);
		return Response.success(list);
	}

	@RequestMapping("/findTransferFailedByPage")
	@ResponseBody
	public Response findTransferFailedByPage(FinanceIOManageModel model, Integer page, Integer pageSize,
			HttpServletRequest request) {
		model.setType(-1);
		model.setStatus(5);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceIOManageModel> list = financeService.findIOByPage(model, id, level, page, pageSize);
		return Response.success(list);
	}
}
