package org.dream.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.admin.dao.AdminActorDao;
import org.dream.admin.dao.AdminAuthorizationDao;
import org.dream.admin.model.AdminActorModel;
import org.dream.admin.model.AdminAuthorizationModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.admin.service.AdminUserService;
import org.dream.channel.dao.ChannelDao;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminUserServiceimpl implements AdminUserService {
	@Autowired
	AdminActorDao adminActorDao;

	@Autowired
	AdminAuthorizationDao adminAuthorizationDao;

	@Autowired
	ChannelDao channelDao;

	@Override
	public void createAdminUser(AdminUserModel adminUserModel, Integer departmentId) {
		/**
		 * 页面在提交保存之前已经对User的登录名做了唯一验证
		 */
		adminUserModel.setPassword(adminUserModel.getDefaultPassword());
		if (departmentId != null) {
			adminActorDao.addDepartmentActor(departmentId, adminUserModel.getId());
		}
		adminActorDao.createAdminUser(adminUserModel);
	}

	@Override
	public void grantAuthoritysToActor(Integer actorId, List<Integer> authorityIdList, Integer dataId) {

		for (Integer authorityId : authorityIdList) {
			AdminAuthorizationModel authorizationMoudel = new AdminAuthorizationModel();
			authorizationMoudel.setActorId(actorId);
			authorizationMoudel.setAuthorityId(authorityId);
			authorizationMoudel.setDataId(dataId);

			adminAuthorizationDao.createAuthorization(authorizationMoudel);
		}
	}

	@Override
	public Page<AdminUserModel> pagingquerByDepartmentId(Integer departmentId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<AdminUserModel> userList = adminActorDao.pagingqueryByDepartmentId(departmentId, limit, pageSize);
		Integer totalCount = adminActorDao.pagingqueryByDepartmentId_count(departmentId);

		Page<AdminUserModel> result = new Page<AdminUserModel>(pageIndex, pageSize, totalCount);
		result.setData(userList);

		return result;
	}

	@Override
	public void deleteUserRelation(Integer departmentId, String userIds) {
		String[] userIdArray = userIds.split(",");

		List<Integer> userIdList = new ArrayList<Integer>();
		for (int i = 0; i < userIdArray.length; i++) {
			userIdList.add(Integer.valueOf(userIdArray[i]));
		}
		if (userIdList.size() > 0) {
			adminActorDao.deleteUserRelation(departmentId, userIdList);
		}
	}

	@Override
	public Page<AdminUserModel> pagingqueryNotRelationUsers(Integer pageIndex, Integer pageSize, Integer dataId) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;

		List<AdminUserModel> userModels = adminActorDao.pagingqueryNotRelationUsers(limit, pageSize, dataId);
		Integer totalCount = adminActorDao.pagingqueryNotRelationUsers_count(dataId);

		Page<AdminUserModel> page = new Page<AdminUserModel>(pageIndex, pageSize, totalCount);
		page.setData(userModels);

		return page;
	}

	@Override
	public void createUserRelation(Integer departmentId, String userIds) {
		String[] userIdArray = userIds.split(",");

		for (int i = 0; i < userIdArray.length; i++) {
			adminActorDao.addDepartmentActor(departmentId, Integer.valueOf(userIdArray[i]));
		}
	}

	@Override
	public void updateAdminUserExceptPassword(AdminUserModel adminUserModel) {
		adminActorDao.updateAdminUserExceptPassword(adminUserModel);

	}

	@Override
	public void deleteAdminUser(Integer id, Integer dataId) {
		adminActorDao.deletAdminUser(id, dataId);

	}

	@Override
	public void deleteAdminUsers(List<Integer> ids, Integer dataId) {

		for (Integer id : ids) {
			// 判断帐号是否是 admin 如果是admin的话就不能删除
			AdminUserModel adminUserModel = adminActorDao.getAdminUser(id);
			if (!"admin".equals(adminUserModel.getUserAccount())) {
				//删除用户 删除与用户关联的角色信息
				adminAuthorizationDao.deleteAuthorizationByActorIdAuthorityIds(id, null, null);
				//删除用户 删除与用户关联的部门信息
				adminActorDao.deleteDepartmentActor(id);
				// 删除用户
				adminActorDao.deletAdminUser(id, dataId);
			}

		}

	}

	@Override
	public AdminUserModel getUser(Integer id) {
		return adminActorDao.getAdminUser(id);
	}

	@Override
	public Page<AdminActorModel> getUserList(Integer pageIndex, Integer size, String userAccount, String name,
			String email, Boolean disable, String phone, Integer dataId) {
		Integer limit = pageIndex > 0 ? pageIndex * size : 0 * size;
		// 渠道自建用户
		List<AdminActorModel> userModels = adminActorDao.getUsersBy(limit, size, userAccount, name, email, disable,
				phone, AdminUserModel.CATEGORY, dataId);
		Integer totalCount = adminActorDao.getUserBy_count(userAccount, name, email, disable, phone,
				AdminUserModel.CATEGORY, dataId);
		Page<AdminActorModel> pageResult = new Page<AdminActorModel>(pageIndex, size, totalCount);
		pageResult.setData(userModels);
		return pageResult;
	}

	@Override
	public void changePassword(Integer id, String newPassword) {
//		AdminUserModel userModel = adminActorDao.getAdminUser(id);
//
//		if (userModel != null && userModel.getPassword().equals(new AdminUserModel().handlePassword(oldPassword))) {
//			adminActorDao.updateAdminUserPassword(id, new AdminUserModel().handlePassword(newPassword));
//		}
		adminActorDao.updateAdminUserPassword(id, newPassword);

	}

	@Override
	public void disbaleOrActivationUser(List<Integer> ids, boolean disbale) {
		adminActorDao.disbaleOrActivationUser(ids, disbale);

	}

	@Override
	public AdminUserModel getUserByUserAccountPassword(String userAccount, String password, Integer dataId) {
		password = new AdminUserModel().handlePassword(password);
		return adminActorDao.getUserByUserAccountPassword(userAccount, password, dataId);
	}

	@Override
	public boolean hasUserAccount(String userAccount,Integer dataId) {

		return adminActorDao.getUserBy_count(userAccount, null, null, null, null, null, dataId) > 0;

	}

	@Override
	public void addDepartmentActor(Integer departmentId, Integer actorId) {
		adminActorDao.addDepartmentActor(departmentId, actorId);

	}

	@Override
	public Page<AdminUserModel> pagingqueryByDepartmentId(Integer departmentId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<AdminUserModel> userList = adminActorDao.pagingqueryByDepartmentId(departmentId, limit, pageSize);
		Integer totalCount = adminActorDao.pagingqueryByDepartmentId_count(departmentId);
		Page<AdminUserModel> result = new Page<AdminUserModel>(pageIndex, pageSize, totalCount);
		result.setData(userList);
		return result;
	}

	@Override
	public Page<AdminUserModel> pageQueryActorByRoleId(Integer roleId, Integer dataId, Integer pageIndex,
			Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<AdminUserModel> userList = adminActorDao.pageQueryActorByRoleId(roleId, dataId, limit, pageSize);
		Integer totalCount = adminActorDao.pageQueryActorByRoleId_count(roleId, dataId);
		Page<AdminUserModel> result = new Page<AdminUserModel>(pageIndex, pageSize, totalCount);
		result.setData(userList);
		return result;
	}

	@Override
	public void deleteUserInRole(Integer roleId, Integer actorId, Integer dataId) {
		adminActorDao.deleteUserInRole(roleId, actorId, dataId);
	}

	@Override
	public Integer getChannelLevelByDomain(String str) {
		
		return adminActorDao.getChannelLevelByDomain(str);
	}

}
