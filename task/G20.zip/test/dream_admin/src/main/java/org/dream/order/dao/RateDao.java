package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.Rate;

public interface RateDao {
	
	    int getRate(@Param("currency")String currency,@Param("channelId")int channelId);
	    
	 	int removeByPrimaryKey(String[] ids);

	    int insertSelective(Rate record);

	    Rate selectByPrimaryKey(Integer id);

	    int updateByPrimaryKeySelective(Rate record);
	    
	    List<Rate> pagingQueryRate(Map map);
	    
	    int pagingQueryRateCount(Map map);
	    
	    public Rate getRateById(Integer rateId);
	    
	    public List<Rate> getRates(String [] ids);
	    
	    public List<Rate> getCurrency();
	    
	    public void updateRate(Rate rate);
	    
	    public List<Rate> getRatesByCurrency(String currency);
	    
	    public int hasSunRate(int id);
	    
	    public void remove(int id);
	    
	    public Rate getRateByCurrency(String currency);
	    

}
