package org.dream.finance.service.impl;

import java.util.List;

import org.dream.finance.dao.FinanceBankDao;
import org.dream.finance.dao.FinanceCertDao;
import org.dream.finance.dao.FinanceChannelPayDao;
import org.dream.finance.dao.FinancePayPlatformBankDao;
import org.dream.finance.service.FinanceChannelService;
import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.model.finance.FinanceTransferCertModel;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceChannelServiceImpl implements FinanceChannelService {
	@Autowired
	private FinanceCertDao certDao;
	@Autowired
	private FinancePayPlatformBankDao payPlatformBankDao;
	@Autowired
	private FinanceChannelPayDao channelPayDao;
	@Autowired
	private FinanceBankDao bankDao;

	@Override
	public Page<FinancePayPlatformBankModel> findPayPlatformBank(String payPlatform, Integer status, Integer page,
			Integer pageSize) {
		Integer offset = page > 0 ? page * pageSize : 0;
		List<FinancePayPlatformBankModel> list = payPlatformBankDao.findByPage(payPlatform, status, offset, pageSize);
		Integer rows = payPlatformBankDao.findRows(payPlatform, status);
		Page<FinancePayPlatformBankModel> payPlatformBankPage = new Page<>(page, pageSize, rows);
		payPlatformBankPage.setData(list);
		return payPlatformBankPage;
	}

	@Override
	public Integer findPayPlatformBankRows(String payPlatform, Integer status) {
		return payPlatformBankDao.findRows(payPlatform, status);
	}

	@Override
	public void saveChannelPay(Integer channelId, Integer bankId, Double limitSingle, Double limitDay, String payRule) {
		FinanceChannelPayModel channelPayModel = new FinanceChannelPayModel();
		channelPayModel.setChannelId(channelId);
		channelPayModel.setBankId(bankId);
		channelPayModel.setLimitSingle(limitSingle);
		channelPayModel.setLimitDay(limitDay);
		channelPayModel.setPayRule(payRule);
		channelPayDao.save(channelPayModel);
	}

	private FinanceTransferCertModel createTransferCertModel(Integer channelId, String platform, String parameter) {
		FinanceTransferCertModel certModel = new FinanceTransferCertModel();
		certModel.setChannelId(channelId);
		certModel.setPlatform(platform);
		certModel.setParameter(parameter);
		return certModel;
	}

	// 银行相关
	@Override
	public FinanceBankModel findBank(Integer bankId, Integer status) {
		return bankDao.findBank(bankId, status);
	}

	@Override
	public void saveFinanceBank(String icon, String name, Integer index) {
		FinanceBankModel bankModel = new FinanceBankModel();
		bankModel.setIcon(icon);
		bankModel.setName(name);
		bankModel.setIndex(index);
		bankDao.saveFinanceBank(bankModel);
	}

	@Override
	public void updateFinanceBank(Integer id, String icon, String name, Integer index, Integer status) {
		FinanceBankModel bankModel = new FinanceBankModel();
		bankModel.setId(id);
		bankModel.setIcon(icon);
		bankModel.setName(name);
		bankModel.setIndex(index);
		bankModel.setStatus(status);
		bankDao.updateFinanceBank(bankModel);

	}

	@Override
	public Page<FinanceBankModel> querypagingBank(String name, String icon, Integer index, Integer status,
			Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0;
		List<FinanceBankModel> resultList = bankDao.querypaging(name, icon, index, status, limit, pageSize);
		Integer resultCount = bankDao.querypaging_count(name, icon, index, status);
		Page<FinanceBankModel> reslutPage = new Page<>(pageIndex, pageSize, resultCount);
		reslutPage.setData(resultList);
		return reslutPage;
	}

	@Override
	public void removeChannelPay(Integer id) {
		channelPayDao.remove(id);

	}

	@Override
	public void updateChannelPay(Integer id, Integer channelId, Integer bankId, Double limitSingle, Double limitDay,
			String payRule) {
		FinanceChannelPayModel channelPayModel = new FinanceChannelPayModel();
		channelPayModel.setId(id);
		channelPayModel.setChannelId(channelId);
		channelPayModel.setBankId(bankId);
		channelPayModel.setLimitSingle(limitSingle);
		channelPayModel.setLimitDay(limitDay);
		channelPayModel.setPayRule(payRule);
		channelPayDao.update(channelPayModel);

	}

	@Override
	public Page<FinanceChannelPayModel> querypagingChannelPay(Integer channelId, Integer bankId, Double limitSingle,
			Double limitDay, String payRule, Integer status, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0;
		List<FinanceChannelPayModel> resultList = channelPayDao.querypaging(channelId, bankId, limitSingle, limitDay,
				payRule, status, limit, pageSize);
		Integer resultCount = channelPayDao.querypaging_count(channelId, bankId, limitSingle, limitDay, payRule,
				status);
		Page<FinanceChannelPayModel> pageResult = new Page<>(pageIndex, pageSize, resultCount);
		pageResult.setData(resultList);
		return pageResult;
	}

}
