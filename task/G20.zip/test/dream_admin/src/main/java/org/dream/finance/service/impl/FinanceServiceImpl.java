package org.dream.finance.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.dao.FinanceMainDao;
import org.dream.finance.service.BasicFinanceService;
import org.dream.finance.service.FinanceService;
import org.dream.model.finance.FinanceAccModel;
import org.dream.model.finance.FinanceDrawModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;

@Service
public class FinanceServiceImpl implements FinanceService {
	@Autowired
	private BasicFinanceService basicFinanceService;
	@Autowired
	private FinanceIODao ioDao;

	@Override
	public List<FinanceDrawModel> findDrawByPage(Integer status, Integer channelId, Integer offset, Integer pageSize) {
		return basicFinanceService.findDrawByPage(status, channelId, offset, pageSize);
	}

	@Override
	public Integer findDrawRows(Integer status, Integer channelId) {
		return basicFinanceService.findDrawRows(status, channelId);
	}

	@Override
	public void checkDraw(Integer status, String ioIds) {
		String[] ioIdsArray = ioIds.split(",");
		List<Integer> ioIdList = new ArrayList<Integer>();
		for (int i = 0; i < ioIdsArray.length; i++) {
			ioIdList.add(Integer.valueOf(ioIdsArray[i]));
		}
		if (ioIdList.size() > 0)
			basicFinanceService.checkDraw(status, ioIdList);
	}

	@Override
	public FinanceMainModel findMain(Integer userId) {
		return basicFinanceService.findMain(userId);
	}

	@Override
	public FinanceAccModel findAcc(Integer userId) {
		return basicFinanceService.findAcc(userId);
	}

	@Override
	public Page<FinanceFlowManageModel> findFlowByPage(Integer id, Integer level, String createTimeStart,
			String createTimeEnd, Integer userId, String userName, String userPhone, Integer channelId,
			Integer topChannelId, Integer type, Integer typeDetail, String remark, Integer page, Integer pageSize,
			String flow) {
		if (level == 1) {
			topChannelId = id;
		} else if (level == 2) {
			channelId = id;
		}
		Integer offset = page > 0 ? page * pageSize : 0;
		List<FinanceFlowManageModel> list = basicFinanceService.findFlowByPage(createTimeStart, createTimeEnd, userId,
				userName, userPhone, channelId, topChannelId, type, typeDetail, remark, offset, pageSize, flow);
		Integer rows = basicFinanceService.findFlowRows(createTimeStart, createTimeEnd, userId, userName, userPhone,
				channelId, topChannelId, type, typeDetail, remark, flow);
		Page<FinanceFlowManageModel> flowPage = new Page<>(page, pageSize, rows);
		flowPage.setData(list);
		return flowPage;
	}

	@Override
	public Integer findFlowRows(Integer id, Integer level, String createTimeStart, String createTimeEnd, Integer userId,
			String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, String flow) {
		if (level == 1) {
			topChannelId = id;
		} else if (level == 2) {
			channelId = id;
		}
		return basicFinanceService.findFlowRows(createTimeStart, createTimeEnd, userId, userName, userPhone, channelId,
				topChannelId, type, typeDetail, remark, flow);
	}

	@Override
	public Page<FinanceIOManageModel> findIOByPage(FinanceIOManageModel model, Integer id, Integer level, Integer page,
			Integer pageSize) {
		if (level == 1) {
			model.setTopChannelId(id);
		} else if (level == 2) {
			model.setChannelId(id);
		}
		Integer offset = page > 0 ? page * pageSize : 0;
		List<FinanceIOManageModel> list = basicFinanceService.findIOByPage(model, offset, pageSize);
		Integer rows = basicFinanceService.findIORows(model);
		Page<FinanceIOManageModel> ioPage = new Page<>(page, pageSize, rows);
		ioPage.setData(list);
		return ioPage;
	}

	@Override
	public List<FinanceTransferModel> saveTransfer(String ioIds, FinanceTransferType transferType,
			FinancePayType payType, String operator) {
		String[] ioIdsArray = ioIds.split(",");
		List<Integer> ioIdList = new ArrayList<Integer>();
		for (int i = 0; i < ioIdsArray.length; i++) {
			ioIdList.add(Integer.valueOf(ioIdsArray[i]));
		}
		return basicFinanceService.saveTransfer(ioIdList, transferType, payType, operator);
		// basicFinanceService.saveTransfer(ioIdList, transferType, payType,
		// operator);
		// return null;
	}

	@Override
	public Page<FinanceTransferManageModel> findTransferByPage(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId, Integer page,
			Integer pageSize) {
		Integer offset = page > 0 ? page * pageSize : 0;
		List<FinanceTransferManageModel> list = basicFinanceService.findTransferByPage(userId, userName, userPhone,
				realName, transferType, status, operator, createTimeStart, createTimeEnd, updateTimeStart,
				updateTimeEnd, topChannelId, offset, pageSize);
		Integer rows = basicFinanceService.findTransferRows(userId, userName, userPhone, realName, transferType, status,
				operator, createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd, topChannelId);
		Page<FinanceTransferManageModel> transferPage = new Page<>(page, pageSize, rows);
		transferPage.setData(list);
		return transferPage;
	}

	@Override
	public FinanceTransferManageModel findTransfer(Integer topChannelId, Integer transferId) {
		return basicFinanceService.findTransfer(topChannelId, transferId);
	}

	@Override
	public FinanceIOManageModel findByid(Integer id) {
		return basicFinanceService.findById(id);
	}

	// v2
	@Override
	public Response systemMakeMoney(Integer id, Double money) {
		basicFinanceService.systemMakeMoney(id, money);
		return Response.response(ResponseCode.SUCCESS_CODE, "系统补单成功");
	}

	// ******************************************************************

	@Override
	public void newSelfOrderId(String ioIds) {
		String[] ioIdsArray = ioIds.split(",");
		List<Integer> ioIdList = new ArrayList<Integer>();
		for (int i = 0; i < ioIdsArray.length; i++) {
			ioIdList.add(Integer.valueOf(ioIdsArray[i]));
		}
		ioDao.updateSelfOrderIdByIOIds(ioIdList);
	}
}
