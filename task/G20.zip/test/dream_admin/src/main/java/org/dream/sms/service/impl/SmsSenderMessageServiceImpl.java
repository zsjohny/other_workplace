package org.dream.sms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.dream.model.sms.SmsSenderMessage;
import org.dream.sms.dao.SmsSenderMessageDao;
import org.dream.sms.service.SmsSenderMessageService;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class SmsSenderMessageServiceImpl implements SmsSenderMessageService {

	@Resource(name = "senderMessageChangendSender")
	JmsSender jmsSender;

	@Autowired
	SmsSenderMessageDao smsSenderMessageDao;

	public static final Integer SMS_ISDELETE = 1;// 表示未删除状态

	@Override
	public void createSenderMessage(SmsSenderMessage senderMseeage) {
		smsSenderMessageDao.createSenderMessage(senderMseeage);
		sendMsg(senderMseeage);
	}

	@Override
	public void updateSenderMessage(SmsSenderMessage senderMseeage) {
		smsSenderMessageDao.updateSenderMessage(senderMseeage);
		SmsSenderMessage message = smsSenderMessageDao.getSenderMsgById(null, null, senderMseeage.getId());
		sendMsg(message);
	}

	@Override
	public Page<SmsSenderMessage> pagingQuery(Integer type, Integer channelId, Integer status, Integer pageIndex,
			Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<SmsSenderMessage> page = smsSenderMessageDao.pagingQuery(type, channelId, status, SMS_ISDELETE, limit,
				pageSize);
		int totalCount = smsSenderMessageDao.pagingQuery_count(type, channelId, status, SMS_ISDELETE);
		Page<SmsSenderMessage> resultPage = new Page<SmsSenderMessage>(pageIndex, pageSize, totalCount);
		resultPage.setData(page);
		return resultPage;
	}

	/**
	 * 添加时验证该渠道下 是否已存在该短信渠道
	 */
	@Override
	public boolean hasSender(Integer type, Integer channelId) {
		return smsSenderMessageDao.pagingQuery_count(type, channelId, null, SMS_ISDELETE) > 0;
	}

	@Override
	public Integer hasSenderIsActive(Integer type, Integer channelId, Integer status) {
		return smsSenderMessageDao.pagingQuery_count(type, channelId, status, SMS_ISDELETE);
	}

	@Override
	public SmsSenderMessage getSenderByStatus(Integer status, Integer channelId) {
		return smsSenderMessageDao.getSenderByStatus(status, channelId, SMS_ISDELETE);
	}

	/**
	 * 发送信息
	 * 
	 * @param smsSenderMessage
	 */
	private void sendMsg(SmsSenderMessage smsSenderMessage) {
		jmsSender.sendMessage(JSON.toJSONString(smsSenderMessage));
	}

	@Override
	public void remove(Integer id) {
		smsSenderMessageDao.remove(id);
		SmsSenderMessage message = smsSenderMessageDao.getSenderMsgById(null, null, id);
		sendMsg(message);
	}

	@Override
	public SmsSenderMessage getSenderMsgById(Integer type, Integer channelId) {
		return smsSenderMessageDao.getSenderMsgById(type, channelId, null);
	}

}
