package org.dream.news.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.news.NewsModel;

public interface NewsDao {
	public List<NewsModel> findByPage(@Param("model") NewsModel newsModel, @Param("offset") Integer offset,
			@Param("pageSize") Integer pageSize);

	public Integer findRows(@Param("model") NewsModel newsModel);

	public NewsModel find(NewsModel newsModel);

	public void save(NewsModel newsModel);

	public void update(NewsModel newsModel);

	public void delete(String ids, Integer channelId);
}
