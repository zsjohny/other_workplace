package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.order.FuturesExchangeModel;
import org.dream.utils.mvc.Page;

public interface FuturesExchangeService {

	public Map<String,Object> createFutruresExchange(FuturesExchangeModel futuresExchangeMoudel);

	public void updateFutureExchange(FuturesExchangeModel futuresExchangeMoudel);

	public FuturesExchangeModel getById(Integer Id);

	public List<FuturesExchangeModel> getAll();

	public Page<FuturesExchangeModel> querypaging(String exchangeName, String exchangeCode, String futuresRemark,
			Integer pageIndex, Integer pageSize);

	public void removeFutruresExchangeByIds(String ids);

	public List<FuturesExchangeModel> getExchangeForSelect();
}
