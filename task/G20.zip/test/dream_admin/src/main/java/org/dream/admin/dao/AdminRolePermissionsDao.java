package org.dream.admin.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface AdminRolePermissionsDao {
	/**
	 * 根据角色id和权限id（会是多个删除分配给角色的权限纪录）
	 * 
	 * @param roleId
	 * @param permissionIds
	 */
	void delteRolePermissionByRoleIdPermissions(@Param(value = "roleId") Integer roleId,
			@Param(value = "permissionIds") List<Integer> permissionIds);
}
