package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.ChannelVarietyModel;
import org.dream.model.order.TradingVarietyModel;

public interface ChannelVarietyDao {

	public void insert(ChannelVarietyModel channelVarietyModel);

	public void changeChannelVarietyStatusByIds(@Param(value = "ids") List<Integer> ids,
			@Param(value = "status") Integer status);

	public void deleteChannelVarietiesByIds(@Param(value = "ids") List<Integer> ids);

	public List<ChannelVarietyModel> getChannelVarietyByChannelId(Integer channelId);

	public void updateFirstInvestorAccount(ChannelVarietyModel channelVarietyModel);

	public void updateSecondChannelVariety(ChannelVarietyModel channelVarietyModel);

	public ChannelVarietyModel getChannelVarietyById(@Param(value = "id") Integer id,
			@Param(value = "channelId") Integer channelId, @Param(value = "varietyId") Integer varietyId);

	public void removeVarietyByVarietyId(Integer id);

	public void openVarietyById(Integer id);

	public void deleteChannelVarietiesByVarietyId(Integer varietyId);

	public void updateChannelVarietyFees(ChannelVarietyModel channelVarietyModel);

	public List<ChannelVarietyModel> qureypagingForFirstChannel(@Param(value = "channelId") Integer channelId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public List<ChannelVarietyModel> qureypagingSecondChannel(@Param(value = "channelId") Integer channelId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "channelId") Integer channelId);

	public List<TradingVarietyModel> getVarietyByChannelId(Integer channelId);

	public List<TradingVarietyModel> getVarietyAndSignBySecondChannelId(Integer channelId);

	List<ChannelVarietyModel> findChannelVarietyModelAllByChannelId(Integer channelId);

	List<ChannelVarietyModel> getChannelVarietyByIds(@Param(value = "ids") List<Integer> ids);
}
