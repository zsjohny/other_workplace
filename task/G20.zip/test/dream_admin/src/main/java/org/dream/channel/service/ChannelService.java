package org.dream.channel.service;

import java.util.List;

import org.dream.model.channel.ChannelModel;
import org.dream.utils.mvc.Page;

public interface ChannelService {

	public ChannelModel getById(Integer id);

	public ChannelModel findChannelByDomain(String domain);

	/**
	 * 
	 * @param backstageDomain
	 * @return
	 */
	public ChannelModel findChannelByBackstageDomain(String backstageDomain);

	public List<ChannelModel> findChannelAll();

	public void saveChannel(ChannelModel channelModel);

	public List<ChannelModel> findAllFirstChannels();

	public List<ChannelModel> findSecondChannelsBySuperId(Integer id);

	public void updateChannel(ChannelModel channelModel);

	public String findChannelNameById(Integer id);

	public void removeChannel(Integer id);

	/**
	 * 分页查询渠道列表
	 * 
	 * @param domain
	 * @param name
	 * @param description
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	public Page<ChannelModel> querypaging(String domain, String name, String description, Integer superId,
			String backstageDomain, Integer pageIndex, Integer pageSize);

	/**
	 * 验证渠道(渠道名称)是否已经存在
	 */
	public boolean hasChannel(String domain, String name, String backstageDomain);

	public Integer findCount(String domain, String name, String backstageDomain, Integer id);

}
