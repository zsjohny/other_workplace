package org.dream.config.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQQueue;
import org.dream.config.dao.TimedTaskDao;
import org.dream.config.model.TimedTaskModel;
import org.dream.config.service.TimedTaskService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class TimedTaskServiceImpl implements TimedTaskService {

	private static final String QUEUE_SUFFIX = ".instantly";

	@Autowired
	JmsTemplate jmsTemplate;

	@Autowired
	TimedTaskDao timedTaskDao;

	@Override
	public void saveTiemdTask(TimedTaskModel taskModel) {
		timedTaskDao.createTimedTask(taskModel);

	}

	@Override
	public void deleteByIds(String ids) {
		timedTaskDao.deleteByIds(this.handleIds(ids));

	}

	@Override
	public List<TimedTaskModel> getAllOpenTasks() {

		return timedTaskDao.getAllOpenTask();
	}

	@Override
	public void changeIsOpenByIds(String ids, Boolean isOpen) {
		timedTaskDao.changeIsOpenBIds(this.handleIds(ids), isOpen);

	}

	@Override
	public Page<TimedTaskModel> querypaging(Integer typeId, Boolean isOpen, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;

		List<TimedTaskModel> list = timedTaskDao.querypaging(typeId, isOpen, limit, pageSize);
		Integer totalCount = timedTaskDao.querypaging_count(typeId, isOpen);

		Page<TimedTaskModel> page = new Page<>(pageIndex, pageSize, totalCount);
		page.setData(list);

		return page;
	}

	private List<Integer> handleIds(String ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public void updateTiemdTask(TimedTaskModel taskModel) {
		timedTaskDao.updateTimedTask(taskModel);
	}

	@Override
	public void instantlyExecute(int taskId, String taskType, String parameters) {

		sendTradeMessage(taskId, taskType, parameters);
	}

	public void sendTradeMessage(final int taskId, String queueName, final String parameters) {
		ActiveMQQueue mqQueue = new ActiveMQQueue(queueName);

		jmsTemplate.send(mqQueue, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				Map<String, Object> map = new HashMap<>();
				map.put("parameters", parameters);
				map.put("taskId", taskId);
				map.put("triggerTime", System.currentTimeMillis());
				TextMessage msg = (TextMessage) session.createTextMessage(JSON.toJSONString(map));
				return msg;
			}
		});

	}
}
