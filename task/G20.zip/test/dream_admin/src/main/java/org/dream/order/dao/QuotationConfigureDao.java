package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.QuotationConfigureModel;

/**
 * 期货行情配置Dao
 * 
 * @author ZY
 *
 */
public interface QuotationConfigureDao {

	public void creatQuotationConfigure(QuotationConfigureModel quotationConfigureModel);

	public void updateQuotationConfigure(QuotationConfigureModel quotationConfigureModel);

	public QuotationConfigureModel getBy(@Param(value = "id") Integer id);

	public void deleteByIds(@Param(value = "ids") List<Integer> ids);

	public List<QuotationConfigureModel> querypaging(@Param(value = "exchangeId") Integer exchangeId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer querypaging_count(@Param(value = "exchangeId") Integer exchangeId,
			@Param(value = "varietyId") Integer varietyId);
}
