package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceFlowModel;

public interface FinanceFlowDao {
	public void save(FinanceFlowModel financeFlowModel);

	public void saveScore(FinanceFlowModel financeFlowModel);

	public List<FinanceFlowManageModel> findByPage(@Param("createTimeStart") String createTimeStart,
			@Param("createTimeEnd") String createTimeEnd, @Param("userId") Integer userId,
			@Param("userName") String userName, @Param("userPhone") String userPhone,
			@Param("channelId") Integer channelId, @Param("topChannelId") Integer topChannelId,
			@Param("type") Integer type, @Param("typeDetail") Integer typeDetail, @Param("remark") String remark,
			@Param("offset") Integer offset, @Param("pageSize") Integer pageSize, @Param("flow") String flow);

	public Integer findRows(@Param("createTimeStart") String createTimeStart,
			@Param("createTimeEnd") String createTimeEnd, @Param("userId") Integer userId,
			@Param("userName") String userName, @Param("userPhone") String userPhone,
			@Param("channelId") Integer channelId, @Param("topChannelId") Integer topChannelId,
			@Param("type") Integer type, @Param("typeDetail") Integer typeDetail, @Param("remark") String remark,
			@Param("flow") String flow);
}
