package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.model.order.QuotationConfigureModel;
import org.dream.order.dao.QuotationConfigureDao;
import org.dream.order.service.QuotationConfigureService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QuotationConfigureServiceImpl implements QuotationConfigureService {

	@Autowired
	QuotationConfigureDao quotationConfigureDao;

	@Override
	public void saveQuotationConfigure(QuotationConfigureModel quotationConfigureModel) {

		quotationConfigureDao.creatQuotationConfigure(quotationConfigureModel);
	}

	@Override
	public void updateQuotationConfigure(QuotationConfigureModel quotationConfigureModel) {
		quotationConfigureDao.updateQuotationConfigure(quotationConfigureModel);
	}

	@Override
	public void delteByIds(String ids) {
		quotationConfigureDao.deleteByIds(this.handleIds(ids));
	}

	@Override
	public QuotationConfigureModel getBy(Integer id) {

		return quotationConfigureDao.getBy(id);
	}

	@Override
	public Page<QuotationConfigureModel> querypaging(Integer exchangeId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<QuotationConfigureModel> list = quotationConfigureDao.querypaging(exchangeId, limit, pageSize);
		Integer totalCount = quotationConfigureDao.querypaging_count(exchangeId, null);

		Page<QuotationConfigureModel> page = new Page<QuotationConfigureModel>(pageIndex, pageSize, totalCount);
		page.setData(list);
		return page;
	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public Integer getVarietyCount(Integer varietyId) {
		return quotationConfigureDao.querypaging_count(null, varietyId);
	}
}
