package org.dream.order.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.order.VarietyPriceModel;
import org.dream.order.service.VarietyPriceService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.dream.utils.prop.SpringProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 品种价格
 * 
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author yehx
 * @date 2016年7月4日 下午1:30:49
 */
@RequestMapping("/varietyPrice")
@Controller
public class VarietyPriceController extends BaseController {
	private static Logger logger = LoggerFactory.getLogger(VarietyPriceController.class);
	@Autowired
	private VarietyPriceService varietyPriceService;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;
	@Autowired
	private SpringProperties springProperties;

	/**
	 * 查找品种，用于前端的下拉框显示
	 * 
	 */
	@RequestMapping(value = "getVariety", method = { RequestMethod.POST })
	@ResponseBody
	public Response getVariety() {
		List<Map<String, Object>> map = varietyPriceService.getVariety();

		return Response.success(map);
	}

	/**
	 * 新增
	 * 
	 */
	@RequestMapping(value = "/save", method = { RequestMethod.POST })
	@ResponseBody
	public Response saveVarietyPrice(VarietyPriceModel varietyPriceModel, HttpServletRequest request) {
		if (StringUtils.isBlank(varietyPriceModel.getVarietyId().toString())
				|| StringUtils.isBlank(varietyPriceModel.getCurrency())
				|| StringUtils.isBlank(varietyPriceModel.getEachPointMoney().toString())
				|| StringUtils.isBlank(varietyPriceModel.getBeatFewPoints().toString())
				|| StringUtils.isBlank(varietyPriceModel.getMarketPoint().toString())
				|| StringUtils.isBlank(varietyPriceModel.getMarginPoint().toString())
				|| StringUtils.isBlank(varietyPriceModel.getFeesPoint().toString())) {
			return Response.response(600, "请求参数错误");
		}
		Integer userId = (Integer) request.getSession().getAttribute("userId");
		varietyPriceModel.setCreateUserId(userId);
		Map<String, Object> map = varietyPriceService.saveVarietyPrice(varietyPriceModel);
		if ("0".equals(map.get("resCode"))) {
			return Response.response(600, (String) map.get("resMgs"));
		}
		return Response.success();
	}

	/**
	 * 修改
	 * 
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateVarietyPrice(VarietyPriceModel varietyPriceModel, HttpServletRequest request) {
		if (StringUtils.isBlank(varietyPriceModel.getId().toString())
				|| StringUtils.isBlank(varietyPriceModel.getCurrency())
				|| StringUtils.isBlank(varietyPriceModel.getEachPointMoney().toString())
				|| StringUtils.isBlank(varietyPriceModel.getBeatFewPoints().toString())
				|| StringUtils.isBlank(varietyPriceModel.getMarketPoint().toString())
				|| StringUtils.isBlank(varietyPriceModel.getMarginPoint().toString())
				|| StringUtils.isBlank(varietyPriceModel.getFeesPoint().toString())) {
			return Response.response(600, "请求参数错误");
		}
		Integer userId = (Integer) request.getSession().getAttribute("userId");
		varietyPriceModel.setUpdateUserId(userId);
		Map<String, Object> map = varietyPriceService.updateVarietyPrice(varietyPriceModel);
		return Response.success(map);
	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	/**
	 * 删除
	 */
	@RequestMapping(value = "/remove", method = { RequestMethod.POST })
	@ResponseBody
	public Response removeVarietyPrice(String ids) {
		Assert.notNull(ids, "ids不能为空");
		List<Integer> idList = handleIds(ids);
		for (Integer id : idList) {
			varietyPriceService.removeVarietyPrice(id);
		}
		return Response.success();
	}

	/**
	 * 查询
	 * 
	 */
	@RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryVarietyPrice(Integer page, Integer pageSize, Integer varietyId, String createTimeStart,
			String createTimeEnd) {
		Page<VarietyPriceModel> data = varietyPriceService.pagingQueryVarietyPrice(page, pageSize, varietyId,
				createTimeStart, createTimeEnd);
		return Response.success(data);
	}

	/**
	 * 根据id得到某个品种价格信息
	 * 
	 */
	@RequestMapping(value = "/getVarietyPrice")
	@ResponseBody
	public Response getVarietyPriceById(Integer id) {
		Assert.notNull(id, "id不能为空");
		VarietyPriceModel v = varietyPriceService.getVarietyPriceById(id);
		return Response.success(v);
	}

}
