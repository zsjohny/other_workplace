package org.dream.finance.service;

import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;

public interface FinancePayPlatformBankService {

	public Response saveFinancePayPlatformBank(FinancePayPlatformBankModel financePayPlatformBankModel);

	public Response updateFinancePayPlatformBank(FinancePayPlatformBankModel financePayPlatformBankModel);

	public void remoceFinancePayPlatformBank(Integer id);

	public FinancePayPlatformBankModel getById(Integer id);

	public Page<FinancePayPlatformBankModel> querypaging(String bankName, String payPlatform, Integer status,
			Integer pageIndex, Integer pageSize);

	public Response findPayPlatformBankAll(FinanceCertModel certModel);

	public Response findChannelPayPlatformAll(FinanceCertModel certModel, Integer bankId);
}
