package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.config.model.TaskTypeModel;
import org.dream.model.order.ExchangeTimeModel;
import org.dream.model.order.FuturesExchangeModel;
import org.dream.schedule.model.TimedTaskModel;

public interface ExchangeTimeDao {
	
	public int  getCountTimeIsIntervalStartTime(ExchangeTimeModel exchangeTimeModel);
	
	public int  getCountTimeIsIntervalEndTime(ExchangeTimeModel exchangeTimeModel);
	
	public void saveExchangeTime(ExchangeTimeModel exchangeTimeModel);
	
	public TaskTypeModel getTaskTypeModelForTaskType(String taskType);
	
	public void insertTimeTask(TimedTaskModel t);
	
	public List<ExchangeTimeModel> pagingQueryExchangeTime(Map map);
	
	public int pagingQueryExchangeTimeCount(Map map);
	
	public void updateExchangeTime(ExchangeTimeModel exchangeTimeModel);
	
	public void deleteTimesTaskByExchangeTimeId(String [] exchangeTimeIds);
	
	public Integer getTimesTaskIdsByExchangeTimeId(int id);
	
	public void deleteExchangeTimeById(String[]ids);
	
	public void updateTimesTask(TimedTaskModel t);
	
	public ExchangeTimeModel getExchangeTimeInfo(int id);
	
	public List<FuturesExchangeModel> getExchange();
	
	public List<Integer> getTimesTaskIdsByIds(String [] ids);

}
