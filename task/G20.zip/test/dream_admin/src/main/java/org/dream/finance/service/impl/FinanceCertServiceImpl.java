package org.dream.finance.service.impl;

import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.dream.finance.dao.FinanceCertDao;
import org.dream.finance.service.FinanceCertService;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

@Service
public class FinanceCertServiceImpl implements FinanceCertService {
	private static final Integer SUCCESS_CODE = 200;
	private static final Integer ERROR_CODE = 600;
	@Autowired
	private FinanceCertDao certDao;

	// V3
	@Override
	public List<FinancePayPlatformModel> findPayPlatformByCert(FinanceCertModel certModel) {
		return certDao.findPayPlatformByCert(certModel);
	}
	// *******************************************************************

	// V2
	private void formatParameter(FinanceCertModel model) {
		JSONObject parameter = JSONObject.parseObject(model.getParameter());
		Set<Entry<String, Object>> set = parameter.entrySet();
		for (Entry<String, Object> entry : set) {
			entry.setValue("******");
		}
		model.setParameter(JSONObject.toJSONString(set));
	}

	@Override
	public Response findCertByPage(FinanceCertModel certModel, Integer page, Integer pageSize) {
		Integer offset = page > 0 ? page * pageSize : 0;
		List<FinanceCertModel> list = certDao.findByPage(certModel, offset, pageSize);
		if (list == null) {
			return Response.response(ERROR_CODE, "查询失败");
		}
		for (FinanceCertModel model : list) {
			formatParameter(model);
		}
		Integer rows = certDao.findRows(certModel);
		Page<FinanceCertModel> certPage = new Page<>(page, pageSize, rows);
		certPage.setData(list);
		return Response.response(SUCCESS_CODE, "查询成功", certPage);
	}

	@Override
	public Response findCert(FinanceCertModel certModel) {
		FinanceCertModel model = certDao.find(certModel);
		if (model == null) {
			return Response.response(ERROR_CODE, "查询失败");
		}
		formatParameter(model);
		return Response.response(SUCCESS_CODE, "查询成功", model);
	}

	@Override
	public Response saveCert(FinanceCertModel certModel) {
		FinanceCertModel model = certDao.find(certModel);
		if (model != null)
			return Response.response(ERROR_CODE, "该证书已保存，请勿重复提交");
		Integer result = certDao.save(certModel);
		if (result == 1)
			return Response.response(SUCCESS_CODE, "保存证书成功");
		return Response.response(ERROR_CODE, "保存证书失败");
	}

	@Override
	public Response updateCert(FinanceCertModel certModel) {
		// FinanceCertModel model = certDao.find(certModel);
		// JSONObject object = JSONObject.parseObject(model.getParameter());
		Integer result = certDao.update(certModel);
		if (result == 1)
			return Response.response(SUCCESS_CODE, "更新证书成功");
		return Response.response(ERROR_CODE, "更新证书失败");
	}
	// *********************************************************

	@Override
	public List<String> findPlatformAll(FinanceCertModel certModel) {
		return certDao.findPlatformAll(certModel);
	}

}
