package org.dream.sms.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.sms.SmsSenderMessage;
import org.dream.sms.service.SmsSenderMessageService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/smsSenderMessage")
public class SmsSenderMessageController extends BaseController {

	@Autowired
	SmsSenderMessageService smsSenderMessageService;

	@RequestMapping(value = "/addSenderMessage", method = { RequestMethod.POST })
	@ResponseBody
	public Response addSenderMessage(Integer type, String account, String password,
			HttpServletRequest request) {
		Assert.notNull(type, "添加类型不能为空");
		Assert.notNull(account, "添加账户不能为空");
		Assert.notNull(password, "添加密码不能为空");
		SmsSenderMessage smsSenderMessage = new SmsSenderMessage();
		// 验证该渠道是否已存在
		if (smsSenderMessageService.hasSender(type, super.getDataId(request))) {
			return Response.error("添加发送渠道失败，已存在的渠道");
		}
		smsSenderMessage.setType(type);
		smsSenderMessage.setAccount(account);
		smsSenderMessage.setPassword(password);
		smsSenderMessage.setChannelId(super.getDataId(request));
		// 验证改渠道下是否已存在激活的短信渠道 若存在则不能添加激活的渠道
//		Integer row = smsSenderMessageService.hasSenderIsActive(null, super.getDataId(request),
//				SmsSenderMessage.STATUS);
//		if (row > 0) {
//			return Response.error("添加发送渠道失败，已存在已经被激活的渠道");
//		}
//		smsSenderMessage.setStatus(status);
		smsSenderMessageService.createSenderMessage(smsSenderMessage);
		return Response.success();
	}

	@RequestMapping(value = "/updateSenderMessage", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateSenderMessage(Integer id, Integer type, String account, String password, Integer status,
			HttpServletRequest request) {
		Assert.notNull(id, "修改id不能为空");
		Assert.notNull(type, "修改类型不能为空");
		Assert.notNull(account, "修改账户不能为空");
		Assert.notNull(password, "修改密码不能为空");
		SmsSenderMessage smsSenderMessage = new SmsSenderMessage();
		smsSenderMessage.setId(id);
		if (smsSenderMessageService.hasSender(type, super.getDataId(request))) {
			SmsSenderMessage message = smsSenderMessageService.getSenderMsgById(type,super.getDataId(request));
			if (message.getId() != id) {
				return Response.error("修改发送渠道失败，已存在的渠道");
			}
		}
		smsSenderMessage.setType(type);
		smsSenderMessage.setAccount(account);
		smsSenderMessage.setPassword(password);
		// 验证改渠道下是否已存在激活的短信渠道 若存在则不能激活
		Integer row = smsSenderMessageService.hasSenderIsActive(null, super.getDataId(request),
				SmsSenderMessage.STATUS);
		if (row == 0) {
			smsSenderMessage.setStatus(status);
		} else if (row > 0) {
			SmsSenderMessage list = smsSenderMessageService.getSenderByStatus(SmsSenderMessage.STATUS,
					super.getDataId(request));
			if (list.getId() == id) {
				smsSenderMessage.setStatus(status);
			} else if (list.getId() != id) {
				if (status == 1) {
					smsSenderMessage.setStatus(status);
				} else {
					return Response.error("激活渠道失败，已存在激活的渠道");
				}
			}
		}

		smsSenderMessageService.updateSenderMessage(smsSenderMessage);
		return Response.success();
	}

	@RequestMapping(value = "/pagingQuery", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQuery(HttpServletRequest request, Integer page, Integer pageSize) {
		return Response
				.success(smsSenderMessageService.pagingQuery(null, super.getDataId(request), null, page, pageSize));
	}

	@RequestMapping(value = "/delete", method = { RequestMethod.POST })
	@ResponseBody
	public Response delete(Integer id) {
		smsSenderMessageService.remove(id);
		return Response.success();
	}

}
