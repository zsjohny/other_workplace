package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.order.TradingVarietyModel;
import org.dream.order.dao.TradingVarietyDao;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TradingVarietyServiceImpl implements TradingVarietyService {

	@Autowired
	TradingVarietyDao tradingVarietyDao;

	@Override
	public Map<String,Object> saveFutureExchange(TradingVarietyModel tradingVarietyModel) {
		Map<String,Object> retMap = new HashMap<String,Object>();
		//首先判断品种名称，品种代码，行情交易所代码，行情品种代码
		int countVarietyName = tradingVarietyDao.getCountByVareityName(tradingVarietyModel.getVarietyName());
		if(countVarietyName >0){
			retMap.put("retCode", "0");
			retMap.put("retmsg", "品种名称已存在");
			return retMap;
		}
		//判断品种代码
		int countVarietyType=tradingVarietyDao.getCountByVareityType(tradingVarietyModel.getVarietyType());
		if(countVarietyType >0){
			retMap.put("retCode", "0");
			retMap.put("retmsg", "品种代码已存在");
			return retMap;
		}
		int quotaVarietyCode=tradingVarietyDao.getCountByQuotaVarietyCode(tradingVarietyModel.getVarietyType());
		if(quotaVarietyCode >0){
			retMap.put("retCode", "0");
			retMap.put("retmsg", "行情品种代码已存在");
			return retMap;
		}
		tradingVarietyDao.createTradingVariety(tradingVarietyModel);
		retMap.put("retCode", "1");
		return retMap;
	}

	@Override
	public void updateFutureExchange(TradingVarietyModel tradingVarietyModel) {

		tradingVarietyDao.updateTradingVariety(tradingVarietyModel);

	}

	@Override
	public TradingVarietyModel getById(Integer id) {

		return tradingVarietyDao.getById(id);
	}

	@Override
	public Page<TradingVarietyModel> querypaging(String varietyName, String varietyType, String exchangeName,
			String varietyRemark, Integer status, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<TradingVarietyModel> tradingVarietyModels = tradingVarietyDao.qureypaging(varietyName, varietyType,
				exchangeName, varietyRemark, status, limit, pageSize);
		int totalCount = tradingVarietyDao.qureypaging_count(varietyName, varietyType, exchangeName, varietyRemark,
				status);

		Page<TradingVarietyModel> resultPage = new Page<>(pageIndex, pageSize, totalCount);
		resultPage.setData(tradingVarietyModels);

		return resultPage;
	}

	private List<Integer> handleIds(String ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public List<TradingVarietyModel> getByExchangeId(Integer exchangeId) {

		return tradingVarietyDao.getByExchangeId(exchangeId);
	}

	/**
	 * 获取平台下所有可售品种
	 */
	public List<TradingVarietyModel> getEffectiveTradingVarieties() {
		return tradingVarietyDao.getEffectiveTradingVarieties();
	}

	/**
	 * 
	 */
	public void removeTradingVarietyById(Integer id, Integer status) {
		tradingVarietyDao.removeTradingVarietyById(id, status);
	}

	public void removeByIds(String ids) {
		tradingVarietyDao.removeByIds(this.handleIds(ids));
	}

	@Override
	public List<TradingVarietyModel> getAllTradingVarieties() {
		return tradingVarietyDao.getAllTradingVarieties();
	}
}
