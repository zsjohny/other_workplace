package org.dream.push.service;

import org.dream.model.push.PushModel;

import java.util.List;

/**
 * 推送的实体类
 * Created by nessary on 16-9-27.
 */
public interface PushService {

    /**
     * 保存推送实体类
     *
     * @param pushModel 推送实体类
     */
    void savePushModel(PushModel pushModel);


    /**
     * 更改推送的内容 包含软删除 之类的
     *
     * @param pushModel 推送实体类
     */
    void updatePushModel(PushModel pushModel);


    /**
     * 分页查找当前渠道下的所有的设置的信息
     *
     * @param pushModel 推送实体类
     * @return
     */
    List<PushModel> findAllPushModel(PushModel pushModel);


    /**
     * 立即执行 推送
     *
     * @param pushModel 推送实体类
     */
    void executePush(PushModel pushModel);
    /**
     * 根据Id寻找推送内容
     *
     * @param pushModel 推送实体类
     * @return
     */
    PushModel findPushModelById(PushModel pushModel);

}
