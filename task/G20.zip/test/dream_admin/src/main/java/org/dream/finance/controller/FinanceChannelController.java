package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminUserModel;
import org.dream.finance.service.FinanceChannelService;
import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceChannelController extends BaseController {
	private static Logger logger = LoggerFactory.getLogger(FinanceChannelController.class);
	@Autowired
	private FinanceChannelService channelService;

	/**
	 * 增加证书
	 * 
	 * @param payPlatform
	 * @param password
	 * @param memberId
	 * @param terminalId
	 * @param extra
	 * @param request
	 * @return
	 */
	// @RequestMapping("/savePayCert")
	// @ResponseBody
	// public Response saveCert(String payPlatform, String password, String
	// memberId, String terminalId, String extra,
	// HttpServletRequest request) {
	// AdminUserModel userModel = (AdminUserModel)
	// request.getSession().getAttribute("user");
	// Integer channelId = userModel.getDataId();
	// Assert.notNull(channelId);
	// Assert.notNull(payPlatform);
	// Assert.notNull(password);
	// Assert.notNull(memberId);
	// DiskFileItemFactory factory = new DiskFileItemFactory();
	// ServletFileUpload upload = new ServletFileUpload(factory);
	// upload.setHeaderEncoding("UTF-8");
	// if (!ServletFileUpload.isMultipartContent(request)) {
	// return Response.error();
	// }
	// logger.info("上传处理......");
	// InputStream in = null;
	// Map<String, byte[]> cert = new HashMap<String, byte[]>();
	// try {
	// FileItemIterator iterator = upload.getItemIterator(request);
	// FileItemStream item = null;
	// while (iterator.hasNext()) {
	// item = iterator.next();
	// if (item.isFormField()) {
	// continue;
	// } else {
	// String filename = item.getName();
	// if (filename == null || filename.trim().equals("")) {
	// continue;
	// }
	// in = item.openStream();
	// byte[] data = IOUtils.toByteArray(in);
	// String key = item.getFieldName();
	// cert.put(key, data);
	// }
	// }
	// } catch (Exception e) {
	// logger.error("上传文件出错：", e);
	// } finally {
	// try {
	// in.close();
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	// }
	// byte[] privateKey = cert.get("privateKey");
	// byte[] publicKey = cert.get("publicKey");
	// byte[] md5Key = cert.get("md5Key");
	// channelService.saveCert(channelId, payPlatform, password, privateKey,
	// publicKey, memberId, terminalId, md5Key,
	// extra);
	// return Response.success();
	// }

	// @RequestMapping("/findPayPlatformBankByPage")
	// @ResponseBody
	// public Response findPayPlatformByPage(String payPlatform, Integer status,
	// Integer page, Integer pageSize) {
	// Assert.notNull(payPlatform, "支付平台不能为空");
	// Assert.notNull(page, "分页不能为空");
	// Assert.notNull(pageSize, "页面数不能为空");
	// Page<FinancePayPlatformBankModel> list =
	// channelService.findPayPlatformBank(payPlatform, status, page,
	// pageSize);
	// return Response.success(list);
	// }

	// @RequestMapping("/findPayPlatformBankRows")
	// @ResponseBody
	// public Response findPayPlatformBankRows(String payPlatform, Integer
	// status) {
	// Assert.notNull(payPlatform, "支付平台不能为空");
	// return
	// Response.success(channelService.findPayPlatformBankRows(payPlatform,
	// status));
	// }

	@RequestMapping("/saveChannelPay")
	@ResponseBody
	public Response saveChannelPay(Integer bankId, Double limitSingle, Double limitDay, String payRule,
			HttpServletRequest request) {
		Assert.notNull(bankId);
		Assert.notNull(limitSingle);
		Assert.notNull(limitDay);
		Assert.notNull(payRule);
		AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");
		Integer channelId = userModel.getDataId();
		Assert.notNull(channelId);
		channelService.saveChannelPay(channelId, bankId, limitSingle, limitDay, payRule);
		return Response.success();
	}

	/**
	 * 根据bankId查找银行
	 * 
	 * @param bankId
	 * @param status
	 * @return
	 */
	@RequestMapping("/findBank")
	@ResponseBody
	public Response findBank(Integer bankId, Integer status) {
		Assert.notNull(bankId, "银行id不能为空");
		Assert.notNull(status, "状态不能为空");
		return Response.success(channelService.findBank(bankId, status));
	}

	/**
	 * 分页查询
	 * 
	 * @param name
	 * @param status
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping("/querypagingBank")
	@ResponseBody
	public Response querypagingBank(String name, String icon, Integer index, Integer status, Integer page,
			Integer pageSize) {
		Page<FinanceBankModel> pageResult = channelService.querypagingBank(name, icon, index, status, page, pageSize);
		return Response.success(pageResult);

	}

	/**
	 * 删除渠道支付规则
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/remove")
	@ResponseBody
	public Response removeChannelPay(Integer id) {
		Assert.notNull(id, "需要删除的id不能为空");
		channelService.removeChannelPay(id);
		return Response.success();

	}

	/**
	 * 更新渠道支付规则
	 * 
	 * @param id
	 * @param channelId
	 * @param bankId
	 * @param limitSingle
	 * @param limitDay
	 * @param payRule
	 * @return
	 */
	@RequestMapping("/updateChannelPay")
	@ResponseBody
	public Response updateChannelPay(Integer id, Integer channelId, Integer bankId, Double limitSingle, Double limitDay,
			String payRule) {
		Assert.notNull(id, "需要修改的id不能为空");
		channelService.updateChannelPay(id, channelId, bankId, limitSingle, limitDay, payRule);
		return Response.success();

	}

	/**
	 * 分页查询
	 * 
	 * @param channelId
	 * @param bankId
	 * @param limitSingle
	 * @param limitDay
	 * @param payRule
	 * @param status
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping("/querypagingChannelPay")
	@ResponseBody
	public Response querypagingChannelPay(Integer bankId, Double limitSingle, Double limitDay, String payRule,
			Integer status, Integer page, Integer pageSize, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		Page<FinanceChannelPayModel> pageResult = channelService.querypagingChannelPay(channelId, bankId, limitSingle,
				limitDay, payRule, status, page, pageSize);
		return Response.success(pageResult);

	}

}
