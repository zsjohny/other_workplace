package org.dream.finance.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.utils.constants.FinanceType;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceController extends BaseController {
	private static final String REDIS_KEY = "admin:filter:";
	@Autowired
	private FinanceService financeService;
	@Autowired
	private RedisTemplate<String, Integer> redisTemplate;

	// V2
	@RequestMapping("/systemMakeMoney")
	@ResponseBody
	public Response systemMakeMoney(Integer id, Double money) {
		String redisKey = REDIS_KEY + "system_make_money" + id;
		RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
		if (!integer.compareAndSet(0, 1)) {
			return null;
		}
		try {
			return financeService.systemMakeMoney(id, money);
		} finally {
			redisKey = REDIS_KEY + "system_make_money" + id;
			redisTemplate.delete(redisKey);
		}
	}

	// ************************************************************************

	@RequestMapping("/findMain")
	@ResponseBody
	public Response findMain(Integer userId) {
		Assert.notNull(userId);
		return Response.success(financeService.findMain(userId));
	}

	@RequestMapping("/findAcc")
	@ResponseBody
	public Response findAcc(Integer userId) {
		Assert.notNull(userId);
		return Response.success(financeService.findAcc(userId));
	}

	@RequestMapping("/findFlowByPage")
	@ResponseBody
	public Response findFlowByPage(String createTimeStart, String createTimeEnd, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, Integer type, Integer typeDetail, String remark,
			Integer page, Integer pageSize, String flow, HttpServletRequest request) {
		Assert.notNull(page, "页面不能为空");
		Assert.notNull(pageSize, "页面数不能为空");
		Assert.notNull(flow, "流水类型不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceFlowManageModel> list = financeService.findFlowByPage(id, level, createTimeStart, createTimeEnd,
				userId, userName, userPhone, channelId, topChannelId, type, typeDetail, remark, page, pageSize, flow);

		return Response.success(list);
	}

	// @RequestMapping("/findIOByPage")
	// @ResponseBody
	// public Response findIOByPage(String updateTimeStart, String
	// updateTimeEnd, String typeDetail,
	// String createTimeStart, String createTimeEnd, Integer userId, String
	// userName, String userPhone,
	// Integer status, Integer type, Integer channelId, Integer topChannelId,
	// Integer page, Integer pageSize,
	// HttpServletRequest request) {
	// Assert.notNull(page, "页面不能为空");
	// Assert.notNull(pageSize, "页面数不能为空");
	// Assert.notNull(type, "IO类型不能为空");
	// ChannelModel channelModel = getCurrentChannel(request);
	// Assert.notNull(channelModel);
	// Integer id = channelModel.getId();
	// Integer level = channelModel.getLevel();
	// Page<FinanceIOManageModel> list =
	// financeService.findIOByPage(updateTimeStart, updateTimeEnd, typeDetail,
	// createTimeStart, createTimeEnd, userId, userName, userPhone, status, id,
	// level, type, channelId,
	// topChannelId, page, pageSize);
	// return Response.success(list);
	// }

	@RequestMapping("/findById")
	@ResponseBody
	public Response findById(Integer id) {
		return Response.success(financeService.findByid(id));

	}

	@RequestMapping("/updateIOStatus")
	@ResponseBody
	public Response updateIOStatus(Integer status, String ioIds, HttpServletRequest request) {
		Assert.notNull(status, "提现状态不能为空");
		Assert.notNull(ioIds, "提现ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// status=1审核通过，=4审核拒绝
		String redisKey = null;
		String[] ioIdsArray = null;
		try {
			ioIdsArray = ioIds.split(",");
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status" + id;
				RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
				if (!integer.compareAndSet(0, 1)) {
					return null;
				}
			}
			financeService.checkDraw(status, ioIds);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");
	}

	@RequestMapping("/findTransfer")
	@ResponseBody
	public Response findTransfer(Integer id, HttpServletRequest request) {
		Assert.notNull(id);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		return Response.success(financeService.findTransfer(channelId, id));
	}

	@RequestMapping("/findFinanceType")
	@ResponseBody
	public Response findFinanceType(String flow) {
		Map<String, Integer> type = new LinkedHashMap<String, Integer>();
		if ("money".equals(flow)) {
			type.put("充值", 1);
			type.put("提现", -1);
		}
		type.put("订单消费", -2);
		type.put("订单结算", 2);
		type.put("订单退单", 21);
		type.put("系统赠送", 3);
		type.put("系统抹除", -3);
		return Response.success(type);
	}

}
