package org.dream.admin.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.admin.model.AdminMenuResourceModel;
import org.dream.admin.model.AdminPageElementResourceModel;
import org.dream.admin.model.AdminSecurityResourceModel;
import org.dream.admin.model.AdminUrlAccessResourceModel;

/**
 * 权限资源DAO 包括菜单资源、页面元素资源
 * 
 * @author wangd
 *
 */
public interface AdminSecurityResourceDao {

	/**
	 * 通过id，通用删除
	 * 
	 * @param id
	 */
	public void delete(Integer id);

	/**
	 * 通用查询，根据菜单id查询菜单所属的页面元素和后台方法，
	 * 
	 * @param menuId菜单id
	 * @param category
	 *            资源类型，可以为空，不为空则值查询相关类型的
	 * @return
	 */
	public List<AdminSecurityResourceModel> getAllByMenuId(@Param(value = "menuId") Integer menuId,
			@Param(value = "category") String category, @Param(value = "type") Integer type);

	/**
	 * 通过改变其状态来进行软删除
	 * 
	 * @param menuResourceModel
	 */
	public void updateStatus(@Param(value = "id") Integer id);

	/**
	 * 菜单资源的保存
	 * 
	 * @param menu
	 */

	public void createMenu(AdminMenuResourceModel menuResourceModel);

	public void updateMenu(AdminMenuResourceModel menuResourceModel);

	/**
	 * 根据菜单id获得菜单
	 * 
	 * @param id
	 * @return
	 */
	public AdminMenuResourceModel getMenu(@Param("id") Integer id, @Param("status") Integer status,
			@Param("category") String category);

	/**
	 * 根据父菜单Id获得子菜单集合
	 * 
	 * @param parentId
	 * @return
	 */
	public List<AdminMenuResourceModel> getChildMenu(@Param("parentId") Integer parentId,
			@Param("status") Integer status, @Param("category") String category, @Param("type") Integer type);

	/**
	 * 根据角色id和登录者所属的渠道获得该渠道下所有可用的叶子菜单
	 * 
	 * @param roleId
	 * @param dataId
	 * @return
	 */
	public List<AdminMenuResourceModel> getAllLeafMenu(@Param("type") Integer type, @Param("category") String category);

	/**
	 * 获得一个菜单的父菜单节点
	 * 
	 * @param childId
	 * @return
	 */
	public AdminMenuResourceModel getParentNode(Integer childId, Integer status);

	/**
	 * 
	 * 
	 * 多条件查询菜单
	 * 
	 * @return
	 */
	public List<AdminMenuResourceModel> findMenuResources(AdminMenuResourceModel menuResourceModel);

	/**
	 * 根据角色Id获得分配给该角色的菜单资源数据
	 * 
	 * @param roleId
	 * @param category
	 * @param level
	 *            菜单层级
	 * @return
	 */
	public List<AdminMenuResourceModel> findMenuResourcesByRoleId(@Param("roleId") Integer roleId,
			@Param("category") String category, @Param(value = "level") Integer level,
			@Param(value = "status") Integer status);

	/**
	 * 根据菜单id和角色id获得所有授权给该角色的该菜单的子菜单集合 适用于根据父菜单和角色数据获得已授权的子菜单集合
	 * 
	 * @param parentId
	 * @param roleId
	 * @return
	 */
	public List<AdminMenuResourceModel> queryMenuResourcesByParentIdRoleId(@Param(value = "parentId") Integer parentId,
			@Param(value = "roleId") Integer roleId, @Param(value = "status") Integer status,
			@Param(value = "category") String category);

	/**
	 * 分页查询菜单数据
	 * 
	 * @param menuName
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminMenuResourceModel> pagingqueryMenu(@Param(value = "name") String menuName,
			@Param(value = "category") String category, @Param(value = "type") Integer type,
			@Param(value = "status") Integer status, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer pagingqueryMenu_count(@Param(value = "name") String menuName,
			@Param(value = "category") String category, @Param(value = "type") Integer type,
			@Param(value = "status") Integer status);

	/**
	 * **********************************菜单部分结束*************************
	 * **********************************URL资源权限开始**********************
	 */

	public void createUrlAccess(AdminUrlAccessResourceModel urlAccessResourceModel);

	public void updateUrlAccess(AdminUrlAccessResourceModel urlAccessResourceModel);

	public List<AdminUrlAccessResourceModel> pagingQueryUrlAccess(Map<String, Object> param);

	public Integer pagingQueryUrlAccess_count(Map<String, Object> param);

	/**
	 * 根据角色id分页查询已分配给该角色的URL权限资源
	 * 
	 * @param name
	 * @param category
	 * @param description
	 * @param roleId
	 * @param dataId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminUrlAccessResourceModel> pagingQueryGrantUrlAccessByRoleId(@Param(value = "name") String name,
			@Param(value = "category") String category, @Param(value = "description") String description,
			@Param(value = "roleId") Integer roleId, @Param(value = "dataId") Integer dataId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer pagingQueryGrantUrlAccessByRoleId_count(@Param(value = "name") String name,
			@Param(value = "category") String category, @Param(value = "description") String description,
			@Param(value = "roleId") Integer roleId, @Param(value = "dataId") Integer dataId);

	/**
	 * 获得为分配给角色的URL访问
	 * 
	 * @param roleId
	 * @param name
	 * @param category
	 * @param description
	 * @param dataId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminUrlAccessResourceModel> pagingQueryNotGrantUrlAccessByRoleId(
			@Param(value = "roleId") Integer roleId, @Param(value = "name") String name,
			@Param(value = "category") String category, @Param(value = "description") String description,
			@Param(value = "dataId") Integer dataId, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer pagingQueryNotGrantUrlAccessByRoleId_count(@Param(value = "roleId") Integer roleId,
			@Param(value = "name") String name, @Param(value = "category") String category,
			@Param(value = "description") String description, @Param(value = "dataId") Integer dataId);

	/**
	 * 
	 * @param category
	 * @param roleId
	 * @param dataId
	 * @return
	 */
	public List<AdminUrlAccessResourceModel> getAllUrlAccessByRoleId(@Param(value = "category") String category,
			@Param(value = "roleId") Integer roleId, @Param(value = "dataId") Integer dataId);

	/**
	 * 根据参与者Id获得分配给参与者的URL权限
	 * 
	 * @param actorId
	 * @param category
	 * @return
	 */
	public List<AdminUrlAccessResourceModel> getUrlAccessResourcesByActorId(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category, @Param(value = "dataId") Integer dataId);

	public List<AdminSecurityResourceModel> getSecurityResourcesByActorId(@Param(value = "actorId") Integer actorId,
			@Param(value = "dataId") Integer dataId, @Param(value = "category") String category);

	/**
	 * **********************************URL资源权限结束*************************
	 * **********************************页面元素资源权限开始**********************
	 */
	public void createPageElement(AdminPageElementResourceModel elementResourceModel);

	public void updatePageElement(AdminPageElementResourceModel elementResourceModel);

	/**
	 * 多条件查询页面元素资源
	 * 
	 * @param param
	 * @return
	 */
	public List<AdminPageElementResourceModel> pagingQueryPageElement(Map<String, Object> param);

	public Integer pagingQueryPageElement_count(Map<String, Object> param);

	/**
	 * 根据角色Id分页获得已授权的页面资源 多条件查询，至少角色Id是必须的 如果没有角色Id将会出现异常
	 * 
	 * @param name
	 * @param description
	 * @param identifier
	 * @param roleId
	 * @param dataId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminPageElementResourceModel> pagingQueryGrantPageElementByRoleId(@Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "identifier") String identifier,
			@Param(value = "roleId") Integer roleId, @Param(value = "dataId") Integer dataId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer pagingQueryGrantPageElementByRoleId_count(@Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "identifier") String identifier,
			@Param(value = "roleId") Integer roleId, @Param(value = "dataId") Integer dataId);

	/**
	 * 根据角色Id分页获得未授权的页面资源 多条件查询
	 * 
	 * @param name
	 * @param description
	 * @param identifier
	 * @param roleId
	 * @param dataId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminPageElementResourceModel> pagingQueryNotGrantPageElementByRoleId(
			@Param(value = "name") String name, @Param(value = "description") String description,
			@Param(value = "identifier") String identifier, @Param(value = "roleId") Integer roleId,
			@Param(value = "dataId") Integer dataId, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer pagingQueryNotGrantPageElementByRoleId_count(@Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "identifier") String identifier,
			@Param(value = "roleId") Integer roleId, @Param(value = "dataId") Integer dataId);

	/**
	 * 
	 * @param actorId
	 * @param idDdentifier
	 * @return
	 */
	public AdminPageElementResourceModel getPagelementByActorIdIdDdentifier(@Param(value = "actorId") Integer actorId,
			@Param(value = "identifier") String identifier, @Param(value = "dataId") Integer dataId,
			@Param(value = "type") Integer type);

	public AdminPageElementResourceModel getPagelementByTypeDdentifier(@Param(value = "identifier") String identifier,
			@Param(value = "dataId") Integer dataId, @Param(value = "type") Integer type);

	/**
	 * 根据登录用户来获取 用户所用有的pageElement
	 * 
	 * @param actorId
	 * @param category
	 * @return
	 */

	public List<String> getPageElementByActorId(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category);

	public List<String> getPageElementAll(@Param(value = "category") String category,
			@Param(value = "type") Integer type);

}
