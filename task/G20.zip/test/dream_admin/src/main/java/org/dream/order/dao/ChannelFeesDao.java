package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.ChannelFeesModel;


public interface ChannelFeesDao {
	
	public int getChannelFeesCountById(@Param("channelId")Integer channelId,@Param("assetsId")Integer assetsId);
	
	int removeByPrimaryKey(Integer id);

    int insert(ChannelFeesModel record);

    int insertSelective(ChannelFeesModel record);

    ChannelFeesModel selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ChannelFeesModel record);

    int updateByPrimaryKey(ChannelFeesModel record);
    
    List<ChannelFeesModel> pagingQueryChannelFees(Map map);
    
    int pagingQueryChannelFeesCount(Map map);

}
