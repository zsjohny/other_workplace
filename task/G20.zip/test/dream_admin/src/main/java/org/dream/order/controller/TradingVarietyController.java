package org.dream.order.controller;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.ChannelVarietyModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.ChannelVarietyService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

/**
 * 交易品种Controller
 *
 * @author
 */
@Controller
@RequestMapping("/tradingVariety")
public class TradingVarietyController {

	@Autowired
	private TradingVarietyService tradingVarietyService;

	@Autowired
	private ChannelVarietyService channelVarietyService;

	@Autowired
	private ChannelService channelService;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@Autowired
	@Qualifier(value = "jmsSenderForQuotaReset")
	JmsSender jmsSender;

	/**
	 * 保存期货品种信息
	 *
	 * @param exchangeId
	 *            交易所id
	 * @param varietyType
	 *            期货品种类型
	 * @param varietyName
	 *            品种名称
	 * @param status
	 *            显示状态
	 * @param varietyIcon
	 *            图标地址
	 * @param varietyRemark
	 *            备注
	 * @return
	 */
	@RequestMapping(value = "/add")
	@ResponseBody
	public Response addTradingVariety(TradingVarietyModel tradingVarietyModel) {

		Map<String,Object> map=tradingVarietyService.saveFutureExchange(tradingVarietyModel);
		if("0".equals(map.get("retCode"))){
			return Response.response(600,(String) map.get("retmsg"));
		}
		return Response.success();
	}

	/**
	 * 修改期货类型信息
	 *
	 * @return
	 */
	@RequestMapping(value = "/update")
	@ResponseBody
	public Response updateTradingVariety(TradingVarietyModel tradingVarietyModel) {
		tradingVarietyService.updateFutureExchange(tradingVarietyModel);
		return Response.success();
	}

	/**
	 * 分页查询 暂时不做条件查询
	 *
	 * @param pageindex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/querypaging")
	@ResponseBody
	public Response querypagingTradingVariety(Integer page, Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<TradingVarietyModel> resultPage = tradingVarietyService.querypaging(null, null, null, null, 1, page,
				pageSize);
		return Response.success(resultPage);
	}

	/**
	 * 获取平台上面所有可售期货品种 即status=1
	 */
	@RequestMapping(value = "/getEffective")
	@ResponseBody
	public Response getEffectiveTradingVarieties() {
		return Response.success(tradingVarietyService.getEffectiveTradingVarieties());
	}

	/**
	 * 删除： 删除平台上面某一期货品种（软删除）
	 * <p>
	 * 同时，当这里发生改动时，会触动平台上面所有的一级渠道和二级渠道该品种删除（物理删除）
	 *
	 * @param id的值为dream_o_trading_variety表中id字段
	 */
	@RequestMapping(value = "/removeOne", method = { RequestMethod.POST })
	@ResponseBody
	public Response closeOneTradingVariety(Integer id) {
		Assert.notNull(id, "品种id不能为空");
		// 平台下的品种先做软删除
		tradingVarietyService.removeTradingVarietyById(id, 0);
		// 渠道下的相关品种做物理删除
		channelVarietyService.deleteChannelVarietiesByVarietyId(id);
		// 将缓存也删掉 ,目前只删除品种相关的用户手续费，一级渠道费率
		List<ChannelModel> channels = channelService.findChannelAll();
		for (ChannelModel cm : channels) {
			Integer channelId = cm.getId();
			redisTemplate.opsForHash().delete(ChannelVarietyModel.oneChannel_Fees, channelId + "_" + id);
			redisTemplate.opsForHash().delete(ChannelVarietyModel.twoChannel_user_costs, channelId + "_" + id);
		}
		return Response.success();
	}

	/**
	 * 获得交易所下所有品种
	 *
	 * @param exchangeId
	 * @return
	 */
	@RequestMapping(value = "/getByExchangeId")
	@ResponseBody
	public Response getByExchangeId(Integer exchangeId) {
		Assert.notNull(exchangeId, "交易所不能为空");
		return Response.success(tradingVarietyService.getByExchangeId(exchangeId));
	}

	/**
	 * 重置行情信息
	 */

	@RequestMapping(value = "resetQuotaByVariety")
	@ResponseBody
	public Response resetQuotaByVariety(@Param("id") Integer id) {
		if (id == null) {
			return Response.success(false);
		}
		try {

			jmsSender.sendMessage(JSON.toJSONString(id));

		} catch (Exception e) {
			return Response.success(false);
		}
		return Response.success(true);

	}

}
