package org.dream.finance.service.impl;

import java.util.List;

import org.dream.finance.dao.FinanceCollectDao;
import org.dream.finance.service.FinanceCollectService;
import org.dream.model.finance.FinanceCollectModel;
import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceCollectServiceImpl implements FinanceCollectService {

	@Autowired
	FinanceCollectDao financeCollectDao;

	@Override
	public FinanceCollectModel findCollectMoneyFlow(Integer id, Integer level, String createTimeStart,
			String createTimeEnd, Integer userId, String userName, String userPhone, Integer channelId,
			Integer topChannelId, Integer type, Integer typeDetail, String remark, String flow) {
		if (level == 1) {
			topChannelId = id;
		} else if (level == 2) {
			channelId = id;
		}
		List<FinanceFlowManageModel> list = financeCollectDao.findCollectMoneyFlow(createTimeStart, createTimeEnd,
				userId, userName, userPhone, channelId, topChannelId, type, typeDetail, remark, flow);
		Double grossIncome = 0.00; // 总收入
		Double grossCharge = 0.00; // 总支出
		for (FinanceFlowManageModel model : list) {
			if (model.getType() > 0) {
				if (model.getMoney() != null) {
					grossIncome += model.getMoney();
				}
			} else {
				if (model.getMoney() != null) {
					grossCharge += model.getMoney();
				}
			}
		}
		FinanceCollectModel collectModel = new FinanceCollectModel();
		collectModel.setGrossCharge(grossCharge);
		collectModel.setGrossIncome(grossIncome);
		return collectModel;
	}

	@Override
	public FinanceCollectModel findCollect(FinanceIOManageModel model, Integer id, Integer level) {
		if (level == 1) {
			model.setTopChannelId(id);
		} else if (level == 2) {
			model.setChannelId(id);
		}
		FinanceCollectModel collectModel = financeCollectDao.findCollect(model);
		return collectModel;
	}

	@Override
	public FinanceCollectModel findCollectTransfer(Integer userId, String userName, String userPhone, String realName,
			String transferType, Integer status, String operator, String createTimeStart, String createTimeEnd,
			String updateTimeStart, String updateTimeEnd, Integer topChannelId) {
		FinanceCollectModel collectModel = financeCollectDao.findCollectTransfer(userId, userName, userPhone, realName,
				transferType, status, operator, createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd,
				topChannelId);
		return collectModel;
	}

	@Override
	public FinanceCollectModel findCollectCommission(FinanceCommissionIOModel commissionIOModel) {
		List<FinanceCommissionIOModel> list = financeCollectDao.findCollectCommission(commissionIOModel);

		Double commissionDeposit = 0.00; // 存入
		Double commissionTransfer = 0.00; // 转出
		for (FinanceCommissionIOModel model : list) {
			if (model.getType() < 0) {
				if (model.getMoney() != null) {
					commissionTransfer += model.getMoney();
				}
			} else {
				if (model.getMoney() != null) {
					commissionDeposit += model.getMoney();
				}
			}
		}
		FinanceCollectModel collectModel = new FinanceCollectModel();
		collectModel.setCommissionDeposit(commissionDeposit);
		collectModel.setCommissionTransfer(commissionTransfer);
		return collectModel;
	}
}
