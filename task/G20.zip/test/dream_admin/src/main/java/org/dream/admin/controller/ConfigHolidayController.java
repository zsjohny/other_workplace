package org.dream.admin.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.dream.config.model.HolidayModel;
import org.dream.config.service.ConfigHolidayService;
import org.dream.model.order.FuturesExchangeModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.FuturesExchangeService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 假期配置Controller
 * 
 * @author wangd
 *
 */
@Controller
@RequestMapping("/configHoliday")
public class ConfigHolidayController {

    @Autowired
    FuturesExchangeService futuresExchangeService;
    @Autowired
    ConfigHolidayService configHolidayService;

    @Autowired
    TradingVarietyService tradingVarietyService;

    /**
     * 保存假期配置<br>
     * 保存假期配置粒度控制到某个品种，页面传递过来的数值中可能会没有品种id，如果没有品种id则将该交易所下所有的品种配置成相同的假期配置
     * 如果有品种id则是某一个品种的假期配置
     * 
     * @param changeId
     * @param holidayName
     * @param stardDate
     * @param endDate
     * @param remark
     * @param request
     * @param response
     * @return
     * @throws ParseException
     */
    @RequestMapping(value = "/saveConfigHoliday", method = { RequestMethod.POST })
    @ResponseBody
    public Response saveConfigHoliday(Integer exchangeId, Integer varietyId, String holidayName, String startDate,
	    String endDate, String remark)
	    throws ParseException {

	Assert.notNull(exchangeId, "交易所不能为空");
	Assert.notNull(startDate, "假期开始时间不能为空");
	Assert.notNull(endDate, "假期结束时间不能为空");

	FuturesExchangeModel exchangeModel = futuresExchangeService.getById(exchangeId);
	if (exchangeModel != null) {
	    if (varietyId == null) {
		configHolidayService.saveConfigHolidays(
			this.getHolidayModels(exchangeModel, holidayName, startDate, endDate, remark));
	    } else {
		HolidayModel holidayModel = new HolidayModel();
		TradingVarietyModel tradingVarietyModel = tradingVarietyService.getById(varietyId);

		holidayModel.setExchangeId(exchangeId);
		holidayModel.setExchangeName(exchangeModel.getExchangeName());
		holidayModel.setVarietyId(varietyId);
		holidayModel.setVarietyName(tradingVarietyModel.getVarietyName());
		holidayModel.setVarietyType(tradingVarietyModel.getVarietyType());
		holidayModel.setHolidayName(holidayName);
		holidayModel.setStartDate(this.getTime(startDate));
		holidayModel.setEndDate(this.getTime(endDate));
		holidayModel.setRemark(remark);
		holidayModel.setCreateDate(new Timestamp(System.currentTimeMillis()));

		configHolidayService.saveConfigHoliday(holidayModel);
	    }

	} else {
	    return Response.error("保存失败，未获得相应的交易所");
	}

	return Response.success();
    }

    /**
     * 为交易所下所有的品种设置假期配置
     * 
     * @param exchangeModel
     * @param holidayName
     * @param stardDate
     * @param endDate
     * @param remark
     * @return
     * @throws ParseException
     */
    private List<HolidayModel> getHolidayModels(FuturesExchangeModel exchangeModel, String holidayName,
	    String startDate, String endDate, String remark) throws ParseException {
	List<HolidayModel> result = new ArrayList<HolidayModel>();
	List<TradingVarietyModel> tradingVarietyModels = tradingVarietyService.getByExchangeId(exchangeModel.getId());
	for (TradingVarietyModel tradingVarietyModel : tradingVarietyModels) {
	    HolidayModel holidayModel = new HolidayModel();
	    holidayModel.setExchangeId(exchangeModel.getId());
	    holidayModel.setExchangeName(exchangeModel.getExchangeName());
	    holidayModel.setVarietyId(tradingVarietyModel.getId());
	    holidayModel.setVarietyName(tradingVarietyModel.getVarietyName());
	    holidayModel.setVarietyType(tradingVarietyModel.getVarietyType());
	    holidayModel.setHolidayName(holidayName);
	    holidayModel.setStartDate(this.getTime(startDate));
	    holidayModel.setEndDate(this.getTime(endDate));
	    holidayModel.setRemark(remark);
	    result.add(holidayModel);
	}

	return result;
    }

    /**
     * 
     * @param id
     * @param exchangeId
     * @param holidayName
     * @param stardDate
     * @param endDate
     * @param remark
     * @return
     * @throws ParseException
     */
    @RequestMapping(value = "/updateConfigHoliday", method = { RequestMethod.POST })
    @ResponseBody
    public Response updateConfigHoliday(Integer id, Integer exchangeId, String holidayName, String startDate,
	    String endDate, String remark)
	    throws ParseException {
	Assert.notNull(id, "要修改的假期配置id不能为空");
	Assert.notNull(exchangeId, "交易所不能为空");
	Assert.notNull(startDate, "假期开始时间不能为空");
	Assert.notNull(endDate, "假期结束时间不能为空");

	FuturesExchangeModel exchangeModel = futuresExchangeService.getById(exchangeId);
	if (exchangeModel != null) {
	    HolidayModel holidayModel = new HolidayModel();

	    holidayModel.setId(id);
	    holidayModel.setExchangeId(exchangeId);
	    holidayModel.setExchangeName(exchangeModel.getExchangeName());
	    holidayModel.setHolidayName(holidayName);
	    holidayModel.setStartDate(this.getTime(startDate));
	    holidayModel.setEndDate(this.getTime(endDate));
	    holidayModel.setRemark(remark);

	    configHolidayService.updateConfigHoliday(holidayModel);

	} else {
	    return Response.error("修改失败，未获得相应的交易所");
	}

	return Response.success();
    }

    /**
     * 
     * @param ids
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/deleteConfigHoliday", method = { RequestMethod.POST })
    @ResponseBody
    public Response deleteConfigHoliday(String ids) {
	Assert.notNull(ids, "要删除的假期配置id不能为空");
	configHolidayService.delteHoliday(ids);
	return Response.success();
    }

    /**
     * 分页查询
     * 
     * @param exchangeId
     * @param holidayName
     * @param status
     * @param page
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
    @ResponseBody
    public Response querypaging(Integer exchangeId, String holidayName, Integer status, Integer page, Integer pageSize) {

	Page<HolidayModel> pageHoliday = configHolidayService.querypaging(exchangeId, status, page, pageSize);
	return Response.success(pageHoliday);
    }

    /**
     * 时间处理
     * 
     * @param date
     *            日期字符串，注意此处的日期串不必带有时间
     * @return
     * @throws ParseException
     */
    private Timestamp getTime(String date) throws ParseException {
	Date date2 = DateUtils.parseDate(date, "yyyy-MM-dd HH:mm:ss");
	return new Timestamp(date2.getTime());
    }
}
