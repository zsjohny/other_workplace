package org.dream.finance.service;

import org.dream.utils.mvc.Response;

public interface FinanceInnerService {
	public Response innerDepositMoney(Integer userId, Double money);

	public Response innerDepositScore(Integer userId, Double score);

	public Response innerExtractMoney(Integer userId, Double money);

	public Response innerExtractScore(Integer userId, Double score);
}
