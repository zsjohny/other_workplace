package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceChannelPayService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceChannelPayController extends BaseController {
	@Autowired
	private FinanceChannelPayService channelPayService;

	@RequestMapping("/findByPage")
	@ResponseBody
	public Response findByPage(FinanceChannelPayModel channelPayModel, Integer page, Integer pageSize,
			HttpServletRequest request) {
		channelPayModel.setChannelId(getDataId(request));
		return channelPayService.findByPage(channelPayModel, page, pageSize);
	}

	@RequestMapping("/save")
	@ResponseBody
	public Response save(FinanceChannelPayModel channelPayModel, HttpServletRequest request) {
		channelPayModel.setChannelId(getDataId(request));
		return channelPayService.save(channelPayModel);

	}

	@RequestMapping("/update")
	@ResponseBody
	public Response update(FinanceChannelPayModel channelPayModel) {
		Assert.notNull(channelPayModel.getId(), "修改id");
		return channelPayService.update(channelPayModel);
	}

	@RequestMapping("/findChannelPayBankList")
	@ResponseBody
	public Response findChannelPayBankList(HttpServletRequest request) {
		Integer channelId = getDataId(request);
		return channelPayService.findChannelPayBankList(channelId, 0);
	}
}
