package org.dream.admin.service.impl;

import java.util.List;

import org.dream.admin.dao.AdminDepartmentDao;
import org.dream.admin.model.AdminDepartmentModel;
import org.dream.admin.service.AdminDepartmentService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminDepartmentServiceImpl implements AdminDepartmentService {

    @Autowired
    AdminDepartmentDao adminDepartmentDao;
    
    @Override
    public void saveDeparment(AdminDepartmentModel deparmentMoudel) {
        adminDepartmentDao.createDeparment(deparmentMoudel);

    }

    @Override
    public void updateDeparment(AdminDepartmentModel deparmentMoudel) {

        adminDepartmentDao.updateDeparment(deparmentMoudel);

    }

    @Override
    public void removeDeparment(Integer id ,Integer dataId) {
        adminDepartmentDao.delteDeparment(id,dataId);

    }

    @Override
    public String removeDeparmentsByIds(List<Integer> ids,Integer dataId) {
        //删除部门之前需要验证部门有没有子部门
        String result = "删除部门成功";
        StringBuffer departmentName = new StringBuffer();
        for (Integer id : ids) {
           List<AdminDepartmentModel> subDepartments = adminDepartmentDao.queryDepatmentsByParentId(id,dataId);
            if (subDepartments != null && subDepartments.size() > 0) {
                departmentName.append(adminDepartmentDao.getDeparment(id,dataId).getFullName()).append("，");
                continue;
            }        
            adminDepartmentDao.delteDeparment(id,dataId);
            //删除部门时删除跟部门相关联的用户信息
            adminDepartmentDao.deleteByDepartmentId(id);
            
        }
        return result + (departmentName.length() > 1 ? "其中" +departmentName.toString().substring(0, departmentName.lastIndexOf("，")) + "因含有子部门不能删除" : "");
    }


    @Override
    public List<AdminDepartmentModel> getDepatementsByParentId(
            Integer parentId,Integer dataId) {
        return adminDepartmentDao.queryDepatmentsByParentId(parentId,dataId);
    }

    @Override
    public boolean hasDeparmentBySn(String sn) {
        
        
        return adminDepartmentDao.pagingQueryDeparment_count(sn, null, null, null, null, null, null) > 0;
    }

    @Override
    public AdminDepartmentModel getDeparmentById(Integer id,Integer dataId) {
        
        return adminDepartmentDao.getDeparment(id,dataId);
    }

    @Override
    public List<AdminDepartmentModel> getTopDepartments(Integer dataId) {
        
    	return adminDepartmentDao.queryTopDepartments(dataId);
    }

	@Override
	public Page<AdminDepartmentModel> pagingQueryDeparment(String sn, String fullName, String shortName,
			String description, Integer parentId, Integer dataId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex  > 0 ? pageIndex* pageSize : 0 * pageSize;
      Integer level_code = parentId == null ? 1 : null;//没有上级部门id时默认获得一级部门数据
      List<AdminDepartmentModel> resultList = adminDepartmentDao.pagingQueryDeparment(sn, fullName, shortName, description, parentId, level_code, dataId, limit, pageSize);
      Integer count = adminDepartmentDao.pagingQueryDeparment_count(sn, fullName, shortName, parentId, level_code, description, dataId);
      Page<AdminDepartmentModel> result = new Page<AdminDepartmentModel>(pageIndex, pageSize, count);
      result.setData(resultList);
      return result;
	}

}
