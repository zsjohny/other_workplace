package org.dream.channel.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.dream.admin.dao.AdminActorDao;
import org.dream.admin.dao.AdminAuthorityDao;
import org.dream.admin.model.AdminRoleModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.channel.dao.ChannelDao;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.dream.utils.prop.SpringProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class ChannelServiceImpl implements ChannelService {
	@Autowired
	ChannelDao channelDao;

	@Autowired
	AdminActorDao adminActorDao;

	@Resource(name = "channelSignChangendSender")
	JmsSender jmsSender;

	@Autowired
	SpringProperties springProperties;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@Autowired
	AdminAuthorityDao adminAuthorityDao;

	@Override
	public ChannelModel getById(Integer id) {

		return channelDao.getById(id);
	}

	@Override
	public List<ChannelModel> findChannelAll() {
		return channelDao.findChannelAll();
	}

	@Override
	public void saveChannel(ChannelModel channelModel) {

		Integer level = null;
		channelDao.saveChannel(channelModel);
		// 将创建好的渠道放入redis
		String redisChannelKey = "uhost_channel";
		HashOperations<String, String, ChannelModel> hashOperations = redisTemplate.opsForHash();
		hashOperations.put(redisChannelKey, channelModel.getDomain(), channelModel);
		// 开始创建渠道的管理员
		AdminUserModel admin = new AdminUserModel();
		Integer channelId = channelModel.getId();
		admin.setDataId(channelId);
		admin.setName(channelModel.getName() + "管理员");
		admin.setUserAccount("admin");
		admin.setPassword(admin.getDefaultPassword());
		adminActorDao.createAdminUser(admin);
		// 创建一个管理员角色 拥有该级数下的所有权限
		AdminRoleModel role = new AdminRoleModel();
		role.setCategory(AdminRoleModel.CATEGORY);
		role.setDataId(channelId);
		role.setName(channelModel.getName() + "系统管理员");
		role.setDescription("系统管理");
		role.setIsAdmin(1);
		role.setType(level);
		adminAuthorityDao.createAdminRole(role);
	}

	@Override
	public List<ChannelModel> findAllFirstChannels() {
		return channelDao.findAllFirstChannels();
	}

	@Override
	public List<ChannelModel> findSecondChannelsBySuperId(Integer id) {
		return channelDao.findSecondChannelsBySuperId(id);
	}

	@Override
	public void updateChannel(ChannelModel channelModel) {
		channelDao.updateChannel(channelModel);
		// 将更新后的渠道数据更新到redis中
		String redisChannelKey = "uhost_channel";
		HashOperations<String, String, ChannelModel> hashOperations = redisTemplate.opsForHash();
		hashOperations.put(redisChannelKey, channelModel.getDomain(), channelModel);

		sendMsg(channelModel.getId(), channelModel.getSign());
	}

	private void sendMsg(Integer id, String sign) {
		ChannelModel channelModel = new ChannelModel();
		channelModel.setId(id);
		channelModel.setSign(sign);
		jmsSender.sendMessage(JSON.toJSONString(channelModel));
	}

	@Override
	public void removeChannel(Integer id) {
		// 删除相应的缓存数据
		ChannelModel channelModel = this.getById(id);
		String redisChannelKey = "uhost_channel";
		HashOperations<String, String, ChannelModel> hashOperations = redisTemplate.opsForHash();
		if (hashOperations.hasKey(redisChannelKey, channelModel.getDomain())) {
			hashOperations.delete(redisChannelKey, channelModel.getDomain());
		}
		channelDao.removeChannel(id);

	}

	@Override
	public ChannelModel findChannelByDomain(String domain) {
		return channelDao.findChannelByDomain(domain);
	}

	@Override
	public Page<ChannelModel> querypaging(String domain, String name, String description, Integer superId,
			String backstageDomain, Integer pageIndex, Integer size) {
		Integer limit = pageIndex > 0 ? pageIndex * size : 0 * pageIndex;
		String userAccount = "admin";
		List<ChannelModel> dataList = channelDao.querypaging(domain, name, description,
				ChannelModel.CHANNEL_STATUS_DEFAULT, superId, backstageDomain,userAccount, limit, size);

		Integer totalCount = channelDao.querypaging_count(domain, name, description,
				ChannelModel.CHANNEL_STATUS_DEFAULT, superId, backstageDomain,userAccount);

		Page<ChannelModel> page = new Page<>(pageIndex, size, totalCount);
		page.setData(dataList);
		return page;
	}

	@Override
	public String findChannelNameById(Integer id) {
		return channelDao.findChannelNameById(id);
	}

	@Override
	public ChannelModel findChannelByBackstageDomain(String backstageDomain) {

		return channelDao.findChannelByBackstageDomain(backstageDomain);
	}

	@Override
	public boolean hasChannel(String domain, String name, String backstageDomain) {
		return channelDao.querypaging_count(domain, name, null, null, null, backstageDomain,null)>0;
	}

	@Override
	public Integer findCount(String domain, String name, String backstageDomain, Integer id) {
		return channelDao.findCount(domain, name, backstageDomain, id);
	}

}
