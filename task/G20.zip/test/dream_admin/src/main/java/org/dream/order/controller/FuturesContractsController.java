package org.dream.order.controller;

import org.dream.model.order.FuturesContractsModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.FuturesContractsService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 期货合约Controller
 * 
 * @author
 */
@Controller
@RequestMapping(value = "/futuresContracts")
public class FuturesContractsController {

	@Autowired
	private FuturesContractsService futuresContractsService;

	@Autowired
	private TradingVarietyService tradingVarietyService;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	/**
	 * 保存期货合约
	 * 
	 * @param exchangeId
	 *            交易所id
	 * @param varietyId
	 *            期货品种id
	 * @param contractsCode
	 *            合约代码
	 * @param status
	 *            合约状态
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	@ResponseBody
	public Response addFuturesContracts(Integer varietyId, String contractsCode) {
		Assert.notNull(varietyId, "期货品种id不能为空");
		Assert.notNull(contractsCode, "合约编码不能为空");
		TradingVarietyModel tradingVarietyModel = tradingVarietyService.getById(varietyId);
		FuturesContractsModel contractsModel = new FuturesContractsModel();

		contractsModel.setExchangeId(tradingVarietyModel.getExchangeId());
		contractsModel.setExchangeName(tradingVarietyModel.getExchangeName());
		contractsModel.setVarietyId(varietyId);
		contractsModel.setVarietyName(tradingVarietyModel.getVarietyName());
		contractsModel.setVarietyType(tradingVarietyModel.getVarietyType());
		contractsModel.setContractsCode(contractsCode.toUpperCase());
		contractsModel.setStatus(0);
		Integer count = futuresContractsService.qureypagingHasContractsCode(contractsCode);
		if (count > 0) {
			return Response.response(600, "添加失败，该合约代码已存在！");
		}

		futuresContractsService.saveFutureContracts(contractsModel);
		return Response.success();
	}

	/**
	 * 获取所有在售合约
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getAll", method = { RequestMethod.POST })
	@ResponseBody
	public Response getAllFuturesContracts() {
		return Response.success(futuresContractsService.getAll());
	}

	/**
	 * 通过合约代码获取缓存中的type
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getByConstractsCodeFromRedis")
	@ResponseBody
	public Response getByConstractsCodeFromRedis(String contractsCode) {

		Object varietyType = redisTemplate.opsForHash().get(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
				contractsCode);
		return Response.success(varietyType);
	}

	/**
	 * 通过品种id在缓存中获取合约
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getByVarietyIdFromRedis")
	@ResponseBody
	public Response getByVarietyIdFromRedis(String varietyId) {
		FuturesContractsModel fcm = (FuturesContractsModel) redisTemplate.opsForHash()
				.get(FuturesContractsModel.VARIETY_SALE_CONTRACTS, new Integer(varietyId));
		return Response.success(fcm);
	}

	/**
	 * 分页多条件查询期货合约
	 * 
	 * @param exchangeName
	 * @param varietyName
	 * @param contractsCode
	 * @param status
	 * @param pageindex
	 * @param pagesize
	 * @return
	 */
	@RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingqueryFuturesContracts(String exchangeName, String varietyName, Integer status, Integer page,
			Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<FuturesContractsModel> data = futuresContractsService.querypaging(exchangeName, varietyName, status, page,
				pageSize);
		return Response.success(data);
	}

	/**
	 * 批量修改期货合约状态
	 * 
	 * @param ids
	 *            合约id(目前前端只能做对一个合约进行修改状态)
	 * @param status
	 *            合约状态， 1：在售;0 ：停售
	 * @return
	 */
	@RequestMapping(value = "/changeStatusByIds", method = { RequestMethod.POST })
	@ResponseBody
	public Response changeStatusByIds(String ids, Integer status) {
		Assert.notNull(ids, "期货合约id不能为空");
		// 目前传过来的ids其是是一个数字。
		// 需要判断，数据库内同一个品种只能存在一个在售合约
		FuturesContractsModel fCModel = futuresContractsService.getById(new Integer(ids));
		if (status == 1) {
			Integer count = futuresContractsService.qureypaging_count(null, fCModel.getVarietyName(), null, 1);
			if (count >= 1) {
				return Response.response(600, "相同品种下只有一个合约可售");
			}
			// 打开的时候，redis中也要添加hash
			futuresContractsService.putContractsRedis(fCModel);
			// redisTemplate.opsForHash().put(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
			// fCModel.getVarietyId(),
			// fCModel);
			// redisTemplate.opsForHash().put(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
			// fCModel.getContractsCode(),
			// fCModel.getVarietyType());
		} else if (status == 0) {
			futuresContractsService.deleteContractsRedis(fCModel);
//			// 关闭的时候，redis中也要删除hash
//			if (redisTemplate.opsForHash().hasKey(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
//					fCModel.getVarietyId())) {
//				redisTemplate.opsForHash().delete(FuturesContractsModel.VARIETY_SALE_CONTRACTS, fCModel.getVarietyId());
//			}
//			// key为合约代码的缓存
//			if (redisTemplate.opsForHash().hasKey(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
//					fCModel.getContractsCode())) {
//				redisTemplate.opsForHash().delete(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
//						fCModel.getContractsCode());
//			}
		}
		futuresContractsService.changeStatusByIds(ids, status);
		return Response.success();
	}
}
