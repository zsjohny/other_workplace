package org.dream.finance.controller;

import org.dream.finance.service.FinancePayPlatformService;
import org.dream.model.finance.FinancePayPlatformModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinancePayPlatformController {
	@Autowired
	private FinancePayPlatformService payPlatformService;

	@RequestMapping("/savePayPlatform")
	@ResponseBody
	public Response savePayPlatform(FinancePayPlatformModel payPlatformModel) {
		return payPlatformService.saveFinancePayPlatform(payPlatformModel);
	}

	@RequestMapping("/updatePayPlatform")
	@ResponseBody
	public Response updatePayPlatform(FinancePayPlatformModel payPlatformModel) {
		return payPlatformService.updateFinancePayPlatform(payPlatformModel);
	}

	@RequestMapping("/findPayPlatformByPage")
	@ResponseBody
	public Response findPayPlatformByPage(FinancePayPlatformModel model, Integer page, Integer pageSize) {
		Page<FinancePayPlatformModel> list = payPlatformService.querypaging(model, page, pageSize);
		return Response.success(list);
	}

	@RequestMapping("/findPayPlatform")
	@ResponseBody
	public Response findPayPlatform(Integer id) {
		FinancePayPlatformModel payPlatformModel = payPlatformService.getById(id);
		return Response.success(payPlatformModel);
	}

	@RequestMapping("/findPayPlatformAll")
	@ResponseBody
	public Response findPayPlatformAll(FinancePayPlatformModel payPlatformModel, Integer type) {
		if (type == null) {
		} else {
			if (type == 0) {
				payPlatformModel.setPayment(1);
			} else if (type == 1) {
				payPlatformModel.setTransfer(1);
			}
		}
		return Response.success(payPlatformService.findPayPlatformAll(payPlatformModel));
	}

	@RequestMapping("/findPayPlatformCertifyAll")
	@ResponseBody
	public Response findPayPlatformCertifyAll(FinancePayPlatformModel payPlatformModel) {
		payPlatformModel.setCertify(1);
		return Response.success(payPlatformService.findPayPlatformAll(payPlatformModel));
	}

}
