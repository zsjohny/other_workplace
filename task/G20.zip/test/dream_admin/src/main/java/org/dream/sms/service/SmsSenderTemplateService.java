package org.dream.sms.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.sms.SmsSenderTemplate;
import org.dream.utils.mvc.Page;

public interface SmsSenderTemplateService {
	public void addSenderTemplate(SmsSenderTemplate smsSenderTemplate);

	public void updateSenderTemplate(SmsSenderTemplate smsSenderTemplate);

	public List<SmsSenderTemplate> getSenderTemplate(Integer channelId);

	public SmsSenderTemplate getById(Integer id);

	public Page<SmsSenderTemplate> pagingQuery(Integer templateId, Integer channelId, Integer type, Integer pageIndex,
			Integer pageSize);

	public void remove(Integer id);

	public boolean hasSenderTemplate(Integer templateId, Integer channelId, Integer type);

	public SmsSenderTemplate findSenderTemplate(Integer templateId, Integer channelId, Integer type);
}
