package org.dream.finance.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.IOUtils;
import org.dream.finance.dao.FinanceTransferDao;
import org.dream.finance.service.AlipayTransferService;
import org.dream.finance.service.BasicFinanceService;
import org.dream.finance.util.alipay.HttpProtocolHandler;
import org.dream.finance.util.alipay.HttpRequest;
import org.dream.finance.util.alipay.HttpResponse;
import org.dream.finance.util.alipay.HttpResultType;
import org.dream.finance.util.alipay.ParamUtil;
import org.dream.model.finance.FinanceTransferCertModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinanceIOType;
import org.dream.utils.mvc.Response;
import org.dream.utils.prop.SpringProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Service
public class AlipayTransferServiceImpl implements AlipayTransferService {
	private Logger logger = LoggerFactory.getLogger(AlipayTransferService.class);
	@Autowired
	private SpringProperties springProperties;
	@Autowired
	private BasicFinanceService basicFinanceService;
	@Autowired
	private FinanceTransferDao transferDao;

	@Override
	public Response alipayResult(String certParameter, String selfOrderId, Integer transferId) {
		String fileName = selfOrderId + ".csv";
		JSONObject parameter = JSON.parseObject(certParameter);
		Map<String, String> sParaTemp = new HashMap<String, String>();
		sParaTemp.put("service", "bptb_result_file");
		String partner = parameter.getString("partner");
		sParaTemp.put("partner", partner);
		sParaTemp.put("_input_charset", ParamUtil.input_charset);
		sParaTemp.put("file_name", fileName);
		String md5Key = parameter.getString("md5Key");
		Map<String, String> sPara = ParamUtil.buildRequestPara(sParaTemp, md5Key);
		HttpProtocolHandler httpProtocolHandler = HttpProtocolHandler.getInstance();
		HttpRequest request = new HttpRequest(HttpResultType.BYTES);
		request.setCharset(ParamUtil.input_charset);
		request.setParameters(ParamUtil.generatNameValuePair(sPara));
		String ALIPAY_GATEWAY_NEW = springProperties.getProperty("admin.alipay.transfer_url");
		request.setUrl(ALIPAY_GATEWAY_NEW + "_input_charset=" + ParamUtil.input_charset);
		HttpResponse response = null;
		try {
			response = httpProtocolHandler.execute(request, "", "");
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (response == null) {
			return null;
		}
		byte[] byteResult = response.getByteResult();
		ZipInputStream inputStream = new ZipInputStream(new ByteArrayInputStream(byteResult));
		ZipEntry entry = null;
		String thirdOrderId = null;
		Integer status = null;
		Double money = null;
		String comments = null;
		try {
			while ((entry = inputStream.getNextEntry()) != null) {
				if (entry.getName().equals(fileName)) {
					logger.info("支付宝转账结果查询:解析转账结果文件{}", fileName);
					String csvFile = IOUtils.toString(inputStream, "GBK");
					String[] dataLines = csvFile.split("\r\n");
					for (int i = 0; i < dataLines.length; i += 2) {
						String[] keys = dataLines[i].split(",");
						String[] values = dataLines[i + 1].split(",");
						for (int j = 0; j < values.length; j++) {
							String key = keys[j];
							String value = values[j];
							if ("提现流水号".equals(key)) {
								thirdOrderId = value;
							} else if ("成功失败标志".equals(key)) {
								if ("F".equals(value)) {
									status = 5;
								} else if ("S".equals(value)) {
									status = 3;
								}
							} else if ("金额".equals(key)) {
								money = Double.valueOf(value);
							} else if ("备注".equals(key)) {
								comments = value;
							}
						}
					}
					if (status == 5) {
						basicFinanceService.transferNotify(transferId, selfOrderId, thirdOrderId, money, status, null);
					} else if (status == 3) {
						basicFinanceService.transferNotify(transferId, selfOrderId, thirdOrderId, money, status, null);
					}
					FinanceTransferModel transferModel = new FinanceTransferModel();
					transferModel.setId(transferId);
					transferModel.setThirdOrderId(thirdOrderId);
					transferModel.setComments(comments);
					transferModel.setStatus(status);
					transferDao.update(transferModel);
					return Response.success();
				}
			}
		} catch (Exception e) {
			logger.error("{}", e);
		}
		return null;
	}
}
