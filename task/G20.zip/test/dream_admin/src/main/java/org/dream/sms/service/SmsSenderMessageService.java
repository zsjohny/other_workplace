package org.dream.sms.service;


import org.dream.model.sms.SmsSenderMessage;
import org.dream.utils.mvc.Page;

public interface SmsSenderMessageService {

	public void createSenderMessage(SmsSenderMessage senderMseeage);

	public void updateSenderMessage(SmsSenderMessage senderMseeage);

	public Page<SmsSenderMessage> pagingQuery(Integer type, Integer channelId, Integer status, Integer pageIndex,
			Integer pageSize);

	public SmsSenderMessage getSenderByStatus(Integer status, Integer channelId);

	public boolean hasSender(Integer type, Integer channelId);

	public Integer hasSenderIsActive(Integer type, Integer channelId, Integer status);
	
	public void remove(Integer id);
	
	public SmsSenderMessage getSenderMsgById(Integer type,Integer id);
}
