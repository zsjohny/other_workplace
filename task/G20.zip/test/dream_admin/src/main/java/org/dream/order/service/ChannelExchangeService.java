package org.dream.order.service;

import java.util.List;

import org.dream.model.order.ChannelExchangeModel;
import org.dream.utils.mvc.Page;

public interface ChannelExchangeService {

	public List<ChannelExchangeModel> getExchangesByChannelId(Integer channelId);

	public void insert(ChannelExchangeModel exchangeModel);

	public Page<ChannelExchangeModel> querypaging(Integer channelId, Integer pageIndex, Integer pageSize);
}
