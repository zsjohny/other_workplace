package org.dream.finance.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;

public interface FinanceIODao {
	// V3
	public Integer validate(Integer id);
	// *********************************************************************

	// V2
	public void updateById(FinanceIOModel ioModel);

	public FinanceIOManageModel findDailById(Integer id);

	public void updateCommissionById(FinanceIOModel ioModel);

	public FinanceIOModel findByTransferIOId(Integer id);

	// ******************************************************

	public List<FinanceIOManageModel> findByPage(@Param("model") FinanceIOManageModel model,
			@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

	public Integer findRows(@Param("model") FinanceIOManageModel model);

	public List<FinanceIOModel> findByIds(List<Integer> idList);

	public void updateByIOIds(Integer status, @Param("ids") List<Integer> idList);

	public void updateSelfOrderIdByIOIds(@Param("ids") List<Integer> idList);

	public List<Map<String, Object>> find(@Param("status") Integer status, @Param("typeDetail") Integer typeDetail,
			@Param("platform") String platform);

	public void update(Integer status, String thirdOrderId, String selfOrderId);

	public FinanceIOModel findBySelfOrderId(String selfOrderId);

	public FinanceIOManageModel findById(@Param(value = "id") Integer id);

}
