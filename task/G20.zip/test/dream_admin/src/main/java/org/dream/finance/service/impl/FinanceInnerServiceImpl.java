package org.dream.finance.service.impl;

import org.dream.finance.dao.FinanceMainDao;
import org.dream.finance.service.BasicInnerService;
import org.dream.finance.service.FinanceInnerService;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceInnerServiceImpl implements FinanceInnerService {
	@Autowired
	private BasicInnerService innerService;
	@Autowired
	private FinanceMainDao mainDao;

	@Override
	public Response innerDepositMoney(Integer userId, Double money) {
		if (money <= 0) {
			return Response.response(ResponseCode.ERROR_CODE, "充值资金需大于0");
		}
		innerService.innerDepositMoney(userId, money);
		return Response.response(ResponseCode.SUCCESS_CODE, "内部充值资金成功");
	}

	@Override
	public Response innerDepositScore(Integer userId, Double score) {
		if (score <= 0) {
			return Response.response(ResponseCode.ERROR_CODE, "充值积分需大于0");
		}
		innerService.innerDepositScore(userId, score);
		return Response.response(ResponseCode.SUCCESS_CODE, "内部充值积分成功");
	}

	@Override
	public Response innerExtractMoney(Integer userId, Double money) {
		if (money <= 0) {
			return Response.response(ResponseCode.ERROR_CODE, "取出资金需大于0");
		}
		if (mainDao.find(userId).getMoneyUsable() < money) {
			return Response.response(ResponseCode.ERROR_CODE, "取出资金大于可用资金余额");
		}
		innerService.innerExtractMoney(userId, money);
		return Response.response(ResponseCode.SUCCESS_CODE, "内部取出资金成功");
	}

	@Override
	public Response innerExtractScore(Integer userId, Double score) {
		if (score <= 0) {
			return Response.response(ResponseCode.ERROR_CODE, "取出积分需大于0");
		}
		if (mainDao.find(userId).getScoreUsable() < score) {
			return Response.response(ResponseCode.ERROR_CODE, "取出积分大于可用积分余额");
		}
		innerService.innerExtractScore(userId, score);
		return Response.response(ResponseCode.SUCCESS_CODE, "内部取出积分成功");
	}

}
