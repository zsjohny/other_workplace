package org.dream.admin.service;

import java.util.List;

import org.dream.admin.model.AdminDepartmentModel;
import org.dream.utils.mvc.Page;

/**
 * 部门Service接口
 * 
 * @author wangd
 *
 */
public interface AdminDepartmentService {

    public void saveDeparment(AdminDepartmentModel deparmentMoudel);

    public void updateDeparment(AdminDepartmentModel deparmentMoudel);

    public void removeDeparment(Integer id,Integer dataId);

    public String removeDeparmentsByIds(List<Integer> ids,Integer dataId);

    /**
     * 多条件分页查询
     * @param sn
     * @param fullName
     * @param shortName
     * @param description
     * @param parentId
     * @param pageIndex
     * @param pageSize
     * @return
     */
    public Page<AdminDepartmentModel> pagingQueryDeparment(String sn,
            String fullName, String shortName, String description,
            Integer parentId,Integer dataId ,Integer pageIndex, Integer pageSize);
   
    /**
     * 获得部门下所有的子部门
     * @param parentId
     * @return
     */
    public List<AdminDepartmentModel> getDepatementsByParentId(Integer parentId,Integer dataId);
    
    /**
     * 验证部门编号是否已存在
     * @param sn
     * @return
     */
    public boolean hasDeparmentBySn(String sn);
    
    public AdminDepartmentModel getDeparmentById(Integer id,Integer dataId);
    
    public List<AdminDepartmentModel> getTopDepartments(Integer dataId);
}
