package org.dream.order.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminUserModel;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.OrderCashCount;
import org.dream.model.order.OrderSunModel;
import org.dream.order.service.OrderService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping("/order")
@Controller
public class OrderController extends BaseController {
	private static Logger logger=LoggerFactory.getLogger(OrderController.class);
	@Autowired
	private OrderService orderService;

	/**
	 * 积分订单查询
	 * 
	 * @auth yehx
	 * @date 2016年7月27日
	 */
	@RequestMapping(value = "/queryIntegral", method = RequestMethod.POST)
	@ResponseBody
	public Response queryIntegralOrderList(OrderSunModel orderSun, HttpServletRequest req) {
		Page<OrderSunModel> data = orderService.queryIntegralOrderList(orderSun, super.getCurrentChannel(req));
		return Response.success(data);
	}

	/**
	 * 获得品种
	 * 
	 * @auth yehx
	 * @date 2016年7月27日
	 */
	@RequestMapping(value = "/getVariety", method = RequestMethod.POST)
	@ResponseBody
	public Response getVarietyIdAndVarietyName() {
		List<Map<String, Object>> data = orderService.getVarietyIdAndVarietyName();
		return Response.success(data);
	}

	/**
	 * 根据积分订单id得到订单信息
	 * 
	 * @auth yehx
	 * @date 2016年7月27日
	 */
	@RequestMapping(value = "/getIntegralInfo", method = RequestMethod.POST)
	@ResponseBody
	public Response getOrderSunModelByIdForIntegral(int id) {
		return Response.success(orderService.getOrderSunModelByIdForIntegral(id));
	}

	/**
	 * 现金订单查询
	 * 
	 * @auth yehx
	 * @date 2016年7月27日
	 */
	@RequestMapping(value = "/queryCash", method = RequestMethod.POST)
	@ResponseBody
	public Response queryCashOrderList(OrderSunModel orderSun, HttpServletRequest req) {
		Page<OrderSunModel> data = orderService.queryCashOrderList(orderSun, super.getCurrentChannel(req));
		return Response.success(data);
	}

	/**
	 * 根据现金订单id得到订单信息
	 * 
	 * @auth yehx
	 * @date 2016年7月27日
	 */
	@RequestMapping(value = "/getCashInfo", method = RequestMethod.POST)
	@ResponseBody
	public Response getOrderSunModelByIdForCash(Integer id) {
		if (id == null) {
			return Response.response(700, "请求参数出错");
		}
		return Response.success(orderService.getOrderSunModelByIdForCash(id));
	}

	/**
	 * 现金订单人为操作已支付待持仓订单 场景，网关交易失败，将订单状态修改z`为失败，并且将钱退还给用户
	 * 
	 * @param id
	 *            订单id
	 * @param payType
	 *            支付方式
	 * @auth yehx
	 * @date 2016年7月28日
	 */
	@RequestMapping(value = "/positionFailure", method = RequestMethod.POST)
	@ResponseBody
	public Response dealWithPositionFailure(Integer id, HttpServletRequest req) {
		if (id == null) {
			return Response.response(700, "请求参数出错");
		}
		//
		int userId=(int) req.getSession().getAttribute("userId");
		logger.info("后台用户id={},将已支付待持仓的订单id={},退款开始：",userId,id);
		Map<String, Object> map = orderService.dealWithPositionFailure(id, super.getCurrentChannel(req).getId());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将已支付待持仓订单id={},退款失败,e={}",req.getSession().getAttribute("userId"),id,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将已支付待持仓订单id={},退款成功：",userId,id);
		return Response.success();

	}

	/**
	 * 现金订单人为操作已支付待持仓订单 场景：网关持仓成功，但是未返回消息给订单。
	 * 
	 * @auth yehx
	 * @date 2016年7月28日
	 */
	@RequestMapping(value = "/userPosition", method = RequestMethod.POST)
	@ResponseBody
	public Response dealWithPosition(Integer id, String realAvgPrice, Integer realHandsNum, String time,
			HttpServletRequest request) {
		realHandsNum = 1;
		if (id == null || realAvgPrice == null || time == null) {
			return Response.response(700, "请求参数出错");
		}
		int userId=(int) request.getSession().getAttribute("userId");
		logger.info("后台用户id={},将已支付待持仓订单id={},变为持仓开始：",userId,id);
		Map<String, Object> map = orderService.dealWithPosition(id, realAvgPrice, realHandsNum, time,
				super.getCurrentChannel(request).getId());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将已支付待持仓订单id={},变为持仓失败 e={}：",request.getSession().getAttribute("userId"),id,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将已支付待持仓订单id={},变为持仓成功：",userId,id);
		return Response.success();
	}

	/**
	 * 现金订单人为操作平仓处理中的订单 场景：网关处理平仓失败,没有将消息发给订单。。。。。
	 * 
	 * @auth yehx
	 * @date 2016年7月29日
	 */
	@RequestMapping(value = "/unwindFailure")
	@ResponseBody
	public Response dealWithUnwindProcessFailure(int id, HttpServletRequest request) {
		int userId = (int) request.getSession().getAttribute("userId");
		logger.info("后台用户id={},将平仓处理中的订单id={},变为持仓开始：",userId,id);
		Map<String, Object> map = orderService.dealWithUnwindProcessFailure(id,
				super.getCurrentChannel(request).getId());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将平仓处理中的订单id={},变为持仓失败 e={}：",userId,id,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将平仓处理中的订单id={},变为持仓成功 ",userId,id);
		return Response.success();
	}

	/**
	 * 现金订单人为操作平仓处理中的订单 场景：网关处理平仓成功,没有将消息发给订单。。。。。
	 * 
	 * @param id
	 *            订单 id
	 * @param unwindAvgPrice
	 *            平仓均价
	 * @auth yehx
	 * @date 2016年7月29日
	 */
	@RequestMapping(value = "/unwind")
	@ResponseBody
	public Response dealWithUnwind(Integer id, String unwindAvgPrice, String time, Integer unwindType,
			HttpServletRequest request) {
		if (id == null || unwindAvgPrice == null || time == null || unwindType == null) {
			Response.response(701, "请求参数出错");
		}
		int userId = (int) request.getSession().getAttribute("userId");
		AdminUserModel admin = (AdminUserModel) request.getSession().getAttribute("user");
		logger.info("后台用户id={},将平仓处理中的订单id={},变为结算成功开始：",userId,id);
		Map<String, Object> map = orderService.dealWithUnwind(id, unwindAvgPrice, time, unwindType,
				super.getCurrentChannel(request).getId(),admin.getUserAccount());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将平仓处理中的订单id={},变为结算成功失败：e={}",userId,id,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将平仓处理中的订单id={},变为结算成功成功",userId,id);
		return Response.success();

	}
	
	/**
	 * 将持仓中的订单市价或者人工平仓
	 * @auth yehx
	 * @date 2016年10月19日
	 */
	@RequestMapping(value="opsitionSettle")
	@ResponseBody
	public Response dealWithOpsitionSettle(Integer id,String unwindAvgPrice,String time,Integer unwindType,HttpServletRequest request){
		if (id == null || unwindAvgPrice == null || time == null || unwindType == null) {
			Response.response(701, "请求参数出错");
		}
		int userId = (int) request.getSession().getAttribute("userId");
		AdminUserModel admin = (AdminUserModel) request.getSession().getAttribute("user");
		logger.info("后台用户id={},将持仓中的订单id={},变为结算成功开始：",userId,id);
		Map<String,Object> map =orderService.dealWithOpsitionSettle(id,unwindAvgPrice,time,unwindType,super.getCurrentChannel(request).getId(),admin.getUserAccount());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将持仓中的订单id={},变为结算成功失败：e={}",userId,id,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将平仓处理中的订单id={},变为结算成功成功",userId,id);
		return Response.success();
	}
	
	/**
	 * 将持仓中的订单发起风控平仓
	 * @auth yehx
	 * @date 2016年10月19日
	 */
	@RequestMapping(value="opsitionRiskUnwind")
	@ResponseBody
	public Response opsitionRiskUnwind(Integer id,Integer unwindType,HttpServletRequest request){
		if (id == null || unwindType == null) {
			Response.response(701, "请求参数出错");
		}
		int userId = (int) request.getSession().getAttribute("userId");
		logger.info("后台用户id={},将持仓中的订单id={},发起风控平仓开始：",userId,id);
		Map<String,Object> map =orderService.opsitionRiskUnwind(id,unwindType,super.getCurrentChannel(request).getId());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将持仓中的订单id={},发起风控平仓失败：e={}",userId,id,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将持仓中的订单id={},发起风控平仓成功",userId,id);
		return Response.success();
	}
	
	
	
	
	

	/**
	 * 批量失败
	 * 
	 * @auth yehx
	 * @date 2016年9月20日
	 */
	@RequestMapping(value = "/batchFailure")
	@ResponseBody
	public Response batchFailure(String orderms, HttpServletRequest req) {
		if (orderms == null) {
			Response.response(701, "请求参数出错");
		}
		//
		int userId = (int) req.getSession().getAttribute("userId");
		logger.info("后台用户id={},将订单orderms={},操作批量失败开始",userId,orderms);
		Map<String, Object> map = orderService.batchFailure(orderms, super.getCurrentChannel(req).getId());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将订单orderms={},操作批量失败失败e={}",userId,orderms,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将订单orderms={},操作批量失败成功",userId,orderms);
		return Response.success();
	}

	/**
	 * 批量成功
	 * 
	 * @auth yehx
	 * @date 2016年9月20日
	 */
	@RequestMapping(value = "/batchSuccess")
	@ResponseBody
	public Response batchSuccess(String orderms, HttpServletRequest req, String price, String time,
			Integer unwindType) {
		if (orderms == null || price == null || time == null) {
			Response.response(701, "请求参数出错");
		}
		//
		int userId = (int) req.getSession().getAttribute("userId");
		logger.info("后台用户id={},将订单orderms={},操作批量成功开始",userId,orderms);
		AdminUserModel admin = (AdminUserModel) req.getSession().getAttribute("user");
		Map<String, Object> map = orderService.batchSuccess(orderms, admin.getUserAccount(), price, time, unwindType,
				super.getCurrentChannel(req).getId());
		if ("0".equals(map.get("retCode"))) {
			logger.info("后台用户id={},将订单orderms={},操作批量成功失败e={}",userId,orderms,map.get("retmsg"));
			return Response.response(701, (String) map.get("retmsg"));
		}
		logger.info("后台用户id={},将订单orderms={},操作批量成功成功",userId,orderms);
		return Response.success();
	}

	// @RequestMapping(value = "/getOrderCashCount")
	// @ResponseBody
	// public Response getOrderCashCount(HttpServletRequest request) {
	// ChannelModel cm = getCurrentChannel(request);
	// OrderCashCount cashCount = orderService.getOrderCashCount(cm);
	// Integer bearishCount = orderService.getBearishCount(cm);
	// Integer candoCoun = orderService.getCandoCoun(cm);
	// cashCount.setBearishCount(bearishCount);
	// cashCount.setCandoCoun(candoCoun);
	// cashCount.setNetEquityPosition(Math.abs(bearishCount - candoCoun));
	// return Response.success(cashCount);
	//
	// }

	@RequestMapping(value = "/getOrderCashCount", method = RequestMethod.POST)
	@ResponseBody
	public Response countCashOrderList(OrderSunModel orderSun, HttpServletRequest request) {
		ChannelModel cm = super.getCurrentChannel(request);
		OrderCashCount count = orderService.countCashOrderList(orderSun, cm);
		return Response.success(count);

	}
}
