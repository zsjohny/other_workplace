package org.dream.finance.service;

import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.utils.mvc.Response;

public interface FinanceIOService {
	public FinanceIOManageModel findIODetail(Integer id);

	public Response adjustCommission(FinanceIOModel ioModel);

}
