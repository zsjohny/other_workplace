package org.dream.admin.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.admin.model.AdminPerssionModel;
import org.dream.admin.model.AdminRoleModel;

/**
 * 授权相关Dao 包含权限、角色、授权Dao
 * 
 * @author wangd
 *
 */
public interface AdminAuthorityDao {

	/**
	 * 批量删除数据 可以删除角色和权限
	 * 
	 * @param ids
	 */
	public void deleteAuthoritysByIds(@Param(value = "ids") List<Integer> ids);

	/**
	 * ****************************************************权限部分DAO接口************
	 * *********
	 */
	/**
	 * 分页多条件查询权限结果
	 * 
	 * @param queryPermissionCondition
	 * @return
	 */
	public List<AdminPerssionModel> pagingQueryPermissions(Map<String, Object> queryPermissionCondition);

	/**
	 * 分页多条件查询权限结果条数
	 * 
	 * @param queryPermissionCondition
	 * @return
	 */
	public int pagingQueryPermissions_count(Map<String, Object> queryPermissionCondition);

	/**
	 * 权限保存
	 * 
	 * @param perssionModel
	 */
	public void createPermission(AdminPerssionModel perssionModel);

	/**
	 * 动态修改权限信息
	 * 
	 * @param perssionModel
	 */
	public void updatePermission(AdminPerssionModel perssionModel);

	/**
	 * 分页获得用户授权的角色
	 * 
	 * @param limit
	 * @param size
	 * @param actorId
	 * @param category
	 * @param name
	 *            角色名称
	 * @return
	 */
	public List<AdminPerssionModel> pagingQueryGrantPsemissionsByActorId(@Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size, @Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category);

	public Integer pagingQueryGrantPsemissionsByActorId_count(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category);

	/**
	 * 根据参与者Id分页查询未授权给参与者的权限
	 * 
	 * @param limit
	 * @param pagesize
	 * @param actorId
	 * @param category
	 * @return
	 */
	public List<AdminPerssionModel> pagingQueryNotGrantPsemissionByActorId(@Param(value = "limit") Integer limit,
			@Param(value = "size") Integer pagesize, @Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category);

	public Integer pagingQueryNotGrantPsemissionByActorId_count(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category);

	/**
	 * **********************角色相关的数据库操作开始************************************
	 */

	public void createAdminRole(AdminRoleModel roleModel);

	public void updateAdminRole(AdminRoleModel roleModel);

	public void deleteAdminRole(Integer id);

	public AdminRoleModel getRole(Integer id);

	/**
	 * 多条件查询角色
	 * 
	 * @param name
	 * @param description
	 * @param category
	 * @param dataId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminRoleModel> pagingQueryRole(@Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "category") String category,
			@Param(value = "dataId") Integer dataId, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer pagingQueryRole_count(@Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "category") String category,
			@Param(value = "dataId") Integer dataId);

	/**
	 * 分页获得用户授权的角色
	 * 
	 * @param limit
	 * @param size
	 * @param actorId
	 * @param category
	 * @param name
	 *            角色名称
	 * @return
	 */
	public List<AdminRoleModel> pagingQueryGrantRolesByUserId(@Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size, @Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category, @Param(value = "name") String name,
			@Param(value = "dataId") Integer dataId);

	public Integer pagingQueryGrantRolesByUserId_count(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category, @Param(value = "name") String name,
			@Param(value = "dataId") Integer dataId);

	/**
	 * 分页获得未授权给用户的角色
	 * 
	 * @param limit
	 * @param size
	 * @param actorId
	 * @param category
	 * @param name
	 *            角色/权限名称
	 * @return
	 */
	public List<AdminRoleModel> pagingQueryNotGrantRolesByUserId(@Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size, @Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category, @Param(value = "name") String name,
			@Param(value = "dataId") Integer dataId);

	public Integer pagingQueryNotGrantRolesByUserId_count(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category, @Param(value = "name") String name,
			@Param(value = "dataId") Integer dataId);

	/**
	 * 获得所有授权给参与者的角色
	 * 
	 * @param actorId
	 * @param category
	 * @return
	 */
	public List<AdminRoleModel> queryGrantRolesByUserId(@Param(value = "actorId") Integer actorId,
			@Param(value = "category") String category);

	/**
	 * 根据dataId type来查询角色列表
	 * @param dataId
	 * @param type
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminRoleModel> pagingQueryRolesByIsAdmin(@Param(value = "dataId") Integer dataId,
			@Param(value = "type") Integer type, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);
	
	public Integer pagingQueryRolesByIsAdmin_count(@Param(value = "dataId") Integer dataId,
			@Param(value = "type") Integer type);
	
	
	public List<AdminRoleModel> findRoles(@Param(value = "dataId") Integer dataId);
}
