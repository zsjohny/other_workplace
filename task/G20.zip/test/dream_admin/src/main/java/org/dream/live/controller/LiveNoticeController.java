package org.dream.live.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.live.service.LiveNoticeService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.live.LiveNoticeModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 直播公告(后台只有一条公告处于启用状态)
 * 
 * @author ZY
 * @date 2016年10月13日
 */
@RequestMapping("/liveNotice")
@Controller
public class LiveNoticeController extends BaseController {

	@Autowired
	LiveNoticeService liveNoticeService;

	/**
	 * 一级渠道添加公告(默认为不启用)
	 * 
	 * @param liveNoticeModel
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/insert")
	@ResponseBody
	public Response insertLiveNotice(LiveNoticeModel liveNoticeModel, HttpServletRequest request) {
		Assert.notNull(liveNoticeModel.getTitle(), "标题不能为空");
		Assert.notNull(liveNoticeModel.getContent(), "内容不能为空");
		// 获取当前渠道的信息
		ChannelModel channelModel = super.getCurrentChannel(request);
		liveNoticeModel.setChannelId(channelModel.getId());
		liveNoticeService.createLiveNotice(liveNoticeModel);
		return Response.success();
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/remove")
	@ResponseBody
	public Response removeLiveNotice(String ids) {
		Assert.notNull(ids, "id不能为空");
		liveNoticeService.removeLiveNotice(ids);
		return Response.success();
	}

	/**
	 * 更新，传入id，content，title，status字段。如果只传入status，表示修改状态。
	 * 
	 * @param liveNoticeModel
	 * @return
	 */
	@RequestMapping(value = "/update")
	@ResponseBody
	public Response updateLiveNotice(LiveNoticeModel liveNoticeModel, HttpServletRequest request) {
		Assert.notNull(liveNoticeModel.getId(), "id不能为空");
		// 如果传入的status=1，则关闭该渠道下其它已启用的公告
		ChannelModel channelModel = super.getCurrentChannel(request);
		if (liveNoticeModel.getStatus() == 1) {
			List<LiveNoticeModel> notices = liveNoticeService.getAll(channelModel.getId(), 1);
			if (notices != null && notices.size() > 0) {
				for (LiveNoticeModel ln : notices) {
					ln.setStatus(0);
					liveNoticeService.updateLiveNotice(ln);
				}
			}
		}
		liveNoticeService.updateLiveNotice(liveNoticeModel);
		return Response.success();
	}

	/**
	 * 分页获取
	 * 
	 * @param status
	 * @param page
	 * @param pageSize
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/querypaging")
	@ResponseBody
	public Response queryPagingLiveNotice(Integer status, Integer page, Integer pageSize, HttpServletRequest request) {
		// 获取当前渠道的信息
		ChannelModel channelModel = super.getCurrentChannel(request);
		Page<LiveNoticeModel> data = liveNoticeService.querypaging(channelModel.getId(), status, page, pageSize);
		return Response.success(data);
	}

}
