package org.dream.finance.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceAccModel;
import org.dream.model.finance.FinanceDrawModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinanceIOType;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;
import org.dream.utils.constants.FinanceType;
import org.dream.utils.mvc.Response;

public interface BasicFinanceService {
	// v2
	public void systemMakeMoney(Integer id, Double money);

	// *******************************************************************
	public FinanceMainModel findMain(Integer userId);

	public FinanceAccModel findAcc(Integer userId);

	public List<FinanceFlowManageModel> findFlowByPage(String createTimeStart, String createTimeEnd, Integer userId,
			String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, Integer offset, Integer pageSize, String flow);

	public Integer findFlowRows(String createTimeStart, String createTimeEnd, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, Integer type, Integer typeDetail, String remark,
			String flow);

	public List<FinanceIOManageModel> findIOByPage(FinanceIOManageModel model, Integer offset, Integer pageSize);

	public Integer findIORows(FinanceIOManageModel model);

	// 提现状态查询相关
	public List<FinanceDrawModel> findDrawByPage(Integer status, Integer channelId, Integer offset, Integer pageSize);

	public Integer findDrawRows(Integer status, Integer channelId);

	// 提现审核
	public void checkDraw(Integer status, List<Integer> idList);

	// 转账相关
	public List<FinanceTransferModel> saveTransfer(List<Integer> idList, FinanceTransferType transferType,
			FinancePayType payType, String operator);

	public List<FinanceTransferManageModel> findTransferByPage(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId, Integer offset,
			Integer pageSize);

	public Integer findTransferRows(Integer userId, String userName, String userPhone, String realName,
			String transferType, Integer status, String operator, String createTimeStart, String createTimeEnd,
			String updateTimeStart, String updateTimeEnd, Integer topChannelId);

	public FinanceTransferManageModel findTransfer(Integer topChannelId, Integer transferId);

	// 转账通知
	public void transferNotify(Integer transferId, String selfOrderId, String thirdOrderId, Double money,
			Integer status, FinanceIOType financeIOType);

	public FinanceIOManageModel findById(Integer id);
}
