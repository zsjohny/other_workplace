package org.dream.user.dao;

import org.apache.ibatis.annotations.Param;
import org.dream.model.user.UserBankCardModel;

public interface UserBankCardDao {
	public UserBankCardModel find(Integer userId);

	public void update(UserBankCardModel bankCardModel);
	
	public UserBankCardModel findByIdCard(@Param("userId")Integer userId ,@Param("idCard") String idCard);
}
