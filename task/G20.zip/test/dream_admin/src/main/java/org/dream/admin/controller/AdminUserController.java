package org.dream.admin.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dream.admin.model.AdminActorModel;
import org.dream.admin.model.AdminPerssionModel;
import org.dream.admin.model.AdminRoleModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.admin.service.AdminPermissionService;
import org.dream.admin.service.AdminRoleService;
import org.dream.admin.service.AdminUserService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/adminUser")
public class AdminUserController extends BaseController {
	@Autowired
	AdminUserService adminUserService;

	@Autowired
	AdminRoleService adminRoleService;

	@Autowired
	AdminPermissionService adminPermissionService;
	
	Logger logger = LoggerFactory.getLogger(AdminUserController.class);

	/**
	 * 多条件分页查询User列表
	 * 
	 * @param userName
	 * @param userAccount
	 * @param description
	 * @param disabled
	 * @param realName
	 * @param phone
	 * @return
	 */
	@RequestMapping(value = "/pagingQuery", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQuery(Integer page, Integer pageSize, String name, String userAccount, String description,
			Boolean disabled, String phone, String email, HttpServletRequest request) {
		Integer dataId = getDataId(request);
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<AdminActorModel> resultPage = adminUserService.getUserList(page, pageSize, userAccount, name, email,
				disabled, phone, dataId);
		return Response.success(resultPage);

	}

	/**
	 * 添加User
	 * 
	 * @param name
	 * @param userAccount
	 * @param description
	 * @param request
	 * @param resp
	 * @return
	 */
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	@ResponseBody
	public Response add(String name, String userAccount, String description, Integer departmentId,
			HttpServletRequest request, HttpServletResponse resp, Integer dataId) {
		Assert.notNull(name, "用户名称不能为空");
		Assert.notNull(userAccount, "用户登录账号不能为空");
		AdminUserModel currentUser = (AdminUserModel) request.getSession().getAttribute("user");
		// 验证用户账户是否已经存在
		AdminUserModel userModel = new AdminUserModel();
		if (dataId == null) {
			dataId = super.getDataId(request);
		}
		userModel.setDataId(dataId);
		if (adminUserService.hasUserAccount(userAccount, dataId)) {
			return Response.error("添加用户失败，已存在的用户账户");
		}
		userModel.setName(name);
		userModel.setUserAccount(userAccount);
		userModel.setDescription(description);
		if (currentUser != null) {
			userModel.setCreateOwnerId(currentUser.getId() != null ? currentUser.getId() : 0);
			userModel.setCreateOwner(currentUser.getName() != null ? currentUser.getName() : "admin");
		}
		if (departmentId != null) {
			adminUserService.createAdminUser(userModel, departmentId);
		} else if (departmentId == null) {
			adminUserService.createAdminUser(userModel, null);
		}
		return Response.success();
	}

	/**
	 * 修改用户信息
	 * 
	 * @param id
	 * @param name
	 * @param userAccount
	 * @param description
	 * @return
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public Response update(Integer id, String name, String userAccount, String description) {
		Assert.notNull(name, "用户名称不能为空");
		Assert.notNull(userAccount, "用户登录账号不能为空");
		AdminUserModel userModel = new AdminUserModel();
		userModel.setId(id);
		userModel.setName(name);
		userModel.setUserAccount(userAccount);
		userModel.setDescription(description);
		adminUserService.updateAdminUserExceptPassword(userModel);
		return Response.success();
	}

	/**
	 * 删除多条用户
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteUsers", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteUsers(String ids, HttpServletRequest request) {
		Integer dataId = getDataId(request);
		Assert.notNull(ids, "要删除的用户的id不能为空");

		String[] id = ids.split(",");
		List<Integer> idList = new ArrayList<Integer>();
		for (int i = 0; i < id.length; i++) {
			idList.add(Integer.valueOf(id[i]));
		}
		adminUserService.deleteAdminUsers(idList, dataId);
		return Response.success();

	}

	/**
	 * 分页获得未授权给User的角色
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryNotGrantRoles", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryNotGrantRoles(Integer page, Integer pageSize, Integer userId, String name,
			HttpServletRequest request) {
		Page<AdminRoleModel> pageResult = adminRoleService.pagingQueryNotGrantRoles(page, pageSize, userId, name,
				super.getDataId(request));
		return Response.success(pageResult);

	}

	/**
	 * 分页获得已授权给User的角色
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryGrantRoleByUserId", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryGrantRoleByUserId(Integer page, Integer pageSize, Integer userId, String name,
			HttpServletRequest request) {
		Page<AdminRoleModel> pageResult = adminRoleService.pagingQueryGrantRoles(page, pageSize, userId, name,
				super.getDataId(request));
		return Response.success(pageResult);

	}

	/**
	 * 为参与者授权
	 * 
	 * @param authorityIds
	 *            授权id，（不区分角色或权限）
	 * @param actorId
	 *            参与者id
	 * @return
	 */
	@RequestMapping(value = "/grantAuthorityToActor", method = { RequestMethod.POST })
	@ResponseBody
	public Response grantAuthorityToActor(String authorityIds, Integer actorId, HttpServletRequest request) {

		// adminUserService.grantAuthoritysToActor(actorId, authorityIdList);
		Assert.notNull(actorId, "参与者id不能为空");
		Assert.notNull(authorityIds, "授权id不能为空");
		List<Integer> authorityIdList = new ArrayList<Integer>();
		String temp[] = authorityIds.split(",");
		for (int i = 0; i < temp.length; i++) {
			authorityIdList.add(Integer.valueOf(temp[i]));
		}
		adminUserService.grantAuthoritysToActor(actorId, authorityIdList, super.getDataId(request));
		return Response.success();
	}

	/**
	 * 批量为用户撤销角色 暂时是只撤销角色，后期可能会也撤销权限
	 * 
	 * @param roleIds
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/terminateAuthorizationByUserInRoles", method = { RequestMethod.POST })
	@ResponseBody
	public Response terminateAuthorizationByUserInRoles(String roleIds, Integer userId, HttpServletRequest request) {

		Assert.notNull(userId, "参与者id不能为空");
		Assert.notNull(roleIds, "授权id不能为空");
		List<Integer> authorityIdList = new ArrayList<Integer>();
		String temp[] = roleIds.split(",");
		for (int i = 0; i < temp.length; i++) {
			authorityIdList.add(Integer.valueOf(temp[i]));
		}
		adminRoleService.terminateAuthorizationByUserIdAuthorithIds(userId, authorityIdList, super.getDataId(request));
		return Response.success();

	}

	/**
	 * 分页获得未授权给User的角色
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryNotGrantPermissions", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryNotGrantPermissions(Integer page, Integer pageSize, Integer userId) {
		Page<AdminPerssionModel> pageResult = adminPermissionService.pagingQueryNotGrantPermissionsByUserId(page,
				pageSize, userId);
		return Response.success(pageResult);

	}

	/**
	 * 分页获得已授权给User的角色
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryGrantPermissionByUserId", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryGrantPermissionByUserId(Integer page, Integer pageSize, Integer userId, String name) {
		Page<AdminPerssionModel> pageResult = adminPermissionService.pagingQueryGrantPermissionByUserId(page, pageSize,
				userId);
		return Response.success(pageResult);

	}

	/**
	 * 用户修改密码 注意前端密码是经过MD5加密后的密码，否则将不能正确匹配用户的密码
	 * 
	 * @param oldUserPassword
	 *            原密码
	 * @param userPassword
	 *            新密码
	 * @return
	 */
	@RequestMapping(value = "/safe_updatePassword", method = { RequestMethod.POST })
	@ResponseBody
	public Response updatePassword(String oldUserPassword, String userPassword, HttpServletRequest request,
			HttpServletResponse resp) {

		Integer userId = (Integer) request.getSession().getAttribute("userId");
		if (userId == null) {
			return Response.error("修改密码失败，无法获得正确的登录用户信息");
		}
		AdminUserModel userModel = adminUserService.getUser(userId);
		if (userModel == null) {
			return Response.error("修改密码失败，无法获得正确的登录用户信息");
		}
		String oldUserPassword_salt = userModel.handlePassword(oldUserPassword);
		// userModel
		// =adminUserService.getUserByUserAccountPassword(userModel.getUserAccount(),oldUserPassword,
		// userId);
		if (!oldUserPassword_salt.equals(userModel.getPassword())) {
			return Response.error("修改密码失败，原密码不正确");
		}
		logger.info("用户更改密码:用户{}更改密码为{}",userModel.getName(),userPassword);
		adminUserService.changePassword(userId, new AdminUserModel().handlePassword(userPassword));
		return Response.success();

	}

	/**
	 * 重置密码(重置为初始密码)
	 * 
	 * @param request
	 * @param resp
	 * @return
	 */
	@RequestMapping(value = "/safe_resetPassword", method = { RequestMethod.POST })
	@ResponseBody
	public Response resetPassword(HttpServletRequest request, HttpServletResponse resp) {
		Integer userId = (Integer) request.getSession().getAttribute("userId");
		if (userId == null) {
			return Response.error("重置密码失败，无法获得正确的登录用户信息");
		}
		AdminUserModel userModel = adminUserService.getUser(userId);
		if (userModel == null) {
			return Response.error("重置密码失败，无法获得正确的登录用户信息");
		}
		adminUserService.changePassword(userId, new AdminUserModel().getDefaultPassword());
		return Response.success();

	}

	/**
	 * 重置密码(重置为初始密码)
	 * 
	 * @param request
	 * @param resp
	 * @return
	 */
	@RequestMapping(value = {"/resetPasswordById","/resetChannelPassword"})
	@ResponseBody
	public Response resetPasswordById(Integer userId) {
		if (userId == null) {
			return Response.error("重置密码失败，无法获得用户信息");
		}
		adminUserService.changePassword(userId, new AdminUserModel().getDefaultPassword());
		return Response.success();

	}

	/**
	 * 禁用用户
	 * 
	 * @param userId
	 * @param request
	 * @param resp
	 * @return
	 */
	@RequestMapping(value = "/suspend", method = { RequestMethod.POST })
	@ResponseBody
	public Response suspend(Integer userId) {
		Assert.notNull(userId, "用户Id不能为空");
		AdminUserModel userModel = new AdminUserModel();
		userModel.setId(userId);
		userModel.setDisable(true);
		adminUserService.updateAdminUserExceptPassword(userModel);
		return Response.success();
	}

	/**
	 * 激活用户
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/activate", method = { RequestMethod.POST })
	@ResponseBody
	public Response activate(Integer userId) {
		Assert.notNull(userId, "用户Id不能为空");
		AdminUserModel userModel = new AdminUserModel();
		userModel.setId(userId);
		userModel.setDisable(false);
		adminUserService.updateAdminUserExceptPassword(userModel);
		return Response.success();
	}

	/**
	 * 查看部门下的用户
	 * 
	 * @param page
	 * @param pagesize
	 * @param departmentId
	 * @return
	 */
	@RequestMapping(value = "/pagingquerByDepartmentId", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingquerByDepartmentId(Integer page, Integer pageSize, Integer departmentId,
			HttpServletRequest request, HttpServletResponse resp) {
		Page<AdminUserModel> pageResult = adminUserService.pagingquerByDepartmentId(departmentId, page, pageSize);
		return Response.success(pageResult);

	}

	@RequestMapping(value = "/deleteUserRelation", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteUserRelation(Integer departmentId, String userIds) {
		Assert.notNull(departmentId, "部门的id不能为空");
		Assert.notNull(userIds, "要移除的用户的id不能为空");
		adminUserService.deleteUserRelation(departmentId, userIds);

		return Response.success();

	}

	/**
	 * 查看未关联的用户
	 * 
	 * @param page
	 * @param pagesize
	 * @return
	 */
	@RequestMapping(value = "/pagingqueryNotRelationUsers", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingqueryNotRelationUsers(Integer page, Integer pageSize, HttpServletRequest request) {
		Page<AdminUserModel> pageResult = adminUserService.pagingqueryNotRelationUsers(page, pageSize,
				super.getDataId(request));
		return Response.success(pageResult);

	}

	/**
	 * 向部门中批量添加已有用户
	 * 
	 * @param departmentId
	 * @param userIds
	 * @return
	 */
	@RequestMapping(value = "/createUserRelation", method = { RequestMethod.POST })
	@ResponseBody
	public Response createUserRelation(Integer departmentId, String userIds) {
		Assert.notNull(departmentId, "部门的id不能为空");
		Assert.notNull(userIds, "要移除的用户的id不能为空");
		adminUserService.createUserRelation(departmentId, userIds);

		return Response.success();
	}

	/**
	 * 分页查询角色下用户
	 * 
	 * @param roleId
	 * @param request
	 * @param page
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/pageQueryActorByRoleId", method = { RequestMethod.POST })
	@ResponseBody
	public Response pageQueryActorByRoleId(Integer roleId, HttpServletRequest request, Integer page, Integer pageSize) {
		Assert.notNull(roleId, "角色id不能为空");
		Page<AdminUserModel> resultPage = adminUserService.pageQueryActorByRoleId(roleId, super.getDataId(request),
				page, pageSize);
		return Response.success(resultPage);
	}

	/**
	 * 移除角色下人员
	 * 
	 * @param roleId
	 * @param actorId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/deleteUserInRole", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteUserInRole(Integer roleId, Integer actorId, HttpServletRequest request) {
		adminUserService.deleteUserInRole(roleId, actorId, super.getDataId(request));
		return Response.success();
	}

}
