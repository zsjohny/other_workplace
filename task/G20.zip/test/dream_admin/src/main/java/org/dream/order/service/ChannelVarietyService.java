package org.dream.order.service;

import java.util.List;

import org.dream.model.order.ChannelVarietyModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.utils.mvc.Page;

public interface ChannelVarietyService {

	public void insertChannelVariety(ChannelVarietyModel channelVarietyModel);

	public void changeChannelVarietyStatusByIds(String ids, Integer status);

	public void deleteChannelVarietiesByIds(String ids);

	public List<ChannelVarietyModel> getChannelVarietyByChannelId(Integer channelId);

	public void updateChannelVarietyCom(ChannelVarietyModel channelVarietyModel, Integer channelId, Integer varietyId);

	public void updateChannelVarietyFees(ChannelVarietyModel channelVarietyModel, Integer channelId, Integer varietyId);

	public void updateFirstInvestorAccount(ChannelVarietyModel channelVarietyModel);

	public void updateSecondChannelVariety(ChannelVarietyModel channelVarietyModel);

	public ChannelVarietyModel getChannelVarietyById(Integer id, Integer channelId, Integer varietyId);

	public void removeVarietyByVarietyId(Integer id);

	public void openVarietyById(Integer id);

	public void deleteChannelVarietiesByVarietyId(Integer VarietyId);

	public Page<ChannelVarietyModel> qureypagingForFirstChannel(Integer channelId, Integer pageIndex, Integer pageSize);

	public Page<ChannelVarietyModel> qureypagingSecondChannel(Integer channelId, Integer pageIndex, Integer pageSize);

	public List<TradingVarietyModel> getVarietyByChannelId(Integer channelId);

	public List<TradingVarietyModel> getVarietyAndSignBySecondChannelId(Integer channelId);

	List<ChannelVarietyModel> findChannelVarietyModelAllByChannelId(Integer channelId);

	public void updateRedisFirstInvestorAccount(Integer channelId, Integer varietyId, String investorAccount);

	public void deleteRedisChannelFees(Integer id, Integer id2);
}
