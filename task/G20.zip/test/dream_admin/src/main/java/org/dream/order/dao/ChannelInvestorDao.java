package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.dream.model.order.ChannelInvestorModel;

public interface ChannelInvestorDao {

	public Integer getCountByChannelIdAndInvestorAccount(ChannelInvestorModel channelInvestorModel);

	public void saveChannelInvestor(ChannelInvestorModel channelInvestorModel);

	public void updateChannelInvestor(ChannelInvestorModel channelInvestorModel);

	public List<ChannelInvestorModel> pagingQueryChannelInvestor(Map<String, Object> map);

	public List<ChannelInvestorModel> getAccountsByChannelId(Integer channelId);

	public Integer pagingQueryChannelInvestorCount(Map<String, Object> map);

	public void removeChannelInvestor(String[] id);

	public ChannelInvestorModel getInfoById(Integer id);

}
