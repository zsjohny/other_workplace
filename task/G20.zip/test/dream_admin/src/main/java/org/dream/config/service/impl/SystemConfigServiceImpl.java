package org.dream.config.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.curator.framework.CuratorFramework;
import org.dream.config.dao.SystemConfigDao;
import org.dream.config.model.SystemConfigModel;
import org.dream.config.service.SystemConfigService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class SystemConfigServiceImpl implements SystemConfigService {

    @Autowired
    SystemConfigDao systemConfigDao;
    
    @Autowired
    CuratorFramework curatorFramework;
    @Override
    public void saveSystemConfig(SystemConfigModel systemConfigModel) throws Exception {
	systemConfigDao.createSystemConfig(systemConfigModel);
	
//	curatorFramework.createContainers(systemConfigModel.getConfigKey());
	if (!this.checkedHasNode(systemConfigModel.getConfigKey())) {
	    curatorFramework.create().forPath(systemConfigModel.getConfigKey(), systemConfigModel.getConfigValue().getBytes());
	}
    }

    @Override
    public void deleteByIds(String ids) throws Exception {

	for (Integer id : this.handleIds(ids)) {
	    SystemConfigModel configModel = systemConfigDao.getById(id);
	    if (configModel != null) {
		systemConfigDao.deleteById(id);
		if (this.checkedHasNode(configModel.getConfigKey())) {
		    curatorFramework.delete().forPath(configModel.getConfigKey());
		}
	    } else {
		throw new RuntimeException("要删除的配置不能为空");
	    }
	}
    }

    @Override
    public Page<SystemConfigModel> querypaging(Integer pageIndex, Integer pageSize) {
	Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
	
	List<SystemConfigModel> list = systemConfigDao.querypaging(limit, pageSize);
	Integer totalCount = systemConfigDao.querypaging_count();
	
	Page<SystemConfigModel> page = new Page<>(pageIndex, pageSize, totalCount);
	
	page.setData(list);
	return page;
    }

    /**
     * 根据path验证该节点配置是否已经存在
     * 在添加和删除之前通过此方法验证一下操作的节点是否存在，这样可以减少添加和删除失败的情况。
     * @param path
     * @return
     */
    private boolean checkedHasNode(String path) {
	
	try {
	    curatorFramework.getData().forPath(path);
	    return true;
	} catch (Exception e) {
	    return false;
	}
    }
    private List<Integer> handleIds(String ids) {
	List<Integer> result = new ArrayList<Integer>();
	String[] temp_id = ids.split(",");
	for (int i = 0; i < temp_id.length; i++) {
	    result.add(Integer.valueOf(temp_id[i]));
	}
	return result;
    }

    @Override
    public void updateSystemConfig(Integer id, String configKey, String configValue, String remark,String configSystem) throws Exception {
	
	systemConfigDao.updateSystemConfig(id, configKey, configValue, remark,configSystem);
	
	if(StringUtils.isNoneEmpty(configKey) && StringUtils.isNoneEmpty(configValue)) {
	    curatorFramework.setData().forPath(configKey, configValue.getBytes());
	}
	
    }

    @Override
    public SystemConfigModel getByKey(String key) {
	
	return systemConfigDao.getByKey(key);
    }
}
