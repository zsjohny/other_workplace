package org.dream.live.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.live.LiveNoticeModel;

/**
 * 直播公告Dao
 * 
 *
 */
public interface LiveNoticeDao {

	public void createLiveNotice(LiveNoticeModel liveNoticeModel);

	public void removeLiveNotice(@Param(value = "ids") List<Integer> ids);

	public void updateLiveNotice(LiveNoticeModel liveNoticeModel);

	public List<LiveNoticeModel> getAll(@Param(value = "channelId") Integer channelId,
			@Param(value = "status") Integer status);

	public LiveNoticeModel getById(@Param(value = "id") Integer id);

	public List<LiveNoticeModel> qureypaging(@Param(value = "channelId") Integer channelId,
			@Param(value = "status") Integer status, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "channelId") Integer channelId,
			@Param(value = "status") Integer status);

}
