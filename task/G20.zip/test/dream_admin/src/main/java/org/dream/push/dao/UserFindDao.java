package org.dream.push.dao;

import org.dream.model.user.UserModel;

import java.util.List;

/**
 * 根据一级渠道获取所有用户信息
 * Created by nessary on 16-9-29.
 */
public interface UserFindDao {
    List<UserModel> findUserAllByChannelId(Integer channelId);
}
