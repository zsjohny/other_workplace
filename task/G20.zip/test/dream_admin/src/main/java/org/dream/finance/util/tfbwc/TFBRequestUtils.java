package org.dream.finance.util.tfbwc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletResponse;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class TFBRequestUtils {

	// // 签名
	// private static String sign;

	// // 服务端返回的数据
	// private static String responseData;

	/**
	 * 发起请求
	 * 
	 * @param url
	 * @param param
	 *            参数列表（按首字母进行排序）
	 */
	public static String sendRequst(final String url, String paramstr, String publicKey) {

		System.out.println("加密原串:" + paramstr);
		String cipherData = encrypt(paramstr.toString(), publicKey);
		System.out.println("加密结果:" + cipherData);

		System.out.println("发起请求--------------------------------------------");
		String responseData = doPost(url, "cipher_data=" + URLEncoder.encode(cipherData));
		return responseData;
	}

	/**
	 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
	 */
	public static String getParamSrc(TreeMap<String, String> paramsMap) {
		StringBuffer paramstr = new StringBuffer();
		for (String pkey : paramsMap.keySet()) {
			String pvalue = paramsMap.get(pkey);
			if (null != pvalue && "" != pvalue && pkey != "sign" && pkey != "retcode" && pkey != "retmsg"
					&& pkey != "source") {// 空值不传递，不签名
				paramstr.append(pkey + "=" + pvalue + "&"); // 签名原串，不url编码
			}
		}
		// 去掉最后一个&
		String result = paramstr.substring(0, paramstr.length() - 1);
		// 原串转码
		// try {
		// result = new String(result.getBytes("utf-8"), "utf-8");
		// } catch (UnsupportedEncodingException e) {
		// e.printStackTrace();
		// }
		System.out.println("签名原串：" + result);
		return result;
	}

	/**
	 * 验签
	 * 
	 * @param source
	 *            签名内容
	 * @param sign
	 *            签名值
	 * @return
	 */
	private static boolean verify(String source, String sign) {
		String publicKey = RSAUtils.loadPublicKey(RSAUtils.GC_PUBLIC_KEY_PATH);
		try {
			boolean verifyResult = RSAUtils.verify(source.getBytes(), publicKey, sign);
			if (verifyResult) {
				System.out.println("验证签名通过");
			} else {
				System.out.println("签名有误");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 对原串进行签名
	 * 
	 * @param paramSrc
	 *            the source to be signed
	 * @return
	 */
	private static String sign(String paramSrc) {
		String privatekey = RSAUtils.loadPrivateKey(RSAUtils.PRIVATE_KEY_PATH);
		String sign = null;
		try {
			sign = RSAUtils.sign(paramSrc.getBytes(), privatekey);
			System.out.println("签名:" + sign);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return sign;
	}

	/**
	 * 加密得到cipherData
	 * 
	 * @param paramstr
	 * @return
	 */
	private static String encrypt(String paramstr, String publickey) {
		// String publickey =
		// RSAUtils.loadPublicKey(RSAUtils.GC_PUBLIC_KEY_PATH);
		publickey = RSAUtils.loadPublicKey(publickey);
		String cipherData = null;
		try {
			cipherData = RSAUtils.encryptByPublicKey(paramstr.getBytes(), publickey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cipherData;
	}

	/**
	 * rsa解密
	 * 
	 * @param cipherData
	 *            the data to be decrypt
	 * @return
	 */
	private static String decryptResponseData(String cipherData, String privatekey) {
		// String privatekey =
		// RSAUtils.loadPrivateKey(RSAUtils.PRIVATE_KEY_PATH);
		privatekey = RSAUtils.loadPrivateKey(privatekey);
		System.out.println("privatekey\n" + privatekey);
		String result;
		try {
			result = RSAUtils.decryptByPrivateKey(TfbBase64.decode(cipherData), privatekey);
			result = new String(result.getBytes("ISO-8859-1"), "utf-8");
			//
			// String sign = result.substring(result.indexOf("sign=") + 5,
			// result.length());
			// String source = result.substring(0, result.lastIndexOf("&sign"));
			// System.out.println("source:" + source);
			// System.out.println("sign:" + sign);
			// verify(source, sign);
			// System.out.println("解密结果:" + result);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static String parseXml(String responseData) {
		String cipher_data = null;

		try {
			Document dom = DocumentHelper.parseText(responseData);
			Element root = dom.getRootElement();

			cipher_data = root.element("cipher_data").getText();
		} catch (DocumentException e1) {
			e1.printStackTrace();
		}
		return cipher_data;
	}

	public static TreeMap<String, String> parseResult(String result, String privatekey) {
		String str = "";
		String cipherData = "";
		try {
			Document dom = DocumentHelper.parseText(result);
			Element root = dom.getRootElement();
			String retcode = root.element("retcode").getText();
			String retmsg = root.element("retmsg").getText();
			str = "retcode=" + retcode + "&retmsg=" + retmsg;
			System.out.println("str-----------------:" + str);
			if ("00".equals(retcode)) {
				cipherData = root.element("cipher_data").getText();
				System.out.println("parseResult0-----------------:" + cipherData);
				cipherData = decryptResponseData(cipherData, privatekey);
				System.out.println("parseResult1-----------------:" + cipherData);
				str += "&" + cipherData;
			}
		} catch (DocumentException e1) {
			e1.printStackTrace();
		}
		System.out.println("str1-----------------:" + str);
		return parseString(str);
	}

	/**
	 * 分解解密后的字符串，保存为map
	 */
	private static TreeMap<String, String> parseString(String responseData) {
		TreeMap<String, String> map = new TreeMap<String, String>();
		String[] s1 = responseData.split("&");
		String[] s2 = new String[2];
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < s1.length; i++) {
			s2 = s1[i].split("=", 2);
			map.put(s2[0], s2[1]);
			if (!s2[0].equals("sign")) {
				sb.append(s2[0] + "=" + s2[1] + "&");
			}
		}
		String source = sb.substring(0, sb.length() - 1);
		map.put("source", source);
		return map;
	}

	public static String doPost(String url, String param) {
		PrintWriter out = null;
		BufferedReader in = null;
		String result = "";
		try {
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			URLConnection conn = realUrl.openConnection();
			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			out = new PrintWriter(conn.getOutputStream());
			// 发送请求参数
			out.print(param);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
			System.out.println("请求结果:" + result);
		} catch (Exception e) {
			System.out.println("发送 POST 请求出现异常！" + e);
			e.printStackTrace();
		}
		// 使用finally块来关闭输出流、输入流
		finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}
}
