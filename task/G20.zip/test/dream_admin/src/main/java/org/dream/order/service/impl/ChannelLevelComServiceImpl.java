package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.ChannelLevelComModel;
import org.dream.order.dao.ChannelLevelComDao;
import org.dream.order.service.ChannelLevelComService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChannelLevelComServiceImpl implements ChannelLevelComService {
	@Autowired
	ChannelLevelComDao channelLevelComDao;

	@Override
	public List<Map<String, Object>> getChannelLevel(int id) {

		return channelLevelComDao.getChannelLevel(id);
	}

	@Override
	public Map<String, Object> saveChannelLevelCom(ChannelLevelComModel channelLevelComModel, int userId,
			ChannelModel cm) {
		Map<String, Object> mapdata = new HashMap<String, Object>();
		int count = channelLevelComDao.getChannelLevelComByLevelIdAndVarietyId(channelLevelComModel.getLevelId(),
				channelLevelComModel.getVarietyId(), cm.getId());
		if (count > 0) {
			mapdata.put("retCode", "0");
			mapdata.put("retmsg", "该等级的品种佣金已存在");
			return mapdata;
		}
		channelLevelComModel.setCreateUserId(userId);
		channelLevelComModel.setChannelId(cm.getId());
		channelLevelComModel.setChannelName(cm.getName());
		channelLevelComDao.insertSelective(channelLevelComModel);
		mapdata.put("resCode", "1");
		return mapdata;
	}

	@Override
	public void updateChannelLevelCom(ChannelLevelComModel channelLevelComModel, int userId) {
		channelLevelComModel.setUpdateUserId(userId);
		channelLevelComDao.updateByPrimaryKeySelective(channelLevelComModel);
	}

	@Override
	public void removeChannelLevelCom(String id) {
		String[] ids = id.split(",");
		channelLevelComDao.removeByPrimaryKey(ids);

	}

	@Override
	public Page<ChannelLevelComModel> pagingQueryChannelLevelCom(Integer page, Integer pageSize, Integer levelId,
			Integer varietyId, String createTimeStart, String createTimeEnd, int channelId) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page ;
		Integer limit = page > 0 ? page  * pageSize : 0 * pageSize;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("limit", limit);
		map.put("pageSize", pageSize);
		map.put("levelId", levelId);
		map.put("varietyId", varietyId);
		map.put("createTimeStart", createTimeStart);
		map.put("createTimeEnd", createTimeEnd);
		map.put("channelId", channelId);
		List<ChannelLevelComModel> data = channelLevelComDao.pagingQueryChannelLevelCom(map);
		int totalCount = channelLevelComDao.pagingQueryChannelLevelComCount(map);
		Page<ChannelLevelComModel> pagelist = new Page<ChannelLevelComModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public ChannelLevelComModel getChannelLevelComById(Integer id) {

		return channelLevelComDao.selectByPrimaryKey(id);
	}

	@Override
	public ChannelLevelComModel getById(Integer id) {
		return channelLevelComDao.getById(id);
	}

}
