package org.dream.news.service;

import org.dream.model.news.NewsModel;
import org.dream.utils.mvc.Response;

public interface NewsService {
	public Response findNewsByPage(NewsModel newsModel, Integer page, Integer pageSize);

	public Response findNews(NewsModel newsModel);

	public Response saveNews(NewsModel newsModel);

	public Response updateNews(NewsModel newsModel);

	public Response deleteNews(String ids, Integer channelId);
}
