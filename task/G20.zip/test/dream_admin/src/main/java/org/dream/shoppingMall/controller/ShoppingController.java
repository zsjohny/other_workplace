package org.dream.shoppingMall.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.shoppingMall.ShoppingModel;
import org.dream.shoppingMall.service.ShoppingService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/shoppingMall")
public class ShoppingController extends BaseController {
	@Autowired
	private ShoppingService shoppingService;

	@RequestMapping("/findShoppingByPage")
	@ResponseBody
	public Response findShoppingByPage(ShoppingModel shoppingModel, Integer page, Integer pageSize,
			HttpServletRequest request) {
		Integer channelId = getDataId(request);
		shoppingModel.setChannelId(channelId);
		return shoppingService.findShoppingByPage(shoppingModel, page, pageSize);
	}
}
