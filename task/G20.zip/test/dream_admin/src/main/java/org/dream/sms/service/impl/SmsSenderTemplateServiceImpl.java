package org.dream.sms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.dream.model.sms.SmsSenderTemplate;
import org.dream.sms.dao.SmsSenderTemplateDao;
import org.dream.sms.service.SmsSenderTemplateService;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class SmsSenderTemplateServiceImpl implements SmsSenderTemplateService {

	@Resource(name = "senderTempalteChangendSender")
	JmsSender jmsSender;

	@Autowired
	SmsSenderTemplateDao smsSenderTemplateDao;

	public static final Integer SMS_ISDELETE = 1;// 表示未删除状态

	@Override
	public void addSenderTemplate(SmsSenderTemplate smsSenderTemplate) {
		smsSenderTemplateDao.createSenderTemplate(smsSenderTemplate);
		sendMsg(smsSenderTemplate);
	}

	@Override
	public void updateSenderTemplate(SmsSenderTemplate smsSenderTemplate) {
		smsSenderTemplateDao.updateSenderTemplate(smsSenderTemplate);
		SmsSenderTemplate senderTemplate = smsSenderTemplateDao.getSenderTemplate(smsSenderTemplate.getId());
		sendMsg(senderTemplate);

	}

	@Override
	public List<SmsSenderTemplate> getSenderTemplate(Integer channelId) {
		List<SmsSenderTemplate> smsSenderTemplates = smsSenderTemplateDao.getAll(SMS_ISDELETE, channelId, null);
		return smsSenderTemplates;
	}

	@Override
	public SmsSenderTemplate getById(Integer id) {
		SmsSenderTemplate smsSenderTemplate = smsSenderTemplateDao.getById(id, SMS_ISDELETE);
		return smsSenderTemplate;
	}

	@Override
	public Page<SmsSenderTemplate> pagingQuery(Integer templateId, Integer channelId, Integer type, Integer pageIndex,
			Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<SmsSenderTemplate> smsSenderTemplates = smsSenderTemplateDao.pagingQuery(templateId, SMS_ISDELETE,
				channelId, type, limit, pageSize);
		int totalCOunt = smsSenderTemplateDao.pagingQuery_count(templateId, SMS_ISDELETE, channelId, type);
		Page<SmsSenderTemplate> resultPage = new Page<SmsSenderTemplate>(pageIndex, pageSize, totalCOunt);
		resultPage.setData(smsSenderTemplates);
		return resultPage;
	}

	@Override
	public void remove(Integer id) {
		smsSenderTemplateDao.remove(id);
		SmsSenderTemplate smsSenderTemplate = smsSenderTemplateDao.getSenderTemplate(id);
		sendMsg(smsSenderTemplate);
	}

	/**
	 * 发送消息
	 * 
	 * @param senderTemplate
	 */
	private void sendMsg(SmsSenderTemplate senderTemplate) {
		jmsSender.sendMessage(JSON.toJSONString(senderTemplate));
	}

	public boolean hasSenderTemplate(Integer templateId, Integer channelId, Integer type) {
		return smsSenderTemplateDao.pagingQuery_count(templateId, SMS_ISDELETE, channelId, type) > 0;

	}

	@Override
	public SmsSenderTemplate findSenderTemplate(Integer templateId, Integer channelId, Integer type) {
		return smsSenderTemplateDao.findSenderTemplate(templateId, channelId, type);
	}
}
