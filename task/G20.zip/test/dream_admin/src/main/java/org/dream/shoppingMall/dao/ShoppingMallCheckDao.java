package org.dream.shoppingMall.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.shoppingMall.ShoppingModel;

public interface ShoppingMallCheckDao {
	
	public void checkShoppingByIds(Integer status,Integer channelId, @Param("ids") List<Integer> idList);
	
	public List<ShoppingModel> findByIds(Integer channelId,List<Integer> idList);

}
