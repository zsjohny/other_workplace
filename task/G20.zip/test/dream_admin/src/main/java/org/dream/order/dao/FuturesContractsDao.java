package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.FuturesContractsModel;

/**
 * 期货合约Dao
 * 
 *
 */
public interface FuturesContractsDao {

	public void createFuturesContracts(FuturesContractsModel contractsMoudel);

	public void updateFuturesContracts(FuturesContractsModel contractsMoudel);

	public Integer getVarietyIdByCode(@Param(value = "contractsCode") String contractsCode);

	public FuturesContractsModel getById(@Param(value = "id") Integer id);

	public List<FuturesContractsModel> getAll();

	public List<FuturesContractsModel> qureypaging(@Param(value = "exchangeName") String exchangeName,
			@Param(value = "varietyName") String varietyName, @Param(value = "status") Integer status,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "exchangeName") String exchangeName,
			@Param(value = "varietyName") String varietyName, @Param(value = "status") Integer status);

	/**
	 * 批量修改合约状态
	 * 
	 * @param statue
	 * @param ids
	 */
	public void changeStatusByIds(@Param(value = "status") Integer status, @Param(value = "ids") List<Integer> ids);
	
	
	public Integer qureypagingHasContractsCode(String contractsCode);
}
