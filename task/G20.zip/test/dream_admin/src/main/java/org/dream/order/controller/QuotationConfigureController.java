package org.dream.order.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.order.QuotationConfigureModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.QuotationConfigureService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 行情配置Controller
 * 
 * @author ZY
 *
 */
@Controller
@RequestMapping(value = "/quotationConfigure")
public class QuotationConfigureController extends BaseController {

	@Autowired
	QuotationConfigureService quotationConfigureService;

	@Autowired
	TradingVarietyService tradingVarietyService;

	/**
	 * 保存期货行情配置
	 * 
	 */
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	@ResponseBody
	public Response addQuotationConfigure(HttpServletRequest request, QuotationConfigureModel configureModel) {
		Integer varietyId = configureModel.getVarietyId();
		Assert.notNull(varietyId, "品种id不能为空");
		// 根据品种id查询表中是否存在该品种的行情配置
		Integer count = quotationConfigureService.getVarietyCount(varietyId);
		if (count > 0) {
			return Response.response(600, "该行情配置已存在");
		}
		TradingVarietyModel tradingVarietyModel = tradingVarietyService.getById(varietyId);
		configureModel.setVarietyId(varietyId);
		configureModel.setVarietyName(tradingVarietyModel.getVarietyName());
		configureModel.setVarietyCode(tradingVarietyModel.getVarietyType());
		configureModel.setExchangeId(tradingVarietyModel.getExchangeId());
		quotationConfigureService.saveQuotationConfigure(configureModel);

		return Response.success();
	}

	/**
	 * 修改行情配置
	 * 
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateQuotationConfigure(QuotationConfigureModel configureModel) {
		quotationConfigureService.updateQuotationConfigure(configureModel);
		return Response.success();
	}

	/**
	 * 多条删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteByIds", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteByIds(String ids) {
		quotationConfigureService.delteByIds(ids);
		return Response.success();
	}

	/**
	 * 根据id或者渠道id查询
	 */
	@RequestMapping(value = "/getBy", method = { RequestMethod.POST })
	@ResponseBody
	public Response getBy(Integer id) {
		QuotationConfigureModel configureModels = quotationConfigureService.getBy(id);
		return Response.success(configureModels);
	}

	/**
	 * 多条件查询
	 */
	@RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
	@ResponseBody
	public Response querypagingQuotationConfigure(HttpServletRequest request, Integer exchangeId, Integer page,
			Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<QuotationConfigureModel> resultPage = quotationConfigureService.querypaging(exchangeId, page, pageSize);
		return Response.success(resultPage);
	}
}
