package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceFlowController extends BaseController {
	@Autowired
	private FinanceService financeService;

	@RequestMapping("/findMoneyFlowByPage")
	@ResponseBody
	public Response findMoneyFlowByPage(String createTimeStart, String createTimeEnd, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, Integer type, Integer typeDetail, String remark,
			Integer page, Integer pageSize, String flow, HttpServletRequest request) {
		flow = "money";
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceFlowManageModel> list = financeService.findFlowByPage(id, level, createTimeStart, createTimeEnd,
				userId, userName, userPhone, channelId, topChannelId, type, typeDetail, remark, page, pageSize, flow);
		return Response.success(list);
	}

	@RequestMapping("/findScoreFlowByPage")
	@ResponseBody
	public Response findScoreFlowByPage(String createTimeStart, String createTimeEnd, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, Integer type, Integer typeDetail, String remark,
			Integer page, Integer pageSize, String flow, HttpServletRequest request) {
		flow = "score";
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<FinanceFlowManageModel> list = financeService.findFlowByPage(id, level, createTimeStart, createTimeEnd,
				userId, userName, userPhone, channelId, topChannelId, type, typeDetail, remark, page, pageSize, flow);
		return Response.success(list);
	}
}
