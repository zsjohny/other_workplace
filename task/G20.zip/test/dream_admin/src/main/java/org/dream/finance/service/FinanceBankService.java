package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceBankModel;
import org.dream.utils.mvc.Response;

public interface FinanceBankService {
	public List<FinanceBankModel> findBankAll();

	public Response saveBank(FinanceBankModel bankModel);

	public Response updateBank(FinanceBankModel bankModel);
}
