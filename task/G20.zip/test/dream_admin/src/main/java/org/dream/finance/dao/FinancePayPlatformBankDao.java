package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.model.finance.FinancePayPlatformModel;
import org.springframework.messaging.handler.annotation.Payload;

public interface FinancePayPlatformBankDao {
	// V2
	public FinancePayPlatformBankModel find(FinancePayPlatformBankModel payPlatformBankModel);

	public List<FinanceBankModel> findBankAll(FinanceCertModel certModel);

	public List<FinancePayPlatformModel> findPayPlatformAll(@Param("model") FinanceCertModel certModel,
			@Param("bankId") Integer bankId);

	// ********************************************************************************
	public List<FinancePayPlatformBankModel> findByPage(String payPlatform, Integer status, Integer offset,
			Integer pageSize);

	public Integer findRows(String payPlatform, Integer status);

	public void saveFinancePayPlatformBank(FinancePayPlatformBankModel payPlatformBankModel);

	public void updateFinancePayPlatformBank(FinancePayPlatformBankModel payPlatformBankModel);

	public void remoceFinancePayPlatformBank(@Param(value = "id") Integer id);

	public FinancePayPlatformBankModel getById(@Param(value = "id") Integer id);

	public List<FinancePayPlatformBankModel> querypaging(@Param(value = "bankName") String bankName,
			@Param(value = "payPlatform") String payPlatform, @Param(value = "status") Integer status,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer querypaging_count(@Param(value = "bankName") String bankName,
			@Param(value = "payPlatform") String payPlatform, @Param(value = "status") Integer status);

	public FinancePayPlatformBankModel check(FinancePayPlatformBankModel payPlatformBankModel);
}
