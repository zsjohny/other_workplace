package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dream.channel.dao.ChannelDao;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.VarietyAssetsModel;
import org.dream.order.dao.VarietyAssetsDao;
import org.dream.order.dao.VarietyPriceDao;
import org.dream.order.service.VarietyAssetsService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class VarietyAssetsServiceImpl implements VarietyAssetsService {

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;
	@Autowired
	VarietyAssetsDao varietyAssetsDao;

	@Autowired
	VarietyPriceDao varietyPriceDao;

	@Autowired
	ChannelDao channelDao;

	@Override
	public Map<String, Object> saveVarietyAssets(VarietyAssetsModel varietyAssetsModel) {
		Map<String, Object> mapdata = new HashMap<String, Object>();
		ChannelModel channelModel = channelDao.getById(varietyAssetsModel.getChannelId());
		// 新增前，需要先判断该用户属于哪个渠道，只有一级渠道才能进行维护
		// if (channelModel.getLevel() != 1) {
		// mapdata.put("resCode", "0");
		// mapdata.put("resMgs", "只有一级渠道才能新增配资");
		// return mapdata;
		// }
		// 首先判断这个品种，在相同渠道下是否已经有默认配资了
		// Integer count =
		// varietyAssetsDao.getVarietyAssetsCountByChannelAndVariety(varietyAssetsModel.getVarietyId(),
		// varietyAssetsModel.getChannelId());
		// if (count > 0) {
		// mapdata.put("resCode", "0");
		// mapdata.put("resMgs", "该品种的默认价格配置已存在");
		// return mapdata;
		// }
		varietyAssetsModel.setChannelName(channelModel.getName());
		varietyAssetsDao.insertSelective(varietyAssetsModel);
		//从数据库中查找数据
		List<VarietyAssetsModel> assets=varietyAssetsDao.getAssetsByVarietyIdAndChannelId(varietyAssetsModel.getVarietyId(), channelModel.getId());
		// 单纯的配资缓存
		redisTemplate.opsForHash().put(VarietyAssetsModel.ASSETS, varietyAssetsModel.getId(), varietyAssetsModel);
		redisTemplate.opsForHash().put(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS,
				channelModel.getId() + "_" + varietyAssetsModel.getVarietyId(), assets);
		
		mapdata.put("resCode", "1");
		mapdata.put("resMgs", "成功");
		return mapdata;
	}

	// @Override
	// public void updateVarietyAssets(VarietyAssetsModel varietyAssetsModel) {
	// varietyAssetsDao.updateByPrimaryKeySelective(varietyAssetsModel);
	//
	// }

	@Override
	public Map<String, Object> updateVarietyAssets(VarietyAssetsModel varietyAssetsModel, ChannelModel channelModel) {
		Map<String, Object> mapdata = new HashMap<String, Object>();
		varietyAssetsDao.updateByPrimaryKeySelective(varietyAssetsModel);
		// 首先得到redis缓存中的数据
		//从数据库中查找数据
		List<VarietyAssetsModel> assets=varietyAssetsDao.getAssetsByVarietyIdAndChannelId(varietyAssetsModel.getVarietyId(), channelModel.getId());
		redisTemplate.opsForHash().put(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS,
				channelModel.getId() + "_" + varietyAssetsModel.getVarietyId(), assets);
		redisTemplate.opsForHash().put(VarietyAssetsModel.ASSETS, varietyAssetsModel.getId(), varietyAssetsModel);
		mapdata.put("resCode", "1");
		mapdata.put("resMgs", "成功");
		return mapdata;
	}

	@Override
	public void removeVarietyAssets(String ids, Integer channelId) {
		List<Integer> idList = handleIds(ids);
		for (Integer id : idList) {
			// 根据配资id得到品种
			Integer varietyId = varietyAssetsDao.getVarietyIdByassetsId(id);
			varietyAssetsDao.removeVarietyAssets(id);
			redisTemplate.opsForHash().delete(VarietyAssetsModel.ASSETS, id);
			// 首先得到redis缓存中的数据
			redisTemplate.opsForHash().delete(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS, channelId + "_" + varietyId);
			List<VarietyAssetsModel> assets=varietyAssetsDao.getAssetsByVarietyIdAndChannelId(varietyId, channelId);
			if(assets !=null && assets.size() > 0){
				redisTemplate.opsForHash().put(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS, channelId + "_" + varietyId,
						assets);
			}
		}

	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public Page<VarietyAssetsModel> pagingQueryVarietyAssets(Integer page, Integer pageSize, Integer varietyId,
			String createTimeStart, String createTimeEnd, int channelId) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("limit", limit);
		map.put("pageSize", pageSize);
		map.put("varietyId", varietyId);
		map.put("channelId", channelId);
		map.put("createTimeStart", createTimeStart);
		map.put("createTimeEnd", createTimeEnd);
		List<VarietyAssetsModel> data = varietyAssetsDao.pagingQueryVarietyAssets(map);
		int totalCount = varietyAssetsDao.pagingQueryVarietyAssetsCount(map);
		Page<VarietyAssetsModel> pagelist = new Page<VarietyAssetsModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public VarietyAssetsModel getVarietyAssetsById(Integer id) {

		return varietyAssetsDao.selectByPrimaryKey(id);
	}

	@Override
	public Integer getVarietyAssetsCountByChannelAndVariety(Integer varietyId, Integer channelId, Integer id) {
		return varietyAssetsDao.getVarietyAssetsCountByChannelAndVariety(varietyId, channelId, id);
	}

}
