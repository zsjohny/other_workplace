package org.dream.news.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.dream.model.news.NewsModel;
import org.dream.news.dao.NewsDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
public class NewsDaoImpl implements NewsDao {
	private Logger logger = LoggerFactory.getLogger(NewsDao.class);
	private static final String NEWS = "dream_u_news";

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public List<NewsModel> findByPage(NewsModel newsModel, Integer offset, Integer pageSize) {
		Criteria criteria = new Criteria();
		Query query = new Query(criteria);
		if (newsModel.getChannelId() != null) {
			criteria = Criteria.where("channelId").is(newsModel.getChannelId());
			query.addCriteria(criteria);
		}
		if (newsModel.getTitle() != null) {
			criteria = Criteria.where("title").regex(".*?" + newsModel.getTitle() + ".*");
			query.addCriteria(criteria);
		}
		if (newsModel.getSummary() != null) {
			criteria = Criteria.where("summary").regex(".*?" + newsModel.getSummary() + ".*");
			query.addCriteria(criteria);
		}
		if (newsModel.getType() != null) {
			criteria = Criteria.where("type").is(newsModel.getType());
			query.addCriteria(criteria);
		}
		if (newsModel.getStyle() != null) {
			criteria = Criteria.where("style").is(newsModel.getStyle());
			query.addCriteria(criteria);
		}
		if (newsModel.getStatus() != null) {
			criteria = Criteria.where("status").is(newsModel.getStatus());
			query.addCriteria(criteria);
		}
		query.with(new Sort(Direction.DESC, "index"));
		query.skip(offset);
		query.limit(pageSize);
		logger.info("{}", query);
		return mongoTemplate.find(query, NewsModel.class, NEWS);
	}

	@Override
	public Integer findRows(NewsModel newsModel) {
		Criteria criteria = new Criteria();
		Query query = new Query(criteria);
		if (newsModel.getChannelId() != null) {
			criteria = Criteria.where("channelId").is(newsModel.getChannelId());
			query.addCriteria(criteria);
		}
		if (newsModel.getTitle() != null) {
			criteria = Criteria.where("title").regex(".*?" + newsModel.getTitle() + ".*");
			query.addCriteria(criteria);
		}
		if (newsModel.getSummary() != null) {
			criteria = Criteria.where("summary").regex(".*?" + newsModel.getSummary() + ".*");
			query.addCriteria(criteria);
		}
		if (newsModel.getType() != null) {
			criteria = Criteria.where("type").is(newsModel.getType());
			query.addCriteria(criteria);
		}
		if (newsModel.getStyle() != null) {
			criteria = Criteria.where("style").is(newsModel.getStyle());
			query.addCriteria(criteria);
		}
		if (newsModel.getStatus() != null) {
			criteria = Criteria.where("status").is(newsModel.getStatus());
			query.addCriteria(criteria);
		}
		return (int) mongoTemplate.count(query, NewsModel.class, NEWS);
	}

	@Override
	public NewsModel find(NewsModel newsModel) {
		Query query = new Query(Criteria.where("id").is(newsModel.getId()));
		return mongoTemplate.findOne(query, NewsModel.class, NEWS);
	}

	@Override
	public void save(NewsModel newsModel) {
		// newsModel.setStatus(0);
		Date date = new Date();
		newsModel.setCreateTime(date);
		newsModel.setUpdateTime(date);
		mongoTemplate.insert(newsModel, NEWS);
	}

	@Override
	public void update(NewsModel newsModel) {
		Update update = new Update();
		if (newsModel.getTitle() != null) {
			update.set("title", newsModel.getTitle());
		}
		if (newsModel.getSummary() != null) {
			update.set("summary", newsModel.getSummary());
		}
		if (newsModel.getType() != null) {
			update.set("type", newsModel.getType());
		}
		if (newsModel.getStyle() != null) {
			update.set("style", newsModel.getStyle());
		}
		if (newsModel.getContent() != null) {
			update.set("content", newsModel.getContent());
		}
		if (newsModel.getCover() != null) {
			update.set("cover", newsModel.getCover());
		}
		if (newsModel.getStatus() != null) {
			update.set("status", newsModel.getStatus());
		}
		if (newsModel.getOperator() != null) {
			update.set("operator", newsModel.getOperator());
		}
		if (newsModel.getIndex() != null) {
			update.set("index", newsModel.getIndex());
		}
		if (newsModel.getSource() != null) {
			update.set("source", newsModel.getSource());
		}
		update.set("updateTime", new Date());
		Query query = new Query(Criteria.where("id").is(newsModel.getId()));
		mongoTemplate.upsert(query, update, NewsModel.class, NEWS);
	}

	@Override
	public void delete(String ids, Integer channelId) {
		List<String> list = new ArrayList<>();
		Collections.addAll(list, ids.split(","));
		Criteria criteria = new Criteria();
		Query query = new Query(criteria);
		criteria = Criteria.where("id").in(list);
		query.addCriteria(criteria);
		criteria = Criteria.where("channelId").is(channelId);
		query.addCriteria(criteria);
		logger.info("{}", query);
		mongoTemplate.remove(query, NewsModel.class, NEWS);
	}

}
