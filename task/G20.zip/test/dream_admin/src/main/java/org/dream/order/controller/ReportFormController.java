package org.dream.order.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.OrderModel;
import org.dream.order.service.ReportFormService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 平台，一级，二级渠道的报表功能
 * 
 * @author ZY
 * @date 2016年10月13日
 */

@RequestMapping("/reportForm")
@Controller
public class ReportFormController extends BaseController {

	@Autowired
	ReportFormService reportFormService;

	// @RequestMapping(value = "/getExcel")
	@ResponseBody
	public Response getReportForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ChannelModel channelModel = super.getCurrentChannel(request);
		// 先获取上周的起始时间
		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.add(Calendar.DATE, -7);
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		java.util.Date sTime = calendar.getTime();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		java.util.Date eTime = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String orderTimeStart = sdf.format(sTime) + " 00:00:00";
		String orderTimeEnd = sdf.format(eTime) + " 23:59:59";
		String formTime = sdf.format(sTime) + "-" + sdf.format(eTime);
		/**
		 * 判断是哪个渠道要报表
		 */
		if (channelModel.getLevel() == 2) {
			// Map<String, Object> map =
			// reportFormService.countSecondChannelFees(25, null, null);
			Map<String, Object> map = reportFormService.countSecondChannelFees(channelModel.getId(), orderTimeStart,
					orderTimeEnd);// TODO加上时间&修改渠道id
			List<OrderModel> orderList = new ArrayList<OrderModel>();
			// if (map.get("list") == null) {
			// return Response.response(800, "上周报表为空");
			// }
			orderList = (List<OrderModel>) map.get("list");
			OrderModel orderTotal = (OrderModel) map.get("total");
			// 创建excel工作簿
			Workbook wb = new HSSFWorkbook();
			// 创建第一个sheet（页），并命名
			Sheet sheet = wb.createSheet(formTime);
			// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
			sheet.setColumnWidth(0, (int) (35.7 * 150));
			sheet.setColumnWidth(1, (int) (35.7 * 150));
			sheet.setColumnWidth(2, (int) (35.7 * 150));
			sheet.setColumnWidth(3, (int) (35.7 * 150));
			sheet.setColumnWidth(4, (int) (35.7 * 150));
			sheet.setColumnWidth(5, (int) (35.7 * 150));
			sheet.setColumnWidth(6, (int) (35.7 * 150));
			sheet.setColumnWidth(7, (int) (35.7 * 150));
			sheet.setColumnWidth(8, (int) (35.7 * 150));
			// 创建第一行
			Row row = sheet.createRow(0);

			// 创建两种单元格格式
			CellStyle cs = wb.createCellStyle();
			CellStyle cs2 = wb.createCellStyle();
			DataFormat df = wb.createDataFormat();
			// 创建两种字体
			Font f = wb.createFont();
			Font f2 = wb.createFont();
			// 创建第一种字体样式
			f.setFontHeightInPoints((short) 10);
			f.setColor(IndexedColors.RED.getIndex());
			f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			// 创建第二种字体样式
			f2.setFontHeightInPoints((short) 10);
			f2.setColor(IndexedColors.BLACK.getIndex());
			f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

			// 设置第一种单元格的样式
			cs.setFont(f);
			cs.setBorderLeft(CellStyle.BORDER_THIN);
			cs.setBorderRight(CellStyle.BORDER_THIN);
			cs.setBorderTop(CellStyle.BORDER_THIN);
			cs.setBorderBottom(CellStyle.BORDER_THIN);
			cs.setDataFormat(df.getFormat("#,##0.0"));
			// 设置第二种单元格的样式
			cs2.setFont(f2);
			cs2.setBorderLeft(CellStyle.BORDER_THIN);
			cs2.setBorderRight(CellStyle.BORDER_THIN);
			cs2.setBorderTop(CellStyle.BORDER_THIN);
			cs2.setBorderBottom(CellStyle.BORDER_THIN);
			cs2.setDataFormat(df.getFormat("text"));
			//
			Cell cell = row.createCell(0);
			cell.setCellValue("一级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(1);
			cell.setCellValue("二级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(2);
			cell.setCellValue("品种名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(3);
			cell.setCellValue("参与人数");
			cell.setCellStyle(cs2);
			cell = row.createCell(4);
			cell.setCellValue("手数");
			cell.setCellStyle(cs2);
			cell = row.createCell(5);
			cell.setCellValue("推广员佣金");
			cell.setCellStyle(cs2);
			cell = row.createCell(6);
			cell.setCellValue("一级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(7);
			cell.setCellValue("二级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(8);
			cell.setCellValue("用户手续费");
			cell.setCellStyle(cs2);
			if (orderList != null && orderList.size() > 0) {

				for (int i = 0; i < orderList.size(); i++) {
					OrderModel orderTemp = orderList.get(i);
					// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的创建一行，在页sheet上
					row = sheet.createRow(i + 1);
					// 在row行上创建一个方格
					addRowCell(row, cs2, orderTemp);
				}
				row = sheet.createRow(orderList.size() + 2);
				addRowCell(row, cs, orderTotal);
			}
			// 返回excel
			giveExcelBack(response, formTime, wb);
			return null;

		} else if (channelModel.getLevel() == 1) {
			List<Map<String, Object>> mapList = reportFormService.countFirstChannelFees(channelModel.getId(),
					orderTimeStart, orderTimeEnd);
			// List<Map<String, Object>> mapList =
			// reportFormService.countFirstChannelFees(12, null, null);
			// if (mapList == null) {
			// return Response.response(800, "上周报表为空");
			// }
			// 创建excel工作簿
			Workbook wb = new HSSFWorkbook();
			// 创建第一个sheet（页），并命名
			Sheet sheet = wb.createSheet(formTime);
			// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
			sheet.setColumnWidth(0, (int) (35.7 * 150));
			sheet.setColumnWidth(1, (int) (35.7 * 150));
			sheet.setColumnWidth(2, (int) (35.7 * 150));
			sheet.setColumnWidth(3, (int) (35.7 * 150));
			sheet.setColumnWidth(4, (int) (35.7 * 150));
			sheet.setColumnWidth(5, (int) (35.7 * 150));
			sheet.setColumnWidth(6, (int) (35.7 * 150));
			sheet.setColumnWidth(7, (int) (35.7 * 150));
			sheet.setColumnWidth(8, (int) (35.7 * 150));
			// 创建第一行
			Row row = sheet.createRow(0);

			// 创建两种单元格格式
			CellStyle cs = wb.createCellStyle();
			CellStyle cs2 = wb.createCellStyle();
			DataFormat df = wb.createDataFormat();
			// 创建两种字体
			Font f = wb.createFont();
			Font f2 = wb.createFont();
			// 创建第一种字体样式
			f.setFontHeightInPoints((short) 10);
			f.setColor(IndexedColors.RED.getIndex());
			f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			// 创建第二种字体样式
			f2.setFontHeightInPoints((short) 10);
			f2.setColor(IndexedColors.BLACK.getIndex());
			f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

			// 设置第一种单元格的样式
			cs.setFont(f);
			cs.setBorderLeft(CellStyle.BORDER_THIN);
			cs.setBorderRight(CellStyle.BORDER_THIN);
			cs.setBorderTop(CellStyle.BORDER_THIN);
			cs.setBorderBottom(CellStyle.BORDER_THIN);
			cs.setDataFormat(df.getFormat("#,##0.0"));
			// 设置第二种单元格的样式
			cs2.setFont(f2);
			cs2.setBorderLeft(CellStyle.BORDER_THIN);
			cs2.setBorderRight(CellStyle.BORDER_THIN);
			cs2.setBorderTop(CellStyle.BORDER_THIN);
			cs2.setBorderBottom(CellStyle.BORDER_THIN);
			cs2.setDataFormat(df.getFormat("text"));
			//
			Cell cell = row.createCell(0);
			cell.setCellValue("一级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(1);
			cell.setCellValue("二级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(2);
			cell.setCellValue("品种名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(3);
			cell.setCellValue("参与人数");
			cell.setCellStyle(cs2);
			cell = row.createCell(4);
			cell.setCellValue("手数");
			cell.setCellStyle(cs2);
			cell = row.createCell(5);
			cell.setCellValue("推广员佣金");
			cell.setCellStyle(cs2);
			cell = row.createCell(6);
			cell.setCellValue("一级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(7);
			cell.setCellValue("二级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(8);
			cell.setCellValue("用户手续费");
			cell.setCellStyle(cs2);
			// 再对list集合进行循环遍历。
			int rowCount = 0;// 行数
			if (mapList != null && mapList.size() > 0) {

				for (Map<String, Object> sMap : mapList) {
					List<OrderModel> ssOrderModels = (List<OrderModel>) sMap.get("list");
					for (OrderModel smallOrder : ssOrderModels) {
						// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的创建一行，在页sheet上
						row = sheet.createRow(rowCount + 1);
						addRowCell(row, cs2, smallOrder);
						rowCount++;
					}
					OrderModel smallOrderTotal = (OrderModel) sMap.get("total");
					row = sheet.createRow(rowCount + 2);
					addRowCell(row, cs, smallOrderTotal);
					rowCount += 3;
				}
			}
			giveExcelBack(response, formTime, wb);
			return null;
		} else if (channelModel.getLevel() == 0) {// 表示平台
			List<Map<String, Object>> mapList = reportFormService.countPlatformFees(orderTimeStart, orderTimeEnd);
			// if (mapList == null) {
			// return Response.response(800, "上周报表为空");
			// }
			// 创建excel工作簿
			Workbook wb = new HSSFWorkbook();
			// 创建第一个sheet（页），并命名
			Sheet sheet = wb.createSheet(formTime);
			// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
			sheet.setColumnWidth(0, (int) (35.7 * 150));
			sheet.setColumnWidth(1, (int) (35.7 * 150));
			sheet.setColumnWidth(2, (int) (35.7 * 150));
			sheet.setColumnWidth(3, (int) (35.7 * 150));
			sheet.setColumnWidth(4, (int) (35.7 * 150));
			sheet.setColumnWidth(5, (int) (35.7 * 150));
			sheet.setColumnWidth(6, (int) (35.7 * 150));
			sheet.setColumnWidth(7, (int) (35.7 * 150));
			sheet.setColumnWidth(8, (int) (35.7 * 150));
			// 创建第一行
			Row row = sheet.createRow(0);

			// 创建两种单元格格式
			CellStyle cs = wb.createCellStyle();
			CellStyle cs2 = wb.createCellStyle();
			DataFormat df = wb.createDataFormat();
			// 创建两种字体
			Font f = wb.createFont();
			Font f2 = wb.createFont();
			// 创建第一种字体样式
			f.setFontHeightInPoints((short) 10);
			f.setColor(IndexedColors.RED.getIndex());
			f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			// 创建第二种字体样式
			f2.setFontHeightInPoints((short) 10);
			f2.setColor(IndexedColors.BLACK.getIndex());
			f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

			// 设置第一种单元格的样式
			cs.setFont(f);
			cs.setBorderLeft(CellStyle.BORDER_THIN);
			cs.setBorderRight(CellStyle.BORDER_THIN);
			cs.setBorderTop(CellStyle.BORDER_THIN);
			cs.setBorderBottom(CellStyle.BORDER_THIN);
			cs.setDataFormat(df.getFormat("#,##0.0"));
			// 设置第二种单元格的样式
			cs2.setFont(f2);
			cs2.setBorderLeft(CellStyle.BORDER_THIN);
			cs2.setBorderRight(CellStyle.BORDER_THIN);
			cs2.setBorderTop(CellStyle.BORDER_THIN);
			cs2.setBorderBottom(CellStyle.BORDER_THIN);
			cs2.setDataFormat(df.getFormat("text"));
			//
			Cell cell = row.createCell(0);
			cell.setCellValue("一级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(1);
			cell.setCellValue("二级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(2);
			cell.setCellValue("品种名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(3);
			cell.setCellValue("参与人数");
			cell.setCellStyle(cs2);
			cell = row.createCell(4);
			cell.setCellValue("手数");
			cell.setCellStyle(cs2);
			cell = row.createCell(5);
			cell.setCellValue("推广员佣金");
			cell.setCellStyle(cs2);
			cell = row.createCell(6);
			cell.setCellValue("一级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(7);
			cell.setCellValue("二级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(8);
			cell.setCellValue("用户手续费");
			cell.setCellStyle(cs2);
			// 再对list集合进行循环遍历。
			int rowCount = 0;// 行数
			for (Map<String, Object> sMap : mapList) {
				List<OrderModel> ssOrderModels = (List<OrderModel>) sMap.get("list");
				for (OrderModel smallOrder : ssOrderModels) {
					// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的创建一行，在页sheet上
					row = sheet.createRow(rowCount + 1);
					addRowCell(row, cs2, smallOrder);
					rowCount++;
				}
				OrderModel smallOrderTotal = (OrderModel) sMap.get("total");
				row = sheet.createRow(rowCount + 2);
				addRowCell(row, cs, smallOrderTotal);
				rowCount += 3;
			}
			giveExcelBack(response, formTime, wb);
			return null;
		}

		return null;
	}

	/**
	 * 用本币做统计
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getExcel")
	@ResponseBody
	public Response getReportFormLocalUnit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ChannelModel channelModel = super.getCurrentChannel(request);
		// 先获取上周的起始时间
		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.add(Calendar.DATE, -7);
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		java.util.Date sTime = calendar.getTime();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		java.util.Date eTime = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String orderTimeStart = sdf.format(sTime) + " 00:00:00";
		String orderTimeEnd = sdf.format(eTime) + " 23:59:59";
		String formTime = sdf.format(sTime) + "-" + sdf.format(eTime);
		/**
		 * 判断是哪个渠道要报表
		 */
		if (channelModel.getLevel() == 2) {
			Map<String, Object> map = reportFormService.countSecondChannelFeesLocalUnit(channelModel.getId(),
					orderTimeStart, orderTimeEnd);
			List<OrderModel> orderList = new ArrayList<OrderModel>();
			orderList = (List<OrderModel>) map.get("list");
			// 创建excel工作簿
			Workbook wb = new HSSFWorkbook();
			// 创建第一个sheet（页），并命名
			Sheet sheet = wb.createSheet(formTime);
			// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
			sheet.setColumnWidth(0, (int) (35.7 * 150));
			sheet.setColumnWidth(1, (int) (35.7 * 150));
			sheet.setColumnWidth(2, (int) (35.7 * 150));
			sheet.setColumnWidth(3, (int) (35.7 * 150));
			sheet.setColumnWidth(4, (int) (35.7 * 150));
			sheet.setColumnWidth(5, (int) (35.7 * 150));
			sheet.setColumnWidth(6, (int) (35.7 * 150));
			sheet.setColumnWidth(7, (int) (35.7 * 150));
			sheet.setColumnWidth(8, (int) (35.7 * 150));
			// 创建第一行
			Row row = sheet.createRow(0);

			// 创建两种单元格格式
			CellStyle cs = wb.createCellStyle();
			CellStyle cs2 = wb.createCellStyle();
			DataFormat df = wb.createDataFormat();
			// 创建两种字体
			Font f = wb.createFont();
			Font f2 = wb.createFont();
			// 创建第一种字体样式
			f.setFontHeightInPoints((short) 10);
			f.setColor(IndexedColors.RED.getIndex());
			f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			// 创建第二种字体样式
			f2.setFontHeightInPoints((short) 10);
			f2.setColor(IndexedColors.BLACK.getIndex());
			f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

			// 设置第一种单元格的样式
			cs.setFont(f);
			cs.setBorderLeft(CellStyle.BORDER_THIN);
			cs.setBorderRight(CellStyle.BORDER_THIN);
			cs.setBorderTop(CellStyle.BORDER_THIN);
			cs.setBorderBottom(CellStyle.BORDER_THIN);
			cs.setDataFormat(df.getFormat("#,##0.0"));
			// 设置第二种单元格的样式
			cs2.setFont(f2);
			cs2.setBorderLeft(CellStyle.BORDER_THIN);
			cs2.setBorderRight(CellStyle.BORDER_THIN);
			cs2.setBorderTop(CellStyle.BORDER_THIN);
			cs2.setBorderBottom(CellStyle.BORDER_THIN);
			cs2.setDataFormat(df.getFormat("text"));
			//
			Cell cell = row.createCell(0);
			cell.setCellValue("一级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(1);
			cell.setCellValue("二级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(2);
			cell.setCellValue("品种名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(3);
			cell.setCellValue("参与人数");
			cell.setCellStyle(cs2);
			cell = row.createCell(4);
			cell.setCellValue("手数");
			cell.setCellStyle(cs2);
			cell = row.createCell(5);
			cell.setCellValue("推广员佣金");
			cell.setCellStyle(cs2);
			cell = row.createCell(6);
			cell.setCellValue("一级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(7);
			cell.setCellValue("二级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(8);
			cell.setCellValue("用户手续费");
			cell.setCellStyle(cs2);
			if (orderList != null && orderList.size() > 0) {

				for (int i = 0; i < orderList.size(); i++) {
					OrderModel orderTemp = orderList.get(i);
					// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的创建一行，在页sheet上
					row = sheet.createRow(i + 1);
					// 在row行上创建一个方格
					addRowCell(row, cs2, orderTemp);
				}
				row = sheet.createRow(orderList.size() + 2);
			}
			// 返回excel
			giveExcelBack(response, formTime, wb);
			return null;

		} else if (channelModel.getLevel() == 1) {
			List<Map<String, Object>> mapList = reportFormService.countFirstChannelFeesLocalUnit(channelModel.getId(),
					orderTimeStart, orderTimeEnd);
			// 创建excel工作簿
			Workbook wb = new HSSFWorkbook();
			// 创建第一个sheet（页），并命名
			Sheet sheet = wb.createSheet(formTime);
			// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
			sheet.setColumnWidth(0, (int) (35.7 * 150));
			sheet.setColumnWidth(1, (int) (35.7 * 150));
			sheet.setColumnWidth(2, (int) (35.7 * 150));
			sheet.setColumnWidth(3, (int) (35.7 * 150));
			sheet.setColumnWidth(4, (int) (35.7 * 150));
			sheet.setColumnWidth(5, (int) (35.7 * 150));
			sheet.setColumnWidth(6, (int) (35.7 * 150));
			sheet.setColumnWidth(7, (int) (35.7 * 150));
			sheet.setColumnWidth(8, (int) (35.7 * 150));
			// 创建第一行
			Row row = sheet.createRow(0);

			// 创建两种单元格格式
			CellStyle cs = wb.createCellStyle();
			CellStyle cs2 = wb.createCellStyle();
			DataFormat df = wb.createDataFormat();
			// 创建两种字体
			Font f = wb.createFont();
			Font f2 = wb.createFont();
			// 创建第一种字体样式
			f.setFontHeightInPoints((short) 10);
			f.setColor(IndexedColors.RED.getIndex());
			f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			// 创建第二种字体样式
			f2.setFontHeightInPoints((short) 10);
			f2.setColor(IndexedColors.BLACK.getIndex());
			f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

			// 设置第一种单元格的样式
			cs.setFont(f);
			cs.setBorderLeft(CellStyle.BORDER_THIN);
			cs.setBorderRight(CellStyle.BORDER_THIN);
			cs.setBorderTop(CellStyle.BORDER_THIN);
			cs.setBorderBottom(CellStyle.BORDER_THIN);
			cs.setDataFormat(df.getFormat("#,##0.0"));
			// 设置第二种单元格的样式
			cs2.setFont(f2);
			cs2.setBorderLeft(CellStyle.BORDER_THIN);
			cs2.setBorderRight(CellStyle.BORDER_THIN);
			cs2.setBorderTop(CellStyle.BORDER_THIN);
			cs2.setBorderBottom(CellStyle.BORDER_THIN);
			cs2.setDataFormat(df.getFormat("text"));
			//
			Cell cell = row.createCell(0);
			cell.setCellValue("一级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(1);
			cell.setCellValue("二级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(2);
			cell.setCellValue("品种名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(3);
			cell.setCellValue("参与人数");
			cell.setCellStyle(cs2);
			cell = row.createCell(4);
			cell.setCellValue("手数");
			cell.setCellStyle(cs2);
			cell = row.createCell(5);
			cell.setCellValue("推广员佣金");
			cell.setCellStyle(cs2);
			cell = row.createCell(6);
			cell.setCellValue("一级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(7);
			cell.setCellValue("二级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(8);
			cell.setCellValue("用户手续费");
			cell.setCellStyle(cs2);
			// 再对list集合进行循环遍历。
			int rowCount = 0;// 行数
			if (mapList != null && mapList.size() > 0) {

				for (Map<String, Object> sMap : mapList) {
					List<OrderModel> ssOrderModels = (List<OrderModel>) sMap.get("list");
					if (ssOrderModels != null && ssOrderModels.size() > 0) {
						for (OrderModel smallOrder : ssOrderModels) {
							// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的创建一行，在页sheet上
							row = sheet.createRow(rowCount + 1);
							addRowCell(row, cs2, smallOrder);
							rowCount++;
						}
						rowCount += 3;
					}
				}
			}
			giveExcelBack(response, formTime, wb);
			return null;
		} else if (channelModel.getLevel() == 0) {// 表示平台
			List<Map<String, Object>> mapList = reportFormService.countPlatformFeesLocalUnit(orderTimeStart,
					orderTimeEnd);
			// 创建excel工作簿
			Workbook wb = new HSSFWorkbook();
			// 创建第一个sheet（页），并命名
			Sheet sheet = wb.createSheet(formTime);
			// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
			sheet.setColumnWidth(0, (int) (35.7 * 150));
			sheet.setColumnWidth(1, (int) (35.7 * 150));
			sheet.setColumnWidth(2, (int) (35.7 * 150));
			sheet.setColumnWidth(3, (int) (35.7 * 150));
			sheet.setColumnWidth(4, (int) (35.7 * 150));
			sheet.setColumnWidth(5, (int) (35.7 * 150));
			sheet.setColumnWidth(6, (int) (35.7 * 150));
			sheet.setColumnWidth(7, (int) (35.7 * 150));
			sheet.setColumnWidth(8, (int) (35.7 * 150));
			// 创建第一行
			Row row = sheet.createRow(0);

			// 创建两种单元格格式
			CellStyle cs = wb.createCellStyle();
			CellStyle cs2 = wb.createCellStyle();
			DataFormat df = wb.createDataFormat();
			// 创建两种字体
			Font f = wb.createFont();
			Font f2 = wb.createFont();
			// 创建第一种字体样式
			f.setFontHeightInPoints((short) 10);
			f.setColor(IndexedColors.RED.getIndex());
			f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			// 创建第二种字体样式
			f2.setFontHeightInPoints((short) 10);
			f2.setColor(IndexedColors.BLACK.getIndex());
			f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

			// 设置第一种单元格的样式
			cs.setFont(f);
			cs.setBorderLeft(CellStyle.BORDER_THIN);
			cs.setBorderRight(CellStyle.BORDER_THIN);
			cs.setBorderTop(CellStyle.BORDER_THIN);
			cs.setBorderBottom(CellStyle.BORDER_THIN);
			cs.setDataFormat(df.getFormat("#,##0.0"));
			// 设置第二种单元格的样式
			cs2.setFont(f2);
			cs2.setBorderLeft(CellStyle.BORDER_THIN);
			cs2.setBorderRight(CellStyle.BORDER_THIN);
			cs2.setBorderTop(CellStyle.BORDER_THIN);
			cs2.setBorderBottom(CellStyle.BORDER_THIN);
			cs2.setDataFormat(df.getFormat("text"));
			//
			Cell cell = row.createCell(0);
			cell.setCellValue("一级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(1);
			cell.setCellValue("二级渠道名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(2);
			cell.setCellValue("品种名称");
			cell.setCellStyle(cs2);
			cell = row.createCell(3);
			cell.setCellValue("参与人数");
			cell.setCellStyle(cs2);
			cell = row.createCell(4);
			cell.setCellValue("手数");
			cell.setCellStyle(cs2);
			cell = row.createCell(5);
			cell.setCellValue("推广员佣金");
			cell.setCellStyle(cs2);
			cell = row.createCell(6);
			cell.setCellValue("一级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(7);
			cell.setCellValue("二级渠道手续费");
			cell.setCellStyle(cs2);
			cell = row.createCell(8);
			cell.setCellValue("用户手续费");
			cell.setCellStyle(cs2);
			// 再对list集合进行循环遍历。
			int rowCount = 0;// 行数
			for (Map<String, Object> sMap : mapList) {
				List<OrderModel> ssOrderModels = (List<OrderModel>) sMap.get("list");
				if (ssOrderModels != null && ssOrderModels.size() > 0) {
					for (OrderModel smallOrder : ssOrderModels) {
						// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的创建一行，在页sheet上
						row = sheet.createRow(rowCount + 1);
						addRowCell(row, cs2, smallOrder);
						rowCount++;
					}
					rowCount += 3;
				}
			}
			giveExcelBack(response, formTime, wb);
			return null;
		}

		return null;
	}

	/**
	 * @param response
	 * @param formTime
	 * @param wb
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	private void giveExcelBack(HttpServletResponse response, String formTime, Workbook wb)
			throws UnsupportedEncodingException, IOException {
		ByteArrayOutputStream os = new ByteArrayOutputStream();

		try {
			wb.write(os);
		} catch (IOException e) {
			e.printStackTrace();
		}

		byte[] content = os.toByteArray();
		InputStream is = new ByteArrayInputStream(content);

		// 设置response参数，可以打开下载页面
		response.reset();
		response.setContentType("application/vnd.ms-excel;charset=utf-8");
		response.setHeader("Content-Disposition",
				"attachment;filename=" + new String((formTime + ".xls").getBytes(), "iso-8859-1"));

		ServletOutputStream out = response.getOutputStream();

		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;

		try {

			bis = new BufferedInputStream(is);
			bos = new BufferedOutputStream(out);

			byte[] buff = new byte[2048];
			int bytesRead;

			// Simple read/write loop.
			while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
				bos.write(buff, 0, bytesRead);
			}

		} catch (final IOException e) {
			throw e;
		} finally {
			if (bis != null)
				bis.close();
			if (bos != null)
				bos.close();
		}
	}

	/**
	 * @param row
	 * @param cs2
	 * @param orderTemp
	 */
	private void addRowCell(Row row, CellStyle cs2, OrderModel orderTemp) {
		Cell cell;
		cell = row.createCell(0);
		if (orderTemp.getOneChannelName() != null) {
			cell.setCellValue(orderTemp.getOneChannelName());
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(1);
		if (orderTemp.getChannelName() != null) {
			cell.setCellValue(orderTemp.getChannelName());
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(2);
		if (orderTemp.getVarietyName() != null) {
			cell.setCellValue(orderTemp.getVarietyName());
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(3);
		if (orderTemp.getUserCount() != null) {
			cell.setCellValue(orderTemp.getUserCount());
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(4);
		if (orderTemp.getHandsCount() != null) {
			cell.setCellValue(orderTemp.getHandsCount());
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(5);
		if (orderTemp.getTotalPromoteCom() != null) {
			cell.setCellValue(orderTemp.getTotalPromoteCom() + "(" + orderTemp.getSign() + ")");
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(6);
		if (orderTemp.getTotalOneChannelFees() != null) {
			cell.setCellValue(orderTemp.getTotalOneChannelFees() + "(" + orderTemp.getSign() + ")");
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(7);
		if (orderTemp.getTotalChannelFees() != null) {
			cell.setCellValue(orderTemp.getTotalChannelFees() + "(" + orderTemp.getSign() + ")");
		}
		cell.setCellStyle(cs2);
		cell = row.createCell(8);
		if (orderTemp.getTotalUserFees() != null) {
			cell.setCellValue(orderTemp.getTotalUserFees() + "(" + orderTemp.getSign() + ")");
		}
		cell.setCellStyle(cs2);
	}

}
