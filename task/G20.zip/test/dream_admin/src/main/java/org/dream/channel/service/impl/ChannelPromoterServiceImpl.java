package org.dream.channel.service.impl;

import java.util.List;

import org.dream.channel.dao.ChannelPromoterDao;
import org.dream.channel.service.ChannelPromoterService;
import org.dream.model.channel.ChannelPromoterModel;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChannelPromoterServiceImpl implements ChannelPromoterService {
	@Autowired
	private ChannelPromoterDao channelPromoterDao;

	@Override
	public List<ChannelPromoterModel> findChannelPromoterAll() {
		return channelPromoterDao.findChannelPromoterAll();
	}

	@Override
	public Page<ChannelPromoterModel> querypaging(Integer channelId, Integer levelId, Integer pageIndex,
			Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<ChannelPromoterModel> channelPromoterModels = channelPromoterDao.qureypaging(channelId, levelId, limit,
				pageSize);
		Integer totalCount = channelPromoterDao.qureypaging_count(channelId, levelId);

		Page<ChannelPromoterModel> resultPage = new Page<ChannelPromoterModel>(pageIndex, pageSize, totalCount);
		resultPage.setData(channelPromoterModels);
		return resultPage;
	}

	@Override
	public void updateChannelPromoter(ChannelPromoterModel channelPromoterModel) {
		channelPromoterDao.updateChannelPromoter(channelPromoterModel);
	}

	@Override
	public Page<ChannelPromoterModel> qureypagingSonUser(Integer promoterId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<ChannelPromoterModel> channelPromoterModels = channelPromoterDao.qureypagingSonUser(promoterId, limit,
				pageSize);
		if (channelPromoterModels != null && channelPromoterModels.size() > 0) {
			for (ChannelPromoterModel cpm : channelPromoterModels) {
				Integer handsNum = channelPromoterDao.getTotalHandsNumByUserId(cpm.getUserId());
				cpm.setTotalHandsNum(handsNum);
			}
		}
		Integer totalCount = channelPromoterDao.qureypagingSonUser_count(promoterId);
		Page<ChannelPromoterModel> resultPage = new Page<ChannelPromoterModel>(pageIndex, pageSize, totalCount);
		resultPage.setData(channelPromoterModels);
		return resultPage;
	}

	@Override
	public Integer getPromoterIdByUserId(Integer userId) {
		return channelPromoterDao.getPromoterIdByUserId(userId);
	}

}
