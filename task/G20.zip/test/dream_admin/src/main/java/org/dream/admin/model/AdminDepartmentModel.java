package org.dream.admin.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * 部门
 * @author wangd
 *
 */
/**
 * @author wangd
 *
 */
public class AdminDepartmentModel implements Serializable{
    
    private static final long serialVersionUID = -2439169013961272254L;
    private Integer id;
    /**
     * 部门编码
     */
    private String sn;
    /**
     * 部门全名
     */
    private String fullName;
    /**
     * 部门简称
     */
    private String shortName;
    /**
     * 创建时间
     */
    private Timestamp createDate;
    /**
     * 撤销时间
     */
    private Timestamp terminateDate;
    /**
     * 描述
     */
    private String description;
    /**
     * 上级部门
     */
    private Integer parentDeparment;
    /**
     * 层级编码
     * 如第一层 ： 1，第二层：2
     */
    private Integer levelCode = 1;
    
    /**
     * 是否是顶级部门
     * true： 是；false：否
     */
    private boolean topDeparment = false;
    
    /**
     * 部门内相对顺序
     */
    private int position;
    
    private int dataId;
    
    /**
     * 子部门
     */
    private List<AdminDepartmentModel> childDepartments;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn;
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getShortName() {
        return shortName;
    }
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }
    public Timestamp getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
    public Timestamp getTerminateDate() {
        return terminateDate;
    }
    public void setTerminateDate(Timestamp terminateDate) {
        this.terminateDate = terminateDate;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Integer getParentDeparment() {
        return parentDeparment;
    }
    public void setParentDeparment(Integer parentDeparment) {
        this.parentDeparment = parentDeparment;
    }
    public Integer getLevelCode() {
        return levelCode;
    }
    public void setLevelCode(Integer levelCode) {
        this.levelCode = levelCode;
    }
    public boolean isTopDeparment() {
        return topDeparment;
    }
    public void setTopDeparment(boolean topDeparment) {
        this.topDeparment = topDeparment;
    }
    public int getPosition() {
        return position;
    }
    public void setPosition(int position) {
        this.position = position;
    }
    public List<AdminDepartmentModel> getChildDepartments() {
        return childDepartments;
    }
    public void setChildDepartments(List<AdminDepartmentModel> childDepartments) {
        this.childDepartments = childDepartments;
    }
	public int getDataId() {
		return dataId;
	}
	public void setDataId(int dataId) {
		this.dataId = dataId;
	}
    
}
