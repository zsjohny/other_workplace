package org.dream.admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminMenuResourceModel;
import org.dream.admin.model.AdminPageElementResourceModel;
import org.dream.admin.model.AdminRoleModel;
import org.dream.admin.service.AdminMenuResouceService;
import org.dream.admin.service.AdminPageElementResourceService;
import org.dream.admin.service.AdminRoleService;
import org.dream.admin.service.AdminUrlAccessResourceService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * @author SUNDONG_
 *
 */

@Controller
@RequestMapping("/role")
public class AdminRoleController extends BaseController {
	@Autowired
	AdminRoleService adminRoleService;

	@Autowired
	AdminUrlAccessResourceService adminUrlAccessResourceService;

	@Autowired
	AdminMenuResouceService adminMenuResouceService;

	@Autowired
	AdminPageElementResourceService adminPageElementResourceService;

	/**
	 * 角色保存
	 * 
	 * @param name
	 * @param description
	 * @return
	 */
	@RequestMapping(value = "/addRole", method = { RequestMethod.POST })
	@ResponseBody
	public Response addRole(String name, String description, HttpServletRequest request) {
		AdminRoleModel roleModel = new AdminRoleModel();
		if(StringUtils.isBlank(name)){
			return Response.error("添加角色名称不能为空");
		}
		roleModel.setName(name);
		roleModel.setDescription(description);
		roleModel.setDataId(super.getDataId(request));
		roleModel.setType(super.getCurrentChannel(request).getLevel());
		roleModel.setIsAdmin(0);
		adminRoleService.createAdminRole(roleModel);
		return Response.success();
	}

	/**
	 * 多条件查询角色
	 * 
	 * @param page
	 * @param pageSize
	 * @param name
	 * @param description
	 * @return
	 */
	@RequestMapping(value = "/pagingQuery", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQuery(Integer page, Integer pageSize, String name, String description,
			HttpServletRequest request) {

		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Map<String, Object> param = new HashMap<String, Object>();
		if (name != null) {
			param.put("name", "%" + name + "%");
		}
		if (description != null) {
			param.put("description", "%" + description + "%");
		}
		param.put("category", AdminRoleModel.CATEGORY);
		Page<AdminRoleModel> data = adminRoleService.pagingQueryPermissions(name, description, AdminRoleModel.CATEGORY,
				super.getDataId(request), page, pageSize);
		return Response.success(data);
	}

	/**
	 * 角色修改
	 * 
	 * @param id
	 * @param name
	 * @param description
	 * @return
	 */
	@RequestMapping(value = "/updateRole", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateRole(Integer id, String name, String description) {
		Assert.notNull(id, "角色id不能为空");
		Assert.notNull(name, "角色名称不能为空");

		AdminRoleModel roleModel = new AdminRoleModel();
		roleModel.setId(id);
		roleModel.setName(name);
		roleModel.setDescription(description);

		adminRoleService.updateAdminRole(roleModel);
		return Response.success();
	}

	/**
	 * 删除多条角色和该角色相关的关系数据纪录如：角色权限关系数据、角色URL资源权限数据
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteRoles", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteRoles(String ids) {

		Assert.notNull(ids, "要删除的角色Id不能为空");
		List<Integer> roleIds = new ArrayList<Integer>();
		String temp[] = ids.split(",");
		for (int i = 0; i < temp.length; i++) {
			roleIds.add(Integer.valueOf(temp[i]));
		}
		List<AdminRoleModel> nodelete = adminRoleService.deleteRoles(roleIds);

		return Response.success(nodelete);
	}

	/**
	 * 为角色删除分配的URL访问权限资源
	 * 
	 * @param roleId
	 * @param urlAccessResourceIds
	 *            要删除的权限资源Id（不是分配纪录的Id）
	 * @return
	 */
	@RequestMapping(value = "/terminateUrlAccessResourcesFromRole", method = { RequestMethod.POST })
	@ResponseBody
	public Response terminateUrlAccessResourcesFromRole(Integer roleId, String urlAccessResourceIds,
			HttpServletRequest request) {

		Assert.notNull(roleId, "角色Id不能为空");
		Assert.notNull(urlAccessResourceIds, "要删除的资源权限Id不能为空");

		String[] urlIds = urlAccessResourceIds.split(",");
		List<Integer> urlAccessResourceIdList = new ArrayList<Integer>();
		for (int i = 0; i < urlIds.length; i++) {
			urlAccessResourceIdList.add(Integer.valueOf(urlIds[i]));
		}

		adminUrlAccessResourceService.terminateUrlAccessResourcesFromRole(roleId, urlAccessResourceIdList,
				super.getDataId(request));
		;
		return Response.success();
	}

	/**
	 * 跟据角色Id获得为该角色已授权的菜单资源数据 <strong>菜单数据是包含子菜单的，注意菜单的层级关系数据
	 * 
	 * </strong>
	 * 
	 * @param roleId
	 * @param urlAccessResourceIds
	 * @return
	 */
	@RequestMapping(value = "/findMenuResourceTreeSelectItemByRoleId", method = { RequestMethod.POST })
	@ResponseBody
	public Response findMenuResourceTreeSelectItemByRoleId(Integer roleId, HttpServletRequest request) {
		List<AdminMenuResourceModel> allMenuResources = adminMenuResouceService
				.findMenuResourceTreeSelectItemByRoleId(roleId, super.getDataId(request));
		return Response.success(allMenuResources);
	}

	/**
	 * 根据角色ID获得未分配给该角色的页面元素资源
	 * 
	 * @param page
	 * @param pageSize
	 * @param roleId
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryNotGrantPageElementResourcesByRoleId", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryNotGrantPageElementResourcesByRoleId(String name, String description, String identifier,
			Integer page, Integer pageSize, Integer roleId, HttpServletRequest request) {

		Assert.notNull(roleId, "角色Id不能为空");
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<AdminPageElementResourceModel> data = adminPageElementResourceService
				.pagingQueryNotGrantPageElementsByRoleId(name, description, identifier, roleId,
						super.getDataId(request), page, pageSize);
		return Response.success(data);
	}

	/**
	 * 根据角色id 和数据类型获取各自所有的菜单 页面元素与url访问地址(平台或者各个渠道 0表示平台 1表示一级渠道 2表示二级渠道)
	 * 
	 * @param roleId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getAllMenuPageUrl")
	@ResponseBody
	public Response getAllMenuPageUrl(Integer roleId, HttpServletRequest request) {
		Integer type = super.getCurrentChannel(request).getLevel();
		return Response.success(adminMenuResouceService.getAllMenuPageUrl(roleId, super.getDataId(request), type));
	}

	/**
	 * 根据角色id、权限资源id、数据类型获取角色下的用户列表<strong>因为权限资源来自于同一张表其id是唯一的</strong>
	 * 
	 * @param roleId
	 *            角色id
	 * @param securityResourceIds
	 *            权限资源id
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/grantResourcesToRole", method = { RequestMethod.POST })
	@ResponseBody
	public Response grantResourcesToRole(Integer roleId, String securityResourceIds, HttpServletRequest request) {
		Assert.notNull(roleId, "角色id不能为空");
		Integer dataId = super.getDataId(request);
		if (securityResourceIds.equals("")) {
			adminMenuResouceService.deleteAdminResourceAssignmentsByAuthorityId(roleId);
		} else {
			String[] ids = securityResourceIds.split(",");
			List<Integer> securityResourceList = new ArrayList<Integer>();
			for (int i = 0; i < ids.length; i++) {
				securityResourceList.add(Integer.valueOf(ids[i]));
			}
			adminMenuResouceService.saveMenuPageUrlToRole(roleId, securityResourceList, dataId);
		}
		return Response.success();

	}

	// *******************************************************************************************************

	/**
	 * 查询平台渠道下的角色列表
	 * 
	 * @param page
	 * @param pageSize
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryChannelRoles")
	@ResponseBody
	public Response pagingQueryChannelRoles(Integer page, Integer pageSize, HttpServletRequest request) {
		return Response.success(adminRoleService.pagingQueryChannelRoles(super.getDataId(request),
				super.getCurrentChannel(request).getLevel(), page, pageSize));

	}
	
	/**
	 * 获取 当前一级渠道的所有角色  
	 * ZY需要
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/findRoles")
	@ResponseBody
	public Response findRoles(HttpServletRequest request){
		return Response.success(adminRoleService.findRoles(super.getDataId(request)));
		
	}
}
