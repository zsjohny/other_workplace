package org.dream.news.service.impl;

import java.util.List;

import org.dream.model.news.NewsModel;
import org.dream.news.dao.NewsDao;
import org.dream.news.service.NewsService;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NewsServiceImpl implements NewsService {
	public static final Integer SUCCESS_CODE = 200;
	public static final Integer ERROR_CODE = 600;
	@Autowired
	private NewsDao newsDao;

	@Override
	public Response findNewsByPage(NewsModel newsModel, Integer page, Integer pageSize) {
		Integer offset = page > 0 ? page * pageSize : 0;
		List<NewsModel> list = newsDao.findByPage(newsModel, offset, pageSize);
		Integer rows = newsDao.findRows(newsModel);
		Page<NewsModel> newsPage = new Page<>(page, pageSize, rows);
		newsPage.setData(list);
		return Response.response(SUCCESS_CODE, "查询资讯列表成功", newsPage);
	}

	@Override
	public Response findNews(NewsModel newsModel) {
		NewsModel model = newsDao.find(newsModel);
		if (model == null) {
			return Response.response(ERROR_CODE, "查询资讯失败");
		}
		return Response.response(SUCCESS_CODE, "查询资讯成功", model);
	}

	@Override
	public Response saveNews(NewsModel newsModel) {
		if (newsModel.getType() == 0 && newsModel.getCover() == null) {
			return Response.response(ResponseCode.ERROR_CODE, "资讯封面不能为空");
		}
		newsDao.save(newsModel);
		return Response.response(SUCCESS_CODE, "保存资讯成功");
	}

	@Override
	public Response updateNews(NewsModel newsModel) {
		newsDao.update(newsModel);
		return Response.response(SUCCESS_CODE, "更新资讯成功");
	}

	@Override
	public Response deleteNews(String ids, Integer channelId) {
		newsDao.delete(ids, channelId);
		return Response.response(SUCCESS_CODE, "删除资讯成功");
	}
}
