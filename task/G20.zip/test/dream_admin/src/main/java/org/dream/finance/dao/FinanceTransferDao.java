package org.dream.finance.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.model.finance.FinanceTransferModel;

public interface FinanceTransferDao {
	public void save(List<FinanceTransferModel> list);

	public List<FinanceTransferManageModel> findByPage(@Param("userId") Integer userId,
			@Param("userName") String userName, @Param("userPhone") String userPhone,
			@Param("realName") String realName, @Param("transferType") String transferType,
			@Param("status") Integer status, @Param("operator") String operator,
			@Param("createTimeStart") String createTimeStart, @Param("createTimeEnd") String createTimeEnd,
			@Param("updateTimeStart") String updateTimeStart, @Param("updateTimeEnd") String updateTimeEnd,
			@Param("topChannelId") Integer topChannelId, @Param("offset") Integer offset,
			@Param("pageSize") Integer pageSize);

	public Integer findRows(@Param("userId") Integer userId, @Param("userName") String userName,
			@Param("userPhone") String userPhone, @Param("realName") String realName,
			@Param("transferType") String transferType, @Param("status") Integer status,
			@Param("operator") String operator, @Param("createTimeStart") String createTimeStart,
			@Param("createTimeEnd") String createTimeEnd, @Param("updateTimeStart") String updateTimeStart,
			@Param("updateTimeEnd") String updateTimeEnd, @Param("topChannelId") Integer topChannelId);

	public FinanceTransferManageModel find(@Param("topChannelId") Integer topChannelId,
			@Param("transferId") Integer transferId);

	public void update(FinanceTransferModel transferModel);

	public List<Map<String, Object>> findTransferParam(@Param("status") Integer status,
			@Param("typeDetail") Integer typeDetail, @Param("platform") String platform);

	public FinanceTransferModel findById(Integer id);
}
