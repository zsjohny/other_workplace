package org.dream.shoppingMall.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.shoppingMall.ShoppingMallGoodsModel;

public interface ShoppingMallGoodsDao {

	public void create(ShoppingMallGoodsModel goodsModel);

	public void update(ShoppingMallGoodsModel goodsModel);

	public void updateStatus(@Param("status") Integer status, @Param("ids") List<Integer> ids);

	public List<ShoppingMallGoodsModel> pagingQuery(@Param("channelId") Integer channelId,
			@Param("limit") Integer limit, @Param("size") Integer size);

	public Integer pagingQuery_count(@Param("channelId") Integer channelId);

	public void delete(@Param("status") Integer status, @Param("id") Integer id);
	
	public ShoppingMallGoodsModel findGoodsById(@Param("id") Integer id,@Param("channelId") Integer channelId);
}
