package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceAccModel;
import org.dream.model.finance.FinanceDrawModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;

public interface FinanceService {
	// V2
	public Response systemMakeMoney(Integer id, Double money);

	// *******************************************************

	public FinanceMainModel findMain(Integer userId);

	public FinanceAccModel findAcc(Integer userId);

	public Page<FinanceFlowManageModel> findFlowByPage(Integer id, Integer level, String createTimeStart,
			String createTimeEnd, Integer userId, String userName, String userPhone, Integer channelId,
			Integer topChannelId, Integer type, Integer typeDetail, String remark, Integer page, Integer pageSize,
			String flow);

	public Integer findFlowRows(Integer id, Integer level, String createTimeStart, String createTimeEnd, Integer userId,
			String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, String flow);

	public Page<FinanceIOManageModel> findIOByPage(FinanceIOManageModel model, Integer id, Integer level, Integer page,
			Integer pageSize);

	public List<FinanceDrawModel> findDrawByPage(Integer status, Integer channelId, Integer offset, Integer pageSize);

	public Integer findDrawRows(Integer status, Integer channelId);

	public void checkDraw(Integer status, String ioIds);

	public void newSelfOrderId(String ioIds);

	public List<FinanceTransferModel> saveTransfer(String ioIds, FinanceTransferType transferType,
			FinancePayType payType, String operator);

	public Page<FinanceTransferManageModel> findTransferByPage(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId, Integer offset,
			Integer pageSize);

	public FinanceTransferManageModel findTransfer(Integer topChannelId, Integer transferId);

	public FinanceIOManageModel findByid(Integer id);

}
