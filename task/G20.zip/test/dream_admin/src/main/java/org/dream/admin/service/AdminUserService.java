package org.dream.admin.service;

import java.util.List;

import org.dream.admin.model.AdminActorModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.utils.mvc.Page;

public interface AdminUserService {
	/**
	 * 创建管理员用户
	 */
	public void createAdminUser(AdminUserModel adminUserModel, Integer departmentId);

	/**
	 * 为参与者批量授权
	 * 
	 * @param actorId
	 * @param authorityIdList
	 */
	public void grantAuthoritysToActor(Integer actorId, List<Integer> authorityIdList,Integer dataId);


	/**
	 * 分页获得部门下的用户
	 * 
	 * @param departmentId
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	public Page<AdminUserModel> pagingquerByDepartmentId(Integer departmentId, Integer pageIndex, Integer pageSize);

	/**
	 * 将用户从部门中移除
	 * 
	 * @param departmentId
	 * @param userIds
	 */
	public void deleteUserRelation(Integer departmentId, String userIds);

	/**
	 * 分页获得未与部门关联的用户
	 * 
	 * @param page
	 * @param pageSize
	 * @return
	 */
	public Page<AdminUserModel> pagingqueryNotRelationUsers(Integer page, Integer pageSize,Integer dataId);

	/**
	 * 批量关联用户和部门
	 * 
	 * @param departmentId
	 * @param userIds
	 */
	public void createUserRelation(Integer departmentId, String userIds);


	/**
	 * 修改User除密码之外的信息 登录名不能修改
	 * 
	 * @param adminUserModel
	 */
	public void updateAdminUserExceptPassword(AdminUserModel adminUserModel);

	/**
	 * 删除一个User
	 * 
	 * @param id
	 */
	public void deleteAdminUser(Integer id, Integer dataId);

	/**
	 * 删除多个User
	 * 
	 * @param ids
	 */
	public void deleteAdminUsers(List<Integer> ids, Integer dataId);

	/**
	 * 根据id获得User
	 * 
	 * @param id
	 * @return
	 */
	public AdminUserModel getUser(Integer id);

	/**
	 * 分页获得多条件查询User列表
	 * 
	 * @param pageIndex
	 *            开始页码
	 * @param size
	 *            页大小
	 * @param userAccount
	 * @param name
	 * @param email
	 * @param disable
	 * @param phone
	 * @return
	 */
	public Page<AdminActorModel> getUserList(Integer pageIndex, Integer size, String userAccount, String name,
			String email, Boolean disable, String phone, Integer dataId);

	/**
	 * 修改User的密码
	 * 
	 * @param id
	 * @param oldPassword
	 * @param newPassword
	 */
	public void changePassword(Integer id, String newPassword);

	/**
	 * 禁用/激活用户
	 * 
	 * @param ids
	 * @param disbale
	 *            禁用或激活 true ： 禁用 false ： 激活
	 */
	public void disbaleOrActivationUser(List<Integer> ids, boolean disbale);

	/**
	 * 根据用户名和密码获得一个用户 登录验证 关于登录密码： 用户的登录密码在页面时会通过MD5加密一次，在后台会拼接加密盐，再次加密，
	 * 保存用户时也是采用此加密流程
	 * 
	 * @param userAccount
	 * @param password
	 * @return
	 */
	public AdminUserModel getUserByUserAccountPassword(String userAccount, String password, Integer dataId);

	/**
	 * 验证用户的账户是否已经存在
	 * 
	 * @param userAccount
	 * @return
	 */
	public boolean hasUserAccount(String userAccount,Integer dataId);

	/**
	 * 保存用户和部门信息
	 * 
	 * @param departmentId
	 * @param actorId
	 */
	public void addDepartmentActor(Integer departmentId, Integer actorId);

	/**
	 * 分页获得部门下的用户
	 * 
	 * @param departmentId
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	public Page<AdminUserModel> pagingqueryByDepartmentId(Integer departmentId, Integer pageIndex, Integer pageSize);
	
	
	/**
	 * 分页查询角色下用户
	 * @param roleId
	 * @param dataId
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	public Page<AdminUserModel> pageQueryActorByRoleId(Integer roleId, Integer dataId, Integer pageIndex,
			Integer pageSize);
	
	/**
	 * 移除角色下人员信息
	 * @param roleId
	 * @param actorId
	 * @param dataId
	 */
	public void deleteUserInRole(Integer roleId,Integer actorId, Integer dataId);
	
	public Integer getChannelLevelByDomain(String str);
}
