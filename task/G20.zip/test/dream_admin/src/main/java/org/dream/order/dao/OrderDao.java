package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.OrderModel;
import org.dream.model.order.OrderSunModel;

public interface OrderDao {

	public List<OrderSunModel> queryIntegralOrderList(OrderSunModel ordersun);

	public List<OrderSunModel> queryCashOrderList(OrderSunModel ordersun);

	public int queryIntegralOrderCount(OrderSunModel ordersun);

	public int queryCashOrderCount(OrderSunModel ordersun);

	public List<Map<String, Object>> getVarietyIdAndVarietyName();

	public OrderSunModel getOrderSunModelByIdForIntegral(int id);
	
	public OrderSunModel getOrderSunModelByIdAndChannelIdForIntegral(@Param("id")int id,@Param("channelId")int channelId,@Param("level")int level);

	public OrderSunModel getOrderSunModelByIdForCash(int id);

	public OrderModel getOrderModelById(int id);

	public int getCountByIdAndOneChannelId(@Param("id") int id, @Param("oneChannelId") int oneChannelId);

	public List<OrderModel> getOrderCashCount(OrderModel model);

	public List<OrderSunModel> countCashOrderList(OrderSunModel ordersun);
}
