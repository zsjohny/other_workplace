package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.order.ChannelFeesModel;
import org.dream.order.dao.ChannelFeesDao;
import org.dream.order.dao.VarietyPriceDao;
import org.dream.order.service.ChannelFeesService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.UserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class ChannelFeesServiceImpl implements ChannelFeesService {
	@Autowired
	ChannelFeesDao channelFeesDao;
	
	@Autowired
	VarietyPriceDao varietyPriceDao;

	@Override
	public Map<String, Object> saveChannelFees(ChannelFeesModel channelFeesModel) {
		Map<String,Object> mapdata=new HashMap<String,Object>();
			
		//首先判断这个配资数据库中是否已经新增了
		int count =channelFeesDao.getChannelFeesCountById(channelFeesModel.getChannelId(),channelFeesModel.getAssetsId());
			if(count >0){
				mapdata.put("resCode","0" );
				mapdata.put("resMgs","该渠道配资手续费配置已存在");
				return mapdata;
		}
	    channelFeesModel.setCreateUserId(UserUtil.getUserId());
		channelFeesDao.insertSelective(channelFeesModel);
		mapdata.put("resCode","1" );
		mapdata.put("resMgs","成功");
		return mapdata;
	}

	@Override
	public void updateChannelFees(ChannelFeesModel channelFeesModel) {
		channelFeesModel.setUpdateUserId(UserUtil.getUserId());
		channelFeesDao.updateByPrimaryKeySelective(channelFeesModel);
		
	}

	@Override
	public void removeChannelFees(Integer id) {
		channelFeesDao.removeByPrimaryKey(id);
		
	}

	@Override
	public Page<ChannelFeesModel> pagingQueryChannelFees(Integer page, Integer pageSize, Integer channelId,Integer assetsId,String createTimeStart, String createTimeEnd) {
		 pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
	     page = page == null ? 0 : page;
	     Integer limit = page  > 0 ? page* pageSize : 0 * pageSize;
	     Map<String,Object> map=new HashMap<String,Object>();
	     map.put("limit", limit);
	     map.put("pageSize", pageSize);
	     map.put("channelId",channelId);
	     map.put("assetsId",assetsId);
	     map.put("createTimeStart", createTimeStart);
	     map.put("createTimeEnd", createTimeEnd);
	     List<ChannelFeesModel> data=channelFeesDao.pagingQueryChannelFees(map);
	     int totalCount = channelFeesDao.pagingQueryChannelFeesCount(map);
	     Page<ChannelFeesModel> pagelist=new Page<ChannelFeesModel>(page,pageSize,totalCount);
	     pagelist.setData(data);
		return pagelist;
	}

	@Override
	public ChannelFeesModel getChannelFeesById(Integer id) {
		
		return channelFeesDao.selectByPrimaryKey(id);
	}
	
	

}
