package org.dream.admin.service;

import java.util.List;

import org.dream.admin.model.AdminRoleModel;
import org.dream.utils.mvc.Page;

/**
 * 
 * @author SUNDONG_
 *
 */
public interface AdminRoleService {
	public void createAdminRole(AdminRoleModel adminRoleModel);

	public void updateAdminRole(AdminRoleModel adminRoleModel);

	public void deleteAdminRole(Integer roleId);

	/**
	 * 
	 * @param name
	 * @param description
	 * @param category
	 * @param dataId
	 * @param page
	 * @param pageSize
	 * @return
	 */
	public Page<AdminRoleModel> pagingQueryPermissions(String name, String description, String category, Integer dataId,
			Integer page, Integer pageSize);

	/**
	 * 删除多条角色数据和角色相关的配置数据，如角色权限关系数据、角色页面元素数据。
	 * 返回不能删除的角色数据（角色和用户关联时，不能删除该角色数据，应先清空该角色用户关系数据后再删除该角色。这样防止误删除的情况）
	 * 
	 * @param ids
	 * @return
	 */
	public List<AdminRoleModel> deleteRoles(List<Integer> ids);

	/**
	 * 根据参与者Id分页查询授权给参与者的角色
	 * 
	 * @param page
	 * @param pageSize
	 * @param actorId
	 * @return
	 */
	public Page<AdminRoleModel> pagingQueryGrantRoles(Integer page, Integer pageSize, Integer actorId, String name,
			Integer dataId);

	/**
	 * 根据参与者Id分页查询未授权给参与者的角色
	 * 
	 * @param page
	 * @param pageSize
	 * @param actorId
	 * @param name
	 * @return
	 */
	public Page<AdminRoleModel> pagingQueryNotGrantRoles(Integer page, Integer pageSize, Integer actorId, String name,
			Integer dataId);

	/**
	 * 根据参与者Id和授权Id批量撤销权限， <strong>该接口同样适用于权限的撤销，</strong>
	 * 
	 * @param userId
	 * @param authorityIds
	 */
	public void terminateAuthorizationByUserIdAuthorithIds(Integer userId, List<Integer> authorityIds, Integer dataId);

	/**
	 * 获得参与者拥有的角色
	 * 
	 * @param actorId
	 * @return
	 */
	public List<AdminRoleModel> queryGrantRoles(Integer actorId, Integer dataId);


	/**
	 * 查询平台渠道下的角色列表 
	 */
	public Page<AdminRoleModel> pagingQueryChannelRoles(Integer dataId,Integer type, Integer page, Integer pageSize);
	
	
	public List<AdminRoleModel> findRoles(Integer dataId);
}
