package org.dream.config.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.config.model.TimedTaskModel;

/**
 * 定时任务Dao
 *
 * @author wangd
 */
public interface TimedTaskDao {

	public void createTimedTask(TimedTaskModel timedTaskModel);

	public void updateTimedTask(TimedTaskModel timedTaskModel);

	public void deleteByIds(@Param(value = "ids") List<Integer> ids);

	/**
	 * 获得所有开启的定时任务
	 *
	 * @return
	 */
	public List<TimedTaskModel> getAllOpenTask();

	/**
	 * 根据任务的id批量修改定时任务的开启或关闭
	 *
	 * @param ids
	 * @param isOpen
	 *            定时任务开启是否开启 true 开启；false： 关闭
	 */
	public void changeIsOpenBIds(@Param(value = "ids") List<Integer> ids, @Param(value = "isOpen") boolean isOpen);

	public List<TimedTaskModel> querypaging(@Param(value = "typeId") Integer typeId,
			@Param(value = "isOpen") Boolean isOpen, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer querypaging_count(@Param(value = "typeId") Integer typeId, @Param(value = "isOpen") Boolean isOpen);

	int updateTimedByExchangeIdAndTopChannelId(TimedTaskModel timedTaskModel);

	TimedTaskModel findTimedTaskIdByIds(@Param("exchangeId") Integer exchangeId,
			@Param("topChannelId") Integer topChannelId, @Param("topTimeTaskId") Long topTimeTaskId);

	int deleteByExchangeIdAndTopChannelId(@Param("exchangeId") Integer exchangeId,
			@Param("topChannelId") Integer topChannelId, @Param("topTimeTaskId") Long topTimeTaskId);

}
