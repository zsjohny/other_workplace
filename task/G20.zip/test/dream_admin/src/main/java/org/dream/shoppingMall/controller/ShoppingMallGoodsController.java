package org.dream.shoppingMall.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.shoppingMall.ShoppingMallGoodsModel;
import org.dream.shoppingMall.service.ShoppingMallGoodsService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/shoppingMall")
public class ShoppingMallGoodsController extends BaseController {

	@Autowired
	ShoppingMallGoodsService shoppingMallGoodsService;

	@RequestMapping("/create")
	@ResponseBody
	public Response create(ShoppingMallGoodsModel goodsModel, HttpServletRequest request) {
		goodsModel.setChannelId(super.getDataId(request));
		return shoppingMallGoodsService.create(goodsModel);
	}

	@RequestMapping("/update")
	@ResponseBody
	public Response update(ShoppingMallGoodsModel goodsModel) {
		return shoppingMallGoodsService.update(goodsModel);
	}

	@RequestMapping("/unavailable")
	@ResponseBody
	public Response unavailable(String ids) {
		Assert.notNull(ids, "需要下架的商品Id不能为空");
		List<Integer> idList = new ArrayList<>();
		String idsArray[] = ids.split(",");
		for (int i = 0; i < idsArray.length; i++) {
			idList.add(Integer.valueOf(idsArray[i]));
		}
		return shoppingMallGoodsService.unavailable(idList);
	}

	@RequestMapping("/sale")
	@ResponseBody
	public Response sale(String ids) {
		Assert.notNull(ids, "需要上架的商品Id不能为空");
		List<Integer> idList = new ArrayList<>();
		String idsArray[] = ids.split(",");
		for (int i = 0; i < idsArray.length; i++) {
			idList.add(Integer.valueOf(idsArray[i]));
		}
		return shoppingMallGoodsService.sale(idList);
	}
	
	@RequestMapping("/pagingQuery")
	@ResponseBody
	public Response pagingQuery(Integer page, Integer pageSize, HttpServletRequest request) {
		return shoppingMallGoodsService.pagingQuery(super.getDataId(request), page, pageSize);
	}
	
	
	@RequestMapping("/delete")
	@ResponseBody
	public Response delete(Integer id){
		Assert.notNull(id, "需要删除的商品Id不能为空");
		return shoppingMallGoodsService.delete(id);
		
	}
	
	
	@RequestMapping("/findGoodsById")
	@ResponseBody
	public Response findGoodsById(Integer id,HttpServletRequest request){
		Assert.notNull(id, "商品Id不能为空");
		return shoppingMallGoodsService.findGoodsById(id,super.getDataId(request));
	}
}
