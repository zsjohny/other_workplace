package org.dream.push.dao;

import org.dream.model.push.PushRemarkModel;

import java.util.List;

/**
 * 推送评论的dao
 * Created by nessary on 16-9-27.
 */
public interface PushRemarkDao {
    /**
     * 保存推送评论实体类
     *
     * @param pushRemarkModel 推送实体类
     */
    void savePushRemarkModel(PushRemarkModel pushRemarkModel);


    /**
     * 更改推送评论的内容 包含软删除 之类的
     *
     * @param pushRemarkModel 推送评论实体类
     */
    void updatePushRemarkModel(PushRemarkModel pushRemarkModel);


    /**
     * 分页查找当前渠道下的所有的设置的信息
     *
     * @param pushRemarkModel 推送评论实体类
     * @return
     */
    List<PushRemarkModel> findAllPushRemarkModel(PushRemarkModel pushRemarkModel);


}
