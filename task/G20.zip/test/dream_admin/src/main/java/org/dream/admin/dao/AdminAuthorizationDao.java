package org.dream.admin.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.admin.model.AdminAuthorizationModel;

/**
 * 授权中心DAO
 * 
 * @author wangd
 *
 */
public interface AdminAuthorizationDao {

    public void createAuthorization(AdminAuthorizationModel adminAuthorizationMoudel);

    public void upadteAuthorization(AdminAuthorizationModel adminAuthorizationMoudel);

    /**
     * 根据参与者id或者授权id删除记录 该接口可以由下面的多条删除接口替代，留着是为了传值方便
     * 
     * @param actorId
     * @param authorityId
     * @param dataId
     */
    public void deleteAuthorization(@Param(value = "actorId") Integer actorId,
	    @Param(value = "authorityId") Integer authorityId, @Param(value = "dataId") Integer dataId);

    /**
     * 根据参与者Id或授权id获得授权纪录
     * 
     * @param actorId
     * @param authorityId
     * @return
     */
    public List<AdminAuthorizationModel> getAuthorizations(@Param(value = "actorId") Integer actorId,
	    @Param(value = "authorityId") Integer authorityId, @Param(value = "dataId") Integer dataId);

    /**
     * 根据参与者id和授权id批量撤销授权
     * 
     * @param actorId
     * @param authorityIds
     */
    public void deleteAuthorizationByActorIdAuthorityIds(@Param(value = "actorId") Integer actorId,
	    @Param(value = "authorityIds") List<Integer> authorityIds, @Param(value = "dataId") Integer dataId);
}
