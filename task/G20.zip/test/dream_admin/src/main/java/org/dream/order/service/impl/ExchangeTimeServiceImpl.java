package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.dream.config.dao.TaskTypeDao;
import org.dream.config.model.TaskTypeModel;
import org.dream.model.order.ExchangeTimeModel;
import org.dream.model.order.FuturesExchangeModel;
import org.dream.order.dao.ExchangeTimeDao;
import org.dream.order.service.ExchangeTimeService;
import org.dream.schedule.model.TimedTaskModel;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.dream.utils.prop.SpringProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
@Service
public class ExchangeTimeServiceImpl implements ExchangeTimeService {
	@Autowired
	private ExchangeTimeDao exchangeTimeDao;
	
    @Autowired
    TaskTypeDao taskTypeDao;
	@Autowired
	private SpringProperties springProperties;
	
	@Autowired
    JmsSender timedTaskChangendSender;

	@Override
	public Map<String, Object> saveExchangeTime(ExchangeTimeModel etm) {
		Map<String,Object> mapRet=new HashMap<String,Object>();
		//先判断传入的时间是否已经存在的区间之内了
//		int countStart=exchangeTimeDao.getCountTimeIsIntervalStartTime(etm);
//		int countEnd=exchangeTimeDao.getCountTimeIsIntervalEndTime(etm);
//		if(countStart > 0||countEnd>0){
//			mapRet.put("retCode", "0");
//			mapRet.put("retmsg", "该交易所的交易时间段已经存在");
//			return mapRet;
//		}
		//首先往市场和时间表里面插数据
		
		//得到周期
		String cycleStr=getCycleStr(etm.getCycleStr());
		etm.setTimeTrigger(getCronz(etm.getStartTimeStr(),cycleStr));
		exchangeTimeDao.saveExchangeTime(etm);
		//首先判断该定时任务类型表中是否有市场这个数据了
		
		insertTimeTaskAndSendMessageToMq(etm);
		
		mapRet.put("retCode", "1");
		return mapRet;
	}

	
	private static String getCronz(String startTime,String cycle){
		StringBuffer buffer=new StringBuffer();
		String s=startTime.substring(startTime.lastIndexOf(":")+1,startTime.length());
		if(s.equals("00")){
			s="0";
		}
		buffer.append(s);
		buffer.append(" ");
		String strE=startTime.substring(startTime.indexOf(":")+1, startTime.lastIndexOf(":"));
		if(strE.equals("00")){
			strE="0";
		}
		buffer.append(strE);
		buffer.append(" ");
		String strS=startTime.substring(0,startTime.indexOf(":"));
		if(strS.equals("00")){
			strS="0";
		}
		buffer.append(strS);
		buffer.append(" ? * ");
		buffer.append(cycle);
		return buffer.toString();
	}
	
	
	private static String getCycleStr(String cycleStr){
		StringBuffer buffer=new StringBuffer();
		for(String cycle:cycleStr.split(",")){
			if(cycle.equals("周一")){
				cycle="MON";
			}else if(cycle.equals("周二")){
				cycle="TUE";
			}else if(cycle.equals("周三")){
				cycle="WED";
			}else if(cycle.equals("周四")){
				cycle="THU";
			}else if(cycle.equals("周五")){
				cycle="FRI";
			}else if(cycle.equals("周六")){
				cycle="SAT";
			}else if(cycle.equals("周日")){
				cycle="SUN";
			}
			buffer.append(cycle);
			buffer.append(",");
		}
		return buffer.toString().substring(0,buffer.lastIndexOf(","));
	}
	
	
	public static void main(String[] args) {
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("exchangeId", 3);
		map.put("status", 1);
		System.out.println(JSON.toJSONString(map));
		System.out.println(getCronz("09:10:12","1"));
		System.out.println(getCycleStr("周一,周二"));
	}


	@Override
	public Page<ExchangeTimeModel> pagingQueryExchangeTime(Integer page, Integer pageSize, Integer exchangeId,
			String createTimeStart, String createTimeEnd) {
		
		 pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
	     page = page == null ? 0 : page;
	     Integer limit = page  > 0 ? page* pageSize : 0 * pageSize;
	     Map<String,Object> map=new HashMap<String,Object>();
	     map.put("limit", limit);
	     map.put("pageSize", pageSize);
	     map.put("exchangeId",exchangeId);
	     map.put("createTimeStart", createTimeStart);
	     map.put("createTimeEnd", createTimeEnd);
	     List<ExchangeTimeModel> data=exchangeTimeDao.pagingQueryExchangeTime(map);
	     int totalCount = exchangeTimeDao.pagingQueryExchangeTimeCount(map);
	     Page<ExchangeTimeModel> pagelist=new Page<ExchangeTimeModel>(page,pageSize,totalCount);
	     pagelist.setData(data);
		return pagelist;
	}

	private void insertTimeTaskAndSendMessageToMq(ExchangeTimeModel etm){
		TaskTypeModel t=exchangeTimeDao.getTaskTypeModelForTaskType(springProperties.getProperty("schedule.order.exchange"));
		if(t==null){
			TaskTypeModel taskTypeModel=new TaskTypeModel();
			taskTypeModel.setTaskType(springProperties.getProperty("schedule.order.exchange"));
			taskTypeModel.setTaskName("市场状态定时任务");
			taskTypeModel.setRemark("市场状态定时任务：开市,休市,当天交易结束,当天交易开始");
			taskTypeDao.creatTaskType(taskTypeModel);
			t=taskTypeModel;
		}
		//往定时任务表里面添加任务
		TimedTaskModel time=new TimedTaskModel();
		time.setTypeId(t.getId());
		time.setTaskType(t.getTaskType());
		time.setTypeName(t.getTaskName());
		time.setIsOpen(true);
		time.setRemark(t.getRemark());
		time.setExchangeTimeId(etm.getId());
		String cycleStr=getCycleStr(etm.getCycleStr());
		//得到cycle
		Map<String,Object> mapStr=new HashMap<String,Object>();
		mapStr.put("exchangeId", etm.getExchangeId());
		mapStr.put("status", etm.getExchangeStatus());
		time.setParameters(JSON.toJSONString(mapStr));
		time.setTimeTrigger(etm.getTimeTrigger());
		//往定时任务表里面插入数据
		exchangeTimeDao.insertTimeTask(time);
		Map<String, Object> message = new HashMap<String, Object>();
		message.put("action", "ADD");
		message.put("id", time.getId());
		timedTaskChangendSender.sendMessage(JSON.toJSONString(message));
			
	}


	@Override
	public void deleteExchangeTime(String id) {
		//首先根据id得到timesTasksId
//		List<Integer> ids=exchangeTimeDao.getTimesTaskIdsByExchangeTimeId(id);
		String []ids= id.split(",");
		//首先删除市场时间的数据
		exchangeTimeDao.deleteExchangeTimeById(ids);
		//删除定时任务表里面的数据
		exchangeTimeDao.deleteTimesTaskByExchangeTimeId(ids);
		//根据ids得到所有的TimesTaskIds
		List<Integer> taskIds=exchangeTimeDao.getTimesTaskIdsByIds(ids);
		StringBuffer str=new StringBuffer();
		String strId=null;
		if(ids !=null && taskIds.size()>0){
			for(Integer taskId:taskIds){
				str.append(taskId);
				str.append(",");
			}
		strId=str.substring(0,str.length()-1);
		//删除定时里面消息里面的数据
		Map<String, Object> message = new HashMap<String, Object>();
			message.put("action", "DELETE");
			message.put("id", strId);
			timedTaskChangendSender.sendMessage(JSON.toJSONString(message));
		}
	}

	/**
	 * 修改市场时间
	 */
	@Override
	public Map<String,Object> updateExchangeTime(ExchangeTimeModel etm) {
		Map<String,Object> mapRet=new HashMap<String,Object>();
		//先判断传入的时间是否已经存在的区间之内了
//		int countStart=exchangeTimeDao.getCountTimeIsIntervalStartTime(etm);
//		int countEnd=exchangeTimeDao.getCountTimeIsIntervalEndTime(etm);
//		if(countStart > 0||countEnd>0){
//			mapRet.put("retCode", "0");
//			mapRet.put("retmsg", "该交易所的交易时间段已经存在");
//			return mapRet;
//		}
		//首先修改市场时间的状态,和时间，和周期
		String cycleStr=getCycleStr(etm.getCycleStr());
		etm.setTimeTrigger(getCronz(etm.getStartTimeStr(),cycleStr));
		exchangeTimeDao.updateExchangeTime(etm);
		
		//其次修改定时任务中的数据参数
		TimedTaskModel t=new TimedTaskModel();
		t.setExchangeTimeId(etm.getId());
		//处理周期
		Map<String,Object> mapStr=new HashMap<String,Object>();
		mapStr.put("exchangeId", etm.getExchangeId());
		mapStr.put("status", etm.getExchangeStatus());
		t.setParameters(JSON.toJSONString(mapStr));
		t.setTimeTrigger(etm.getTimeTrigger());
		exchangeTimeDao.updateTimesTask(t);
		//首先根据id得到timesTasksId
		Integer ids=exchangeTimeDao.getTimesTaskIdsByExchangeTimeId(etm.getId());
		//修改定时里面消息里面的数据
		Map<String, Object> message = new HashMap<String, Object>();
			message.put("action", "UPDATE");
			message.put("id", ids);
			timedTaskChangendSender.sendMessage(JSON.toJSONString(message));
		mapRet.put("retCode", "1");
		return mapRet;
		
	}


	@Override
	public ExchangeTimeModel getExchangeTimeInfo(int id) {
		
		return exchangeTimeDao.getExchangeTimeInfo(id);
	}


	@Override
	public List<FuturesExchangeModel> getExchange() {
		return exchangeTimeDao.getExchange();
	}
}
