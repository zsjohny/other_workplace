package org.dream.shoppingMall.service;

import java.util.List;

public interface ShoppingMallCheckService {

	public void checkSuccessShopping(Integer status, Integer channelId, List<Integer> idList);
	
	public void checkFailShopping(Integer status, Integer channelId, List<Integer> idList);

}
