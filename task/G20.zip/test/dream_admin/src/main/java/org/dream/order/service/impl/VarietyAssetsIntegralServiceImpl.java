package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dream.channel.dao.ChannelDao;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.VarietyAssetsModel;
import org.dream.order.dao.VarietyAssetsIntegralDao;
import org.dream.order.dao.VarietyPriceDao;
import org.dream.order.service.VarietyAssetsIntegralService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class VarietyAssetsIntegralServiceImpl implements VarietyAssetsIntegralService {

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;
	@Autowired
	VarietyAssetsIntegralDao varietyAssetsIntegralDao;

	@Autowired
	VarietyPriceDao varietyPriceDao;

	@Autowired
	ChannelDao channelDao;

	@Override
	public Map<String, Object> saveVarietyAssets(VarietyAssetsModel varietyAssetsModel) {
		Map<String, Object> mapdata = new HashMap<String, Object>();
		ChannelModel channelModel = channelDao.getById(varietyAssetsModel.getChannelId());
		varietyAssetsModel.setChannelName(channelModel.getName());
		varietyAssetsIntegralDao.insertSelective(varietyAssetsModel);
		List<VarietyAssetsModel> assets= varietyAssetsIntegralDao.getAssetsByVarietyIdAndChannelIdForIntegral(varietyAssetsModel.getVarietyId(), channelModel.getId());
		
		redisTemplate.opsForHash().put(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS_INTEGRAL,
				channelModel.getId() + "_" + varietyAssetsModel.getVarietyId(), assets);
		// 单纯的配资缓存
		redisTemplate.opsForHash().put(VarietyAssetsModel.ASSETS_INTEGRAL, varietyAssetsModel.getId(),
				varietyAssetsModel);
		mapdata.put("resCode", "1");
		mapdata.put("resMgs", "成功");
		return mapdata;
	}

	@Override
	public Map<String, Object> updateVarietyAssets(VarietyAssetsModel varietyAssetsModel, ChannelModel channelModel) {
		Map<String, Object> mapdata = new HashMap<String, Object>();
		varietyAssetsIntegralDao.updateByPrimaryKeySelective(varietyAssetsModel);
		List<VarietyAssetsModel> assets= varietyAssetsIntegralDao.getAssetsByVarietyIdAndChannelIdForIntegral(varietyAssetsModel.getVarietyId(), channelModel.getId());
		redisTemplate.opsForHash().put(VarietyAssetsModel.ASSETS_INTEGRAL, varietyAssetsModel.getId(),
				varietyAssetsModel);
		redisTemplate.opsForHash().put(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS_INTEGRAL,
				channelModel.getId() + "_" + varietyAssetsModel.getVarietyId(), assets);
		
		mapdata.put("resCode", "1");
		mapdata.put("resMgs", "成功");
		return mapdata;
	}

	@Override
	public void removeVarietyAssets(String ids, Integer channelId) {
		List<Integer> idList = handleIds(ids);
		for (Integer id : idList) {
			// 根据配资id得到品种
			Integer varietyId = varietyAssetsIntegralDao.getVarietyIdByassetsId(id);
			varietyAssetsIntegralDao.removeVarietyAssets(id);
			redisTemplate.opsForHash().delete(VarietyAssetsModel.ASSETS_INTEGRAL, id);
			redisTemplate.opsForHash().delete(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS_INTEGRAL,
					channelId + "_" + varietyId);
			List<VarietyAssetsModel> assets= varietyAssetsIntegralDao.getAssetsByVarietyIdAndChannelIdForIntegral(varietyId, channelId);
			if(assets !=null && assets.size() > 0){
				redisTemplate.opsForHash().put(VarietyAssetsModel.CHANNEL_VARIETY_ASSETS_INTEGRAL,
						channelId + "_" + varietyId, assets);
			}
		}

	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public Page<VarietyAssetsModel> pagingQueryVarietyAssets(Integer page, Integer pageSize, Integer varietyId,
			String createTimeStart, String createTimeEnd, int channelId) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("limit", limit);
		map.put("pageSize", pageSize);
		map.put("varietyId", varietyId);
		map.put("channelId", channelId);
		map.put("createTimeStart", createTimeStart);
		map.put("createTimeEnd", createTimeEnd);
		List<VarietyAssetsModel> data = varietyAssetsIntegralDao.pagingQueryVarietyAssets(map);
		int totalCount = varietyAssetsIntegralDao.pagingQueryVarietyAssetsCount(map);
		Page<VarietyAssetsModel> pagelist = new Page<VarietyAssetsModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public VarietyAssetsModel getVarietyAssetsById(Integer id) {

		return varietyAssetsIntegralDao.selectByPrimaryKey(id);
	}

	@Override
	public Integer getVarietyAssetsCountByChannelAndVariety(Integer varietyId, Integer channelId, Integer id) {
		return varietyAssetsIntegralDao.getVarietyAssetsCountByChannelAndVariety(varietyId, channelId, id);
	}

}
