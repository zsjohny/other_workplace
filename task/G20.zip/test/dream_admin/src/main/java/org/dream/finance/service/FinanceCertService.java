package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformModel;
import org.dream.utils.mvc.Response;

public interface FinanceCertService {
	// V3
	public List<FinancePayPlatformModel> findPayPlatformByCert(FinanceCertModel certModel);

	// ***************************************************************************
	// V2
	public Response findCertByPage(FinanceCertModel certModel, Integer page, Integer pageSize);

	public Response findCert(FinanceCertModel certModel);

	public Response saveCert(FinanceCertModel certModel);

	public Response updateCert(FinanceCertModel certModel);

	public List<String> findPlatformAll(FinanceCertModel certModel);

	// ****************************************
}
