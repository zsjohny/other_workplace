package org.dream.order.dao;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.ExchangeTimeModel;
import org.dream.model.order.TopChannelModel;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * 一级渠道下的 表格名称
 * Created by nessary on 16-7-21.
 */
public interface TopChannelTaskTimeDao {

    void saveTopChannelTime(TopChannelModel topChannelModel);


    List<TopChannelModel> findTopChannelTimeByChannelIdAndExchangeIds(@Param("topChannelId") Integer topChannelId, @Param("exchangeIds") Set<Integer> exchangeIds, @Param("start") Integer start, @Param("pageCount") Integer pageCount);


    int findTopChannelTimeCountByChannelIdAndExchangeIds(@Param("topChannelId") Integer topChannelId, @Param("exchangeIds") Set<Integer> exchangeIds);


    int removeTopChannelTimeById(@Param("topChannelId") Integer topChannelId, @Param("exchangeId") Integer exchangeId, @Param("id") Long topChannelModelId);


    void updateTopChannelTimeById(TopChannelModel topChannelModel);


    int findChannelIdCountByIds(@Param("topChannelId") Integer topChannelId, @Param("exchangeId") Integer exchangeId, @Param("id") Long topChannelModelId);


    List<TopChannelModel> findTopChannelTimeAllNotPageByChannelIdAndExchangeId(@Param("topChannelId") Integer topChannelId, @Param("exchangeId") Integer exchangeId);


    TopChannelModel findChannelIdByIdsAndExchangeTime(@Param("topChannelId") Integer topChannelId, @Param("exchangeId") Integer exchangeId,@Param("varietyId") Integer varietyId, @Param("exchangeTime") Date exchangeTime);


    ExchangeTimeModel getExchangeTimeByExchangeId(Integer exchangeId);

}
