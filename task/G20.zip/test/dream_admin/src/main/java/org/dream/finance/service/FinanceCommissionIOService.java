package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.utils.mvc.Response;

public interface FinanceCommissionIOService {
	public Response findCommissionIOByPage(FinanceCommissionIOModel commissionIOModel, Integer page, Integer pageSize);

	public Response updateCommissionIO(String ids, Integer status);
}
