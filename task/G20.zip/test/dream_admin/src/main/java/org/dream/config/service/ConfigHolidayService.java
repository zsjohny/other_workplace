package org.dream.config.service;

import java.util.List;

import org.dream.config.model.HolidayModel;
import org.dream.utils.mvc.Page;

/**
 * 假期配置Service
 * 
 * @author wangd
 *
 */
public interface ConfigHolidayService {

    public void saveConfigHoliday(HolidayModel holidayModel);

    /**
     * 批量保存假期配置
     * @param holidayModels
     */
    public void saveConfigHolidays(List<HolidayModel> holidayModels);
    
    public void updateConfigHoliday(HolidayModel holidayModel);

    public List<HolidayModel> getAllHolidays(Integer exchangeId, Integer stauts);

    public void delteHoliday(String ids);

    public Page<HolidayModel> querypaging(Integer exchangeId, Integer stauts,Integer pageIndex, Integer pageSize);
}
