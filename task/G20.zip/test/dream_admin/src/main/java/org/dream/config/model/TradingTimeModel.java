package org.dream.config.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 交易时间管理 动态处理某一品种在某一天中的开市和休市状态的判断 不建议使用该类数据处理假期情况，虽然理论上是可行的，但是木意义
 * 
 * @author wangd
 *
 */
public class TradingTimeModel implements Serializable {
    private static final long serialVersionUID = 3995981002044637828L;
    private Integer id;
    /**
     * 交易所id
     */
    private Integer exchangeId;
    /**
     * 交易所名称
     */
    private String exchangeName;
    /**
     * 品种id
     */
    private Integer varietyId;
    /**
     * 品种名称
     */
    private String varietyName;

    /**
     * 品种类型
     */
    private String varietyType;
    /**
     * 交易时间段（开市时间-休市时间，不包含天） 如：9：00-10：00
     */
    private String timePeriod;
    /**
     * 时间表达式<br>
     * quartz cron 表达式
     */
    private String timeTrigger;
    /**
     * 操作 0：休市；1：开市；2：只能买进；3：只能卖出
     */
    private Integer action;
    /**
     * 备注
     */
    private String remark;
    /**
     * 当前状态
     * 1：有效 ；0：无效
     */
    private Integer status = 1;
    private Timestamp createDate;
    private Timestamp lastUdateDate;

    public Integer getId() {
	return id;
    }

    public void setId(Integer id) {
	this.id = id;
    }

    public Integer getExchangeId() {
	return exchangeId;
    }

    public void setExchangeId(Integer exchangeId) {
	this.exchangeId = exchangeId;
    }

    public String getExchangeName() {
	return exchangeName;
    }

    public void setExchangeName(String exchangeName) {
	this.exchangeName = exchangeName;
    }

    public Integer getVarietyId() {
	return varietyId;
    }

    public void setVarietyId(Integer varietyId) {
	this.varietyId = varietyId;
    }

    public String getVarietyName() {
	return varietyName;
    }

    public void setVarietyName(String varietyName) {
	this.varietyName = varietyName;
    }

    public String getVarietyType() {
	return varietyType;
    }

    public void setVarietyType(String varietyType) {
	this.varietyType = varietyType;
    }

    public String getTimePeriod() {
	return timePeriod;
    }

    public void setTimePeriod(String timePeriod) {
	this.timePeriod = timePeriod;
    }

    public String getTimeTrigger() {
	return timeTrigger;
    }

    public void setTimeTrigger(String timeTrigger) {
	this.timeTrigger = timeTrigger;
    }

    public String getRemark() {
	return remark;
    }

    public void setRemark(String remark) {
	this.remark = remark;
    }

    public Timestamp getCreateDate() {
	return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
	this.createDate = createDate;
    }

    public Integer getAction() {
	return action;
    }

    public void setAction(Integer action) {
	this.action = action;
    }

    public Timestamp getLastUdateDate() {
	return lastUdateDate;
    }

    public void setLastUdateDate(Timestamp lastUdateDate) {
	this.lastUdateDate = lastUdateDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

}
