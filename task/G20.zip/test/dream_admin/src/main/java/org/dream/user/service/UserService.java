package org.dream.user.service;

import java.util.Date;
import java.util.List;

import org.dream.model.user.UserBankCardModel;
import org.dream.model.user.UserManageModel;
import org.dream.model.user.UserModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;

public interface UserService {
	public Page<UserManageModel> findByPage(Integer id, Integer level, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, String createTimeStart, String createTimeEnd,
			String lastLoginTimeStart, String lastLoginTimeEnd, String realName, String idCard, Integer status,
			Integer offset, Integer pageSize, String orderBy);

	public UserManageModel findUser(Integer userId);

	public UserBankCardModel findUserBankCard(Integer userId);

	public Response updateUserBankCard(UserBankCardModel bankCardModel);

	public Response updateUser(UserModel userModel);
}
