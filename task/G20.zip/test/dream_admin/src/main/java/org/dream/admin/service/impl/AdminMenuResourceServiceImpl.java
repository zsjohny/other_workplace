package org.dream.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.admin.dao.AdminActorDao;
import org.dream.admin.dao.AdminAuthorityDao;
import org.dream.admin.dao.AdminResourceAssignmentDao;
import org.dream.admin.dao.AdminSecurityResourceDao;
import org.dream.admin.model.AdminMenuResourceModel;
import org.dream.admin.model.AdminPageElementResourceModel;
import org.dream.admin.model.AdminResourceAssignmentModel;
import org.dream.admin.model.AdminRoleModel;
import org.dream.admin.model.AdminSecurityResourceModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.admin.service.AdminMenuResouceService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminMenuResourceServiceImpl implements AdminMenuResouceService {
	@Autowired
	AdminSecurityResourceDao adminSecurityResourceDao;

	@Autowired
	AdminResourceAssignmentDao adminResourceAssignmentDao;

	@Autowired
	AdminAuthorityDao adminAuthorityDao;

	@Autowired
	AdminActorDao adminActorDao;

	public static final Integer MENU_STATUS_NOTDELETE = 1;

	@Override
	public void saveMenu(AdminMenuResourceModel menuResourceModel) {
		// 修改上级菜单的是否是叶子菜单为false
		if (menuResourceModel.getParentId() != null) {
			AdminMenuResourceModel parentNode = adminSecurityResourceDao.getMenu(menuResourceModel.getParentId(),
					MENU_STATUS_NOTDELETE, AdminMenuResourceModel.CATEGORY);
			menuResourceModel.setLevel(parentNode.getLevel() + 1);

			parentNode.setIsLeaf(false);
			adminSecurityResourceDao.updateMenu(parentNode);
		}
		menuResourceModel.setCategory(AdminMenuResourceModel.CATEGORY);
		adminSecurityResourceDao.createMenu(menuResourceModel);
	}

	@Override
	public AdminMenuResourceModel getMenuPedigree(Integer id) {
		id = id == null ? 0 : id;
		AdminMenuResourceModel menuResourceModel = adminSecurityResourceDao.getMenu(id, MENU_STATUS_NOTDELETE,
				AdminMenuResourceModel.CATEGORY);
		menuResourceModel.setChildren(this.getChildren(menuResourceModel.getId()));
		return menuResourceModel;
	}

	/**
	 * 递归查找菜单下所有的子菜单
	 * 
	 * @param parentId
	 * @return
	 */
	private List<AdminMenuResourceModel> getChildren(Integer parentId) {
		List<AdminMenuResourceModel> result = adminSecurityResourceDao.getChildMenu(parentId, MENU_STATUS_NOTDELETE,
				AdminMenuResourceModel.CATEGORY, null);
		for (AdminMenuResourceModel menuResourceModel : result) {
			if (this.getChildren(menuResourceModel.getId()) != null
					&& this.getChildren(menuResourceModel.getId()).size() > 0) {
				menuResourceModel.setChildren(this.getChildren(menuResourceModel.getId()));
			}
		}
		return result;
	}

	@Override
	public void updateMenu(AdminMenuResourceModel menuResourceModel) {
		adminSecurityResourceDao.updateMenu(menuResourceModel);
	}

	@SuppressWarnings("unused")
	@Override
	public String removeMenu(Integer menuId) {

		AdminMenuResourceModel menuResourceModel = this.getMenuPedigree(menuId);
		if (menuResourceModel == null || menuResourceModel != null) {
			return "删除失败，该菜单包含有子菜单";
		}
		adminSecurityResourceDao.delete(menuId);
		return "菜单删除成功";
	}

	/**
	 * 获得所有的菜单数据
	 */
	@Override
	public List<AdminMenuResourceModel> findAllMenusTree(Integer level) {
		List<AdminMenuResourceModel> result = new ArrayList<AdminMenuResourceModel>();
		List<AdminMenuResourceModel> topMenus = this.findTopMenuResources(level);
		result.addAll(topMenus);
		for (AdminMenuResourceModel menuResourceModel : topMenus) {
			List<AdminMenuResourceModel> childNode = this.getChildren(menuResourceModel.getId());
			if (childNode != null && childNode.size() > 0) {
				this.setParent(menuResourceModel.getId(), menuResourceModel.getName(), childNode);
			}
			result.addAll(childNode);
		}
		return result;
	}

	/**
	 * 递归修改子菜单的父菜单信息，包括父菜单的Id和name
	 * 
	 * @param parentId
	 * @param childNode
	 */
	private void setParent(Integer parentId, String name, List<AdminMenuResourceModel> childNode) {
		for (AdminMenuResourceModel model : childNode) {
			model.setParentId(parentId);
			model.setParentName(name);
			if (model.getChildren() != null && model.getChildren().size() > 0) {
				this.setParent(model.getId(), model.getName(), model.getChildren());
			}
		}
	}

	/**
	 * 获得顶级菜单 顶级菜单的层级为0 菜单维护时一定要注意菜单的层级
	 * 
	 * @return
	 */
	public List<AdminMenuResourceModel> findTopMenuResources(Integer type) {
		AdminMenuResourceModel menuResourceModel = new AdminMenuResourceModel();
		menuResourceModel.setCategory(AdminMenuResourceModel.CATEGORY);
		menuResourceModel.setLevel(0);
		menuResourceModel.setType(type);
		return adminSecurityResourceDao.findMenuResources(menuResourceModel);
	}

	public List<AdminMenuResourceModel> findMenuResources(Integer level, Integer type) {
		AdminMenuResourceModel menuResourceModel = new AdminMenuResourceModel();
		menuResourceModel.setCategory(AdminMenuResourceModel.CATEGORY);
		menuResourceModel.setLevel(level);
		menuResourceModel.setType(type);
		return adminSecurityResourceDao.findMenuResources(menuResourceModel);
	}

	@Override
	public List<AdminMenuResourceModel> removeMenus(List<Integer> ids) {
		List<AdminMenuResourceModel> result = new ArrayList<AdminMenuResourceModel>();
		for (Integer id : ids) {
			// 判断是否还有子菜单
			if (!hasChildren(id)) {
				adminSecurityResourceDao.updateStatus(id);
				// 删除菜单 删除与菜单相关联的权限记录
				adminResourceAssignmentDao.deleteAdminResourceAssignment(null, id, null);
			} else if (hasChildren(id)) {
				adminSecurityResourceDao.updateStatus(id);
				// 获取该菜单的子菜单
				List<AdminMenuResourceModel> menuResourceModels = adminSecurityResourceDao.getChildMenu(id,
						MENU_STATUS_NOTDELETE, AdminMenuResourceModel.CATEGORY, null);
				for (AdminMenuResourceModel menuResourceModel : menuResourceModels) {
					adminSecurityResourceDao.updateStatus(menuResourceModel.getId());
					adminResourceAssignmentDao.deleteAdminResourceAssignment(null, menuResourceModel.getId(), null);
				}
			} else {
				result.add(this.getMenu(id));
			}
		}
		return result;
	}

	@Override
	public AdminMenuResourceModel getMenu(Integer id) {
		return adminSecurityResourceDao.getMenu(id, MENU_STATUS_NOTDELETE, AdminMenuResourceModel.CATEGORY);
	}

	/**
	 * 根据菜单Id判断菜单是否含有子菜单
	 * 
	 * @param id
	 * @return 如果含有子菜单返回true否则返回false
	 */
	private boolean hasChildren(Integer id) {
		return adminSecurityResourceDao.getChildMenu(id, MENU_STATUS_NOTDELETE, AdminMenuResourceModel.CATEGORY,
				null) != null
				&& adminSecurityResourceDao
						.getChildMenu(id, MENU_STATUS_NOTDELETE, AdminMenuResourceModel.CATEGORY, null).size() > 0;
	}

	@Override
	public List<AdminMenuResourceModel> findMenuResourceTreeSelectItemByRoleId(Integer roleId, Integer dataId) {
		List<AdminMenuResourceModel> topMenuResources = this.findTopMenuResources(null);
		List<AdminMenuResourceModel> allMenuResourcesAsRole = adminSecurityResourceDao.findMenuResourcesByRoleId(roleId,
				AdminMenuResourceModel.CATEGORY, null, MENU_STATUS_NOTDELETE);
		for (AdminMenuResourceModel menuResourceModel : topMenuResources) {
			menuResourceModel.setChecked(this.content(menuResourceModel, allMenuResourcesAsRole));
			menuResourceModel.setChildren(this.getChildren(menuResourceModel.getId(), allMenuResourcesAsRole));
		}
		return topMenuResources;
	}

	/**
	 * 
	 * @param id
	 * @param allMenuResourcesAsRole
	 * @return
	 */
	private List<AdminMenuResourceModel> getChildren(Integer id, List<AdminMenuResourceModel> allMenuResourcesAsRole) {
		List<AdminMenuResourceModel> result = adminSecurityResourceDao.getChildMenu(id, MENU_STATUS_NOTDELETE,
				AdminMenuResourceModel.CATEGORY, null);
		for (AdminMenuResourceModel menuResourceModel : result) {
			menuResourceModel.setChecked(this.content(menuResourceModel, allMenuResourcesAsRole));
			if (this.getChildren(menuResourceModel.getId()) != null
					&& this.getChildren(menuResourceModel.getId()).size() > 0) {
				menuResourceModel.setChildren(this.getChildren(menuResourceModel.getId(), allMenuResourcesAsRole));
			}
		}
		return result;
	}

	/**
	 * 分配给角色的菜单资源集合中是否包含指定的菜单资源
	 * 
	 * @param menuResourceModel
	 * @param allMenuResourcesAsRole
	 * @return
	 */
	private boolean content(AdminMenuResourceModel menuResourceModel,
			List<AdminMenuResourceModel> allMenuResourcesAsRole) {
		for (AdminMenuResourceModel menuResourceModelAsRole : allMenuResourcesAsRole) {
			if (menuResourceModelAsRole.getId() == menuResourceModel.getId()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 集合中是否已存在给菜单 菜单对象是否相等或菜单对象的id是否相等
	 * 
	 * @param menuResourceModels
	 * @param resourceModel
	 * @return
	 */
	private boolean hasMenuContent(List<AdminMenuResourceModel> menuResourceModels,
			AdminMenuResourceModel resourceModel) {

		for (AdminMenuResourceModel model : menuResourceModels) {
			if (model.getId().intValue() == resourceModel.getId().intValue()
					|| menuResourceModels.contains(resourceModel)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<AdminMenuResourceModel> getMenuPedigreeByActorId(AdminUserModel actor, Integer dataId, Integer type) {
		if (actor == null) {
			return new ArrayList<AdminMenuResourceModel>();
		}
		/**
		 * 1.根据actorId判断 actor是否是admin 是的话返回所有的 menu 2.不是的话根据
		 * actorId获取其角色来获取menu
		 */
		List<AdminMenuResourceModel> firstMenus = new ArrayList<AdminMenuResourceModel>();
		if ("admin".equals(actor.getUserAccount())) {
			// 获得所有的一级菜单
			AdminMenuResourceModel menuResourceModel = new AdminMenuResourceModel();
			menuResourceModel.setCategory(AdminMenuResourceModel.CATEGORY);
			menuResourceModel.setLevel(0);
			menuResourceModel.setType(type);
			List<AdminMenuResourceModel> firstMenuResourceModels = adminSecurityResourceDao
					.findMenuResources(menuResourceModel);
			for (AdminMenuResourceModel firstMenuResourceModel : firstMenuResourceModels) {
				if (!this.hasMenuContent(firstMenus, firstMenuResourceModel)) {
					firstMenus.add(firstMenuResourceModel);
				}
			}
			for (AdminMenuResourceModel firstMenu : firstMenus) {
				handleChilden(firstMenu, type);
			}
			return firstMenus;
		}
		List<AdminRoleModel> roleModels = adminAuthorityDao.queryGrantRolesByUserId(actor.getId(),
				AdminRoleModel.CATEGORY);
		/**
		 * 获得已授权的一级菜单数据
		 */
		for (AdminRoleModel roleModel : roleModels) {
			List<AdminMenuResourceModel> firstMenuResourceModels_temp = adminSecurityResourceDao
					.findMenuResourcesByRoleId(roleModel.getId(), AdminMenuResourceModel.CATEGORY, 0,
							MENU_STATUS_NOTDELETE);
			for (AdminMenuResourceModel temp_menu : firstMenuResourceModels_temp) {
				if (!this.hasMenuContent(firstMenus, temp_menu)) {
					firstMenus.add(temp_menu);
				}
			}
		}
		/**
		 * 组装一级菜单下的已授权的子菜单数据
		 */
		for (AdminMenuResourceModel firstMenu : firstMenus) {
			handleChildenMeusByRoleIds(firstMenu, roleModels, dataId);
		}
		return firstMenus;
	}

	// ****************************************************************************************************
	private void handleChilden(AdminMenuResourceModel menuModel, Integer type) {
		/**
		 * 1：获取所有的菜单数据 2：根据菜单的上下级关系组装菜单数据 3：递归子菜单
		 */
		List<AdminMenuResourceModel> childrenMenus = getChildenMeusByMenuId(menuModel.getId(), type);
		if (childrenMenus != null && childrenMenus.size() > 0) {
			menuModel.setChecked(true);
			menuModel.setChildren(childrenMenus);
//			for (AdminMenuResourceModel childMenu : childrenMenus) {
//				/**
//				 * 递归一下处理孙子以及以下的菜单
//				 */
//				this.handleChilden(childMenu, type);
//			}
		}
	}

	private List<AdminMenuResourceModel> getChildenMeusByMenuId(Integer menuId, Integer type) {
		List<AdminMenuResourceModel> result = new ArrayList<AdminMenuResourceModel>();
		List<AdminMenuResourceModel> temp_list = adminSecurityResourceDao.getChildMenu(menuId, MENU_STATUS_NOTDELETE,
				AdminMenuResourceModel.CATEGORY, type);
		for (AdminMenuResourceModel menu_temp : temp_list) {
			if (!this.hasMenuContent(result, menu_temp)) {
				result.add(menu_temp);
			}
		}
		return result;
	}

	// ********************************************************************************************
	/**
	 * 递归组装一级菜单下所有分配给角色的菜单数据
	 * 
	 * @param firstMenu
	 * @param roleModels
	 */
	private void handleChildenMeusByRoleIds(AdminMenuResourceModel menuModel, List<AdminRoleModel> roleModels,
			Integer dataId) {
		/**
		 * 1：根据角色数据获得所有的菜单数据 2：根据菜单的上下级关系组装菜单数据 3：递归子菜单
		 */
		List<AdminMenuResourceModel> childrenMenus = getChildenMeusByMenuIdRoles(menuModel.getId(), roleModels, dataId);
		if (childrenMenus != null && childrenMenus.size() > 0) {
			menuModel.setChecked(true);
			menuModel.setChildren(childrenMenus);
//			for (AdminMenuResourceModel childMenu : childrenMenus) {
//				/**
//				 * 递归一下处理孙子以及以下的菜单
//				 */
//				this.handleChildenMeusByRoleIds(childMenu, roleModels, dataId);
//			}
		}

	}

	/**
	 * 带权限查询子菜单 关于带权限子菜单数据的查询
	 * 根据角色id和菜单的id获得子菜单的数据，汇总成子菜单的一个集合，该集合需要验证子菜单是否已经存在，如果存在了就不添加了
	 * 因为多角色情况下不同的角色授权的菜单数据可能会重叠，需要判重操作
	 * 
	 * @param menuId
	 * @param roleModels
	 * @return
	 */
	private List<AdminMenuResourceModel> getChildenMeusByMenuIdRoles(Integer menuId, List<AdminRoleModel> roleModels,
			Integer dataId) {
		List<AdminMenuResourceModel> result = new ArrayList<AdminMenuResourceModel>();
		for (AdminRoleModel roleModel : roleModels) {
			List<AdminMenuResourceModel> temp_list = adminSecurityResourceDao.queryMenuResourcesByParentIdRoleId(menuId,
					roleModel.getId(), MENU_STATUS_NOTDELETE, AdminMenuResourceModel.CATEGORY);
			for (AdminMenuResourceModel menu_temp : temp_list) {
				if (!this.hasMenuContent(result, menu_temp)) {
					result.add(menu_temp);
				}
			}
		}
		return result;
	}

	@Override
	public Page<AdminMenuResourceModel> pagingqueryMenu(String menuName, Integer type, Integer pageIndex,
			Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;

		List<AdminMenuResourceModel> resourceModels = adminSecurityResourceDao.pagingqueryMenu(menuName,
				AdminMenuResourceModel.CATEGORY, type, MENU_STATUS_NOTDELETE, limit, pageSize);
		Integer totalCount = adminSecurityResourceDao.pagingqueryMenu_count(menuName, AdminMenuResourceModel.CATEGORY,
				type, MENU_STATUS_NOTDELETE);

		Page<AdminMenuResourceModel> menuPage = new Page<>(pageIndex, pageSize, totalCount);
		menuPage.setData(resourceModels);

		return menuPage;
	}

	/**
	 * 根据获取 叶子菜单
	 */
	@Override
	public List<AdminMenuResourceModel> getAllLeafMenu(Integer type) {
		List<AdminMenuResourceModel> leafMenus = new ArrayList<AdminMenuResourceModel>();
		List<AdminMenuResourceModel> menuResourceModels = adminSecurityResourceDao.getAllLeafMenu(type,
				AdminMenuResourceModel.CATEGORY);
		for (AdminMenuResourceModel menuResourceModel : menuResourceModels) {
			if (!this.hasMenuContent(leafMenus, menuResourceModel)) {
				leafMenus.add(menuResourceModel);
			}
		}
		return leafMenus;
	}

	@Override
	public List<AdminMenuResourceModel> getAllMenuPageUrl(Integer roleId, Integer dataId, Integer type) {
		/**
		 * 1：获得所有的一级菜单，一级菜单应该是不会有相关的页面和URL的配置 2：根据一级菜单获得子菜单（注意需要递归，因为菜单的层级不能确定）
		 * 3：处理子菜单，子菜单授权检查、页面元素和URL数据关联和授权检查
		 */
		List<AdminMenuResourceModel> topMenus = this.findTopMenuResources(type);
		for (AdminMenuResourceModel topMenu : topMenus) {
			topMenu.setChecked(this.isAssignmen(roleId, topMenu.getId(), dataId));
			this.handleChildMenu(topMenu, roleId, dataId, type);
		}
		return topMenus;
	}

	/**
	 * 子菜单数据以及相关数据的组装 1: 检查是否授权 2：页面元素和URL数据获得 3：检查页面和URL数据的授权
	 * 4：递归一下是否还有子菜单，基本上是不会有的
	 * 
	 * @param topMenu
	 * @param roleId
	 * @param dataId
	 */
	private void handleChildMenu(AdminMenuResourceModel topMenu, Integer roleId, Integer dataId, Integer type) {
		List<AdminMenuResourceModel> childMenus = this.getChildrenIsType(topMenu.getId(), type);
		for (AdminMenuResourceModel childMenu : childMenus) {
			List<AdminSecurityResourceModel> pageElementResourceModels = adminSecurityResourceDao
					.getAllByMenuId(childMenu.getId(), AdminPageElementResourceModel.CATEGORY, type);
			for (AdminSecurityResourceModel resourceModel : pageElementResourceModels) {
				resourceModel.setChecked(this.isAssignmen(roleId, resourceModel.getId(), dataId));
			}
			childMenu.setPageElements(pageElementResourceModels);

			// List<AdminSecurityResourceModel> urlAccessModels =
			// adminSecurityResourceDao
			// .getAllByMenuId(childMenu.getId(),
			// AdminUrlAccessResourceModel.CATEGORY, type);
			// for (AdminSecurityResourceModel resourceModel : urlAccessModels)
			// {
			// resourceModel.setChecked(this.isAssignmen(roleId,
			// resourceModel.getId(), dataId));
			// }
			// childMenu.setUrlAccess(urlAccessModels);
			childMenu.setChecked(this.isAssignmen(roleId, childMenu.getId(), dataId));
			List<AdminMenuResourceModel> sonMenus = this.getChildren(childMenu.getId());
			// 递归
			if (sonMenus != null && sonMenus.size() > 0) {
				for (AdminMenuResourceModel sonMenu : sonMenus) {
					this.handleChildMenu(sonMenu, roleId, dataId, type);
				}
				childMenu.setChildren(sonMenus);
			}
		}
		topMenu.setChildren(childMenus);
	}

	/**
	 * 数据授权验证
	 * 
	 * @param roleId
	 * @param resourceId
	 * @param dataId
	 * @return
	 */
	private boolean isAssignmen(Integer roleId, Integer resourceId, Integer dataId) {
		AdminResourceAssignmentModel assignmentModel = adminResourceAssignmentDao.getByDataIdAthourIdResourceId(dataId,
				roleId, resourceId);
		return assignmentModel != null;
	}

	/**
	 * 根据角色id 权限资源id 数据类型保存角色权限信息
	 * 
	 * @param roleId
	 * @param securityResourceIds
	 * @param dataId
	 */
	@Override
	public void saveMenuPageUrlToRole(Integer roleId, List<Integer> securityResourceIds, Integer dataId) {
		List<Integer> oldAminResourcesAssignment = adminResourceAssignmentDao
				.getAdminResourceAssignmentIdsByRoleId(dataId, roleId);
		if (!oldAminResourcesAssignment.isEmpty()) {
			// Map<String, Object> param = new HashMap<String, Object>();
			// param.put("authorityId", roleId);
			// param.put("securityResourceIds", oldAminResourcesAssignment);
			// adminResourceAssignmentDao.deleteAdminResourceAssignmentsByIds(oldAminResourcesAssignment);
			adminResourceAssignmentDao.deleteAdminResourceAssignmentsByAuthorityId(roleId);
		}
		if (securityResourceIds.size() > 0) {
			List<AdminResourceAssignmentModel> list = new ArrayList<>();
			for (Integer securityResourceId : securityResourceIds) {
				AdminResourceAssignmentModel resourceAssignmentModel = new AdminResourceAssignmentModel();
				resourceAssignmentModel.setAuthorityId(roleId);
				resourceAssignmentModel.setSecurityResourceId(securityResourceId);
				resourceAssignmentModel.setDataId(dataId);
				list.add(resourceAssignmentModel);
			}
			adminResourceAssignmentDao.creatAdminResourceAssignment(list);
		}

	}

	/**
	 * 递归查找菜单下所有的子菜单
	 * 
	 * @param parentId
	 * @return
	 */
	private List<AdminMenuResourceModel> getChildrenIsType(Integer parentId, Integer type) {
		List<AdminMenuResourceModel> result = adminSecurityResourceDao.getChildMenu(parentId, MENU_STATUS_NOTDELETE,
				AdminMenuResourceModel.CATEGORY, type);
		for (AdminMenuResourceModel menuResourceModel : result) {
			if (this.getChildrenIsType(menuResourceModel.getId(), type) != null
					&& this.getChildrenIsType(menuResourceModel.getId(), type).size() > 0) {
				menuResourceModel.setChildren(this.getChildrenIsType(menuResourceModel.getId(), type));
			}
		}
		return result;
	}

	@Override
	public void deleteAdminResourceAssignmentsByAuthorityId(Integer roleId) {
		adminResourceAssignmentDao.deleteAdminResourceAssignmentsByAuthorityId(roleId);
		
	}

}
