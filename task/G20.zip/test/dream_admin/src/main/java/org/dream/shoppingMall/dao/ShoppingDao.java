package org.dream.shoppingMall.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.shoppingMall.ShoppingModel;

public interface ShoppingDao {
	public List<ShoppingModel> findByPage(@Param("model") ShoppingModel model, @Param("offset") Integer offset,
			@Param("pageSize") Integer pageSize);

	public Integer findRows(@Param("model") ShoppingModel model);
}
