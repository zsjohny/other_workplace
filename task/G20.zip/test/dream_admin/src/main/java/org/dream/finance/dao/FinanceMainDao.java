package org.dream.finance.dao;

import org.dream.model.finance.FinanceMainModel;

public interface FinanceMainDao {

	public FinanceMainModel find(Integer userId);

	public void update(FinanceMainModel financeMainModel);
}
