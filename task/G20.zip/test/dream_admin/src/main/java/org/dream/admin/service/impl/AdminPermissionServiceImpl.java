package org.dream.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.admin.dao.AdminAuthorityDao;
import org.dream.admin.dao.AdminAuthorizationDao;
import org.dream.admin.dao.AdminRolePermissionsDao;
import org.dream.admin.model.AdminPerssionModel;
import org.dream.admin.service.AdminPermissionService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminPermissionServiceImpl implements AdminPermissionService {

    @Autowired
    AdminAuthorityDao adminAuthorityDao;
    
    @Autowired
    AdminRolePermissionsDao adminRolePermissionsDao;
    
    @Autowired
    AdminAuthorizationDao adminAuthorizationDao;
    @Override
    public void createPermission(AdminPerssionModel perssionModel) {
        
        adminAuthorityDao.createPermission(perssionModel);
    }

    @Override
    public void updatePermission(AdminPerssionModel perssionModel) {
        adminAuthorityDao.updatePermission(perssionModel);
    }

    @Override
    public Page<AdminPerssionModel> pagingQueryPermissions(Integer pageIndex,
            Integer pageSize, Map<String, Object> queryPermissionCondition) {
        /**
         * 分页偏移处理，这个是不是要放到Page中处理？？？
         */
        Integer limit = pageIndex  > 0 ? pageIndex* pageSize : 0 * pageSize;
        queryPermissionCondition.put("limit", limit);
        queryPermissionCondition.put("size", pageSize);
        
        List<AdminPerssionModel> perssionModels = adminAuthorityDao.pagingQueryPermissions(queryPermissionCondition);
        
        int count = adminAuthorityDao.pagingQueryPermissions_count(queryPermissionCondition);
        Page<AdminPerssionModel> result = new Page<AdminPerssionModel>(pageIndex, pageSize, count);
        result.setData(perssionModels);
        
        return result;
    }


    @Override
    public Page<AdminPerssionModel> pagingQueryGrantPermissionByUserId(Integer page,
            Integer pageSize, Integer actorId) {
        Integer limit = (page - 1) > 0 ? (page - 1) : 0 * pageSize;
        List<AdminPerssionModel> resultList = adminAuthorityDao.pagingQueryGrantPsemissionsByActorId(limit, pageSize, actorId, AdminPerssionModel.CATEGORY);
        Integer count = adminAuthorityDao.pagingQueryGrantPsemissionsByActorId_count(actorId, AdminPerssionModel.CATEGORY);
        
        Page<AdminPerssionModel> resultPage = new Page<AdminPerssionModel>(page, pageSize, count);
        resultPage.setData(resultList);
        return resultPage;
    }

    @Override
    public Page<AdminPerssionModel> pagingQueryNotGrantPermissionsByUserId(Integer page,
            Integer pageSize, Integer actorId) {
        Integer limit = (page - 1) > 0 ? (page - 1) : 0 * pageSize;
        List<AdminPerssionModel> resultList = adminAuthorityDao.pagingQueryNotGrantPsemissionByActorId(limit, pageSize, actorId, AdminPerssionModel.CATEGORY);
        Integer count = adminAuthorityDao.pagingQueryNotGrantPsemissionByActorId_count(actorId, AdminPerssionModel.CATEGORY);
        
        Page<AdminPerssionModel> resultPage = new Page<AdminPerssionModel>(page, pageSize, count);
        resultPage.setData(resultList);
        return resultPage;
    }

    @Override
    public void deletePermissionsByIds(List<Integer> idList, Integer dataId) {
        //删除角色权限关系数据
        adminRolePermissionsDao.delteRolePermissionByRoleIdPermissions(null, idList);
        //删除参与者授权关系数据
        adminAuthorizationDao.deleteAuthorizationByActorIdAuthorityIds(null, idList, dataId);
        
        adminAuthorityDao.deleteAuthoritysByIds(idList);
        
    }

    @Override
    public boolean hasPermissionByIdentifier(String identifier) {
        Map<String, Object> queryPermissionCondition = new HashMap<String, Object>();
        queryPermissionCondition.put("identifier", identifier);
        queryPermissionCondition.put("category", AdminPerssionModel.CATEGORY);

        return adminAuthorityDao.pagingQueryPermissions_count(queryPermissionCondition) > 0;
    }

}
