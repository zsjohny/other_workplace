package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.order.ChannelInvestorModel;
import org.dream.order.dao.ChannelInvestorDao;
import org.dream.order.service.ChannelInvestorService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChannelInvestorServiceImpl implements ChannelInvestorService {
	@Autowired
	ChannelInvestorDao channelInvestorDao;

	@Override
	public Map<String, Object> saveChannelInvestor(ChannelInvestorModel channelInvestorModel) {
		Map<String, Object> mapRet = new HashMap<String, Object>();
		// 首先根据一级渠道id和账号判断是否存在了该账号
		Integer count = channelInvestorDao.getCountByChannelIdAndInvestorAccount(channelInvestorModel);
		if (count > 0) {
			mapRet.put("retCode", "0");
			mapRet.put("retmsg", "该账号已经存在");
			return mapRet;
		}
		channelInvestorDao.saveChannelInvestor(channelInvestorModel);
		mapRet.put("retCode", "1");
		return mapRet;
	}

	@Override
	public Map<String, Object> updateChannelInvestor(ChannelInvestorModel channelInvestorModel) {
		Map<String, Object> mapRet = new HashMap<String, Object>();
		// 首先根据一级渠道id和账号判断是否存在了该账号
		Integer count = channelInvestorDao.getCountByChannelIdAndInvestorAccount(channelInvestorModel);
		if (count > 0) {
			mapRet.put("retCode", "0");
			mapRet.put("retmsg", "该账号已经存在");
			return mapRet;
		}
		channelInvestorDao.updateChannelInvestor(channelInvestorModel);
		mapRet.put("retCode", "1");
		return mapRet;
	}

	@Override
	public Page<ChannelInvestorModel> pagingQueryChannelInvestor(Integer page, Integer pageSize, Integer channelId) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("limit", limit);
		map.put("pageSize", pageSize);
		map.put("channelId", channelId);
		List<ChannelInvestorModel> data = channelInvestorDao.pagingQueryChannelInvestor(map);
		Integer totalCount = channelInvestorDao.pagingQueryChannelInvestorCount(map);
		Page<ChannelInvestorModel> pagelist = new Page<ChannelInvestorModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public void removeChannelInvestor(String ids) {
		String[] id = ids.split(",");
		channelInvestorDao.removeChannelInvestor(id);

	}

	@Override
	public ChannelInvestorModel getInfo(Integer id) {

		return channelInvestorDao.getInfoById(id);
	}

	@Override
	public List<ChannelInvestorModel> getAccountsByChannelId(Integer channelId) {
		return channelInvestorDao.getAccountsByChannelId(channelId);
	}

}
