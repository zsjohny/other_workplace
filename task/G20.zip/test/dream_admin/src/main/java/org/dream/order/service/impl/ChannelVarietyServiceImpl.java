package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.model.order.ChannelInvestorModel;
import org.dream.model.order.ChannelVarietyModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.dao.ChannelVarietyDao;
import org.dream.order.service.ChannelVarietyService;
import org.dream.utils.mvc.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class ChannelVarietyServiceImpl implements ChannelVarietyService {

	@Autowired
	RedisTemplate<String, Object> redisTemplate;

	@Autowired
	ChannelVarietyDao channelVarietyDao;

	private static Logger logger = LoggerFactory.getLogger(ChannelVarietyServiceImpl.class);

	public void insertChannelVariety(ChannelVarietyModel channelVarietyModel) {
		channelVarietyDao.insert(channelVarietyModel);
	}

	public void changeChannelVarietyStatusByIds(String ids, Integer status) {
		channelVarietyDao.changeChannelVarietyStatusByIds(this.handleIds(ids), status);
	}

	public List<ChannelVarietyModel> getChannelVarietyByChannelId(Integer channelId) {
		List<ChannelVarietyModel> list = channelVarietyDao.getChannelVarietyByChannelId(channelId);
		return list;
	}

	public void updateChannelVarietyCom(ChannelVarietyModel channelVarietyModel, Integer channelId, Integer varietyId) {
		// channelVarietyDao.updateChannelVarietyCom(channelVarietyModel);
		// key 一级渠道id
		// redisTemplate.opsForHash().put(ChannelVarietyModel.PLATFORM_COM,
		// channelId+"_"+varietyId,channelVarietyModel.getCom());

	}

	// public static void main(String[] args) {
	// ApplicationContext c = new
	// ClassPathXmlApplicationContext("classpath:/app*.xml");
	// RedisTemplate<String, Object> redisT = (RedisTemplate<String, Object>)
	// c.getBean("redisTemplate");
	// for (int channelId = 0; channelId < 100; channelId++) {
	// for (int varietyId = 0; varietyId < 100; varietyId++) {
	// if (redisT.opsForHash().get(ChannelVarietyModel.PLATFORM_COM, channelId +
	// "_" + varietyId) != null) {
	// redisT.opsForHash().delete(ChannelVarietyModel.PLATFORM_COM, channelId +
	// "_" + varietyId);
	// }
	// }
	// }
	// }

	private List<Integer> handleIds(String ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	public void updateChannelVarietyFees(ChannelVarietyModel channelVarietyModel, Integer channelId,
			Integer varietyId) {
		channelVarietyDao.updateChannelVarietyFees(channelVarietyModel);
		// 二级渠道id
		redisTemplate.opsForHash().put(ChannelVarietyModel.oneChannel_Fees, channelId + "_" + varietyId,
				channelVarietyModel.getFees());
	}

	public ChannelVarietyModel getChannelVarietyById(Integer id, Integer channelId, Integer varietyId) {
		return channelVarietyDao.getChannelVarietyById(id, channelId, varietyId);
	}

	public void removeVarietyByVarietyId(Integer id) {
		channelVarietyDao.removeVarietyByVarietyId(id);
	}

	@Override
	public Page<ChannelVarietyModel> qureypagingForFirstChannel(Integer channelId, Integer pageIndex,
			Integer pageSize) {

		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<ChannelVarietyModel> channelVarietyModels = channelVarietyDao.qureypagingForFirstChannel(channelId, limit,
				pageSize);
		int totalCount = channelVarietyDao.qureypaging_count(channelId);
		Page<ChannelVarietyModel> resultPage = new Page<ChannelVarietyModel>(pageIndex, pageSize, totalCount);
		resultPage.setData(channelVarietyModels);
		return resultPage;
	}

	@Override
	public void deleteChannelVarietiesByIds(String ids) {
		List<ChannelVarietyModel> list = channelVarietyDao.getChannelVarietyByIds(this.handleIds(ids));
		channelVarietyDao.deleteChannelVarietiesByIds(this.handleIds(ids));
		if (list != null && list.size() > 0) {
			for (ChannelVarietyModel vm : list) {
				redisTemplate.opsForHash().delete(ChannelVarietyModel.twoChannel_user_costs,
						vm.getChannelId() + "_" + vm.getVarietyId());
			}
		}

	}

	@Override
	public void deleteChannelVarietiesByVarietyId(Integer varietyId) {
		channelVarietyDao.deleteChannelVarietiesByVarietyId(varietyId);

	}

	@Override
	public List<TradingVarietyModel> getVarietyByChannelId(Integer channelId) {
		return channelVarietyDao.getVarietyByChannelId(channelId);
	}

	@Override
	public List<ChannelVarietyModel> findChannelVarietyModelAllByChannelId(Integer channelId) {
		return channelVarietyDao.findChannelVarietyModelAllByChannelId(channelId);
	}

	@Override
	public void openVarietyById(Integer id) {
		channelVarietyDao.openVarietyById(id);
	}

	@Override
	public void updateSecondChannelVariety(ChannelVarietyModel channelVarietyModel) {
		channelVarietyDao.updateSecondChannelVariety(channelVarietyModel);
		// key 二级渠道id
		redisTemplate.opsForHash().put(ChannelVarietyModel.twoChannel_user_costs,
				channelVarietyModel.getChannelId() + "_" + channelVarietyModel.getVarietyId(),
				channelVarietyModel.getUserCosts());
	}

	@Override
	public void updateFirstInvestorAccount(ChannelVarietyModel channelVarietyModel) {
		channelVarietyDao.updateFirstInvestorAccount(channelVarietyModel);
	}

	@Override
	public Page<ChannelVarietyModel> qureypagingSecondChannel(Integer channelId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<ChannelVarietyModel> channelVarietyModels = channelVarietyDao.qureypagingSecondChannel(channelId, limit,
				pageSize);
		int totalCount = channelVarietyDao.qureypaging_count(channelId);
		Page<ChannelVarietyModel> resultPage = new Page<ChannelVarietyModel>(pageIndex, pageSize, totalCount);
		resultPage.setData(channelVarietyModels);
		return resultPage;
	}

	@Override
	public List<TradingVarietyModel> getVarietyAndSignBySecondChannelId(Integer channelId) {
		return channelVarietyDao.getVarietyAndSignBySecondChannelId(channelId);
	}

	@Override
	public void updateRedisFirstInvestorAccount(Integer channelId, Integer varietyId, String investorAccount) {
		// 放入缓存
		if (redisTemplate.opsForHash().get(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT,
				channelId + "_" + varietyId) != null) {
			redisTemplate.opsForHash().delete(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT,
					channelId + "_" + varietyId);
		}
		redisTemplate.opsForHash().put(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT, channelId + "_" + varietyId,
				investorAccount);
	}

	@Override
	public void deleteRedisChannelFees(Integer id, Integer id2) {
		// 删除二级渠道的费用
		redisTemplate.opsForHash().delete(ChannelVarietyModel.oneChannel_Fees, id2 + "_" + id);
		// 删除二级渠道的对用户的费用
		redisTemplate.opsForHash().delete(ChannelVarietyModel.twoChannel_user_costs, id2 + "_" + id);
	}

}
