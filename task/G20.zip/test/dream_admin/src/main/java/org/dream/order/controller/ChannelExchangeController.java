package org.dream.order.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.ChannelExchangeModel;
import org.dream.model.order.FuturesExchangeModel;
import org.dream.order.service.ChannelExchangeService;
import org.dream.order.service.FuturesExchangeService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 一级渠道下的交易市场
 * 
 * @author ZY
 *
 */
@RequestMapping("/channelExchange")
@Controller
public class ChannelExchangeController extends BaseController {

	@Autowired
	private ChannelExchangeService channelExchangeService;

	@Autowired
	private ChannelService channelService;

	@Autowired
	private FuturesExchangeService futuresExchangeService;

	/**
	 * 通过渠道id分页获取该渠道下的交易市场
	 */
	@RequestMapping(value = "/querypagingByChannelId", method = { RequestMethod.POST })
	@ResponseBody
	public Response querypagingExchangesByChannelId(HttpServletRequest request, Integer channelId, Integer page,
			Integer pageSize) {
		// Assert.notNull(channelId, "渠道id不能为空");
		if (channelId == null) {
			ChannelModel channelModel = getCurrentChannel(request);
			channelId = channelModel.getId();
		}
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<ChannelExchangeModel> data = channelExchangeService.querypaging(channelId, page, pageSize);

		return Response.success(data);
	}

	/**
	 * 为某一级渠道添加交易市场
	 * 
	 * @param channelId
	 * @param ids
	 *            市场id的集合
	 * @return
	 */
	@RequestMapping(value = "/insertExchanges", method = { RequestMethod.POST })
	@ResponseBody
	public Response insertExchange(Integer channelId, String ids) {
		Assert.notNull(channelId, "渠道id不能为空");
		Assert.notNull(ids, "市场id不能为空");
		List<Integer> idList = handleIds(ids);

		for (Integer excId : idList) {
			FuturesExchangeModel exchangeModel = futuresExchangeService.getById(excId);
			ChannelExchangeModel channelExcModel = new ChannelExchangeModel();
			channelExcModel.setChannelId(channelId);
			channelExcModel.setChannelName(channelService.findChannelNameById(channelId));
			channelExcModel.setExchangeId(excId);
			channelExcModel.setExchangeName(exchangeModel.getExchangeName());
			channelExcModel.setExchangeCode(exchangeModel.getExchangeCode());
			channelExcModel.setIsDomestic(exchangeModel.getIsDomestic());
			channelExchangeService.insert(channelExcModel);

		}
		return Response.success();
	}

	private List<Integer> handleIds(String ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

}
