package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceTransferManageModel;

public interface FinanceProduceExcelDao {

	public List<FinanceFlowManageModel> findAllFlow(@Param("createTimeStart") String createTimeStart,
			@Param("createTimeEnd") String createTimeEnd, @Param("userId") Integer userId,
			@Param("userName") String userName, @Param("userPhone") String userPhone,
			@Param("channelId") Integer channelId, @Param("topChannelId") Integer topChannelId,
			@Param("type") Integer type, @Param("typeDetail") Integer typeDetail, @Param("remark") String remark,
			@Param("flow") String flow);

	public List<FinanceIOManageModel> findAllIO(@Param("model") FinanceIOManageModel model);

	public List<FinanceTransferManageModel> findAllTransfer(@Param("userId") Integer userId,
			@Param("userName") String userName, @Param("userPhone") String userPhone,
			@Param("realName") String realName, @Param("transferType") String transferType,
			@Param("status") Integer status, @Param("operator") String operator,
			@Param("createTimeStart") String createTimeStart, @Param("createTimeEnd") String createTimeEnd,
			@Param("updateTimeStart") String updateTimeStart, @Param("updateTimeEnd") String updateTimeEnd,
			@Param("topChannelId") Integer topChannelId);

}
