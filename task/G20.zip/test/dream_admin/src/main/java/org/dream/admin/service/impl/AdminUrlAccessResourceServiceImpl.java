package org.dream.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.admin.dao.AdminResourceAssignmentDao;
import org.dream.admin.dao.AdminSecurityResourceDao;
import org.dream.admin.model.AdminSecurityResourceModel;
import org.dream.admin.model.AdminUrlAccessResourceModel;
import org.dream.admin.service.AdminUrlAccessResourceService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 
 * @author wangd
 *
 */
@Service
public class AdminUrlAccessResourceServiceImpl implements AdminUrlAccessResourceService {

	@Autowired
	AdminSecurityResourceDao adminSecurityResourceDao;
	@Autowired
	AdminResourceAssignmentDao adminResourceAssignmentDao;

	@Override
	public void saveUrlAccess(AdminUrlAccessResourceModel accessResourceModel) {
		adminSecurityResourceDao.createUrlAccess(accessResourceModel);

	}

	@Override
	public void updateUrlAccess(AdminUrlAccessResourceModel accessResourceModel) {
		adminSecurityResourceDao.updateUrlAccess(accessResourceModel);

	}

	@Override
	public void deleteUrlAccess(List<Integer> ids) {
		for (Integer id : ids) {
			adminSecurityResourceDao.updateStatus(id);
			adminResourceAssignmentDao.deleteAdminResourceAssignmentsByAuthorityId(id);
		}
		
	}

	@Override
	public Page<AdminUrlAccessResourceModel> pagingQueryPermissions(Integer pageIndex, Integer pageSize,
			Map<String, Object> param) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		param.put("limit", limit);
		param.put("size", pageSize);

		List<AdminUrlAccessResourceModel> data = adminSecurityResourceDao.pagingQueryUrlAccess(param);
		int resultCount = adminSecurityResourceDao.pagingQueryUrlAccess_count(param);
		Page<AdminUrlAccessResourceModel> page = new Page<>(pageIndex, pageSize, resultCount);
		page.setData(data);
		return page;
	}

	@Override
	public void terminateUrlAccessResourcesFromRole(Integer roleId, List<Integer> urlAccessResourceIdList,
			Integer dataId) {

		adminResourceAssignmentDao.deleteAdminResourceAssignments(roleId, urlAccessResourceIdList, dataId);
	}

	@Override
	public boolean hasUrlAccessByUrlAddress(String url, Integer type) {

		Map<String, Object> param = new HashMap<String, Object>();

		param.put("url", url);
		param.put("type", type);
		param.put("category", AdminUrlAccessResourceModel.CATEGORY);

		return adminSecurityResourceDao.pagingQueryUrlAccess_count(param) > 0;
	}

	@Override
	public List<AdminUrlAccessResourceModel> getUrlAccessResourcesByActorId(Integer actorId, Integer dataId) {

		return adminSecurityResourceDao.getUrlAccessResourcesByActorId(actorId, AdminUrlAccessResourceModel.CATEGORY,
				dataId);
	}


	@Override
	public List<AdminUrlAccessResourceModel> getUrlAccessByRoleId(Integer roleId, Integer dataId) {
		List<AdminUrlAccessResourceModel> urlAccessModels = adminSecurityResourceDao
				.getAllUrlAccessByRoleId(AdminUrlAccessResourceModel.CATEGORY, roleId, dataId);
		List<AdminUrlAccessResourceModel> checkedUrlAccess = new ArrayList<AdminUrlAccessResourceModel>();
		for (AdminUrlAccessResourceModel urlAccessModel : urlAccessModels) {
			urlAccessModel.setChecked(true);
			checkedUrlAccess.add(urlAccessModel);
		}
		return checkedUrlAccess;
	}

	@Override
	public List<AdminSecurityResourceModel> getAllByMenuId(Integer menuId, String category, Integer type) {
		return adminSecurityResourceDao.getAllByMenuId(menuId, category, type);
	}

	@Override
	public List<AdminSecurityResourceModel> getSecurityResourcesByActorId(Integer actorId, Integer dataId,String category) {
		return adminSecurityResourceDao.getSecurityResourcesByActorId(actorId, dataId,category);
	}

}
