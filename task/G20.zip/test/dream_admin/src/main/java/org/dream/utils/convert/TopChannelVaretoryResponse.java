package org.dream.utils.convert;

/**
 * 用于一级渠道下市场的品种 返回状态的类
 * Created by nessary on 16-7-28.
 */
public class TopChannelVaretoryResponse {

    /**
     * 是否清仓 true是 false不是
     */
    private Boolean inventory;

    /**
     * 前台展示时间 格式 如 09:34:48
     */
    private String dateTime;

    /**
     * 前台展示周期 格式 周一到周日 0-6
     */
    private String dateWeek;

    /**
     * 品种Id
     */
    private Integer varietyId;

    /**
     * 市场Id
     */
    private Integer exchangeId;


    /**
     * 品种名称
     */
    private String varietyName;

    /**
     * 一级渠道时间表格Id
     */
    private Long topChannelId;

    /**
     * 品种设置清仓表格的Id
     */
    private Long varietyInventoryId;


    public Integer getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(Integer exchangeId) {
        this.exchangeId = exchangeId;
    }

    public Long getVarietyInventoryId() {
        return varietyInventoryId;
    }

    public void setVarietyInventoryId(Long varietyInventoryId) {
        this.varietyInventoryId = varietyInventoryId;
    }

    public Long getTopChannelId() {
        return topChannelId;
    }

    public void setTopChannelId(Long topChannelId) {
        this.topChannelId = topChannelId;
    }

    public String getDateWeek() {
        return dateWeek;
    }

    public void setDateWeek(String dateWeek) {
        this.dateWeek = dateWeek;
    }

    public Integer getVarietyId() {
        return varietyId;
    }

    public void setVarietyId(Integer varietyId) {
        this.varietyId = varietyId;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public Boolean getInventory() {
        return inventory;
    }

    public void setInventory(Boolean inventory) {
        this.inventory = inventory;
    }

    public void setInventory(boolean inventory) {
        this.inventory = inventory;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TopChannelVaretoryResponse)) return false;

        TopChannelVaretoryResponse that = (TopChannelVaretoryResponse) o;

        if (varietyId != null ? !varietyId.equals(that.varietyId) : that.varietyId != null) return false;
        if (exchangeId != null ? !exchangeId.equals(that.exchangeId) : that.exchangeId != null) return false;
        if (topChannelId != null ? !topChannelId.equals(that.topChannelId) : that.topChannelId != null) return false;
        return varietyInventoryId != null ? varietyInventoryId.equals(that.varietyInventoryId) : that.varietyInventoryId == null;

    }

    @Override
    public int hashCode() {
        int result = varietyId != null ? varietyId.hashCode() : 0;
        result = 31 * result + (exchangeId != null ? exchangeId.hashCode() : 0);
        result = 31 * result + (topChannelId != null ? topChannelId.hashCode() : 0);
        result = 31 * result + (varietyInventoryId != null ? varietyInventoryId.hashCode() : 0);
        return result;
    }
}
