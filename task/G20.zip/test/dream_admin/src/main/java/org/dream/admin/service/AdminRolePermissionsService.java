package org.dream.admin.service;

import java.util.List;

import org.dream.admin.model.AdminPerssionModel;
import org.dream.admin.model.AdminRolePermissionsModel;
import org.dream.utils.mvc.Page;

/**
 * 
 * @author SUNDONG_
 *
 */
public interface AdminRolePermissionsService
{
	/**
	 * 创建权限
	 * @param permissionsModel
	 */
	public void createRolePermissions(Integer roleId,Integer permissionsId);
	/**
	 * 更新权限
	 * @param permissionsModel
	 */
	public void updateRolePermissions(Integer roleId,Integer permissionsId);
	/**
	 * 获取一条权限数据
	 * @param PermissionsId
	 * @return
	 */
	public AdminRolePermissionsModel getPermissions(Integer PermissionsId);
	/**
	 * 获取一组权限数据
	 * @param roleId
	 * @return
	 */
	public List<AdminRolePermissionsModel> getPermissionsList(Integer roleId);
	/**
	 * 删除一条权限
	 * @param PermissionsId
	 */
	public void deletePermissions(Integer roleId);
	
	/**
	 * 根据页面元素Id获得授予页面元素的权限
	 * @param page
	 * @param pageSize
	 * @param pageElementId
	 * @return
	 */
	public Page<AdminPerssionModel> pagingQueryGrantPermissionsByPageElementResourceId(Integer page, Integer pageSize, Integer pageElementId);
}
