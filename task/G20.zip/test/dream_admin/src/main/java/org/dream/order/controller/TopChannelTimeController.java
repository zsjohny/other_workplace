package org.dream.order.controller;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.dream.admin.model.AdminUserModel;
import org.dream.model.order.TopChannelModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.TopChannelTimeService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.enums.TopChannelErrMsgEnum;
import org.dream.utils.mvc.Response;
import org.dream.utils.mvc.annotation.LimitLess;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 一级渠道下的修改所属时间
 * Created by nessary on 16-7-22.
 */
@Controller
@RequestMapping(value = "topChannel")
public class TopChannelTimeController {


    @Autowired
    private TopChannelTimeService topChannelTimeService;

    @Autowired
    private TradingVarietyService tradingVarietyService;

    //成功标识
    private static Integer SUCCESS_CODE = 200;

    //失败标识
    private static Integer ERROR_CODE = 500;

    //转换时间
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");

    /**
     * 修改一级渠道下市场对应时间信息
     *
     * @param request           Request请求
     * @param exchangeId        交易所Id
     * @param exchangeTime      交易所的时间
     * @param exchangeWeek      交易所的周期
     * @param exchangeStatus    交易所对应时间下的状态
     * @param topChannelModelId 交易所的对应的时间表的Id
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "modifyTopChannelTime", method = RequestMethod.POST)
    @LimitLess
    public Response modifyTopChannelTime(HttpServletRequest request, @RequestParam("exchangeId") Integer exchangeId,
                                         @RequestParam("exchangeTime") String exchangeTime, @RequestParam("exchangeWeek") String exchangeWeek, @RequestParam(value = "exchangeStatus", defaultValue = "true") String exchangeStatus,
                                         @RequestParam(value = "topChannelModelId", required = false) Long topChannelModelId, @RequestParam(value = "inventory", defaultValue = "false") String inventory,
                                         @RequestParam(value = "varietyInventoryId", required = false) Long varietyInventoryId, @RequestParam("varietyId") Integer varietyId) {


        //新增时间
        //获取当前用户所有所属渠道信息
        AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


        if (userModel == null) {
            //当前没有用户登录
            return Response.response(ERROR_CODE, "当前没用权限！!");

        }


        //成功
        String status = "ok";
        String msg = "新增成功!";
        int result = topChannelTimeService.modifyExchangeSechedulByExchangeId(userModel.getDataId(), exchangeId, exchangeTime, exchangeWeek, exchangeStatus, topChannelModelId, inventory, varietyId, varietyInventoryId);

        Boolean flag = StringUtils.isEmpty(TopChannelErrMsgEnum.getMsg(result)) ? true : false;

        if (flag && topChannelModelId != null) {
            msg = "修改成功!";
        } else if (!flag && topChannelModelId != null) {
            status = "false";
            msg = TopChannelErrMsgEnum.getMsg(result);
        } else if (!flag && topChannelModelId == null) {
            status = "false";
            msg = TopChannelErrMsgEnum.getMsg(result);
        }


        return Response.response(SUCCESS_CODE, msg, status);
    }


    /**
     * 用户获取当前渠道下所有的信息
     *
     * @param request Request请求
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "loadTopChannelTime", method = RequestMethod.POST)
    @LimitLess
    public Response loadTopChannelTime(HttpServletRequest request, @RequestParam(value = "page", defaultValue = "0", required = false) Integer start, @RequestParam(value = "pageSize", defaultValue = "3", required = false) Integer pageCount) {


        //获取当前用户所有所属渠道信息
        AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


        if (userModel == null) {
            //当前没有用户登录
            return Response.response(ERROR_CODE, "当前没用权限");

        }

        List<TopChannelModel> list = topChannelTimeService.findAllExchangeByExchangeId(userModel.getDataId(), start, pageCount);

        //空的集合
        String status = "false";

        JSONObject jsonobject = new JSONObject();

        if (list != null && list.size() != 0) {
            status = "ok";

            JSONArray array = new JSONArray();
            for (TopChannelModel topModel : list) {

                JSONObject json = new JSONObject();
                Integer exchangeId = topModel.getExchangeId();

                json.put("exchangeId", exchangeId);

                List<TradingVarietyModel> tradingVarietyModels = tradingVarietyService.getByExchangeId(exchangeId);


                String exchangeName = "";
                if (tradingVarietyModels != null && !tradingVarietyModels.isEmpty()) {

                    exchangeName = tradingVarietyModels.get(0).getExchangeName();
                }


                json.put("exchangeName", exchangeName);
                json.put("exchangeTime", simpleDateFormat.format(topModel.getExchangeTime()));
                json.put("exchangeWeek", topModel.getExchangeWeek());
                json.put("exchangeStatus", topModel.getExchangeStatus());
                json.put("varietyName", topModel.getVarietyName());
                json.put("varietyId", topModel.getVarietyId());
                json.put("inventory", topModel.getInventory());
                json.put("topChannelModelId", topModel.getId() == null ? "" : topModel.getId());
                array.add(json);
            }

            jsonobject.put("data", array);
            try {

                jsonobject.put("exchangeWeek", list.get(0).getExchangeWeek());
            } catch (Exception e) {

            }
            jsonobject.put("resultCount", list.get(0).getTotalCount());
            //添加页数
            jsonobject.put("total", (int) (Math.floor(pageCount / list.get(0).getTotalCount()) + 1));
        } else {
            list = new ArrayList<>();
            jsonobject.put("resultCount", 0);
            //添加页数
            jsonobject.put("total", 0);
        }


        jsonobject.put("start", start);
        jsonobject.put("pageSize", pageCount);


        return Response.response(SUCCESS_CODE, status, jsonobject);
    }


    /**
     * 删除用户读应的渠道信息
     *
     * @param request Request请求
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "removeTopChannelTimeById", method = RequestMethod.POST)
    @LimitLess
    public Response removeTopChannelTimeById(HttpServletRequest request, @RequestParam("exchangeId") Integer exchangeId, @RequestParam("topChannelModelId") Long topChannelModelId) {


        //获取当前用户所有所属渠道信息
        AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


        if (userModel == null) {
            //当前没有用户登录
            return Response.response(ERROR_CODE, "当前没用权限");

        }


        String status = "ok";

        boolean flag = topChannelTimeService.removeTopChannelTimeByIds(userModel.getDataId(), exchangeId, topChannelModelId);

        String msg = "删除成功!!";
        if (!flag) {
            status = "false";

            msg = "删除失败!!";
        }


        return Response.response(SUCCESS_CODE, msg, status);
    }


}
