package org.dream.sms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.sms.Sms;
import org.dream.model.sms.SmsTemplate;
import org.dream.sms.service.SmsTemplateService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 短信模板接口
 * 
 * @author zjj
 *
 */
@Controller
@RequestMapping(value = "/smsTemplate")
public class SmsTemplateController extends BaseController {

	@Autowired
	SmsTemplateService smsTemplateService;

	/**
	 * 添加短信模板
	 * 
	 * @param name
	 * @param template
	 * @return
	 */

	@RequestMapping(value = "/addTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response addTemplate(String name, String template, HttpServletRequest request) {
		SmsTemplate smsTemplate = new SmsTemplate();
		if (StringUtils.isBlank(name)) {
			return Response.error("添加短信名称不能为空");
		}
		if (StringUtils.isBlank(template)) {
			return Response.error("添加模板不能为空");
		}
		if (smsTemplateService.hasSmsTemplate(name, super.getDataId(request))) {
			return Response.error("已存在要添加的短信名称");
		}
		smsTemplate.setName(name);
		smsTemplate.setTemplate(template);
		smsTemplate.setChannelId(super.getDataId(request));
		smsTemplateService.addTemplate(smsTemplate);
		return Response.success();

	}

	/**
	 * 修改短信模板
	 * 
	 * @param id
	 * @param name
	 * @param template
	 * @return
	 */
	@RequestMapping(value = "/updateTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateTemplate(Integer id, String name, String template, HttpServletRequest request) {
		Assert.notNull(id, "需要修改的id不能为空");
		SmsTemplate smsTemplate = new SmsTemplate();
		smsTemplate.setId(id);
		if (StringUtils.isBlank(name)) {
			return Response.error("修改名字不能为空");
		}
		if (StringUtils.isBlank(template)) {
			return Response.error("修改模板不能为空");
		}
		if (smsTemplateService.hasSmsTemplate(name, super.getDataId(request))) {
			SmsTemplate temp = smsTemplateService.findTemplate(name, null, super.getDataId(request));
			if (temp.getId() != id) {
				return Response.error("已存在要修改的短信名称");
			}
		}
		smsTemplate.setName(name);
		smsTemplate.setTemplate(template);
		smsTemplateService.updateTemplate(smsTemplate);
		return Response.success();

	}

	/**
	 * 获取全部短信模板
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response getTemplate(HttpServletRequest request) {
		return Response.success(smsTemplateService.getTemplate(super.getDataId(request)));

	}

	/**
	 * 根据id获取短信模板
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getTemplateById", method = { RequestMethod.POST })
	@ResponseBody
	public Response getTemplateById(Integer id) {
		SmsTemplate smsTemplate = smsTemplateService.getById(id);
		return Response.success(smsTemplate);
	}

	/**
	 * 分页查询
	 * 
	 * @param page
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/pagingQuery", method = { RequestMethod.POST })
	@ResponseBody
	public Response queryPaging(String name, String template, Integer page, Integer pageSize,
			HttpServletRequest request) {
		Page<SmsTemplate> resultPage = smsTemplateService.pagingQuery(name, template, super.getDataId(request), page,
				pageSize);
		return Response.success(resultPage);
	}

	/**
	 * 通过改变isDelete来表示是否删除 进行软删除
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/remove", method = { RequestMethod.POST })
	@ResponseBody
	public Response remove(Integer id) {
		Assert.notNull(id, "需要删除的id不能为空");
		SmsTemplate smsTemplate = new SmsTemplate();
		smsTemplate.setId(id);
		smsTemplateService.remove(id);
		return Response.success();
	}

	@RequestMapping(value = "/getChannelTemplate", method = { RequestMethod.POST })
	@ResponseBody
	public Response getChannelTemplate() {
		Integer channelId = 0;
		List<SmsTemplate> resultPage = smsTemplateService.getTemplate(channelId);
		return Response.success(resultPage);
	}
}