package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.dream.model.order.VarietyPriceModel;

public interface VarietyPriceDao {
	void removeVarietyPrice(Integer id);

	int insertSelective(VarietyPriceModel record);

	VarietyPriceModel selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(VarietyPriceModel record);

	Map<String, Object> getVarietyNameAndTypeByVarietyId(Integer varietyId);

	List<VarietyPriceModel> pagingQueryVarietyPrice(Map map);

	int pagingQueryVarietyPriceCount(Map map);

	int getVarietyPriceCountById(Integer varietyId);

	List<Map<String, Object>> getVariety();

	public Integer getVarietyIdById(Integer id);

	public String getVarietyTypeByVarietyId(Integer varietyId);

}
