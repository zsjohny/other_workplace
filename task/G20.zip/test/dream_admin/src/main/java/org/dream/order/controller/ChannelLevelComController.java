package org.dream.order.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.order.ChannelLevelComModel;
import org.dream.model.order.ChannelVarietyModel;
import org.dream.order.service.ChannelLevelComService;
import org.dream.order.service.ChannelVarietyService;
import org.dream.order.service.VarietyPriceService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 渠道等级佣金 ZY
 *
 */
@RequestMapping("/channelLevelCom")
@Controller
public class ChannelLevelComController extends BaseController {
	@Autowired
	private ChannelLevelComService channelLevelComService;
	@Autowired
	private VarietyPriceService varietyPriceService;
	@Autowired
	private ChannelVarietyService channelVarietyService;

	/**
	 * 根据用户得到该用户下的渠道等级
	 * 
	 */
	@RequestMapping("/getChannelLevel")
	@ResponseBody
	public Response getChannelLevel(HttpServletRequest req) {
		List<Map<String, Object>> map = channelLevelComService.getChannelLevel(super.getCurrentChannel(req).getId());
		return Response.success(map);
	}

	/**
	 * 此接口为二级渠道上等级佣金配套币种符号的接口
	 */
	@RequestMapping("/getVariety")
	@ResponseBody
	public Response getVarietyAndSign(HttpServletRequest req) {
		return Response.success(
				channelVarietyService.getVarietyAndSignBySecondChannelId(super.getCurrentChannel(req).getId()));
	}

	@RequestMapping("/save")
	@ResponseBody
	public Response saveChannelLevelCom(ChannelLevelComModel channelLevelComModel, HttpServletRequest req) {
		// 根据当前渠道的id和品种获取它的用户佣金
		ChannelVarietyModel cvm = channelVarietyService.getChannelVarietyById(null,
				super.getCurrentChannel(req).getId(), channelLevelComModel.getVarietyId());
		if (cvm.getUserCosts() != null && cvm.getFees() != null) {
			// 先获取用户佣金字段值，与要新增的渠道等级佣金进行比较。
			Double m = cvm.getUserCosts();
			// 不能使渠道等级佣金大于用户佣金
			if (channelLevelComModel.getCom() > m) {
				return Response.response(700, "推广员佣金过大，请设定小于二级渠道佣金:" + m);
			}
		}
		Map<String, Object> map = channelLevelComService.saveChannelLevelCom(channelLevelComModel,
				(Integer) req.getSession().getAttribute("userId"), super.getCurrentChannel(req));
		if ("0".equals(map.get("retCode"))) {
			return Response.response(600, (String) map.get("retmsg"));
		}
		return Response.success();
	}

	@RequestMapping("/update")
	@ResponseBody
	public Response updateChannelLevelCom(ChannelLevelComModel channelLevelComModel, HttpServletRequest req) {
		ChannelLevelComModel clcm = channelLevelComService.getById(channelLevelComModel.getId());
		ChannelVarietyModel cvm = channelVarietyService.getChannelVarietyById(null, clcm.getChannelId(),
				clcm.getVarietyId());
		if (cvm.getUserCosts() != null && cvm.getFees() != null) {
			Double m = cvm.getUserCosts();
			if (channelLevelComModel.getCom() > m) {
				return Response.response(700, "推广员佣金过大，请设定小于二级渠道佣金:" + m);
			}
		}
		channelLevelComService.updateChannelLevelCom(channelLevelComModel,
				(Integer) req.getSession().getAttribute("userId"));
		return Response.success();

	}

	@RequestMapping("/remove")
	@ResponseBody
	public Response delChannelLevelCom(String id) {
		channelLevelComService.removeChannelLevelCom(id);
		return Response.success();
	}

	/**
	 * 查询
	 * 
	 */
	@RequestMapping("/pagingQuery")
	@ResponseBody
	public Response pagingQueryChannelLevelCom(Integer page, Integer pageSize, Integer levelId, Integer varietyId,
			String createTimeStart, String createTimeEnd, HttpServletRequest req) {
		Page<ChannelLevelComModel> data = channelLevelComService.pagingQueryChannelLevelCom(page, pageSize, levelId,
				varietyId, createTimeStart, createTimeEnd, super.getCurrentChannel(req).getId());
		return Response.success(data);
	}

	@RequestMapping("/getChannelLevelCom")
	@ResponseBody
	public Response getChannelLevelComById(Integer id) {
		ChannelLevelComModel c = channelLevelComService.getChannelLevelComById(id);
		return Response.success(c);
	}

}
