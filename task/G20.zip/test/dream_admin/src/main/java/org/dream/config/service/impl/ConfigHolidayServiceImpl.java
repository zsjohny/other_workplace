package org.dream.config.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.dream.config.dao.ConfigHolidayDao;
import org.dream.config.model.HolidayModel;
import org.dream.config.service.ConfigHolidayService;
import org.dream.utils.mvc.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class ConfigHolidayServiceImpl implements ConfigHolidayService {



    @Autowired
    ConfigHolidayDao configHolidayDao;


    @Override
    public void saveConfigHoliday(HolidayModel holidayModel) {


        configHolidayDao.createHoliday(holidayModel);

    }

    @Override
    public void updateConfigHoliday(HolidayModel holidayModel) {
        configHolidayDao.updateHoliday(holidayModel);

    }

    @Override
    public List<HolidayModel> getAllHolidays(Integer exchangeId, Integer status) {

        return configHolidayDao.getByExchangeId(exchangeId, status);
    }

    @Override
    public void delteHoliday(String ids) {
        if (StringUtils.isNotEmpty(ids)) {
            configHolidayDao.deleteByIds(this.handleIds(ids));
        }

    }

    @Override
    public Page<HolidayModel> querypaging(Integer exchangeId, Integer status, Integer pageIndex, Integer pageSize) {
        Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
        List<HolidayModel> list = configHolidayDao.querypaging(exchangeId, status, limit, pageSize);
        Integer totalCount = configHolidayDao.querypaging_count(exchangeId, status);
        Page<HolidayModel> page = new Page<HolidayModel>(pageIndex, pageSize, totalCount);

        page.setData(list);
        return page;
    }

    private List<Integer> handleIds(String ids) {
        List<Integer> result = new ArrayList<Integer>();
        String[] temp_id = ids.split(",");
        for (int i = 0; i < temp_id.length; i++) {
            result.add(Integer.valueOf(temp_id[i]));
        }
        return result;
    }

    @Override
    public void saveConfigHolidays(List<HolidayModel> holidayModels) {

        for (HolidayModel holidayModel : holidayModels) {
            this.saveConfigHoliday(holidayModel);
        }

    }
}
