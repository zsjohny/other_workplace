package org.dream.order.service;

import org.dream.model.order.ExchangeTimeModel;
import org.dream.model.order.TopChannelModel;
import org.dream.model.order.VarietyPriceModel;
import org.dream.utils.convert.TopChannelVaretoryResponse;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 一级渠道下的业务层的接口
 * Created by nessary on 16-7-22.
 */

public interface TopChannelTimeService {

    int modifyExchangeSechedulByExchangeId(Integer topChannelId, Integer exchangeId, String exchangeTime, String exchangeWeek, String exchangeStatus, Long topChannelModelId, String inventory, Integer varietyId, Long varietyInventoryId);

    List<TopChannelModel> findAllExchangeByExchangeId(Integer topChannelId, Integer start, Integer pageCount);

    boolean removeTopChannelTimeByIds(Integer topChannelId, Integer exchangeId, Long topChannelModelId);


}
