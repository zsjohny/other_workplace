package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceCommissionIOService;
import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceCommissionIOController extends BaseController {
	@Autowired
	private FinanceCommissionIOService commissionIOService;

	@RequestMapping("/findCommissionIOByPage")
	@ResponseBody
	public Response findCommissionIOByPage(FinanceCommissionIOModel commissionIOModel, Integer page, Integer pageSize,
			HttpServletRequest request) {
		Integer channelId = getDataId(request);
		commissionIOModel.setChannelId(channelId);
		return commissionIOService.findCommissionIOByPage(commissionIOModel, page, pageSize);
	}

	@RequestMapping("/updateCommissionIO")
	@ResponseBody
	public Response updateCommissionIO(String ioIds, Integer status) {
		return commissionIOService.updateCommissionIO(ioIds, status);
	}
}
