package org.dream.finance.service.impl;

import java.util.List;

import org.dream.finance.dao.FinanceProduceExcelDao;
import org.dream.finance.service.FinanceProduceExcelService;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceProduceExcelServiceImpl implements FinanceProduceExcelService {

	@Autowired
	FinanceProduceExcelDao financeProduceExcelDao;

	@Override
	public List<FinanceFlowManageModel> findAllFlow(String createTimeStart, String createTimeEnd, Integer userId,
			String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, String flow) {
		return financeProduceExcelDao.findAllFlow(createTimeStart, createTimeEnd, userId, userName, userPhone,
				channelId, topChannelId, type, typeDetail, remark, flow);
	}

	@Override
	public List<FinanceIOManageModel> findAllIO(FinanceIOManageModel model) {
		return financeProduceExcelDao.findAllIO(model);
	}

	@Override
	public List<FinanceTransferManageModel> findAllTransfer(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId) {
		return financeProduceExcelDao.findAllTransfer(userId, userName, userPhone, realName, transferType, status,
				operator, createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd, topChannelId);

	}

}
