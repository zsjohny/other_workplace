package org.dream.config.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 手续费配置
 * @author wangd
 *
 */
public class BrokerageModel implements Serializable {

    private static final long serialVersionUID = -3310328900744319235L;

    private Integer id;
    /**
     * 品种Id
     */
    private Integer varietyId;
    /**
     * 品种名称
     */
    private String varietyName;
    /**
     * 品种编码
     */
    private String varietyCode;
    /**
     * 资金类型
     * 0：现金 1： 积分
     */
    private Integer bankrollType = 0;
    /**
     * 手数
     */
    private Integer transactionsNum;
    /**
     * 保证金
     */
    private Double cashFund;
    /**
     * 应扣手续费
     */
    private Double theoryCounterFee;
    /**
     * 是否是默认
     * true：是；false：否
     */
    private Boolean isDefault = true;
    /**
     * 止盈设置
     */
    private String maxProfit;
    /**
     * 默认止盈
     */
    private Integer defaultProfit;
    
    /**
     * 止损设置
     */
    private String maxLoss;
    /**
     * 触发止损
     */
    private Integer defaultLoss;
    /**
     * 状态
     * 1： 可买；0：不可买 
     */
    private Integer status = 1;
    /**
     * 可买手数
     * 可买手数为多种情况，如：1，2，5，10表示可以买1手、2手、5手和10手
     */
    private String multiple;
    /**
     * 币种
     * CNY：人民币
     * USD：美元
     * HKD：港币
     */
    private String currency;
    /**
     * 创建时间
     */
    private Timestamp createDate;
    
    /**
     * 最后修改时间
     */
    private Timestamp lastUpdateDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getVarietyId() {
        return varietyId;
    }

    public void setVarietyId(Integer varietyId) {
        this.varietyId = varietyId;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public String getVarietyCode() {
        return varietyCode;
    }

    public void setVarietyCode(String varietyCode) {
        this.varietyCode = varietyCode;
    }

    public Integer getBankrollType() {
        return bankrollType;
    }

    public void setBankrollType(Integer bankrollType) {
        this.bankrollType = bankrollType;
    }

    public Integer getTransactionsNum() {
        return transactionsNum;
    }

    public void setTransactionsNum(Integer transactionsNum) {
        this.transactionsNum = transactionsNum;
    }

    public Double getCashFund() {
        return cashFund;
    }

    public void setCashFund(Double cashFund) {
        this.cashFund = cashFund;
    }

    public Double getTheoryCounterFee() {
        return theoryCounterFee;
    }

    public void setTheoryCounterFee(Double theoryCounterFee) {
        this.theoryCounterFee = theoryCounterFee;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getMaxProfit() {
        return maxProfit;
    }

    public void setMaxProfit(String maxProfit) {
        this.maxProfit = maxProfit;
    }


    public Integer getDefaultProfit() {
        return defaultProfit;
    }

    public void setDefaultProfit(Integer defaultProfit) {
        this.defaultProfit = defaultProfit;
    }

    public String getMaxLoss() {
        return maxLoss;
    }

    public void setMaxLoss(String maxLoss) {
        this.maxLoss = maxLoss;
    }

    public Integer getDefaultLoss() {
        return defaultLoss;
    }

    public void setDefaultLoss(Integer defaultLoss) {
        this.defaultLoss = defaultLoss;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMultiple() {
        return multiple;
    }

    public void setMultiple(String multiple) {
        this.multiple = multiple;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Timestamp lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }
    
    
    
}
