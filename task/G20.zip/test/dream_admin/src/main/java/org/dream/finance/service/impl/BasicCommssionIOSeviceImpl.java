package org.dream.finance.service.impl;

import java.util.List;

import org.dream.channel.dao.ChannelPromoterDao;
import org.dream.finance.dao.FinanceCommissionIODao;
import org.dream.finance.dao.FinanceFlowDao;
import org.dream.finance.dao.FinanceMainDao;
import org.dream.finance.service.BasicCommissionIOService;
import org.dream.model.channel.ChannelPromoterModel;
import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.utils.constants.FinanceCommissionType;
import org.dream.utils.math.Arith;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BasicCommssionIOSeviceImpl implements BasicCommissionIOService {
	private static final Integer SUCCEED_CODE = 200;
	private static final Integer ERROR_CODE = 600;
	@Autowired
	private FinanceCommissionIODao commissionIODao;
	@Autowired
	private ChannelPromoterDao promoterDao;
	@Autowired
	private FinanceMainDao mainDao;
	@Autowired
	private FinanceFlowDao flowDao;

	@Override
	public Response findCommissionIOByPage(FinanceCommissionIOModel commissionIOModel, Integer page, Integer pageSize) {
		Integer offset = page > 0 ? page * pageSize : 0;
		List<FinanceCommissionIOModel> list = commissionIODao.findByPage(commissionIOModel, offset, pageSize);
		Integer rows = commissionIODao.findRows(commissionIOModel);
		Page<FinanceCommissionIOModel> pageCommissionIO = new Page<>(offset, pageSize, rows);
		pageCommissionIO.setData(list);
		return Response.response(SUCCEED_CODE, "查询成功", pageCommissionIO);
	}

	@Override
	public Response updateCommissionIO(List<Integer> list, Integer status) {
		List<FinanceCommissionIOModel> models = commissionIODao.findByIds(list);
		for (FinanceCommissionIOModel model : models) {
			if (model.getStatus() != 0) {
				continue;
			}
			ChannelPromoterModel promoterModel = new ChannelPromoterModel();
			promoterModel.setUserId(model.getUserId());
			promoterModel.setFrozenCom(model.getMoney());
			if (status == 1) {
				promoterModel.setCurrentCom(model.getMoney());
			} else if (status == 2) {
				FinanceMainModel mainModel = mainDao.find(model.getUserId());
				Double moneyUsable = Arith.add(mainModel.getMoneyUsable(), model.getMoney());
				mainModel.setMoneyUsable(moneyUsable);
				mainModel.setMoneyDrawUsable(moneyUsable);
				mainDao.update(mainModel);
				FinanceFlowModel flowModel = new FinanceFlowModel();
				flowModel.setUserId(model.getUserId());
				flowModel.setType(FinanceCommissionType.COMMISSION_CARRYOVER.getType());
				flowModel.setTypeDetail(FinanceCommissionType.COMMISSION_CARRYOVER.getTypeDetail());
				flowModel.setRemark(FinanceCommissionType.COMMISSION_CARRYOVER.getRemark());
				flowModel.setMoney(model.getMoney());
				flowModel.setRedbag(0.0);
				flowModel.setMoneyLeft(moneyUsable);
				flowModel.setRedbagLeft(mainModel.getRedbagUsable());
				flowModel.setIoOrderId(model.getId());
				flowDao.save(flowModel);
			}
			promoterDao.update(promoterModel);
		}
		commissionIODao.update(list, status);
		return Response.response(SUCCEED_CODE, "更新佣金转出状态成功");
	}

}
