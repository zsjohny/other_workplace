package org.dream.config.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.config.model.HolidayModel;

/**
 * 假期配置
 * 
 * @author wangd
 *
 */
public interface ConfigHolidayDao {

    public void createHoliday(HolidayModel holidayModel);

    public void updateHoliday(HolidayModel holidayModel);

    /**
     * 获得全部的假期配置
     * 
     * @param status
     *            假期状态，为空则查询全部假期
     * @return
     */
    public List<HolidayModel> getAll(@Param(value = "status") Integer status);

    /**
     * 根据市场id，查询全部的假期配置
     * 
     * @param exchangeId
     * @param status
     * @return
     */
    public List<HolidayModel> getByExchangeId(@Param(value = "exchangeId") Integer exchangeId,
	    @Param(value = "status") Integer status);

    /**
     * 删除
     * 
     * @param ids
     *            要删除的id，不能为空
     */
    public void deleteByIds(@Param(value = "ids") List<Integer> ids);

    /**
     * 分页查询
     * 
     * @param exchangeId
     * @param status
     * @param limit
     * @param size
     * @return
     */
    public List<HolidayModel> querypaging(@Param(value = "exchangeId") Integer exchangeId,
	    @Param(value = "status") Integer status, @Param(value = "limit") Integer limit,
	    @Param(value = "size") Integer size);

    public int querypaging_count(@Param(value = "exchangeId") Integer exchangeId,
	    @Param(value = "status") Integer status);
}
