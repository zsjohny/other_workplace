package org.dream.order.controller;

import java.util.Map;

import org.dream.model.order.FuturesExchangeModel;
import org.dream.order.service.FuturesExchangeService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/futuresExchange")
public class FuturesExchangeController {

	@Autowired
	private FuturesExchangeService futuresExchangeService;

	/**
	 * 保存期货交易所
	 * 
	 * @param exchangeName
	 * @param exchangeCode
	 * @param futuresRemark
	 * @param statusDesc
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	@ResponseBody
	public Response addFuturesExchange(String exchangeName, String exchangeCode, String futuresRemark,
			Integer statusDesc, Integer isDomestic, String exchangeTimes) {

		Assert.notNull(exchangeName, "交易所名称不能为空");
		Assert.notNull(exchangeCode, "交易所编码不能为空");
		Assert.notNull(futuresRemark, "描述不能为空");
		Assert.notNull(statusDesc, "交易所状态不能为空");
		Assert.notNull(isDomestic, "国际国内不能为空");
		FuturesExchangeModel exchangeModel = new FuturesExchangeModel();

		exchangeModel.setExchangeName(exchangeName);
		exchangeModel.setExchangeCode(exchangeCode);
		exchangeModel.setFuturesRemark(futuresRemark);
		exchangeModel.setStatusDesc(statusDesc);
		exchangeModel.setIsDomestic(isDomestic);
		exchangeModel.setStatus(1);
		exchangeModel.setExchangeTimes(exchangeTimes);
		Map<String,Object> map = futuresExchangeService.createFutruresExchange(exchangeModel);
		if("0".equals(map.get("retCode"))){
			return Response.response(600, (String)map.get("retmsg"));
		}
		return Response.success();
	}

	/**
	 * 获得所有的交易所
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/getExchangeForSelect", method = { RequestMethod.POST })
	@ResponseBody
	public Response getExchangeForSelect() {

		return Response.success(futuresExchangeService.getExchangeForSelect());
	}

	/**
	 * 获得所有的交易所
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/getAll", method = { RequestMethod.POST })
	@ResponseBody
	public Response getAllExchanges() {

		return Response.success(futuresExchangeService.getAll());
	}

	/**
	 * 修改交易所信息 如果期货交易所的状态发生改变，则应当在redis中将期货交易所的状态改变
	 * 
	 * @param id
	 * @param exchangeName
	 * @param exchangeCode
	 * @param futuresRemark
	 * @param statusDesc
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/update")
	@ResponseBody
	public Response updateFuturesExchange(Integer id, String exchangeName, String exchangeCode, String futuresRemark,
			Integer statusDesc, String exchangeTimes,Integer isDomestic) {
		Assert.notNull(id, "要修改的交易所id不能为空");
		Assert.notNull(statusDesc, "交易所状态不能为空");
		FuturesExchangeModel exchangeModel = new FuturesExchangeModel();
		exchangeModel.setId(id);
		exchangeModel.setExchangeName(exchangeName);
		exchangeModel.setExchangeCode(exchangeCode);
		exchangeModel.setFuturesRemark(futuresRemark);
		exchangeModel.setStatusDesc(statusDesc);
		exchangeModel.setExchangeTimes(exchangeTimes);
		exchangeModel.setIsDomestic(isDomestic);
		futuresExchangeService.updateFutureExchange(exchangeModel);
		return Response.success();
	}

	/**
	 * 软删除期货市场 同时需要在redis中删除该期货市场
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/removeByIds", method = { RequestMethod.POST })
	@ResponseBody
	public Response removeFutruresExchangeByIds(String ids) {
		futuresExchangeService.removeFutruresExchangeByIds(ids);
		return Response.success();
	}

	/**
	 * 分页多条件查询
	 * 
	 * @param exchangeName
	 * @param exchangeCode
	 * @param futuresRemark
	 * @param pageindex
	 * @param pagesize
	 * @return
	 */
	@RequestMapping(value = "/querypaging")
	@ResponseBody
	public Response queryPagingFuturesExchange(String exchangeName, String exchangeCode, String futuresRemark,
			Integer page, Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<FuturesExchangeModel> data = futuresExchangeService.querypaging(exchangeName, exchangeCode, futuresRemark,
				page, pageSize);

		return Response.success(data);
	}

}
