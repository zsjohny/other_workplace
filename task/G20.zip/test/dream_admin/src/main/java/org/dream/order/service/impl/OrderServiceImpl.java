package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.OrderCashCount;
import org.dream.model.order.OrderModel;
import org.dream.model.order.OrderModel.OrderDirection;
import org.dream.model.order.OrderModel.OrderStatus;
import org.dream.model.order.OrderSunModel;
import org.dream.model.order.VarietyPriceModel;
import org.dream.model.quota.Quota;
import org.dream.model.quota.SimpleQuota;
import org.dream.order.dao.OrderDao;
import org.dream.order.service.OrderService;
import org.dream.utils.http.HttpTools;
import org.dream.utils.math.Arith;
import org.dream.utils.mvc.Page;
import org.dream.utils.prop.SpringProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderDao orderDao;

	@Autowired
	SpringProperties springProperties;

	private static final String POSITIONFAILURE_URL = "order/order/userPositionFailure.do";

	private static final String POSITION_URL = "order/order/userPosition.do";

	private static final String UNWINDFAILURE_URL = "order/order/userUnwindFailure.do";

	private static final String UNWIND_URL = "order/order/userUnwind.do";

	private static final String BATCH_FAILURE = "order/order/batchFailure.do";

	private static final String BATCH_SUCCESS = "order/order/batchSuccess.do";
	
	private static final String OPSITION_SETTLE="order/order/opsitionSettle.do";
	
	private static final String OPSITION_RISK_UNWIND="order/order/opsitionRiskUnwind.do";

	private static final int MARKET_CHECk_TIME = 6000;

	@Autowired
	RedisTemplate<String, Object> redisTemplate;

	private static Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Override
	public Page<OrderSunModel> queryIntegralOrderList(OrderSunModel ordersun, ChannelModel cm) {
		// 首先判断channelModel是否是一级渠道还是二级渠道，还是平台
		if (cm.getLevel() == 1) {
			// 一级渠道只能看自己渠道的下的二级渠道
			ordersun.setOneChannelId(cm.getId());
		} else if (cm.getLevel() == 2) {
			// 二级渠道只能看自己的，一级渠道和二级渠道，
			ordersun.setChannelId(cm.getId());
			ordersun.setOneChannelId(cm.getSuperId());
		}
		Integer pageSize = ordersun.getPageSize() == null ? Page.DEFAULE_PAGESIZE : ordersun.getPageSize();
		Integer page = ordersun.getPage() == null ? 0 : ordersun.getPage();
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;
		ordersun.setLimit(limit);
		ordersun.setPageSize(pageSize);
		List<OrderSunModel> data = orderDao.queryIntegralOrderList(ordersun);
		if (data != null && data.size() > 0) {
			// 如果是持仓和平仓处理中的订单要计算盈亏浮动
			for (OrderSunModel sunModel : data) {
				if (sunModel.getOrderStatus() == OrderStatus.POSITION.value) {
					// 计算盈亏
					getFloatWinOrLoss(sunModel);
				}
			}
		}
		int totalCount = orderDao.queryIntegralOrderCount(ordersun);
		Page<OrderSunModel> pagelist = new Page<OrderSunModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public List<Map<String, Object>> getVarietyIdAndVarietyName() {

		return orderDao.getVarietyIdAndVarietyName();
	}

	@Override
	public OrderSunModel getOrderSunModelByIdForIntegral(int id) {

		return orderDao.getOrderSunModelByIdForIntegral(id);
	}

	@Override
	public OrderSunModel getOrderSunModelByIdForCash(int id) {

		return orderDao.getOrderSunModelByIdForCash(id);
	}

	@Override
	public Page<OrderSunModel> queryCashOrderList(OrderSunModel ordersun, ChannelModel cm) {
		// 首先判断channelModel是否是一级渠道还是二级渠道，还是平台
		if (cm.getLevel() == 1) {
			// 一级渠道只能看自己渠道的下的二级渠道
			ordersun.setOneChannelId(cm.getId());
		} else if (cm.getLevel() == 2) {
			// 二级渠道只能看自己的，一级渠道和二级渠道，
			ordersun.setChannelId(cm.getId());
			ordersun.setOneChannelId(cm.getSuperId());
		}
		Integer pageSize = ordersun.getPageSize() == null ? Page.DEFAULE_PAGESIZE : ordersun.getPageSize();
		Integer page = ordersun.getPage() == null ? 0 : ordersun.getPage();
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;
		ordersun.setLimit(limit);
		ordersun.setPageSize(pageSize);
		List<OrderSunModel> data = orderDao.queryCashOrderList(ordersun);
		if (data != null && data.size() > 0) {
			// 如果是持仓和平仓处理中的订单要计算盈亏浮动
			for (OrderSunModel sunModel : data) {
				if (sunModel.getOrderStatus() == OrderStatus.POSITION.value) {
					// 计算盈亏
					getFloatWinOrLoss(sunModel);
				}
			}
		}
		int totalCount = orderDao.queryCashOrderCount(ordersun);
		Page<OrderSunModel> pagelist = new Page<OrderSunModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public Map<String, Object> dealWithPositionFailure(int id, int oneChannelId) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		// 首先判断该订单id的账户是否在该用户的渠道下
		if (oneChannelId != 0) {
			int count = orderDao.getCountByIdAndOneChannelId(id, oneChannelId);
			if (count == 0) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", "非法操作");
				logger.error("人工持仓失败处理,订单和渠道不匹配,orderId={},oneChannelId={}", id, oneChannelId);
				return retMap;
			}
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", String.valueOf(id));
		String str = null;
		try {
			// 调用订单模块
			str = HttpTools.doPost(springProperties.getProperty("sys.host") + POSITIONFAILURE_URL, map);
			JSONObject json = JSON.parseObject(str);
			if (json.getInteger("code") != 200) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", json.getString("msg"));
				return retMap;
			}

		} catch (Exception e) {
			logger.error("后台用户处理已支付待持仓订单,发起退款和修改订单状态为失败,调用订单模块的时候出错:e={},orderId={}", e, id);
			throw new RuntimeException();
		}
		retMap.put("retCode", "1");
		return retMap;
	}

	@Override
	public Map<String, Object> dealWithPosition(int id, String realAvgPrice, int realHandsNum, String time,
			int oneChannelId) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		// 首先判断该订单id的账户是否在该用户的渠道下
		if (oneChannelId != 0) {
			int count = orderDao.getCountByIdAndOneChannelId(id, oneChannelId);
			if (count == 0) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", "非法操作");
				logger.error("人工持仓处理,订单和渠道不匹配,orderId={},oneChannelId={}", id, oneChannelId);
				return retMap;
			}
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", String.valueOf(id));
		map.put("realAvgPrice", realAvgPrice);
		map.put("realHandsNum", String.valueOf(realHandsNum));
		map.put("time", time);
		String str = null;
		try {
			// 调用订单模块
			str = HttpTools.doPost(springProperties.getProperty("sys.host") + POSITION_URL, map);
			JSONObject json = JSON.parseObject(str);
			if (json.getInteger("code") != 200) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", json.getString("msg"));
				return retMap;
			}

		} catch (Exception e) {
			logger.error("后台用户处理已支付待持仓订单,发起持仓请求,调用订单模块的时候出错:e={},orderId={}", e, id);
			throw new RuntimeException();
		}
		retMap.put("retCode", "1");
		return retMap;
	}

	@Override
	public Map<String, Object> dealWithUnwindProcessFailure(int id, int oneChannelId) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		if (oneChannelId != 0) {
			// 首先判断该订单id的账户是否在该用户的渠道下
			int count = orderDao.getCountByIdAndOneChannelId(id, oneChannelId);
			if (count == 0) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", "非法操作");
				logger.error("人工平仓处理中失败处理,退回持仓中功能,订单和渠道不匹配,orderId={},oneChannelId={}", id, oneChannelId);
				return retMap;
			}
		}

		Map<String, String> map = new HashMap<String, String>();
		map.put("id", String.valueOf(id));
		String str = null;
		try {
			// 调用订单模块
			str = HttpTools.doPost(springProperties.getProperty("sys.host") + UNWINDFAILURE_URL, map);
			JSONObject json = JSON.parseObject(str);
			if (json.getInteger("code") != 200) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", json.getString("msg"));
				return retMap;
			}

		} catch (Exception e) {
			logger.error("后台用户处理平仓处理中订单,发起持仓请求,调用订单模块的时候出错:e={},orderId={}", e, id);
			throw new RuntimeException();
		}
		retMap.put("retCode", "1");
		return retMap;
	}

	@Override
	public Map<String, Object> dealWithUnwind(int id, String unwindAvgPrice, String time, int unwindType,
			int oneChannelId,String userAccount) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		if (oneChannelId != 0) {
			// 首先判断该订单id的账户是否在该用户的渠道下
			int count = orderDao.getCountByIdAndOneChannelId(id, oneChannelId);
			if (count == 0) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", "非法操作");
				logger.error("人工平仓处理中,结算成功功能,订单和渠道不匹配,orderId={},oneChannelId={}", id, oneChannelId);
				return retMap;
			}
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", String.valueOf(id));
		map.put("unwindAvgPrice", unwindAvgPrice);
		map.put("time", time);
		map.put("unwindType", String.valueOf(unwindType));
		map.put("userAccount", userAccount);
		String str = null;
		try {
			// 调用订单模块
			str = HttpTools.doPost(springProperties.getProperty("sys.host") + UNWIND_URL, map);
			JSONObject json = JSON.parseObject(str);
			if (json.getInteger("code") != 200) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", json.getString("msg"));
				return retMap;
			}

		} catch (Exception e) {
			logger.error("后台用户处理已支付待持仓订单,发起持仓请求,调用订单模块的时候出错:e={},orderId={}", e, id);
			throw new RuntimeException();
		}
		retMap.put("retCode", "1");
		return retMap;
	}

	private void getFloatWinOrLoss(OrderSunModel sunOrderm) {
		VarietyPriceModel varietyPricem = (VarietyPriceModel) redisTemplate.opsForHash()
				.get(VarietyPriceModel.VARIETY_PRICE, sunOrderm.getVarietyId());
		if (varietyPricem != null) {
			Quota simpleQuota = (Quota) redisTemplate.opsForHash().get(Quota.QUOTA_DATA_PREFIX,
					sunOrderm.getContractsCode());
			long timePoor = (System.currentTimeMillis() - simpleQuota.getUpTime());
			if (simpleQuota != null) {
				logger.info("simpleQuota={}", JSON.toJSONString(simpleQuota));
				Double avgPrice = getMarketMoneyOrderIntegral(simpleQuota, sunOrderm.getDirection(),
						varietyPricem.getMarketPoint());
				Double totalVal = Arith.multiply(avgPrice, Double.valueOf(sunOrderm.getRealHandsNum()),
						varietyPricem.getEachPointMoney(), varietyPricem.getMarketPoint());
				if (sunOrderm.getDirection() == OrderDirection.BUY_UP.value) {
					sunOrderm.setFloatWinOrLoss(
							Arith.subtract(totalVal, sunOrderm.getRealMarketVal(), varietyPricem.getMarketPoint()));
				} else if (sunOrderm.getDirection() == OrderDirection.BUY_DOWN.value) {
					sunOrderm.setFloatWinOrLoss(
							Arith.subtract(sunOrderm.getRealMarketVal(), totalVal, varietyPricem.getMarketPoint()));
				}

			} else {
				logger.error("该合约的行情不稳定simpleQuota={},timePoor={}", JSON.toJSONString(simpleQuota), timePoor);
			}
		} else {
			logger.error("该品种没有设置品种价格：varietyId={}", sunOrderm.getVarietyId());
		}
	}

	// 得到积分的行情价
	private Double getMarketMoneyOrderIntegral(SimpleQuota simpleQuota, int direction, int marketPoint) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		Double avgPrice = 0.0;
		// 调用行情接口根据合约得到买入
		if (direction == OrderDirection.BUY_UP.value) {
			// 得到卖一价
			avgPrice = simpleQuota.getAskPrice();
		} else if (direction == OrderDirection.BUY_DOWN.value) {
			// 得到买一价
			avgPrice = simpleQuota.getBidPrice();
		}
		return Arith.setScale(avgPrice, marketPoint);

	}

	public static void main(String[] args) {
		ApplicationContext act = new ClassPathXmlApplicationContext("classpath:app*.xml");
		OrderService os = (OrderService) act.getBean("orderServiceImpl");
		OrderSunModel o = new OrderSunModel();
		ChannelModel cm = new ChannelModel();
		cm.setLevel(0);
		cm.setId(25);
		cm.setSuperId(12);
		os.queryIntegralOrderList(o, cm);
	}

	@Override
	public Map<String, Object> batchFailure(String orderms, int oneChannelId) {
		Map<String, Object> map = new HashMap<String, Object>();
		String[] strs = orderms.split(",");
		if (strs != null && strs.length > 0) {
			String id = strs[0];
			// 根据订单id得到 订单状态
			OrderModel m = orderDao.getOrderModelById(Integer.valueOf(id));
			if (oneChannelId != 0) {
				if (m.getOneChannelId() != oneChannelId) {
					map.put("retCode", "0");
					map.put("retmsg", "非法操作");
					logger.error("人工批量失败功能,订单和渠道不匹配,orderId={},oneChannelId={},orderms={}", id, oneChannelId, orderms);
					return map;
				}
			}
			String contractsCode = m.getContractsCode();
			Integer direction = m.getDirection();
			Integer orderStatus = m.getOrderStatus();
			// 首先判断该订单状态是否是在已支付，待持仓或者平仓处理中的订单，因为只有这两种订单才能操作失败
			if (!(orderStatus == OrderStatus.HAVED_PAY_WAIT_POSITION.value
					|| orderStatus == OrderStatus.UNWIND_PROCESSED.value)) {
				map.put("retCode", "0");
				map.put("retmsg", "订单状态不在待持仓或者平仓处理中");
				return map;
			}
			// 判断是否是在铜一个合约，同一个交易方向，同一个状态
			for (int i = 1; i < strs.length; i++) {
				Integer orderId = Integer.valueOf(strs[i]);
				OrderModel order = orderDao.getOrderModelById(orderId);
				if (order.getContractsCode().equalsIgnoreCase(contractsCode) && direction == order.getDirection()
						&& orderStatus == order.getOrderStatus()) {
					continue;
				} else {
					map.put("retCode", "0");
					map.put("retmsg", "选择的订单,合约代码,状态,交易方向不一致");
					return map;
				}
			}
			Map<String, String> mapSend = new HashMap<String, String>();
			mapSend.put("orderms", orderms);
			mapSend.put("orderStatus", String.valueOf(orderStatus));
			String str = null;
			try {
				// 调用订单模块
				str = HttpTools.doPost(springProperties.getProperty("sys.host") + BATCH_FAILURE, mapSend);
				JSONObject json = JSON.parseObject(str);
				if (json.getInteger("code") != 200) {
					map.put("retCode", "0");
					map.put("retmsg", json.getString("msg"));
					return map;
				}

			} catch (Exception e) {
				logger.error("后台用户处理批量失败请求,调用订单模块的时候出错:e={},orderms={}", e, orderms);
				throw new RuntimeException();
			}
		}
		map.put("retCode", "1");
		return map;
	}

	@Override
	public Map<String, Object> batchSuccess(String orderms, String userAccount, String price, String time,
			Integer unwindType, int oneChannelId) {
		Map<String, Object> map = new HashMap<String, Object>();
		String[] strs = orderms.split(",");
		if (strs != null && strs.length > 0) {
			Integer id = Integer.valueOf(strs[0]);
			// 根据订单id得到 订单状态
			OrderModel m = orderDao.getOrderModelById(id);
			if (oneChannelId != 0) {
				if (m.getOneChannelId() != oneChannelId) {
					map.put("retCode", "0");
					map.put("retmsg", "非法操作");
					logger.error("人工批量成功功能,订单和渠道不匹配,orderId={},oneChannelId={},orderms={}", id, oneChannelId, orderms);
					return map;
				}
			}
			String contractsCode = m.getContractsCode();
			int direction = m.getDirection();
			int orderStatus = m.getOrderStatus();
			if (orderStatus == OrderStatus.UNWIND_PROCESSED.value) {
				if (unwindType == null) {
					map.put("retCode", "0");
					map.put("retmsg", "请选择卖出类型");
					return map;
				}
			}
			// 首先判断该订单状态是否是在已支付，待持仓或者平仓处理中的订单，因为只有这两种订单才能操作失败
			if (!(orderStatus == OrderStatus.HAVED_PAY_WAIT_POSITION.value
					|| orderStatus == OrderStatus.UNWIND_PROCESSED.value)) {
				map.put("retCode", "0");
				map.put("retmsg", "订单状态不在待持仓或者平仓处理中");
				return map;
			}
			// 判断是否是在铜一个合约，同一个交易方向，同一个状态
			for (int i = 1; i < strs.length; i++) {
				Integer orderId = Integer.valueOf(strs[i]);
				OrderModel order = orderDao.getOrderModelById(orderId);
				if (order.getContractsCode().equalsIgnoreCase(contractsCode) && direction == order.getDirection()
						&& orderStatus == order.getOrderStatus()) {
					continue;
				} else {
					map.put("retCode", "0");
					map.put("retmsg", "选择的订单,合约代码,状态,交易方向不一致");
					return map;
				}
			}

			Map<String, String> mapSend = new HashMap<String, String>();
			mapSend.put("orderms", orderms);
			mapSend.put("userAccount", userAccount);
			mapSend.put("price", price);
			mapSend.put("time", time);
			mapSend.put("unwindType", String.valueOf(unwindType));
			mapSend.put("orderStatus", String.valueOf(orderStatus));
			String str = null;
			try {
				// 调用订单模块
				str = HttpTools.doPost(springProperties.getProperty("sys.host") + BATCH_SUCCESS, mapSend);
				JSONObject json = JSON.parseObject(str);
				if (json.getInteger("code") != 200) {
					map.put("retCode", "0");
					map.put("retmsg", json.getString("msg"));
					return map;
				}

			} catch (Exception e) {
				logger.error("后台用户处理批量成功请求,调用订单模块的时候出错:e={},orderms={}", e, orderms);
				throw new RuntimeException();
			}
		}
		map.put("retCode", "1");
		return map;
	}

	@Override
	public Map<String, Object> dealWithOpsitionSettle(int id, String unwindAvgPrice, String time, int unwindType,
			int oneChannelId,String userAccount) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		if (oneChannelId != 0) {
			// 首先判断该订单id的账户是否在该用户的渠道下
			int count = orderDao.getCountByIdAndOneChannelId(id, oneChannelId);
			if (count == 0) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", "非法操作");
				logger.error("人工处理持仓中订单,结算成功功能,订单和渠道不匹配,orderId={},oneChannelId={}", id, oneChannelId);
				return retMap;
			}
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", String.valueOf(id));
		map.put("unwindAvgPrice", unwindAvgPrice);
		map.put("time", time);
		map.put("unwindType", String.valueOf(unwindType));
		map.put("userAccount", userAccount);
		String str = null;
		try {
			// 调用订单模块
			str = HttpTools.doPost(springProperties.getProperty("sys.host") + OPSITION_SETTLE, map);
			JSONObject json = JSON.parseObject(str);
			if (json.getInteger("code") != 200) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", json.getString("msg"));
				return retMap;
			}

		} catch (Exception e) {
			logger.error("后台用户处理持仓中订单,结算成功请求,调用订单模块的时候出错:e={},orderId={}", e, id);
			throw new RuntimeException();
		}
		retMap.put("retCode", "1");
		return retMap;
		
	}
	
	@Override
	public Map<String, Object> opsitionRiskUnwind(int id, int unwindType, int oneChannelId) {
		Map<String, Object> retMap = new HashMap<String, Object>();
		if (oneChannelId != 0) {
			// 首先判断该订单id的账户是否在该用户的渠道下
			int count = orderDao.getCountByIdAndOneChannelId(id, oneChannelId);
			if (count == 0) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", "非法操作");
				logger.error("人工处理持仓中订单,风控平仓功能,订单和渠道不匹配,orderId={},oneChannelId={}", id, oneChannelId);
				return retMap;
			}
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", String.valueOf(id));
		map.put("unwindType", String.valueOf(unwindType));
		String str = null;
		try {
			// 调用订单模块
			str = HttpTools.doPost(springProperties.getProperty("sys.host") + OPSITION_RISK_UNWIND, map);
			JSONObject json = JSON.parseObject(str);
			if (json.getInteger("code") != 200) {
				retMap.put("retCode", "0");
				retMap.put("retmsg", json.getString("msg"));
				return retMap;
			}

		} catch (Exception e) {
			logger.error("后台用户处理持仓中订单,风控平仓功能,调用订单模块的时候出错:e={},orderId={}", e, id);
			throw new RuntimeException();
		}
		retMap.put("retCode", "1");
		return retMap;
	}
	/**
	 * 
	 * 看空
	 * 
	 * @param cm
	 * @param direction
	 * @return
	 */
	@Override
	public Integer getBearishCount(ChannelModel cm) {
		OrderModel orderModel = new OrderModel();
		// 首先判断channelModel是否是一级渠道还是二级渠道，还是平台
		if (cm.getLevel() == 1) {
			// 一级渠道只能看自己渠道的下的二级渠道
			orderModel.setOneChannelId(cm.getId());
		} else if (cm.getLevel() == 2) {
			// 二级渠道只能看自己的，一级渠道和二级渠道，
			orderModel.setChannelId(cm.getId());
		}
		orderModel.setDirection(0);
		List<OrderModel> bearishCountList = orderDao.getOrderCashCount(orderModel);
		Integer bearishCount = 0;
		for (OrderModel model : bearishCountList) {
			bearishCount += model.getHandsNum();
		}
		return bearishCount;
	}

	/**
	 * 
	 * 看多
	 * 
	 * @param cm
	 * @param direction
	 * @return
	 */
	@Override
	public Integer getCandoCoun(ChannelModel cm) {
		OrderModel orderModel = new OrderModel();
		// 首先判断channelModel是否是一级渠道还是二级渠道，还是平台
		if (cm.getLevel() == 1) {
			// 一级渠道只能看自己渠道的下的二级渠道
			orderModel.setOneChannelId(cm.getId());
		} else if (cm.getLevel() == 2) {
			// 二级渠道只能看自己的，一级渠道和二级渠道，
			orderModel.setChannelId(cm.getId());
		}
		orderModel.setDirection(1);
		List<OrderModel> candoCounList = orderDao.getOrderCashCount(orderModel);
		Integer candoCoun = 0;
		for (OrderModel model : candoCounList) {
			candoCoun += model.getHandsNum();
		}
		return candoCoun;
	}

	/**
	 * 总计
	 * 
	 * @param cm
	 * @param direction
	 * @return
	 */
	@Override
	public OrderCashCount getOrderCashCount(ChannelModel cm) {
		OrderCashCount cashCount = new OrderCashCount();
		OrderModel orderModel = new OrderModel();
		// 首先判断channelModel是否是一级渠道还是二级渠道，还是平台
		if (cm.getLevel() == 1) {
			// 一级渠道只能看自己渠道的下的二级渠道
			orderModel.setOneChannelId(cm.getId());
		} else if (cm.getLevel() == 2) {
			// 二级渠道只能看自己的，一级渠道和二级渠道，
			orderModel.setChannelId(cm.getId());
		}
		List<OrderModel> handsNumCountList = orderDao.getOrderCashCount(orderModel);
		Integer handsNumCount = 0;
		Double totalFee = 0.00;
		Double totalWinOrLoss = 0.00;
		for (OrderModel model : handsNumCountList) {
			handsNumCount += model.getHandsNum();
			totalFee += (model.getUserFees() * model.getRatio());
			if (model.getWinOrLoss() != null) {
				totalWinOrLoss += (model.getWinOrLoss() * model.getRatio());
			}
		}
		cashCount.setHandsNumCount(handsNumCount);
		cashCount.setTotalFee(totalFee);
		cashCount.setTotalWinOrLoss(totalWinOrLoss);
		return cashCount;
	}

	/**
	 * 用作计算订单数据统计ZY TODO 优化
	 */
	@Override
	public OrderCashCount countCashOrderList(OrderSunModel ordersun, ChannelModel cm) {
		// 首先判断channelModel是否是一级渠道还是二级渠道，还是平台
		if (cm.getLevel() == 1) {
			// 一级渠道只能看自己渠道的下的二级渠道
			ordersun.setOneChannelId(cm.getId());
		} else if (cm.getLevel() == 2) {
			// 二级渠道只能看自己的，一级渠道和二级渠道，
			ordersun.setChannelId(cm.getId());
			ordersun.setOneChannelId(cm.getSuperId());
		}
		OrderCashCount orderReturn = new OrderCashCount();
		List<OrderSunModel> orderSunModels = orderDao.countCashOrderList(ordersun);
		Integer handsNumCount = 0;
		Double totalFee = 0.00;
		Double totalWinOrLoss = 0.00;
		Integer bearishCount = 0;// 看跌
		Integer bullishCount = 0;// 看涨
		if (orderSunModels != null && orderSunModels.size() > 0) {
			for (OrderSunModel os : orderSunModels) {
				handsNumCount += os.getHandsNum();
				totalFee += (os.getUserFees() * os.getRatio());
				if (os.getWinOrLoss() != null) {
					totalWinOrLoss += (os.getWinOrLoss() * os.getRatio());
				}
				if (os.getDirection() == 0) {// 看空
					bearishCount += os.getHandsNum();
				}
			}
		}
		orderReturn.setTotalFee(totalFee);
		orderReturn.setTotalWinOrLoss(totalWinOrLoss);
		orderReturn.setHandsNumCount(handsNumCount);
		orderReturn.setBearishCount(bearishCount);
		bullishCount = handsNumCount - bearishCount;
		orderReturn.setCandoCoun(bullishCount);
		orderReturn.setNetEquityPosition(Math.abs(bullishCount - bearishCount));// 净持仓
		return orderReturn;
	}

	

	
}
