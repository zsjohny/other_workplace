package org.dream.config.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.config.dao.TradingTimeDao;
import org.dream.config.model.TradingTimeModel;
import org.dream.config.service.TradingTimeService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 交易时间配置Service
 * 
 * @author wangd
 *
 */
@Service
public class TradingTimeServiceImpl implements TradingTimeService {

    @Autowired
    TradingTimeDao tradingTimeDao;

    @Override
    public void saveTradingTimeConfig(TradingTimeModel tradingTimeModel) {
	tradingTimeDao.createTradingTime(tradingTimeModel);

    }

    @Override
    public void updateTradingTimeConfig(TradingTimeModel tradingTimeModel) {
	tradingTimeDao.updateTradingTime(tradingTimeModel);

    }

    @Override
    public List<TradingTimeModel> getAllTradingTimes(Integer exchangeId) {

	return tradingTimeDao.getByExchangeId(exchangeId);
    }

    @Override
    public void delteTradingTimes(String ids) {

	tradingTimeDao.deleteByIds(this.handleIds(ids));
    }

    @Override
    public Page<TradingTimeModel> querypaging(Integer varietyId, Integer action, String remark,  Integer pageIndex, Integer pageSize) {
	Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
	List<TradingTimeModel> list = tradingTimeDao.querypaging(varietyId, action, remark, limit, pageSize);
	int totalCount = tradingTimeDao.querypaging_count(varietyId, action, remark);

	Page<TradingTimeModel> page = new Page<>(pageIndex, pageSize, totalCount);
	page.setData(list);

	return page;
    }

    private List<Integer> handleIds(String ids) {
	List<Integer> result = new ArrayList<Integer>();
	String[] temp_id = ids.split(",");
	for (int i = 0; i < temp_id.length; i++) {
	    result.add(Integer.valueOf(temp_id[i]));
	}
	return result;
    }

    @Override
    public void changeStatus(Integer id, Integer status) {
	TradingTimeModel timeModel = new TradingTimeModel();
	timeModel.setId(id);
	timeModel.setStatus(status);
	
	tradingTimeDao.updateTradingTime(timeModel);
	
    }
}
