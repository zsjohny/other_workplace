package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinancePayPlatformModel;

public interface FinancePayPlatformDao {

	/**
	 * 通用分页查询
	 * 
	 * @param platform
	 * @param name
	 * @param status
	 * @param offset
	 * @param size
	 * @return
	 */
	public List<FinancePayPlatformModel> querypaging(@Param("model") FinancePayPlatformModel model,
			@Param(value = "offset") Integer offset, @Param(value = "size") Integer size);

	public Integer querypaging_count(@Param("model") FinancePayPlatformModel model);

	public void saveFinancePayPlatform(FinancePayPlatformModel financePayPlatformModel);

	public void updateFinancePayPlatform(FinancePayPlatformModel financePayPlatformModel);

	public void removeFinancePayPlatform(@Param(value = "id") Integer id);

	public FinancePayPlatformModel getById(@Param(value = "id") Integer id);

	public List<FinancePayPlatformModel> findAll(FinancePayPlatformModel payPlatformModel);

	public FinancePayPlatformModel check(FinancePayPlatformModel payPlatformModel);
}
