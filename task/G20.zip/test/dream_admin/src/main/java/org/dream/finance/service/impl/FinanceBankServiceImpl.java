package org.dream.finance.service.impl;

import java.util.List;

import org.dream.finance.dao.FinanceBankDao;
import org.dream.finance.service.FinanceBankService;
import org.dream.model.finance.FinanceBankModel;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceBankServiceImpl implements FinanceBankService {
	private static final Integer ERROR_CODE = 600;
	private static final Integer SUCCEED_CODE = 200;
	@Autowired
	private FinanceBankDao bankDao;

	@Override
	public List<FinanceBankModel> findBankAll() {
		return bankDao.findAll();
	}

	@Override
	public Response saveBank(FinanceBankModel bankModel) {
		FinanceBankModel model = bankDao.check(bankModel);
		if (model != null)
			return Response.response(ERROR_CODE, "该银行已存在");
		bankDao.saveFinanceBank(bankModel);
		return Response.response(SUCCEED_CODE, "保存银行成功");
	}

	@Override
	public Response updateBank(FinanceBankModel bankModel) {
//		FinanceBankModel model = bankDao.check(bankModel);
//		if (model != null)
//			return Response.response(ERROR_CODE, "该银行已存在");
		bankDao.updateFinanceBank(bankModel);
		return Response.response(SUCCEED_CODE, "更新银行成功");
	}

}
