package org.dream.finance.service;

import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.model.finance.FinanceTransferCertModel;
import org.dream.utils.mvc.Page;

public interface FinanceChannelService {

	public Page<FinancePayPlatformBankModel> findPayPlatformBank(String payPlatform, Integer status, Integer offset,
			Integer pageSize);

	public Integer findPayPlatformBankRows(String payPlatform, Integer status);

	// 渠道支付规则
	public void saveChannelPay(Integer channelId, Integer bankId, Double limitSingle, Double limitDay, String payRule);

	// 银行相关
	public FinanceBankModel findBank(Integer bankId, Integer status);

	public void saveFinanceBank(String icon, String name, Integer index);

	public void updateFinanceBank(Integer id, String icon, String name, Integer index, Integer status);

	public Page<FinanceBankModel> querypagingBank(String name, String icon, Integer index, Integer status,
			Integer pageIndex, Integer pageSize);

	// 渠道支付规则

	public void removeChannelPay(Integer id);

	public void updateChannelPay(Integer id, Integer channelId, Integer bankId, Double limitSingle, Double limitDay,
			String payRule);

	public Page<FinanceChannelPayModel> querypagingChannelPay(Integer channelId, Integer bankId, Double limitSingle,
			Double limitDay, String payRule, Integer status, Integer pageIndex, Integer pageSize);

}
