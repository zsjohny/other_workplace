package org.dream.config.service;

import java.util.List;

import org.dream.config.model.TradingTimeModel;
import org.dream.utils.mvc.Page;

/**
 * 交易时间配置Service
 * 
 * @author wangd
 *
 */
public interface TradingTimeService {

    public void saveTradingTimeConfig(TradingTimeModel tradingTimeModel);

    public void updateTradingTimeConfig(TradingTimeModel tradingTimeModel);

    public List<TradingTimeModel> getAllTradingTimes(Integer exchangeId);

    public void delteTradingTimes(String ids);

    public Page<TradingTimeModel> querypaging(Integer varietyId, Integer action, String remark, Integer pageIndex, Integer pageSize);
    
    /**
     * 修改时间配置的状态，使该事件配置生效或失效
     * @param id
     * @param status
     */
    public void changeStatus(Integer id, Integer status);
}
