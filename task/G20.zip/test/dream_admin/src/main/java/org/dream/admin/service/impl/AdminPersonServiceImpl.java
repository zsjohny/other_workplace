package org.dream.admin.service.impl;

import java.util.List;

import org.dream.admin.dao.AdminPersonDao;
import org.dream.admin.model.AdminPersonModel;
import org.dream.admin.service.AdminPersonService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminPersonServiceImpl implements AdminPersonService {

    @Autowired
    AdminPersonDao adminPersonDao;
    
    @Override
    public void savePerson(AdminPersonModel personMoudel,
            Integer dempartmentId) {

        adminPersonDao.createPerson(personMoudel);
        if (dempartmentId != null) {
           adminPersonDao.createDepartmentPerson(dempartmentId, personMoudel.getId()); 
        }

    }

    @Override
    public void updatePerson(AdminPersonModel personMoudel) {
        adminPersonDao.updatePerson(personMoudel);

    }

    @Override
    public AdminPersonModel getById(Integer id) {
        
        return adminPersonDao.getById(id);
    }

    @Override
    public void deleteByPersonId(Integer id) {
        /**
         * 删除人员之前需要验证是否已经与用户关联
         * 如果关联先取消关联。
         * 此验证应该放在Controller层处理
         * 下同批量删除
         */
       adminPersonDao.deltePerson(id, null);
       
       adminPersonDao.deleteDepartmentPersonByPersonId(id, null);
       

    }

    @Override
    public void deletePersonsByIds(List<Integer> ids) {
        adminPersonDao.deltePerson(null, ids);
        
        adminPersonDao.deleteDepartmentPersonByPersonId(null, ids);

    }

    @Override
    public Page<AdminPersonModel> pagingQueryPersons(String name,
            String gender, String idNumber, String mobilePhone,
            String familyPhone, String email, String description,
            Integer pageIndex, Integer pageSize) {
        Integer limit = pageIndex  > 0 ? pageIndex* pageSize : 0 * pageSize;
        List<AdminPersonModel> resultList = adminPersonDao.pagingQueryPersons(name, gender, idNumber, mobilePhone, familyPhone, email, description, limit, pageSize);
        Integer count = adminPersonDao.pagingQueryPersons_count(name, gender, idNumber, mobilePhone, familyPhone, email, description);
        
        Page<AdminPersonModel> result = new Page<>(pageIndex, pageSize, count);
        result.setData(resultList);
        
        return result;
    }

}
