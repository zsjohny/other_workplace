package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.order.FuturesExchangeModel;
import org.dream.order.dao.FuturesExchangeDao;
import org.dream.order.service.FuturesExchangeService;
import org.dream.utils.mvc.Page;
import org.dream.utils.prop.SpringProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class FuturesExchangeServiceImpl implements FuturesExchangeService {

	@Autowired
	FuturesExchangeDao futuresExchangeDao;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@Autowired
	private SpringProperties springProperties;

	@Override
	public Map<String, Object> createFutruresExchange(FuturesExchangeModel futuresExchangeMoudel) {
		Map<String, Object> mapRet = new HashMap<String, Object>();
		// 首先判断交易所名称是否相同
		int countByExchangeName = futuresExchangeDao.getCountByExchangeName(futuresExchangeMoudel.getExchangeName());
		if (countByExchangeName > 0) {
			mapRet.put("retCode", "0");
			mapRet.put("retmsg", "交易所名称已存在");
			return mapRet;
		}
		int countByExchangeCode = futuresExchangeDao.getCountByExchangeCode(futuresExchangeMoudel.getExchangeCode());
		if (countByExchangeCode > 0) {
			mapRet.put("retCode", "0");
			mapRet.put("retmsg", "交易所编码已存在");
			return mapRet;
		}
		futuresExchangeDao.createFuturesExchange(futuresExchangeMoudel);
		mapRet.put("retCode", "1");
		return mapRet;

	}

	@Override
	public void updateFutureExchange(FuturesExchangeModel futuresExchangeMoudel) {
		// 修改期货状态后 修改redis
		// 先根据exchangeId 来查询原有的redis中的状态值。如果不同，则修改
		Integer exchangeId = futuresExchangeMoudel.getId();
		Integer status = (Integer) redisTemplate.opsForHash().get(FuturesExchangeModel.EXCHANGE_STATUS, exchangeId);
		Integer statusNew = futuresExchangeMoudel.getStatusDesc();
		if (status != statusNew) {
			redisTemplate.opsForHash().put(FuturesExchangeModel.EXCHANGE_STATUS, exchangeId, statusNew);
		}

		futuresExchangeDao.updateFuturesExchange(futuresExchangeMoudel);

	}

	@Override
	public FuturesExchangeModel getById(Integer id) {

		return futuresExchangeDao.getById(id);
	}

	@Override
	public Page<FuturesExchangeModel> querypaging(String exchangeName, String exchangeCode, String futuresRemark,
			Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<FuturesExchangeModel> futuresExchangeMoudels = futuresExchangeDao.qureypaging(exchangeName, exchangeCode,
				futuresRemark, limit, pageSize);
		Integer totalCount = futuresExchangeDao.qureypaging_count(exchangeName, exchangeCode, futuresRemark);

		Page<FuturesExchangeModel> resultPage = new Page<FuturesExchangeModel>(pageIndex, pageSize, totalCount);
		resultPage.setData(futuresExchangeMoudels);
		return resultPage;
	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public List<FuturesExchangeModel> getAll() {

		return futuresExchangeDao.getAll();
	}

	@Override
	public void removeFutruresExchangeByIds(String ids) {
		// 先删除该期货市场的redis
		List<Integer> list = handleIds(ids);
		for (Integer id : list) {
			FuturesExchangeModel model = futuresExchangeDao.getById(id);
			Integer exchangeId = model.getId();
			redisTemplate.opsForHash().delete(FuturesExchangeModel.EXCHANGE_STATUS, exchangeId);
		}
		// 再在数据库中将期货市场移除
		futuresExchangeDao.removeFuturesExchangeByIds(this.handleIds(ids));
	}

	@Override
	public List<FuturesExchangeModel> getExchangeForSelect() {
		return futuresExchangeDao.getExchangeForSelect();
	}
}
