package org.dream.order.service;

import java.util.List;
import java.util.Map;

/**
 * 查询上周的订单，做成报表。
 * 
 * @author ZY
 * @date 2016年10月11日
 */
public interface ReportFormService {

	public Map<String, Object> countSecondChannelFees(Integer channelId, String sTime, String eTime);

	public List<Map<String, Object>> countFirstChannelFees(Integer oneChannelId, String orderTimeStart,
			String orderTimeEnd);

	public List<Map<String, Object>> countPlatformFees(String orderTimeStart, String orderTimeEnd);

	/**
	 * 新的需求：不需要乘以汇率，也不需要统计
	 */
	public Map<String, Object> countSecondChannelFeesLocalUnit(Integer channelId, String sTime, String eTime);

	public List<Map<String, Object>> countFirstChannelFeesLocalUnit(Integer oneChannelId, String orderTimeStart,
			String orderTimeEnd);

	public List<Map<String, Object>> countPlatformFeesLocalUnit(String orderTimeStart, String orderTimeEnd);
}
