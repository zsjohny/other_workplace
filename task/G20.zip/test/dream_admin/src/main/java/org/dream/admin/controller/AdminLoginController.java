package org.dream.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dream.admin.model.AdminMenuResourceModel;
import org.dream.admin.model.AdminPageElementResourceModel;
import org.dream.admin.model.AdminRoleModel;
import org.dream.admin.model.AdminSecurityResourceModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.admin.service.AdminMenuResouceService;
import org.dream.admin.service.AdminRoleService;
import org.dream.admin.service.AdminUrlAccessResourceService;
import org.dream.admin.service.AdminUserService;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 
 * 系统登录实现Controller
 * 
 * @author wangdf
 *
 */
@Controller
@RequestMapping("/login")
public class AdminLoginController extends BaseController{
	Logger logger = LoggerFactory.getLogger(AdminLoginController.class);
	@Autowired
	AdminUserService adminUserService;

	@Autowired
	AdminUrlAccessResourceService adminUrlAccessResourceService;

	@Autowired
	AdminRoleService adminRoleService;

	@Autowired
	ChannelService channelService;

	@Autowired
	AdminMenuResouceService adminMenuResouceService;

	/**
	 * 登录验证
	 * 
	 * @param userAccount
	 * @param password
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/verification", method = { RequestMethod.POST })
	@ResponseBody
	public Response verification(String userAccount, String password, HttpServletRequest request,
			HttpServletResponse response) {

		// 根据登录用户的域名确定用户所属的渠道
		String url = request.getHeader("Host");// 客户端的主机名
		// 去掉端口号
		if (url.indexOf(":") > -1) {
			url = url.split(":")[0];
		}
		ChannelModel channelModel = channelService.findChannelByBackstageDomain(url);

		// 如果获取不到相对应的渠道信息则不允许登陆
		if (channelModel == null) {
			logger.error("用户{}，登录失败，未能获得正确的渠道信息", userAccount);
			return Response.error("系统未能确定您的登录途径，请联系管理员后登录");
		}
		request.getSession().setAttribute("channel", channelModel);

		AdminUserModel userModel = adminUserService.getUserByUserAccountPassword(userAccount, password,
				channelModel.getId());

		if (userModel == null || userModel.getId() == null) {
			// 验证失败，用户名或密码错误
			return Response.error("用户名或密码错误");
		}
		if (userModel.isDisable()) {
			return Response.error("该用户已禁用，请联系管理员");
		}
		/**
		 * 保存用户信息到Session，以后可能会添加用户的组织机构信息
		 */
		request.getSession().setAttribute("user", userModel);
		request.getSession().setAttribute("userId", userModel.getId());
		/**
		 * 保存用户的角色数据？？？ 其目的是处理系统管理员最大权限的实现
		 */
		List<AdminRoleModel> roleModels = adminRoleService.queryGrantRoles(userModel.getId(), channelModel.getId());
		request.getSession().setAttribute("roles", roleModels);

		/**
		 * 获取urlAccess
		 */
		// 获取所有的该平台 or 渠道下的 所有权限(urlAccess)
		List<AdminSecurityResourceModel> adminSecurityResourceModels_all = adminUrlAccessResourceService
				.getAllByMenuId(null, AdminPageElementResourceModel.CATEGORY, channelModel.getLevel());
		List<String> url11 = new ArrayList<>();
		List<String> urlAccessList_all = new ArrayList<>();
		for (AdminSecurityResourceModel model : adminSecurityResourceModels_all) {
			if (model.getUrl() != null) {
				String urlAccess[] = model.getUrl().split("\\|");
				url11.add(model.getUrl());
				for (int i = 0; i < urlAccess.length; i++) {
					urlAccessList_all.add(urlAccess[i]);
				}
			}
		}
		request.getSession().setAttribute("allUrlAccess", urlAccessList_all);

		// 获取该用户下的所有的 权限（urlAccess ）
		List<AdminSecurityResourceModel> adminSecurityResourceModels = adminUrlAccessResourceService
				.getSecurityResourcesByActorId(userModel.getId(), channelModel.getId(),
						AdminPageElementResourceModel.CATEGORY);
		List<String> urlAccessList = new ArrayList<>();
		for (AdminSecurityResourceModel model : adminSecurityResourceModels) {
			if (model.getUrl() != null) {
				String urlAccess[] = model.getUrl().split("\\|");
				for (int i = 0; i < urlAccess.length; i++) {
					urlAccessList.add(urlAccess[i]);
				}
			}
		}
		request.getSession().setAttribute("urlAccess", urlAccessList);
		/**
		 * 获取menu
		 */
		List<AdminMenuResourceModel> menu = adminMenuResouceService.getMenuPedigreeByActorId(userModel,
				channelModel.getId(), channelModel.getLevel());
		request.getSession().setAttribute("menu", menu);

		return Response.success();
	}

	@RequestMapping(value = "/safe_userMession", method = { RequestMethod.POST })
	@ResponseBody
	public Response userMession(HttpServletRequest request, HttpServletResponse response) {
		AdminUserModel user=(AdminUserModel) request.getSession().getAttribute("user");
		ChannelModel cm=super.getCurrentChannel(request);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("name", user.getName());
		map.put("level", cm.getLevel());
		return Response.success(map);

	}

	/**
	 * 退出系统 清除session和用户Id数据
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/safe_loginOut", method = { RequestMethod.POST })
	@ResponseBody
	public Response loginOut(HttpServletRequest request, HttpServletResponse response) throws IOException {

		request.getSession().removeAttribute("user");
		request.getSession().removeAttribute("userId");
		return Response.success();
	}
	@RequestMapping(value="/responseRedirect")
	public void  responseRedirect(HttpServletRequest request,HttpServletResponse response)throws IOException {
		response.sendRedirect("./redirect.do");

	}
	
	@RequestMapping(value="/redirect")
	public void  redirect(HttpServletRequest request,HttpServletResponse response)throws Exception {
		String str=request.getHeader("Host");
		//首先根据域名得到渠道等级
		Integer level = adminUserService.getChannelLevelByDomain(str);
		if(level !=null){
			if(level ==0){
				request.getRequestDispatcher("login.html").forward(request, response);
			}else if(level ==1 ){
				request.getRequestDispatcher("loginTrading.html").forward(request, response);
			}else if(level ==2 ){
				request.getRequestDispatcher("loginAgent.html").forward(request, response);
			}
		}else{
			request.getRequestDispatcher("login.html").forward(request, response);
		}
	}
	

	public static void main(String[] args) {
		
	}

}
