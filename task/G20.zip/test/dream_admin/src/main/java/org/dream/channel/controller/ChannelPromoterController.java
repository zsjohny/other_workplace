package org.dream.channel.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.channel.service.ChannelPromoterService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.channel.ChannelPromoterModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.dream.utils.mvc.UserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller()
@RequestMapping("/channelPromoter")
public class ChannelPromoterController extends BaseController {
	@Autowired
	private ChannelPromoterService channelPromoterService;

	/**
	 * 根据渠道id分页获取该渠道下的所有推广员
	 * 
	 * @return
	 */
	@RequestMapping("/querypaging")
	@ResponseBody
	public Response querypaging(HttpServletRequest request, Integer levelId, Integer page, Integer pageSize) {
		ChannelModel channelModel = getCurrentChannel(request);
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<ChannelPromoterModel> data = channelPromoterService.querypaging(channelModel.getId(), levelId, page,
				pageSize);

		return Response.success(data);
	}

	/**
	 * 修改渠道推广员的信息
	 * 
	 * @param id
	 * @param code
	 * @param levelId
	 * @return
	 */
	@RequestMapping(value = "/update")
	@ResponseBody
	public Response updateFuturesExchange(Integer id, String code, Integer levelId) {
		Assert.notNull(id, "要修改的推广员id不能为空");
		ChannelPromoterModel channelPromoterModel = new ChannelPromoterModel();
		channelPromoterModel.setId(id);
		channelPromoterModel.setCode(code);
		channelPromoterModel.setLevelId(levelId);
		channelPromoterService.updateChannelPromoter(channelPromoterModel);
		return Response.success();
	}

	/**
	 * 根据登录用户获取他推广出来的子用户信息
	 */
	@RequestMapping("/qureypagingSonUser")
	@ResponseBody
	public Response qureypagingSonUser(Integer page, Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Integer userId = UserUtil.getUserId();
		// Integer userId = 19;
		Integer promoterId = channelPromoterService.getPromoterIdByUserId(userId);
		Page<ChannelPromoterModel> data = channelPromoterService.qureypagingSonUser(promoterId, page, pageSize);
		return Response.success(data);
	}

}
