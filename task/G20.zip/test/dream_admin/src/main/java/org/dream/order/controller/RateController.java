package org.dream.order.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.order.Rate;
import org.dream.order.service.RateService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/rate")
public class RateController extends BaseController {
	@Autowired
	private RateService rateService;
	
	@RequestMapping("/save")
	@ResponseBody
	public Response saveRate(Rate rate,HttpServletRequest req){
		if(StringUtils.isBlank(rate.getCurrency())){
			return Response.response(600, "请求参数出错");
		}
		
		Map<String,Object> map = rateService.saveRate(rate,(Integer)req.getSession().getAttribute("userId"),super.getCurrentChannel(req).getId());
		if("0".equals(map.get("retCode"))){
			return Response.response(600, (String)map.get("retmsg"));
		}
		return Response.success();
	}
	
	@RequestMapping("/update")
	@ResponseBody
	public Response updateRate(Rate rate,HttpServletRequest req){
		if(rate.getId()==null ){
			return Response.response(600, "请求参数出错");
		}
		rateService.updateRate(rate,(Integer)req.getSession().getAttribute("userId"),super.getCurrentChannel(req));
		return Response.success();
	}
	@RequestMapping("/remove")
	@ResponseBody
	public Response removeRate(String id,HttpServletRequest req){
		if(StringUtils.isBlank(id)){
			return Response.response(600, "请求参数出错");
		}
		Map<String,Object> map=rateService.removeRate(id,super.getCurrentChannel(req).getId());
		if("0".equals(map.get("retCode"))){
			return Response.response(600,(String)map.get("retmsg"));
		}
		return Response.success();
	}
	
	@RequestMapping("/pagingQuery")
	@ResponseBody
	public Response pagingQueryRate(Integer page, Integer pageSize, String currency,HttpServletRequest req){
		Page<Rate> data=rateService.pagingQueryRate( page,  pageSize,  currency,super.getCurrentChannel(req).getId());
		
		return Response.success(data);
		
	}
	/**
	 * 
	 * @auth yehx
	 * @date 2016年7月5日
	 */
	
	@RequestMapping("getRateById")
	@ResponseBody
	public Response getRateById(Integer id){
		Assert.notNull(id,"请求参数出错");
		Rate rate=rateService.getRateById(id);
		
		return Response.success(rate);
	}
	/**
	 * 得到币种
	 * @auth yehx
	 * @date 2016年9月19日
	 */
	@RequestMapping("getCurrency")
	@ResponseBody
	public Response getCurrency(){
		
		return Response.success(rateService.getCurrency());
	}
	@RequestMapping("getRateInfoBycurrency")
	@ResponseBody
	public Response getRate(String currency){
		return Response.success(rateService.getRateByCurrency(currency));
	}
}
