/*
Navicat MySQL Data Transfer

Source Server         : develop
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : queryphone

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2015-10-28 22:56:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `queryphone`
-- ----------------------------
DROP TABLE IF EXISTS `queryphone`;
CREATE TABLE `queryphone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户注册的id',
  `userName` varchar(16) DEFAULT NULL,
  `userPhone` bigint(11) DEFAULT NULL,
  `userPassword` varchar(20) DEFAULT NULL,
  `findPhone` bigint(11) DEFAULT NULL,
  `findApplay` varchar(512) DEFAULT NULL,
  `regSign` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of queryphone
-- ----------------------------
INSERT INTO `queryphone` VALUES ('1', null, '32', '1212', null, null, null);
INSERT INTO `queryphone` VALUES ('2', null, '23', '2312', null, null, null);
INSERT INTO `queryphone` VALUES ('3', '232', null, '123', null, null, null);
INSERT INTO `queryphone` VALUES ('4', '32423', null, '324234', null, null, null);
INSERT INTO `queryphone` VALUES ('5', '32423', null, '324234', null, null, null);
INSERT INTO `queryphone` VALUES ('6', '1234', null, '1', null, null, null);
INSERT INTO `queryphone` VALUES ('7', '12423432141', null, '345', null, null, null);
INSERT INTO `queryphone` VALUES ('8', '138856368932', null, '1234', null, null, null);
INSERT INTO `queryphone` VALUES ('9', '1368858', null, '13856368932', null, null, null);
INSERT INTO `queryphone` VALUES ('10', '1', null, '1', null, null, null);
INSERT INTO `queryphone` VALUES ('11', 'admin', null, 'admin', null, null, null);
INSERT INTO `queryphone` VALUES ('12', 'uesr', null, 'user', null, null, null);
INSERT INTO `queryphone` VALUES ('13', 'user', null, 'user', null, null, null);
INSERT INTO `queryphone` VALUES ('14', ' admin', null, 'admin', null, null, null);
INSERT INTO `queryphone` VALUES ('15', null, '13856368932', '1', null, null, '970300');
INSERT INTO `queryphone` VALUES ('16', null, null, '1', null, null, null);
INSERT INTO `queryphone` VALUES ('17', null, '15924179757', null, null, null, '711791');
