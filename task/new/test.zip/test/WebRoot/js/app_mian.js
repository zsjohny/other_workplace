$(function() {
	 


 //鼠标进入注册或登陆
function enterUser(e){
	var clickMsg=e.value;
	if(clickMsg=='登录'){
		$("#checkpass").hide();
		$(".login_but").css("background", "red");  
		$(".register_but").css("background", "gray"); 
		document.getElementById("login").type="submit"; 
		 
	}else{
		//如果不一致光标指向密码栏
		if(document.getElementsByName("judge")[0].value!=document.getElementsByName("password")[0].value){
			$("#password").focus();
			$("#judge").val("");
			}
		
		$("#checkpass").show();
		$(".register_but").css("background", "red"); 
		 $(".login_but").css("background", "gray");   
		  
	}
	
  	
	
	
}

//鼠标离开注册或登录
	function leaveUser(e){
	var clickMsg=e.value;
	if(clickMsg=='登录'){
		 $(".register_but").css("background", "#00B4C9");  
		 $(".login_but").css("background", "#00B4C9");  
		 document.getElementById("login").type="button"; 
		document.getElementById("register").type="button"; 
	
	}else{
	
		 $(".login_but").hide(); 
		 $("#findpass").hide(); 
		document.getElementById("register").type="submit"; 
		 $(".register_but").css("background", "#00B4C9");   
	  document.getElementsByName("judge")[0].required="true";  

	}
	}
   //判断密码是否一致
	function isequalpass(){
	if(document.getElementsByName("judge")[0].value!=document.getElementsByName("password")[0].value){
		$("#passMsg").show();
		}
		
	}
	//密码消失
	function ignore(){
		$("#passMsg").hide();
		
	}
	

})
	