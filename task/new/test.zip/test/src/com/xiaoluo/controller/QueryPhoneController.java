/**
 *
 */
package com.xiaoluo.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.jfinal.aop.Before;
import com.jfinal.aop.Clear;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.key.Key;
import com.xiaoluo.interceptor.QueryPhoneGlobalInterceptor;
import com.xiaoluo.interceptor.QueryPhoneInterceptor;
import com.xiaoluo.util.CaluRatio;
import com.xiaoluo.util.DesEnum;
import com.xiaoluo.util.DesUtil;
import com.xiaoluo.util.DrawImageUtil;
import com.xiaoluo.util.EmailSendUtil;
import com.xiaoluo.util.Log4jUtil;
import com.xiaoluo.util.QueryPhoneSetAttr;
import com.xiaoluo.util.QyeryPhoneByProxyIp;
import com.xiaoluo.util.RegitEnum;
import com.xiaoluo.util.UnicodeConverChinese;
import com.xiaoluo.util.impl.QueryPhoneSetAttrImpl;
import com.xiaoluo.validator.QueryPhoneValidator;

import net.sf.json.JSONObject;

/**
 * @author xiaoluo
 * @version $Id: QueryPhoneController.java, 2015年10月18日 下午1:36:37
 */

public class QueryPhoneController extends Controller {
	// 日志加载
	private static Logger logger = Log4jUtil.init(QueryPhoneController.class);

	/**
	 * 用于页面初始化检查
	 *
	 * @param
	 * @return
	 */
	// @Before(QueryPhoneValidator.class) // 参数检测器
	public void index() {
		// 进入初始化页面的时候建立一个cookie
		forwardAction("/init");// 转发不让用户看到真实的初始化页面

	}

	/**
	 * 用于页面初始化
	 *
	 * @param
	 * @return
	 */
	public void init() {

		// 辨别是否有cookie
		setCookie("loginInit", "true", 60 * 30);
		renderFreeMarker("login.html");// 跳转到初始化页面

	}

	/**
	 * 用于验证码
	 *
	 * @param
	 * @return
	 */
	@Clear(QueryPhoneGlobalInterceptor.class)
	// 清除全局拦截
	public void drawImage() {

		render(new DrawImageUtil());

	}

	/**
	 * 用于页面的注册和登录
	 *
	 * @param
	 * @return
	 */

	public void addUser() {

		try {
			List<Record> list = null;
			String loginName = getPara("loginname", "").trim();

			String password = getPara("password", "").trim();

			// 查找是否存在该帐号,检验登录账号是否唯一
			if (loginName.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$")) {
				list = Db.find("select * from queryPhone where userPhone=? ", Long.valueOf(loginName));
			} else {
				list = Db.find("select * from queryPhone where userName=? ", loginName);
			}

			// 根据是否再次输入密码判断是注册还是登录
			String jude = getPara("judge", "");
			if (jude == "") {
				if (list == null || list.size() == 0) {
					setAttr("loginnameMsg", "该帐号不存在!!");
					// 防止再次点击滑动
					setAttr("status", "1");
					forwardAction("/init");
					return;
				}
				// 判断密码是否正确
				if (password.equals(list.get(0).getStr("userPassword"))) {
					// 设置密码正确的时候session
					setAttr("xiaoluo", Key.init());
					setSessionAttr("xiaoluo", getAttr("xiaoluo"));

					// 判断是否是管理员
					Properties properties = new Properties();
					String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\defaultAdmin.properties";
					properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));

					// 没有cookie的用户进入
					if (getCookie("loginInit") == null) {
						// 增加没有cookie的用户进入
						Properties propertiesUser = new Properties();
						propertiesUser.put("deaultUserSession", Key.init());
						propertiesUser.put("defaultMillsecond", properties.getProperty("defaultMillsecond"));
						OutputStream output = new FileOutputStream(new File(
								System.getProperty("user.dir") + "\\WebRoot\\properties\\defaultUser\\defaultUser"
										+ getAttr("realIp") + ".properties"));
						propertiesUser.store(output, "author xiaoluo");
						output.close();
					}

					// 判断标志--是否为管理员
					if (loginName.equals(properties.getProperty("admin").trim())
							&& password.equals(properties.getProperty("password").trim())) {

						renderFreeMarker("onlineEncrypt.html");
						return;

					}
					// 普通用户进入
					// 设置当前登录的用户名称和密码
					Map<String, String> map = new HashMap<String, String>();

					map.put("loginName", DesUtil.encrypt(loginName, "password"));
					map.put("password", DesUtil.encrypt(password, "loginName"));
					setAttr("loginKey", map);

					// 将当前的用户查询次数增加一次
					// // 将当前用户的查询的次数数目加1-----充值支护的代码
					// if (loginName
					// .matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$"))
					// {
					//
					// Db.update(
					// "update queryphone set queryCount='1' where userPhone=?",
					// Long.valueOf(loginName));
					// } else {
					// Db.update(
					// "update queryphone set queryCount='1' where userName=?",
					// loginName);
					// }
					// 进入资产查询所有的目录
					// 携带用户支持的参数
					Long totalCount = Db.queryLong("select count(*) from queryPhone ");
					Long supportCount = Db.queryLong("select count(*) from queryPhone where isSupport='true' ");
					setAttr("loginName", loginName);
					setSessionAttr(loginName, "true");
					if ((supportCount / totalCount) > 0.85) {
						setAttr("supportCount", new DecimalFormat("#0.00").format(supportCount / totalCount * 100));
					} else {
						setAttr("supportCount", new DecimalFormat("#0.00").format((double) (Math.random() * 5 + 85)));
					}

					// 成功页面-- 测试apple
					// --------------------------------------------------
					// DecimalFormat decimalFormat = new DecimalFormat("0.00");
					//
					// setAttr("result", "经过我们的全网推断,您的出轨的可能性是:" +
					// decimalFormat.format(Math.random() * 100));
					// setAttr("datagay", "");
					// renderFreeMarker("outsideResult.html");
					// ------------------------------------------
					renderFreeMarker("fundCatalog.html");
				} else {
					setAttr("loginName", loginName);
					setAttr("passwordMsg", "该密码不正确!!");
					// 防止再次点击滑动
					setAttr("status", "1");
					forwardAction("/init");

				}
				return;
			}
			// 注册时携带错误信息
			if (list != null && list.size() != 0 && password != "") {
				setAttr("loginnameMsg", "该帐号已存在!!");
				// 防止再次点击滑动
				setAttr("status", "1");
				forwardAction("/init");
				return;
			}
			Record record = new Record();
			if (loginName.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$")) {

				record.set("userPhone", Long.valueOf(loginName));

			} else {
				record.set("userName", loginName);

			}
			record.set("userPassword", password);
			Boolean flag = Db.save("queryPhone", record);
			if (flag) {
				// 返回到登陆页面携带的参数
				setAttr("loginName", loginName);
				setAttr("loginPass", password);
				// 防止再次点击滑动
				setAttr("status", "1");
				forwardAction("/init");
			} else {
				setAttr("loginnameMsg", "注册失败，请刷新重试!!");
				// 防止再次点击滑动
				setAttr("status", "1");
				forwardAction("/init");
			}
		} catch (Exception e) {
			logger.warn("添加帐号出错:" + e.getMessage());
		}

	}

	// 进入婚外恋的查询页面
	public void outsideFind() {

		String key = getSessionAttr(getPara("key", ""));
		if ("true".equals(key)) {
			setAttr("key", getPara("key", ""));

			renderFreeMarker("outsideFind.html");
		} else {
			// 设置到错误页面
			setAttr("judgeError", "true");

			renderFreeMarker("fundCatalog.html");
		}

	}

	public void test() {
		renderFreeMarker("outsideResult.html");

		// renderFreeMarker("fundCatalog.html");
	}

	/**
	 * 会员根据输入手机号查找功能
	 *
	 * @param
	 * @return
	 */
	public void findPhone() {
		JSONObject json = new JSONObject();
		// boolean flag1 = true;
		// if (flag1) {
		//
		// json.put("nomal",
		// "[像像]、 [九秀美女直播间]、 [成人之美]、 [抱抱]、 [爱真心]、 [百合]、 [58交友]、 [我在找你]、 [见见]、
		// [Highing]、 [嘤嘤]、 [柏拉图]、 [么么直播]、 [繁星直播]、 [甜甜圈]");
		// json.put("legal", "蜜约]、 [九秀美女直播间]、 [今日有约]、 [有我]、 [红娘]、 [猜么]、 [约会说]、
		// [压寨]");
		// json.put("total",
		// "[探探]、[有缘网]、[有缘网]、 [像像]、 [蜜约]、 [metoo]、 [九秀美女直播间]、 [乐园交友]、 [影约]、
		// [今日有约]、 [寂寞美女约会]、 [有我]、 [抱抱]、 [行者]、 [敢聊]、 [真巧]、 [爱真心]、 [同城交友见见]、
		// [六间房秀场]、 [初夜约]、 [缘来婚恋]、 [百合]、 [58交友]、 [红娘]、 [赛客]、 [我在找你]、 [中国红娘网]、
		// [猜么]、 [约会说]、 [约会吧]、 [都秀嗨皮]、 [友寻交友]、 [约碰同城交友]、 [寂寞单身约会]、 [有约]、 [脸脸]、
		// [两面]、 [Tutu]、 [找到ta]、 [见见]、 [亲亲]、 [陌游]、 [Highing]、 [陌邻]、 [一说]、 [美缘网]、
		// [朋友印象]、 [实名相亲]、 [黑白校园]、 [啧啧]、 [美呼]、 [压寨]、 [火聊]、 [嘤嘤]、 [妙途]、 [柏拉图]、
		// [么么直播]、 [诱趣]、 [繁星直播]、 [聚微米]、 [ZANK]、 [GLOW]、 [甜甜圈]");
		// json.put("status", "0.00");
		//
		// renderJson(json.toString());
		// return;
		//
		// }

		String key = getSessionAttr(getPara("key", ""));
		if (!"true".equals(key)) {
			// 设置到错误页面
			json.put("errMsg", "您还没进行登陆,请退出登陆!");

			renderJson(json.toString());
			return;
		}

		String phones = getPara("findPhone", "");
		String[] arr = null;

		if (StringUtils.isEmpty(phones)) {
			// 给予么输入手机号提示
			json.put("errMsg", "请输入手机号:");

			renderJson(json.toString());
			return;
		}

		if (phones.indexOf(",") > -1) {
			arr = phones.split(",");
		} else if (phones.indexOf("") > -1) {
			arr = phones.split("，");
		} else {
			arr = new String[] { phones };
		}
		String partTimeStr = getPara("partTime", "");

		if (StringUtils.isEmpty(partTimeStr)) {
			json.put("errMsg", "请输入开始分开的时间:");

			renderJson(json.toString());
			return;
		}
		// 分手时间
		SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd");

		String operateSys = getPara("operateSys", "");
		if (StringUtils.isEmpty(operateSys)) {
			json.put("errMsg", "请输入对方的手机系统:");

			renderJson(json.toString());

			return;
		}
		// 是否注册过gay
		boolean flag = false;
		try {
			Date partTime = sFormat.parse(partTimeStr);
			// 加载产品上线的时间的配置
			Properties productOnlineTimePro = new Properties();
			productOnlineTimePro.load(new InputStreamReader(
					new FileInputStream(
							System.getProperty("user.dir") + "\\WebRoot\\properties\\productOnlineTimePro.properties"),
					"utf-8"));

			// 读取配置时间
			QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();//
			Map<String, String> map = null;
			JSONObject jsonObject = null;
			String string = null;
			Properties properties = new Properties();
			String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\queryphoneController.properties";
			properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));

			StringBuilder sb = new StringBuilder();
			// 正常能使用
			StringBuilder stringBuilder = new StringBuilder();
			// 总共
			StringBuilder sbtotal = new StringBuilder();

			List<Integer> list = new ArrayList<>();
			double regScore = 0;
			for (String phone : arr) {
				int regCount = 0;

				if (StringUtils.isEmpty(phone)) {
					continue;
				}
				if (!phone.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$")) {
					continue;
				}
				// 记录查询的手机号
				Record record = new Record();
				record.set("queryPhone", phone);
				record.set("queryPerson", getPara("key"));
				Db.save("queryRecord", record);

				// sb.append(properties.getProperty("RegStartTips") + phone +
				// RegitEnum.getRegMsgEnumCovert("RegTips"));
				sb.append(properties.getProperty("RegStartTips") + phone + RegitEnum.getRegMsgEnumCovert("RegTips"));
				try {

					sbtotal.append(properties.getProperty("tantanTips"));

					// 进入探探App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("tantan" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("tantan" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tantanUrl"),
									properties.getProperty("tantanParam") + phone
											+ properties.getProperty("tantanOtherParam"),
									queryPhoneSetAttr, properties.getProperty("tantanAttr"));
							jsonObject = JSONObject.fromObject(map.get("content"));
							if (jsonObject.get("message").equals(properties.getProperty("tantanRegMsg"))) {
								sb.append(properties.getProperty("tantanTips"));

								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("tantanScore"),
										productOnlineTimePro);

							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("tantanTips"));
				}
				try {
					sbtotal.append(properties.getProperty("jiqingyuehuiTips"));
					// 激情约会App查询--有缘网
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("jiqingyuehui" + operateSys + "Time"))) {
						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("jiqingyuehui" + operateSys + "Time")))) {

							HttpPost httpPost = new HttpPost(properties.getProperty("jiqingyuehuiUrl"));

							List<NameValuePair> params = new ArrayList<NameValuePair>();
							params.add(new BasicNameValuePair(properties.getProperty("jiqingyuehuiParam"), phone));
							httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));

							HttpResponse response = new DefaultHttpClient().execute(httpPost);
							if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
								String result = EntityUtils.toString(response.getEntity());
								if (result.equals(properties.getProperty("jiqingyuehuiRegMsg"))) {
									sb.append(properties.getProperty("jiqingyuehuiTips"));
									regCount++;
									regScore += CaluRatio.calScore(
											productOnlineTimePro.getProperty("jiqingyuehuiScore"),
											productOnlineTimePro);

								}
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("jiqingyuehuiTips"));
				}
				try {
					sbtotal.append(properties.getProperty("jiqingyuehuiTips"));
					// 单身交友App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("danshenjiaoyou" + operateSys + "Time"))) {
						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("danshenjiaoyou" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("danshenjiaoyouUrl"),

									properties.getProperty("danshenjiaoyouParam") + phone
											+ properties.getProperty("danshenjiaoyouOtherParam"),

									queryPhoneSetAttr, properties.getProperty("danshenjiaoyouAttr"));

							if (!map.get("content").equals("")) {
								sb.append(properties.getProperty("danshenjiaoyouTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("danshenjiaoyouScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("danshenjiaoyouTips"));
				}
				try {
					sbtotal.append(properties.getProperty("xiangxiangTips"));
					// 像像App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("xiangxiang" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("xiangxiang" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xiangxiangUrl"),

									properties.getProperty("xiangxiangParam") + phone
											+ properties.getProperty("xiangxiangOtherParam"),

									queryPhoneSetAttr, properties.getProperty("xiangxiangAttr"));
							if (JSONObject.fromObject(map.get("content")).toString()
									.indexOf(properties.getProperty("xiangxiangRegMsg")) > 0) {
								sb.append(properties.getProperty("xiangxiangTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("xiangxiangScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					stringBuilder.append(properties.getProperty("xiangxiangTips"));
					e1.printStackTrace();
				}
				try {
					sbtotal.append(properties.getProperty("miyueTips"));
					// 蜜约App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("miyue" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("miyue" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("miyueUrl"),

									properties.getProperty("miyueParam") + phone
											+ properties.getProperty("miyueOtherParam"),

									queryPhoneSetAttr, properties.getProperty("miyueAttr"));
							if (!JSONObject.fromObject(map.get("content")).get("message")
									.equals(properties.getProperty("miyueRegMsg"))) {
								sb.append(properties.getProperty("miyueTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("miyueScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					stringBuilder.append(properties.getProperty("miyueTips"));
					e1.printStackTrace();
				}
				try {
					sbtotal.append(properties.getProperty("metooTips"));
					// metooApp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("metoo" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("metoo" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("metooUrl"),

									properties.getProperty("metooParam") + phone
											+ properties.getProperty("metooOtherParam"),

									queryPhoneSetAttr, properties.getProperty("metooAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("error")
									.equals(properties.getProperty("metooRegMsg"))) {
								sb.append(properties.getProperty("metooTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("metooScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("metooTips"));
				}

				try {
					sbtotal.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
					// 九秀美女直播间App查询
					if (StringUtils.isNotEmpty(
							productOnlineTimePro.getProperty("jiuxiumeinvzhibojian" + operateSys + "Time"))) {
						if (partTime.before(sFormat.parse(
								productOnlineTimePro.getProperty("jiuxiumeinvzhibojian" + operateSys + "Time")))) {

							String msg = QyeryPhoneByProxyIp.httpURLConnectionGET(
									properties.getProperty("jiuxiumeinvzhibojianUrl"),

									properties.getProperty("jiuxiumeinvzhibojianParam") + phone
											+ properties.getProperty("jiuxiumeinvzhibojianOtherParam")

							);

							int code = Integer.parseInt(properties.getProperty("jiuxiumeinvzhibojianRegMsg"));
							if (!JSONObject.fromObject(msg).get("code").equals(code)) {

								sb.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("jiuxiumeinvzhibojianScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
				}
				try {
					sbtotal.append(properties.getProperty("leyuanjiaoyouTips"));
					// 乐园交友App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("leyuanjiaoyou" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("leyuanjiaoyou" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("leyuanjiaoyouUrl"),

									properties.getProperty("leyuanjiaoyouParam") + phone
											+ properties.getProperty("leyuanjiaoyouOtherParam"),

									queryPhoneSetAttr, properties.getProperty("leyuanjiaoyouAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("message")
									.equals(properties.getProperty("leyuanjiaoyouRegMsg"))) {
								sb.append(properties.getProperty("leyuanjiaoyouTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("leyuanjiaoyouScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
				}
				try {
					sbtotal.append(properties.getProperty("yingyueTips"));
					// 影约App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("yingyue" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("yingyue" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yingyueUrl"),

									properties.getProperty("yingyueParam") + phone
											+ properties.getProperty("yingyueOtherParam"),

									queryPhoneSetAttr, properties.getProperty("yingyueAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("msg")
									.equals(properties.getProperty("yingyueRegMsg"))) {
								sb.append(properties.getProperty("yingyueTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yingyueScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("yingyueRegMsg"));
				}
				try {
					sbtotal.append(properties.getProperty("jinriyouyueTips"));
					// 今日有约App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("jinriyouyue" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("jinriyouyue" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jinriyouyueUrl"),

									properties.getProperty("jinriyouyueParam") + phone
											+ properties.getProperty("jinriyouyueOtherParam"),

									queryPhoneSetAttr, properties.getProperty("jinriyouyueAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("tips")
									.equals(properties.getProperty("jinriyouyueRegMsg"))) {
								sb.append(properties.getProperty("jinriyouyueTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("jinriyouyueScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("jinriyouyueTips"));
				}
				try {
					sbtotal.append(properties.getProperty("jimomeinvyuehuiTips"));
					// 寂寞美女约会App查询--服务器貌似坏了
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("jimomeinvyuehui" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("jimomeinvyuehui" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
									properties.getProperty("jimomeinvyuehuiUrl"),

									properties.getProperty("jimomeinvyuehuiParam") + phone
											+ properties.getProperty("jimomeinvyuehuiOtherParam"),

									queryPhoneSetAttr, properties.getProperty("jimomeinvyuehuiAttr"));
							if (!JSONObject.fromObject(map.get("content")).get("event")
									.equals(properties.getProperty("jimomeinvyuehuiRegMsg"))) {
								sb.append(properties.getProperty("jimomeinvyuehuiTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("jimomeinvyuehuiScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					stringBuilder.append(properties.getProperty("jimomeinvyuehuiTips"));
				}

				try {
					sbtotal.append(properties.getProperty("youwoTips"));
					// 有我App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("youwo" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("youwo" + operateSys + "Time")))) {

							HttpClient client = new HttpClient();
							HttpMethod method = new GetMethod(
									properties.getProperty("youwoUrl") + "?" + properties.getProperty("youwoParam")
											+ phone + properties.getProperty("youwoOtherParam"));
							OutputStream os = new FileOutputStream(
									new File(System.getProperty("user.dir") + "\\WebRoot\\properties\\appLoading",
											properties.getProperty("youwoAttr")));
							client.executeMethod(method);
							if (method.getStatusCode() == HttpStatus.SC_OK) {
								InputStream is = method.getResponseBodyAsStream();
								byte[] b = new byte[1024];
								int len = 0;
								while ((len = is.read(b)) != -1) {
									os.write(b, 0, len);

									if (len != Integer.parseInt((properties.getProperty("youwoRegMsg")))) {
										sb.append(properties.getProperty("youwoTips"));
										regCount++;
										regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("youwoScore"),
												productOnlineTimePro);
									}
								}
							}
						}
					}
				} catch (Exception e) {
					stringBuilder.append(properties.getProperty("youwoTips"));
				}
				try {
					// 成人之美App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("chengrenzhimei" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("chengrenzhimei" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chengrenzhimeiUrl"),

									properties.getProperty("chengrenzhimeiParam") + phone
											+ properties.getProperty("chengrenzhimeiOtherParam"),

									queryPhoneSetAttr, properties.getProperty("chengrenzhimeiAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("errorInfo")
									.equals(properties.getProperty("chengrenzhimeiRegMsg"))) {
								sb.append(properties.getProperty("chengrenzhimeiTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("chengrenzhimeiScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("chengrenzhimeiTips"));
				}
				try {
					sbtotal.append(properties.getProperty("baobaoTips"));
					// 抱抱App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("baobao" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("baobao" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("baobaoUrl"),

									properties.getProperty("baobaoParam") + phone
											+ properties.getProperty("baobaoOtherParam"),

									queryPhoneSetAttr, properties.getProperty("baobaoAttr"));

							if (JSONObject.fromObject(map.get("content")).toString()

									.indexOf((properties.getProperty("baobaoRegMsg"))) > -1) {
								sb.append(properties.getProperty("baobaoTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("baobaoScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("baobaoTips"));
				}
				try {
					sbtotal.append(properties.getProperty("xingzheTips"));
					// 行者App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("xingzhe" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("xingzhe" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xingzheUrl"),

									properties.getProperty("xingzheParam") + phone
											+ properties.getProperty("xingzheOtherParam"),

									queryPhoneSetAttr, properties.getProperty("xingzheAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("errmsg")
									.equals(properties.getProperty("xingzheRegMsg"))) {
								sb.append(properties.getProperty("xingzheTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("xingzheScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("xingzheTips"));
				}

				try {
					sbtotal.append(properties.getProperty("ganliaoTips"));
					// 敢聊App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("ganliao" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("ganliao" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ganliaoUrl"),

									properties.getProperty("ganliaoParam") + phone
											+ properties.getProperty("ganliaoOtherParam"),

									queryPhoneSetAttr, properties.getProperty("ganliaoAttr"));

							if (JSONObject.fromObject(map.get("content")).get("code")
									.equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[0]))
									|| JSONObject.fromObject(map.get("content")).get("code").equals(
											Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[1]))) {
								sb.append(properties.getProperty("ganliaoTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("ganliaoScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					stringBuilder.append(properties.getProperty("ganliaoTips"));
				}
				try {
					sbtotal.append(properties.getProperty("zhenqiaoTips"));
					// 真巧App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("zhenqiao" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("zhenqiao" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhenqiaoUrl"),

									properties.getProperty("zhenqiaoParam") + phone
											+ properties.getProperty("zhenqiaoOtherParam"),

									queryPhoneSetAttr, properties.getProperty("zhenqiaoAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("msg")
									.equals(properties.getProperty("zhenqiaoRegMsg"))) {
								sb.append(properties.getProperty("zhenqiaoTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("zhenqiaoScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("zhenqiaoTips"));
				}

				// http: //
				// accounts.douban.com/login?uid=135307167&alias=15856316912&redir=https%3A%2F%2Fwww.douban.com%2F&source=index_nav&error=1013
				// Your browser should have redirected you to
				//
				// http://accounts.douban.com/login?uid=&alias=15924179757&redir=https%3A%2F%2Fwww.douban.com%2F&source=index_nav&error=1012
				// try {
				// // 豆瓣App查询----去掉
				// map =
				//
				// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("doubanUrl"),
				//
				// properties.getProperty("doubanParam") + phone +
				// properties.getProperty("doubanOtherParam"),
				//
				// queryPhoneSetAttr, properties.getProperty("doubanAttr"));
				//
				// if
				//
				// (map.get("content").indexOf(properties.getProperty("doubanRegMsg"))
				// > -1) {
				// sb.append(properties.getProperty("doubanTips"));
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("aizhenxinTips"));
					// 爱真心App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("aizhenxin" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("aizhenxin" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("aizhenxinUrl"),

									properties.getProperty("aizhenxinParam") + phone
											+ properties.getProperty("aizhenxinOtherParam"),

									queryPhoneSetAttr, properties.getProperty("aizhenxinAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("retmean")
									.equals(properties.getProperty("aizhenxinRegMsg"))) {
								sb.append(properties.getProperty("aizhenxinTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("aizhenxinScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("aizhenxinTips"));
				}
				try {
					sbtotal.append(properties.getProperty("tongchengjiaoyoujianjianTips"));
					// 同城交友见见App查询
					if (StringUtils.isNotEmpty(
							productOnlineTimePro.getProperty("tongchengjiaoyoujianjian" + operateSys + "Time"))) {

						if (partTime.before(sFormat.parse(
								productOnlineTimePro.getProperty("tongchengjiaoyoujianjian" + operateSys + "Time")))) {

							string = QyeryPhoneByProxyIp.httpURLConnectionGET(
									properties.getProperty("tongchengjiaoyoujianjianUrl"),

									properties.getProperty("tongchengjiaoyoujianjianParam") + phone
											+ properties.getProperty("tongchengjiaoyoujianjianOtherParam"));

							if ((!JSONObject.fromObject(string).get("message")
									.equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg"))
									&& !JSONObject.fromObject(string).get("message")
											.equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg1")))) {
								sb.append(properties.getProperty("tongchengjiaoyoujianjianTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("tongchengjiaoyoujianjianScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("tongchengjiaoyoujianjianTips"));
				}

				try {
					sbtotal.append(properties.getProperty("liujianfangxiuchangTips"));
					// 六间房秀场App查询
					if (StringUtils.isNotEmpty(
							productOnlineTimePro.getProperty("liujianfangxiuchang" + operateSys + "Time"))) {

						if (partTime.before(sFormat.parse(
								productOnlineTimePro.getProperty("liujianfangxiuchang" + operateSys + "Time")))) {

							string = QyeryPhoneByProxyIp.httpURLConnectionGET(
									properties.getProperty("liujianfangxiuchangUrl"),

									properties.getProperty("liujianfangxiuchangParam") + phone
											+ properties.getProperty("liujianfangxiuchangOtherParam"));

							if (string.indexOf(properties.getProperty("liujianfangxiuchangRegMsg")) == -1) {
								sb.append(properties.getProperty("liujianfangxiuchangTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("liujianfangxiuchangScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("liujianfangxiuchangTips"));
				}

				try {
					sbtotal.append(properties.getProperty("chuyeyueTips"));
					// 除夜约App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("chuyeyue" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("chuyeyue" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chuyeyueUrl"),

									properties.getProperty("chuyeyueParam") + phone
											+ properties.getProperty("chuyeyueOtherParam"),

									queryPhoneSetAttr, properties.getProperty("chuyeyueAttr"));

							if (JSONObject.fromObject(map.get("content")).get("error").toString()
									.indexOf(properties.getProperty("chuyeyueRegMsg")) == -1) {
								sb.append(properties.getProperty("chuyeyueTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("chuyeyueScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("chuyeyueTips"));
				}
				try {
					sbtotal.append(properties.getProperty("yuanlaihunlianTips"));
					// 缘来婚恋App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("yuanlaihunlian" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("yuanlaihunlian" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuanlaihunlianUrl"),

									properties.getProperty("yuanlaihunlianParam") + phone
											+ properties.getProperty("yuanlaihunlianOtherParam"),

									queryPhoneSetAttr, properties.getProperty("yuanlaihunlianAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("msg")
									.equals(properties.getProperty("yuanlaihunlianRegMsg"))) {
								sb.append(properties.getProperty("yuanlaihunlianTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yuanlaihunlianScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yuanlaihunlianTips"));
				}

				String str;
				try {
					sbtotal.append(properties.getProperty("baiheTips"));
					// 百合婚恋App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("baihe" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("baihe" + operateSys + "Time")))) {
							str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("baiheUrl"),
									"jsonCallBack=jQuery18307090277567040175_1451103749446&l1451103760230&email="
											+ phone + "&_=1451103760233");

							if (JSONObject.fromObject(str.substring(str.indexOf("{"), str.lastIndexOf(")"))).get("data")
									.equals(properties.getProperty("baiheRegMsg"))) {
								sb.append(properties.getProperty("baiheTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("baiheScore"),
										productOnlineTimePro);

							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("baiheTips"));
				}
				try {
					sbtotal.append(properties.getProperty("58jiaoyouTips"));
					// 58交友App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("58jiaoyou" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("58jiaoyou" + operateSys + "Time")))) {
							str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("58jiaoyouUrl"),
									properties.getProperty("58jiaoyouParam") + phone);

							if (str.indexOf(properties.getProperty("58jiaoyouRegMsg")) == -1) {
								sb.append(properties.getProperty("58jiaoyouTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("58jiaoyouScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("58jiaoyouTips"));
				}
				try {
					sbtotal.append(properties.getProperty("hongniangTips"));
					// 红娘App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("hongniang" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("hongniang" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("hongniangUrl"),

									properties.getProperty("hongniangParam") + phone
											+ properties.getProperty("hongniangOtherParam"),

									queryPhoneSetAttr, properties.getProperty("hongniangAttr"));

							if (!JSONObject.fromObject(map).get("content")
									.equals(properties.getProperty("hongniangRegMsg"))) {
								sb.append(properties.getProperty("hongniangTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("hongniangScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("hongniangTips"));
				}
				try {
					sbtotal.append(properties.getProperty("shaigeTips"));
					// 赛客App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("shaige" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("shaige" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shaigeUrl"),

									properties.getProperty("shaigeParam") + phone
											+ properties.getProperty("shaigeOtherParam"),

									queryPhoneSetAttr, properties.getProperty("shaigeAttr"));

							if (!JSONObject
									.fromObject(map.toString().substring(map.toString().indexOf("{\""),
											map.toString().indexOf("\"}") + 2))
									.get("desc").equals(properties.getProperty("shaigeRegMsg"))) {
								sb.append(properties.getProperty("shaigeTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("shaigeScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("shaigeTips"));
				}
				try {
					sbtotal.append(properties.getProperty("wozaizhaoniTips"));
					// 我在找你App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("wozaizhaoni" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("wozaizhaoni" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("wozaizhaoniUrl"),

									properties.getProperty("wozaizhaoniParam") + phone
											+ properties.getProperty("wozaizhaoniOtherParam"),

									queryPhoneSetAttr, properties.getProperty("wozaizhaoniAttr"));

							if (!JSONObject.fromObject(map).get("content")
									.equals(properties.getProperty("wozaizhaoniRegMsg"))) {
								sb.append(properties.getProperty("wozaizhaoniTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("wozaizhaoniScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("wozaizhaoniTips"));
				}
				try {
					sbtotal.append(properties.getProperty("zhongguohongniangwangTips"));
					// 中国红娘网App查询
					if (StringUtils.isNotEmpty(
							productOnlineTimePro.getProperty("zhongguohongniangwang" + operateSys + "Time"))) {

						if (partTime.before(sFormat.parse(
								productOnlineTimePro.getProperty("zhongguohongniangwang" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
									properties.getProperty("zhongguohongniangwangUrl"),

									properties.getProperty("zhongguohongniangwangParam") + phone
											+ properties.getProperty("zhongguohongniangwangOtherParam") + phone,

									queryPhoneSetAttr, properties.getProperty("zhongguohongniangwangAttr"));
							if (!JSONObject.fromObject(map).get("content")
									.equals(properties.getProperty("zhongguohongniangwangRegMsg"))) {
								sb.append(properties.getProperty("zhongguohongniangwangTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("zhongguohongniangwangScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("zhongguohongniangwangTips"));
				}
				// try {
				// // 若邻App查询---求职
				// if
				// (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("ruoling"
				// + operateSys + "Time"))) {
				//
				// if (partTime.before(
				// sFormat.parse(productOnlineTimePro.getProperty("ruoling" +
				// operateSys + "Time")))) {
				//
				// map =
				// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ruolingUrl"),
				//
				// properties.getProperty("ruolingParam") + phone
				// + properties.getProperty("ruolingOtherParam"),
				//
				// queryPhoneSetAttr, properties.getProperty("ruolingAttr"));
				//
				// if (!JSONObject.fromObject(map).get("content")
				// .equals(properties.getProperty("ruolingRegMsg"))) {
				// sb.append(properties.getProperty("ruolingTips"));
				// regCount++;
				// regScore +=
				// CaluRatio.calScore(productOnlineTimePro.getProperty("ruolingScore"),
				// productOnlineTimePro);
				// }
				// }
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("caimeTips"));
					// 猜么App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("caime" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("caime" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("caimeUrl"),

									properties.getProperty("caimeParam") + phone
											+ properties.getProperty("caimeOtherParam"),

									queryPhoneSetAttr, properties.getProperty("caimeAttr"));

							if (!JSONObject
									.fromObject(map.toString().substring(map.toString().indexOf("{\""),
											map.toString().lastIndexOf(",")))
									.get("msg").equals(properties.getProperty("caimeRegMsg"))) {
								sb.append(properties.getProperty("caimeTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("caimeScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("caimeTips"));
				}
				try {
					sbtotal.append(properties.getProperty("yuehuishuoTips"));
					// 约会说App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("yuehuishuo" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("yuehuishuo" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuehuishuoUrl"),

									properties.getProperty("yuehuishuoParam") + phone
											+ properties.getProperty("yuehuishuoOtherParam"),

									queryPhoneSetAttr, properties.getProperty("yuehuishuoAttr"));
							String st = UnicodeConverChinese.decodeUnicode(
									map.get("content").substring(16, map.get("content").lastIndexOf("\"}")));
							if (!st.equals("用户名不存在！")) {
								sb.append(properties.getProperty("yuehuishuoTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yuehuishuoScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yuehuishuoTips"));
				}

				try {
					sbtotal.append(properties.getProperty("yuihuibaTips"));
					// 约会吧App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("yuihuiba" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("yuihuiba" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuihuibaUrl"),

									properties.getProperty("yuihuibaParam") + phone
											+ properties.getProperty("yuihuibaOtherParam"),

									queryPhoneSetAttr, properties.getProperty("yuihuibaAttr"));

							if (!JSONObject.fromObject(map).get("content")
									.equals(properties.getProperty("yuihuibaRegMsg"))) {
								sb.append(properties.getProperty("yuihuibaTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yuihuibaScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yuihuibaTips"));
				}
				try {
					sbtotal.append(properties.getProperty("douxiuhaipiTips"));
					// 都秀嗨皮App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("douxiuhaipi" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("douxiuhaipi" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("douxiuhaipiUrl"),

									properties.getProperty("douxiuhaipiParam") + phone
											+ properties.getProperty("douxiuhaipiOtherParam"),

									queryPhoneSetAttr, properties.getProperty("douxiuhaipiAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("msg")
									.equals(properties.getProperty("douxiuhaipiRegMsg"))) {
								sb.append(properties.getProperty("douxiuhaipiTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("douxiuhaipiScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("douxiuhaipiTips"));
				}
				try {
					sbtotal.append(properties.getProperty("youxunjiaoyouTips"));
					// 友寻交友App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("youxunjiaoyou" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("youxunjiaoyou" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youxunjiaoyouUrl"),

									properties.getProperty("youxunjiaoyouParam") + phone
											+ properties.getProperty("youxunjiaoyouOtherParam"),

									queryPhoneSetAttr, properties.getProperty("youxunjiaoyouAttr"));

							if ((Integer) JSONObject.fromObject(map.toString()
									.substring(map.toString().indexOf(":{\"") + 1, map.toString().lastIndexOf(",")))
									.get("status") != Integer.parseInt(properties.getProperty("youxunjiaoyouRegMsg"))) {
								sb.append(properties.getProperty("youxunjiaoyouTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("youxunjiaoyouScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("youxunjiaoyouTips"));
				}
				// try {
				// // 人脉通App查询---去掉
				// f (StringUtils
				// .isNotEmpty(productOnlineTimePro.getProperty("renmaitong" +
				// operateSys + "Time"))) {
				//
				// if (partTime.before(
				// sFormat.parse(productOnlineTimePro.getProperty("renmaitong" +
				// operateSys + "Time")))) {
				//
				// map =
				// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("renmaitongUrl"),
				//
				// properties.getProperty("renmaitongParam") + phone
				// + properties.getProperty("renmaitongOtherParam"),
				//
				// queryPhoneSetAttr, properties.getProperty("renmaitongAttr"));
				//
				// if
				// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf(":{\"")
				// + 1,
				// map.toString().lastIndexOf(","))).get("Tips")
				//
				// .equals(properties.getProperty("renmaitongRegMsg"))) {
				// sb.append(properties.getProperty("renmaitongTips"));
				// regCount++;
				// }
				// }
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("yuepengtongchengjiaoyouTips"));
					// 约碰同城交友App查询
					if (StringUtils.isNotEmpty(
							productOnlineTimePro.getProperty("yuepengtongchengjiaoyou" + operateSys + "Time"))) {

						if (partTime.before(sFormat.parse(
								productOnlineTimePro.getProperty("yuepengtongchengjiaoyou" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
									properties.getProperty("yuepengtongchengjiaoyouUrl"),

									properties.getProperty("yuepengtongchengjiaoyouParam") + phone
											+ properties.getProperty("yuepengtongchengjiaoyouOtherParam"),

									queryPhoneSetAttr, properties.getProperty("yuepengtongchengjiaoyouAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("msg")

									.equals(properties.getProperty("yuepengtongchengjiaoyouRegMsg"))) {
								sb.append(properties.getProperty("yuepengtongchengjiaoyouTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("yuepengtongchengjiaoyouScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yuepengtongchengjiaoyouTips"));
				}
				try {
					sbtotal.append(properties.getProperty("jimodanshenyuehuiTips"));
					// 寂寞单身约会App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("jimodanshenyuehui" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("jimodanshenyuehui" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
									properties.getProperty("jimodanshenyuehuiUrl"),

									properties.getProperty("jimodanshenyuehuiParam") + phone
											+ properties.getProperty("jimodanshenyuehuiOtherParam"),

									queryPhoneSetAttr, properties.getProperty("jimodanshenyuehuiAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("event")

									.equals(properties.getProperty("jimodanshenyuehuiRegMsg")))

							{
								sb.append(properties.getProperty("jimodanshenyuehuiTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("jimodanshenyuehuiScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("jimodanshenyuehuiTips"));
				}
				try {
					sbtotal.append(properties.getProperty("youyueTips"));
					// 有约App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("youyue" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("youyue" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youyueUrl"),

									properties.getProperty("youyueParam") + phone
											+ properties.getProperty("youyueOtherParam"),

									queryPhoneSetAttr, properties.getProperty("youyueAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("error_info")

									.equals(properties.getProperty("youyueRegMsg")))

							{
								sb.append(properties.getProperty("youyueTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("youyueScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("youyueTips"));
				}
				try {
					sbtotal.append(properties.getProperty("lianlianTips"));
					// 脸脸App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("lianlian" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("lianlian" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lianlianUrl"),

									properties.getProperty("lianlianParam") + phone
											+ properties.getProperty("lianlianOtherParam"),

									queryPhoneSetAttr, properties.getProperty("lianlianAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("error")

									.equals(properties.getProperty("lianlianRegMsg")))

							{
								sb.append(properties.getProperty("lianlianTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("lianlianScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("lianlianTips"));
				}
				try {
					sbtotal.append(properties.getProperty("liangmianTips"));
					// 两面App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("liangmian" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("liangmian" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("liangmianUrl"),

									properties.getProperty("liangmianParam") + phone
											+ properties.getProperty("liangmianOtherParam"),

									queryPhoneSetAttr, properties.getProperty("liangmianAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("code_msg")

									.equals(properties.getProperty("liangmianRegMsg")))

							{
								sb.append(properties.getProperty("liangmianTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("liangmianScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("liangmianTips"));
				}
				try {
					sbtotal.append(properties.getProperty("tutuTips"));
					// TutuApp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("tutu" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("tutu" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tutuUrl"),

									properties.getProperty("tutuParam") + phone
											+ properties.getProperty("tutuOtherParam"),

									queryPhoneSetAttr, properties.getProperty("tutuAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("desc")

									.equals(properties.getProperty("tutuRegMsg")))

							{
								sb.append(properties.getProperty("tutuTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("tutuScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("tutuTips"));
				}
				try {
					sbtotal.append(properties.getProperty("zhaodaotaTips"));
					// 找到taApp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("zhaodaota" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("zhaodaota" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhaodaotaUrl"),

									properties.getProperty("zhaodaotaParam") + phone
											+ properties.getProperty("zhaodaotaOtherParam"),

									queryPhoneSetAttr, properties.getProperty("zhaodaotaAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("msg")

									.equals(properties.getProperty("zhaodaotaRegMsg")))

							{
								sb.append(properties.getProperty("zhaodaotaTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("zhaodaotaScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("zhaodaotaTips"));
				}
				try {
					sbtotal.append(properties.getProperty("jianjianTips"));
					// 见见App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("jianjian" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("jianjian" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jianjianUrl"),

									properties.getProperty("jianjianParam") + phone
											+ properties.getProperty("jianjianOtherParam"),

									queryPhoneSetAttr, properties.getProperty("jianjianAttr"));

							if (JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("ret")

									.equals(properties.getProperty("jianjianRegMsg"))) {
								sb.append(properties.getProperty("jianjianTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("jianjianScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("jianjianTips"));
				}
				try {
					sbtotal.append(properties.getProperty("qinqinTips"));
					// 亲亲App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("qinqin" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("qinqin" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("qinqinUrl"),

									properties.getProperty("qinqinParam") + phone
											+ properties.getProperty("qinqinOtherParam"),

									queryPhoneSetAttr, properties.getProperty("qinqinAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("errorMsg")

									.equals(properties.getProperty("qinqinRegMsg"))) {
								sb.append(properties.getProperty("qinqinTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("qinqinScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("qinqinTips"));
				}
				try {
					sbtotal.append(properties.getProperty("moyouTips"));
					// 陌游App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("moyou" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("moyou" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moyouUrl"),

									properties.getProperty("moyouParam") + phone
											+ properties.getProperty("moyouOtherParam"),

									queryPhoneSetAttr, properties.getProperty("moyouAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(","))).get("entity")

									.equals(properties.getProperty("moyouRegMsg")))

							{
								sb.append(properties.getProperty("moyouTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("moyouScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("moyouTips"));
				}
				try {
					sbtotal.append(properties.getProperty("HighingTips"));
					// HighingApp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("highing" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("highing" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("HighingUrl"),

									properties.getProperty("HighingParam") + phone
											+ properties.getProperty("HighingOtherParam"),

									queryPhoneSetAttr, properties.getProperty("HighingAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(","))).get("state")

									.equals(Integer.parseInt(properties.getProperty("HighingRegMsg"))))

							{
								sb.append(properties.getProperty("HighingTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("highingScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("HighingTips"));
				}
				try {
					sbtotal.append(properties.getProperty("moulingTips"));
					// 陌邻App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("mouling" + operateSys + "Time"))) {

						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("mouling" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moulingUrl"),

									properties.getProperty("moulingParam") + phone
											+ properties.getProperty("moulingOtherParam"),

									queryPhoneSetAttr, properties.getProperty("moulingAttr"));

							if (!JSONObject
									.fromObject(map.toString().substring(map.toString().indexOf("{\""),
											map.toString().lastIndexOf(",")))
									.get("message").equals(properties.getProperty("moulingRegMsg")))

							{
								sb.append(properties.getProperty("moulingTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("moulingScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("moulingTips"));
				}
				try {
					sbtotal.append(properties.getProperty("yishuoTips"));
					// 一说App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("yishuo" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("yishuo" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yishuoUrl"),

									properties.getProperty("yishuoParam") + phone,

									queryPhoneSetAttr, properties.getProperty("yishuoAttr"));

							if (!JSONObject
									.fromObject(map.toString().substring(map.toString().indexOf("{\""),
											map.toString().lastIndexOf(",")))
									.get("msg").equals(properties.getProperty("yishuoRegMsg")))

							{
								sb.append(properties.getProperty("yishuoTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yishuoScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yishuoTips"));
				}
				// try {
				// // 微微App查询--电话去掉
				// if
				// (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("weiwei"
				// + operateSys + "Time"))) {
				// if (partTime.before(
				// sFormat.parse(productOnlineTimePro.getProperty("weiwei" +
				// operateSys + "Time")))) {
				//
				// map =
				// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("weiweiUrl"),
				//
				// properties.getProperty("weiweiParam") + phone
				// + properties.getProperty("weiweiOtherParam"),
				//
				// queryPhoneSetAttr, properties.getProperty("weiweiAttr"));
				//
				// if (!map.toString()
				// .substring(map.toString().lastIndexOf("<error>") + 7,
				// map.toString().lastIndexOf("</error>"))
				// .equals(properties.getProperty("weiweiRegMsg")))
				//
				// {
				// sb.append(properties.getProperty("weiweiTips"));
				// regCount++;
				// }
				// }
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("meiyuanwangTips"));
					// 美缘网App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("meiyuanwang" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("meiyuanwang" + operateSys + "Time")))) {

							str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("meiyuanwangUrl"),

									"username=" + phone + "&password=879227577&fromsys=7");
							if (!JSONObject.fromObject(str).get("return_content")
									.equals(properties.getProperty("meiyuanwangRegMsg"))) {
								sb.append(properties.getProperty("meiyuanwangTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("meiyuanwangScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("meiyuanwangTips"));
				}
				// try {
				// // 到喜啦App查询---去掉
				// if
				// (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("daoxila"
				// + operateSys + "Time"))) {
				// if (partTime.before(
				// sFormat.parse(productOnlineTimePro.getProperty("daoxila" +
				// operateSys + "Time")))) {
				//
				// String map1 =
				// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("daoxilaUrl"),
				//
				// properties.getProperty("daoxilaParam") + phone
				// + properties.getProperty("daoxilaOtherParam"));
				// if
				// (!JSONObject.fromObject(map1.toString().substring(map1.toString().indexOf("{\""),
				// map1.toString().lastIndexOf(")"))).get("msg")
				//
				// .equals(properties.getProperty("daoxilaRegMsg")))
				//
				// {
				// sb.append(properties.getProperty("daoxilaTips"));
				// regCount++;
				// }
				// }
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("pengyouyingxiangTips"));
					// 朋友印象App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("pengyouyingxiang" + operateSys + "Time"))) {
						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("pengyouyingxiang" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
									properties.getProperty("pengyouyingxiangUrl"),

									properties.getProperty("pengyouyingxiangParam") + phone
											+ properties.getProperty("pengyouyingxiangOtherParam"),

									queryPhoneSetAttr, properties.getProperty("pengyouyingxiangAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(","))).get("message")

									.equals(properties.getProperty("pengyouyingxiangRegMsg")))

							{
								sb.append(properties.getProperty("pengyouyingxiangTips"));
								regCount++;
								regScore += CaluRatio.calScore(
										productOnlineTimePro.getProperty("pengyouyingxiangScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("pengyouyingxiangTips"));
				}
				try {
					sbtotal.append(properties.getProperty("shimingxiangqinTips"));
					// 实名相亲App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("shimingxiangqin" + operateSys + "Time"))) {

						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("shimingxiangqin" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
									properties.getProperty("shimingxiangqinUrl"),

									properties.getProperty("shimingxiangqinParam") + phone
											+ properties.getProperty("shimingxiangqinOtherParam"),

									queryPhoneSetAttr, properties.getProperty("shimingxiangqinAttr"));

							if (map.toString().indexOf(properties.getProperty("shimingxiangqinRegMsg")) == -1)

							{
								sb.append(properties.getProperty("shimingxiangqinTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("shimingxiangqinScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("shimingxiangqinTips"));
				}

				// httpPost = new
				// HttpPost("http://api.stuhui.com/club/login");
				// params = new ArrayList<NameValuePair>();
				// params.add(new BasicNameValuePair("act", "login_ajax"));
				// params.add(new BasicNameValuePair("mobile", phone));
				// params.add(new BasicNameValuePair("code", "879227577"));
				// httpPost.setEntity(new UrlEncodedFormEntity(params,
				// "utf-8"));
				// response = new DefaultHttpClient().execute(httpPost);
				// if (response.getStatusLine().getStatusCode() ==
				// HttpStatus.SC_OK) {
				// String result =
				// EntityUtils.toString(response.getEntity());
				// System.out.println(result);
				// }
				//
				// if (!JSONObject
				//
				// .fromObject(map.toString().substring(map.toString().indexOf("{\""),
				// map.toString().lastIndexOf(",")))
				// .get("msg")
				//
				// .equals(properties.getProperty("heibaixiaoyuanRegMsg"))) {
				// sb.append(properties.getProperty("heibaixiaoyuanTips"));
				// }
				try {
					sbtotal.append(properties.getProperty("heibaixiaoyuanTips"));
					// 黑白校园App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("heibaixiaoyuan" + operateSys + "Time"))) {
						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("heibaixiaoyuan" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("heibaixiaoyuanUrl"),

									properties.getProperty("heibaixiaoyuanParam") + phone
											+ properties.getProperty("heibaixiaoyuanOtherParam"),

									queryPhoneSetAttr, properties.getProperty("heibaixiaoyuanAttr"));

							String string2 = (String) JSONObject.fromObject(map.toString()
									.substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
									.get("msg");

							if (!string2.equals(properties.getProperty("heibaixiaoyuanRegMsg"))
									&& !string2.equals(properties.getProperty("heibaixiaoyuanRegMsg1")))

							{
								sb.append(properties.getProperty("heibaixiaoyuanTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("heibaixiaoyuanScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("heibaixiaoyuanTips"));
				}
				// try {
				// // 推友App查询--去掉
				// if
				// (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("tuiyou"
				// + operateSys + "Time"))) {
				// if (partTime.before(
				// sFormat.parse(productOnlineTimePro.getProperty("tuiyou" +
				// operateSys + "Time")))) {
				//
				// map =
				// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tuiyouUrl"),
				//
				// properties.getProperty("tuiyouParam") + phone
				// + properties.getProperty("tuiyouOtherParam"),
				//
				// queryPhoneSetAttr, properties.getProperty("tuiyouAttr"));
				//
				// if
				// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
				// map.toString().lastIndexOf(","))).get("msg")
				//
				// .equals(properties.getProperty("tuiyouRegMsg")))
				//
				// {
				// sb.append(properties.getProperty("tuiyouTips"));
				// regCount++;
				// regScore +=
				// CaluRatio.calScore(productOnlineTimePro.getProperty("tuiyouScore"),
				// productOnlineTimePro);
				// }
				// }
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("zezeTips"));
					// 啧啧App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("zeze" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("zeze" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zezeUrl"),

									properties.getProperty("zezeParam") + phone
											+ properties.getProperty("zezeOtherParam"),

									queryPhoneSetAttr, properties.getProperty("zezeAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(","))).get("code")

									.equals(Integer.parseInt(properties.getProperty("zezeRegMsg"))))

							{
								sb.append(properties.getProperty("zezeTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("zezeScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("zezeTips"));
				}
				try {
					sbtotal.append(properties.getProperty("meihuTips"));
					// 美呼App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("meihu" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("meihu" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("meihuUrl"),

									properties.getProperty("meihuParam") + phone
											+ properties.getProperty("meihuOtherParam"),

									queryPhoneSetAttr, properties.getProperty("meihuAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(","))).get("event")

									.equals(properties.getProperty("meihuRegMsg")))

							{
								sb.append(properties.getProperty("meihuTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("meihuScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("meihuTips"));
				}
				try {
					sbtotal.append(properties.getProperty("yazhaiTips"));
					// 压寨App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("yazhai" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("yazhai" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yazhaiUrl"),

									properties.getProperty("yazhaiParam") + phone
											+ properties.getProperty("yazhaiOtherParam"),

									queryPhoneSetAttr, properties.getProperty("yazhaiAttr"));

							if (!map.toString()
									.substring(map.toString().indexOf("=") + 1, map.toString().lastIndexOf(","))
									.equals(properties.getProperty("yazhaiRegMsg")))

							{
								sb.append(properties.getProperty("yazhaiTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yazhaiScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yazhaiTips"));
				}
				try {
					sbtotal.append(properties.getProperty("huoliaoTips"));
					// 火聊pp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("huoliao" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("huoliao" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("huoliaoUrl"),

									properties.getProperty("huoliaoParam") + phone
											+ properties.getProperty("huoliaoOtherParam"),

									queryPhoneSetAttr, properties.getProperty("huoliaoAttr"));

							if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
									map.toString().lastIndexOf(","))).get("errorMsg")

									.equals(properties.getProperty("huoliaoRegMsg")))

							{
								sb.append(properties.getProperty("huoliaoTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("huoliaoScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("huoliaoTips"));
				}
				try {
					sbtotal.append(properties.getProperty("yingyingTips"));
					// 嘤嘤App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("yingying" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("yingying" + operateSys + "Time")))) {

							str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("yingyingUrl"),

									properties.getProperty("yingyingParam") + phone
											+ properties.getProperty("yingyingOtherParam"));

							if (!JSONObject.fromObject(str).get("code")
									.equals(properties.getProperty("yingyingRegMsg")))

							{
								sb.append(properties.getProperty("yingyingTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("yingyingScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("yingyingTips"));
				}
				// try {
				// // k歌房App查询--去掉
				// if
				// (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("kgefang"
				// + operateSys + "Time"))) {
				// if (partTime.before(
				// sFormat.parse(productOnlineTimePro.getProperty("kgefang" +
				// operateSys + "Time")))) {
				//
				// map =
				// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("kgefangUrl"),
				//
				// properties.getProperty("kgefangParam") + phone
				// + properties.getProperty("kgefangOtherParam"),
				//
				// queryPhoneSetAttr, properties.getProperty("kgefangAttr"));
				//
				// if
				// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("{\""),
				// map.toString().lastIndexOf(","))).get("msg")
				//
				// .equals(properties.getProperty("kgefangRegMsg")))
				//
				// {
				// sb.append(properties.getProperty("kgefangTips"));
				// regCount++;
				// regScore +=
				// CaluRatio.calScore(productOnlineTimePro.getProperty("kgefangScore"),
				// productOnlineTimePro);
				// }
				// }
				// }
				// } catch (Exception e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				try {
					sbtotal.append(properties.getProperty("miaotuTips"));
					// 妙途App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("miaotu" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("miaotu" + operateSys + "Time")))) {
							string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("miaotuUrl"),

									properties.getProperty("miaotuParam") + phone);

							if (!JSONObject.fromObject(string).get("Msg")
									.equals(properties.getProperty("miaotuRegMsg")))

							{
								sb.append(properties.getProperty("miaotuTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("miaotuScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("miaotuTips"));
				}

				try {
					sbtotal.append(properties.getProperty("bolatuTips"));
					// 柏拉图App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("bolatu" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("bolatu" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("bolatuUrl"),

									properties.getProperty("bolatuParam") + phone
											+ properties.getProperty("bolatuOtherParam"),

									queryPhoneSetAttr, properties.getProperty("bolatuAttr"));

							if (!JSONObject.fromObject(map.get("content")).get("msg")
									.equals(properties.getProperty("bolatuRegMsg"))) {
								sb.append(properties.getProperty("bolatuTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("bolatuScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("bolatuTips"));
				}
				try {
					sbtotal.append(properties.getProperty("memezhiboTips"));
					// 么么直播App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("memezhibo" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("memezhibo" + operateSys + "Time")))) {

							string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("memezhiboUrl"),

									properties.getProperty("memezhiboParam") + phone);
							if (JSONObject.fromObject(string).get("code").toString()
									.equals(properties.getProperty("memezhiboRegMsg"))) {
								sb.append(properties.getProperty("memezhiboTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("memezhiboScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("memezhiboTips"));
				}
				try {
					sbtotal.append(properties.getProperty("youquTips"));
					// 诱趣App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("youqu" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("youqu" + operateSys + "Time")))) {

							org.apache.http.client.HttpClient httpClient = HttpClients.createDefault();
							HttpPost httpPost = new HttpPost(properties.getProperty("youquUrl"));
							JSONObject jso = new JSONObject();
							jso.put("UniqueIdentifier", phone);
							jso.put("PassWord", "nzksms");
							jso.put("APPMark", "com.wenweikj.www");
							jso.put("DeviceCode", properties.getProperty("youquParam"));

							StringEntity entity = new StringEntity(jso.toString(), "utf-8");
							entity.setContentEncoding("UTF-8");
							entity.setContentType("application/jso");
							httpPost.setEntity(entity);
							httpPost.setHeader("Authorization", properties.getProperty("youquOtherParam"));
							HttpResponse response = httpClient.execute(httpPost);
							HttpEntity httpEntity = response.getEntity();
							jso = JSONObject.fromObject(EntityUtils.toString(httpEntity, "utf-8"));
							if (!jso.get("Remark").equals(properties.getProperty("youquRegMsg"))) {
								sb.append(properties.getProperty("youquTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("youquScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					stringBuilder.append(properties.getProperty("youquTips"));
				}

				try {
					sbtotal.append(properties.getProperty("fanxingzhiboTips"));
					// 繁星直播App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("fanxingzhibo" + operateSys + "Time"))) {
						if (partTime.before(sFormat
								.parse(productOnlineTimePro.getProperty("fanxingzhibo" + operateSys + "Time")))) {

							org.apache.http.client.HttpClient httpClient = HttpClients.createDefault();
							HttpPost httpPost = new HttpPost(properties.getProperty("fanxingzhiboUrl"));
							JSONObject jso = new JSONObject();
							jso.put("clienttime", properties.getProperty("fanxingzhiboTime"));
							jso.put("p", properties.getProperty("fanxingzhiboParam"));
							jso.put("mid", "b997523eada19eb9d02d84b859b0b00f8cb104f8");
							jso.put("clientver", "2808");
							jso.put("username", phone);
							jso.put("key", properties.getProperty("fanxingzhiboOtherParam"));
							jso.put("appid", "1131");
							StringEntity entity = new StringEntity(jso.toString(), "utf-8");// 解决中文乱码问题
							entity.setContentEncoding("UTF-8");
							entity.setContentType("application/json");

							httpPost.setEntity(entity);
							HttpResponse response = httpClient.execute(httpPost);
							HttpEntity httpEntity = response.getEntity();
							jso = JSONObject.fromObject(EntityUtils.toString(httpEntity, "utf-8"));

							if (jso.get("error_code").toString().equals(properties.getProperty("fanxingzhiboRegMsg"))) {
								sb.append(properties.getProperty("fanxingzhiboTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("fanxingzhiboScore"),
										productOnlineTimePro);
							}
						}
					}

				} catch (Exception e) {
					// TODO: handle exception
					stringBuilder.append(properties.getProperty("fanxingzhiboTips"));
				}

				try {
					sbtotal.append(properties.getProperty("juweimiTips"));
					// 聚微米App查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("juweimi" + operateSys + "Time"))) {
						if (partTime.before(
								sFormat.parse(productOnlineTimePro.getProperty("juweimi" + operateSys + "Time")))) {

							map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("juweimiUrl"),

									properties.getProperty("juweimiParam") + phone
											+ properties.getProperty("juweimiOtherParam"),

									queryPhoneSetAttr, properties.getProperty("juweimiAttr"));
							if (!JSONObject.fromObject(map.get("content")).get("msg")
									.equals(properties.getProperty("juweimiRegMsg"))) {
								sb.append(properties.getProperty("juweimiTips"));
								regCount++;
								regScore += CaluRatio.calScore(productOnlineTimePro.getProperty("juweimiScore"),
										productOnlineTimePro);
							}
						}
					}
				} catch (Exception e) {
					// TODO: handle exception
					stringBuilder.append(properties.getProperty("juweimiTips"));
				}
				// ----gay----------------------------------
				try {
					sbtotal.append(properties.getProperty("ZANKTips"));
					// ZANKApp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("ZANK" + operateSys + "Time"))) {

						string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("ZANKUrl"),

								properties.getProperty("ZANKParam") + phone + properties.getProperty("ZANKOtherParam"));

						if (!JSONObject.fromObject(string).get("error").equals(properties.getProperty("ZANKRegMsg"))) {
							sb.append(properties.getProperty("ZANKTips"));
							regCount++;
							flag = true;
							if (partTime.before(
									sFormat.parse(productOnlineTimePro.getProperty("ZANK" + operateSys + "Time")))) {
								regScore += (1 / Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
										* Double.parseDouble(productOnlineTimePro.getProperty("ZANKScore"))
										+ Double.parseDouble(productOnlineTimePro.getProperty("appGayBefore"));
							} else {
								regScore += (1 / Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
										* Double.parseDouble(productOnlineTimePro.getProperty("ZANKScore"))
										+ Double.parseDouble(productOnlineTimePro.getProperty("appGayAfter"));
							}
						}

					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("ZANKTips"));
				}
				try {
					// 左左App查询----有弊端啊。-没有注册的第一次都被注册了暂时不进入
					// if
					// (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("zuozuo"
					// + operateSys + "Time"))) {
					//
					// org.apache.http.client.HttpClient httpClient =
					// HttpClients.createDefault();
					// HttpPost httpPost = new
					// HttpPost(properties.getProperty("zuozuoUrl"));
					// JSONObject jso = new JSONObject();
					// jso.put("v", properties.getProperty("zuozuoParam"));
					// jso.put("username", phone);
					// jso.put("password", "njjnnnnnm");
					// StringEntity entity = new StringEntity(jso.toString(),
					// "utf-8");
					// entity.setContentEncoding("UTF-8");
					// entity.setContentType("application/json");
					//
					// httpPost.setEntity(entity);
					// HttpResponse response = httpClient.execute(httpPost);
					// HttpEntity httpEntity = response.getEntity();
					// jso =
					// JSONObject.fromObject(EntityUtils.toString(httpEntity,
					// "utf-8"));
					// if
					// (jso.get("msg").toString().equals(properties.getProperty("zuozuoRegMsg")))
					// {
					// sb.append(properties.getProperty("zuozuoTips"));
					// regCount++;
					// flag = true;
					// if (partTime.before(
					// sFormat.parse(productOnlineTimePro.getProperty("zuozuo" +
					// operateSys + "Time")))) {
					// regScore += (1 /
					// Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
					// *
					// Double.parseDouble(productOnlineTimePro.getProperty("zuozuoScore"))
					// +
					// Double.parseDouble(productOnlineTimePro.getProperty("appGayBefore"));
					// } else {
					// regScore += (1 /
					// Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
					// *
					// Double.parseDouble(productOnlineTimePro.getProperty("zuozuoScore"))
					// +
					// Double.parseDouble(productOnlineTimePro.getProperty("appGayAfter"));
					// }
					// }
					//
					// }
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					sbtotal.append(properties.getProperty("glowTips"));
					// GLOWApp查询
					if (StringUtils.isNotEmpty(productOnlineTimePro.getProperty("glow" + operateSys + "Time"))) {

						map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("glowUrl"),

								properties.getProperty("glowParam") + phone + properties.getProperty("glowOtherParam"),

								queryPhoneSetAttr, properties.getProperty("glowAttr"));
						if (!JSONObject.fromObject(map.get("content")).get("message")
								.equals(properties.getProperty("glowRegMsg"))) {
							sb.append(properties.getProperty("glowTips"));
							regCount++;
							flag = true;
							if (partTime.before(
									sFormat.parse(productOnlineTimePro.getProperty("glow" + operateSys + "Time")))) {
								regScore += (1 / Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
										* Double.parseDouble(productOnlineTimePro.getProperty("glowScore"))
										+ Double.parseDouble(productOnlineTimePro.getProperty("appGayBefore"));
							} else {
								regScore += (1 / Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
										* Double.parseDouble(productOnlineTimePro.getProperty("glowScore"))
										+ Double.parseDouble(productOnlineTimePro.getProperty("appGayAfter"));
							}
						}

					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("glowTips"));
				}
				try {
					sbtotal.append(properties.getProperty("tiantianquanTips"));
					// 甜甜圈App查询
					if (StringUtils
							.isNotEmpty(productOnlineTimePro.getProperty("tiantianquan" + operateSys + "Time"))) {

						map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tiantianquanUrl"),

								properties.getProperty("tiantianquanParam") + phone
										+ properties.getProperty("tiantianquanOtherParam"),

								queryPhoneSetAttr, properties.getProperty("tiantianquanAttr"));

						if (JSONObject.fromObject(map.get("content")).get("auth").toString()
								.equals(properties.getProperty("tiantianquanRegMsg"))) {
							sb.append(properties.getProperty("tiantianquanTips"));

							regCount++;
							flag = true;
							if (partTime.before(sFormat
									.parse(productOnlineTimePro.getProperty("tiantianquan" + operateSys + "Time")))) {
								regScore += (1 / Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
										* Double.parseDouble(productOnlineTimePro.getProperty("tiantianquanScore"))
										+ Double.parseDouble(productOnlineTimePro.getProperty("appGayBefore"));
							} else {
								regScore += (1 / Double.parseDouble(productOnlineTimePro.getProperty("appTotal")))
										* Double.parseDouble(productOnlineTimePro.getProperty("tiantianquanScore"))
										+ Double.parseDouble(productOnlineTimePro.getProperty("appGayAfter"));
							}
						}

					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					stringBuilder.append(properties.getProperty("tiantianquanTips"));
				}

				// ----gay----------------------------------
				// 给定存取结果
				list.add(regCount);

			}

			// 输入的手机号查询结束进行计算

			if (list.size() == 0) {
				// 查无结果
			}
			Integer regTotal = 0;
			for (Integer integer : list) {
				regTotal += integer;
			}

			// 计算
			// Integer total =
			// Integer.parseInt(productOnlineTimePro.getProperty("appTotal")) *
			// list.size();
			// double ratio = (double) regTotal / total;

			// 返回给前台

			String result = productOnlineTimePro.getProperty("appTips")
					+ new DecimalFormat("#0.00").format(regScore * 10);
			if (flag) {
				json.put("datagay", productOnlineTimePro.getProperty("appTipsAppend"));
				flag = false;
			}

			json.put("nomal", sb.toString());
			json.put("legal", stringBuilder.toString());
			json.put("total", sbtotal.toString());
			json.put("status", result);

			renderJson(json.toString());

			return;
			/*
			 * // 新增单线程测试 sb.append(properties.getProperty("RegEndTips")); //
			 * 设置到前台的查询App结果 setAttr("findResult", sb.toString());
			 * 
			 * jsonObject.put("check", "true"); jsonObject.put("result",
			 * sb.toString());
			 * 
			 * // 返回到前台 // 返回到查询界面 renderJson(jsonObject.toString());
			 */
		} catch (

		Exception e)

		{
			logger.warn("寻找手机加载配置出错:" + e.getMessage());
		}

	}

	public void outsideResult() {
		String result = getPara("result", "");
		String datagay = getPara("datagay", "");

		// 测试---
		setAttr("nomal", getPara("nomal"));
		setAttr("legal", getPara("legal"));
		setAttr("total", getPara("total"));
		// --------
		setAttr("result", result);
		setAttr("datagay", datagay);
		renderFreeMarker("outsideResult.html");

	}

	public void findPhonetest() {

		final String phone = getPara("findPhone", "");
		try {
			// // 限制查询一次
			// String loginAttr = getPara("loginKey");
			//
			// if (loginAttr == null) {
			// // 错误处理--非法进入
			// setAttr("loginnameMsg", "只能查询一次!!");
			// forwardAction("/init");
			// return;
			// }
			//
			// // 记录查询剩余的次数
			// int spareCount = 1;
			//
			// // 划分前台穿过来的值
			// String loginName = DesUtil.decrypt(
			// loginAttr.substring(loginAttr.lastIndexOf(", loginName=") + 12,
			// loginAttr.lastIndexOf("}")),
			// "password");
			// String password = DesUtil.decrypt(loginAttr.substring(10,
			// loginAttr.lastIndexOf(", loginName=")), "loginName");
			//
			// List<Record> list = null;
			// if
			// (loginName.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$"))
			// {
			// list = Db.find("select * from queryPhone where userPhone=? ",
			// Long.valueOf(loginName));
			// } else {
			// list = Db.find("select * from queryPhone where userName=? ",
			// loginName);
			// }
			//
			// if (list != null) {
			//
			// String userPassword = list.get(0).getStr("userPassword");
			//
			// // 获得查询还剩余的次数
			// spareCount = Integer.parseInt(list.get(0).getStr("queryCount"));
			// if (userPassword.equals(password)) {
			// // 限制查询次数一次
			// if (spareCount < 1) {
			// // 错误处理--非法进入
			// setAttr("loginnameMsg", "只能查询一次!!");
			// forwardAction("/init");
			// return;
			// }
			// }
			//
			// } else {
			//
			// setAttr("loginnameMsg", "该密码不正确!!");
			// forwardAction("/init");
			// return;
			// }
			//
			// try {
			// // 没有cookis下的用户查找手机功能
			// final Properties propertiesUser = new Properties();
			// final String defaultUserUrl = System.getProperty("user.dir")
			// + "\\WebRoot\\properties\\defaultUser\\defaultUser" +
			// getAttr("realIp") + ".properties";
			// // 判断该文件是否被删除
			// File file = new File(defaultUserUrl);
			// if (file.exists()) {
			// // 存在的时候加载文件
			// propertiesUser
			// .load(new BufferedReader(new InputStreamReader(new
			// FileInputStream(defaultUserUrl), "utf-8")));
			// }
			// if (propertiesUser.getProperty("deaultUserSession") == null) {
			// // 正常有cookie下的模式查询
			// // 获得判断标志
			// if (!(getPara("luo") == null ? "luo" : getPara("luo"))
			// .equals((getSessionAttr("xiaoluo") == null ? "xiaoluo" :
			// getSessionAttr("xiaoluo")))) {
			// // 错误处理--非法进入
			// setAttr("loginnameMsg", "请勿非法进入!!");
			// forwardAction("/init");
			// return;
			// }
			//
			// }
			//
			// // 获取前台输入的手机
			// final String phone = getPara("findPhone", "");
			//
			// if
			// (!phone.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$"))
			// {
			// removeSessionAttr("xiaoluo");
			// setAttr("xiaoluo", Key.init());
			// setSessionAttr("xiaoluo", getAttr("xiaoluo"));
			// // JSONObject jsonObject = new JSONObject();
			// // jsonObject.put("check", "false");
			// JSONObject jsonObject =
			// JSONObject.fromObject("{'check':'false'}");
			// renderJson(jsonObject.toString());
			//
			// }
			//
			// // 将当前用户的查询的次数数目减1--除非是充值之后才可以进入
			// if
			// (loginName.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$"))
			// {
			//
			// Db.update("update queryphone set queryCount=? where userPhone=?",
			// String.valueOf(--spareCount),
			// Long.valueOf(loginName));
			// } else {
			// Db.update("update queryphone set queryCount=? where userName=?",
			// String.valueOf(--spareCount),
			// loginName);
			// }
			// // 移除session
			// removeSessionAttr("xiaoluo");
			//
			// // 再次判定是否是有cookie
			// if (propertiesUser.getProperty("deaultUserSession") != null) {
			// // 没有cookie,删除文件
			// System.gc();
			// file.delete();
			// }

			// 加载配置文件
			final Properties properties = new Properties();
			String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\queryphoneController.properties";
			properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));
			// 用于前台展示注册的手机数目
			final StringBuilder sb = new StringBuilder();
			// 开始注册信息
			sb.append(properties.getProperty("RegStartTips") + phone + RegitEnum.getRegMsgEnumCovert("RegTips"));
			// App查询程序-------------------------------start----------------------------------------

			// // 读多个程序的配置
			// Enumeration<?> enumeration = properties.propertyNames();
			//
			// // 用于App配置文件的计数的存取
			// int wroteCount = 0;
			// // 用于存取读取的配置文件
			// final List<String> appList = new ArrayList<String>();
			// // 用于读取多少个配置文件的技术
			// while (enumeration.hasMoreElements()) {
			// Object object = enumeration.nextElement();
			// String propetery = (String) object;
			// appList.add(wroteCount++, propetery);
			//
			// }
			//
			// for (int i = 0; i < Integer.valueOf(properties
			// .getProperty("RegCount")); i++) {
			// // 用于配置每个App查询的开始
			// final int appStarCount = (i - 0) * 6 + 3;
			// // 进入设定App查询
			// Thread threadAppQuery = new Thread() {
			//
			// public void run() {
			// // 用于App配置文件的读取
			// int readCount = appStarCount;
			// QueryPhoneSetAttr queryPhoneSetAttr = new
			// QueryPhoneSetAttrImpl();// 配置属性
			//
			// Map<String, String> map = QyeryPhoneByProxyIp
			// .httpURLConnectionPOST(
			// appList.get(readCount++),
			// appList.get(readCount++) + phone
			// + appList.get(readCount++),
			// queryPhoneSetAttr,
			// appList.get(readCount++));
			// JSONObject jsonObject = JSONObject.fromObject(map
			// .get("content"));
			// if (jsonObject.get("message")
			// .equals(properties.getProperty(appList
			// .get(readCount++)))) {
			// sb.append(appList.get(readCount++));
			// }
			// }
			//
			// };
			//
			// }

			// 进入探探App查询
			final Thread threadTantan = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = QyeryPhoneByProxyIp
							.httpURLConnectionPOST(properties.getProperty("tantanUrl"),
									properties.getProperty("tantanParam") + phone
											+ properties.getProperty("tantanOtherParam"),
									queryPhoneSetAttr, properties.getProperty("tantanAttr"));
					JSONObject jsonObject = JSONObject.fromObject(map.get("content"));
					if (jsonObject.get("message").equals(properties.getProperty("tantanRegMsg"))) {
						sb.append(properties.getProperty("tantanTips"));
					}
				}

			};
			// 连接超时
			// 约单App查询
			final Thread threadYuedan = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = QyeryPhoneByProxyIp
							.httpURLConnectionPOST(properties.getProperty("yuedanUrl"),
									properties.getProperty("yuedanParam") + phone
											+ properties.getProperty("yuedanOtherParam"),
									queryPhoneSetAttr, properties.getProperty("yuedanAttr"));
					// String yueDanMsg = map.get("content").split("==")[1];
					// if
					// (!yueDanMsg.equals(properties.getProperty("yuedanRegMsg")))
					// {
					// sb.append(properties.getProperty("yuedanTips"));
					// }
				}

			};
			// 友约App查询
			// final Thread threadYouyue = new Thread() {
			//
			// public void run() {
			// QueryPhoneSetAttr queryPhoneSetAttr = new
			// QueryPhoneSetAttrImpl();// 配置属性
			// Map<String, String> map = QyeryPhoneByProxyIp
			// .httpURLConnectionPOST(properties.getProperty("youyueUrl"),
			// properties.getProperty("youyueParam") + phone
			// + properties.getProperty("youyueOtherParam"),
			// queryPhoneSetAttr, properties.getProperty("youyueAttr"));
			// JSONObject jsonObject =
			// JSONObject.fromObject(map.get("content"));
			// if
			// (!(jsonObject.get("error_info").equals(properties.getProperty("youyueRegMsg"))
			// ||
			// (jsonObject.get("error_info").equals(properties.getProperty("youyueRegMsgs")))))
			// {
			// sb.append(properties.getProperty("youyueTips"));
			// }
			// }
			//
			// };
			// 激情约会App查询--有缘网
			final Thread threadJiqingyuehui = new Thread() {

				public void run() {
					try {
						// HttpClient模拟POST的方式登录
						// 目标地址
						HttpPost httpPost = new HttpPost(properties.getProperty("jiqingyuehuiUrl"));
						// 模拟客户写入参数
						List<NameValuePair> params = new ArrayList<NameValuePair>();
						params.add(new BasicNameValuePair(properties.getProperty("jiqingyuehuiParam"), phone));
						httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));
						// 使用DefaultHttpClient类的execute方法发送HTTP
						// POST请求，并返回HttpResponse对象。
						HttpResponse response = new DefaultHttpClient().execute(httpPost);
						if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
							String result = EntityUtils.toString(response.getEntity());
							if (result.equals(properties.getProperty("jiqingyuehuiRegMsg"))) {
								sb.append(properties.getProperty("jiqingyuehuiTips"));
							}
						}
					} catch (Exception e) {
						logger.warn("有缘网查询App失败:" + e.getMessage());
					}
				}

			};
			// 单身交友App查询
			final Thread threadDanshenjiaoyou = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("danshenjiaoyouUrl"),

							properties.getProperty("danshenjiaoyouParam") + phone
									+ properties.getProperty("danshenjiaoyouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("danshenjiaoyouAttr"));

					if (!map.get("content").equals("")) {
						sb.append(properties.getProperty("danshenjiaoyouTips"));
					}
				}

			};
			// 像像App查询
			final Thread threadXiangxiang = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xiangxiangUrl"),

							properties.getProperty("xiangxiangParam") + phone
									+ properties.getProperty("xiangxiangOtherParam"),

							queryPhoneSetAttr, properties.getProperty("xiangxiangAttr"));

					if (JSONObject.fromObject(map.get("content")).toString()
							.indexOf(properties.getProperty("xiangxiangRegMsg")) > 0) {
						sb.append(properties.getProperty("xiangxiangTips"));
					}
				}

			};

			// 连接超时
			// 柏拉图App查询
			final Thread threadBolatu = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("bolatuUrl"),

							properties.getProperty("bolatuParam") + phone + properties.getProperty("bolatuOtherParam"),

							queryPhoneSetAttr, properties.getProperty("bolatuAttr"));

					// if (!JSONObject.fromObject(map.get("content")).get("msg")
					// .equals(properties.getProperty("bolatuRegMsg"))) {
					// sb.append(properties.getProperty("bolatuTips"));
					// }
				}

			};

			// 租我App查询
			final Thread threadZuwo = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zuwoUrl"),

							properties.getProperty("zuwoParam") + phone + properties.getProperty("zuwoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("zuwoAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("zuwoRegMsg"))) {
						sb.append(properties.getProperty("zuwoTips"));
					}
				}

			};

			// 美丽约App查询
			final Thread threadMeiliyue = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("meiliyueUrl"),

							properties.getProperty("meiliyueParam") + phone
									+ properties.getProperty("meiliyueOtherParam"),

							queryPhoneSetAttr, properties.getProperty("meiliyueAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("meiliyueRegMsg"))) {
						sb.append(properties.getProperty("meiliyueTips"));
					}
				}

			};
			// 蜜约App查询
			final Thread threadMiyue = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("miyueUrl"),

							properties.getProperty("miyueParam") + phone + properties.getProperty("miyueOtherParam"),

							queryPhoneSetAttr, properties.getProperty("miyueAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("message")
							.equals(properties.getProperty("miyueRegMsg"))) {
						sb.append(properties.getProperty("miyueTips"));
					}
				}

			};
			// 勿忘我App查询
			final Thread threadWuwangwo = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("wuwangwoUrl"),

							properties.getProperty("wuwangwoParam") + phone
									+ properties.getProperty("wuwangwoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("wuwangwoAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("message")
							.equals(properties.getProperty("wuwangwoRegMsg"))) {
						sb.append(properties.getProperty("wuwangwoTips"));
					}
				}

			};
			// metooApp查询
			final Thread threadMetoo = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("metooUrl"),

							properties.getProperty("metooParam") + phone + properties.getProperty("metooOtherParam"),

							queryPhoneSetAttr, properties.getProperty("metooAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("error")
							.equals(properties.getProperty("metooRegMsg"))) {
						sb.append(properties.getProperty("metooTips"));
					}
				}

			};
			// 有短信通知换
			// 世纪佳缘App查询
			final Thread threadShijijiayuan = new Thread() {

				public void run() {

					String string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("shijijiayuanUrl"),

							properties.getProperty("shijijiayuanParam") + phone
									+ properties.getProperty("shijijiayuanOtherParam"));

					if (!JSONObject.fromObject(string).get("msg")
							.equals(properties.getProperty("shijijiayuanRegMsg"))) {
						sb.append(properties.getProperty("shijijiayuanTips"));
					}

				}

				;
			};
			// PP语音App查询
			final Thread threadPpyuyin = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ppyuyinUrl"),

							properties.getProperty("ppyuyinParam") + phone
									+ properties.getProperty("ppyuyinOtherParam"),

							queryPhoneSetAttr, properties.getProperty("ppyuyinAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("ppyuyinRegMsg"))) {
						sb.append(properties.getProperty("ppyuyinTips"));
					}

				}

			};
			// 激情爱恋App查询
			final Thread threadJiqingailian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jiqingailianUrl"),

							properties.getProperty("jiqingailianParam") + phone
									+ properties.getProperty("jiqingailianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("jiqingailianAttr"));

					if (JSONObject.fromObject(map.get("content")).get("error").equals(0)) {
						sb.append(properties.getProperty("jiqingailianTips"));
					}

				}

			};
			// 九秀美女直播间App查询
			final Thread threadJiuxiumeinvzhibojian = new Thread() {

				public void run() {

					String msg = QyeryPhoneByProxyIp.httpURLConnectionGET(
							properties.getProperty("jiuxiumeinvzhibojianUrl"),

							properties.getProperty("jiuxiumeinvzhibojianParam") + phone
									+ properties.getProperty("jiuxiumeinvzhibojianOtherParam")

					);

					int code = Integer.parseInt(properties.getProperty("jiuxiumeinvzhibojianRegMsg"));
					if (!JSONObject.fromObject(msg).get("code").equals(code)) {

						sb.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
					}
				}

			};
			// 乐园交友App查询
			final Thread threadLeyuanjiaoyou = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("leyuanjiaoyouUrl"),

							properties.getProperty("leyuanjiaoyouParam") + phone
									+ properties.getProperty("leyuanjiaoyouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("leyuanjiaoyouAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("message")
							.equals(properties.getProperty("leyuanjiaoyouRegMsg"))) {
						sb.append(properties.getProperty("leyuanjiaoyouTips"));
					}

				}

			};
			// 么么哒App查询---被查询的会有短信通知
			final Thread threadMemeda = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("memedaUrl"),

							properties.getProperty("memedaParam") + phone + properties.getProperty("memedaOtherParam"),

							queryPhoneSetAttr, properties.getProperty("memedaAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("RC")
							.equals(properties.getProperty("memedaRegMsg"))) {
						// sb.append(properties.getProperty("memedaTips"));
					}

				}

			};

			// 随遇App查询
			final Thread threadSuiyu = new Thread() {

				public void run() {

					String string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("suiyuUrl"),

							properties.getProperty("suiyuParam") + phone + properties.getProperty("suiyuOtherParam"));

					if (JSONObject.fromObject(string).get("msg").equals(properties.getProperty("suiyuRegMsg"))) {
						sb.append(properties.getProperty("suiyuTips"));
					}

				}

			};
			// 影约App查询
			final Thread threadYingyue = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yingyueUrl"),

							properties.getProperty("yingyueParam") + phone
									+ properties.getProperty("yingyueOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yingyueAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("yingyueRegMsg"))) {
						sb.append(properties.getProperty("yingyueTips"));
					}

				}

			};
			// 百合婚恋App查询
			final Thread threadBaihehunlian = new Thread() {

				public void run() {

					// QueryPhoneSetAttr queryPhoneSetAttr = new
					// QueryPhoneSetAttrImpl();// 配置属性
					// Map<String, String> map = null;
					//
					// map =
					// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("baihehunlianUrl"),
					//
					// properties.getProperty("baihehunlianParam") + phone
					// + properties.getProperty("baihehunlianOtherParam"),
					//
					// queryPhoneSetAttr,
					// properties.getProperty("baihehunlianAttr"));
					//
					// if
					// (!JSONObject.fromObject(map.get("content")).get("message")
					// .equals(properties.getProperty("baihehunlianRegMsg"))) {
					// sb.append(properties.getProperty("baihehunlianTips"));
					// }

				}

			};
			// 今日有约App查询
			final Thread threadjinriyouyue = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jinriyouyueUrl"),

							properties.getProperty("jinriyouyueParam") + phone
									+ properties.getProperty("jinriyouyueOtherParam"),

							queryPhoneSetAttr, properties.getProperty("jinriyouyueAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("tips")
							.equals(properties.getProperty("jinriyouyueRegMsg"))) {
						sb.append(properties.getProperty("jinriyouyueTips"));
					}

				}

			};
			// 寂寞美女约会App查询--服务器貌似坏了
			final Thread threadJimomeinvyuehui = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jimomeinvyuehuiUrl"),

							properties.getProperty("jimomeinvyuehuiParam") + phone
									+ properties.getProperty("jimomeinvyuehuiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("jimomeinvyuehuiAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("event")
							.equals(properties.getProperty("jimomeinvyuehuiRegMsg"))) {
						sb.append(properties.getProperty("jimomeinvyuehuiTips"));
					}

				}

			};
			// 对面App查询
			final Thread threadDuimian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("duimianUrl"),

							properties.getProperty("duimianParam") + phone
									+ properties.getProperty("duimianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("duimianAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("duimianRegMsg"))) {
						// sb.append(properties.getProperty("duimianTips"));
					}

				}

			};
			// 花田App查询---网易账号可以登录
			final Thread threadHuatian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("huatianUrl"),

							properties.getProperty("huatianParam") + phone
									+ properties.getProperty("huatianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("huatianAttr"));

					if (JSONObject.fromObject(map.get("content")).get("status")
							.equals(properties.getProperty("huatianRegMsg"))) {
						sb.append(properties.getProperty("huatianTips"));
					}

				}

			};
			// 有我App查询
			final Thread threadYouwo = new Thread() {

				public void run() {

					HttpClient client = new HttpClient();
					HttpMethod method = new GetMethod(properties.getProperty("youwoUrl") + "?"
							+ properties.getProperty("youwoParam") + phone + properties.getProperty("youwoOtherParam"));
					try {
						OutputStream os = new FileOutputStream(
								new File(System.getProperty("user.dir") + "\\WebRoot\\properties\\appLoading",
										properties.getProperty("youwoAttr")));
						client.executeMethod(method);
						if (method.getStatusCode() == HttpStatus.SC_OK) {
							InputStream is = method.getResponseBodyAsStream();
							byte[] b = new byte[1024];
							int len = 0;
							while ((len = is.read(b)) != -1) {
								os.write(b, 0, len);

								if (len != Integer.parseInt((properties.getProperty("youwoRegMsg")))) {
									sb.append(properties.getProperty("youwoTips"));
								}
							}
						}
					} catch (Exception e) {
						logger.warn("有我App读取数据请求出错:" + e.getMessage());
					}
				}
			};
			// 遇见App查询--短信验证会有
			final Thread threadYujian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yujianUrl"),

							properties.getProperty("yujianParam") + phone + properties.getProperty("yujianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yujianAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("errordesc")
							.equals(properties.getProperty("yujianRegMsg"))) {
						sb.append(properties.getProperty("yujianTips"));
					}

				}

			};
			// 新浪微博App查询---派派
			final Thread threadXianlangweibo = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xianlangweiboUrl"),

							properties.getProperty("xianlangweiboParam") + phone
									+ properties.getProperty("xianlangweiboOtherParam"),

							queryPhoneSetAttr, properties.getProperty("xianlangweiboAttr"));

					if (!properties.getProperty("xianlangweiboRegMsg")
							.equals(JSONObject.fromObject(map.get("content")).get("errmsg"))) {
						sb.append(properties.getProperty("xianlangweiboTips"));
					}

				}

			};
			// 领爱App查询
			final Thread threadLingai = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lingaiUrl"),

							properties.getProperty("lingaiParam") + phone + properties.getProperty("lingaiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("lingaiAttr"));

					if (JSONObject.fromObject(map.get("content").replace("(", "").replace(")", "")).get("msg")
							.equals(properties.getProperty("lingaiRegMsg"))) {
						sb.append(properties.getProperty("lingaiTips"));
					}

				}

			};

			// 成人之美App查询
			final Thread threadChengrenzhimei = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chengrenzhimeiUrl"),

							properties.getProperty("chengrenzhimeiParam") + phone
									+ properties.getProperty("chengrenzhimeiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("chengrenzhimeiAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("errorInfo")
							.equals(properties.getProperty("chengrenzhimeiRegMsg"))) {
						sb.append(properties.getProperty("chengrenzhimeiTips"));
					}

				}

			};
			// 在线求爱App查询---数据加密
			final Thread threadZaixianqiuai = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zaixianqiuaiUrl"),

							properties.getProperty("zaixianqiuaiParam") + phone
									+ properties.getProperty("zaixianqiuaiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("zaixianqiuaiAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("error")
							.equals(Integer.parseInt(properties.getProperty("zaixianqiuaiRegMsg")))) {
						sb.append(properties.getProperty("zaixianqiuaiTips"));
					}

				}

			};
			// 爱吧App查询---签名错误
			final Thread threadAiba = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("aibaUrl"),

							properties.getProperty("aibaParam") + phone + properties.getProperty("aibaOtherParam"),

							queryPhoneSetAttr, properties.getProperty("aibaAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("return_msg")
							.equals(properties.getProperty("aibaRegMsg"))) {
						sb.append(properties.getProperty("aibaTips"));
					}

				}

			};
			// 抱抱App查询
			final Thread threadBaobao = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("baobaoUrl"),

							properties.getProperty("baobaoParam") + phone + properties.getProperty("baobaoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("baobaoAttr"));

					if (JSONObject.fromObject(map.get("content")).toString()

							.indexOf((properties.getProperty("baobaoRegMsg"))) > -1) {
						sb.append(properties.getProperty("baobaoTips"));
					}

				}

			};
			// 行者App查询
			final Thread threadXingzhe = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xingzheUrl"),

							properties.getProperty("xingzheParam") + phone
									+ properties.getProperty("xingzheOtherParam"),

							queryPhoneSetAttr, properties.getProperty("xingzheAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("errmsg")
							.equals(properties.getProperty("xingzheRegMsg"))) {
						sb.append(properties.getProperty("xingzheTips"));
					}

				}

			};
			// 敢聊App查询
			final Thread threadGanliao = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ganliaoUrl"),

							properties.getProperty("ganliaoParam") + phone
									+ properties.getProperty("ganliaoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("ganliaoAttr"));

					if (JSONObject.fromObject(map.get("content")).get("code")
							.equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[0]))
							|| JSONObject.fromObject(map.get("content")).get("code")
									.equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[1]))) {
						sb.append(properties.getProperty("ganliaoTips"));
					}

				}

			};

			// 真巧App查询
			final Thread threadZhenqiao = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhenqiaoUrl"),

							properties.getProperty("zhenqiaoParam") + phone
									+ properties.getProperty("zhenqiaoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("zhenqiaoAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("zhenqiaoRegMsg"))) {
						sb.append(properties.getProperty("zhenqiaoTips"));
					}

				}

			};

			// 豆瓣App查询
			final Thread threadDouban = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("doubanUrl"),

							properties.getProperty("doubanParam") + phone + properties.getProperty("doubanOtherParam"),

							queryPhoneSetAttr, properties.getProperty("doubanAttr"));

					if (map.get("content").indexOf(properties.getProperty("doubanRegMsg")) > -1) {
						sb.append(properties.getProperty("doubanTips"));
					}
				}

			};
			// 论酒App查询
			final Thread threadLunjiu = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lunjiuUrl"),

							properties.getProperty("lunjiuParam") + phone + properties.getProperty("lunjiuOtherParam"),

							queryPhoneSetAttr, properties.getProperty("lunjiuAttr"));

					if (!map.get("content").toString().equals(properties.getProperty("lunjiuRegMsg"))) {
						sb.append(properties.getProperty("lunjiuTips"));
					}

				}

			};

			// 知乎App查询------------------https协议待解决
			final Thread threadZhihu = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhihuUrl"),

							properties.getProperty("zhihuParam") + phone + properties.getProperty("zhihuOtherParam"),

							queryPhoneSetAttr, properties.getProperty("zhihuAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("message")
							.equals(properties.getProperty("zhihuRegMsg"))) {
						sb.append(properties.getProperty("zhihuTips"));
					}

				}

			};

			// 爱真心App查询
			final Thread threadAizhenxin = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("aizhenxinUrl"),

							properties.getProperty("aizhenxinParam") + phone
									+ properties.getProperty("aizhenxinOtherParam"),

							queryPhoneSetAttr, properties.getProperty("aizhenxinAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("retmean")
							.equals(properties.getProperty("aizhenxinRegMsg"))) {
						sb.append(properties.getProperty("aizhenxinTips"));
					}

				}

			};

			// 同城交友见见App查询
			final Thread threadTongchengjiaoyoujianjian = new Thread() {

				public void run() {

					String string = QyeryPhoneByProxyIp.httpURLConnectionGET(
							properties.getProperty("tongchengjiaoyoujianjianUrl"),

							properties.getProperty("tongchengjiaoyoujianjianParam") + phone
									+ properties.getProperty("tongchengjiaoyoujianjianOtherParam"));

					if ((!JSONObject.fromObject(string).get("message")
							.equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg"))
							&& !JSONObject.fromObject(string).get("message")
									.equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg1")))) {
						sb.append(properties.getProperty("tongchengjiaoyoujianjianTips"));
					}

				}
			};
			// ZANKApp查询
			final Thread threadZANK = new Thread() {

				public void run() {
					String string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("ZANKUrl"),

							properties.getProperty("ZANKParam") + phone + properties.getProperty("ZANKOtherParam"));

					if (!JSONObject.fromObject(string).get("error").equals(properties.getProperty("ZANKRegMsg"))) {
						sb.append(properties.getProperty("ZANKTips"));
					}
				}

			};

			// 六间房秀场App查询
			final Thread threadLiujianfangxiuchang = new Thread() {

				public void run() {
					String string = QyeryPhoneByProxyIp.httpURLConnectionGET(
							properties.getProperty("liujianfangxiuchangUrl"),

							properties.getProperty("liujianfangxiuchangParam") + phone
									+ properties.getProperty("liujianfangxiuchangOtherParam"));

					if (string.indexOf(properties.getProperty("liujianfangxiuchangRegMsg")) == -1) {
						sb.append(properties.getProperty("liujianfangxiuchangTips"));
					}

				}

			};
			// 除夜约App查询
			final Thread threadChuyeyue = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chuyeyueUrl"),

							properties.getProperty("chuyeyueParam") + phone
									+ properties.getProperty("chuyeyueOtherParam"),

							queryPhoneSetAttr, properties.getProperty("chuyeyueAttr"));

					if (JSONObject.fromObject(map.get("content")).get("error").toString()
							.indexOf(properties.getProperty("chuyeyueRegMsg")) == -1) {
						sb.append(properties.getProperty("chuyeyueTips"));
					}

				}

			};

			// 缘来婚恋App查询
			final Thread threadYuanlaihunlian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuanlaihunlianUrl"),

							properties.getProperty("yuanlaihunlianParam") + phone
									+ properties.getProperty("yuanlaihunlianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yuanlaihunlianAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("yuanlaihunlianRegMsg"))) {
						sb.append(properties.getProperty("yuanlaihunlianTips"));
					}

				}

			};
			// 百合婚恋App查询
			final Thread threadBaihe = new Thread() {

				public void run() {

					String str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("baiheUrl"),
							"jsonCallBack=jQuery18307090277567040175_1451103749446&l1451103760230&email=" + phone
									+ "&_=1451103760233");

					if (JSONObject.fromObject(str.substring(str.indexOf("{"), str.lastIndexOf(")"))).get("data")
							.equals(properties.getProperty("baiheRegMsg"))) {
						sb.append(properties.getProperty("baiheTips"));
					}

				}

			};

			// 58交友App查询
			final Thread thread58jiaoyou = new Thread() {

				public void run() {

					String str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("58jiaoyouUrl"),
							properties.getProperty("58jiaoyouParam") + phone);

					if (str.indexOf(properties.getProperty("58jiaoyouRegMsg")) == -1) {
						sb.append(properties.getProperty("58jiaoyouTips"));
					}

				}

			};

			// 红娘App查询
			final Thread threadHongniang = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("hongniangUrl"),

							properties.getProperty("hongniangParam") + phone
									+ properties.getProperty("hongniangOtherParam"),

							queryPhoneSetAttr, properties.getProperty("hongniangAttr"));

					if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("hongniangRegMsg"))) {
						sb.append(properties.getProperty("hongniangTips"));
					}

				}

			};

			// 赛客App查询
			final Thread threadShaige = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shaigeUrl"),

							properties.getProperty("shaigeParam") + phone + properties.getProperty("shaigeOtherParam"),

							queryPhoneSetAttr, properties.getProperty("shaigeAttr"));

					if (!JSONObject
							.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().indexOf("\"}") + 2))
							.get("desc").equals(properties.getProperty("shaigeRegMsg"))) {
						sb.append(properties.getProperty("shaigeTips"));
					}

				}

			};
			// 我在找你App查询
			final Thread threadWozaizhaoni = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("wozaizhaoniUrl"),

							properties.getProperty("wozaizhaoniParam") + phone
									+ properties.getProperty("wozaizhaoniOtherParam"),

							queryPhoneSetAttr, properties.getProperty("wozaizhaoniAttr"));

					if (!JSONObject.fromObject(map).get("content")
							.equals(properties.getProperty("wozaizhaoniRegMsg"))) {
						sb.append(properties.getProperty("wozaizhaoniTips"));
					}

				}

			};
			// 中国红娘网App查询
			final Thread threadZhongguohongniangwang = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhongguohongniangwangUrl"),

							properties.getProperty("zhongguohongniangwangParam") + phone
									+ properties.getProperty("zhongguohongniangwangOtherParam") + phone,

							queryPhoneSetAttr, properties.getProperty("zhongguohongniangwangAttr"));
					if (!JSONObject.fromObject(map).get("content")
							.equals(properties.getProperty("zhongguohongniangwangRegMsg"))) {
						sb.append(properties.getProperty("zhongguohongniangwangTips"));
					}

				}

			};

			// 若邻App查询
			final Thread threadRuoling = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ruolingUrl"),

							properties.getProperty("ruolingParam") + phone
									+ properties.getProperty("ruolingOtherParam"),

							queryPhoneSetAttr, properties.getProperty("ruolingAttr"));

					if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("ruolingRegMsg"))) {
						sb.append(properties.getProperty("ruolingTips"));
					}

				}

			};

			// 猜么App查询
			final Thread threadCaime = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("caimeUrl"),

							properties.getProperty("caimeParam") + phone + properties.getProperty("caimeOtherParam"),

							queryPhoneSetAttr, properties.getProperty("caimeAttr"));

					if (!JSONObject
							.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(",")))
							.get("msg").equals(properties.getProperty("caimeRegMsg"))) {
						sb.append(properties.getProperty("caimeTips"));
					}

				}

			};

			// 约会说App查询
			final Thread threadYuehuishuo = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuehuishuoUrl"),

							properties.getProperty("yuehuishuoParam") + phone
									+ properties.getProperty("yuehuishuoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yuehuishuoAttr"));
					String st = UnicodeConverChinese
							.decodeUnicode(map.get("content").substring(16, map.get("content").lastIndexOf("\"}")));
					if (!st.equals("用户名不存在！")) {
						sb.append(properties.getProperty("yuehuishuoTips"));
					}
				}

			};
			// 约会吧App查询
			final Thread threadYuihuiba = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuihuibaUrl"),

							properties.getProperty("yuihuibaParam") + phone
									+ properties.getProperty("yuihuibaOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yuihuibaAttr"));

					if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("yuihuibaRegMsg"))) {
						sb.append(properties.getProperty("yuihuibaTips"));
					}

				}

			};

			// 都秀嗨皮App查询
			final Thread threadDouxiuhaipi = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("douxiuhaipiUrl"),

							properties.getProperty("douxiuhaipiParam") + phone
									+ properties.getProperty("douxiuhaipiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("douxiuhaipiAttr"));

					if (!JSONObject.fromObject(map.get("content")).get("msg")
							.equals(properties.getProperty("douxiuhaipiRegMsg"))) {
						sb.append(properties.getProperty("douxiuhaipiTips"));
					}

				}

			};
			// 友寻交友App查询
			final Thread threadYouxunjiaoyou = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youxunjiaoyouUrl"),

							properties.getProperty("youxunjiaoyouParam") + phone
									+ properties.getProperty("youxunjiaoyouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("youxunjiaoyouAttr"));

					if ((Integer) JSONObject.fromObject(map.toString().substring(map.toString().indexOf(":{\"") + 1,
							map.toString().lastIndexOf(","))).get("status")

					!= Integer.parseInt(properties.getProperty("youxunjiaoyouRegMsg"))) {
						sb.append(properties.getProperty("youxunjiaoyouTips"));
					}

				}

			};

			// 人脉通App查询
			final Thread threadRenmaitong = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("renmaitongUrl"),

							properties.getProperty("renmaitongParam") + phone
									+ properties.getProperty("renmaitongOtherParam"),

							queryPhoneSetAttr, properties.getProperty("renmaitongAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf(":{\"") + 1,
							map.toString().lastIndexOf(","))).get("Tips")

							.equals(properties.getProperty("renmaitongRegMsg"))) {
						sb.append(properties.getProperty("renmaitongTips"));
					}

				}

			};
			// 约碰同城交友App查询
			final Thread threadYuepengtongchengjiaoyou = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
							properties.getProperty("yuepengtongchengjiaoyouUrl"),

							properties.getProperty("yuepengtongchengjiaoyouParam") + phone
									+ properties.getProperty("yuepengtongchengjiaoyouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yuepengtongchengjiaoyouAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("msg")

							.equals(properties.getProperty("yuepengtongchengjiaoyouRegMsg"))) {
						sb.append(properties.getProperty("yuepengtongchengjiaoyouTips"));
					}

				}

			};
			// 寂寞单身约会App查询
			final Thread threadJimodanshenyuehui = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jimodanshenyuehuiUrl"),

							properties.getProperty("jimodanshenyuehuiParam") + phone
									+ properties.getProperty("jimodanshenyuehuiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("jimodanshenyuehuiAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("event")

							.equals(properties.getProperty("jimodanshenyuehuiRegMsg"))) {
						sb.append(properties.getProperty("jimodanshenyuehuiTips"));
					}

				}

			};
			// 有约App查询
			final Thread threadYouyue = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youyueUrl"),

							properties.getProperty("youyueParam") + phone + properties.getProperty("youyueOtherParam"),

							queryPhoneSetAttr, properties.getProperty("youyueAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("error_info")

							.equals(properties.getProperty("youyueRegMsg"))) {
						sb.append(properties.getProperty("youyueTips"));
					}

				}

			};

			// 脸脸App查询
			final Thread threadLianlian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lianlianUrl"),

							properties.getProperty("lianlianParam") + phone
									+ properties.getProperty("lianlianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("lianlianAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("error")

							.equals(properties.getProperty("lianlianRegMsg"))) {
						sb.append(properties.getProperty("lianlianTips"));
					}

				}

			};
			// 两面App查询
			final Thread threadLiangmian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("liangmianUrl"),

							properties.getProperty("liangmianParam") + phone
									+ properties.getProperty("liangmianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("liangmianAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("code_msg")

							.equals(properties.getProperty("liangmianRegMsg"))) {
						sb.append(properties.getProperty("liangmianTips"));
					}

				}

			};

			// TutuApp查询
			final Thread threadTutu = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tutuUrl"),

							properties.getProperty("tutuParam") + phone + properties.getProperty("tutuOtherParam"),

							queryPhoneSetAttr, properties.getProperty("tutuAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("desc")

							.equals(properties.getProperty("tutuRegMsg"))) {
						sb.append(properties.getProperty("tutuTips"));
					}

				}

			};
			// 找到taApp查询
			final Thread threadZhaodaota = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhaodaotaUrl"),

							properties.getProperty("zhaodaotaParam") + phone
									+ properties.getProperty("zhaodaotaOtherParam"),

							queryPhoneSetAttr, properties.getProperty("zhaodaotaAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("msg")

							.equals(properties.getProperty("zhaodaotaRegMsg"))) {
						sb.append(properties.getProperty("zhaodaotaTips"));
					}

				}

			};
			// 见见App查询
			final Thread threadJianjian = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jianjianUrl"),

							properties.getProperty("jianjianParam") + phone
									+ properties.getProperty("jianjianOtherParam"),

							queryPhoneSetAttr, properties.getProperty("jianjianAttr"));

					if (JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("ret")

							.equals(properties.getProperty("jianjianRegMsg"))) {
						sb.append(properties.getProperty("jianjianTips"));
					}
				}

			};

			// 亲亲App查询
			final Thread threadQinqin = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("qinqinUrl"),

							properties.getProperty("qinqinParam") + phone + properties.getProperty("qinqinOtherParam"),

							queryPhoneSetAttr, properties.getProperty("qinqinAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("errorMsg")

							.equals(properties.getProperty("qinqinRegMsg"))) {
						sb.append(properties.getProperty("qinqinTips"));
					}

				}

			};
			// 陌游App查询
			final Thread threadMoyou = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moyouUrl"),

							properties.getProperty("moyouParam") + phone + properties.getProperty("moyouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("moyouAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("entity")

							.equals(properties.getProperty("moyouRegMsg"))) {
						sb.append(properties.getProperty("moyouTips"));
					}

				}

			};

			// 轻众筹App查询
			final Thread threadQingzhongchou = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("qingzhongchouUrl"),

							properties.getProperty("qingzhongchouParam") + phone
									+ properties.getProperty("qingzhongchouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("qingzhongchouAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("errorMsg")

							.equals(properties.getProperty("qingzhongchouRegMsg"))) {
						sb.append(properties.getProperty("qingzhongchouTips"));
					}

				}

			};
			// HighingApp查询
			final Thread threadHighing = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("HighingUrl"),

							properties.getProperty("HighingParam") + phone
									+ properties.getProperty("HighingOtherParam"),

							queryPhoneSetAttr, properties.getProperty("HighingAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("state")

							.equals(Integer.parseInt(properties.getProperty("HighingRegMsg")))) {
						sb.append(properties.getProperty("HighingTips"));
					}

				}

			};
			// 陌邻App查询
			final Thread threadMouling = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moulingUrl"),

							properties.getProperty("moulingParam") + phone
									+ properties.getProperty("moulingOtherParam"),

							queryPhoneSetAttr, properties.getProperty("moulingAttr"));

					if (!JSONObject
							.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(",")))
							.get("message").equals(properties.getProperty("moulingRegMsg"))) {
						sb.append(properties.getProperty("moulingTips"));
					}

				}

			};
			// 一说App查询
			final Thread threadYishuo = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yishuoUrl"),

							properties.getProperty("yishuoParam") + phone,

							queryPhoneSetAttr, properties.getProperty("yishuoAttr"));

					if (!JSONObject
							.fromObject(map.toString().substring(map.toString().indexOf("{\""),
									map.toString().lastIndexOf(",")))
							.get("msg").equals(properties.getProperty("yishuoRegMsg"))) {
						sb.append(properties.getProperty("yishuoTips"));
					}

				}

			};

			// 微微App查询
			final Thread threadWeiwei = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("weiweiUrl"),

							properties.getProperty("weiweiParam") + phone + properties.getProperty("weiweiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("weiweiAttr"));

					if (!map.toString()
							.substring(map.toString().lastIndexOf("<error>") + 7,
									map.toString().lastIndexOf("</error>"))
							.equals(properties.getProperty("weiweiRegMsg"))) {
						sb.append(properties.getProperty("weiweiTips"));
					}

				}

			};
			// 美缘网App查询
			final Thread threadMeiyuanwang = new Thread() {

				public void run() {

					String str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("meiyuanwangUrl"),

							"username=" + phone + "&password=879227577&fromsys=7");
					if (!JSONObject.fromObject(str).get("return_content")
							.equals(properties.getProperty("meiyuanwangRegMsg"))) {
						sb.append(properties.getProperty("meiyuanwangTips"));
					}

				}

			};

			// 到喜啦App查询
			final Thread threadDaoxila = new Thread() {

				public void run() {
					String map1 = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("daoxilaUrl"),

							properties.getProperty("daoxilaParam") + phone
									+ properties.getProperty("daoxilaOtherParam"));
					if (!JSONObject.fromObject(
							map1.toString().substring(map1.toString().indexOf("{\""), map1.toString().lastIndexOf(")")))
							.get("msg")

							.equals(properties.getProperty("daoxilaRegMsg"))) {
						sb.append(properties.getProperty("daoxilaTips"));
					}

				}

			};
			// 朋友印象App查询
			final Thread threadPengyouyingxiang = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("pengyouyingxiangUrl"),

							properties.getProperty("pengyouyingxiangParam") + phone
									+ properties.getProperty("pengyouyingxiangOtherParam"),

							queryPhoneSetAttr, properties.getProperty("pengyouyingxiangAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("message")

							.equals(properties.getProperty("pengyouyingxiangRegMsg"))) {
						sb.append(properties.getProperty("pengyouyingxiangTips"));
					}

				}

			};
			// 实名相亲App查询
			final Thread threadShimingxiangqin = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shimingxiangqinUrl"),

							properties.getProperty("shimingxiangqinParam") + phone
									+ properties.getProperty("shimingxiangqinOtherParam"),

							queryPhoneSetAttr, properties.getProperty("shimingxiangqinAttr"));

					if (map.toString().indexOf(properties.getProperty("shimingxiangqinRegMsg")) == -1)

					{
						sb.append(properties.getProperty("shimingxiangqinTips"));
					}

				}

			};
			// 黑白校园App查询
			final Thread threadHeibaixiaoyuan = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("heibaixiaoyuanUrl"),

							properties.getProperty("heibaixiaoyuanParam") + phone
									+ properties.getProperty("heibaixiaoyuanOtherParam"),

							queryPhoneSetAttr, properties.getProperty("heibaixiaoyuanAttr"));
					String string2 = (String) JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("msg");

					if (!string2.equals(properties.getProperty("heibaixiaoyuanRegMsg"))
							&& !string2.equals(properties.getProperty("heibaixiaoyuanRegMsg1"))) {
						sb.append(properties.getProperty("heibaixiaoyuanTips"));
					}

				}

			};
			// 推友App查询
			final Thread threadTuiyou = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tuiyouUrl"),

							properties.getProperty("tuiyouParam") + phone + properties.getProperty("tuiyouOtherParam"),

							queryPhoneSetAttr, properties.getProperty("tuiyouAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("msg")

							.equals(properties.getProperty("tuiyouRegMsg"))) {
						sb.append(properties.getProperty("tuiyouTips"));
					}

				}

			};
			// 啧啧App查询
			final Thread threadZeze = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zezeUrl"),

							properties.getProperty("zezeParam") + phone + properties.getProperty("zezeOtherParam"),

							queryPhoneSetAttr, properties.getProperty("zezeAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("code")

							.equals(Integer.parseInt(properties.getProperty("zezeRegMsg")))) {
						sb.append(properties.getProperty("zezeTips"));
					}

				}

			};

			// 美呼App查询
			final Thread threadMeihu = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("meihuUrl"),

							properties.getProperty("meihuParam") + phone + properties.getProperty("meihuOtherParam"),

							queryPhoneSetAttr, properties.getProperty("meihuAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("event")

							.equals(properties.getProperty("meihuRegMsg"))) {
						sb.append(properties.getProperty("meihuTips"));
					}

				}

			};

			// 压寨App查询
			final Thread threadYazhai = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yazhaiUrl"),

							properties.getProperty("yazhaiParam") + phone + properties.getProperty("yazhaiOtherParam"),

							queryPhoneSetAttr, properties.getProperty("yazhaiAttr"));

					if (!map.toString().substring(map.toString().indexOf("=") + 1, map.toString().lastIndexOf(","))
							.equals(properties.getProperty("yazhaiRegMsg"))) {
						sb.append(properties.getProperty("yazhaiTips"));
					}

				}

			};

			// 火聊pp查询
			final Thread threadHuoliao = new Thread() {

				public void run() {

					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("huoliaoUrl"),

							properties.getProperty("huoliaoParam") + phone
									+ properties.getProperty("huoliaoOtherParam"),

							queryPhoneSetAttr, properties.getProperty("huoliaoAttr"));

					if (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"") + 1,
							map.toString().lastIndexOf(","))).get("errorMsg")

							.equals(properties.getProperty("huoliaoRegMsg"))) {
						sb.append(properties.getProperty("huoliaoTips"));
					}

				}

			};

			// 嘤嘤App查询
			final Thread threadYingying = new Thread() {

				public void run() {

					String str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("yingyingUrl"),

							properties.getProperty("yingyingParam") + phone
									+ properties.getProperty("yingyingOtherParam"));

					if (!JSONObject.fromObject(str).get("code").equals(properties.getProperty("yingyingRegMsg"))) {
						sb.append(properties.getProperty("yingyingTips"));
					}

				}

			};
			// k歌房App查询
			final Thread threadKgefang = new Thread() {

				public void run() {
					QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
					Map<String, String> map = null;

					map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("kgefangUrl"),

							properties.getProperty("kgefangParam") + phone
									+ properties.getProperty("kgefangOtherParam"),

							queryPhoneSetAttr, properties.getProperty("kgefangAttr"));

					if (!JSONObject.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
							.get("msg")

							.equals(properties.getProperty("kgefangRegMsg"))) {
						sb.append(properties.getProperty("kgefangTips"));
					}

				}

			};
			// App查询程序-------------------------------end----------------------------------------
			// 判断标志
			boolean flag = true;
			// 前台展示的结果
			final JSONObject jsonObject = new JSONObject();

			// 主线程进行返回查询任务
			Thread thread = new Thread() {

				public void run() {
					try {
						// 等待所有分线程都结束任务才返回结构
						threadTantan.join();
						// threadYuedan.join();
						threadYouyue.join();
						threadJiqingyuehui.join();
						threadDanshenjiaoyou.join();
						threadXiangxiang.join();
						// threadBolatu.join();
						// threadZuwo.join();
						// threadMeiliyue.join();
						threadMiyue.join();
						// threadWuwangwo.join();
						threadMetoo.join();
						// threadShijijiayuan.join();
						// threadPpyuyin.join();
						// threadJiqingailian.join();
						threadJiuxiumeinvzhibojian.join();
						threadLeyuanjiaoyou.join();
						// threadMemeda.join();
						// threadSuiyu.join();
						threadYingyue.join();
						// threadBaihehunlian.join();
						threadjinriyouyue.join();
						threadJimomeinvyuehui.join();
						// threadDuimian.join();
						// threadHuatian.join();
						threadYouwo.join();
						// threadYujian.join();
						// threadXianlangweibo.join();
						// threadLingai.join();
						threadChengrenzhimei.join();
						// threadZaixianqiuai.join();
						// threadAiba.join();
						threadBaobao.join();
						threadXingzhe.join();
						threadGanliao.join();
						threadZhenqiao.join();
						threadDouban.join();
						// threadLunjiu.join();
						threadAizhenxin.join();
						threadTongchengjiaoyoujianjian.join();
						threadZANK.join();
						threadLiujianfangxiuchang.join();
						threadChuyeyue.join();
						threadYuanlaihunlian.join();
						threadBaihe.join();
						thread58jiaoyou.join();
						threadHongniang.join();
						threadShaige.join();
						threadWozaizhaoni.join();
						threadZhongguohongniangwang.join();
						threadRuoling.join();
						threadCaime.join();
						threadYuehuishuo.join();
						threadYuihuiba.join();
						threadDouxiuhaipi.join();
						threadYouxunjiaoyou.join();
						threadRenmaitong.join();
						threadYuepengtongchengjiaoyou.join();
						threadJimodanshenyuehui.join();
						threadLianlian.join();
						threadLiangmian.join();
						threadTutu.join();
						threadZhaodaota.join();
						threadJianjian.join();
						threadQinqin.join();
						threadMoyou.join();
						// threadQingzhongchou.join();
						threadMouling.join();
						threadYishuo.join();
						threadWeiwei.join();
						threadMeiyuanwang.join();
						threadDaoxila.join();
						threadPengyouyingxiang.join();
						threadHeibaixiaoyuan.join();
						threadTuiyou.join();
						threadZeze.join();
						threadMeihu.join();
						threadYazhai.join();
						threadHuoliao.join();
						threadYingying.join();
						threadHighing.join();
						threadShimingxiangqin.join();
						threadKgefang.join();
						sb.append(properties.getProperty("RegEndTips"));
						// 设置到前台的查询App结果
						setAttr("findResult", sb.toString());

						jsonObject.put("check", "true");
						jsonObject.put("result", sb.toString());

					} catch (Exception e) {
						logger.warn("多线程阻塞出错:" + e.getMessage());
					}
				}
			};

			// 启动程查询
			threadTantan.start();
			// threadYuedan.start();
			threadYouyue.start();
			threadJiqingyuehui.start();
			threadDanshenjiaoyou.start();
			threadXiangxiang.start();
			// threadBolatu.start();
			// threadZuwo.start();
			// threadMeiliyue.start();
			threadMiyue.start();
			// threadWuwangwo.start();
			threadMetoo.start();
			// threadShijijiayuan.start();
			// threadPpyuyin.start();
			// threadJiqingailian.start();
			threadJiuxiumeinvzhibojian.start();
			threadLeyuanjiaoyou.start();
			// threadMemeda.start();
			// threadSuiyu.start();
			threadYingyue.start();
			// threadBaihehunlian.start();
			threadjinriyouyue.start();
			threadJimomeinvyuehui.start();
			// threadDuimian.start();
			// threadHuatian.start();
			threadYouwo.start();
			// threadYujian.start();
			// threadXianlangweibo.start();
			// threadLingai.start();
			threadChengrenzhimei.start();
			// threadZaixianqiuai.start();
			// threadAiba.start();
			threadBaobao.start();
			threadXingzhe.start();
			threadGanliao.start();
			threadZhenqiao.start();
			threadDouban.start();
			// threadLunjiu.start();
			threadAizhenxin.start();
			threadTongchengjiaoyoujianjian.start();
			threadZANK.start();
			threadLiujianfangxiuchang.start();
			threadChuyeyue.start();
			threadYuanlaihunlian.start();
			threadBaihe.start();
			thread58jiaoyou.start();
			threadHongniang.start();
			threadShaige.start();
			threadWozaizhaoni.start();
			threadZhongguohongniangwang.start();
			threadRuoling.start();
			threadCaime.start();
			threadYuehuishuo.start();
			threadYuihuiba.start();
			threadDouxiuhaipi.start();
			threadYouxunjiaoyou.start();
			threadRenmaitong.start();
			threadYuepengtongchengjiaoyou.start();
			threadJimodanshenyuehui.start();
			threadLianlian.start();
			threadLiangmian.start();
			threadTutu.start();
			threadZhaodaota.start();
			threadJianjian.start();
			threadQinqin.start();
			threadMoyou.start();
			// threadQingzhongchou.start();
			threadMouling.start();
			threadYishuo.start();
			threadWeiwei.start();
			threadMeiyuanwang.start();
			threadDaoxila.start();
			threadPengyouyingxiang.start();
			threadHeibaixiaoyuan.start();
			threadTuiyou.start();
			threadZeze.start();
			threadMeihu.start();
			threadYazhai.start();
			threadHuoliao.start();
			threadYingying.start();
			threadHighing.start();
			threadShimingxiangqin.start();
			threadKgefang.start();
			// 主线程
			thread.start();

			// 循环判断程序，不让他走出去
			while (flag) {
				// 阻塞一会
				Thread.sleep(4000);
				if (!thread.isAlive()) {
					flag = false;
				}
			}

			// 新增单线程测试
			sb.append(properties.getProperty("RegEndTips"));
			// 设置到前台的查询App结果
			setAttr("findResult", sb.toString());

			jsonObject.put("check", "true");
			jsonObject.put("result", sb.toString());

			// 返回到前台
			// 返回到查询界面
			renderJson(jsonObject.toString());

			return;

		} catch (

		Exception e)

		{
			logger.warn("寻找手机加载配置出错:" + e.getMessage());
		}

	}

	/**
	 * 管理员界面
	 *
	 * @param
	 * @return
	 */
	public void admin() {

		// 省略直接访问对应页面
		// 建立上传cookies
		setCookie("success", Key.init(), 60 * 30);
	}

	/**
	 * 管理员登录成功
	 *
	 * @param
	 * @return
	 */

	public void adminLogin() {

		try {

			String adminName = getPara("adminName", "").trim();
			String adminPassword = getPara("adminPassword", "").trim();
			// 读取管理员上传的配置文件
			Properties properties = new Properties();
			String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\admin.properties";
			properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));
			// 读取密钥配件
			Properties propertiesKey = new Properties();
			String keyUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\defaultAdmin.properties";
			propertiesKey.load(new BufferedReader(new InputStreamReader(new FileInputStream(keyUrl), "utf-8")));
			String key = propertiesKey.getProperty("adminKey");
			if (properties.getProperty("adminName").trim().equals(DesUtil.encrypt(adminName, key))
					&& properties.getProperty("adminPassword").trim().equals(DesUtil.encrypt(adminPassword, key))) {
				// 设置密码正确的时候session
				// 判断是否用户是否禁止了Cookie
				if (getCookie("success") == null) {
					// 手动设置一个cookie模拟客户端有cookie的登录
					// HttpClient模拟Get的方式登录
					// // 目标地址
					// HttpGet httpget = new HttpGet(
					// propertiesKey.getProperty("defaultCookieLoginUrl"));
					// // 更新Key生成出不唯一的cookie
					// String cookie = Key.init();
					// httpget.setHeader("Cookie", "JSESSIONID=" + cookie
					// + "; defaultCookie=" + cookie + "");
					//
					//
					// // 并把钥匙设置到缺省配置文件中方便上传文件时候进行读取匹配
					// Properties propertiesCookie = new Properties();
					// OutputStream out = new FileOutputStream(
					// System.getProperty("user.dir")
					// + "\\WebRoot\\properties\\defaultCookie\\defaultCookie"
					// + getAttr("realIp") + ".properties");
					// propertiesCookie.setProperty("defaultCookie", cookie);
					// propertiesCookie.setProperty("defaultMillsecond",
					// propertiesKey.getProperty("defaultMillsecond"));
					// propertiesCookie.store(out, "author: xiaoluo");
					// out.close();
					// // 使用DefaultHttpClient类的execute方法发送HTTP
					// // GET请求，并返回HttpResponse对象。
					// HttpResponse response = new DefaultHttpClient()
					// .execute(httpget);// 其中HttpGet是HttpUriRequst的子类
					// // 返回状态是OK的话讲输入流输出

					// HttpClient模拟POST的方式登录
					// 目标地址
					HttpPost httpPost = new HttpPost(propertiesKey.getProperty("defaultCookieLoginUrl"));
					// 更新Key生成出不唯一的cookie
					String cookie = Key.init();
					httpPost.setHeader("Cookie", "JSESSIONID=" + cookie + "; defaultCookie=" + cookie + "");
					// 并把钥匙设置到缺省配置文件中方便上传文件时候进行读取匹配
					Properties propertiesCookie = new Properties();
					OutputStream out = new FileOutputStream(
							System.getProperty("user.dir") + "\\WebRoot\\properties\\defaultCookie\\defaultCookie"
									+ getAttr("realIp") + ".properties");
					propertiesCookie.setProperty("defaultCookie", cookie);
					propertiesCookie.setProperty("defaultMillsecond", propertiesKey.getProperty("defaultMillsecond"));
					propertiesCookie.store(out, "author: xiaoluo");
					out.close();
					// 模拟客户前把当前的Ip存入到输入流文件中，方便读取
					List<NameValuePair> params = new ArrayList<NameValuePair>();
					params.add(new BasicNameValuePair("realIp", (String) getAttr("realIp")));
					httpPost.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
					// 使用DefaultHttpClient类的execute方法发送HTTP
					// POST请求，并返回HttpResponse对象。
					HttpResponse response = new DefaultHttpClient().execute(httpPost);
					if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
						String result = EntityUtils.toString(response.getEntity());
						// 写入文件，让用户看到该文件
						BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(
								new FileOutputStream(System.getProperty("user.dir") + "\\WebRoot\\index\\"
										+ propertiesKey.getProperty("defaultCookieFile") + ""),
								"utf-8"));
						bufferedWriter.write(result);
						bufferedWriter.close();
						renderFreeMarker(propertiesKey.getProperty("defaultCookieFile"));
					} else {
						setAttr("adminErrorMsg", "网络连接失败!!");
						renderFreeMarker("admin.html");
					}

					return;

				}

				setSessionAttr("adminSuccess", getCookie("success", "success"));

				renderFreeMarker("uploadProterties.html");
			} else {
				setAttr("adminErrorMsg", "用户或密码不正确!!");
				renderFreeMarker("admin.html");
			}

		} catch (Exception e) {
			logger.warn("管理员登录失败:" + e.getMessage());
		}
	}

	/**
	 * 管理员上传配置文件
	 *
	 * @param
	 * @return
	 */
	@Clear(QueryPhoneGlobalInterceptor.class)
	// 清除全局拦截
	@Before(QueryPhoneValidator.class)
	public void uploadFile() {

		try {

			// 文件的移动和删除
			// 获得总配置文件目录
			String baseUrl = System.getProperty("user.dir") + "\\WebRoot\\";
			// 获得上传的配置文件
			File uploadFilePath = new File(baseUrl + "download\\");
			File[] uploadFiles = uploadFilePath.listFiles();
			// 获得本地的配置文件
			File localFilePath = new File(baseUrl + "properties\\");
			File[] localFiles = localFilePath.listFiles();

			for (File uploadFile : uploadFiles) {
				for (File localFile : localFiles) {
					// 对于存在的文件进行替换
					if (localFile.getName().equals(uploadFile.getName())) {

						// 创建输入流进行读取上传的文件
						BufferedReader bf = new BufferedReader(
								new InputStreamReader(new FileInputStream(uploadFile), "utf-8"));
						// 创建输出流对文件进行存储本地
						BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
								new FileOutputStream(
										new File(baseUrl + "properties" + File.separator + uploadFile.getName())),
								"utf-8"));
						// 创建字节进行读取
						String len = "";
						while ((len = bf.readLine()) != null) {
							bw.write(len);
							// 换行
							bw.write("\n");

						}
						bw.flush();
						bf.close();
						bw.close();
						break;
					}

				}
				// 删除上传的文件--包括其他文件
				uploadFile.delete();
			}
			// 上传成功调到上传页面
			setAttr("uploadMsg", "上传配置文件成功!!!");
			renderFreeMarker("uploadProterties.html");

			// 没有cookies情况下删除cookies文件
			if ("true".equals(getAttr("deleteCookie"))) {
				// 调用两个线程，一个关闭流减少客户等待删除文件指令(防止用户多次上传文件和黑客盗取频繁上传问题)
				// 线程1--关闭流
				Runnable runnable = new Runnable() {

					@Override
					public void run() {
						// 关闭流
						return;

					}
				};

				// 线程2--删除文件
				Thread threadDeleteCookie = new Thread() {
					public void run() {
						// 读取管理员登录成功存入文件的cookie密钥
						Properties propertiesCookie = new Properties();
						final String cookieUrl = System.getProperty("user.dir")
								+ "\\WebRoot\\properties\\defaultCookie\\defaultCookie" + getAttr("realIp")
								+ ".properties";

						try {
							// 装载配置文件
							propertiesCookie.load(
									new BufferedReader(new InputStreamReader(new FileInputStream(cookieUrl), "utf-8")));
							// 获得定时时间长
							String timeStr = propertiesCookie.getProperty("defaultMillsecond");
							Integer waitTime = Integer.parseInt(timeStr.matches("\\d+") ? timeStr : "6000");
							// 启动定时任务
							Thread.sleep(waitTime);
						} catch (Exception e) {
							logger.warn("defaultCookie文件删除失败：" + e.getMessage());
							return;
						}

						// 读取存取cookie的文件
						File file = new File(cookieUrl);
						if (file.exists()) {
							System.gc();
							// 删除存取cookie的文件
							file.delete();

						}

					}
				};
				// 关闭守护线程模式
				threadDeleteCookie.setDaemon(false);
				// 线程1加载和启动
				Thread threadClose = new Thread(runnable);
				threadClose.start();
				// 线程2启动
				threadDeleteCookie.start();
			}
		} catch (Exception e) {
			logger.warn("配置文件上传出错：" + e.getMessage());

		}

	}

	/**
	 * 在线加密
	 *
	 * @param
	 * @return
	 */
	@Before(QueryPhoneInterceptor.class)
	public void onlineEncyrt() {

		String encrypt = getPara("encrypt", "").trim();
		String decrypt = getPara("decrypt", "").trim();
		String submit = getPara("submit", "").trim();
		// 查询返回的信息
		String msg = "";
		// 查询密钥
		String key = "";

		if ("".equals(encrypt) && "".equals(decrypt)) {

		} else if ("".equals(encrypt)) {
			key = decrypt.indexOf(" ") == -1 ? "" : decrypt == "" ? "" : decrypt.split(" ")[1];
		} else if ("".equals(decrypt)) {
			key = encrypt.indexOf(" ") == -1 ? "" : encrypt == "" ? "" : encrypt.split(" ")[1];

		} else {
			// 其他捣乱情况

		}

		if (key == "" || key.length() < 8) {
			setAttr("keyMsg", "您输入的密钥长度太短了，请重新输入!!");
			renderFreeMarker("onlineEncrypt.html");
			return;
		}

		try {
			// 加密
			if ("encrypt".equals(DesEnum.getEnumValue(submit))) {
				msg = DesUtil.encrypt(encrypt.split(" ")[0], key);
				// 返回查询结果
				setAttr("encryptresult", msg);
			} else {
				msg = DesUtil.decrypt(decrypt.split(" ")[0], key);
				// 返回查询结果
				setAttr("decryptresult", msg);

			}
			// 判断查询是否失败
			if ("".equals(msg)) {

				setAttr("keyMsg", "查询结果失败，请核对密钥是否正确！");

			}
			renderFreeMarker("onlineEncrypt.html");

		} catch (Exception e) {

			logger.warn(DesEnum.getEnumValue(submit) + "出错：" + e.getMessage());

		}
	}

	/**
	 * 利用手机找回密码登录
	 *
	 * @param
	 * @return
	 */
	public void phoneReg() {
		String phone = getPara("phone", "").trim();
		// 保存上次提交的数据--登录所填的数
		setAttr("phone", phone);
	}

	/**
	 * 利用获取时间
	 *
	 * @param
	 * @return
	 */
	public void gainYear() {

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy");
		renderJson(simpleDateFormat.format(new Date()));

	}

	/**
	 * 利用手机找回密码验证码
	 *
	 * @param
	 * @return
	 */
	public void phoneCheck() {

		// 获得异步发送过来的手机参数
		try {
			String phone = getPara("phone", "").trim();
			// 发送Json
			JSONObject jsonObject = new JSONObject();
			// 验证手机是否是空
			if ("".equals(phone)) {
				// 手机号不能为空
				jsonObject.put("remark", "empty");
				renderJson(jsonObject.toString());
				return;
			}
			// 生产6位随机数
			String num = "";
			for (int i = 0; i < 6; i++) {
				num += String.valueOf(((int) (Math.random() * 10)));
			}
			// 发送邮箱验证
			String sendRemark = "";
			// 判断手机属于哪个公司
			if (phone.matches("1(3[4-9]|5[012789]|47|8[234789])\\d{8}")) {
				sendRemark = EmailSendUtil.send(num, num, phone + "@139.com", "author", null);
			} else if (phone.matches("1(3[0-2]|5[56]|8[56]|4[5]|7[6])\\d{8}")) {
				sendRemark = EmailSendUtil.send(num, num, phone + "@wo.cn", "author", null);
			} else if (phone.matches("^1(3[3]|8[019]|53)\\d{8}")) {
				sendRemark = EmailSendUtil.send(num, num, phone + "@189.cn", "author", null);
			} else {
				// 手机号填写错误
				jsonObject.put("remark", "error");
				renderJson(jsonObject.toString());
				return;

			}

			if (StringUtils.isNotEmpty(sendRemark)) {
				// 先查询是否存在该手机号
				List<Record> list = Db.find("select * from queryphone  where  userPhone= ?", phone);
				if (list != null && list.size() != 0) {
					// 存取验证码到原来的手机号
					Db.update("update  queryphone set regSign=? where userPhone=?", num, phone);
				} else {
					// 存取新的手机号
					Record record = new Record();
					record.set("userPhone", phone);
					record.set("regSign", num);
					Db.save("queryphone", record);
				}
				logger.debug(num);
				jsonObject.put("remark", "true");
				renderJson(jsonObject.toString());
			} else {

				jsonObject.put("remark", "false");
				renderJson(jsonObject.toString());
			}
		} catch (Exception e) {
			logger.warn("验证码使用失败:" + e.getMessage());
		}

	}

	/**
	 * 利用手机找回密码存储
	 *
	 * @param
	 * @return
	 */
	public void savePass() {
		// 获得手机号
		try {
			String phone = getPara("phone", "").trim();
			String pass = getPara("pass");
			// 验证手机是否是空
			if ("".equals(phone)) {
				// 手机号不能为空
				setAttr("errorReg", "手机号不能为空!");
				renderFreeMarker("phoneReg.html");
				return;

			}

			// 验证密码是否符合规范
			if (StringUtils.isEmpty(pass)) {
				setAttr("findphone", phone);
				setAttr("passwordMsg", "密码不能为空!");
				renderFreeMarker("resetPass.html");
				return;

			}
			// 验证密码大小长度是否符合规范
			if (4 > pass.length() || pass.length() > 10) {
				setAttr("findphone", phone);
				setAttr("passwordMsg", "密码长度不对!");
				renderFreeMarker("resetPass.html");
				return;

			}
			// 获取前台传过来的验证码
			String checkParam = getPara("numParam", "1").trim();
			// 查询该手机存取的验证码
			List<Record> list = Db.find("select regSign from queryphone  where  userPhone=?", phone);
			if (list != null) {
				// 获得数据库注册的验证码
				String regSign = list.get(0).getStr("regSign");
				// 保存上次提交的数据
				setAttr("findphone", phone);
				if (regSign.equals(checkParam)) {
					// 存储密码
					int infectNum = Db.update("update  queryphone set userPassword=? where userPhone=?", pass, phone);
					if (infectNum == 1) {
						// 返回到登陆页面携带的参数
						setAttr("loginName", phone);
						setAttr("loginPass", pass);

						setAttr("status", "1");
						renderFreeMarker("login.html");
						return;
					} else {
						setAttr("errorReg", "找回失败，请刷新重试!!");
						renderFreeMarker("phoneReg.html");
						return;
					}
				} else {

					setAttr("errorReg", "您输入的验证码错误!!");
					renderFreeMarker("phoneReg.html");
					return;
				}

			} else {
				setAttr("notExist", "您输入的" + phone + "不存在!");
				renderFreeMarker("phoneReg.html");
			}
		} catch (Exception e) {
			logger.warn("找回密码出错:" + e.getMessage());
		}

	}

	/**
	 * 比对手机验证码
	 *
	 * @param
	 * @return
	 */
	public void compCode() {
		// 获得手机号
		try {
			String phone = getPara("phone", "").trim();

			// 验证手机是否是空
			if ("".equals(phone)) {
				// 手机号不能为空
				setAttr("errorReg", "手机号不能为空!");
				renderFreeMarker("phoneReg.html");
				return;
			}
			// 获取前台传过来的验证码
			String checkParam = getPara("numParam", "").trim();
			// 查询该手机存取的验证码
			List<Record> list = Db.find("select regSign from queryphone  where  userPhone=?", phone);
			if (list != null) {
				// 获得数据库注册的验证码
				String regSign = list.get(0).getStr("regSign");
				// 保存上次提交的数据
				setAttr("findphone", phone);

				if (regSign.equals(checkParam)) {
					// 返回到输入新的密码界面
					setAttr("findnumparam", regSign);
					renderFreeMarker("resetPass.html");
				} else {

					setAttr("errorReg", "您输入的验证码错误!!");
					renderFreeMarker("phoneReg.html");
					return;
				}
			} else {
				setAttr("notExist", "您输入的" + phone + "不存在!");
				renderFreeMarker("phoneReg.html");
			}
		} catch (Exception e) {
			logger.warn("找回密码出错:" + e.getMessage());
		}
	}

	// 点赞支持可能的
	public void outsidesupport() {
		String loginName = getPara("support");

		if (loginName == null) {
			renderJson("false");
			return;
		}
		List<Record> list;
		// 查找是否存在该帐号,检验登录账号是否唯一
		if (loginName.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$")) {
			list = Db.find("select * from queryPhone where userPhone=? ", Long.valueOf(loginName));
		} else {
			list = Db.find("select * from queryPhone where userName=? ", loginName);
		}
		int update = 0;
		if (list != null && list.size() != 0) {
			if (loginName.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$")) {
				update = Db.update("update queryphone set isSupport='true' where userPhone=?", Long.valueOf(loginName));
			} else {
				update = Db.update("update queryphone set isSupport='true' where userName=?", loginName);

			}
		}

		if (update != 0) {
			renderJson("true");
		} else {
			renderJson("false");
		}

	}

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date parse = simpleDateFormat.parse("2005-05-10");
		Date parse2 = simpleDateFormat.parse("2014-07-10");
		System.out.println(parse.before(parse2));

		// // 获得异步发送过来的手机参数
		// String phone = "15924179757";
		// // 验证手机是否是空
		// if ("".equals(phone)) {
		// // 等待补充参数
		// return;
		// }
		// // 生产6位随机数
		// String num = "";
		// for (int i = 0; i < 7; i++) {
		// num += String.valueOf(((int) (Math.random() * 10)));
		// }
		//
		// // 发送邮箱验证
		// String sendRemark = EmailSendUtil.send(num, num,
		// "15924179757@139.com", "author", null);
		//
		// logger.debug(sendRemark);
		// 多线程处理问题
		/*
		 * boolean flag = true;
		 *
		 * Thread thread = new Thread() {
		 *
		 * public void run() { try {
		 *
		 * Thread.sleep(6000); System.out.println("中间");
		 *
		 * } catch (InterruptedException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } } }; thread.start();
		 *
		 * while (flag) { try { Thread.sleep(2000); } catch
		 * (InterruptedException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } System.err.println("开始"); if
		 * (!thread.isAlive()) { flag = false; } }
		 * System.out.println("-----------------结束-------------------------");
		 */
	}
}
