package com.xiaoluo.controller;

public class SSmTEst {
	// 填写从短信SDK应用后台注册得到的APPKEY
	private static String APPKEY = "5887b8134af8";// 463db7238681 27fe7909f8e8
	// 填写从短信SDK应用后台注册得到的APPSECRET
	private static String APPSECRET = "9cd46d6cf9908a297fbafeb75b7b19d3";

	public static void main(String[] args) {
		System.out.println("1");
	}
}
