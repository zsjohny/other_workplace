/**
 * 
 */
package com.xiaoluo.controller;

import java.text.DecimalFormat;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: Test.java, 2015年12月27日 下午11:41:57
 */

public class Test {

	public static void main(String[] args) {
		DecimalFormat decimalFormat = new DecimalFormat("0.00");
		System.out.println(decimalFormat.format(Math.random() * 100));
	}
}
