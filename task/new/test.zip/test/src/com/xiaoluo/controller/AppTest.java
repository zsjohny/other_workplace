/**
 * 
 */
package com.xiaoluo.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Properties;

import com.xiaoluo.util.QueryPhoneSetAttr;
import com.xiaoluo.util.QyeryPhoneByProxyIp;
import com.xiaoluo.util.impl.QueryPhoneSetAttrImpl;

import net.sf.json.JSONObject;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: AppTest.java, 2015年12月3日 上午12:03:31
 */

public class AppTest {
	public static void main(String[] args) throws Exception {
		final Properties properties = new Properties();
		String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\queryphoneController.properties";
		properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));

		String phone = "15924179752";

		// HttpClient httpClient = HttpClients.createDefault();
		// HttpPost httpPost = new
		// HttpPost(properties.getProperty("tiantianquanUrl"));
		// StringBody flag = new StringBody("1");
		// StringBody password = new StringBody("sssss");
		// StringBody username = new StringBody(phone);
		// HttpEntity httpEntity =
		// MultipartEntityBuilder.create().addPart("flag",
		// flag).addPart("password", password)
		// .addPart("username", username).build();
		// httpPost.setEntity(httpEntity);
		// HttpResponse response = httpClient.execute(httpPost);
		// httpEntity = response.getEntity();
		// System.out.println(EntityUtils.toString(httpEntity, "utf-8"));
		// JSONObject jso =
		// JSONObject.fromObject(EntityUtils.toString(httpEntity, "utf-8"));
		// System.out.println(jso.get("msg"));
		// if
		// (jso.get("msg").toString().equals(properties.getProperty("tiantianquanRegMsg")))
		// {
		// // System.out.println(jso.get("msg"));
		// }
		//
		// // String string =
		// //
		// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("memezhiboUrl"),
		// //
		// // properties.getProperty("memezhiboParam") + phone);
		// // System.out.println(
		// //
		// jso.fromObject(string).get("code").toString().equals(properties.getProperty("memezhiboRegMsg")));
		QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();//
		// // 配置属性
		Map<String, String> map = null;

		map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tiantianquanUrl"),

				properties.getProperty("tiantianquanParam") + phone + properties.getProperty("tiantianquanOtherParam"),

				queryPhoneSetAttr, properties.getProperty("tiantianquanAttr"));
		System.out.println(map.get("content"));
		if (JSONObject.fromObject(map.get("content")).get("auth").toString()
				.equals(properties.getProperty("tiantianquanRegMsg"))) {
			// sb.append(properties.getProperty("tiantianquanTips"));
			System.out.println(properties.getProperty("tiantianquanTips"));
		}

	}

}
