package com.xiaoluo.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.xiaoluo.util.QueryPhoneSetAttr;
import com.xiaoluo.util.QyeryPhoneByProxyIp;
import com.xiaoluo.util.RegitEnum;
import com.xiaoluo.util.UnicodeConverChinese;
import com.xiaoluo.util.impl.QueryPhoneSetAttrImpl;

import net.sf.json.JSONObject;

public class AppConfig {
	public static void main(String[] args) throws Exception {
		Properties properties = new Properties();
		String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\queryphoneController.properties";
		properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));

		final StringBuilder sb = new StringBuilder();
		String phone = "15990073236";

		sb.append(properties.getProperty("RegStartTips") + phone + RegitEnum.getRegMsgEnumCovert("RegTips"));
		QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();//
		Map<String, String> map = null;
		JSONObject jsonObject = null;
		String string = null;

		try {
			// 进入探探App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tantanUrl"),
					properties.getProperty("tantanParam") + phone + properties.getProperty("tantanOtherParam"),
					queryPhoneSetAttr, properties.getProperty("tantanAttr"));
			jsonObject = JSONObject.fromObject(map.get("content"));
			if (jsonObject.get("message").equals(properties.getProperty("tantanRegMsg"))) {
				sb.append(properties.getProperty("tantanTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		try {
			// 激情约会App查询--有缘网
			HttpPost httpPost = new HttpPost(properties.getProperty("jiqingyuehuiUrl"));

			List<NameValuePair> params = new ArrayList<NameValuePair>();
			params.add(new BasicNameValuePair(properties.getProperty("jiqingyuehuiParam"), phone));
			httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));

			HttpResponse response = new DefaultHttpClient().execute(httpPost);
			if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				String result = EntityUtils.toString(response.getEntity());
				if (result.equals(properties.getProperty("jiqingyuehuiRegMsg"))) {
					sb.append(properties.getProperty("jiqingyuehuiTips"));
				}
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 单身交友App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("danshenjiaoyouUrl"),

					properties.getProperty("danshenjiaoyouParam") + phone
							+ properties.getProperty("danshenjiaoyouOtherParam"),

					queryPhoneSetAttr, properties.getProperty("danshenjiaoyouAttr"));

			if (!map.get("content").equals("")) {
				sb.append(properties.getProperty("danshenjiaoyouTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 像像App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xiangxiangUrl"),

					properties.getProperty("xiangxiangParam") + phone + properties.getProperty("xiangxiangOtherParam"),

					queryPhoneSetAttr, properties.getProperty("xiangxiangAttr"));
			if (JSONObject.fromObject(map.get("content")).toString()
					.indexOf(properties.getProperty("xiangxiangRegMsg")) > 0) {
				sb.append(properties.getProperty("xiangxiangTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 蜜约App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("miyueUrl"),

					properties.getProperty("miyueParam") + phone + properties.getProperty("miyueOtherParam"),

					queryPhoneSetAttr, properties.getProperty("miyueAttr"));
			if (!JSONObject.fromObject(map.get("content")).get("message")
					.equals(properties.getProperty("miyueRegMsg"))) {
				sb.append(properties.getProperty("miyueTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// metooApp查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("metooUrl"),

					properties.getProperty("metooParam") + phone + properties.getProperty("metooOtherParam"),

					queryPhoneSetAttr, properties.getProperty("metooAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("error").equals(properties.getProperty("metooRegMsg"))) {
				sb.append(properties.getProperty("metooTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			// 九秀美女直播间App查询
			String msg = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("jiuxiumeinvzhibojianUrl"),

					properties.getProperty("jiuxiumeinvzhibojianParam") + phone
							+ properties.getProperty("jiuxiumeinvzhibojianOtherParam")

			);

			int code = Integer.parseInt(properties.getProperty("jiuxiumeinvzhibojianRegMsg"));
			if (!JSONObject.fromObject(msg).get("code").equals(code)) {

				sb.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 乐园交友App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("leyuanjiaoyouUrl"),

					properties.getProperty("leyuanjiaoyouParam") + phone
							+ properties.getProperty("leyuanjiaoyouOtherParam"),

					queryPhoneSetAttr, properties.getProperty("leyuanjiaoyouAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("message")
					.equals(properties.getProperty("leyuanjiaoyouRegMsg"))) {
				sb.append(properties.getProperty("leyuanjiaoyouTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 影约App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yingyueUrl"),

					properties.getProperty("yingyueParam") + phone + properties.getProperty("yingyueOtherParam"),

					queryPhoneSetAttr, properties.getProperty("yingyueAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("msg").equals(properties.getProperty("yingyueRegMsg"))) {
				sb.append(properties.getProperty("yingyueTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 今日有约App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jinriyouyueUrl"),

					properties.getProperty("jinriyouyueParam") + phone
							+ properties.getProperty("jinriyouyueOtherParam"),

					queryPhoneSetAttr, properties.getProperty("jinriyouyueAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("tips")
					.equals(properties.getProperty("jinriyouyueRegMsg"))) {
				sb.append(properties.getProperty("jinriyouyueTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			// 寂寞美女约会App查询--服务器貌似坏了
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jimomeinvyuehuiUrl"),

					properties.getProperty("jimomeinvyuehuiParam") + phone
							+ properties.getProperty("jimomeinvyuehuiOtherParam"),

					queryPhoneSetAttr, properties.getProperty("jimomeinvyuehuiAttr"));
			if (!JSONObject.fromObject(map.get("content")).get("event")
					.equals(properties.getProperty("jimomeinvyuehuiRegMsg"))) {
				sb.append(properties.getProperty("jimomeinvyuehuiTips"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// 有我App查询
		HttpClient client = new HttpClient();
		HttpMethod method = new GetMethod(properties.getProperty("youwoUrl") + "?"
				+ properties.getProperty("youwoParam") + phone + properties.getProperty("youwoOtherParam"));
		try {
			OutputStream os = new FileOutputStream(
					new File(System.getProperty("user.dir") + "\\WebRoot\\properties\\appLoading",
							properties.getProperty("youwoAttr")));
			client.executeMethod(method);
			if (method.getStatusCode() == HttpStatus.SC_OK) {
				InputStream is = method.getResponseBodyAsStream();
				byte[] b = new byte[1024];
				int len = 0;
				while ((len = is.read(b)) != -1) {
					os.write(b, 0, len);

					if (len != Integer.parseInt((properties.getProperty("youwoRegMsg")))) {
						sb.append(properties.getProperty("youwoTips"));
					}
				}
			}
		} catch (Exception e) {

		}
		try {
			// 成人之美App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chengrenzhimeiUrl"),

					properties.getProperty("chengrenzhimeiParam") + phone
							+ properties.getProperty("chengrenzhimeiOtherParam"),

					queryPhoneSetAttr, properties.getProperty("chengrenzhimeiAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("errorInfo")
					.equals(properties.getProperty("chengrenzhimeiRegMsg"))) {
				sb.append(properties.getProperty("chengrenzhimeiTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 抱抱App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("baobaoUrl"),

					properties.getProperty("baobaoParam") + phone + properties.getProperty("baobaoOtherParam"),

					queryPhoneSetAttr, properties.getProperty("baobaoAttr"));

			if (JSONObject.fromObject(map.get("content")).toString()

					.indexOf((properties.getProperty("baobaoRegMsg"))) > -1) {
				sb.append(properties.getProperty("baobaoTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 行者App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xingzheUrl"),

					properties.getProperty("xingzheParam") + phone + properties.getProperty("xingzheOtherParam"),

					queryPhoneSetAttr, properties.getProperty("xingzheAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("errmsg")
					.equals(properties.getProperty("xingzheRegMsg"))) {
				sb.append(properties.getProperty("xingzheTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 敢聊App查询
		map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ganliaoUrl"),

				properties.getProperty("ganliaoParam") + phone + properties.getProperty("ganliaoOtherParam"),

				queryPhoneSetAttr, properties.getProperty("ganliaoAttr"));

		if (JSONObject.fromObject(map.get("content")).get("code")
				.equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[0]))
				|| JSONObject.fromObject(map.get("content")).get("code")
						.equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[1]))) {
			sb.append(properties.getProperty("ganliaoTips"));
		}
		try {
			// 真巧App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhenqiaoUrl"),

					properties.getProperty("zhenqiaoParam") + phone + properties.getProperty("zhenqiaoOtherParam"),

					queryPhoneSetAttr, properties.getProperty("zhenqiaoAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("msg")
					.equals(properties.getProperty("zhenqiaoRegMsg"))) {
				sb.append(properties.getProperty("zhenqiaoTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// http://accounts.douban.com/login?uid=135307167&alias=15856316912&redir=https%3A%2F%2Fwww.douban.com%2F&source=index_nav&error=1013
		// Your browser should have redirected you to
		// http://accounts.douban.com/login?uid=&alias=15924179757&redir=https%3A%2F%2Fwww.douban.com%2F&source=index_nav&error=1012
		try {
			// 豆瓣App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("doubanUrl"),

					properties.getProperty("doubanParam") + phone + properties.getProperty("doubanOtherParam"),

					queryPhoneSetAttr, properties.getProperty("doubanAttr"));

			if (map.get("content").indexOf(properties.getProperty("doubanRegMsg")) > -1) {
				sb.append(properties.getProperty("doubanTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 爱真心App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("aizhenxinUrl"),

					properties.getProperty("aizhenxinParam") + phone + properties.getProperty("aizhenxinOtherParam"),

					queryPhoneSetAttr, properties.getProperty("aizhenxinAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("retmean")
					.equals(properties.getProperty("aizhenxinRegMsg"))) {
				sb.append(properties.getProperty("aizhenxinTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 同城交友见见App查询
			string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("tongchengjiaoyoujianjianUrl"),

					properties.getProperty("tongchengjiaoyoujianjianParam") + phone
							+ properties.getProperty("tongchengjiaoyoujianjianOtherParam"));

			if ((!JSONObject.fromObject(string).get("message")
					.equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg"))
					&& !JSONObject.fromObject(string).get("message")
							.equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg1")))) {
				sb.append(properties.getProperty("tongchengjiaoyoujianjianTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// ZANKApp查询
			string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("ZANKUrl"),

					properties.getProperty("ZANKParam") + phone + properties.getProperty("ZANKOtherParam"));

			if (!JSONObject.fromObject(string).get("error").equals(properties.getProperty("ZANKRegMsg"))) {
				sb.append(properties.getProperty("ZANKTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 六间房秀场App查询
			string = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("liujianfangxiuchangUrl"),

					properties.getProperty("liujianfangxiuchangParam") + phone
							+ properties.getProperty("liujianfangxiuchangOtherParam"));

			if (string.indexOf(properties.getProperty("liujianfangxiuchangRegMsg")) == -1) {
				sb.append(properties.getProperty("liujianfangxiuchangTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			// 除夜约App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chuyeyueUrl"),

					properties.getProperty("chuyeyueParam") + phone + properties.getProperty("chuyeyueOtherParam"),

					queryPhoneSetAttr, properties.getProperty("chuyeyueAttr"));

			if (JSONObject.fromObject(map.get("content")).get("error").toString()
					.indexOf(properties.getProperty("chuyeyueRegMsg")) == -1) {
				sb.append(properties.getProperty("chuyeyueTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 缘来婚恋App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuanlaihunlianUrl"),

					properties.getProperty("yuanlaihunlianParam") + phone
							+ properties.getProperty("yuanlaihunlianOtherParam"),

					queryPhoneSetAttr, properties.getProperty("yuanlaihunlianAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("msg")
					.equals(properties.getProperty("yuanlaihunlianRegMsg"))) {
				sb.append(properties.getProperty("yuanlaihunlianTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 百合婚恋App查询
		String str;
		try {
			str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("baiheUrl"),
					"jsonCallBack=jQuery18307090277567040175_1451103749446&l1451103760230&email=" + phone
							+ "&_=1451103760233");

			if (JSONObject.fromObject(str.substring(str.indexOf("{"), str.lastIndexOf(")"))).get("data")
					.equals(properties.getProperty("baiheRegMsg"))) {
				sb.append(properties.getProperty("baiheTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 58交友App查询
			str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("58jiaoyouUrl"),
					properties.getProperty("58jiaoyouParam") + phone);

			if (str.indexOf(properties.getProperty("58jiaoyouRegMsg")) == -1) {
				sb.append(properties.getProperty("58jiaoyouTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 红娘App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("hongniangUrl"),

					properties.getProperty("hongniangParam") + phone + properties.getProperty("hongniangOtherParam"),

					queryPhoneSetAttr, properties.getProperty("hongniangAttr"));

			if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("hongniangRegMsg"))) {
				sb.append(properties.getProperty("hongniangTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 赛客App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shaigeUrl"),

					properties.getProperty("shaigeParam") + phone + properties.getProperty("shaigeOtherParam"),

					queryPhoneSetAttr, properties.getProperty("shaigeAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().indexOf("\"}") + 2))
					.get("desc").equals(properties.getProperty("shaigeRegMsg"))) {
				sb.append(properties.getProperty("shaigeTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 我在找你App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("wozaizhaoniUrl"),

					properties.getProperty("wozaizhaoniParam") + phone
							+ properties.getProperty("wozaizhaoniOtherParam"),

					queryPhoneSetAttr, properties.getProperty("wozaizhaoniAttr"));

			if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("wozaizhaoniRegMsg"))) {
				sb.append(properties.getProperty("wozaizhaoniTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 中国红娘网App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhongguohongniangwangUrl"),

					properties.getProperty("zhongguohongniangwangParam") + phone
							+ properties.getProperty("zhongguohongniangwangOtherParam") + phone,

					queryPhoneSetAttr, properties.getProperty("zhongguohongniangwangAttr"));
			if (!JSONObject.fromObject(map).get("content")
					.equals(properties.getProperty("zhongguohongniangwangRegMsg"))) {
				sb.append(properties.getProperty("zhongguohongniangwangTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 若邻App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ruolingUrl"),

					properties.getProperty("ruolingParam") + phone + properties.getProperty("ruolingOtherParam"),

					queryPhoneSetAttr, properties.getProperty("ruolingAttr"));

			if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("ruolingRegMsg"))) {
				sb.append(properties.getProperty("ruolingTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 猜么App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("caimeUrl"),

					properties.getProperty("caimeParam") + phone + properties.getProperty("caimeOtherParam"),

					queryPhoneSetAttr, properties.getProperty("caimeAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("msg").equals(properties.getProperty("caimeRegMsg"))) {
				sb.append(properties.getProperty("caimeTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 约会说App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuehuishuoUrl"),

					properties.getProperty("yuehuishuoParam") + phone + properties.getProperty("yuehuishuoOtherParam"),

					queryPhoneSetAttr, properties.getProperty("yuehuishuoAttr"));
			String st = UnicodeConverChinese
					.decodeUnicode(map.get("content").substring(16, map.get("content").lastIndexOf("\"}")));
			if (!st.equals("用户名不存在！")) {
				sb.append(properties.getProperty("yuehuishuoTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			// 约会吧App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuihuibaUrl"),

					properties.getProperty("yuihuibaParam") + phone + properties.getProperty("yuihuibaOtherParam"),

					queryPhoneSetAttr, properties.getProperty("yuihuibaAttr"));

			if (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("yuihuibaRegMsg"))) {
				sb.append(properties.getProperty("yuihuibaTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 都秀嗨皮App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("douxiuhaipiUrl"),

					properties.getProperty("douxiuhaipiParam") + phone
							+ properties.getProperty("douxiuhaipiOtherParam"),

					queryPhoneSetAttr, properties.getProperty("douxiuhaipiAttr"));

			if (!JSONObject.fromObject(map.get("content")).get("msg")
					.equals(properties.getProperty("douxiuhaipiRegMsg"))) {
				sb.append(properties.getProperty("douxiuhaipiTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 友寻交友App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youxunjiaoyouUrl"),

					properties.getProperty("youxunjiaoyouParam") + phone
							+ properties.getProperty("youxunjiaoyouOtherParam"),

					queryPhoneSetAttr, properties.getProperty("youxunjiaoyouAttr"));

			if ((Integer) JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf(":{\"") + 1, map.toString().lastIndexOf(",")))
					.get("status") != Integer.parseInt(properties.getProperty("youxunjiaoyouRegMsg"))) {
				sb.append(properties.getProperty("youxunjiaoyouTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 人脉通App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("renmaitongUrl"),

					properties.getProperty("renmaitongParam") + phone + properties.getProperty("renmaitongOtherParam"),

					queryPhoneSetAttr, properties.getProperty("renmaitongAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf(":{\"") + 1, map.toString().lastIndexOf(",")))
					.get("Tips")

					.equals(properties.getProperty("renmaitongRegMsg"))) {
				sb.append(properties.getProperty("renmaitongTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 约碰同城交友App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuepengtongchengjiaoyouUrl"),

					properties.getProperty("yuepengtongchengjiaoyouParam") + phone
							+ properties.getProperty("yuepengtongchengjiaoyouOtherParam"),

					queryPhoneSetAttr, properties.getProperty("yuepengtongchengjiaoyouAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("msg")

					.equals(properties.getProperty("yuepengtongchengjiaoyouRegMsg")))

			{
				sb.append(properties.getProperty("yuepengtongchengjiaoyouTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 寂寞单身约会App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jimodanshenyuehuiUrl"),

					properties.getProperty("jimodanshenyuehuiParam") + phone
							+ properties.getProperty("jimodanshenyuehuiOtherParam"),

					queryPhoneSetAttr, properties.getProperty("jimodanshenyuehuiAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("event")

					.equals(properties.getProperty("jimodanshenyuehuiRegMsg")))

			{
				sb.append(properties.getProperty("jimodanshenyuehuiTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 有约App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youyueUrl"),

					properties.getProperty("youyueParam") + phone + properties.getProperty("youyueOtherParam"),

					queryPhoneSetAttr, properties.getProperty("youyueAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("error_info")

					.equals(properties.getProperty("youyueRegMsg")))

			{
				sb.append(properties.getProperty("youyueTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 脸脸App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lianlianUrl"),

					properties.getProperty("lianlianParam") + phone + properties.getProperty("lianlianOtherParam"),

					queryPhoneSetAttr, properties.getProperty("lianlianAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("error")

					.equals(properties.getProperty("lianlianRegMsg")))

			{
				sb.append(properties.getProperty("lianlianTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 两面App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("liangmianUrl"),

					properties.getProperty("liangmianParam") + phone + properties.getProperty("liangmianOtherParam"),

					queryPhoneSetAttr, properties.getProperty("liangmianAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("code_msg")

					.equals(properties.getProperty("liangmianRegMsg")))

			{
				sb.append(properties.getProperty("liangmianTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// TutuApp查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tutuUrl"),

					properties.getProperty("tutuParam") + phone + properties.getProperty("tutuOtherParam"),

					queryPhoneSetAttr, properties.getProperty("tutuAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("desc")

					.equals(properties.getProperty("tutuRegMsg")))

			{
				sb.append(properties.getProperty("tutuTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 找到taApp查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhaodaotaUrl"),

					properties.getProperty("zhaodaotaParam") + phone + properties.getProperty("zhaodaotaOtherParam"),

					queryPhoneSetAttr, properties.getProperty("zhaodaotaAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("msg")

					.equals(properties.getProperty("zhaodaotaRegMsg")))

			{
				sb.append(properties.getProperty("zhaodaotaTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 见见App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jianjianUrl"),

					properties.getProperty("jianjianParam") + phone + properties.getProperty("jianjianOtherParam"),

					queryPhoneSetAttr, properties.getProperty("jianjianAttr"));

			if (JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("ret")

					.equals(properties.getProperty("jianjianRegMsg"))) {
				sb.append(properties.getProperty("jianjianTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 亲亲App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("qinqinUrl"),

					properties.getProperty("qinqinParam") + phone + properties.getProperty("qinqinOtherParam"),

					queryPhoneSetAttr, properties.getProperty("qinqinAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("errorMsg")

					.equals(properties.getProperty("qinqinRegMsg")))

			{
				sb.append(properties.getProperty("qinqinTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 陌游App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moyouUrl"),

					properties.getProperty("moyouParam") + phone + properties.getProperty("moyouOtherParam"),

					queryPhoneSetAttr, properties.getProperty("moyouAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("entity")

					.equals(properties.getProperty("moyouRegMsg")))

			{
				sb.append(properties.getProperty("moyouTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// HighingApp查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("HighingUrl"),

					properties.getProperty("HighingParam") + phone + properties.getProperty("HighingOtherParam"),

					queryPhoneSetAttr, properties.getProperty("HighingAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("state")

					.equals(Integer.parseInt(properties.getProperty("HighingRegMsg"))))

			{
				sb.append(properties.getProperty("HighingTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 陌邻App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moulingUrl"),

					properties.getProperty("moulingParam") + phone + properties.getProperty("moulingOtherParam"),

					queryPhoneSetAttr, properties.getProperty("moulingAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("message").equals(properties.getProperty("moulingRegMsg")))

			{
				sb.append(properties.getProperty("moulingTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 一说App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yishuoUrl"),

					properties.getProperty("yishuoParam") + phone,

					queryPhoneSetAttr, properties.getProperty("yishuoAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("msg").equals(properties.getProperty("yishuoRegMsg")))

			{
				sb.append(properties.getProperty("yishuoTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 微微App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("weiweiUrl"),

					properties.getProperty("weiweiParam") + phone + properties.getProperty("weiweiOtherParam"),

					queryPhoneSetAttr, properties.getProperty("weiweiAttr"));

			if (!map.toString()
					.substring(map.toString().lastIndexOf("<error>") + 7, map.toString().lastIndexOf("</error>"))
					.equals(properties.getProperty("weiweiRegMsg")))

			{
				sb.append(properties.getProperty("weiweiTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 美缘网App查询
			str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("meiyuanwangUrl"),

					"username=" + phone + "&password=879227577&fromsys=7");
			if (!JSONObject.fromObject(str).get("return_content").equals(properties.getProperty("meiyuanwangRegMsg"))) {
				sb.append(properties.getProperty("meiyuanwangTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 到喜啦App查询
			String map1 = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("daoxilaUrl"),

					properties.getProperty("daoxilaParam") + phone + properties.getProperty("daoxilaOtherParam"));
			if (!JSONObject
					.fromObject(
							map1.toString().substring(map1.toString().indexOf("{\""), map1.toString().lastIndexOf(")")))
					.get("msg")

					.equals(properties.getProperty("daoxilaRegMsg")))

			{
				sb.append(properties.getProperty("daoxilaTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 朋友印象App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("pengyouyingxiangUrl"),

					properties.getProperty("pengyouyingxiangParam") + phone
							+ properties.getProperty("pengyouyingxiangOtherParam"),

					queryPhoneSetAttr, properties.getProperty("pengyouyingxiangAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("message")

					.equals(properties.getProperty("pengyouyingxiangRegMsg")))

			{
				sb.append(properties.getProperty("pengyouyingxiangTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 实名相亲App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shimingxiangqinUrl"),

					properties.getProperty("shimingxiangqinParam") + phone
							+ properties.getProperty("shimingxiangqinOtherParam"),

					queryPhoneSetAttr, properties.getProperty("shimingxiangqinAttr"));

			if (map.toString().indexOf(properties.getProperty("shimingxiangqinRegMsg")) == -1)

			{
				sb.append(properties.getProperty("shimingxiangqinTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// httpPost = new HttpPost("http://api.stuhui.com/club/login");
		// params = new ArrayList<NameValuePair>();
		// params.add(new BasicNameValuePair("act", "login_ajax"));
		// params.add(new BasicNameValuePair("mobile", phone));
		// params.add(new BasicNameValuePair("code", "879227577"));
		// httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));
		// response = new DefaultHttpClient().execute(httpPost);
		// if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		// String result = EntityUtils.toString(response.getEntity());
		// System.out.println(result);
		// }
		//
		// if (!JSONObject
		// .fromObject(map.toString().substring(map.toString().indexOf("{\""),
		// map.toString().lastIndexOf(",")))
		// .get("msg")
		//
		// .equals(properties.getProperty("heibaixiaoyuanRegMsg"))) {
		// sb.append(properties.getProperty("heibaixiaoyuanTips"));
		// }
		try {
			// 黑白校园App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("heibaixiaoyuanUrl"),

					properties.getProperty("heibaixiaoyuanParam") + phone
							+ properties.getProperty("heibaixiaoyuanOtherParam"),

					queryPhoneSetAttr, properties.getProperty("heibaixiaoyuanAttr"));

			String string2 = (String) JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("msg");

			if (!string2.equals(properties.getProperty("heibaixiaoyuanRegMsg"))
					&& !string2.equals(properties.getProperty("heibaixiaoyuanRegMsg1")))

			{
				sb.append(properties.getProperty("heibaixiaoyuanTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 推友App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tuiyouUrl"),

					properties.getProperty("tuiyouParam") + phone + properties.getProperty("tuiyouOtherParam"),

					queryPhoneSetAttr, properties.getProperty("tuiyouAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("msg")

					.equals(properties.getProperty("tuiyouRegMsg")))

			{
				sb.append(properties.getProperty("tuiyouTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 啧啧App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zezeUrl"),

					properties.getProperty("zezeParam") + phone + properties.getProperty("zezeOtherParam"),

					queryPhoneSetAttr, properties.getProperty("zezeAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("code")

					.equals(Integer.parseInt(properties.getProperty("zezeRegMsg"))))

			{
				sb.append(properties.getProperty("zezeTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 美呼App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("meihuUrl"),

					properties.getProperty("meihuParam") + phone + properties.getProperty("meihuOtherParam"),

					queryPhoneSetAttr, properties.getProperty("meihuAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("event")

					.equals(properties.getProperty("meihuRegMsg")))

			{
				sb.append(properties.getProperty("meihuTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 压寨App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yazhaiUrl"),

					properties.getProperty("yazhaiParam") + phone + properties.getProperty("yazhaiOtherParam"),

					queryPhoneSetAttr, properties.getProperty("yazhaiAttr"));

			if (!map.toString().substring(map.toString().indexOf("=") + 1, map.toString().lastIndexOf(","))
					.equals(properties.getProperty("yazhaiRegMsg")))

			{
				sb.append(properties.getProperty("yazhaiTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 火聊pp查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("huoliaoUrl"),

					properties.getProperty("huoliaoParam") + phone + properties.getProperty("huoliaoOtherParam"),

					queryPhoneSetAttr, properties.getProperty("huoliaoAttr"));

			if (!JSONObject.fromObject(
					map.toString().substring(map.toString().indexOf("={\"") + 1, map.toString().lastIndexOf(",")))
					.get("errorMsg")

					.equals(properties.getProperty("huoliaoRegMsg")))

			{
				sb.append(properties.getProperty("huoliaoTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// 嘤嘤App查询
			str = QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("yingyingUrl"),

					properties.getProperty("yingyingParam") + phone + properties.getProperty("yingyingOtherParam"));

			if (!JSONObject.fromObject(str).get("code").equals(properties.getProperty("yingyingRegMsg")))

			{
				sb.append(properties.getProperty("yingyingTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			// k歌房App查询
			map = QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("kgefangUrl"),

					properties.getProperty("kgefangParam") + phone + properties.getProperty("kgefangOtherParam"),

					queryPhoneSetAttr, properties.getProperty("kgefangAttr"));

			if (!JSONObject
					.fromObject(
							map.toString().substring(map.toString().indexOf("{\""), map.toString().lastIndexOf(",")))
					.get("msg")

					.equals(properties.getProperty("kgefangRegMsg")))

			{
				sb.append(properties.getProperty("kgefangTips"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(sb.toString());
	}

}
