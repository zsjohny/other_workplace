/**
 * 
 */
package com.xiaoluo.controller;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: SSlTest.java, 2015年12月6日 下午4:23:41
 */

public class SSlTest {
	/**
	 * 加载证书
	 */
	static {
		System.setProperty("javax.net.ssl.trustStore", "C:\\Users\\pj\\Desktop\\1\\svrkey");
		System.setProperty("javax.net.ssl.trustStorePassword", "985595");
	}

	public static void main(String[] args) throws IOException {
		// 创建URL对象
		URL myURL = new URL("https://www.baidu.com");

		// 创建HttpsURLConnection对象，并设置其SSLSocketFactory对象
		HttpsURLConnection httpsConn = (HttpsURLConnection) myURL.openConnection();

		// 添加头信息
		httpsConn.setRequestProperty("X-Bmob-Application-Id", "baidu.cer");
		httpsConn.setRequestProperty("X-Bmob-REST-API-Key", "985595");
		httpsConn.setRequestProperty("Content-Type", "application/json");

		// 取得该连接的输入流，以读取响应内容
		InputStreamReader insr = new InputStreamReader(httpsConn.getInputStream());

		// 读取服务器的响应内容并显示
		int respInt = insr.read();
		while (respInt != -1) {
			System.out.print((char) respInt);
			respInt = insr.read();
		}
	}
}
