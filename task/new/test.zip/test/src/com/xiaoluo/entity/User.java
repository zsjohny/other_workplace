/**
 * 
 */
package com.xiaoluo.entity;

import com.jfinal.plugin.activerecord.Model;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: User.java, 2015��10��18�� ����1:33:50
 */

public class User extends Model<User> {
	public static final User user = new User();
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
