/**
 * 
 */
package com.xiaoluo.entity;

import com.jfinal.plugin.activerecord.Model;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: QueryRecord.java, 2016年2月17日 下午11:49:21
 */

public class QueryRecord extends Model<QueryRecord> {
	public static final QueryRecord queryRecord = new QueryRecord();
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
