package com.xiaoluo.config;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class css {
	public static void main(String[] args) throws IOException {
		File file = new File("C:\\Users\\Administrator\\Desktop\\1.png");
		BufferedImage source = ImageIO.read(file);
		System.out.println(source.getWidth());
	}
}
