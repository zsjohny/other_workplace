/**
 * 
 */
package com.xiaoluo.config;

import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.core.JFinal;
import com.jfinal.ext.handler.ContextPathHandler;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.c3p0.C3p0Plugin;
import com.jfinal.render.ViewType;
import com.xiaoluo.controller.QueryPhoneController;
import com.xiaoluo.interceptor.QueryPhoneGlobalInterceptor;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: ApplyConfig.java, 2015锟斤拷10锟斤拷18锟斤拷 锟斤拷锟斤拷1:14:39
 */

public class ApplyConfig extends JFinalConfig {

	/**
	 * 锟斤拷锟矫筹拷锟斤拷
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void configConstant(Constants me) {
		PropKit.use("mysq_config.properties");// 锟斤拷锟斤拷mysql锟斤拷锟斤拷菘锟�
		me.setDevMode(false);// 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷模式
		me.setViewType(ViewType.FREE_MARKER);// 锟斤拷锟斤拷锟斤拷图
		me.setUploadedFileSaveDirectory("download/");// 锟斤拷锟斤拷锟侥硷拷锟较达拷锟斤拷路锟斤拷
	}

	/**
	 * 锟斤拷锟斤拷路锟斤拷
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void configRoute(Routes me) {
		me.add("/", QueryPhoneController.class, "/index");
	}

	/**
	 * 锟斤拷锟斤拷锟斤拷锟�
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void configPlugin(Plugins me) {
		// 锟斤拷锟斤拷C3p0锟斤拷菘锟斤拷锟斤拷映夭锟斤拷
		C3p0Plugin c3p0Plugin = new C3p0Plugin(PropKit.get("jdbcUrl"), PropKit.get("user"),
				PropKit.get("password").trim());
		me.add(c3p0Plugin);
		// 锟斤拷锟斤拷ActiveRecord锟斤拷锟�
		ActiveRecordPlugin arp = new ActiveRecordPlugin(c3p0Plugin);
		me.add(arp);// 锟斤拷锟紸ctiveRecord锟斤拷录
		// arp.addMapping("queryPhone", User.class);// 映锟斤拷queryPhone锟�User模锟斤拷

	}

	/**
	 * 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void configInterceptor(Interceptors me) {
		me.add(new QueryPhoneGlobalInterceptor());// 锟斤拷锟饺拷锟斤拷锟斤拷锟斤拷锟�
	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void configHandler(Handlers me) {
		me.add(new ContextPathHandler("contextPath"));// 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷路锟斤拷
	}

	public static void main(String[] args) {

		JFinal.start("WebRoot", 8048, "/query", 3);
	}

}
