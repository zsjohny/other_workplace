/**
 * 
 */
package com.xiaoluo.util;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: RegitEnum.java, 2015��11��16�� ����1:28:24
 */

public enum RegitEnum {
	// ע�Ὺʼ��ʾ��
	RegStartTips("RegStartTips", "��������ֻ��� ��"), RegTips("RegTips", "ע����"),
	// ע�������ʾ��
	RegEndTips("RegEndTips", "������!!");

	private String key;
	private String value;

	/**
	 * @param key
	 * @param value
	 */
	private RegitEnum(String key, String value) {
		this.key = key;
		this.value = value;
	}

	// ��ѯ����
	public static String getRegMsgEnumCovert(String regTips) {
		for (RegitEnum regitEnum : RegitEnum.values()) {
			if (regitEnum.getKey().equals(regTips)) {
				return regitEnum.getValue();
			}
		}
		return regTips;

	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

}
