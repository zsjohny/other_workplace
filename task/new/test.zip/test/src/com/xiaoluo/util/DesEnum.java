/**
 * 
 */
package com.xiaoluo.util;

/**
 * 
 * 
 * @author wb-pengjian.d
 * @version $Id: DesEnum.java, 2015-10-22 ����12:17:26
 */

public enum DesEnum {
	encypt("encrypt", "����"), decypt("decrypt", "����");

	private String key;
	private String value;

	/**
	 * @param key
	 * @param value
	 */
	private DesEnum(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public static String getEnumValue(String value) {
		// ����ö��
		for (DesEnum desEnum : DesEnum.values()) {
			if (desEnum.getValue().equals(value)) {
				return desEnum.getKey();
			}
		}

		return value;

	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

}
