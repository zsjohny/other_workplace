/**
 * 
 */
package com.xiaoluo.util;

import java.util.Properties;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: CaluRatio.java, 2016年2月17日 下午9:13:27
 */

public class CaluRatio {

	public static Double calScore(String socre, Properties properties) {


		return (1 / Double.parseDouble(properties.getProperty("appTotal"))) * Double.parseDouble(socre.trim())
				+ Double.parseDouble(properties.getProperty("appRatio"));

	}
}
