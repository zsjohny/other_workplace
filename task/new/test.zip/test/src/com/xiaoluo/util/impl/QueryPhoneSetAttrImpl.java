/**
 * 
 */
package com.xiaoluo.util.impl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.xiaoluo.util.Log4jUtil;
import com.xiaoluo.util.QueryPhoneSetAttr;

/**
 * 
 * 
 * @author wb-pengjian.d
 * @version $Id: QueryPhoneSetAttrImpl.java, 2015-10-21 ����5:37:34
 */

public class QueryPhoneSetAttrImpl implements QueryPhoneSetAttr {
	// ��־����
	private static Logger logger = Log4jUtil.init(QueryPhoneSetAttrImpl.class);

	@Override
	public void setSetConnecAttr(HttpURLConnection connection, String readPropertiesName) {
		try {

			if (readPropertiesName.equals("")) {
				return;
			}
			// ��ȡ�����ļ�
			Properties properties = new Properties();
			String webUrl = System.getProperty("user.dir") + "\\WebRoot\\properties\\appLoading\\" + readPropertiesName;
			properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(webUrl), "utf-8")));
			// ���ζ�ȡ�����ļ�������
			Enumeration<?> enumeration = properties.propertyNames();
			while (enumeration.hasMoreElements()) {
				Object object = enumeration.nextElement();
				String str = (String) object;
				connection.setRequestProperty(str, properties.getProperty(str));
			}
		} catch (Exception e) {
			logger.warn("��ȡsetSetConnecAttrʱ���ô���" + e.getMessage() + readPropertiesName);
		}

	}

}
