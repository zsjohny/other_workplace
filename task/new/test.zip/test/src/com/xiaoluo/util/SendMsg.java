package com.xiaoluo.util;


import java.io.InputStream;
import java.net.URLDecoder;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.output.ByteArrayOutputStream;

/**
 * Created by p on 2016/2/18.
 */
public class SendMsg {


    public static String batchSend(String url, String account, String pswd, String mobile, String msg,
                                   boolean needstatus, String product, String extno) throws Exception {
        HttpClient client = new HttpClient();
        GetMethod method = new GetMethod();
        try {
            URI base = new URI(url, false);
            method.setURI(new URI(base, "HttpBatchSendSM", false));
            method.setQueryString(new NameValuePair[]{
                    new NameValuePair("account", account),
                    new NameValuePair("pswd", pswd),
                    new NameValuePair("mobile", mobile),
                    new NameValuePair("needstatus", String.valueOf(needstatus)),
                    new NameValuePair("msg", msg),
                    new NameValuePair("product", product),
                    new NameValuePair("extno", extno),
            });
            int result = client.executeMethod(method);
            if (result == HttpStatus.SC_OK) {
                InputStream in;
                in = method.getResponseBodyAsStream();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len = 0;
                while ((len = in.read(buffer)) != -1) {
                    baos.write(buffer, 0, len);
                }
                return URLDecoder.decode(baos.toString(), "UTF-8");
            } else {
                throw new Exception("HTTP ERROR Status: " + method.getStatusCode() + ":" + method.getStatusText());
            }
        } finally {
            method.releaseConnection();
        }

    }


    public static void main(String[] args) {

        String url = "http://222.73.117.158/msg/";// 应用地址
        String account = "vip-szwl";// 账号
        String pswd = "Tch123456";// 密码
		String mobile = "15924179757";// 手机号码，多个号码使用","分割

		String msg = "您好，您的那个人靠谱么验证码：" + "323423" + ",请于5分钟内正确输入验证码。";// 短信内容
        boolean needstatus = true;// 是否需要状态报告，需要true，不需要false
        String product = null;// 产品ID
        String extno = null;// 扩展码
        try {
            String returnString = SendMsg.batchSend(url, account, pswd, mobile, msg, needstatus, product, extno);
			System.out.println(returnString);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
