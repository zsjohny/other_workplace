package com.xiaoluo.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class TestVisit {
	public static void main(String[] args) throws Exception {
		String url = "http://feng-home.iteye.com/blog/657089";
		URL getUrl = new URL(url);
		HttpURLConnection getConnection = (HttpURLConnection) getUrl
				.openConnection();
		InputStreamReader isReader = new InputStreamReader(
				getConnection.getInputStream(), "utf-8");
		BufferedReader bReader = new BufferedReader(isReader);

		String info = "";
		while ((info = bReader.readLine()) != null) {
			System.out.println(info);

		}
	}
}