/**
 * 
 */
package com.xiaoluo.test;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * 
 * 
 * @author wb-pengjian.d
 * @version $Id: OtherTest.java, 2015-10-21 ����6:50:11
 */

public class OtherTest {
	public static void main(String[] args) throws IOException {
		// // ���������ļ�
		// Properties properties = new Properties();
		// String webUrl = System.getProperty("user.dir") +
		// "\\WebRoot\\properties\\appLoading\\tantan.properties";
		//
		// InputStream inputStream = new FileInputStream(new File(webUrl));
		// properties.load(inputStream);
		// System.out.println(properties.getProperty("host"));

		// ����ö��

		// System.out.println(DesEnum.getEnumValue("����"));
		// ���Ա���Ip
		// Enumeration<?> allNetInterfaces = NetworkInterface
		// .getNetworkInterfaces();
		// InetAddress ip = null;
		// while (allNetInterfaces.hasMoreElements()) {
		// NetworkInterface netInterface = (NetworkInterface) allNetInterfaces
		// .nextElement();
		// Enumeration<InetAddress> addresses = netInterface
		// .getInetAddresses();
		// while (addresses.hasMoreElements()) {
		// ip = (InetAddress) addresses.nextElement();
		// if (ip != null && ip instanceof Inet4Address) {
		// System.out.println("������IP = " + ip.getHostAddress());
		// }
		// }
		// }
		// ������־����
		// Logger logger = Logger.getLogger("");
		// logger.info("û��");
		// logger.log(Level.FINEST, "����", new Exception());

		System.setProperty("java.util.logging.config.file",
				"C:\\Users\\pj\\Desktop\\onecartplugin\\demo.properties");
		Logger log = Logger.getLogger(OtherTest.class.getName());
		log.warning("������Ϣ");
		log.severe("Σ��");
	}
}
