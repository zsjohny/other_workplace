package com.xiaoluo.test;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.PostMethod;

public class SdkTest {
	// ��ַ���˿ڡ�Э��
	private String httpAddressUrl;

	// ��Ϣ���͵�ַ
	private String msgSendUrl;

	// ����ѯ��ַ
	private String msgQueryUrl;

	// �û���֤
	private String msgCheckUrl;

	// ���Ŷ�ʱ����
	private String msgScheSendUrl;

	// ���Ž��յ�ַ
	private String msgRegUrl;
	// ���������ַ
	private String msgModifyUrl;

	public String getMsgModifyUrl() {
		return msgModifyUrl;
	}

	public void setMsgModifyUrl(String msgModifyUrl) {
		this.msgModifyUrl = msgModifyUrl;
	}

	public String getMsgCheckUrl() {
		return msgCheckUrl;
	}

	public void setMsgCheckUrl(String msgCheckUrl) {
		this.msgCheckUrl = msgCheckUrl;
	}

	public String getMsgScheSendUrl() {
		return msgScheSendUrl;
	}

	public void setMsgScheSendUrl(String msgScheUrl) {
		this.msgScheSendUrl = msgScheUrl;
	}

	public String getHttpAddressUrl() {
		return httpAddressUrl;
	}

	public void setHttpAddressUrl(String httpAddressUrl) {
		this.httpAddressUrl = httpAddressUrl;
	}

	public String getMsgQueryUrl() {
		return msgQueryUrl;
	}

	public void setMsgQueryUrl(String msgQueryUrl) {
		this.msgQueryUrl = msgQueryUrl;
	}

	public String getMsgSendUrl() {
		return msgSendUrl;
	}

	public void setMsgSendUrl(String msgSendUrl) {
		this.msgSendUrl = msgSendUrl;
	}

	// ������Ϣ
	public PostMethod getSend(String userName, String password, String mobile,
			String content) {
		// System.out.println("sms send method");
		StringBuilder url = new StringBuilder();
		url.append("accountname=");
		url.append(userName);
		url.append("&accountpwd=");
		url.append(password);
		url.append("&mobilecodes=");
		url.append(mobile);
		url.append("&msgcontent=");
		url.append(content);
		// System.out.println(url);
		PostMethod post = new PostMethod(msgSendUrl);
		post.setRequestHeader("Content-type", "text/xml; charset=gbk");
		post.setRequestBody(url.toString());
		return post;
	}

	// ��ʱ������Ϣ
	public PostMethod getScheSend(String userName, String password,
			String mobile, String content, String scheTime) {
		StringBuilder url = new StringBuilder();
		url.append("accountname=");
		url.append(userName);
		url.append("&accountpwd=");
		url.append(password);
		url.append("&mobilecodes=");
		url.append(mobile);
		url.append("&attime=");
		url.append(scheTime);
		url.append("&msgcontent=");
		url.append(content);
		// System.out.println(url);
		PostMethod post = new PostMethod(msgScheSendUrl);
		post.setRequestHeader("Content-type", "text/xml; charset=gbk");
		post.setRequestBody(url.toString());
		return post;
	}

	// ����ѯ
	public PostMethod getQuery(String userName, String password) {
		StringBuilder url = new StringBuilder();
		url.append("accountname=");
		url.append(userName);
		url.append("&accountpwd=");
		url.append(password);
		// System.out.println(url.toString());
		PostMethod post = new PostMethod(msgQueryUrl);
		post.setRequestHeader("Content-type", "text/xml; charset=gbk");
		post.setRequestBody(url.toString());
		return post;
	}

	// ��������
	public PostMethod modifyPwd(String userName, String password,
			String newpassword) {
		StringBuilder url = new StringBuilder();
		url.append("accountname=");
		url.append(userName);
		url.append("&accountpwd=");
		url.append(password);
		url.append("&accountnewpwd=");
		url.append(newpassword);
		// System.out.println(url.toString());
		PostMethod post = new PostMethod(msgModifyUrl);
		post.setRequestHeader("Content-type", "text/xml; charset=gbk");
		post.setRequestBody(url.toString());
		return post;
	}

	public String getMsgRegUrl() {
		return msgRegUrl;
	}

	public void setMsgRegUrl(String msgRegUrl) {
		this.msgRegUrl = msgRegUrl;
	}

	public String smsOperation(HttpMethod method) throws IOException {
		HttpClient client = new HttpClient();
		client.getHostConfiguration().setHost("csdk.zzwhxx.com", 8002, "http");
		client.executeMethod(method);

		System.out.println("���������ص�״̬��" + method.getStatusLine());

		String value = method.getResponseBodyAsString();
		method.releaseConnection();
		return value;
	}

	public static void main(String str[]) throws Exception {
		SdkTest msgHttp = new SdkTest();
		msgHttp.setMsgSendUrl("submitsms.aspx");
		msgHttp.setMsgQueryUrl("getbalance.aspx");
		msgHttp.setMsgScheSendUrl("submitschsms.aspx");
		msgHttp.setMsgModifyUrl("changepwd.aspx");
		// ���Է��Ͷ���
		String value = msgHttp.smsOperation(msgHttp.getSend("�ʺ�", "����",
				"15924179757", "���Ͳ���"));

		System.out.println(value);
		// ���Զ�ʱ����
		String timeVal = msgHttp.smsOperation(msgHttp.getScheSend("�ʺ�", "����",
				"15924179757", "��3������eegggg��", "2012-2-21 13:33:00"));
		System.out.println(timeVal);
		// ���Ի�ȡ���
		String moneyVal = msgHttp.smsOperation(msgHttp.getQuery("�ʺ�", "����"));
		System.out.println(moneyVal);
		// ��������
		String modifyVal = msgHttp.smsOperation(msgHttp.modifyPwd("�ʺ�", "ԭ����",
				"������"));
		System.out.println(modifyVal);

	}

}