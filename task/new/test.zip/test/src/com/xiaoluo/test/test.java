/**
 * 
 */
package com.xiaoluo.test;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * 
 * @author wb-pengjian.d
 * @version $Id: test.java, 2015-10-19 ����11:54:26 wb-pengjian.d Exp $
 */

public class test {
	public static void main(String[] args) {
		// DownLoadPages("http://www.baidu.com", "download/");

		// TODO �Զ����ɵķ������

		Map<String, List<String>> map = new HashMap();

		// String surl =
		// "http://www.baidu.com/s?word=java%E8%AE%BF%E9%97%AE%E7%BD%91%E5%9D%80&tn=94368718_hao_pg&ie=utf-8&ssl_sample=normal";
		// String surl =
		// "http://localhost/query/addUser?loginname=13856368932&password=1234&judge=";
		String surl = "http://tantan-account.p1.cn/v1/oauth2/access_token?username=86 13616555130&password=879227577&grant_type=password";

		// String surl = "http://www.sina.com.cn/";
		// String surl = "https://ebank.xxxxx.com/pweb/test.do?actionType=1";
		// //������
		// try {
		// URL url = new URL(surl);
		// URLConnection urlc = url.openConnection();
		//
		// map = urlc.getHeaderFields();
		//
		// Set<String> key = map.keySet();
		// for (Iterator<String> it = key.iterator(); it.hasNext();) {
		// String s = it.next();
		// System.out.println(s + " : " + map.get(s));
		// }
		//
		// } catch (MalformedURLException e) {
		// // TODO �Զ����ɵ� catch ��
		// e.printStackTrace();
		// } catch (IOException e) {
		// // TODO �Զ����ɵ� catch ��
		// e.printStackTrace();
		// }
		// url����
		try {
			String urlDeoder = URLDecoder
					.decode("%7B%22account%22%3A%2215924179757%22%2C%22platformInfo%22%3A%7B%22w%22%3A720%2C%22product%22%3A%2241%22%2C%22phonetype%22%3A%22NoxW%22%2C%22fid%22%3A%2248411%22%2C%22platform%22%3A%223%22%2C%22netType%22%3A2%2C%22systemVersion%22%3A%224.4.2%22%2C%22mobileIP%22%3A%22%22%2C%22pid%22%3A%22352284046569343%22%2C%22imsi%22%3A%22%22%2C%22release%22%3A%2220150407%22%2C%22h%22%3A1242%2C%22version%22%3A%2240050203%22%7D%2C%22password%22%3A%221111%22%2C%22loginType%22%3A0%2C%22verType%22%3A0%7D",
							"utf-8");
			String urlEncoder = URLEncoder
					.encode("{'account':'15924179757','platformInfo':{'w':720,'product':'41','phonetype':'NoxW','fid':'48411','platform':'3','netType':2,'systemVersion':'4.4.2','mobileIP':'','pid':'352284046569343','imsi':'','release':'20150407','h':1242,'version':'40050203'},'password':'1111','loginType':0,'verType':0}",
							"utf-8");
			System.out.println(urlEncoder);
			System.out
					.println(urlEncoder == "%7B%22account%22%3A%2215924179757%22%2C%22platformInfo%22%3A%7B%22w%22%3A720%2C%22product%22%3A%2241%22%2C%22phonetype%22%3A%22NoxW%22%2C%22fid%22%3A%2248411%22%2C%22platform%22%3A%223%22%2C%22netType%22%3A2%2C%22systemVersion%22%3A%224.4.2%22%2C%22mobileIP%22%3A%22%22%2C%22pid%22%3A%22352284046569343%22%2C%22imsi%22%3A%22%22%2C%22release%22%3A%2220150407%22%2C%22h%22%3A1242%2C%22version%22%3A%2240050203%22%7D%2C%22password%22%3A%221111%22%2C%22loginType%22%3A0%2C%22verType%22%3A0%7D");

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
