/**
 * 
 */
package com.xiaoluo.test;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: EmailEasyTest.java, 2015��10��27�� ����8:21:16
 */

public class EmailEasyTest {

	public static void send(String toemail, String toname, String subject, String content) throws EmailException {// �������������ʼ�
		String fromemail = "systemAutoReply@163.com";
		String fromname = "�Ǹ��˿�����?";
		String password = "vbrnawqhllexxbbj";
		HtmlEmail multipartemail = new HtmlEmail();
		multipartemail.setHostName("smtp.163.com");
		multipartemail.addTo(toemail, toname);
		multipartemail.setFrom(fromemail, fromname);
		multipartemail.setAuthentication(fromemail, password);
		multipartemail.setSubject(subject);
		multipartemail.setCharset("gb2312");
		multipartemail.setHtmlMsg(content);
		multipartemail.send();
	}

	public static void send(String toemail, String toname, String subject, String content, List<String> filepath)
			throws EmailException, MalformedURLException {// �����������ʼ�
		String fromemail = "notreply@foxmail.com";
		String fromname = "240509";
		String password = "879227577";
		HtmlEmail multipartemail = new HtmlEmail();
		multipartemail.setHostName("smtp.qq.com");
		multipartemail.addTo(toemail, toname);
		multipartemail.setFrom(fromemail, fromname);
		multipartemail.setAuthentication(fromemail, password);
		multipartemail.setSubject(subject);
		multipartemail.setCharset("gb2312");
		multipartemail.setHtmlMsg(content);

		// ����
		if (filepath != null && filepath.size() > 0) {
			for (int i = 0; i < filepath.size(); i++) {
				EmailAttachment attac = new EmailAttachment();
				attac.setPath(filepath.get(i));
				multipartemail.attach(attac);
			}
		}
		// ����
		multipartemail.send();
		System.out.println("The attachmentEmail send sucessful!!!");
	}

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < 6; i++) {
			sb.append(String.valueOf((int) (Math.random() * 10)));
		}
		String param = sb.toString();
		List<String> list = new ArrayList<>();
		list.add(System.getProperty("user.dir") + "\\WebRoot\\properties\\log4j.properties");
		try {
			send("nessary@foxmail.com", "1", "ϵͳ��֤��", param, list);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
