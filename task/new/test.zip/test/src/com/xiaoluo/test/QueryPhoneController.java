/// **
// *
// */
// package com.xiaoluo.test;
//
// import java.io.BufferedReader;
// import java.io.BufferedWriter;
// import java.io.File;
// import java.io.FileInputStream;
// import java.io.FileOutputStream;
// import java.io.InputStream;
// import java.io.InputStreamReader;
// import java.io.OutputStream;
// import java.io.OutputStreamWriter;
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.Properties;
//
// import org.apache.commons.httpclient.HttpClient;
// import org.apache.commons.httpclient.HttpMethod;
// import org.apache.commons.httpclient.methods.GetMethod;
// import org.apache.http.HttpResponse;
// import org.apache.http.HttpStatus;
// import org.apache.http.NameValuePair;
// import org.apache.http.client.entity.UrlEncodedFormEntity;
// import org.apache.http.client.methods.HttpPost;
// import org.apache.http.impl.client.DefaultHttpClient;
// import org.apache.http.message.BasicNameValuePair;
// import org.apache.http.protocol.HTTP;
// import org.apache.http.util.EntityUtils;
// import org.apache.log4j.Logger;
//
// import com.jfinal.aop.Before;
// import com.jfinal.aop.Clear;
// import com.jfinal.core.Controller;
// import com.jfinal.plugin.activerecord.Db;
// import com.jfinal.plugin.activerecord.Record;
// import com.key.Key;
// import com.xiaoluo.interceptor.QueryPhoneGlobalInterceptor;
// import com.xiaoluo.interceptor.QueryPhoneInterceptor;
// import com.xiaoluo.util.DesEnum;
// import com.xiaoluo.util.DesUtil;
// import com.xiaoluo.util.DrawImageUtil;
// import com.xiaoluo.util.EmailSendUtil;
// import com.xiaoluo.util.Log4jUtil;
// import com.xiaoluo.util.QueryPhoneSetAttr;
// import com.xiaoluo.util.QyeryPhoneByProxyIp;
// import com.xiaoluo.util.RegitEnum;
// import com.xiaoluo.util.impl.QueryPhoneSetAttrImpl;
// import com.xiaoluo.validator.QueryPhoneValidator;
//
// import net.sf.json.JSONObject;
//
/// **
// * @author xiaoluo
// * @version $Id: QueryPhoneController.java, 2015年10月18日 下午1:36:37
// */
//
// public class QueryPhoneController extends Controller {
// // 日志加载
// private static Logger logger = Log4jUtil.init(QueryPhoneController.class);
//
// /**
// * 用于页面初始化检查
// *
// * @param
// * @return
// */
// // @Before(QueryPhoneValidator.class) // 参数检测器
// public void index() {
// // 进入初始化页面的时候建立一个cookie
// forwardAction("/init");// 转发不让用户看到真实的初始化页面
//
// }
//
// /**
// * 用于页面初始化
// *
// * @param
// * @return
// */
// public void init() {
//
// // 辨别是否有cookie
// setCookie("loginInit", "true", 60 * 30);
// renderFreeMarker("login.html");// 跳转到初始化页面
//
// }
//
// /**
// * 用于验证码
// *
// * @param
// * @return
// */
// @Clear(QueryPhoneGlobalInterceptor.class)
// // 清除全局拦截
// public void drawImage() {
//
// render(new DrawImageUtil());
//
// }
//
// /**
// * 用于页面的注册和登录
// *
// * @param
// * @return
// */
//
// public void addUser() {
//
// try {
// List<Record> list = null;
// String loginName = getPara("loginname", "").trim();
//
// String password = getPara("password", "").trim();
//
// // 查找是否存在该帐号,检验登录账号是否唯一
// if (loginName.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
// list = Db.find("select * from queryPhone where userPhone=? ",
/// Long.valueOf(loginName));
// } else {
// list = Db.find("select * from queryPhone where userName=? ", loginName);
// }
//
// // 根据是否再次输入密码判断是注册还是登录
// String jude = getPara("judge", "");
// if (jude == "") {
// if (list == null || list.size() == 0) {
// setAttr("loginnameMsg", "该帐号不存在!!");
// forwardAction("/init");
// return;
// }
// // 判断密码是否正确
// if (password.equals(list.get(0).getStr("userPassword"))) {
// // 设置密码正确的时候session
// setAttr("xiaoluo", Key.init());
// setSessionAttr("xiaoluo", getAttr("xiaoluo"));
//
// // 判断是否是管理员
// Properties properties = new Properties();
// String webUrl = System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\defaultAdmin.properties";
// properties.load(new BufferedReader(new InputStreamReader(new
/// FileInputStream(webUrl), "utf-8")));
//
// // 没有cookie的用户进入
// if (getCookie("loginInit") == null) {
// // 增加没有cookie的用户进入
// Properties propertiesUser = new Properties();
// propertiesUser.put("deaultUserSession", Key.init());
// propertiesUser.put("defaultMillsecond",
/// properties.getProperty("defaultMillsecond"));
// OutputStream output = new FileOutputStream(new File(
// System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\defaultUser\\defaultUser"
// + getAttr("realIp") + ".properties"));
// propertiesUser.store(output, "author xiaoluo");
// output.close();
// }
//
// // 判断标志--是否为管理员
// if (loginName.equals(properties.getProperty("admin").trim())
// && password.equals(properties.getProperty("password").trim())) {
//
// renderFreeMarker("onlineEncrypt.html");
// return;
//
// }
// // 普通用户进入
// // 设置当前登录的用户名称和密码
// Map<String, String> map = new HashMap<String, String>();
//
// map.put("loginName", DesUtil.encrypt(loginName, "password"));
// map.put("password", DesUtil.encrypt(password, "loginName"));
// setAttr("loginKey", map);
//
// // 将当前的用户查询次数增加一次
// // // 将当前用户的查询的次数数目加1-----充值支护的代码
// // if (loginName
// // .matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$"))
// // {
// //
// // Db.update(
// // "update queryphone set queryCount='1' where userPhone=?",
// // Long.valueOf(loginName));
// // } else {
// // Db.update(
// // "update queryphone set queryCount='1' where userName=?",
// // loginName);
// // }
//
// renderFreeMarker("findPhone.html");
//
// } else {
// setAttr("loginname", loginName);
// setAttr("passwordMsg", "该密码不正确!!");
// forwardAction("/init");
//
// }
// return;
// }
// // 注册时携带错误信息
// if (list != null && list.size() != 0 && password != "") {
// setAttr("loginnameMsg", "该帐号已存在!!");
// forwardAction("/init");
// return;
// }
// Record record = new Record();
// if (loginName.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
//
// record.set("userPhone", Long.valueOf(loginName));
//
// } else {
// record.set("userName", loginName);
//
// }
// record.set("userPassword", password);
// Boolean flag = Db.save("queryPhone", record);
// if (flag) {
// forwardAction("/init");
// } else {
// setAttr("loginnameMsg", "注册失败，请刷新重试!!");
// forwardAction("/init");
// }
// } catch (Exception e) {
// logger.warn("添加帐号出错:" + e.getMessage());
// }
//
// }
//
// public void test() {
// renderFreeMarker("findPhone.html");
// }
//
// /**
// * 会员根据输入手机号查找功能
// *
// * @param
// * @return
// */
// public void findPhone() {
//
// final String phone = getPara("findPhone", "");
// try {
// // // 限制查询一次
// // String loginAttr = getPara("loginKey");
// //
// // if (loginAttr == null) {
// // // 错误处理--非法进入
// // setAttr("loginnameMsg", "只能查询一次!!");
// // forwardAction("/init");
// // return;
// // }
// //
// // // 记录查询剩余的次数
// // int spareCount = 1;
// //
// // // 划分前台穿过来的值
// // String loginName = DesUtil.decrypt(
// // loginAttr.substring(loginAttr.lastIndexOf(", loginName=") + 12,
// // loginAttr.lastIndexOf("}")),
// // "password");
// // String password = DesUtil.decrypt(loginAttr.substring(10,
// // loginAttr.lastIndexOf(", loginName=")), "loginName");
// //
// // List<Record> list = null;
// // if
// // (loginName.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$"))
// // {
// // list = Db.find("select * from queryPhone where userPhone=? ",
// // Long.valueOf(loginName));
// // } else {
// // list = Db.find("select * from queryPhone where userName=? ",
// // loginName);
// // }
// //
// // if (list != null) {
// //
// // String userPassword = list.get(0).getStr("userPassword");
// //
// // // 获得查询还剩余的次数
// // spareCount = Integer.parseInt(list.get(0).getStr("queryCount"));
// // if (userPassword.equals(password)) {
// // // 限制查询次数一次
// // if (spareCount < 1) {
// // // 错误处理--非法进入
// // setAttr("loginnameMsg", "只能查询一次!!");
// // forwardAction("/init");
// // return;
// // }
// // }
// //
// // } else {
// //
// // setAttr("loginnameMsg", "该密码不正确!!");
// // forwardAction("/init");
// // return;
// // }
// //
// // try {
// // // 没有cookis下的用户查找手机功能
// // final Properties propertiesUser = new Properties();
// // final String defaultUserUrl = System.getProperty("user.dir")
// // + "\\WebRoot\\properties\\defaultUser\\defaultUser" +
// // getAttr("realIp") + ".properties";
// // // 判断该文件是否被删除
// // File file = new File(defaultUserUrl);
// // if (file.exists()) {
// // // 存在的时候加载文件
// // propertiesUser
// // .load(new BufferedReader(new InputStreamReader(new
// // FileInputStream(defaultUserUrl), "utf-8")));
// // }
// // if (propertiesUser.getProperty("deaultUserSession") == null) {
// // // 正常有cookie下的模式查询
// // // 获得判断标志
// // if (!(getPara("luo") == null ? "luo" : getPara("luo"))
// // .equals((getSessionAttr("xiaoluo") == null ? "xiaoluo" :
// // getSessionAttr("xiaoluo")))) {
// // // 错误处理--非法进入
// // setAttr("loginnameMsg", "请勿非法进入!!");
// // forwardAction("/init");
// // return;
// // }
// //
// // }
// //
// // // 获取前台输入的手机
// // final String phone = getPara("findPhone", "");
// //
// // if
// // (!phone.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$"))
// // {
// // removeSessionAttr("xiaoluo");
// // setAttr("xiaoluo", Key.init());
// // setSessionAttr("xiaoluo", getAttr("xiaoluo"));
// // // JSONObject jsonObject = new JSONObject();
// // // jsonObject.put("check", "false");
// // JSONObject jsonObject =
// // JSONObject.fromObject("{'check':'false'}");
// // renderJson(jsonObject.toString());
// //
// // }
// //
// // // 将当前用户的查询的次数数目减1--除非是充值之后才可以进入
// // if
// // (loginName.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$"))
// // {
// //
// // Db.update("update queryphone set queryCount=? where userPhone=?",
// // String.valueOf(--spareCount),
// // Long.valueOf(loginName));
// // } else {
// // Db.update("update queryphone set queryCount=? where userName=?",
// // String.valueOf(--spareCount),
// // loginName);
// // }
// // // 移除session
// // removeSessionAttr("xiaoluo");
// //
// // // 再次判定是否是有cookie
// // if (propertiesUser.getProperty("deaultUserSession") != null) {
// // // 没有cookie,删除文件
// // System.gc();
// // file.delete();
// // }
//
// // 加载配置文件
// final Properties properties = new Properties();
// String webUrl = System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\queryphoneController.properties";
// properties.load(new BufferedReader(new InputStreamReader(new
/// FileInputStream(webUrl), "utf-8")));
// // 用于前台展示注册的手机数目
// final StringBuilder sb = new StringBuilder();
// // 开始注册信息
// sb.append(properties.getProperty("RegStartTips") + phone +
/// RegitEnum.getRegMsgEnumCovert("RegTips"));
// //
/// App查询程序-------------------------------start----------------------------------------
//
// // // 读多个程序的配置
// // Enumeration<?> enumeration = properties.propertyNames();
// //
// // // 用于App配置文件的计数的存取
// // int wroteCount = 0;
// // // 用于存取读取的配置文件
// // final List<String> appList = new ArrayList<String>();
// // // 用于读取多少个配置文件的技术
// // while (enumeration.hasMoreElements()) {
// // Object object = enumeration.nextElement();
// // String propetery = (String) object;
// // appList.add(wroteCount++, propetery);
// //
// // }
// //
// // for (int i = 0; i < Integer.valueOf(properties
// // .getProperty("RegCount")); i++) {
// // // 用于配置每个App查询的开始
// // final int appStarCount = (i - 0) * 6 + 3;
// // // 进入设定App查询
// // Thread threadAppQuery = new Thread() {
// //
// // public void run() {
// // // 用于App配置文件的读取
// // int readCount = appStarCount;
// // QueryPhoneSetAttr queryPhoneSetAttr = new
// // QueryPhoneSetAttrImpl();// 配置属性
// //
// // Map<String, String> map = QyeryPhoneByProxyIp
// // .httpURLConnectionPOST(
// // appList.get(readCount++),
// // appList.get(readCount++) + phone
// // + appList.get(readCount++),
// // queryPhoneSetAttr,
// // appList.get(readCount++));
// // JSONObject jsonObject = JSONObject.fromObject(map
// // .get("content"));
// // if (jsonObject.get("message")
// // .equals(properties.getProperty(appList
// // .get(readCount++)))) {
// // sb.append(appList.get(readCount++));
// // }
// // }
// //
// // };
// //
// // }
//
// // 进入探探App查询
// final Thread threadTantan = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = QyeryPhoneByProxyIp
// .httpURLConnectionPOST(properties.getProperty("tantanUrl"),
// properties.getProperty("tantanParam") + phone
// + properties.getProperty("tantanOtherParam"),
// queryPhoneSetAttr, properties.getProperty("tantanAttr"));
// JSONObject jsonObject = JSONObject.fromObject(map.get("content"));
// if (jsonObject.get("message").equals(properties.getProperty("tantanRegMsg")))
/// {
// sb.append(properties.getProperty("tantanTips"));
// }
// }
//
// };
// // 连接超时
// // 约单App查询
// final Thread threadYuedan = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = QyeryPhoneByProxyIp
// .httpURLConnectionPOST(properties.getProperty("yuedanUrl"),
// properties.getProperty("yuedanParam") + phone
// + properties.getProperty("yuedanOtherParam"),
// queryPhoneSetAttr, properties.getProperty("yuedanAttr"));
// // String yueDanMsg = map.get("content").split("==")[1];
// // if
// // (!yueDanMsg.equals(properties.getProperty("yuedanRegMsg")))
// // {
// // sb.append(properties.getProperty("yuedanTips"));
// // }
// }
//
// };
// // 友约App查询
// // final Thread threadYouyue = new Thread() {
// //
// // public void run() {
// // QueryPhoneSetAttr queryPhoneSetAttr = new
// // QueryPhoneSetAttrImpl();// 配置属性
// // Map<String, String> map = QyeryPhoneByProxyIp
// // .httpURLConnectionPOST(properties.getProperty("youyueUrl"),
// // properties.getProperty("youyueParam") + phone
// // + properties.getProperty("youyueOtherParam"),
// // queryPhoneSetAttr, properties.getProperty("youyueAttr"));
// // JSONObject jsonObject =
// // JSONObject.fromObject(map.get("content"));
// // if
// //
/// (!(jsonObject.get("error_info").equals(properties.getProperty("youyueRegMsg"))
// // ||
// //
/// (jsonObject.get("error_info").equals(properties.getProperty("youyueRegMsgs")))))
// // {
// // sb.append(properties.getProperty("youyueTips"));
// // }
// // }
// //
// // };
// // 激情约会App查询--有缘网
// final Thread threadJiqingyuehui = new Thread() {
//
// public void run() {
// try {
// // HttpClient模拟POST的方式登录
// // 目标地址
// HttpPost httpPost = new HttpPost(properties.getProperty("jiqingyuehuiUrl"));
// // 模拟客户写入参数
// List<NameValuePair> params = new ArrayList<NameValuePair>();
// params.add(new
/// BasicNameValuePair(properties.getProperty("jiqingyuehuiParam"), phone));
// httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));
// // 使用DefaultHttpClient类的execute方法发送HTTP
// // POST请求，并返回HttpResponse对象。
// HttpResponse response = new DefaultHttpClient().execute(httpPost);
// if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
// String result = EntityUtils.toString(response.getEntity());
// if (result.equals(properties.getProperty("jiqingyuehuiRegMsg"))) {
// sb.append(properties.getProperty("jiqingyuehuiTips"));
// }
// }
// } catch (Exception e) {
// logger.warn("有缘网查询App失败:" + e.getMessage());
// }
// }
//
// };
// // 单身交友App查询
// final Thread threadDanshenjiaoyou = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("danshenjiaoyouUrl"),
//
// properties.getProperty("danshenjiaoyouParam") + phone
// + properties.getProperty("danshenjiaoyouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("danshenjiaoyouAttr"));
//
// if (!map.get("content").equals("")) {
// sb.append(properties.getProperty("danshenjiaoyouTips"));
// }
// }
//
// };
// // 像像App查询
// final Thread threadXiangxiang = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xiangxiangUrl"),
//
// properties.getProperty("xiangxiangParam") + phone
// + properties.getProperty("xiangxiangOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("xiangxiangAttr"));
//
// if (JSONObject.fromObject(map.get("content")).toString()
// .indexOf(properties.getProperty("xiangxiangRegMsg")) > 0) {
// sb.append(properties.getProperty("xiangxiangTips"));
// }
// }
//
// };
//
// // 连接超时
// // 柏拉图App查询
// final Thread threadBolatu = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("bolatuUrl"),
//
// properties.getProperty("bolatuParam") + phone +
/// properties.getProperty("bolatuOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("bolatuAttr"));
//
// // if (!JSONObject.fromObject(map.get("content")).get("msg")
// // .equals(properties.getProperty("bolatuRegMsg"))) {
// // sb.append(properties.getProperty("bolatuTips"));
// // }
// }
//
// };
//
// // 租我App查询
// final Thread threadZuwo = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zuwoUrl"),
//
// properties.getProperty("zuwoParam") + phone +
/// properties.getProperty("zuwoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("zuwoAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("zuwoRegMsg"))) {
// sb.append(properties.getProperty("zuwoTips"));
// }
// }
//
// };
//
// // 美丽约App查询
// final Thread threadMeiliyue = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("meiliyueUrl"),
//
// properties.getProperty("meiliyueParam") + phone
// + properties.getProperty("meiliyueOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("meiliyueAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("meiliyueRegMsg"))) {
// sb.append(properties.getProperty("meiliyueTips"));
// }
// }
//
// };
// // 蜜约App查询
// final Thread threadMiyue = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("miyueUrl"),
//
// properties.getProperty("miyueParam") + phone +
/// properties.getProperty("miyueOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("miyueAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("message")
// .equals(properties.getProperty("miyueRegMsg"))) {
// sb.append(properties.getProperty("miyueTips"));
// }
// }
//
// };
// // 勿忘我App查询
// final Thread threadWuwangwo = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("wuwangwoUrl"),
//
// properties.getProperty("wuwangwoParam") + phone
// + properties.getProperty("wuwangwoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("wuwangwoAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("message")
// .equals(properties.getProperty("wuwangwoRegMsg"))) {
// sb.append(properties.getProperty("wuwangwoTips"));
// }
// }
//
// };
// // metooApp查询
// final Thread threadMetoo = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("metooUrl"),
//
// properties.getProperty("metooParam") + phone +
/// properties.getProperty("metooOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("metooAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("error")
// .equals(properties.getProperty("metooRegMsg"))) {
// sb.append(properties.getProperty("metooTips"));
// }
// }
//
// };
// // 有短信通知换
// // 世纪佳缘App查询
// final Thread threadShijijiayuan = new Thread() {
//
// public void run() {
//
// String string =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("shijijiayuanUrl"),
//
// properties.getProperty("shijijiayuanParam") + phone
// + properties.getProperty("shijijiayuanOtherParam"));
//
// if (!JSONObject.fromObject(string).get("msg")
// .equals(properties.getProperty("shijijiayuanRegMsg"))) {
// sb.append(properties.getProperty("shijijiayuanTips"));
// }
//
// }
//
// ;
// };
// // PP语音App查询
// final Thread threadPpyuyin = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ppyuyinUrl"),
//
// properties.getProperty("ppyuyinParam") + phone
// + properties.getProperty("ppyuyinOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("ppyuyinAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("ppyuyinRegMsg"))) {
// sb.append(properties.getProperty("ppyuyinTips"));
// }
//
// }
//
// };
// // 激情爱恋App查询
// final Thread threadJiqingailian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jiqingailianUrl"),
//
// properties.getProperty("jiqingailianParam") + phone
// + properties.getProperty("jiqingailianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("jiqingailianAttr"));
//
// if (JSONObject.fromObject(map.get("content")).get("error").equals(0)) {
// sb.append(properties.getProperty("jiqingailianTips"));
// }
//
// }
//
// };
// // 九秀美女直播间App查询
// final Thread threadJiuxiumeinvzhibojian = new Thread() {
//
// public void run() {
//
// String msg = QyeryPhoneByProxyIp.httpURLConnectionGET(
// properties.getProperty("jiuxiumeinvzhibojianUrl"),
//
// properties.getProperty("jiuxiumeinvzhibojianParam") + phone
// + properties.getProperty("jiuxiumeinvzhibojianOtherParam")
//
// );
//
// int code =
/// Integer.parseInt(properties.getProperty("jiuxiumeinvzhibojianRegMsg"));
// if (!JSONObject.fromObject(msg).get("code").equals(code)) {
//
// sb.append(properties.getProperty("jiuxiumeinvzhibojianTips"));
// }
// }
//
// };
// // 乐园交友App查询
// final Thread threadLeyuanjiaoyou = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("leyuanjiaoyouUrl"),
//
// properties.getProperty("leyuanjiaoyouParam") + phone
// + properties.getProperty("leyuanjiaoyouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("leyuanjiaoyouAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("message")
// .equals(properties.getProperty("leyuanjiaoyouRegMsg"))) {
// sb.append(properties.getProperty("leyuanjiaoyouTips"));
// }
//
// }
//
// };
// // 么么哒App查询---被查询的会有短信通知
// final Thread threadMemeda = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("memedaUrl"),
//
// properties.getProperty("memedaParam") + phone +
/// properties.getProperty("memedaOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("memedaAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("RC")
// .equals(properties.getProperty("memedaRegMsg"))) {
// // sb.append(properties.getProperty("memedaTips"));
// }
//
// }
//
// };
//
// // 随遇App查询
// final Thread threadSuiyu = new Thread() {
//
// public void run() {
//
// String string =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("suiyuUrl"),
//
// properties.getProperty("suiyuParam") + phone +
/// properties.getProperty("suiyuOtherParam"));
//
// if
/// (JSONObject.fromObject(string).get("msg").equals(properties.getProperty("suiyuRegMsg")))
/// {
// sb.append(properties.getProperty("suiyuTips"));
// }
//
// }
//
// };
// // 影约App查询
// final Thread threadYingyue = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yingyueUrl"),
//
// properties.getProperty("yingyueParam") + phone
// + properties.getProperty("yingyueOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yingyueAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("yingyueRegMsg"))) {
// sb.append(properties.getProperty("yingyueTips"));
// }
//
// }
//
// };
// // 百合婚恋App查询
// final Thread threadBaihehunlian = new Thread() {
//
// public void run() {
//
// // QueryPhoneSetAttr queryPhoneSetAttr = new
// // QueryPhoneSetAttrImpl();// 配置属性
// // Map<String, String> map = null;
// //
// // map =
// //
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("baihehunlianUrl"),
// //
// // properties.getProperty("baihehunlianParam") + phone
// // + properties.getProperty("baihehunlianOtherParam"),
// //
// // queryPhoneSetAttr,
// // properties.getProperty("baihehunlianAttr"));
// //
// // if
// // (!JSONObject.fromObject(map.get("content")).get("message")
// // .equals(properties.getProperty("baihehunlianRegMsg"))) {
// // sb.append(properties.getProperty("baihehunlianTips"));
// // }
//
// }
//
// };
// // 今日有约App查询
// final Thread threadjinriyouyue = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jinriyouyueUrl"),
//
// properties.getProperty("jinriyouyueParam") + phone
// + properties.getProperty("jinriyouyueOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("jinriyouyueAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("tips")
// .equals(properties.getProperty("jinriyouyueRegMsg"))) {
// sb.append(properties.getProperty("jinriyouyueTips"));
// }
//
// }
//
// };
// // 寂寞美女约会App查询--服务器貌似坏了
// final Thread threadJimomeinvyuehui = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jimomeinvyuehuiUrl"),
//
// properties.getProperty("jimomeinvyuehuiParam") + phone
// + properties.getProperty("jimomeinvyuehuiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("jimomeinvyuehuiAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("event")
// .equals(properties.getProperty("jimomeinvyuehuiRegMsg"))) {
// sb.append(properties.getProperty("jimomeinvyuehuiTips"));
// }
//
// }
//
// };
// // 对面App查询
// final Thread threadDuimian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("duimianUrl"),
//
// properties.getProperty("duimianParam") + phone
// + properties.getProperty("duimianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("duimianAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("duimianRegMsg"))) {
// // sb.append(properties.getProperty("duimianTips"));
// }
//
// }
//
// };
// // 花田App查询---网易账号可以登录
// final Thread threadHuatian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("huatianUrl"),
//
// properties.getProperty("huatianParam") + phone
// + properties.getProperty("huatianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("huatianAttr"));
//
// if (JSONObject.fromObject(map.get("content")).get("status")
// .equals(properties.getProperty("huatianRegMsg"))) {
// sb.append(properties.getProperty("huatianTips"));
// }
//
// }
//
// };
// // 有我App查询
// final Thread threadYouwo = new Thread() {
//
// public void run() {
//
// HttpClient client = new HttpClient();
// HttpMethod method = new GetMethod(properties.getProperty("youwoUrl") + "?"
// + properties.getProperty("youwoParam") + phone +
/// properties.getProperty("youwoOtherParam"));
// try {
// OutputStream os = new FileOutputStream(
// new File(System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\appLoading",
// properties.getProperty("youwoAttr")));
// client.executeMethod(method);
// if (method.getStatusCode() == HttpStatus.SC_OK) {
// InputStream is = method.getResponseBodyAsStream();
// byte[] b = new byte[1024];
// int len = 0;
// while ((len = is.read(b)) != -1) {
// os.write(b, 0, len);
//
// if (len != Integer.parseInt((properties.getProperty("youwoRegMsg")))) {
// sb.append(properties.getProperty("youwoTips"));
// }
// }
// }
// } catch (Exception e) {
// logger.warn("有我App读取数据请求出错:" + e.getMessage());
// }
// }
// };
// // 遇见App查询--短信验证会有
// final Thread threadYujian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yujianUrl"),
//
// properties.getProperty("yujianParam") + phone +
/// properties.getProperty("yujianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yujianAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("errordesc")
// .equals(properties.getProperty("yujianRegMsg"))) {
// sb.append(properties.getProperty("yujianTips"));
// }
//
// }
//
// };
// // 新浪微博App查询---派派
// final Thread threadXianlangweibo = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xianlangweiboUrl"),
//
// properties.getProperty("xianlangweiboParam") + phone
// + properties.getProperty("xianlangweiboOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("xianlangweiboAttr"));
//
// if (!properties.getProperty("xianlangweiboRegMsg")
// .equals(JSONObject.fromObject(map.get("content")).get("errmsg"))) {
// sb.append(properties.getProperty("xianlangweiboTips"));
// }
//
// }
//
// };
// // 领爱App查询
// final Thread threadLingai = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lingaiUrl"),
//
// properties.getProperty("lingaiParam") + phone +
/// properties.getProperty("lingaiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("lingaiAttr"));
//
// if (JSONObject.fromObject(map.get("content").replace("(", "").replace(")",
/// "")).get("msg")
// .equals(properties.getProperty("lingaiRegMsg"))) {
// sb.append(properties.getProperty("lingaiTips"));
// }
//
// }
//
// };
//
// // 成人之美App查询
// final Thread threadChengrenzhimei = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chengrenzhimeiUrl"),
//
// properties.getProperty("chengrenzhimeiParam") + phone
// + properties.getProperty("chengrenzhimeiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("chengrenzhimeiAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("errorInfo")
// .equals(properties.getProperty("chengrenzhimeiRegMsg"))) {
// sb.append(properties.getProperty("chengrenzhimeiTips"));
// }
//
// }
//
// };
// // 在线求爱App查询---数据加密
// final Thread threadZaixianqiuai = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zaixianqiuaiUrl"),
//
// properties.getProperty("zaixianqiuaiParam") + phone
// + properties.getProperty("zaixianqiuaiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("zaixianqiuaiAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("error")
// .equals(Integer.parseInt(properties.getProperty("zaixianqiuaiRegMsg")))) {
// sb.append(properties.getProperty("zaixianqiuaiTips"));
// }
//
// }
//
// };
// // 爱吧App查询---签名错误
// final Thread threadAiba = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("aibaUrl"),
//
// properties.getProperty("aibaParam") + phone +
/// properties.getProperty("aibaOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("aibaAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("return_msg")
// .equals(properties.getProperty("aibaRegMsg"))) {
// sb.append(properties.getProperty("aibaTips"));
// }
//
// }
//
// };
// // 抱抱App查询
// final Thread threadBaobao = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("baobaoUrl"),
//
// properties.getProperty("baobaoParam") + phone +
/// properties.getProperty("baobaoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("baobaoAttr"));
//
// if (JSONObject.fromObject(map.get("content")).toString()
//
// .indexOf((properties.getProperty("baobaoRegMsg"))) > -1) {
// sb.append(properties.getProperty("baobaoTips"));
// }
//
// }
//
// };
// // 行者App查询
// final Thread threadXingzhe = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("xingzheUrl"),
//
// properties.getProperty("xingzheParam") + phone
// + properties.getProperty("xingzheOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("xingzheAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("errmsg")
// .equals(properties.getProperty("xingzheRegMsg"))) {
// sb.append(properties.getProperty("xingzheTips"));
// }
//
// }
//
// };
// // 敢聊App查询
// final Thread threadGanliao = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ganliaoUrl"),
//
// properties.getProperty("ganliaoParam") + phone
// + properties.getProperty("ganliaoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("ganliaoAttr"));
//
// if (JSONObject.fromObject(map.get("content")).get("code")
// .equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[0]))
// || JSONObject.fromObject(map.get("content")).get("code")
// .equals(Integer.parseInt(properties.getProperty("ganliaoRegMsg").split("_")[1])))
/// {
// sb.append(properties.getProperty("ganliaoTips"));
// }
//
// }
//
// };
//
// // 真巧App查询
// final Thread threadZhenqiao = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhenqiaoUrl"),
//
// properties.getProperty("zhenqiaoParam") + phone
// + properties.getProperty("zhenqiaoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("zhenqiaoAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("zhenqiaoRegMsg"))) {
// sb.append(properties.getProperty("zhenqiaoTips"));
// }
//
// }
//
// };
//
// // 豆瓣App查询
// final Thread threadDouban = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("doubanUrl"),
//
// properties.getProperty("doubanParam") + phone +
/// properties.getProperty("doubanOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("doubanAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("description")
// .equals(properties.getProperty("doubanRegMsg"))) {
// sb.append(properties.getProperty("doubanTips"));
// }
//
// }
//
// };
// // 论酒App查询
// final Thread threadLunjiu = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lunjiuUrl"),
//
// properties.getProperty("lunjiuParam") + phone +
/// properties.getProperty("lunjiuOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("lunjiuAttr"));
//
// if
/// (!map.get("content").toString().equals(properties.getProperty("lunjiuRegMsg")))
/// {
// sb.append(properties.getProperty("lunjiuTips"));
// }
//
// }
//
// };
//
// // 知乎App查询------------------https协议待解决
// final Thread threadZhihu = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhihuUrl"),
//
// properties.getProperty("zhihuParam") + phone +
/// properties.getProperty("zhihuOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("zhihuAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("message")
// .equals(properties.getProperty("zhihuRegMsg"))) {
// sb.append(properties.getProperty("zhihuTips"));
// }
//
// }
//
// };
//
// // 爱真心App查询
// final Thread threadAizhenxin = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("aizhenxinUrl"),
//
// properties.getProperty("aizhenxinParam") + phone
// + properties.getProperty("aizhenxinOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("aizhenxinAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("retmean")
// .equals(properties.getProperty("aizhenxinRegMsg"))) {
// sb.append(properties.getProperty("aizhenxinTips"));
// }
//
// }
//
// };
//
// // 同城交友见见App查询
// final Thread threadTongchengjiaoyoujianjian = new Thread() {
//
// public void run() {
//
// String string = QyeryPhoneByProxyIp.httpURLConnectionGET(
// properties.getProperty("tongchengjiaoyoujianjianUrl"),
//
// properties.getProperty("tongchengjiaoyoujianjianParam") + phone
// + properties.getProperty("tongchengjiaoyoujianjianOtherParam"));
//
// if ((!JSONObject.fromObject(string).get("message")
// .equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg"))
// && !JSONObject.fromObject(string).get("message")
// .equals(properties.getProperty("tongchengjiaoyoujianjianRegMsg1")))) {
// sb.append(properties.getProperty("tongchengjiaoyoujianjianTips"));
// }
//
// }
// };
// // ZANKApp查询
// final Thread threadZANK = new Thread() {
//
// public void run() {
// String string =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("ZANKUrl"),
//
// properties.getProperty("ZANKParam") + phone +
/// properties.getProperty("ZANKOtherParam"));
//
// if
/// (!JSONObject.fromObject(string).get("error").equals(properties.getProperty("ZANKRegMsg")))
/// {
// sb.append(properties.getProperty("ZANKTips"));
// }
// }
//
// };
//
// // 六间房秀场App查询
// final Thread threadLiujianfangxiuchang = new Thread() {
//
// public void run() {
// String string = QyeryPhoneByProxyIp.httpURLConnectionGET(
// properties.getProperty("liujianfangxiuchangUrl"),
//
// properties.getProperty("liujianfangxiuchangParam") + phone
// + properties.getProperty("liujianfangxiuchangOtherParam"));
//
// if (string.indexOf(properties.getProperty("liujianfangxiuchangRegMsg")) ==
/// -1) {
// sb.append(properties.getProperty("liujianfangxiuchangTips"));
// }
//
// }
//
// };
// // 除夜约App查询
// final Thread threadChuyeyue = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("chuyeyueUrl"),
//
// properties.getProperty("chuyeyueParam") + phone
// + properties.getProperty("chuyeyueOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("chuyeyueAttr"));
//
// if (JSONObject.fromObject(map.get("content")).get("error").toString()
// .indexOf(properties.getProperty("chuyeyueRegMsg")) == -1) {
// sb.append(properties.getProperty("chuyeyueTips"));
// }
//
// }
//
// };
//
// // 缘来婚恋App查询
// final Thread threadYuanlaihunlian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuanlaihunlianUrl"),
//
// properties.getProperty("yuanlaihunlianParam") + phone
// + properties.getProperty("yuanlaihunlianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yuanlaihunlianAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("yuanlaihunlianRegMsg"))) {
// sb.append(properties.getProperty("yuanlaihunlianTips"));
// }
//
// }
//
// };
// // 百合婚恋App查询
// final Thread threadBaihe = new Thread() {
//
// public void run() {
//
// String str =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("baiheUrl"),
// "jsonCallBack=jQuery18307090277567040175_1451103749446&l1451103760230&email="
/// + phone
// + "&_=1451103760233");
//
// if (JSONObject.fromObject(str.substring(str.indexOf("{"),
/// str.lastIndexOf(")"))).get("data")
// .equals(properties.getProperty("baiheRegMsg"))) {
// sb.append(properties.getProperty("baiheTips"));
// }
//
// }
//
// };
//
// // 58交友App查询
// final Thread thread58jiaoyou = new Thread() {
//
// public void run() {
//
// String str =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("58jiaoyouUrl"),
// properties.getProperty("58jiaoyouParam") + phone);
//
// if (str.indexOf(properties.getProperty("58jiaoyouRegMsg")) == -1) {
// sb.append(properties.getProperty("58jiaoyouTips"));
// }
//
// }
//
// };
//
// // 红娘App查询
// final Thread threadHongniang = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("hongniangUrl"),
//
// properties.getProperty("hongniangParam") + phone
// + properties.getProperty("hongniangOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("hongniangAttr"));
//
// if
/// (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("hongniangRegMsg")))
/// {
// sb.append(properties.getProperty("hongniangTips"));
// }
//
// }
//
// };
//
// // 赛客App查询
// final Thread threadShaige = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shaigeUrl"),
//
// properties.getProperty("shaigeParam") + phone +
/// properties.getProperty("shaigeOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("shaigeAttr"));
//
// if (!JSONObject
// .fromObject(map.toString().substring(map.toString().indexOf("{\""),
// map.toString().indexOf("\"}") + 2))
// .get("desc").equals(properties.getProperty("shaigeRegMsg"))) {
// sb.append(properties.getProperty("shaigeTips"));
// }
//
// }
//
// };
// // 我在找你App查询
// final Thread threadWozaizhaoni = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("wozaizhaoniUrl"),
//
// properties.getProperty("wozaizhaoniParam") + phone
// + properties.getProperty("wozaizhaoniOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("wozaizhaoniAttr"));
//
// if (!JSONObject.fromObject(map).get("content")
// .equals(properties.getProperty("wozaizhaoniRegMsg"))) {
// sb.append(properties.getProperty("wozaizhaoniTips"));
// }
//
// }
//
// };
// // 中国红娘网App查询
// final Thread threadZhongguohongniangwang = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhongguohongniangwangUrl"),
//
// properties.getProperty("zhongguohongniangwangParam") + phone
// + properties.getProperty("zhongguohongniangwangOtherParam") + phone,
//
// queryPhoneSetAttr, properties.getProperty("zhongguohongniangwangAttr"));
// if (!JSONObject.fromObject(map).get("content")
// .equals(properties.getProperty("zhongguohongniangwangRegMsg"))) {
// sb.append(properties.getProperty("zhongguohongniangwangTips"));
// }
//
// }
//
// };
//
// // 若邻App查询
// final Thread threadRuoling = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("ruolingUrl"),
//
// properties.getProperty("ruolingParam") + phone
// + properties.getProperty("ruolingOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("ruolingAttr"));
//
// if
/// (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("ruolingRegMsg")))
/// {
// sb.append(properties.getProperty("ruolingTips"));
// }
//
// }
//
// };
//
// // 猜么App查询
// final Thread threadCaime = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("caimeUrl"),
//
// properties.getProperty("caimeParam") + phone +
/// properties.getProperty("caimeOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("caimeAttr"));
//
// if (!JSONObject
// .fromObject(map.toString().substring(map.toString().indexOf("{\""),
// map.toString().lastIndexOf(",")))
// .get("msg").equals(properties.getProperty("caimeRegMsg"))) {
// sb.append(properties.getProperty("caimeTips"));
// }
//
// }
//
// };
//
// // 约会说App查询
// final Thread threadYuehuishuo = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuehuishuoUrl"),
//
// properties.getProperty("yuehuishuoParam") + phone
// + properties.getProperty("yuehuishuoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yuehuishuoAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("yuehuishuoRegMsg"))) {
// sb.append(properties.getProperty("yuehuishuoTips"));
// }
//
// }
//
// };
// // 约会吧App查询
// final Thread threadYuihuiba = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yuihuibaUrl"),
//
// properties.getProperty("yuihuibaParam") + phone
// + properties.getProperty("yuihuibaOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yuihuibaAttr"));
//
// if
/// (!JSONObject.fromObject(map).get("content").equals(properties.getProperty("yuihuibaRegMsg")))
/// {
// sb.append(properties.getProperty("yuihuibaTips"));
// }
//
// }
//
// };
//
// // 都秀嗨皮App查询
// final Thread threadDouxiuhaipi = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("douxiuhaipiUrl"),
//
// properties.getProperty("douxiuhaipiParam") + phone
// + properties.getProperty("douxiuhaipiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("douxiuhaipiAttr"));
//
// if (!JSONObject.fromObject(map.get("content")).get("msg")
// .equals(properties.getProperty("douxiuhaipiRegMsg"))) {
// sb.append(properties.getProperty("douxiuhaipiTips"));
// }
//
// }
//
// };
// // 友寻交友App查询
// final Thread threadYouxunjiaoyou = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youxunjiaoyouUrl"),
//
// properties.getProperty("youxunjiaoyouParam") + phone
// + properties.getProperty("youxunjiaoyouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("youxunjiaoyouAttr"));
//
// if ((Integer)
/// JSONObject.fromObject(map.toString().substring(map.toString().indexOf(":{\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("status")
//
// != Integer.parseInt(properties.getProperty("youxunjiaoyouRegMsg"))) {
// sb.append(properties.getProperty("youxunjiaoyouTips"));
// }
//
// }
//
// };
//
// // 人脉通App查询
// final Thread threadRenmaitong = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("renmaitongUrl"),
//
// properties.getProperty("renmaitongParam") + phone
// + properties.getProperty("renmaitongOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("renmaitongAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf(":{\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("Tips")
//
// .equals(properties.getProperty("renmaitongRegMsg"))) {
// sb.append(properties.getProperty("renmaitongTips"));
// }
//
// }
//
// };
// // 约碰同城交友App查询
// final Thread threadYuepengtongchengjiaoyou = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map = QyeryPhoneByProxyIp.httpURLConnectionPOST(
// properties.getProperty("yuepengtongchengjiaoyouUrl"),
//
// properties.getProperty("yuepengtongchengjiaoyouParam") + phone
// + properties.getProperty("yuepengtongchengjiaoyouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yuepengtongchengjiaoyouAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("msg")
//
// .equals(properties.getProperty("yuepengtongchengjiaoyouRegMsg"))) {
// sb.append(properties.getProperty("yuepengtongchengjiaoyouTips"));
// }
//
// }
//
// };
// // 寂寞单身约会App查询
// final Thread threadJimodanshenyuehui = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jimodanshenyuehuiUrl"),
//
// properties.getProperty("jimodanshenyuehuiParam") + phone
// + properties.getProperty("jimodanshenyuehuiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("jimodanshenyuehuiAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("event")
//
// .equals(properties.getProperty("jimodanshenyuehuiRegMsg"))) {
// sb.append(properties.getProperty("jimodanshenyuehuiTips"));
// }
//
// }
//
// };
// // 有约App查询
// final Thread threadYouyue = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("youyueUrl"),
//
// properties.getProperty("youyueParam") + phone +
/// properties.getProperty("youyueOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("youyueAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("error_info")
//
// .equals(properties.getProperty("youyueRegMsg"))) {
// sb.append(properties.getProperty("youyueTips"));
// }
//
// }
//
// };
//
// // 脸脸App查询
// final Thread threadLianlian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("lianlianUrl"),
//
// properties.getProperty("lianlianParam") + phone
// + properties.getProperty("lianlianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("lianlianAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("error")
//
// .equals(properties.getProperty("lianlianRegMsg"))) {
// sb.append(properties.getProperty("lianlianTips"));
// }
//
// }
//
// };
// // 两面App查询
// final Thread threadLiangmian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("liangmianUrl"),
//
// properties.getProperty("liangmianParam") + phone
// + properties.getProperty("liangmianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("liangmianAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("code_msg")
//
// .equals(properties.getProperty("liangmianRegMsg"))) {
// sb.append(properties.getProperty("liangmianTips"));
// }
//
// }
//
// };
//
// // TutuApp查询
// final Thread threadTutu = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tutuUrl"),
//
// properties.getProperty("tutuParam") + phone +
/// properties.getProperty("tutuOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("tutuAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("desc")
//
// .equals(properties.getProperty("tutuRegMsg"))) {
// sb.append(properties.getProperty("tutuTips"));
// }
//
// }
//
// };
// // 找到taApp查询
// final Thread threadZhaodaota = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zhaodaotaUrl"),
//
// properties.getProperty("zhaodaotaParam") + phone
// + properties.getProperty("zhaodaotaOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("zhaodaotaAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("msg")
//
// .equals(properties.getProperty("zhaodaotaRegMsg"))) {
// sb.append(properties.getProperty("zhaodaotaTips"));
// }
//
// }
//
// };
// // 见见App查询
// final Thread threadJianjian = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("jianjianUrl"),
//
// properties.getProperty("jianjianParam") + phone
// + properties.getProperty("jianjianOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("jianjianAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("Message")
//
// .equals(properties.getProperty("jianjianRegMsg"))) {
// sb.append(properties.getProperty("jianjianTips"));
// }
//
// }
//
// };
//
// // 亲亲App查询
// final Thread threadQinqin = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("qinqinUrl"),
//
// properties.getProperty("qinqinParam") + phone +
/// properties.getProperty("qinqinOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("qinqinAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("errorMsg")
//
// .equals(properties.getProperty("qinqinRegMsg"))) {
// sb.append(properties.getProperty("qinqinTips"));
// }
//
// }
//
// };
// // 陌游App查询
// final Thread threadMoyou = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moyouUrl"),
//
// properties.getProperty("moyouParam") + phone +
/// properties.getProperty("moyouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("moyouAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("entity")
//
// .equals(properties.getProperty("moyouRegMsg"))) {
// sb.append(properties.getProperty("moyouTips"));
// }
//
// }
//
// };
//
// // 轻众筹App查询
// final Thread threadQingzhongchou = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("qingzhongchouUrl"),
//
// properties.getProperty("qingzhongchouParam") + phone
// + properties.getProperty("qingzhongchouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("qingzhongchouAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("errorMsg")
//
// .equals(properties.getProperty("qingzhongchouRegMsg"))) {
// sb.append(properties.getProperty("qingzhongchouTips"));
// }
//
// }
//
// };
// // HighingApp查询
// final Thread threadHighing = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("HighingUrl"),
//
// properties.getProperty("HighingParam") + phone
// + properties.getProperty("HighingOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("HighingAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("state")
//
// .equals(Integer.parseInt(properties.getProperty("HighingRegMsg")))) {
// sb.append(properties.getProperty("HighingTips"));
// }
//
// }
//
// };
// // 陌邻App查询
// final Thread threadMouling = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("moulingUrl"),
//
// properties.getProperty("moulingParam") + phone
// + properties.getProperty("moulingOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("moulingAttr"));
//
// if (!JSONObject
// .fromObject(map.toString().substring(map.toString().indexOf("{\""),
// map.toString().lastIndexOf(",")))
// .get("message").equals(properties.getProperty("moulingRegMsg"))) {
// sb.append(properties.getProperty("moulingTips"));
// }
//
// }
//
// };
// // 一说App查询
// final Thread threadYishuo = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yishuoUrl"),
//
// properties.getProperty("yishuoParam") + phone,
//
// queryPhoneSetAttr, properties.getProperty("yishuoAttr"));
//
// if (!JSONObject
// .fromObject(map.toString().substring(map.toString().indexOf("{\""),
// map.toString().lastIndexOf(",")))
// .get("msg").equals(properties.getProperty("yishuoRegMsg"))) {
// sb.append(properties.getProperty("yishuoTips"));
// }
//
// }
//
// };
//
// // 微微App查询
// final Thread threadWeiwei = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("weiweiUrl"),
//
// properties.getProperty("weiweiParam") + phone +
/// properties.getProperty("weiweiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("weiweiAttr"));
//
// if (!map.toString()
// .substring(map.toString().lastIndexOf("<error>") + 7,
// map.toString().lastIndexOf("</error>"))
// .equals(properties.getProperty("weiweiRegMsg"))) {
// sb.append(properties.getProperty("weiweiTips"));
// }
//
// }
//
// };
// // 美缘网App查询
// final Thread threadMeiyuanwang = new Thread() {
//
// public void run() {
//
// String str =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("meiyuanwangUrl"),
//
// "username=15924179757&password=879227577&fromsys=7");
// if (!JSONObject.fromObject(str).get("return_content")
// .equals(properties.getProperty("meiyuanwangRegMsg"))) {
// sb.append(properties.getProperty("meiyuanwangTips"));
// }
//
// }
//
// };
//
// // 到喜啦App查询
// final Thread threadDaoxila = new Thread() {
//
// public void run() {
// String map1 =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("daoxilaUrl"),
//
// properties.getProperty("daoxilaParam") + phone
// + properties.getProperty("daoxilaOtherParam"));
// if (!JSONObject.fromObject(
// map1.toString().substring(map1.toString().indexOf("{\""),
/// map1.toString().lastIndexOf(")")))
// .get("msg")
//
// .equals(properties.getProperty("daoxilaRegMsg"))) {
// sb.append(properties.getProperty("daoxilaTips"));
// }
//
// }
//
// };
// // 朋友印象App查询
// final Thread threadPengyouyingxiang = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("pengyouyingxiangUrl"),
//
// properties.getProperty("pengyouyingxiangParam") + phone
// + properties.getProperty("pengyouyingxiangOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("pengyouyingxiangAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("message")
//
// .equals(properties.getProperty("pengyouyingxiangRegMsg"))) {
// sb.append(properties.getProperty("pengyouyingxiangTips"));
// }
//
// }
//
// };
// // 实名相亲App查询
// final Thread threadShimingxiangqin = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("shimingxiangqinUrl"),
//
// properties.getProperty("shimingxiangqinParam") + phone
// + properties.getProperty("shimingxiangqinOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("shimingxiangqinAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("Message")
//
// .equals(properties.getProperty("shimingxiangqinRegMsg"))) {
// sb.append(properties.getProperty("shimingxiangqinTips"));
// }
//
// }
//
// };
// // 黑白校园App查询
// final Thread threadHeibaixiaoyuan = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("heibaixiaoyuanUrl"),
//
// properties.getProperty("heibaixiaoyuanParam") + phone
// + properties.getProperty("heibaixiaoyuanOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("heibaixiaoyuanAttr"));
// String string2 = (String) JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("msg");
// System.out.println(string2);
// if (!string2.equals(properties.getProperty("heibaixiaoyuanRegMsg"))
// && !string2.equals(properties.getProperty("heibaixiaoyuanRegMsg1"))) {
// sb.append(properties.getProperty("heibaixiaoyuanTips"));
// }
//
// }
//
// };
// // 推友App查询
// final Thread threadTuiyou = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("tuiyouUrl"),
//
// properties.getProperty("tuiyouParam") + phone +
/// properties.getProperty("tuiyouOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("tuiyouAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("msg")
//
// .equals(properties.getProperty("tuiyouRegMsg"))) {
// sb.append(properties.getProperty("tuiyouTips"));
// }
//
// }
//
// };
// // 啧啧App查询
// final Thread threadZeze = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("zezeUrl"),
//
// properties.getProperty("zezeParam") + phone +
/// properties.getProperty("zezeOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("zezeAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("code")
//
// .equals(Integer.parseInt(properties.getProperty("zezeRegMsg")))) {
// sb.append(properties.getProperty("zezeTips"));
// }
//
// }
//
// };
//
// // 美呼App查询
// final Thread threadMeihu = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("meihuUrl"),
//
// properties.getProperty("meihuParam") + phone +
/// properties.getProperty("meihuOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("meihuAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("event")
//
// .equals(properties.getProperty("meihuRegMsg"))) {
// sb.append(properties.getProperty("meihuTips"));
// }
//
// }
//
// };
//
// // 压寨App查询
// final Thread threadYazhai = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("yazhaiUrl"),
//
// properties.getProperty("yazhaiParam") + phone +
/// properties.getProperty("yazhaiOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("yazhaiAttr"));
//
// if (!map.toString().substring(map.toString().indexOf("=") + 1,
/// map.toString().lastIndexOf(","))
// .equals(properties.getProperty("yazhaiRegMsg"))) {
// sb.append(properties.getProperty("yazhaiTips"));
// }
//
// }
//
// };
//
// // 火聊pp查询
// final Thread threadHuoliao = new Thread() {
//
// public void run() {
//
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("huoliaoUrl"),
//
// properties.getProperty("huoliaoParam") + phone
// + properties.getProperty("huoliaoOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("huoliaoAttr"));
//
// if
/// (!JSONObject.fromObject(map.toString().substring(map.toString().indexOf("={\"")
/// + 1,
// map.toString().lastIndexOf(","))).get("errorMsg")
//
// .equals(properties.getProperty("huoliaoRegMsg"))) {
// sb.append(properties.getProperty("huoliaoTips"));
// }
//
// }
//
// };
//
// // 嘤嘤App查询
// final Thread threadYingying = new Thread() {
//
// public void run() {
//
// String str =
/// QyeryPhoneByProxyIp.httpURLConnectionGET(properties.getProperty("yingyingUrl"),
//
// properties.getProperty("yingyingParam") + phone
// + properties.getProperty("yingyingOtherParam"));
//
// if
/// (!JSONObject.fromObject(str).get("code").equals(properties.getProperty("yingyingRegMsg")))
/// {
// sb.append(properties.getProperty("yingyingTips"));
// }
//
// }
//
// };
// // k歌房App查询
// final Thread threadKgefang = new Thread() {
//
// public void run() {
// QueryPhoneSetAttr queryPhoneSetAttr = new QueryPhoneSetAttrImpl();// 配置属性
// Map<String, String> map = null;
//
// map =
/// QyeryPhoneByProxyIp.httpURLConnectionPOST(properties.getProperty("kgefangUrl"),
//
// properties.getProperty("kgefangParam") + phone
// + properties.getProperty("kgefangOtherParam"),
//
// queryPhoneSetAttr, properties.getProperty("kgefangAttr"));
//
// if (!JSONObject.fromObject(
// map.toString().substring(map.toString().indexOf("{\""),
/// map.toString().lastIndexOf(",")))
// .get("msg")
//
// .equals(properties.getProperty("kgefangRegMsg"))) {
// sb.append(properties.getProperty("kgefangTips"));
// }
//
// }
//
// };
// //
/// App查询程序-------------------------------end----------------------------------------
// // 判断标志
// boolean flag = true;
// // 前台展示的结果
// final JSONObject jsonObject = new JSONObject();
//
// // 主线程进行返回查询任务
// Thread thread = new Thread() {
//
// public void run() {
// try {
// // 等待所有分线程都结束任务才返回结构
// threadTantan.join();
// threadYuedan.join();
// threadYouyue.join();
// threadJiqingyuehui.join();
// threadDanshenjiaoyou.join();
// threadXiangxiang.join();
// threadBolatu.join();
// // threadZuwo.join();
// // threadMeiliyue.join();
// threadMiyue.join();
// // threadWuwangwo.join();
// threadMetoo.join();
// // threadShijijiayuan.join();
// // threadPpyuyin.join();
// // threadJiqingailian.join();
// threadJiuxiumeinvzhibojian.join();
// threadLeyuanjiaoyou.join();
// threadMemeda.join();
// // threadSuiyu.join();
// threadYingyue.join();
// // threadBaihehunlian.join();
// threadjinriyouyue.join();
// threadJimomeinvyuehui.join();
// threadDuimian.join();
// // threadHuatian.join();
// threadYouwo.join();
// // threadYujian.join();
// // threadXianlangweibo.join();
// // threadLingai.join();
// threadChengrenzhimei.join();
// // threadZaixianqiuai.join();
// // threadAiba.join();
// threadBaobao.join();
// threadXingzhe.join();
// threadGanliao.join();
// threadZhenqiao.join();
// threadDouban.join();
// // threadLunjiu.join();
// threadAizhenxin.join();
// threadTongchengjiaoyoujianjian.join();
// threadZANK.join();
// threadLiujianfangxiuchang.join();
// threadChuyeyue.join();
// threadYuanlaihunlian.join();
// threadBaihe.join();
// thread58jiaoyou.join();
// threadHongniang.join();
// threadShaige.join();
// threadWozaizhaoni.join();
// threadZhongguohongniangwang.join();
// threadRuoling.join();
// threadCaime.join();
// threadYuehuishuo.join();
// threadYuihuiba.join();
// threadDouxiuhaipi.join();
// threadYouxunjiaoyou.join();
// threadRenmaitong.join();
// threadYuepengtongchengjiaoyou.join();
// threadJimodanshenyuehui.join();
// threadLianlian.join();
// threadLiangmian.join();
// threadTutu.join();
// threadZhaodaota.join();
// threadJianjian.join();
// threadQinqin.join();
// threadMoyou.join();
// // threadQingzhongchou.join();
// threadMouling.join();
// threadYishuo.join();
// threadWeiwei.join();
// threadMeiyuanwang.join();
// threadDaoxila.join();
// threadPengyouyingxiang.join();
// threadHeibaixiaoyuan.join();
// threadTuiyou.join();
// threadZeze.join();
// threadMeihu.join();
// threadYazhai.join();
// threadHuoliao.join();
// threadYingying.join();
// threadHighing.join();
// threadShimingxiangqin.join();
// threadKgefang.join();
// sb.append(properties.getProperty("RegEndTips"));
// // 设置到前台的查询App结果
// setAttr("findResult", sb.toString());
//
// jsonObject.put("check", "true");
// jsonObject.put("result", sb.toString());
//
// } catch (Exception e) {
// logger.warn("多线程阻塞出错:" + e.getMessage());
// }
// }
// };
//
// // 启动程查询
// threadTantan.start();
// threadYuedan.start();
// threadYouyue.start();
// threadJiqingyuehui.start();
// threadDanshenjiaoyou.start();
// threadXiangxiang.start();
// threadBolatu.start();
// // threadZuwo.start();
// // threadMeiliyue.start();
// threadMiyue.start();
// // threadWuwangwo.start();
// threadMetoo.start();
// // threadShijijiayuan.start();
// // threadPpyuyin.start();
// // threadJiqingailian.start();
// threadJiuxiumeinvzhibojian.start();
// threadLeyuanjiaoyou.start();
// threadMemeda.start();
// // threadSuiyu.start();
// threadYingyue.start();
// // threadBaihehunlian.start();
// threadjinriyouyue.start();
// threadJimomeinvyuehui.start();
// threadDuimian.start();
// // threadHuatian.start();
// threadYouwo.start();
// // threadYujian.start();
// // threadXianlangweibo.start();
// // threadLingai.start();
// threadChengrenzhimei.start();
// // threadZaixianqiuai.start();
// // threadAiba.start();
// threadBaobao.start();
// threadXingzhe.start();
// threadGanliao.start();
// threadZhenqiao.start();
// threadDouban.start();
// // threadLunjiu.start();
// threadAizhenxin.start();
// threadTongchengjiaoyoujianjian.start();
// threadZANK.start();
// threadLiujianfangxiuchang.start();
// threadChuyeyue.start();
// threadYuanlaihunlian.start();
// threadBaihe.start();
// thread58jiaoyou.start();
// threadHongniang.start();
// threadShaige.start();
// threadWozaizhaoni.start();
// threadZhongguohongniangwang.start();
// threadRuoling.start();
// threadCaime.start();
// threadYuehuishuo.start();
// threadYuihuiba.start();
// threadDouxiuhaipi.start();
// threadYouxunjiaoyou.start();
// threadRenmaitong.start();
// threadYuepengtongchengjiaoyou.start();
// threadJimodanshenyuehui.start();
// threadLianlian.start();
// threadLiangmian.start();
// threadTutu.start();
// threadZhaodaota.start();
// threadJianjian.start();
// threadQinqin.start();
// threadMoyou.start();
// // threadQingzhongchou.start();
// threadMouling.start();
// threadYishuo.start();
// threadWeiwei.start();
// threadMeiyuanwang.start();
// threadDaoxila.start();
// threadPengyouyingxiang.start();
// threadHeibaixiaoyuan.start();
// threadTuiyou.start();
// threadZeze.start();
// threadMeihu.start();
// threadYazhai.start();
// threadHuoliao.start();
// threadYingying.start();
// threadHighing.start();
// threadShimingxiangqin.start();
// threadKgefang.start();
// // 主线程
// thread.start();
//
// // 循环判断程序，不让他走出去
// while (flag) {
// // 阻塞一会
// Thread.sleep(4000);
// if (!thread.isAlive()) {
// flag = false;
// }
// }
//
// // 新增单线程测试
// sb.append(properties.getProperty("RegEndTips"));
// // 设置到前台的查询App结果
// setAttr("findResult", sb.toString());
//
// jsonObject.put("check", "true");
// jsonObject.put("result", sb.toString());
//
// // 返回到前台
// // 返回到查询界面
// renderJson(jsonObject.toString());
//
// return;
//
// } catch (
//
// Exception e)
//
// {
// logger.warn("寻找手机加载配置出错:" + e.getMessage());
// }
//
// }
//
// /**
// * 管理员界面
// *
// * @param
// * @return
// */
// public void admin() {
//
// // 省略直接访问对应页面
// // 建立上传cookies
// setCookie("success", Key.init(), 60 * 30);
// }
//
// /**
// * 管理员登录成功
// *
// * @param
// * @return
// */
//
// public void adminLogin() {
//
// try {
//
// String adminName = getPara("adminName", "").trim();
// String adminPassword = getPara("adminPassword", "").trim();
// // 读取管理员上传的配置文件
// Properties properties = new Properties();
// String webUrl = System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\admin.properties";
// properties.load(new BufferedReader(new InputStreamReader(new
/// FileInputStream(webUrl), "utf-8")));
// // 读取密钥配件
// Properties propertiesKey = new Properties();
// String keyUrl = System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\defaultAdmin.properties";
// propertiesKey.load(new BufferedReader(new InputStreamReader(new
/// FileInputStream(keyUrl), "utf-8")));
// String key = propertiesKey.getProperty("adminKey");
// if
/// (properties.getProperty("adminName").trim().equals(DesUtil.encrypt(adminName,
/// key))
// &&
/// properties.getProperty("adminPassword").trim().equals(DesUtil.encrypt(adminPassword,
/// key))) {
// // 设置密码正确的时候session
// // 判断是否用户是否禁止了Cookie
// if (getCookie("success") == null) {
// // 手动设置一个cookie模拟客户端有cookie的登录
// // HttpClient模拟Get的方式登录
// // // 目标地址
// // HttpGet httpget = new HttpGet(
// // propertiesKey.getProperty("defaultCookieLoginUrl"));
// // // 更新Key生成出不唯一的cookie
// // String cookie = Key.init();
// // httpget.setHeader("Cookie", "JSESSIONID=" + cookie
// // + "; defaultCookie=" + cookie + "");
// //
// //
// // // 并把钥匙设置到缺省配置文件中方便上传文件时候进行读取匹配
// // Properties propertiesCookie = new Properties();
// // OutputStream out = new FileOutputStream(
// // System.getProperty("user.dir")
// // + "\\WebRoot\\properties\\defaultCookie\\defaultCookie"
// // + getAttr("realIp") + ".properties");
// // propertiesCookie.setProperty("defaultCookie", cookie);
// // propertiesCookie.setProperty("defaultMillsecond",
// // propertiesKey.getProperty("defaultMillsecond"));
// // propertiesCookie.store(out, "author: xiaoluo");
// // out.close();
// // // 使用DefaultHttpClient类的execute方法发送HTTP
// // // GET请求，并返回HttpResponse对象。
// // HttpResponse response = new DefaultHttpClient()
// // .execute(httpget);// 其中HttpGet是HttpUriRequst的子类
// // // 返回状态是OK的话讲输入流输出
//
// // HttpClient模拟POST的方式登录
// // 目标地址
// HttpPost httpPost = new
/// HttpPost(propertiesKey.getProperty("defaultCookieLoginUrl"));
// // 更新Key生成出不唯一的cookie
// String cookie = Key.init();
// httpPost.setHeader("Cookie", "JSESSIONID=" + cookie + "; defaultCookie=" +
/// cookie + "");
// // 并把钥匙设置到缺省配置文件中方便上传文件时候进行读取匹配
// Properties propertiesCookie = new Properties();
// OutputStream out = new FileOutputStream(
// System.getProperty("user.dir") +
/// "\\WebRoot\\properties\\defaultCookie\\defaultCookie"
// + getAttr("realIp") + ".properties");
// propertiesCookie.setProperty("defaultCookie", cookie);
// propertiesCookie.setProperty("defaultMillsecond",
/// propertiesKey.getProperty("defaultMillsecond"));
// propertiesCookie.store(out, "author: xiaoluo");
// out.close();
// // 模拟客户前把当前的Ip存入到输入流文件中，方便读取
// List<NameValuePair> params = new ArrayList<NameValuePair>();
// params.add(new BasicNameValuePair("realIp", (String) getAttr("realIp")));
// httpPost.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
// // 使用DefaultHttpClient类的execute方法发送HTTP
// // POST请求，并返回HttpResponse对象。
// HttpResponse response = new DefaultHttpClient().execute(httpPost);
// if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
// String result = EntityUtils.toString(response.getEntity());
// // 写入文件，让用户看到该文件
// BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(
// new FileOutputStream(System.getProperty("user.dir") + "\\WebRoot\\index\\"
// + propertiesKey.getProperty("defaultCookieFile") + ""),
// "utf-8"));
// bufferedWriter.write(result);
// bufferedWriter.close();
// renderFreeMarker(propertiesKey.getProperty("defaultCookieFile"));
// } else {
// setAttr("adminErrorMsg", "网络连接失败!!");
// renderFreeMarker("admin.html");
// }
//
// return;
//
// }
//
// setSessionAttr("adminSuccess", getCookie("success", "success"));
//
// renderFreeMarker("uploadProterties.html");
// } else {
// setAttr("adminErrorMsg", "用户或密码不正确!!");
// renderFreeMarker("admin.html");
// }
//
// } catch (Exception e) {
// logger.warn("管理员登录失败:" + e.getMessage());
// }
// }
//
// /**
// * 管理员上传配置文件
// *
// * @param
// * @return
// */
// @Clear(QueryPhoneGlobalInterceptor.class)
// // 清除全局拦截
// @Before(QueryPhoneValidator.class)
// public void uploadFile() {
//
// try {
//
// // 文件的移动和删除
// // 获得总配置文件目录
// String baseUrl = System.getProperty("user.dir") + "\\WebRoot\\";
// // 获得上传的配置文件
// File uploadFilePath = new File(baseUrl + "download\\");
// File[] uploadFiles = uploadFilePath.listFiles();
// // 获得本地的配置文件
// File localFilePath = new File(baseUrl + "properties\\");
// File[] localFiles = localFilePath.listFiles();
//
// for (File uploadFile : uploadFiles) {
// for (File localFile : localFiles) {
// // 对于存在的文件进行替换
// if (localFile.getName().equals(uploadFile.getName())) {
//
// // 创建输入流进行读取上传的文件
// BufferedReader bf = new BufferedReader(
// new InputStreamReader(new FileInputStream(uploadFile), "utf-8"));
// // 创建输出流对文件进行存储本地
// BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
// new FileOutputStream(
// new File(baseUrl + "properties" + File.separator + uploadFile.getName())),
// "utf-8"));
// // 创建字节进行读取
// String len = "";
// while ((len = bf.readLine()) != null) {
// bw.write(len);
// // 换行
// bw.write("\n");
//
// }
// bw.flush();
// bf.close();
// bw.close();
// break;
// }
//
// }
// // 删除上传的文件--包括其他文件
// uploadFile.delete();
// }
// // 上传成功调到上传页面
// setAttr("uploadMsg", "上传配置文件成功!!!");
// renderFreeMarker("uploadProterties.html");
//
// // 没有cookies情况下删除cookies文件
// if ("true".equals(getAttr("deleteCookie"))) {
// // 调用两个线程，一个关闭流减少客户等待删除文件指令(防止用户多次上传文件和黑客盗取频繁上传问题)
// // 线程1--关闭流
// Runnable runnable = new Runnable() {
//
// @Override
// public void run() {
// // 关闭流
// return;
//
// }
// };
//
// // 线程2--删除文件
// Thread threadDeleteCookie = new Thread() {
// public void run() {
// // 读取管理员登录成功存入文件的cookie密钥
// Properties propertiesCookie = new Properties();
// final String cookieUrl = System.getProperty("user.dir")
// + "\\WebRoot\\properties\\defaultCookie\\defaultCookie" + getAttr("realIp")
// + ".properties";
//
// try {
// // 装载配置文件
// propertiesCookie.load(
// new BufferedReader(new InputStreamReader(new FileInputStream(cookieUrl),
/// "utf-8")));
// // 获得定时时间长
// String timeStr = propertiesCookie.getProperty("defaultMillsecond");
// Integer waitTime = Integer.parseInt(timeStr.matches("\\d+") ? timeStr :
/// "6000");
// // 启动定时任务
// Thread.sleep(waitTime);
// } catch (Exception e) {
// logger.warn("defaultCookie文件删除失败：" + e.getMessage());
// return;
// }
//
// // 读取存取cookie的文件
// File file = new File(cookieUrl);
// if (file.exists()) {
// System.gc();
// // 删除存取cookie的文件
// file.delete();
//
// }
//
// }
// };
// // 关闭守护线程模式
// threadDeleteCookie.setDaemon(false);
// // 线程1加载和启动
// Thread threadClose = new Thread(runnable);
// threadClose.start();
// // 线程2启动
// threadDeleteCookie.start();
// }
// } catch (Exception e) {
// logger.warn("配置文件上传出错：" + e.getMessage());
//
// }
//
// }
//
// /**
// * 在线加密
// *
// * @param
// * @return
// */
// @Before(QueryPhoneInterceptor.class)
// public void onlineEncyrt() {
//
// String encrypt = getPara("encrypt", "").trim();
// String decrypt = getPara("decrypt", "").trim();
// String submit = getPara("submit", "").trim();
// // 查询返回的信息
// String msg = "";
// // 查询密钥
// String key = "";
//
// if ("".equals(encrypt) && "".equals(decrypt)) {
//
// } else if ("".equals(encrypt)) {
// key = decrypt.indexOf(" ") == -1 ? "" : decrypt == "" ? "" : decrypt.split("
/// ")[1];
// } else if ("".equals(decrypt)) {
// key = encrypt.indexOf(" ") == -1 ? "" : encrypt == "" ? "" : encrypt.split("
/// ")[1];
//
// } else {
// // 其他捣乱情况
//
// }
//
// if (key == "" || key.length() < 8) {
// setAttr("keyMsg", "您输入的密钥长度太短了，请重新输入!!");
// renderFreeMarker("onlineEncrypt.html");
// return;
// }
//
// try {
// // 加密
// if ("encrypt".equals(DesEnum.getEnumValue(submit))) {
// msg = DesUtil.encrypt(encrypt.split(" ")[0], key);
// // 返回查询结果
// setAttr("encryptresult", msg);
// } else {
// msg = DesUtil.decrypt(decrypt.split(" ")[0], key);
// // 返回查询结果
// setAttr("decryptresult", msg);
//
// }
// // 判断查询是否失败
// if ("".equals(msg)) {
//
// setAttr("keyMsg", "查询结果失败，请核对密钥是否正确！");
//
// }
// renderFreeMarker("onlineEncrypt.html");
//
// } catch (Exception e) {
//
// logger.warn(DesEnum.getEnumValue(submit) + "出错：" + e.getMessage());
//
// }
// }
//
// /**
// * 利用手机找回密码登录
// *
// * @param
// * @return
// */
// public void phoneReg() {
// String phone = getPara("phone", "").trim();
// // 保存上次提交的数据--登录所填的数
// setAttr("phone", phone);
// }
//
// /**
// * 利用手机找回密码验证码
// *
// * @param
// * @return
// */
// public void phoneCheck() {
//
// // 获得异步发送过来的手机参数
// try {
// String phone = getPara("phone", "").trim();
// // 发送Json
// JSONObject jsonObject = new JSONObject();
// // 验证手机是否是空
// if ("".equals(phone)) {
// // 手机号不能为空
// jsonObject.put("remark", "empty");
// renderJson(jsonObject.toString());
// return;
// }
// // 生产6位随机数
// String num = "";
// for (int i = 0; i < 6; i++) {
// num += String.valueOf(((int) (Math.random() * 10)));
// }
// // 发送邮箱验证
// String sendRemark = "";
// // 判断手机属于哪个公司
// if (phone.matches("1(3[4-9]|5[012789]|47|8[234789])\\d{8}")) {
// sendRemark = EmailSendUtil.send(num, num, phone + "@139.com", "author",
/// null);
// } else if (phone.matches("1(3[0-2]|5[56]|8[56]|4[5]|7[6])\\d{8}")) {
// sendRemark = EmailSendUtil.send(num, num, phone + "@wo.cn", "author", null);
// } else if (phone.matches("^1(3[3]|8[019]|53)\\d{8}")) {
// sendRemark = EmailSendUtil.send(num, num, phone + "@189.cn", "author", null);
// } else {
// // 手机号填写错误
// jsonObject.put("remark", "error");
// renderJson(jsonObject.toString());
// return;
//
// }
//
// if (sendRemark != null) {
// // 先查询是否存在该手机号
// List<Record> list = Db.find("select * from queryphone where userPhone= ?",
/// phone);
// if (list != null && list.size() != 0) {
// // 存取验证码到原来的手机号
// Db.update("update queryphone set regSign=? where userPhone=?", num, phone);
// } else {
// // 存取新的手机号
// Record record = new Record();
// record.set("userPhone", phone);
// record.set("regSign", num);
// Db.save("queryphone", record);
// }
// logger.debug(num);
// jsonObject.put("remark", "true");
// renderJson(jsonObject.toString());
// } else {
//
// jsonObject.put("remark", "false");
// renderJson(jsonObject.toString());
// }
// } catch (Exception e) {
// logger.warn("验证码使用失败:" + e.getMessage());
// }
//
// }
//
// /**
// * 利用手机找回密码存储
// *
// * @param
// * @return
// */
// public void savePass() {
// // 获得手机号
// try {
// String phone = getPara("phone", "").trim();
//
// // 验证手机是否是空
// if ("".equals(phone)) {
// // 手机号不能为空
// setAttr("errorReg", "手机号不能为空!");
// renderFreeMarker("phoneReg.html");
// return;
// }
// // 获取前台传过来的验证码
// String checkParam = getPara("numParam", "").trim();
// // 查询该手机存取的验证码
// List<Record> list = Db.find("select regSign from queryphone where
/// userPhone=?", phone);
// if (list != null) {
// // 获得数据库注册的验证码
// String regSign = list.get(0).getStr("regSign");
// if (regSign.equals(checkParam)) {
// // 存储密码
// int infectNum = Db.update("update queryphone set userPassword=? where
/// userPhone=?",
// getPara("pass"), phone);
// if (infectNum == 1) {
// forwardAction("/init");
// return;
// } else {
// setAttr("errorReg", "找回失败，请刷新重试!!");
// renderFreeMarker("phoneReg.html");
// return;
// }
// } else {
//
// // 保存上次提交的数据
// setAttr("phone", phone);
// setAttr("errorReg", "您输入的验证码错误!!");
// renderFreeMarker("phoneReg.html");
// return;
// }
// }
// } catch (Exception e) {
// logger.warn("找回密码出错:" + e.getMessage());
// }
// }
//
// public static void main(String[] args) {
//
// // // 获得异步发送过来的手机参数
// // String phone = "15924179757";
// // // 验证手机是否是空
// // if ("".equals(phone)) {
// // // 等待补充参数
// // return;
// // }
// // // 生产6位随机数
// // String num = "";
// // for (int i = 0; i < 7; i++) {
// // num += String.valueOf(((int) (Math.random() * 10)));
// // }
// //
// // // 发送邮箱验证
// // String sendRemark = EmailSendUtil.send(num, num,
// // "15924179757@139.com", "author", null);
// //
// // logger.debug(sendRemark);
// // 多线程处理问题
// /*
// * boolean flag = true;
// *
// * Thread thread = new Thread() {
// *
// * public void run() { try {
// *
// * Thread.sleep(6000); System.out.println("中间");
// *
// * } catch (InterruptedException e) { // TODO Auto-generated catch block
// * e.printStackTrace(); } } }; thread.start();
// *
// * while (flag) { try { Thread.sleep(2000); } catch
// * (InterruptedException e) { // TODO Auto-generated catch block
// * e.printStackTrace(); } System.err.println("开始"); if
// * (!thread.isAlive()) { flag = false; } }
// * System.out.println("-----------------结束-------------------------");
// */
// }
// }
