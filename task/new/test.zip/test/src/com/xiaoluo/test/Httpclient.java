/**
 * 
 */
package com.xiaoluo.test;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: Httpclient.java, 2015年12月3日 下午11:53:21   
 */

public class Httpclient {

}
