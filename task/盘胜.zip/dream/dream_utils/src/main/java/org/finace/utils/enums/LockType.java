package org.finace.utils.enums;

/**
 * 加锁的类型
 * Created by Ness on 2017/1/9.
 */
public enum LockType {
    ORDER_NUMBER_LOCK("order_number_lock"), USER_ACCOUNT_LOCK("user_account_lock"),MERCH_STOCK_LOCK("merch_stock_lock"),
    PAY_RESULT_LOCK("pay_result_lock"),SHOP_CART_LOCK("shop_cart_lock"),ADDRESS_ADD_LOCK("address_add_lock");
    private String key;

    LockType(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

}
