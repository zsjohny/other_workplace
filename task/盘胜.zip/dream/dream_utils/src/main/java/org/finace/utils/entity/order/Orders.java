package org.finace.utils.entity.order;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonManagedReference;

/**
 * order实体类
 * Created by ChuLiang on 2016/12/16.
 */
@Entity
@Table(name = "orders")
public class Orders {
	/**
	 * mongodb ids
	 */
//	@org.springframework.data.annotation.Id
//	private String ids;
	
    private Integer id;


    private String uuid;
    

    private Double totalPrice;
    
    private String orderNo;
    
    /**    
     * 创建时间
     */
    private Timestamp createTime;

    /**
     * 修改时间
     */
    
    private Timestamp updateTime;


    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;
    
    private String orderMessage;
    
    private Integer status;
    
    private String userUuid;
    
    private String deletedPersonUuid;
    
    private String merchandiserUuid;
    
    private String merchandiserName;
    
    private Boolean isFlashSale;
    
    private Boolean isAnonymous;
    
    private Boolean isFromCart;
    
    private String reCheckId;
    
    private String updatePersonUuid;
    
    private String diliveryCompanyNo;
    
    private String deliveryNo;
    
    private String receiveAddressDetail;
    
    private List <OrderMerch> omlist;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
    public Integer getId() {
        return id;
    }
   
	public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public String getDeletedPersonUuid() {
		return deletedPersonUuid;
	}

	public void setDeletedPersonUuid(String deletedPersonUuid) {
		this.deletedPersonUuid = deletedPersonUuid;
	}

	public Orders(){
	}
	
	
	
	public String getReceiveAddressDetail() {
		return receiveAddressDetail;
	}

	public void setReceiveAddressDetail(String receiveAddressDetail) {
		this.receiveAddressDetail = receiveAddressDetail;
	}
	@OneToMany(mappedBy="singleOrder",fetch=FetchType.EAGER)
	public List<OrderMerch> getOmlist() {
		return omlist;
	}

	public void setOmlist(List<OrderMerch> omlist) {
		this.omlist = omlist;
	}
	

	public String getMerchandiserUuid() {
		return merchandiserUuid;
	}

	public void setMerchandiserUuid(String merchandiserUuid) {
		this.merchandiserUuid = merchandiserUuid;
	}

	public String getMerchandiserName() {
		return merchandiserName;
	}
	

	public void setMerchandiserName(String merchandiserName) {
		this.merchandiserName = merchandiserName;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public Boolean getIsFlashSale() {
		return isFlashSale;
	}

	public void setIsFlashSale(Boolean isFlashSale) {
		this.isFlashSale = isFlashSale;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOrderMessage() {
		return orderMessage;
	}

	public void setOrderMessage(String orderMessage) {
		this.orderMessage = orderMessage;
	}

	public Boolean getIsAnonymous() {
		return isAnonymous;
	}

	public void setIsAnonymous(Boolean isAnonymous) {
		this.isAnonymous = isAnonymous;
	}

	public Boolean getIsFromCart() {
		return isFromCart;
	}

	public void setIsFromCart(Boolean isFromCart) {
		this.isFromCart = isFromCart;
	}

	public String getReCheckId() {
		return reCheckId;
	}

	public void setReCheckId(String reCheckId) {
		this.reCheckId = reCheckId;
	}

	public String getUpdatePersonUuid() {
		return updatePersonUuid;
	}

	public void setUpdatePersonUuid(String updatePersonUuid) {
		this.updatePersonUuid = updatePersonUuid;
	}

	public String getDiliveryCompanyNo() {
		return diliveryCompanyNo;
	}

	public void setDiliveryCompanyNo(String diliveryCompanyNo) {
		this.diliveryCompanyNo = diliveryCompanyNo;
	}

	public String getDeliveryNo() {
		return deliveryNo;
	}

	public void setDeliveryNo(String deliveryNo) {
		this.deliveryNo = deliveryNo;
	}


	
	

	
    
}
