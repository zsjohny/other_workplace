package org.finace.utils.enums;

/**
 * 定时任务的key类型
 * Created by Ness on 2016/12/26.
 */
public enum TimerTaskNameType {
    MERCHANDISE_AUTO_PPURCASE("merchandise_auto_ppurcase"),ORDER_AUTO_INVALID("order_auto_invalid"),ORDER_COUNT_PAYMENT("order_count_payment");
    private String key;

    TimerTaskNameType(String key) {
        this.key = key;
    }

    public String getName() {
        return key;
    }


}
