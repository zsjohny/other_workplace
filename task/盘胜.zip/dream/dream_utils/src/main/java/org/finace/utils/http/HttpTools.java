package org.finace.utils.http;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.HtmlEmail;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.finace.utils.Regular.Regular;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import java.io.*;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import static org.finace.utils.Regular.Regular.checkEmpty;
import static org.finace.utils.Regular.Regular.checkUrl;


/**
 * 链接访问工具类
 */
public class HttpTools {
    private static Logger logger = LoggerFactory.getLogger(HttpTools.class);
    private static String REMOVE_HEARDR = "Transfer-Encoding";

    /**
     * get请求访问
     *
     * @param url    访问链接
     * @param params 访问参数
     * @return
     */
    public static String doGet(String url, String params) {

        String result = "";
        try {


            //检测网址和参数
//            if (!checkUrl(url) || checkEmpty(params, null)) {
//                return result;
//            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpGet get = new HttpGet(url + "?" + params);

            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * post请求访问
     *
     * @param url    访问链接
     * @param params 访问参数
     * @return
     */
    public static String doPost(String url, Map<String, Object> params) {


        String result = "";
        try {

            //检测网址和参数

            if (!checkUrl(url) || checkEmpty(params, null)) {
                return result;
            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpPost post = new HttpPost(url);
            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * head模拟get请求访问
     *
     * @param url     访问链接
     * @param params  访问参数
     * @param headers head访问数组
     * @return
     */
    public static String doGet(String url, String params, Header[] headers) {

        String result = "";
        try {


            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0) {
                return result;
            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpGet get = new HttpGet(url + "?" + params);
            get.setHeaders(headers);
            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * head模拟post请求访问
     *
     * @param url     访问链接
     * @param params  访问参数
     * @param headers head访问数组
     * @return
     */
    public static String doPost(String url, Map<String, Object> params, Header[] headers) {


        String result = "";
        try {

            //检测网址和参数

            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0) {
                return result;
            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpPost post = new HttpPost(url);
            post.setHeaders(headers);
            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }


    /**
     * 保持会话持续get请求访问--自定义head进行初次访问
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param headers   head访问数组
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doGet(String url, String params, Header[] headers, String dialogKey) {

        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0 || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpGet get = new HttpGet(url + "?" + params);
            get.setHeaders(headers);
            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);

            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }


    /**
     * 保持会话持续get请求访问
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doGet(String url, String params, String dialogKey) {

        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpGet get = new HttpGet(url + "?" + params);
            Header[] headers = dialogKeepMap.get(dialogKey);
            if (headers != null && headers.length != 0) {
                get.setHeaders(headers);
            }

            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);

            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }


    /**
     * 保持会话持续post请求访问
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doPost(String url, Map<String, Object> params, String dialogKey) {


        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }


            HttpClient httpClient = HttpClients.createDefault();
            HttpPost post = new HttpPost(url);
            Header[] headers = dialogKeepMap.get(dialogKey);
            if (headers != null && headers.length != 0) {
                post.setHeaders(headers);
            }
            ;
            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * 保持会话持续post请求访问--自定义head进行初次访问
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param headers   head访问数组
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doPost(String url, Map<String, Object> params, Header[] headers, String dialogKey) {


        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0 || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }

            HttpClient httpClient = HttpClients.createDefault();
            HttpPost post = new HttpPost(url);
            post.setHeaders(headers);
            ;
            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }


    private static Properties properties;

    static {
        properties = new Properties();
        InputStreamReader isr = null;
        try {
            isr = new InputStreamReader(HttpTools.class.getClassLoader().getResourceAsStream("defaultLink.properties"), "utf-8");
            properties.load(isr);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (isr != null) {
                try {
                    isr.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static Boolean sendReport(String email, String msg) {
        Boolean flag = false;
        try {
            logger.info("邮箱={},报告={},开始发送", email, msg);
            HtmlEmail htmlEmail = new HtmlEmail();
            htmlEmail.setHostName(properties.getProperty("email.host"));
            htmlEmail.setCharset("utf-8");
            htmlEmail.setFrom(
                    properties.getProperty("email.sender"), properties.getProperty("email.content"));
            htmlEmail.addTo(email, "", properties.getProperty("email.sender"));
            htmlEmail.setSubject(properties.getProperty("email.sendContent"));
            htmlEmail.setAuthenticator(new DefaultAuthenticator(properties.getProperty("email.name"), properties.getProperty("email.pass")));
            htmlEmail.setMsg(msg);
            htmlEmail.send();
            flag = true;
            logger.info("邮箱={},报告={},结束发送", email, msg);
        } catch (Exception e) {
            logger.warn("邮箱={},报告={},访问出错", email, msg, e);
        }
        return flag;
    }

    /**
     * get请求访问--https
     *
     * @param url    访问链接
     * @param params 访问参数
     * @return
     */
    public static String doGets(String url, String params) {

        String result = "";
        try {


            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null)) {
                return result;
            }


            HttpClient httpClient = HttpsClient();
            HttpGet get = new HttpGet(url + "?" + params);

            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * post请求访问---https
     *
     * @param url    访问链接
     * @param params 访问参数
     * @return
     */
    public static String doPosts(String url, Map<String, Object> params) {


        String result = "";
        try {

            //检测网址和参数

            if (!checkUrl(url) || checkEmpty(params, null)) {
                return result;
            }


            HttpClient httpClient = HttpsClient();
            HttpPost post = new HttpPost(url);
            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * head模拟get请求访问---https
     *
     * @param url     访问链接
     * @param params  访问参数
     * @param headers head访问数组
     * @return
     */
    public static String doGets(String url, String params, Header[] headers) {

        String result = "";
        try {


            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0) {
                return result;
            }


            HttpClient httpClient = HttpsClient();
            HttpGet get = new HttpGet(url + "?" + params);
            get.setHeaders(headers);
            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * head模拟post请求访问---https
     *
     * @param url     访问链接
     * @param params  访问参数
     * @param headers head访问数组
     * @return
     */
    public static String doPosts(String url, Map<String, Object> params, Header[] headers) {


        String result = "";
        try {

            //检测网址和参数

            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0) {
                return result;
            }


            HttpClient httpClient = HttpsClient();
            HttpPost post = new HttpPost(url);
            post.setHeaders(headers);
            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    private static ConcurrentHashMap<String, Header[]> dialogKeepMap = new ConcurrentHashMap<>();

    /**
     * 保存所有head
     *
     * @param response  返回的http
     * @param dialogKey 对话的key
     */
    private static void saveHead(HttpResponse response, String dialogKey) {
        response.removeHeaders(REMOVE_HEARDR);
        Header[] headers = response.getAllHeaders();
        dialogKeepMap.put(dialogKey, headers);
    }

    /**
     * 保持会话持续get请求访问---https
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doGets(String url, String params, String dialogKey) {

        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }


            HttpClient httpClient = HttpsClient();
            HttpGet get = new HttpGet(url + "?" + params);
            Header[] headers = dialogKeepMap.get(dialogKey);
            if (headers != null && headers.length != 0) {
                get.setHeaders(headers);
            }

            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * 保持会话持续get请求访问---https,自定义head进行初次访问
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param headers   head访问数组
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doGets(String url, String params, Header[] headers, String dialogKey) {

        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0 || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }


            HttpClient httpClient = HttpsClient();
            HttpGet get = new HttpGet(url + "?" + params);
            get.setHeaders(headers);
            HttpResponse response = httpClient.execute(get);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }


    /**
     * 保持会话持续post请求访问---https
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doPosts(String url, Map<String, Object> params, String dialogKey) {


        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }

            HttpClient httpClient = HttpsClient();
            HttpPost post = new HttpPost(url);
            Header[] headers = dialogKeepMap.get(dialogKey);
            if (headers != null && headers.length != 0) {
                post.setHeaders(headers);
            }


            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * 保持会话持续post请求访问---https,自定义head进行初次访问
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param headers   head访问数组
     * @param dialogKey 保持会话的key
     * @return
     */
    public static String doPosts(String url, Map<String, Object> params, Header[] headers, String dialogKey) {


        String result = "";
        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || headers == null || headers.length == 0 || Regular.checkEmpty(dialogKey, null)) {
                return result;
            }

            HttpClient httpClient = HttpsClient();
            HttpPost post = new HttpPost(url);
            post.setHeaders(headers);

            List<NameValuePair> list = new ArrayList<>();

            for (Map.Entry<String, Object> entry : params.entrySet()) {
                list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            HttpEntity entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));
            post.setEntity(entity);
            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
                saveHead(response, dialogKey);
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * 保持会话持续get请求访问下载--https
     *
     * @param url       访问链接
     * @param params    访问参数
     * @param dialogKey 保持会话的key
     * @return
     */
    public static File doFileGets(String url, String params, String dialogKey) {
        File file = null;

        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null) || Regular.checkEmpty(dialogKey, null)) {
                return file;
            }

            HttpClient httpClient = HttpsClient();
            HttpGet get = new HttpGet(url + "?" + params);
            Header[] headers = dialogKeepMap.get(dialogKey);
            if (headers != null && headers.length != 0) {
                get.setHeaders(headers);
            }

            HttpResponse response = httpClient.execute(get);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                file = File.createTempFile(String.valueOf(System.currentTimeMillis()), String.valueOf(System.currentTimeMillis()));
                try (InputStream is = response.getEntity().getContent();
                     OutputStream os = new FileOutputStream(file)) {
                    byte[] tempCache = new byte[1024];
                    int len = 0;
                    while ((len = is.read(tempCache)) != -1) {
                        os.write(tempCache, 0, len);
                    }
                    os.flush();
                }

            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return file;

    }

    /**
     * 保持会话持续get请求访问下载
     *
     * @param url    访问链接
     * @param params 访问参数
     * @return
     */
    public static File doFileGet(String url, String params) {
        File file = null;

        try {

            //检测网址和参数
            if (!checkUrl(url) || checkEmpty(params, null)) {
                return file;
            }

            HttpClient httpClient = HttpClients.createDefault();
            HttpGet get = new HttpGet(url + "?" + params);


            HttpResponse response = httpClient.execute(get);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                file = File.createTempFile(String.valueOf(System.currentTimeMillis()), String.valueOf(System.currentTimeMillis()));
                try (InputStream is = response.getEntity().getContent();
                     OutputStream os = new FileOutputStream(file)) {
                    byte[] tempCache = new byte[1024];
                    int len = 0;
                    while ((len = is.read(tempCache)) != -1) {
                        os.write(tempCache, 0, len);
                    }
                    os.flush();
                    EntityUtils.consume(response.getEntity());
                }

            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return file;

    }

    public static HttpClient HttpsClient() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        SSLContext sslContent = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
            @Override
            public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                return false;
            }

        }).build();
        return HttpClients.custom().setSSLContext(sslContent).build();

    }

    /**
     * post请求访问---https
     *
     * @param url    访问链接
     * @param params 访问参数
     * @return
     */
    public static String doPostsByStr(String url, String params) {


        String result = "";
        try {

            //检测网址和参数


            HttpClient httpClient = HttpsClient();
            HttpPost post = new HttpPost(url);


            post.setEntity(new StringEntity(params, "utf-8"));

            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, params, e);
        }
        return result;

    }

    /**
     * post的Json请求访问---https
     *
     * @param url  访问链接
     * @param json 访问参数
     * @return
     */
    public static String doPostsByJson(String url, String json) {


        String result = "";
        try {

            //检测网址和参数

            if (!checkUrl(url) || checkEmpty(json, null)) {
                return result;
            }

            HttpClient httpClient = HttpsClient();

            HttpPost post = new HttpPost(url);

            StringEntity entity = new StringEntity(json, "utf-8");
//            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            post.setEntity(entity);

            HttpResponse response = httpClient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {

                result = EntityUtils.toString(response.getEntity(), Charset.forName("utf-8"));
            }

        } catch (Exception e) {
            logger.warn("地址={},参数={},访问出错", url, json, e);
        }
        return result;

    }


}
