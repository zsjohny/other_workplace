package org.finace.utils.entity.merchandise;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 首页广告
 * Created by Ness on 2016/12/20.
 */
@Table(name = "merchandiseAdvertise")
@Entity
public class MerchandiseAdvertise {
    private Integer id;
    private String uuid;
    /**
     * 首页广告的地址
     */
    private String adviseUrl;
    /**
     * 首页的广告链接
     */
    private String adviseLink;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;


    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getAdviseUrl() {
        return adviseUrl;
    }

    public void setAdviseUrl(String adviseUrl) {
        this.adviseUrl = adviseUrl;
    }

    public String getAdviseLink() {
        return adviseLink;
    }

    public void setAdviseLink(String adviseLink) {
        this.adviseLink = adviseLink;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
