 package org.finace.utils.entity.user;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "collection")
public class Collection {
	/**
	 * 自增ID
	 */
	private Integer id;
	/**
	 * 与用户关联的id
	 */
	private String fatherId;
	/**
	 * 收藏的UID
	 */
	private String uuid;
	/**
	 * 是否删除
	 */
	private Boolean deleted;
	/**
	 * 创建时间
	 */
	private Timestamp newTime;
	/**
	 * 删除时间
	 */
	private Timestamp deleteTime;
	
	/**
	 * 是否是商家
	 */
	private Boolean merchandiser;
	
	@Id
    @GeneratedValue(strategy = GenerationType.TABLE)
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFatherId() {
		return fatherId;
	}
	public void setFatherId(String fatherId) {
		this.fatherId = fatherId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Boolean getDeleted() {
		return deleted;
	}
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	public Timestamp getNewTime() {
		return newTime;
	}
	public void setNewTime(Timestamp newTime) {
		this.newTime = newTime;
	}
	public Timestamp getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Timestamp deleteTime) {
		this.deleteTime = deleteTime;
	}
	public Collection() {
		super();
	}
	public Collection(String uuid) {
		super();
		this.uuid = uuid;
	}
	public Boolean getMerchandiser() {
		return merchandiser;
	}
	public void setMerchandiser(Boolean merchandiser) {
		this.merchandiser = merchandiser;
	}
}
