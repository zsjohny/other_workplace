package org.finace.utils.entity.user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "generalize")
public class Generalize {

	private Integer id;
	
	private String the;
	
	private String topOne;
	
	private String topTwo;

	
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getThe() {
		return the;
	}

	public void setThe(String the) {
		this.the = the;
	}


	public String getTopOne() {
		return topOne;
	}

	public void setTopOne(String topOne) {
		this.topOne = topOne;
	}

	public String getTopTwo() {
		return topTwo;
	}

	public void setTopTwo(String topTwo) {
		this.topTwo = topTwo;
	}
	
	
	
	
	

	
}
