package org.finace.utils.db;

import com.mongodb.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

/**
 * MongoDb的操作Templete
 * Created by Ness on 2016/12/7.
 */
public class MongodbTemplete implements InitializingBean, BeanFactoryAware {

    private Logger logger = LoggerFactory.getLogger(MongodbTemplete.class);
    private String BEAN_NAME = new StringBuilder("mongo").append(System.nanoTime()).toString();
    private MongoTemplate mongoTemplate;
    private Properties properties = new Properties();

    {
        try {
            properties.load(MongodbTemplete.class.getClassLoader().getResourceAsStream("defaultLink.properties"));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 存储数据
     *
     * @param obj 需要存储的类
     */
    public void save(Object obj) {

        try {
            if (obj == null) {
                return;
            }
            String dbName = obj.getClass().getName();
            if (dbName.contains("\\$")) {
                dbName = dbName.split("\\$")[1];
            } else {
                dbName = dbName.split("\\.")[dbName.split("\\.").length - 1];
            }
            mongoTemplate.save(obj, dbName);
            logger.info("mongo存储成功,{}", obj);
        } catch (Exception e) {

            logger.warn("mongo存储失败,{}", obj, e);
        }


    }

    /**
     * 查找一个
     *
     * @param query     查找条件
     * @param className 查找的类
     * @return
     */
    public Object findOne(Query query, Class<?> className) {
        Object result = null;
        try {

            if (query == null || className == null) {
                return result;
            }

            String dbName = className.getName();
            if (dbName.contains("\\$")) {
                dbName = dbName.split("\\$")[1];
            } else {
                dbName = dbName.split("\\.")[dbName.split("\\.").length - 1];
            }

            result = mongoTemplate.findOne(query, className, dbName);

            logger.info("mongo查找成功,{}", query);
        } catch (Exception e) {

            logger.warn("mongo查找失败,{}", query, e);
        }

        return result;

    }

    /**
     * 查找所有
     *
     * @param query     查找条件 为null时候查找所有
     * @param className 查找的类
     * @return
     */
    public List<?> findAll(Query query, Class<?> className) {
        List<?> results = null;
        try {

            if (className == null) {
                return results;
            }

            String dbName = className.getName();
            if (dbName.contains("\\$")) {
                dbName = dbName.split("\\$")[1];
            } else {
                dbName = dbName.split("\\.")[dbName.split("\\.").length - 1];
            }


            if (query == null) {
                results = mongoTemplate.findAll(className, dbName);
            } else {
                results = mongoTemplate.find(query, className, dbName);
            }


            logger.info("mongo查找所有成功,{}", query);
        } catch (Exception e) {
            logger.warn("mongo查找所有失败,{}", query, e);
        }

        return results;

    }

    /**
     * 更新
     *
     * @param query 需要更新的语句
     * @param obj   更新的实体类名称
     */
    public void update(Query query, Object obj) {

        try {

            if (obj == null) {
                return;
            }


            String dbName = obj.getClass().getName();
            if (dbName.contains("\\$")) {
                dbName = dbName.split("\\$")[1];
            } else {
                dbName = dbName.split("\\.")[dbName.split("\\.").length - 1];
            }

            Object one = mongoTemplate.findOne(query, obj.getClass(), dbName);

            if (one != null) {
                mongoTemplate.remove(query, obj.getClass(), dbName);
                mongoTemplate.save(obj, dbName);
            }

            logger.info("mongo更新成功,{}", obj);
        } catch (Exception e) {

            logger.warn("mongo更新失败,{}", obj, e);
        }


    }


    /**
     * 删除
     *
     * @param className 删除的实体类
     */
    public void delete(Query query, Class<?> className) {

        try {

            if (className == null || query == null) {
                return;
            }

            String dbName = className.getName();
            if (dbName.contains("\\$")) {
                dbName = dbName.split("\\$")[1];
            } else {
                dbName = dbName.split("\\.")[dbName.split("\\.").length - 1];
            }


            mongoTemplate.remove(query, dbName);


            logger.info("mongo删除成功,{},{}", query, className);
        } catch (Exception e) {
            System.out.println(e);
            logger.warn("mongo删除失败,{},{}", query, className, e);
        }


    }


    /**
     * 查找个数
     *
     * @param query     查询的条件
     * @param className 查询的实体类（xxx.class）
     */
    public long count(Query query, Class<?> className) {
        long count = 0;
        try {

            if (query == null || className == null) {
                return count;
            }
            String dbName = className.getName();
            if (dbName.contains("\\$")) {
                dbName = dbName.split("\\$")[1];
            } else {
                dbName = dbName.split("\\.")[dbName.split("\\.").length - 1];
            }

            count = mongoTemplate.count(query, dbName);


            logger.info("mongo查询个数成功,{},{}", query, className);
        } catch (Exception e) {
            logger.warn("mongo查询个数失败,{},{}", query, className, e);
        }
        return count;

    }

  /*  public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        MongodbTemplete ss = (MongodbTemplete) context.getBean("www");

        User user = new User("111", "111");
        ss.save(user);
        Query query = new Query(Criteria.where("name").is("111"));
        Object one = ss.findOne(query, User.class);

        List<?> all = ss.findAll(query, User.class);
        user = new User("122211", "222");
//        ss.update(query, user);
        System.out.println(ss.count(query,User.class));

    }*/


    @Override
    public void afterPropertiesSet() throws Exception {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(MongoTemplate.class);


        ServerAddress serverAddress = new ServerAddress(properties.getProperty("mongo.host"), Integer.parseInt(properties.getProperty("mongo.port")));

        MongoClientOptions options = MongoClientOptions.builder().
                socketKeepAlive(Boolean.parseBoolean(properties.getProperty("mongo.socketKeepAlive"))).// 是否保持长链接
                connectTimeout(Integer.parseInt(properties.getProperty("mongo.connectTimeout"))). // 链接超时时间
                socketTimeout(Integer.parseInt(properties.getProperty("mongo.socketTimeout"))). // read数据超时时间
                readPreference(ReadPreference.primary()).// // 最近优先策略
                connectionsPerHost(Integer.parseInt(properties.getProperty("mongo.maxPort"))).//每个地址最大请求数
                maxWaitTime(Integer.parseInt(properties.getProperty("mongo.maxWaitTime"))).//长链接的最大等待时间
                threadsAllowedToBlockForConnectionMultiplier(Integer.parseInt(properties.getProperty("mongo.socketAllowCount"))).//一个socket最大的等待请求数
                writeConcern(WriteConcern.MAJORITY).build();

        //现在mongodb没权限，这是以后设置权限的地方
//    List<MongoCredential> authors = new ArrayList<>();
//        MongoCredential credential = MongoCredential.createCredential(properties.getProperty("mongo.name"),
//                properties.getProperty("mongo.databases"), properties.getProperty("mongo.pass").toCharArray());
//
//   authors.add(credential);
//        MongoClient client = new MongoClient(serverAddress, authors, options);
        MongoClient client = new MongoClient(serverAddress, options);


        builder.addConstructorArgValue(client);
        builder.addConstructorArgValue(properties.getProperty("mongo.databases"));

        DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) factory;

        beanFactory.registerBeanDefinition(BEAN_NAME, builder.getRawBeanDefinition());

        mongoTemplate = (MongoTemplate) beanFactory.getBean(BEAN_NAME);


    }

    /* static class User {
         String name;
         String pass;
         Integer id;

         @Transient
         public Integer getId() {
             return id;
         }

         public void setId(Integer id) {
             this.id = id;
         }

         public User(String name, String pass) {
             this.name = name;
             this.pass = pass;
         }

         @Override
         public String toString() {
             return "User{" +
                     "name='" + name + '\'' +
                     ", pass='" + pass + '\'' +
                     '}';
         }

         public String getName() {
             return name;
         }

         public void setName(String name) {
             this.name = name;
         }

         public String getPass() {
             return pass;
         }

         public void setPass(String pass) {
             this.pass = pass;
         }
     }
 */
    private BeanFactory factory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.factory = beanFactory;
    }
}
