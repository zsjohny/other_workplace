package org.finace.utils.entity.merchandise;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import java.util.Arrays;
import java.util.Date;

/**
 * 商品的规格属性
 * Created by Ness on 2016/12/19.
 */
@Entity
@Table(name = "merchandiseStandard")
public class MerchandiseStandard {
    private Integer id;

    /**
     * uuid
     */
    private String uuid;

    /**
     * 一级分类的组成 存储格式 简单的数据 [xxx,xxx,xxx]
     */
    private String[] topCategoryName;

    /**
     * 二级分类的组成 存储格式 一个大数组嵌套单个小数组(小数组是对应 一级分类的索引) eg [ [xx,xx,xx] ,[xx,xx,xx] ]
     */
    private String[][] secondCateGoryName;

    /**
     * 对应商品价格  存储格式 一个大数组嵌套单个小数组 （小数组是对应 二级分类的索引) eg [ [xxx,xxx,xxx] ,[xxx,xxx,xxx] ] 当小组数里面有-1 表示不存在改价格
     */
    private String[][] prices;
    
    
    private byte[] topCategoryNameByteArr;
    
    
    private byte[] secondCateGoryNameByteArr;
    private byte[] secondCateGoryNameByteArr_2;


    /**
     * 对应的库存 存储格式  一个大数组嵌套单个小数组 （小数组是对应 二级分类的索引) eg [ [xx,xx,xx] ,[xxx,xx,xx] ] 当小组数里面有-1 表示不存在改价格
     */
   
    private String[][] stocks;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;
    
    private String merchUuid;

    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;

    
    private String merchLog;
    /**
     * 维度，标识这个规格是一维还是二维
     */
    private Integer dimension;
    
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
    public String[] getTopCategoryName() {
        return topCategoryName;
    }

    public void setTopCategoryName(String[] topCategoryName) {
        this.topCategoryName = topCategoryName;
    }
    
    public String[][] getSecondCateGoryName() {
        return secondCateGoryName;
    }

    public void setSecondCateGoryName(String[][] secondCateGoryName) {
        this.secondCateGoryName = secondCateGoryName;
    }
    
    
    
    
    public Integer getDimension() {
		return dimension;
	}

	public void setDimension(Integer dimension) {
		this.dimension = dimension;
	}

	public byte[] getTopCategoryNameByteArr() {
		return topCategoryNameByteArr;
	}

	public void setTopCategoryNameByteArr(byte[] topCategoryNameByteArr) {
		this.topCategoryNameByteArr = topCategoryNameByteArr;
	}


	@Transient
    public String[][] getPrices() {
        return prices;
    }

    public void setPrices(String[][] prices) {
        this.prices = prices;
    }
    @Transient
    public String[][] getStocks() {
        return stocks;
    }

    public void setStocks(String[][] stocks) {
        this.stocks = stocks;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
    
    
    public String getMerchUuid() {
		return merchUuid;
	}

	public void setMerchUuid(String merchUuid) {
		this.merchUuid = merchUuid;
	}

	@Transient
	public String getMerchLog() {
		return merchLog;
	}

	public void setMerchLog(String merchLog) {
		this.merchLog = merchLog;
	}


	public byte[] getSecondCateGoryNameByteArr() {
		return secondCateGoryNameByteArr;
	}

	public void setSecondCateGoryNameByteArr(byte[] secondCateGoryNameByteArr) {
		this.secondCateGoryNameByteArr = secondCateGoryNameByteArr;
	}

	public byte[] getSecondCateGoryNameByteArr_2() {
		return secondCateGoryNameByteArr_2;
	}

	public void setSecondCateGoryNameByteArr_2(byte[] secondCateGoryNameByteArr_2) {
		this.secondCateGoryNameByteArr_2 = secondCateGoryNameByteArr_2;
	}

	public MerchandiseStandard(Integer dimension, byte[] topCategoryNameByteArr, byte[] secondCateGoryNameByteArr, byte[] secondCateGoryNameByteArr_2) {
		super();
		this.dimension = dimension;
		this.topCategoryNameByteArr = topCategoryNameByteArr;
		this.secondCateGoryNameByteArr = secondCateGoryNameByteArr;
		this.secondCateGoryNameByteArr_2 = secondCateGoryNameByteArr_2;
	}

	@Override
    public String toString() {
        return "MerchandiseStandard{" +
                "id=" + id +
                ", uuid='" + uuid + '\'' +
                ", topCategoryName=" + Arrays.toString(topCategoryName) +
                ", secondCateGoryName=" + Arrays.toString(secondCateGoryName) +
                ", prices=" + Arrays.toString(prices) +
                ", stocks=" + Arrays.toString(stocks) +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", deleted=" + deleted +
                '}';
    }

	public MerchandiseStandard(String[][] secondCateGoryName) {
		super();
		this.secondCateGoryName = secondCateGoryName;
	}

	public MerchandiseStandard() {
		super();
	}

	
	
	
	
}
