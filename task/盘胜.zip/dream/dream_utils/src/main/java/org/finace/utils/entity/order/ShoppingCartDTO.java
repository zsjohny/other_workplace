package org.finace.utils.entity.order;

import java.util.List;

public class ShoppingCartDTO {
	private String shopName;
	private List<ShoppingCartMerch> goodsList;
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public List<ShoppingCartMerch> getGoodsList() {
		return goodsList;
	}
	public void setGoodsList(List<ShoppingCartMerch> goodsList) {
		this.goodsList = goodsList;
	}

}
