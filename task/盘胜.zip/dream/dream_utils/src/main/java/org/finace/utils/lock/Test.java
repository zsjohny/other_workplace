package org.finace.utils.lock;

import org.finace.utils.enums.LockType;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by Ness on 2017/1/10.
 */
public class Test {

    static Lock lock;
    AtomicInteger count = new AtomicInteger();

    public void doJob(String no) {
        String currentTime = "";
        try {
            System.out.println("000000000");
            while (lock.lock(LockType.ORDER_NUMBER_LOCK, no)) {
                //对当前参数进行校验 是否已经操作过了
                System.err.println("success" + no);
                //自己的代码

                currentTime = lock.getLock(LockType.ORDER_NUMBER_LOCK, no);
            }

            System.out.println("333333333");
        } catch (Exception e) {

        } finally {
            lock.unLock(LockType.ORDER_NUMBER_LOCK, no, currentTime);
        }


    }

    public void doJobCirCle(String no, String sign) {


            lock.lockCircle(LockType.ORDER_NUMBER_LOCK, no);
            //对当前参数进行校验 是否已经操作过了
            System.err.println("success" + no + "_____:" + sign + "____:num:" + count.incrementAndGet());
            //自己的代码

            System.out.println("333333333");


    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        Test test = context.getBean("test", Test.class);
        lock = context.getBean("lock", Lock.class);

        if (1 == 1) {

            new Thread(() -> test.doJobCirCle("1", "a")).start();
            new Thread(() -> test.doJobCirCle("1", "b")).start();
            new Thread(() -> test.doJobCirCle("1", "c")).start();
            new Thread(() -> test.doJobCirCle("1", "d")).start();
            new Thread(() -> test.doJobCirCle("1", "d")).start();
            new Thread(() -> test.doJobCirCle("1", "d")).start();
            new Thread(() -> test.doJobCirCle("2", "e")).start();
            new Thread(() -> test.doJobCirCle("2", "f")).start();
            new Thread(() -> test.doJobCirCle("2", "g")).start();
            new Thread(() -> test.doJobCirCle("2", "h")).start();
            new Thread(() -> test.doJobCirCle("2", "h")).start();
            new Thread(() -> test.doJobCirCle("2", "h")).start();
            return;
        }
        new Thread(() -> test.doJob("1")).start();
        new Thread(() -> test.doJob("1")).start();
        new Thread(() -> test.doJob("1")).start();
        new Thread(() -> test.doJob("1")).start();
        new Thread(() -> test.doJob("2")).start();
        new Thread(() -> test.doJob("2")).start();
        new Thread(() -> test.doJob("2")).start();
        new Thread(() -> test.doJob("2")).start();


    }
}
