package org.finace.utils.entity.user;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "city")
public class City implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//自身ID
    private Integer id;
    //市ID
    private Integer cityID;
    //市昵称
    private String city;
    //与省核对的ID
    private Integer fatherID;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

	public Integer getCityID() {
		return cityID;
	}

	public void setCityID(Integer cityID) {
		this.cityID = cityID;
	}

	public Integer getFatherID() {
		return fatherID;
	}

	public void setFatherID(Integer fatherID) {
		this.fatherID = fatherID;
	}
	
	public City() {
		super();
	}
	public City( String city,Integer cityID,Integer fatherID) {
		super();
		this.fatherID = fatherID;
		this.cityID = cityID;
		this.city = city;
	}
	

    
}
