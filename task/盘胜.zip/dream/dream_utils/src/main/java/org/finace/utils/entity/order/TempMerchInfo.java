package org.finace.utils.entity.order;

public class TempMerchInfo {
	private String merchUuid;
	private String merchStandardIndex;
	private Integer merchQuantity;
	public String getMerchUuid() {
		return merchUuid;
	}
	public void setMerchUuid(String merchUuid) {
		this.merchUuid = merchUuid;
	}
	public String getMerchStandardIndex() {
		return merchStandardIndex;
	}
	public void setMerchStandardIndex(String merchStandardIndex) {
		this.merchStandardIndex = merchStandardIndex;
	}
	public Integer getMerchQuantity() {
		return merchQuantity;
	}
	public void setMerchQuantity(Integer merchQuantity) {
		this.merchQuantity = merchQuantity;
	}
	
	public TempMerchInfo() {
	}
	public TempMerchInfo(String merchUuid, String merchStandardIndex, Integer merchQuantity) {
		super();
		this.merchUuid = merchUuid;
		this.merchStandardIndex = merchStandardIndex;
		this.merchQuantity = merchQuantity;
	}

}
