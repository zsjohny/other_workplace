package org.finace.utils.entity.order;

public class MerchStanModel {
	
	private String merchSpec;
	private Double merchPrice;
	private Integer stocks;
	private String merchPicByStand;
	public String getMerchSpec() {
		return merchSpec;
	}
	public void setMerchSpec(String merchSpec) {
		this.merchSpec = merchSpec;
	}
	public Double getMerchPrice() {
		return merchPrice;
	}
	public void setMerchPrice(Double merchPrice) {
		this.merchPrice = merchPrice;
	}
	public Integer getStocks() {
		return stocks;
	}
	public void setStocks(Integer stocks) {
		this.stocks = stocks;
	}
	public String getMerchPicByStand() {
		return merchPicByStand;
	}
	public void setMerchPicByStand(String merchPicByStand) {
		this.merchPicByStand = merchPicByStand;
	}
	
	
	

}
