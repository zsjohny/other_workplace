package org.finace.utils.entity.schedule;


import org.finace.utils.enums.ScheduleOperaType;

import javax.persistence.*;

/**
 * 定时任务的类
 * Created by Ness on 2016/12/8.
 */
@Table(name = "timerTask")
@Entity
public class TimeTask {

    private Integer id;
    private String scheduleTaskIndex;
    /**
     * 任务名称
     */
    private String timeTaskName;

    /**
     * 执行时间
     */
    private String executeTime;
    /**
     * 任务参数
     */
    private String params;

    private ScheduleOperaType scheduleOperaType;


    @Transient
    public ScheduleOperaType getScheduleOperaType() {
        return scheduleOperaType;
    }

    public void setScheduleOperaType(ScheduleOperaType scheduleOperaType) {
        this.scheduleOperaType = scheduleOperaType;
    }




    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getExecuteTime() {
        return executeTime;
    }

    public void setExecuteTime(String executeTime) {
        this.executeTime = executeTime;
    }

    @Column(length = 64)
    public String getTimeTaskName() {
        return timeTaskName;
    }

    public void setTimeTaskName(String timeTaskName) {
        this.timeTaskName = timeTaskName;
    }




    @Column(length = 32)
    public String getScheduleTaskIndex() {
        return scheduleTaskIndex;
    }
    public void setScheduleTaskIndex(String scheduleTaskIndex) {
        this.scheduleTaskIndex = scheduleTaskIndex;
    }

    @Column(length = 1024)
    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    @Override
    public String toString() {
        return "TimeTask{" +
                "id=" + id +
                ", scheduleTaskIndex='" + scheduleTaskIndex + '\'' +
                ", timeTaskName='" + timeTaskName + '\'' +
                ", executeTime='" + executeTime + '\'' +
                ", params='" + params + '\'' +
                ", scheduleOperaType=" + scheduleOperaType +
                '}';
    }
}
