package org.finace.utils.entity.order;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="shop_cart")
public class ShoppingCartMerch {



	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private Integer id;
	//商品数量
	private int quantity;
	//商品id
	private String merchUuid;
	//用户id
	private String userUuid;
	//商品规格在二维数组中的坐标
	private String merchStandardIndex;
	
	//购物车id
	private String uuid;
	
	private Timestamp createTime;
	
	private Timestamp updateTime;
	
	/**
	 * 以下所有字段都不需要持久化
	 */
	
	//商品名称，实时从商品表获取，不需持久化
	@Transient
	private String merchName;
	//商品价格，实时从商品表获取，不需持久化
	@Transient
	private Double merchPrice;
	//商品首图地址，实时从商品表获取，不需持久化
	@Transient
	private String merchPic;
	//商品规格显示字符串，根据商品规格坐标和一级分类二级分类实时拼接，不需持久化
	@Transient
	private String merchSpec;
	//购物车中此商品是否有效，实时根据merchUuid从商品表中关联查询，判断商品是否仍然有效
	//而此过程中关联商家的话，如果商品存在而商家关联不到，那么不会显示出来，提示出错。
	@Transient
	private Boolean isMerchValid;
	//商家uuid，从商家表中关联查询。无需持久化，然后根据商家，分类购物车商品，相同商家的商品放在一起
	@Transient
	private String merchandiserUuid;
	//商品规格id，无用
	//商品库存，实时从数据库中获取，无需持久化
	@Transient
	private int stocks;
	//商品是否充足，根据库存和quantity对比判断，如果库存少于quantity则为false
	@Transient
	private Boolean isStockSufficient;

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	public Boolean getIsMerchValid() {
		return isMerchValid;
	}


	public void setIsMerchValid(Boolean isMerchValid) {
		this.isMerchValid = isMerchValid;
	}


	public String getMerchUuid() {
		return merchUuid;
	}


	public void setMerchUuid(String merchUuid) {
		this.merchUuid = merchUuid;
	}


	public String getMerchName() {
		return merchName;
	}


	public void setMerchName(String merchName) {
		this.merchName = merchName;
	}


	public Double getMerchPrice() {
		return merchPrice;
	}


	public void setMerchPrice(Double merchPrice) {
		this.merchPrice = merchPrice;
	}


	public String getMerchPic() {
		return merchPic;
	}


	public void setMerchPic(String merchPic) {
		this.merchPic = merchPic;
	}

	
	public String getMerchSpec() {
		return merchSpec;
	}


	public void setMerchSpec(String merchSpec) {
		this.merchSpec = merchSpec;
	}


	public String getUserUuid() {
		return userUuid;
	}


	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}


	public String getMerchandiserUuid() {
		return merchandiserUuid;
	}


	public void setMerchandiserUuid(String merchandiserUuid) {
		this.merchandiserUuid = merchandiserUuid;
	}




	public String getMerchStandardIndex() {
		return merchStandardIndex;
	}


	public void setMerchStandardIndex(String merchStandardIndex) {
		this.merchStandardIndex = merchStandardIndex;
	}


	public ShoppingCartMerch() {
	}


	public ShoppingCartMerch(int quantity, String uuid) {
		super();
		this.quantity = quantity;
		this.uuid = uuid;
	}


	public int getStocks() {
		return stocks;
	}


	public void setStocks(int stocks) {
		this.stocks = stocks;
	}


	public Boolean getIsStockSufficient() {
		return isStockSufficient;
	}


	public void setIsStockSufficient(Boolean isStockSufficient) {
		this.isStockSufficient = isStockSufficient;
	}


	public Timestamp getCreateTime() {
		return createTime;
	}


	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}


	public Timestamp getUpdateTime() {
		return updateTime;
	}


	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	



}
