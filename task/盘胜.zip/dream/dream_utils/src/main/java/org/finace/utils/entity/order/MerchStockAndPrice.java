package org.finace.utils.entity.order;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * @author Administrator
 *
 */
/**
 * @author Administrator
 *
 */
@Entity
@Table(name="merchStockAndPrice")
public class MerchStockAndPrice {

	private Integer id;
	private String merchUuid;
	private String merchStandardIndex;
	private int stock;
	private Double price;
	private Timestamp createTime;
	private Timestamp updateTime;
	
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMerchUuid() {
		return merchUuid;
	}

	public void setMerchUuid(String merchUuid) {
		this.merchUuid = merchUuid;
	}

	public String getMerchStandardIndex() {
		return merchStandardIndex;
	}

	public void setMerchStandardIndex(String merchStandardIndex) {
		this.merchStandardIndex = merchStandardIndex;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public MerchStockAndPrice(int stock, Double price) {
		super();
		this.stock = stock;
		this.price = price;
	}

	public MerchStockAndPrice() {
		super();
	}
	
	
	
	
}
