package org.finace.utils.enums;

public enum MerchCheckType {
	
	MERCH_STOCK_CHECK("merch_stock_check");
	
	 private String key;

	 MerchCheckType(String key) {
	        this.key = key;
	    }

	    public String getName() {
	        return key;
	    }

}
