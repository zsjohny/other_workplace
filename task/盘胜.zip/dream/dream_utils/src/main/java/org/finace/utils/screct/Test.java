package org.finace.utils.screct;

import java.util.concurrent.atomic.LongAdder;

/**
 * Created by Ness on 2017/3/6.
 */
public class Test {
    private static LongAdder _orderNoLock = new LongAdder();
    public static void main(String[] args) {
        _orderNoLock.add(1);

        _orderNoLock.increment();;
        _orderNoLock.add(1);
        System.out.println(_orderNoLock.intValue());

    }
}
