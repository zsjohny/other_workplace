package org.finace.utils.enums;

/**
 * 返回状态码
 */
public enum ResponseType {

    EMPTY_CODE(201), INCORRECT_CODE(204), HAVE_SEND_CODE(202), HAVEN_INVALIAD_CODE(203),RESET_LOGIN(220);
    private Integer key;

     ResponseType(Integer key) {
        this.key = key;
    }

    /**
     * 获取返回状态
     *
     * @return
     */
    public Integer getCode() {
        return key;
    }

}
