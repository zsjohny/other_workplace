package org.finace.utils.operate;

import java.util.HashMap;

/**
 * 返回类型
 * Created by Ness on 2016/12/14.
 */
public class Response {

    protected int code;
    protected String msg;

    private static int ERROR_CODE = 500;
    private static int SUCCESS_CODE = 200;
    private static int FAILE_CODE = 208;
    private static int INVALIDE_CODE = 300;
    private static int FREQUEN_CODE = 600;
    private static String ERROR_MSG = "暂无数据";
    private static String SUCCESS_MSG = "";

    /**
     * 泛型
     *
     * @param <T>
     */
    private static class ResponseData<T> extends Response {
        private T data;

        public ResponseData() {
            data = (T) new HashMap<>();
        }

        public T getData() {
            return data;
        }
    }

    /**
     * 成功
     *
     * @param data 泛型 data
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> success(E data) {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.data = data;
        responseData.code = SUCCESS_CODE;
        responseData.msg = SUCCESS_MSG;
        return responseData;

    }

    /**
     * 成功
     *
     * @param msg 提示信息
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> success(String msg) {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = SUCCESS_CODE;
        responseData.msg = msg;
        return responseData;

    }

    /**
     * 成功 --无数据
     *
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> success() {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = SUCCESS_CODE;
        responseData.msg = SUCCESS_MSG;
        return responseData;

    }

    /**
     * 错误返回类型
     *
     * @param data 错误返回数据
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> error(E data) {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = ERROR_CODE;
        responseData.msg = ERROR_MSG;
        responseData.data = data;
        return responseData;
    }

    /**
     * 错误返回类型
     *
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> error() {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = ERROR_CODE;
        responseData.msg = ERROR_MSG;
        return responseData;
    }

    /**
     * 失败返回类型
     *
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> fail() {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = FAILE_CODE;
        responseData.msg = "";
        return responseData;
    }


    /**
     * 自定义类型
     *
     * @param code 返回状态码
     * @param msg  返回提示
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> response(int code, String msg) {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = code;
        responseData.msg = msg;
        return responseData;
    }

    /**
     * 自定义类型
     *
     * @param code 返回状态码
     * @param msg  返回提示
     * @param data 返回数据
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> response(int code, String msg, E data) {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = code;
        responseData.msg = msg;
        responseData.data = data;
        return responseData;
    }

    /**
     * 自定义类型
     *
     * @param code 返回状态码
     * @return
     */
    public static <E> ResponseData<E> response(int code) {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = code;
        responseData.msg = "";
        return responseData;
    }


    /**
     * token失效
     *
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> noAuthor() {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = INVALIDE_CODE;
        responseData.msg = "";
        return responseData;
    }

    /**
     * 频繁访问
     *
     * @param <E>
     * @return
     */
    public static <E> ResponseData<E> forbitten() {
        ResponseData<E> responseData = new ResponseData<>();
        responseData.code = FREQUEN_CODE;
        responseData.msg = "";
        return responseData;
    }


    public static void main(String[] args) {
        System.out.println(Response.success());
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
