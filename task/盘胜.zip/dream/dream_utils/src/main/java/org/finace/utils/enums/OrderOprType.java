package org.finace.utils.enums;

/**
 * 各类长度的判断
 * Created by Ness on 2016/12/5.
 */
public enum OrderOprType {
	  ORDER_SAVE_TYPE("order_save_type");
    private String key;

    OrderOprType(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

}
