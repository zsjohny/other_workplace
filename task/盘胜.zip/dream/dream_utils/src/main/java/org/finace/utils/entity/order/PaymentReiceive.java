package org.finace.utils.entity.order;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="paymentReiceive")
public class PaymentReiceive {
	private Integer id;
	private Timestamp createTime;
	private String merchandiserUuid;
	private String orderNo;
	private Double total_amount;
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public String getMerchandiserUuid() {
		return merchandiserUuid;
	}
	public void setMerchandiserUuid(String merchandiserUuid) {
		this.merchandiserUuid = merchandiserUuid;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public Double getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(Double total_amount) {
		this.total_amount = total_amount;
	}
	
}
