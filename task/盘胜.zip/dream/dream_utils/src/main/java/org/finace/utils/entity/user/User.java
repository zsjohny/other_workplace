package org.finace.utils.entity.user;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "user")
public class User {


    // 自增的id
    private Integer id;

    // 前段展示的id
    private String uuid;

    // 账号
    private String nickName;

    // 密码
    private String pass;

    // 姓名
    private String name;

    // 电话号
    private String phone;

    // 电子邮箱
    private String email;

    // 身份证
    private String idCard;

    // 银行卡号
    private String bankCard;

    /**
     * 第三方QQ自增Id
     */
    private String thirdQQId;


    /**
     * 第三方QQ密码
     */
    private String thirdQQPass;

    /**
     * 第三方微信自增Id
     */
    private String thirdWechatId;

    /**
     * 第三方微信的密码
     */
    private String thirdWechatPass;


    /**
     * 第三方微博自增Id
     */
    private String thirdWeBoId;


    /**
     * 第三方微博密码
     */
    private String thirdWeboPass;


    /**
     * 手机标识
     */
    private String uid;

    /**
     * 个人头像的地址
     */
    private String headPic;

    /**
     * 默认的收货地址
     */
    private String defaultAddress;
    /**
     * 默认的收货地址Id
     */
    private String defaultAddressId;


    /**
     * 登陆时间
     */
    private Date loadTime;


    /**
     * 创建时间
     */
    private Timestamp createTime;

    /**
     * 修改时间
     */
    private Date updateTime;


    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;
    
    /**
     * 设备号
     */
    private String facility;

    /**
     * 钱
     */
    private Double money;
    
    /**
     * 设备标识
     */
    private String diviceType;
    
    /**
     * 用户登录的client_id
     */
    private String cid;
    
    
    
    public static int MODEL_FOR_QQ = 0;
    public static int MODEL_FOR_WECHAT = 1;
    public static int MODEL_FOR_WEBO = 2;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getBankCard() {
        return bankCard;
    }

    public void setBankCard(String bankCard) {
        this.bankCard = bankCard;
    }

    public String getThirdQQId() {
        return thirdQQId;
    }

    public void setThirdQQId(String thirdQQId) {
        this.thirdQQId = thirdQQId;
    }

    public String getThirdQQPass() {
        return thirdQQPass;
    }

    public void setThirdQQPass(String thirdQQPass) {
        this.thirdQQPass = thirdQQPass;
    }

    public String getThirdWechatId() {
        return thirdWechatId;
    }

    public void setThirdWechatId(String thirdWechatId) {
        this.thirdWechatId = thirdWechatId;
    }

    public String getThirdWeBoId() {
        return thirdWeBoId;
    }

    public void setThirdWeBoId(String thirdWeBoId) {
        this.thirdWeBoId = thirdWeBoId;
    }

    public String getThirdWeboPass() {
        return thirdWeboPass;
    }

    public void setThirdWeboPass(String thirdWeboPass) {
        this.thirdWeboPass = thirdWeboPass;
    }

    public String getHeadPic() {
        return headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getDefaultAddress() {
        return defaultAddress;
    }

    public void setDefaultAddress(String defaultAddress) {
        this.defaultAddress = defaultAddress;
    }

    public String getDefaultAddressId() {
        return defaultAddressId;
    }

    public void setDefaultAddressId(String defaultAddressId) {
        this.defaultAddressId = defaultAddressId;
    }

    public String getThirdWechatPass() {
        return thirdWechatPass;
    }

    public void setThirdWechatPass(String thirdWechatPass) {
        this.thirdWechatPass = thirdWechatPass;
    }
    
	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Date getLoadTime() {
        return loadTime;
    }

    public void setLoadTime(Date loadTime) {
        this.loadTime = loadTime;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public User() {
    }

    public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}
	
    public Double getMoney() {
		return money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}
	
	public String getDiviceType() {
		return diviceType;
	}

	public void setDiviceType(String diviceType) {
		this.diviceType = diviceType;
	}
	
	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public User(String uuid, String uid,String pass, String thirdQQPass, String thirdWechatPass, String thirdWeboPass, String headPic, String nickName) {
        this.uuid = uuid;
        this.uid = uid;
        this.pass = pass;
        this.thirdQQPass = thirdQQPass;
        this.thirdWechatPass = thirdWechatPass;
        this.thirdWeboPass = thirdWeboPass;
        this.headPic = headPic;
        this.nickName = nickName;

    }

    public User(String phone, String pass) {
        this.phone = phone;
        this.pass = pass;

    }
    

}
