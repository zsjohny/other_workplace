package org.finace.utils.entity.order;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="orderTest")
public class OrderTest {
	@org.springframework.data.annotation.Id
	private String ids;
	private Integer id;
	private String uuid;
	private String orderNo;
	private Double totalPrice;
	private Date createTime;
	private Date updateTime;
	private Boolean deleted;
	private Integer status;
	private String userUuid;
	private String deletedPersonUuid;
	private String merchandiserUuid;
	private String merchandiserName;
	private Boolean isFlashSale;
	private String receiveAddressDetail;
	private byte [] merchUuid;
	private byte [] merchPic;
	private byte [] merchName;
	private byte [] merchPrice;
	private byte [] merchSpec;
	private byte [] merchStandardUuid;
	private byte [] merchStandardIndex;
	private byte [] merchQuantity;
	
	private String [] merchUuidStringArr;
	private String [] merchPicStringArr;
	private String [] merchNameStringArr;
	private String [] merchPriceStringArr;
	private String [] merchSpecStringArr;
	private String [] merchStandardUuidStringArr;
	private String [] merchStandardIndexStringArr;
	private String [] merchQuantityStringArr;
	private String orderMessage;
	private Boolean isAnonymous;
	private Boolean isFromCart;
	private String reCheckId;
	private String updatePersonUuid;
	private String diliveryCompanyNo;
	private String deliveryNo;
	private Boolean autoConfirmed;
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	
	public Boolean getIsFromCart() {
		return isFromCart;
	}
	public void setIsFromCart(Boolean isFromCart) {
		this.isFromCart = isFromCart;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	
	
	
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Boolean getDeleted() {
		return deleted;
	}
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}
	public String getDeletedPersonUuid() {
		return deletedPersonUuid;
	}
	public void setDeletedPersonUuid(String deletedPersonUuid) {
		this.deletedPersonUuid = deletedPersonUuid;
	}
	public String getMerchandiserUuid() {
		return merchandiserUuid;
	}
	public void setMerchandiserUuid(String merchandiserUuid) {
		this.merchandiserUuid = merchandiserUuid;
	}
	public String getMerchandiserName() {
		return merchandiserName;
	}
	public void setMerchandiserName(String merchandiserName) {
		this.merchandiserName = merchandiserName;
	}
	public Boolean getIsFlashSale() {
		return isFlashSale;
	}
	public void setIsFlashSale(Boolean isFlashSale) {
		this.isFlashSale = isFlashSale;
	}
	public String getReceiveAddressDetail() {
		return receiveAddressDetail;
	}
	public void setReceiveAddressDetail(String receiveAddressDetail) {
		this.receiveAddressDetail = receiveAddressDetail;
	}
	public String getOrderMessage() {
		return orderMessage;
	}
	public void setOrderMessage(String orderMessage) {
		this.orderMessage = orderMessage;
	}
	public Boolean getIsAnonymous() {
		return isAnonymous;
	}
	public void setIsAnonymous(Boolean isAnonymous) {
		this.isAnonymous = isAnonymous;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	public String getReCheckId() {
		return reCheckId;
	}
	public void setReCheckId(String reCheckId) {
		this.reCheckId = reCheckId;
	}
	
	
	public byte[] getMerchUuid() {
		return merchUuid;
	}
	public void setMerchUuid(byte[] merchUuid) {
		this.merchUuid = merchUuid;
	}
	public byte[] getMerchPic() {
		return merchPic;
	}
	public void setMerchPic(byte[] merchPic) {
		this.merchPic = merchPic;
	}
	public byte[] getMerchName() {
		return merchName;
	}
	public void setMerchName(byte[] merchName) {
		this.merchName = merchName;
	}
	public byte[] getMerchPrice() {
		return merchPrice;
	}
	public void setMerchPrice(byte[] merchPrice) {
		this.merchPrice = merchPrice;
	}
	public byte[] getMerchSpec() {
		return merchSpec;
	}
	public void setMerchSpec(byte[] merchSpec) {
		this.merchSpec = merchSpec;
	}
	public byte[] getMerchStandardUuid() {
		return merchStandardUuid;
	}
	public void setMerchStandardUuid(byte[] merchStandardUuid) {
		this.merchStandardUuid = merchStandardUuid;
	}
	public byte[] getMerchStandardIndex() {
		return merchStandardIndex;
	}
	public void setMerchStandardIndex(byte[] merchStandardIndex) {
		this.merchStandardIndex = merchStandardIndex;
	}
	public byte[] getMerchQuantity() {
		return merchQuantity;
	}
	public void setMerchQuantity(byte[] merchQuantity) {
		this.merchQuantity = merchQuantity;
	}
	@Transient
	public String[] getMerchUuidStringArr() {
		return merchUuidStringArr;
	}
	public void setMerchUuidStringArr(String[] merchUuidStringArr) {
		this.merchUuidStringArr = merchUuidStringArr;
	}
	@Transient
	public String[] getMerchPicStringArr() {
		return merchPicStringArr;
	}
	public void setMerchPicStringArr(String[] merchPicStringArr) {
		this.merchPicStringArr = merchPicStringArr;
	}
	@Transient
	public String[] getMerchNameStringArr() {
		return merchNameStringArr;
	}
	public void setMerchNameStringArr(String[] merchNameStringArr) {
		this.merchNameStringArr = merchNameStringArr;
	}
	@Transient
	public String[] getMerchPriceStringArr() {
		return merchPriceStringArr;
	}
	public void setMerchPriceStringArr(String[] merchPriceStringArr) {
		this.merchPriceStringArr = merchPriceStringArr;
	}
	@Transient
	public String[] getMerchSpecStringArr() {
		return merchSpecStringArr;
	}
	public void setMerchSpecStringArr(String[] merchSpecStringArr) {
		this.merchSpecStringArr = merchSpecStringArr;
	}
	@Transient
	public String[] getMerchStandardUuidStringArr() {
		return merchStandardUuidStringArr;
	}
	public void setMerchStandardUuidStringArr(String[] merchStandardUuidStringArr) {
		this.merchStandardUuidStringArr = merchStandardUuidStringArr;
	}
	@Transient
	public String[] getMerchStandardIndexStringArr() {
		return merchStandardIndexStringArr;
	}
	public void setMerchStandardIndexStringArr(String[] merchStandardIndexStringArr) {
		this.merchStandardIndexStringArr = merchStandardIndexStringArr;
	}
	@Transient
	public String[] getMerchQuantityStringArr() {
		return merchQuantityStringArr;
	}
	public void setMerchQuantityStringArr(String[] merchQuantityStringArr) {
		this.merchQuantityStringArr = merchQuantityStringArr;
	}
	public String getUpdatePersonUuid() {
		return updatePersonUuid;
	}
	public void setUpdatePersonUuid(String updatePersonUuid) {
		this.updatePersonUuid = updatePersonUuid;
	}
	public OrderTest(Double totalPrice, Integer status) {
		this.totalPrice = totalPrice;
		this.status = status;
	}
	public OrderTest(Double totalPrice, Integer status, String userUuid, String merchandiserUuid) {
		this.totalPrice = totalPrice;
		this.status = status;
		this.userUuid = userUuid;
		this.merchandiserUuid = merchandiserUuid;
	}
	public OrderTest() {
	}
	
	public OrderTest(byte[] merchName) {
		super();
		this.merchName = merchName;
	}
	public OrderTest(Integer status, byte[] merchUuid, byte[] merchStandardIndex, byte[] merchQuantity) {
		this.status = status;
		this.merchUuid = merchUuid;
		this.merchStandardIndex = merchStandardIndex;
		this.merchQuantity = merchQuantity;
	}

	
	
	
	
	
	
	
	public OrderTest(Double totalPrice, String uuid, String orderNo, Date createTime, Integer status,
			String merchandiserName, byte[] merchUuid, byte[] merchPic, byte[] merchName,
			byte[] merchPrice, byte[] merchSpec, byte[] merchStandardUuid, byte[] merchStandardIndex,
			byte[] merchQuantity, String orderMessage, Boolean isAnonymous, String receiveAddressDetail) {
		super();
		this.uuid = uuid;
		this.orderNo = orderNo;
		this.totalPrice = totalPrice;
		this.createTime = createTime;
		this.status = status;
		this.merchandiserName = merchandiserName;
		this.receiveAddressDetail = receiveAddressDetail;
		this.merchUuid = merchUuid;
		this.merchPic = merchPic;
		this.merchName = merchName;
		this.merchPrice = merchPrice;
		this.merchSpec = merchSpec;
		this.merchStandardUuid = merchStandardUuid;
		this.merchStandardIndex = merchStandardIndex;
		this.merchQuantity = merchQuantity;
		this.orderMessage = orderMessage;
		this.isAnonymous = isAnonymous;
	}
	public String getDiliveryCompanyNo() {
		return diliveryCompanyNo;
	}
	public void setDiliveryCompanyNo(String diliveryCompanyNo) {
		this.diliveryCompanyNo = diliveryCompanyNo;
	}
	public String getDeliveryNo() {
		return deliveryNo;
	}
	public void setDeliveryNo(String deliveryNo) {
		this.deliveryNo = deliveryNo;
	}
	public Boolean getAutoConfirmed() {
		return autoConfirmed;
	}
	public void setAutoConfirmed(Boolean autoConfirmed) {
		this.autoConfirmed = autoConfirmed;
	}
	public OrderTest(String orderNo, Double totalPrice, Integer status, String merchandiserUuid) {
		super();
		this.orderNo = orderNo;
		this.totalPrice = totalPrice;
		this.status = status;
		this.merchandiserUuid = merchandiserUuid;
	}
	





}
