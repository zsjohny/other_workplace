package org.finace.utils.prop;

import org.finace.utils.Regular.Regular;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * 默认数据加载
 * Created by Ness on 2016/12/8.
 */
public class DataProperties extends PropertyPlaceholderConfigurer {
    private Properties properties;
    private Map<String, String> map;


    @Override
    protected Properties mergeProperties() throws IOException {
        properties = super.mergeProperties();
        map = new HashMap<>(properties.size());
        Enumeration<?> enumeration = properties.propertyNames();
        Object key;
        while (enumeration.hasMoreElements()) {
            key = enumeration.nextElement();
            map.put(key.toString(), properties.get(key).toString());
        }
        return properties;
    }

    public void setProperty(String key, String value) {
        if (Regular.checkEmpty(key, null) || Regular.checkEmpty(value, null)) {
            return;
        }
        map.put(key, value);
//        return properties.getProperty(key);
    }

    public String getProperty(String key) {
        return map.get(key);
//        return properties.getProperty(key);
    }

    public static void main(String[] args) throws InterruptedException {

        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        DataProperties s = (DataProperties) context.getBean("dataProperties");
        System.out.println(s.getProperty("test"));


    }
}
