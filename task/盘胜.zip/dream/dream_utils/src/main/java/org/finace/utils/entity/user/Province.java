package org.finace.utils.entity.user;


import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="province")
public class Province implements Serializable{
	/**
	 * 	序列化
	 */
	private static final long serialVersionUID = 1L;
	//自身ID
	private Integer id;
	//省IDP
	private Integer provinceID;
	//省名称
	private String province;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public Integer getProvinceID() {
		return provinceID;
	}

	public void setProvinceID(Integer provinceID) {
		this.provinceID = provinceID;
	}

	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}

	public Province( String province,Integer provinceID) {
		super();
		this.provinceID = provinceID;
		this.province = province;
	}

	public Province() {
		super();
	}
	
	
	
}
