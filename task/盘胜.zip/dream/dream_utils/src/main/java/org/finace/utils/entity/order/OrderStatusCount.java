package org.finace.utils.entity.order;

public class OrderStatusCount {
	private String status;
	private String Count;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCount() {
		return Count;
	}
	public void setCount(String count) {
		Count = count;
	}
	
	

}
