package org.finace.utils.entity.user;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "address")
public class Address implements Serializable{
	private static final long serialVersionUID = 1L;
	//自增Id
	private Integer id;
	//地址的UUID
	private String uuid;
    //关联ID
    private String fatherId;
    //收货人姓名
    private String addressName;
    //收货人手机号
    private String addressPhone;
    //所在地区
    private String[] addressSite;
    //详细地址
    private String addressMinute;
    //默认地址
    private boolean defaultSite;
    //创建时间
    private Timestamp createTime;
    //修改时间
    private Timestamp updateTime;
    //是否删除 true是删除 false不是
    private Boolean deleted;
    //省市区Id
    private byte[] siteId;
    
   
    
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getFatherId() {
		return fatherId;
	}
	public void setFatherId(String fatherId) {
		this.fatherId = fatherId;
	}
	public String getAddressName() {
		return addressName;
	}
	public void setAddressName(String addressName) {
		this.addressName = addressName;
	}
	public String getAddressPhone() {
		return addressPhone;
	}
	public void setAddressPhone(String addressPhone) {
		this.addressPhone = addressPhone;
	}
	public String[] getAddressSite() {
		return addressSite;
	}
	public void setAddressSite(String[] addressSite) {
		this.addressSite = addressSite;
	}
	public String getAddressMinute() {
		return addressMinute;
	}
	public void setAddressMinute(String addressMinute) {
		this.addressMinute = addressMinute;
	}
	public boolean isDefaultSite() {
		return defaultSite;
	}
	public void setDefaultSite(boolean defaultSite) {
		this.defaultSite = defaultSite;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public Timestamp getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}
	public Boolean getDeleted() {
		return deleted;
	}
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	public byte[] getSiteId() {
		return siteId;
	}
	public void setSiteId(byte[] siteId) {
		this.siteId = siteId;
	}
	
	public Address(String uuid,String addressName, String addressPhone, String[] addressSite,String addressMinute, boolean defaultSite,byte[] siteId) {
		super();
		this.uuid = uuid;
		this.addressName = addressName;
		this.addressPhone = addressPhone;
		this.addressSite = addressSite;
		this.addressMinute = addressMinute;
		this.defaultSite = defaultSite;
		this.siteId = siteId;
	}
	public Address() {
		super();
	}
	
}
