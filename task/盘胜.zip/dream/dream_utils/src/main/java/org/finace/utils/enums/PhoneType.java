package org.finace.utils.enums;

/**
 * 手机状态(0是安卓，1是苹果)
 */
public enum PhoneType {
	
	ANDROID_KEY(0),IOS_KEY(1);
	
	private Integer key;

	public Integer getKey() {
		return key;
	}

	private PhoneType(Integer key) {
		this.key = key;
	}
	
}
