package org.finace.utils.entity.merchandise;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 商品分类
 * Created by Ness on 2016/12/16.
 */
@Table(name = "merchandiseCategory")
@Entity
public class MerchandiseCategory {

    private Integer id;

    private String uuid;

    /**
     * 商品名称
     */
    private String name;


    /**
     * 是否是父级分类 ,true是父级分类 flase是子类分类
     */
    private Boolean parentCate;

    /**
     * 父级的uuid
     */
    private String parentUuid;
    
    /*
     * 一张图
     */
    private String jpg;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;


    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;

    
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Boolean getParentCate() {
		return parentCate;
	}


	public void setParentCate(Boolean parentCate) {
		this.parentCate = parentCate;
	}


	public String getParentUuid() {
		return parentUuid;
	}


	public void setParentUuid(String parentUuid) {
		this.parentUuid = parentUuid;
	}


	public Date getCreateTime() {
		return createTime;
	}


	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}


	public Date getUpdateTime() {
		return updateTime;
	}


	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}


	public Boolean getDeleted() {
		return deleted;
	}


	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}


	public String getJpg() {
		return jpg;
	}


	public void setJpg(String jpg) {
		this.jpg = jpg;
	}

    
}
