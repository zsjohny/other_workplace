package org.finace.utils.entity.order;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OrderPayTemp")
public class OrderPayTemp {
		private Integer id;
		private String paymentNo;
		private String orderNo;
		private Integer appResult;
		private Integer thirdPayResult;
		private String total_amount;
		private Boolean payed;
		private String userUuid;
		private String random_code;
		private Timestamp createTime;
		private String mercherName;
		private String singleOrderPrice;
		@Id
		@GeneratedValue(strategy = GenerationType.TABLE)
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getPaymentNo() {
			return paymentNo;
		}
		public void setPaymentNo(String paymentNo) {
			this.paymentNo = paymentNo;
		}
		public String getOrderNo() {
			return orderNo;
		}
		public void setOrderNo(String orderNo) {
			this.orderNo = orderNo;
		}
		public Integer getAppResult() {
			return appResult;
		}
		public void setAppResult(Integer appResult) {
			this.appResult = appResult;
		}
		public Integer getThirdPayResult() {
			return thirdPayResult;
		}
		public void setThirdPayResult(Integer thirdPayResult) {
			this.thirdPayResult = thirdPayResult;
		}
		public String getTotal_amount() {
			return total_amount;
		}
		public void setTotal_amount(String total_amount) {
			this.total_amount = total_amount;
		}
		
		public Boolean getPayed() {
			return payed;
		}
		public void setPayed(Boolean payed) {
			this.payed = payed;
		}
		public String getUserUuid() {
			return userUuid;
		}
		public void setUserUuid(String userUuid) {
			this.userUuid = userUuid;
		}
		public String getRandom_code() {
			return random_code;
		}
		public void setRandom_code(String random_code) {
			this.random_code = random_code;
		}
		public Timestamp getCreateTime() {
			return createTime;
		}
		public void setCreateTime(Timestamp createTime) {
			this.createTime = createTime;
		}
		public String getMercherName() {
			return mercherName;
		}
		public void setMercherName(String mercherName) {
			this.mercherName = mercherName;
		}
		public String getSingleOrderPrice() {
			return singleOrderPrice;
		}
		public void setSingleOrderPrice(String singleOrderPrice) {
			this.singleOrderPrice = singleOrderPrice;
		}
		
		
}
