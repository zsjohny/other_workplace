package org.finace.utils.entity.user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="area")

public class Area {
	//自增ID
	private Integer id;
	//area的本身ID
	private Integer areaID;
	//（区）地点名称
	private String area;
	//与市核对的ID
	private Integer fatherID;
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getAreaID() {
		return areaID;
	}
	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public Integer getFatherID() {
		return fatherID;
	}
	public void setFatherID(Integer fatherID) {
		this.fatherID = fatherID;
	}
	
	
	public Area() {
		super();
	}
	public Area( String area, Integer areaID,Integer fatherID) {
		super();
		this.fatherID = fatherID;
		this.areaID = areaID;
		this.area = area;
	}
	
	
	
}
