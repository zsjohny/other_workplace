package org.finace.utils.push;

import com.alibaba.fastjson.JSON;
import org.finace.utils.entity.push.Push;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by Ness on 2017/1/11.
 */
public class Test {

    private ThreadLocal<String> uuid = new ThreadLocal<>();

    public String getUuid() {
        return uuid.get();
    }

    public  void setUuid(String uuid) {
        this.uuid.set(uuid);
    }


    static   List<Push> pushes = new CopyOnWriteArrayList<>();

    public static void main(String[] args) {

        if(1==1){
            Test test = new Test();
            test.setUuid("111");
            String uuid = test.getUuid();
            System.out.println(uuid);
            return;
        }

        Push push = new Push();
        push.setSendDeviceType(0);
        push.setDeviceNum("122412542542");
        push.setSendTopic("");
        push.setSendContent(JSON.toJSONString(""));
        PushUtils.sendPush(push);


        pushes.add(push);

        PushUtils.sendPush(pushes.toArray(new Push[pushes.size()]));
        pushes.clear();


    }
}
