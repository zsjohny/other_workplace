package org.finace.utils.test;

/**
 * Created by Ness on 2017/1/2.
 */
public class Singleton {

    public static void main(String[] args) throws InterruptedException {

    }
}


