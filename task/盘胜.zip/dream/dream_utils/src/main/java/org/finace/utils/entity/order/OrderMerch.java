package org.finace.utils.entity.order;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * @author Administrator
 *
 */
@Entity
@Table(name = "order_merch")
public class OrderMerch {

	private Integer id;

	private int quantity;
	/**
	 * 商品的uuid
	 */
	private String merchUuid;
	/**
	 * 商品名称
	 */
	private String merchName;
	/**
	 * 商品单价
	 */
	private Double merchPrice;
	/**
	 * 商品首图
	 */
	private String merchPic;
	/**
	 * 商品规格
	 */
	private String merchSpec;

	private String orderNo;

	private String merchStandardUuid;

	private String merchStandardIndex;

	private Timestamp createTime;

	private Timestamp updateTime;

	private Boolean payed;
	private Orders singleOrder;
	
	private String uuid;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getMerchUuid() {
		return merchUuid;
	}

	public void setMerchUuid(String merchUuid) {
		this.merchUuid = merchUuid;
	}




	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public String getMerchName() {
		return merchName;
	}

	public void setMerchName(String merchName) {
		this.merchName = merchName;
	}

	public Double getMerchPrice() {
		return merchPrice;
	}

	public void setMerchPrice(Double merchPrice) {
		this.merchPrice = merchPrice;
	}

	public String getMerchPic() {
		return merchPic;
	}

	public void setMerchPic(String merchPic) {
		this.merchPic = merchPic;
	}

	public String getMerchSpec() {
		return merchSpec;
	}

	public void setMerchSpec(String merchSpec) {
		this.merchSpec = merchSpec;
	}



	public OrderMerch() {
	}

	public String getMerchStandardUuid() {
		return merchStandardUuid;
	}

	public void setMerchStandardUuid(String merchStandardUuid) {
		this.merchStandardUuid = merchStandardUuid;
	}

	public String getMerchStandardIndex() {
		return merchStandardIndex;
	}

	public void setMerchStandardIndex(String merchStandardIndex) {
		this.merchStandardIndex = merchStandardIndex;
	}

	public Boolean getPayed() {
		return payed;
	}

	public void setPayed(Boolean payed) {
		this.payed = payed;
	}
	@ManyToOne
	@JoinColumn(name="soid")
	public Orders getSingleOrder() {
		return singleOrder;
	}

	public void setSingleOrder(Orders singleOrder) {
		this.singleOrder = singleOrder;
	}

	public OrderMerch(int quantity, String merchUuid, String merchStandardIndex) {
		super();
		this.quantity = quantity;
		this.merchUuid = merchUuid;
		this.merchStandardIndex = merchStandardIndex;
	}
	
	
}
