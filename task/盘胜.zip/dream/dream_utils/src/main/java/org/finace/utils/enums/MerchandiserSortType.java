package org.finace.utils.enums;

public enum MerchandiserSortType {
    SALE_COUNT("merchReceivedSeveral"), CREATE_TIME("salesVolume");
    private String key;

	 MerchandiserSortType(String key) {
		this.key = key;
	}

	public String getKey() {
		return key;
	}
	
	 
}
