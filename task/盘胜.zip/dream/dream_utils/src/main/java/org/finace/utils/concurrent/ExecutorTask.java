package org.finace.utils.concurrent;

/**
 * 任务的名称
 * Created by Ness on 2017/1/5.
 */
public abstract class ExecutorTask implements Runnable {

    @Override
    public void run() {
        doJob();
    }

    public abstract void doJob();

}
