package org.finace.utils.enums;

/**
 * Created by Ness on 2016/12/18.
 */
public enum MerchadiseSortType {
    SALE_COUNT("merchHaveSaleTotalCount"), SALE_PRICE("merchPrice"), CREATE_TIME("createTime");
    private String key;

    MerchadiseSortType(String key) {
        this.key = key;
    }

    public String getSort() {
        return key;
    }

}
