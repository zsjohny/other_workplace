package org.finace.utils.screct;

import javax.crypto.Cipher;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * RSA加密类
 */
public class RsaUtils {


    /**
     * 初始化秘钥组
     *
     * @return
     */
    public static Map<String, String> initKeys() {
        Map<String, String> map = new HashMap<>();
        try {
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
            keyPairGen.initialize(1024);
            KeyPair keyPair = keyPairGen.generateKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();
            PublicKey publicKey = keyPair.getPublic();
            map.put("publicKey", Base64.getEncoder().encodeToString(publicKey.getEncoded()));
            map.put("privateKey", Base64.getEncoder().encodeToString(privateKey.getEncoded()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return map;
    }

    public static void main(String[] args) throws InterruptedException {

        System.out.println("aNhLPmVY6UdkesDBmSLhSFLqAuqNXdW6Ufwj9CFX+s3ZawUxL+/zg53Ott9rtHPqshty1IxJmErRwlTKElrhlg==:338038280fb5a492b0d368bebb8c40c3017e7b816".length());

        CountDownLatch downLatch = new CountDownLatch((Runtime.getRuntime().availableProcessors() + 1) * 10);


        Set<String> setPub = new HashSet<>();
        List<String> listPub = new ArrayList<>();
        Set<String> setPrivate = new HashSet<>();
        List<String> listPrivate = new ArrayList<>();
        for (int j = 0; j < Runtime.getRuntime().availableProcessors() + 1; j++) {
            new Thread(() -> {
                for (int i = 0; i < 10; i++) {
                    Map<String, String> stringStringMap = initKeys();
                    String publicKey = stringStringMap.get("publicKey");
                    String privateKey = stringStringMap.get("privateKey");
                    setPub.add(publicKey);
                    listPub.add(publicKey);
                    setPrivate.add(privateKey);
                    listPrivate.add(privateKey);
//                   System.out.println(Thread.currentThread().getName()+"   :public:____" + publicKey);
//                   System.out.println(Thread.currentThread().getName()+" private:___" + privateKey);
                    downLatch.countDown();

                }

            }).start();


        }

        downLatch.await();

        System.out.println("privateSize:" + setPrivate.size());
        System.out.println("privateListSize:" + listPrivate.size());
        System.out.println("publicSize:" + setPub.size());
        System.out.println("publicListSize:" + listPub.size());

//        String result = decrypt(privateKey, str);
//        System.out.println(result);

    }


    /**
     * 加密
     *
     * @param key    加密的公钥
     * @param encrty 加密对象
     * @return
     */
    public static String encrypt(String key, String encrty) {
        String result = "";
        if (key == null || key.length() == 0) {
            return result;
        }
        try {
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(key));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key publicKey = keyFactory.generatePublic(x509KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            result = Base64.getEncoder().encodeToString(cipher.doFinal(encrty.getBytes()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return result;
    }

    /**
     * 解密
     *
     * @param key    加密秘钥
     * @param decrty 待解密的对象
     * @return
     */
    public static String decrypt(String key, String decrty) {
        String result = "";
        if (key == null || key.length() == 0) {
            return result;
        }

        try {
            // 取得私钥
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(key));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            result = new String(cipher.doFinal(Base64.getDecoder().decode(decrty)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return result;
    }



}
