package org.finace.utils.entity.user;

import java.sql.Date;
import java.sql.Timestamp;

public class BankCard {
	
	private Integer id;
	/*
	 * 用户关联的uuid
	 */
	private String uuid;
	
	/*
	 * 持卡人姓名
	 */
	private String name;
	
	/*
	 * 手机号
	 */
	private String phone;
	
	/*
	 * 银行卡号 
	 */
	private String number;
	
	/*
	 * 是哪个银行
	 */
	private String bankCard;
	
	/*
	 * 创建时间
	 */
	private Timestamp createTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getBankCard() {
		return bankCard;
	}

	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
