package org.finace.utils.conver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 数据转换的utils
 * Created by Ness on 2017/1/17.
 */
public class DataConverUtils {
    private static Logger logger = LoggerFactory.getLogger(DataConverUtils.class);
    private static Lock strLock = new ReentrantLock();
    private static Lock byteLock = new ReentrantLock();

    /**
     * string[] 转成 byte[]
     *
     * @param strs 需要转换的字符串数组
     * @return
     */
    public static byte[] stringArr2ByteArr(String[] strs) {
        byte[] bytes = null;
        ByteArrayInputStream bais=null;
        if (strs == null || strs.length == 0) {
            return bytes;
        }
        try {

            strLock.lock();
            bais= new ByteArrayInputStream(Arrays.asList(strs).toString().getBytes());
            bytes = new byte[bais.available()];
            bais.read(bytes);
        } catch (Exception e) {
            logger.warn("对象将string 转成 byte 类型出错", e);
        } finally {

            if(bais!=null){
                strLock.unlock();
                try {
                    bais.close();
                } catch (IOException e) {

                }

            }

        }

        return bytes;


    }


    /**
     * byte[] 转 string[]
     *
     * @param bytes 需要转换的byte数组
     * @return
     */
    public static String[] byteArr2StringArr(byte[] bytes) {
        ByteArrayOutputStream baos = null;
        String[] str = null;
        if (bytes == null || bytes.length == 0) {
            return str;
        }
        try {

            byteLock.lock();
            baos = new ByteArrayOutputStream(bytes.length);

            baos.write(bytes);
            String s = baos.toString();
            str = s.replaceAll("\\[|]| ", "").split(",");

        } catch (Exception e) {
            logger.warn("对象将byte 转成 String  类型出错", e);
        } finally {

            if(baos!=null){
                byteLock.unlock();
                try {
                    baos.close();
                } catch (IOException e) {

                }

            }
        }


        return str;
    }


    public static void main(String[] args) {
        for(int i=0;i<100;i++){
            new Thread(() -> {
                byte[] bytes = stringArr2ByteArr(new String[]{"1", "2"});
                System.out.println(bytes);
            }).start();
        }

        byte[] bytes = stringArr2ByteArr(new String[]{"1", "2"});
        stringArr2ByteArr(new String[]{"1", "3"});
        stringArr2ByteArr(new String[]{"1", "4"});
        stringArr2ByteArr(new String[]{"1", "5"});
        System.out.println("ok..");
        String[] strings = byteArr2StringArr(bytes);
        System.out.println(strings.length);
        System.out.println(strings[0]);
        System.out.println(strings[1]);
    }

}
