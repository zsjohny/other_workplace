package org.finace.utils.lock;

import com.alibaba.fastjson.JSONArray;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.enums.LockType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 分布式线程锁
 * Created by Ness on 2017/1/5.
 */
public class Lock extends CacheTemplete {


    private Logger logger = LoggerFactory.getLogger(Lock.class);
    private final int INVALID_TIME = 4000;
    private final int FAILE_CODE = 0;
    private final String LOCK_KEY = "lock";
    private static Boolean HAVE_RESUME = false;
    private final String LINK = ":";

    /**
     * 循环加锁
     *
     * @param lockType 加锁的类型
     * @param uniqueNo 加锁的编号
     * @return
     */
    public void lockCircle(LockType lockType, String uniqueNo) {
        if (Regular.checkEmpty(uniqueNo, null)) {
            logger.warn("对内容{}循环 加锁,加锁编号为空", lockType.getKey());
            return;
        }
        try {
            logger.info("开始添加内容{},加锁编号{} 循环 锁任务 ", lockType, uniqueNo);

            while (!setLock(lockType, uniqueNo)) {
            }
            unLock(lockType, uniqueNo, getLock(lockType, uniqueNo));
            logger.info("结束添加  内容{},加锁编号{} 循环锁任务 ", lockType, uniqueNo);
        } catch (Exception e) {
            logger.warn("进行添加 内容{},加锁编号{} 循环锁任务出错 ", lockType, uniqueNo, e);
        }
    }

    /**
     * 加锁
     *
     * @param lockType 加锁的类型
     * @param uniqueNo 加锁的编号
     * @return
     */
    public Boolean lock(LockType lockType, String uniqueNo) {
        if (Regular.checkEmpty(uniqueNo, null)) {
            logger.warn("对内容{}加锁,加锁编号为空", lockType.getKey());
            return false;
        }
        return setLock(lockType, uniqueNo);
    }

    /**
     * 上锁
     *
     * @param lockType 加锁的类型
     * @param uniqueNo 加锁的编号
     * @return
     */
    private Boolean setLock(LockType lockType, String uniqueNo) {
        Boolean flag = false;
        if (Regular.checkEmpty(uniqueNo, null)) {
            logger.warn("对内容{}加锁,加锁编号为空", lockType.getKey());
            return flag;
        }
        try {
            openCaceTemplete();
            logger.info("开始进行对内容{},加锁编号{} 加锁", lockType.getKey(), uniqueNo);
            String key = lockType.getKey() + uniqueNo;
            Long currentTime = System.currentTimeMillis();
            while (jedis.get() == null) {
                openCaceTemplete();
            }
            if (jedis.get().setnx(key, currentTime.toString()) == FAILE_CODE) {
                String oringalTime = jedis.get().get(key);
                if (Regular.checkEmpty(oringalTime, null)) {
                    return flag;
                }
                if (Math.abs(currentTime - Long.parseLong(oringalTime)) > INVALID_TIME) {
                    if (resetLock(lockType, uniqueNo, currentTime.toString(), oringalTime)) {
                        flag = true;
                        saveLock(lockType, key, currentTime);
                    }
                }

            } else {
                flag = true;
                saveLock(lockType, key, currentTime);
            }


            logger.info("结束进行对内容{},加锁编号{} 加锁", lockType.getKey(), uniqueNo);
        } catch (Exception e) {
            StringBuilder builder = new StringBuilder();
            builder.append("对内容{ ");
            builder.append(lockType.getKey());
            builder.append("} 加锁编号{ ");
            builder.append(uniqueNo);
            builder.append("加锁出错");
            builder.append(e);
            sendReport(builder.toString());
            logger.warn("对内容{},加锁编号{} 加锁出错", lockType.getKey(), uniqueNo, e);
        } finally {
            closeCacheTemplete();
        }
        return flag;
    }


    private static ConcurrentHashMap<String, String> lockMap = new ConcurrentHashMap<>();


    /**
     * 存储lock对象
     *
     * @param lockType    lock类型
     * @param key         lock存储的key
     * @param currentTime lock的当前时间
     */
    private void saveLock(LockType lockType, String key, Long currentTime) {
        if (jedis.get() == null) {
            return;
        }
        try {
            String hget = jedis.get().hget(LOCK_KEY, lockType.getKey());
            JSONArray array;
            if (Regular.checkEmpty(hget, null)) {
                array = new JSONArray();
                array.add(key + LINK + currentTime);
            } else {
                array = JSONArray.parseArray(hget);
                String result;
                int len = array.size();
                for (int i = 0; i < len; i++) {
                    result = (String) array.get(i);
                    if (result.startsWith(key)) {
                        array.set(i, key + LINK + currentTime);
                    }
                }

            }
            jedis.get().hset(LOCK_KEY, lockType.getKey(), array.toJSONString());
            lockMap.put(key, currentTime.toString());
        } catch (Exception e) {
            logger.info("进行存储锁内容{},加锁编号{} 出错", lockType, key, e);
        }
    }

    /**
     * 获取当前锁的内容
     *
     * @param lockType 锁的内容
     * @param uniqueNo 加锁的编号
     * @return
     */
    public String getLock(LockType lockType, String uniqueNo) {
        if (Regular.checkEmpty(uniqueNo, null)) {
            logger.warn("对内容{}获取锁,加锁编号为空", lockType.getKey());
            return "";
        }


        return lockMap.get(lockType.getKey()+uniqueNo);
    }


    /**
     * 重置锁
     *
     * @param lockType    重置锁的类型
     * @param uniqueNo    加锁的编号
     * @param nowTime     重置锁的当前时间
     * @param oringalTime 重置锁的之前时间
     * @return
     */
    private Boolean resetLock(LockType lockType, String uniqueNo, String nowTime, String oringalTime) {
        Boolean flag = false;
        if (Regular.checkEmpty(uniqueNo, null)) {
            logger.warn("加锁的编号为空");
            return flag;
        }
        if (jedis == null) {
            return flag;
        }
        try {

            String key = lockType.getKey() + uniqueNo;
            logger.info("开始进行对内容{} 加锁编号{} 重置锁", lockType.getKey(), uniqueNo);
            String _saveOrinaglTime = jedis.get().getSet(key, nowTime);
            if (!_saveOrinaglTime.equals(oringalTime)) {
                //恢复之前的锁
                jedis.get().set(key, oringalTime);
                logger.info("恢复之前对内容{} 加锁编号{} 重置锁 success", lockType.getKey(), uniqueNo);
            } else {
                flag = true;
                logger.info("成功进行对内容{} 加锁编号{} 重置锁 success", lockType.getKey(), uniqueNo);
            }

            logger.info("结束进行对内容{} 加锁编号{} 重置锁", lockType.getKey(), uniqueNo);
        } catch (Exception e) {
            StringBuilder builder = new StringBuilder();
            builder.append("对内容{ ");
            builder.append(lockType.getKey());
            builder.append("} 加锁编号{ ");
            builder.append(uniqueNo);
            builder.append("} 重置锁出错");
            builder.append(e);
            sendReport(builder.toString());
            logger.warn("对内容{} 加锁编号{} 重置锁 出错", lockType.getKey(), uniqueNo, e);
        }
        return flag;
    }

    /**
     * 解锁
     *
     * @param lockType    解锁的类型
     * @param uniqueNo    加锁的编号
     * @param currentTime 解锁的时间
     * @return
     */
    public Boolean unLock(LockType lockType, String uniqueNo, String currentTime) {
        Boolean flag = false;
        if (Regular.checkEmpty(currentTime, null)) {
            logger.info("进对内容{} 加锁编号{} 解锁，currentTime为空", lockType.getKey(), uniqueNo);
            return flag;
        }

        if (Regular.checkEmpty(uniqueNo, null)) {
            logger.info("进对内容{}解锁，currentTime{} 加锁编号为空", lockType.getKey(), currentTime);
            return flag;
        }

        try {
            openCaceTemplete();
            String key = lockType.getKey() + uniqueNo;
            logger.info("开始进行对内容{} 加锁编号{} 解锁", lockType.getKey(), uniqueNo);
            if (jedis.get().exists(key) && currentTime.equals(jedis.get().get(key))) {
                jedis.get().del(key);
                jedis.get().hdel(LOCK_KEY, lockType.getKey(), key);
                lockMap.remove(key);
                logger.info("进行对内容{} 加锁编号{} 解锁success", lockType.getKey(), uniqueNo);
            }
            logger.info("结束进行对内容{} 加锁编号{}  解锁", lockType.getKey(), uniqueNo);
        } catch (Exception e) {
            StringBuilder builder = new StringBuilder();
            builder.append("对内容{ ");
            builder.append(lockType.getKey());
            builder.append("} 加锁编号{ ");
            builder.append(uniqueNo);
            builder.append("解锁出错");
            builder.append(e);
            sendReport(builder.toString());
            logger.warn("对内容{} 加锁编号{}  解锁出错", lockType.getKey(), uniqueNo, e);
        } finally {
            closeCacheTemplete();
        }

        return flag;
    }



    public Lock() {

        try {
            openCaceTemplete();
            if (!HAVE_RESUME) {
                //尝试初始化
                EnumSet<LockType> enumSet = EnumSet.allOf(LockType.class);
                Iterator<LockType> iterator = enumSet.iterator();

                logger.info("开始进行初始化缓存值操作");
                String result;
                String key = "";
                String vla;
                while (iterator.hasNext()) {
                    key = iterator.next().getKey();
                    result = jedis.get().hget(LOCK_KEY, key);
                    if (!Regular.checkEmpty(result, null)) {
                        JSONArray array = JSONArray.parseArray(result);
                        for (Iterator<Object> _itertor = array.iterator(); _itertor.hasNext(); ) {
                            Object obj = _itertor.next();
                            vla = (String) obj;
                            if (Regular.checkEmpty(vla, null)) {
                                continue;
                            }
                            lockMap.put(vla.split(LINK)[0], vla.split(LINK)[1]);
                        }
                    }

                }
                logger.info("结束进行初始化缓存值操作");
                HAVE_RESUME = true;
            }
        } catch (Exception e) {
            logger.info("进行初始化缓存值操作出错", e);
        } finally {

            closeCacheTemplete();
        }
    }

}
