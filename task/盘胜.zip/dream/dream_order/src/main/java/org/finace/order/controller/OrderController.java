package org.finace.order.controller;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.client.HttpClient;
import org.finace.order.dao.OrderDao;
import org.finace.order.dao.ShopCartDao;
import org.finace.order.repository.MerchStockAndPriceRepository;
import org.finace.order.repository.OrderCrudRepository;
import org.finace.order.repository.OrderPayTempRepository;
import org.finace.order.repository.OrderTestRepository;
import org.finace.order.repository.ShoppingCartRepository;
import org.finace.order.repository.StandardRepository;
import org.finace.order.server.OrderBackUpService;
import org.finace.order.server.OrderService;
import org.finace.order.server.impl.OrderBackUpServiceImpl;
import org.finace.order.utils.JmsOrderSender;
import org.finace.order.utils.MD5Util;
import org.finace.order.utils.WxPayConfig;
import org.finace.utils.Regular.Regular;
import org.finace.utils.concurrent.ExecutorService;
import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.Orders;
import org.finace.utils.entity.order.ShoppingCartMerch;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.http.HttpTools;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.lock.Lock;
import org.finace.utils.operate.Response;
import org.finace.utils.prop.DataProperties;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * order的Controller
 * Created by Ness on 2016/12/16.
 */
@RestController
@RequestMapping("/order")
public class OrderController {
    

    
    @Autowired
    private OrderService os;
    @Autowired
    private OrderTestRepository otr;
    
	private Logger logger = LoggerFactory.getLogger(OrderController.class);
    
    @Autowired
    private OrderDao orderDao;
    
    @Autowired
    private DataProperties dataProperties;
    
    //1、查询所有订单（按用户)
    /**
     * 
     * @param userUuid 用户id
     * @param page 页数
     * @param pageCount 每页数据大小
     * @param order 排序方向（暂时用不上）
     * @param status 订单状态，未付款=1 待发货=2 待收货=3 待评价=4 已取消=5 已完成=6
     * @return
     */
    @RequestMapping("/listOrders")
    public Response listOrders(Integer page, Integer pageCount, Integer order, Integer status, HttpServletRequest req) {
    	if(req == null){
    		logger.warn("HttpServletRequest 为null，非网络请求！已拦截");
    		return Response.noAuthor();
    	}
    	String userUuid = (String) req.getAttribute("uuid");
    	if(userUuid == null){
    		logger.warn("查询订单的时候，userUUid为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    		return os.findOrdersByUserUuid_service(userUuid, order, page, pageCount, status);
    }
    
  //2、保存订单商品
    /**
     * 
     * @param data json字符串，具体格式查看文档，解析成订单列表
     * @param validMinutes 失效分钟
     * @return
     */
    @Resource(name="userUtils")
    private UserUtils userUtils;
    
    @RequestMapping("/saveOrders")
    public Response saveOrders (HttpServletRequest req, String data, Integer validMinutes){
    	
    	if(req == null){
    		logger.warn("HttpServletRequest 为null，非网络请求！已拦截");
    		return Response.noAuthor();
    	}
    	
    	if(data==null){
    		logger.warn("data为空!");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(validMinutes == null){
    		validMinutes = 5;
    	}
    	List<OrderTest> list = JSONArray.parseArray(data,OrderTest.class);
    	if(!Regular.checkEmpty(list, null)){
    		return os.saveOrdersInUse(list,validMinutes);
    	}else{
    		logger.warn("解析成的订单列表为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    }
    //3、按状态查询订单
    /**
     * 
     * @param userUuid 用户id
     * @return
     */
    @RequestMapping("/countNumberOfOrdersByStatus")
    public Response countNumberOfOrdersByStatus(String userUuid){
    	return os.countNumberOfOrdersByStatus(userUuid);
    }
    
    //4、改变订单状态
    /**
     * 
     * @param uuid 订单id
     * @param status 订单状态
     * @return
     */
    @RequestMapping("/changeOrderStatus")
    public Response changeOrderStatus(String uuid, Integer status){
    	return os.changeStatus(uuid, status);
    }
    //5、软删除订单
    /**
     * 
     * @param uuid 订单id
     * @param deletedPersonUuid 删除者的id
     * @return
     */
    @RequestMapping("/setOrderDeleted")
    public Response setOrderDeleted(String uuid ,String deletedPersonUuid){
		return os.setOrderDeleted(uuid, deletedPersonUuid);
    }
    
    //6、查看订单详情
    /**
     * 
     * @param order_uuid 订单id
     * @return
     */
    @RequestMapping("/showSingleOrder")
    public Response showSingleOrder(String order_uuid){
    	return os.findOrderTestsbyOrderUuid(order_uuid);
    }
    //7、显示购物车
    /**
     * 
     * @param userUuid 用户id
     * @param page 页数
     * @param pageCount 每页大小
     * @return
     */
    @RequestMapping("/showShoppingCart")
    public Response showShoppingCart(String userUuid,Integer page, Integer pageCount){
    	return os.loadAllShopCartMerchByUserUuid(userUuid,page,pageCount);
    		
    }
    //8、删除购物车商品
    /**
     * 
     * @param data 购物车条目数据，解析出来的购物车条目列表中包含购物车条目的uuid
     * @return
     */
    @RequestMapping("/deleteShoppingCartMerch")
    public Response deleteShoppingCartMerch(String data){
    	if(data==null){
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    		List<ShoppingCartMerch> list = JSONArray.parseArray(data,ShoppingCartMerch.class);
    		if(Regular.checkEmpty(list, null)){
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    	return os.deleteShoppingCartMerch(list);
    }
    
    
    //9、更新购物车中的商品数目
    /**
     * 
     * @param uuid 购物车条目的id
     * @param number 购物车条目的数量
     * @return
     */
    @RequestMapping("/changeCartMerchQuantity")
    public Response changeCartMerchQuantity(String uuid, Integer number){
    	return os.changeCartMerchQuantity(uuid,number);
    }
    
    
    //10、添加商品到购物车
    /**
     * @param data 购物车条目
     * @param userUuid 用户id
     * @return
     */
    @RequestMapping("/saveShopCartMerch")
    public Response saveShopCartMerch(String data,String userUuid){
    
    		if(data==null){
    			logger.warn("传入data数据为空！");
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		if(userUuid==null){
    			logger.warn("用户uuid为空！");
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		
    	List<ShoppingCartMerch> list = JSONArray.parseArray(data,ShoppingCartMerch.class);
    	
    	if(Regular.checkEmpty(list, null)){
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    		return os.saveShopCartMerch(list,userUuid);
    }
    /**
     * 11.订单提交付款
     */
    @RequestMapping("/payOrder")
    public Response payOrder(HttpServletRequest req, Integer payType, String userUuid, String data, Double totalPrice, Double balancePrice, String body, String subject){
    	if(data == null){
    		logger.warn("提交付款时，订单data为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(payType == null){
    		logger.warn("提交付款时，payType为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	logger.warn("订单提交付款的时候，从req里获取uuid=== {} ===",req.getAttribute("uuid"));
    	
    	if(userUuid == null){
    		logger.warn("提交付款时，userUuid为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(totalPrice == null){
    		logger.warn("提交付款时，totalPrice为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(balancePrice == null){
    		logger.warn("提交付款时，balancePrice为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(body == null){
    		logger.warn("提交付款时，body为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(subject == null){
    		logger.warn("提交付款时，subject为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	return os.payOrder(payType, data, userUuid, totalPrice, balancePrice, body, subject);
    	
    }
    
    /**
     * 12.购物车商品更改规格
     */
    //如果购物车中有该商品的目的规格条目，那么将原有条目删除，在目的条目上增加数量。如果购物车中没有目的商品的目的规格，那么将商品不变，规格更改。
    /**
     * 
     * @param userUuid 用户id
     * @param uuid 购物车条目id
     * @param merchUuid 商品id
     * @param merchStandardIndex 购物车条目中对应商品要更改成规格
     * @param quantity 要改成的数量
     * @return
     */
    @RequestMapping("/changeShoppingcartMerchStandard")
    public Response changeShoppingcartMerchStandard(String userUuid, String uuid, String merchUuid, String merchStandardIndex, Integer quantity){
    	return os.changeShoppingcartMerchStandard(userUuid, uuid, merchUuid, merchStandardIndex, quantity);
    }
    
    /**
     * 13.根据订单的生成批号查询刚才生成的订单
     */
    /**
     * 
     * @param reCheckId 生成订单时异步生成的重复查询id，根据此id可以查询刚才生成的所有订单
     * @return
     */
    @RequestMapping("/loadOrdersByReCheckId")
    public Response loadOrdersByReCheckId(String reCheckId){
    	if(reCheckId==null){
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	JSONObject json = new JSONObject();
    	List<OrderTest> list = otr.loadOrdersByReCheckId(reCheckId);
    	json.put("content", list);
    	return Response.success(json);
    }
    
    /**
     * 14.查询商品规格
     */
    /**
     * 
     * @param merchUuid 商品id
     * @return
     */
    @RequestMapping("/loadMerchStandardIndex")
    public Response loadMerchStandardIndex(String merchUuid){
    	if(merchUuid==null){
    		merchUuid = "6836191203976ab055ec20c59da44efe50a9cbf95";
    	}
    	return os.loadMerchStandardIndex(merchUuid);
    }
    
    /**
     * 15.通知服务端app端付款成功
     * 
     */
    @RequestMapping("/appPayResultInfo")
    public Response appPayResultInfo(String out_trade_no, String userUuid, String random_code){
    	return os.appPayResultInfo(out_trade_no, userUuid, random_code);
    }
    
    /**
     * 16.查询付款结果（多次请求，解决app结果快于第三方的问题）
     */
    
    @RequestMapping("/checkPaymentPayed")
    public Response checkPaymentPayed(String paymentNo){
    	if(paymentNo == null){
    		logger.warn("paymentNo为null");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	return os.checkPaymentPayed(paymentNo);
    }
    
    @RequestMapping("/checkThirdPayResult")
    public Response checkThirdPayResult(String paymentNo){
    	if(paymentNo == null){
    		logger.warn("paymentNo为null");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	return os.checkThirdPayResult(paymentNo);
    }
    /**
     * 提醒发货
     */
    @RequestMapping("/remindDelivery")
    public Response remindDelivery(String orderNo){
    	
    	
    	
    	
    	return os.remindDelivery(orderNo);
    }
    
    /**
     * 游客模式
     */
    
    /**
     * 1.查看一个用户的所有订单
     */
    @RequestMapping("/listOrders/tourist")
    public Response listOrdersTourist(String userUuid, Integer page, Integer pageCount, Integer order, Integer status){
    	if(userUuid == null){
    		userUuid = "user007";
    	}
    	return null;
    	//return this.listOrders(page, pageCount, order, status, null);
    }
    
   

    /**
     * 2.保存订单
     */
    public JSONArray addJson(JSONArray array){
    	
    	JSONObject json = new JSONObject();
    	json.put("totalPrice", 430);
    	json.put("userUuid", "nidaye");
    	json.put("isFlashSale", false);
    	json.put("merchandiserUuid", "92194912083c306b0bdb9b948cc44c36469372635");
    	json.put("merchandiserName", "百家旺7");
    	json.put("merchUuidStringArr", new String[]{"9263202205162b7aef88317db0504094ac4c17aff","530450220e9c739c456fbe12ad7847d43a4e58c05","530450220e9c739c456fbe12ad7847d43a4e58c05","530450220e9c739c456fbe12ad7847d43a4e58c05","530450220e9c739c456fbe12ad7847d43a4e58c05","530450220e9c739c456fbe12ad7847d43a4e58c05","530450220e9c739c456fbe12ad7847d43a4e58c05","530450220e9c739c456fbe12ad7847d43a4e58c05"});
    	//json.put("merchPic", new String[]{"http://sucai.dabaoku.com/meishu/logo/077cy.jpg","http://sucai.dabaoku.com/meishu/logo/077cy.jpg"});
    	json.put("merchNameStringArr", new String[]{"随机生成名字15","随机生成名字15","随机生成名字15","随机生成名字15","随机生成名字15","随机生成名字15","随机生成名字15","随机生成名字15"});
    	json.put("merchPriceStringArr", new String[]{"80","50","50","50","50","50","50","50"});
    	json.put("merchSpecStringArr", new String[]{"黑色,xl","白色,xl","白色,xl","白色,xl","白色,xl","白色,xl","白色,xl","白色,xl"});
    	//json.put("merchStandardUuid", new String[]{"6421394803572498cd4abe7b82d847e885cfcf0e3","033139480eb8b01b2cc709d2b8b9423a9ee646c7d"});
    	json.put("merchStandardIndexStringArr", new String[]{"0,2","2,0","2,0","2,0","2,0","2,0","2,0","2,0"});
    	json.put("merchQuantityStringArr", new String[]{"1","1","1","1","1","1","1","1"});
    	json.put("orderMessage", "订单留言");
    	json.put("receiveAddressDetail", "浙江省杭州市！");
    	json.put("isAnonymous", false);
    	json.put("isFromCart", true);
    	array.add(json);
    	return array;
    }
    
    @RequestMapping("/saveOrders/tourist")
    public Response saveOrderstourist (String data){
    	
    	JSONArray array = new JSONArray();
    	array = addJson(array);
    	data = array.toJSONString();
    	List<OrderTest> list = JSONArray.parseArray(data,OrderTest.class);
    	if(!Regular.checkEmpty(list, null)){
    		return os.saveOrdersInUse(list,15);
    	}else{
    		logger.warn("解析成的订单列表为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	
    	
//    	List<OrderTest> list = JSONArray.parseArray(array.toJSONString(),OrderTest.class);
    	
    	
    	//return this.saveOrders(data, 15);
    	
    }
    
  /**
   * 3.按状态查询订单
   */
    @RequestMapping("/countNumberOfOrdersByStatus/tourist")
    public Response countNumberOfOrdersByStatus_tourist(String userUuid){
//    	return null;
    	return this.countNumberOfOrdersByStatus(userUuid);
    }
  /**
   * 4、改变订单状态
   */
    @RequestMapping("/changeOrderStatus/tourist")
    public Response changeOrderStatus_tourist(String uuid, Integer status){
    	return this.changeOrderStatus(uuid, status);
    }
  /**
   * 5、软删除订单
   */
    @RequestMapping("/setOrderDeleted/tourist")
    public Response setOrderDeleted_tourist(String uuid ,String deletedPersonUuid){
		return this.setOrderDeleted(uuid, deletedPersonUuid);
    }
    
    /**
     * 6、查看订单详情
     */
    @RequestMapping("/showSingleOrder/tourist")
    public Response showSingleOrdertourist(String order_uuid){
    	if(order_uuid==null){
    		order_uuid = "20170105526515142906594628967581738204";
    	}
    	return this.showSingleOrder(order_uuid);
    }
    /**
     * 7.查看一个用户的购物车
     */
    
	@RequestMapping("/showShoppingCart/tourist")
    public Response showShoppingCarttourist(String userUuid, Integer page, Integer pageCount){
    	if(userUuid==null){
    		userUuid = "351050030d75fae120320092bb9241276ad6ab56d";
    	}

    	return this.showShoppingCart(userUuid, page, pageCount);
    }
    /**
     * 8.删除购物车中的商品
     */
    @RequestMapping("/deleteShoppingCartMerch/tourist")
    public Response deleteShoppingCartMerch_tourist(String data){
    	if(data==null){
    		data = "[{'uuid':'7735502203f629fe51fdfa9c8de04c37109e24d27'},{'uuid':'083944131b34d3e916795af6b6ff4234b894b8a93'}]";
    	}
    		
    	return this.deleteShoppingCartMerch(data);
    }
    
    /**
     * 9、更新购物车中的商品数目
     */
    @RequestMapping("/changeCartMerchQuantity/tourist")
    public Response changeCartMerchQuantity_tourist(String uuid, Integer number){
    	if(uuid == null){
    		uuid="99565748084943cf415c60639f8e44f6ac94f785f";
    	}
    	if(number == null){
    		number=108;
    	}
    	return this.changeCartMerchQuantity(uuid, number);
    }
    
    
    public JSONArray addToShopCart(JSONArray array){
    	JSONObject json = new JSONObject();
    	json.put("merchStandardIndex", "0,1");
    	json.put("merchUuid", "7735502203f629fe51fdfa9c8de04c37109e24d27");
    	json.put("quantity", 1);
    	json.put("userUuid", "测试用户007");
    	array.add(json);
    	return array;
    	
    }
    /**
     * 10.保存商品到购物车
     */
    @RequestMapping("/saveShopCartMerch/tourist")
    public Response saveShopCartMerchtourist(String data,String userUuid){
    	JSONArray array = new JSONArray();
    	array = addToShopCart(array);

    	
    	data = array.toJSONString();
    	userUuid = "测试用户007";
    	return this.saveShopCartMerch(data, userUuid);
    }
    
    
    /**
     * 12.购物车商品更改规格
     */
    //如果购物车中有该商品的目的规格条目，那么将原有条目删除，在目的条目上增加数量。如果购物车中没有目的商品的目的规格，那么将商品不变，规格更改。
    @RequestMapping("/changeShoppingcartMerchStandard/tourist")
    public Response changeShoppingcartMerchStandard_tourist(String userUuid, String uuid, String merchUuid, String merchStandardIndex, Integer quantity){
    	
    	userUuid = "测试用户007";
    	uuid = "952023160e579b113177c958984d4661f572b8286";
    	merchUuid = "7735502203f629fe51fdfa9c8de04c37109e24d27";
    	merchStandardIndex = "0,0";
    	quantity = 100;
    	return this.changeShoppingcartMerchStandard(userUuid, uuid, merchUuid, merchStandardIndex, quantity);
    }
    /**
     * 14.查看商品规格
     */
    @RequestMapping("/loadMerchStandardIndex/tourist")
    public Response loadMerchStandardIndex_tourist(String merchUuid, HttpServletRequest req){
    	if(merchUuid==null){
    		merchUuid = "32712022055a4036b3f97fdb97a54d0043f0bdddd";
    	}
    	return this.loadMerchStandardIndex(merchUuid);
    }
    
    
    
    /**
     * 测试
     */
    @Autowired
    private ShopCartDao scd;
    @Autowired
    private OrderPayTempRepository optr;
    @Autowired
    private ShoppingCartRepository scr;
    
    @Autowired
	private ExecutorService executorService;
    
    
    @Autowired
	private JmsSender jmsSender;
    
    private DateTimeFormatter formatter=DateTimeFormatter.ofPattern("ss mm HH dd MM ?");
    
    @Autowired
    private OrderPayTempRepository orderPayTempRepository;
    @Autowired
    private OrderCrudRepository ocr;
    @Autowired
    private Lock lock;
    
    @Autowired
    private MerchStockAndPriceRepository msapr;
    
    @Resource(name="jmsOrderSender")
    private JmsOrderSender jmsOrderSender;
    
    @RequestMapping("/test_3/tourist")
    public String test_3(){
    	
    	return "123123";
    }
    
    @RequestMapping("appPayResultInfo/tourist")
    public Response appPayResultInfo_tourist(String out_trade_no){
    	logger.warn("接收到app端的付款成功通知！");
    	return this.appPayResultInfo( out_trade_no, null, null);
    }
    
    @RequestMapping("thirdPayResultInfo/tourist")
    public String thirdPayResultInfo(HttpServletRequest req){
    	logger.warn("接收到第三方的付款成功通知！");
    	return os.thirdPayResultInfo(req);
    }
    @RequestMapping("wxPayCallbackResult/tourist")
    public String wxPayCallbackResult(HttpServletRequest req){
    	logger.warn("接收到微信的付款成功通知！");
    	return os.wxPayCallbackResult(req);
    }
    
    @RequestMapping("/saveOrderList")
    public Response saveOrderList(String data, Integer inValidMinutes){
    	
    	//List<Orders> orderList = JSONArray.parseArray(data, Orders.class);
    	obrs.saveOrders(data,1);
    	
    	return null;
    }
    @RequestMapping("/saveOrderList/tourist")
    public Response saveOrderList_tourist(String data){
    	
    	
    	this.saveOrderList(data,1);
    	return null;
    }
    
    
//    @Autowired
//   private OrderCrudRepository ocr;
//    @Autowired
//    private OrderMerchCrudRepository omcr;
	@RequestMapping("/test/tourist")
	@Transactional
    public Response test_0(HttpServletRequest req){
		//logger.warn("====req.getHeader('token')==={}",req.getHeader("uuid"));
		//System.out.println(optr.loadAllOrderPayTemp("754543050aa54144c9b1d4ab82a9457a7dc3263bd").get(0).toString());
		//return Response.success();
		return Response.error();
//		return null;
		//return this.payOrder(2, "[{'totalPrice':'0.01','orderNo':'2017022540216763844227230891308454687004'}]", "612803130e4658a62fce5acc89084969597156dd6", 0.01, 0.00, "123", "321");
    }
	
	@RequestMapping("/payOrder/tourist")
	public Response payOrder_test(Integer payType, String data, String userUuid, Double totalPrice, Double balancePrice, String body, String subject){
		//return this.payOrder(null,payType, data, totalPrice, balancePrice, body, subject);
		return null;
	}
	
    
    @Autowired
    private StandardRepository sr;
    
    @RequestMapping("/test_1/tourist")
    public  void test_1(){
    	String merchUuid = "95380923078ad4b4e486d7a28c634afcf1ba633e2";
    	MerchandiseStandard ms = otr.loadMerchandiseStandard(merchUuid).get(0);
    	String [] tcn = new String [1];
    	tcn[0] = "颜色";
    	String [][] secondCateGoryName = new String [][]{
    			new String[]{
    					"黑色","白色","绿色"
    			}
    	};
    	ms.setTopCategoryName(tcn);
    	ms.setSecondCateGoryName(secondCateGoryName);
    	sr.save(ms);
    }
    @Autowired
    private OrderBackUpService obrs;
    public static void main(String[] args) {
//    	ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
//    	OrderController orderController = (OrderController) context.getBean("orderController");
    
    	String body = "body";
    	String out_trade_no = "out_trade_no";
    	Double totalPrice = 0.01;
    	SortedMap<String, String> packageParams = new TreeMap<>();
		packageParams.put("appid", WxPayConfig.appid);
		packageParams.put("mch_id", WxPayConfig.partner);
		packageParams.put("nonce_str", UserUtils.generateOrderNo());
		packageParams.put("body", body);
		packageParams.put("out_trade_no", out_trade_no);
		packageParams.put("total_fee", Math.round(totalPrice*100)+"");
		//packageParams.put("spbill_create_ip", req.getRemoteAddr());
		packageParams.put("spbill_create_ip", "192.168.121.1");
		packageParams.put("notify_url", WxPayConfig.notify_url);
		packageParams.put("trade_type", WxPayConfig.trade_type);
		String sign = MD5Util.createSign(packageParams);
		System.out.println(sign);
		packageParams.put("sign", sign);

		SortedMap<String,Object> objMap = new TreeMap<>();

		objMap.put("appid", WxPayConfig.appid);
		objMap.put("mch_id", WxPayConfig.partner);
		objMap.put("nonce_str", UserUtils.generateIncrementId());
		objMap.put("body", body);
		objMap.put("out_trade_no", out_trade_no);
		objMap.put("total_fee", Math.round(totalPrice*100)+"");
		objMap.put("spbill_create_ip", "192.168.121.1");
		objMap.put("notify_url", WxPayConfig.notify_url);
		objMap.put("trade_type", WxPayConfig.trade_type);
		objMap.put("sign", sign);


		StringBuilder builder = new StringBuilder();
		builder.append("<xml>");
		builder.append("<appid>");
		builder.append(WxPayConfig.appid);
		builder.append("</appid>");
		builder.append("<mch_id>");
		builder.append(WxPayConfig.partner);
		builder.append("</mch_id>");
		builder.append("<nonce_str>");
		builder.append(packageParams.get("nonce_str"));
		builder.append("</nonce_str>");
		builder.append("<sign>");
		builder.append(sign);
		builder.append("</sign>");
		builder.append("<body><![CDATA[");
		builder.append(body);
		builder.append("]]></body>");
		builder.append("<out_trade_no>");
		builder.append(out_trade_no);
		builder.append("</out_trade_no>");
		builder.append("<total_fee>");
		builder.append(packageParams.get("total_fee"));
		builder.append("</total_fee>");
		builder.append("<spbill_create_ip>");
		builder.append(packageParams.get("spbill_create_ip"));
		builder.append("</spbill_create_ip>");
		builder.append("<notify_url>");
		builder.append(packageParams.get("notify_url"));
		builder.append("</notify_url>");
		builder.append("<trade_type>");
		builder.append(WxPayConfig.trade_type);
		builder.append("</trade_type>");
		builder.append("</xml>");
		String prepay_id = HttpTools.doPostsByStr("https://api.mch.weixin.qq.com/pay/unifiedorder", builder.toString());
		
		System.out.println(prepay_id);
	}
    
    
}
