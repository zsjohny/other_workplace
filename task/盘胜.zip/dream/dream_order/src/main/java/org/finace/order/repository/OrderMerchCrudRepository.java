package org.finace.order.repository;

import java.util.List;

import org.finace.utils.entity.order.OrderMerch;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface OrderMerchCrudRepository extends CrudRepository<OrderMerch,Integer> {
	
	@Query("select new OrderMerch(quantity, merchUuid, merchStandardIndex) from OrderMerch where orderNo=:orderNo")
	List<OrderMerch> loadOrderMerchList(@Param("orderNo") String orderNo);
}
