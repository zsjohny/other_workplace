package org.finace.order.controller;

import javax.servlet.http.HttpServletRequest;

import org.finace.order.repository.OrderCrudRepository;
import org.finace.order.server.OrderBackUpService;
import org.finace.order.server.impl.OrderBackUpServiceImpl;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

@RestController
@RequestMapping("/orderInfo")
public class OrderControllerBackUp {
	@Autowired
	private OrderBackUpService obus;
	
	@Autowired
	private OrderCrudRepository ocr;
	
//	@Autowired
	private HttpServletRequest request;
	
	private Logger logger = LoggerFactory.getLogger(OrderControllerBackUp.class);
	
	@RequestMapping("saveOrder")
	public Response saveOrders(String data, Integer validMinutes){
		if(data == null){
			
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(validMinutes == null){
			validMinutes = 1440;
		}
		return obus.saveOrders(data,validMinutes);
	}
	@RequestMapping("listOrders")
	public Response listOrders(Integer page, Integer pageCount){
		if(request == null){
			logger.warn("listOrders 方法 request == null");
			return Response.error("request == null");
		}
		String userUuid = (String) request.getAttribute("uuid");
		if(userUuid == null){
			logger.warn("userUuid == null");
			return Response.error("userUuid == null");
		}
		return obus.listOrders(userUuid, page, pageCount);
	}
	@RequestMapping("showSingleOrder")
	public Response showSingleOrder(String orderNo){
		if(orderNo == null){
			logger.warn("showSingleOrder方法 orderNo == null");
			Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		return obus.showSingleOrder(orderNo);
	}
	@RequestMapping("")
	
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
		OrderControllerBackUp orderController = (OrderControllerBackUp) context.getBean("orderControllerBackUp");
		System.out.println(JSONObject.toJSONString(orderController.showSingleOrder("201703141429294436117834243826")));
	}
}
