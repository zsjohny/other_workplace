package org.finace.order.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface StandardRepository extends CrudRepository<MerchandiseStandard, Integer>,JpaSpecificationExecutor<MerchandiseStandard>{
	
	@Query("from MerchandiseStandard where merchUuid=:merchUuid")
	List<MerchandiseStandard> loadMerchandiseStandard (@Param("merchUuid")String merchUuid);
	@Query("from MerchandiseStandard")
	List<MerchandiseStandard> loadMerchandiseStandard ();
	
	
}
