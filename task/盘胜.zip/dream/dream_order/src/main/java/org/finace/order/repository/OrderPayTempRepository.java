package org.finace.order.repository;

import java.util.List;

import javax.persistence.LockModeType;

import org.finace.utils.entity.order.OrderPayTemp;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface OrderPayTempRepository extends CrudRepository<OrderPayTemp,Integer>, JpaSpecificationExecutor<OrderPayTemp> {
	
	@Query("from OrderPayTemp where paymentNo=:out_trade_no")
	List<OrderPayTemp> loadAllOrderPayTemp(@Param("out_trade_no") String out_trade_no);
	
	@Modifying
	@Transactional 
	@Query("update OrderPayTemp set appResult=1 where paymentNo=:out_trade_no")
	void setAppResultTrue(@Param("out_trade_no") String out_trade_no);
	@Modifying
	@Transactional 
	@Query("update OrderPayTemp set thirdPayResult=1 where paymentNo=:out_trade_no")
	void setThirdResultTrue(@Param("out_trade_no") String out_trade_no);
	
	@Modifying
	@Transactional 
	@Query("update OrderPayTemp set payed=true where paymentNo=:out_trade_no")
	void setPaymentPayed(@Param("out_trade_no") String out_trade_no);
	@Modifying
	@Transactional 
	@Query("update OnePaymentNoToManyOrderNo set payed=true where paymentNo=:out_trade_no")
	void setOnePaymentNoToManyOrderNoayed(@Param("out_trade_no") String out_trade_no);
	
	@Query("select payed from OrderPayTemp where paymentNo=:paymentNo")
	List<Boolean> checkPaymentPayed(@Param("paymentNo")String paymentNo);
	
	@Query("select thirdPayResult from OrderPayTemp where paymentNo=:paymentNo")
	List<Integer> checkThirdPayResult(@Param("paymentNo")String paymentNo);
	
}
