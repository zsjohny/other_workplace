package org.finace.order.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.TempStockCheck;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface OrderTestRepository extends CrudRepository<OrderTest, Integer>,JpaSpecificationExecutor<OrderTest>{
	
	@Modifying
	@Transactional  
	@Query("update OrderTest set status=:status,updateTime=:updateTime where uuid=:uuid")
    void changeOrderTestStatus(@Param("uuid") String uuid, @Param("status")Integer status,@Param("updateTime") Timestamp updateTime);

	@Modifying
	@Transactional  
	@Query("update OrderTest set status=:status,updateTime=:updateTime where orderNo=:orderNo")
    void changeOrderStatusByOrderNo(@Param("orderNo") String orderNo, @Param("status")Integer status,@Param("updateTime") Timestamp updateTime);
	
	
	@Modifying
	@Transactional  
	@Query("update OrderTest set deleted=1, updateTime=:deleteTime,deletedPersonUuid=:deletedPersonUuid where uuid=:uuid ")
    void setOrderTestDeleted(@Param("uuid") String uuid, @Param("deletedPersonUuid")String deletedPersonUuid, @Param("deleteTime")Timestamp deleteTime);

	@Query("from MerchandiseStandard where merchUuid=:merchUuid")
	List<MerchandiseStandard> loadMerchandiseStandard (@Param("merchUuid")String merchUuid);
	
	 @Query("select new OrderTest(totalPrice,uuid,orderNo,"
	    		+ "createTime,"
	    		+ "status,merchandiserName,merchUuid,merchPic,merchName,merchPrice,merchSpec,merchStandardUuid,merchStandardIndex,merchQuantity,orderMessage,isAnonymous,receiveAddressDetail) from OrderTest where uuid=:uuid")
	List <OrderTest> findOrderTestsbyOrderUuid(@Param("uuid")String uuid);
	@Query("select status,count(1) from  OrderTest where userUuid=:userUuid group by status")
    List<Object[]> countNumberOfOrdersByStatus(@Param("userUuid") String userUuid);
    @Query("select status from OrderTest where uuid=:uuid")
    Integer loadStatuOfOrderTest(@Param("uuid")String uuid);
    @Query("select status from OrderTest where orderNo=:orderNo")
    Integer loadStatuOfOrderByOrderNo(@Param("orderNo")String orderNo);
    @Query("from OrderTest where orderNo=:orderNo")
    List<OrderTest> loadOrderTestByOrderNo(@Param("orderNo")String orderNo);
    
    @Query("select count(1) from OrderPayTemp where orderNo=:orderNo")
    int countPayOrderNo(@Param("orderNo")String orderNo);
    
    @Query("select new OrderTest(totalPrice,status,userUuid,merchandiserUuid) from OrderTest where orderNo=:orderNo")
    List<OrderTest> loadPriceAndStatusOfSingleOrder(@Param("orderNo") String orderNo);
    @Query("select new OrderTest(status,merchUuid,merchStandardIndex,merchQuantity) from OrderTest where orderNo=:orderNo")
    List<OrderTest> loadOrderAfterInValid(@Param("orderNo") String orderNo);
    
    
    @Query("select id from Merchandiser")
    List<Integer> loadMerchandiserlist();
    
    @Modifying
	@Transactional  
    @Query("delete TimeTask where params =:params")
    void deleteTimerTask(@Param("params") String params);
    
    @Query("from OrderTest where reCheckId=:reCheckId")
    List<OrderTest> loadOrdersByReCheckId(@Param("reCheckId") String reCheckId);
    
    @Query(nativeQuery=true,value="select merchName from orderTest where id=19412")
    Object loadOrderTestTest();
    @Query("select new OrderTest(merchName) from OrderTest where id=19438")
    OrderTest loadOrderTestTest123();
    @Query(nativeQuery=true,value="select topCategoryNameByteArr from merchandiseStandard where id = 5890")
    Object loadMerchStandardTest();
    @Query("select new OrderTest(totalPrice,uuid,orderNo,"
    		+ "createTime,"
    		+ "status,merchandiserName,merchUuid,merchPic,merchName,merchPrice,merchSpec,merchStandardUuid,merchStandardIndex,merchQuantity,orderMessage,isAnonymous,receiveAddressDetail) from OrderTest where userUuid=:userUuid and status=:status and deleted=false order by createTime desc")
    List<OrderTest> listAllOrdersByUserUuid(@Param("userUuid") String userUuid,@Param("status") Integer status,Pageable pageable);
    
    @Query("select new OrderTest(totalPrice,uuid,orderNo,"
    		+ "createTime,"
    		+ "status,merchandiserName,merchUuid,merchPic,merchName,merchPrice,merchSpec,merchStandardUuid,merchStandardIndex,merchQuantity,orderMessage,isAnonymous,receiveAddressDetail) from OrderTest where userUuid=:userUuid and deleted=false order by createTime desc")
    List<OrderTest> listAllOrdersByUserUuidAllStatus(@Param("userUuid") String userUuid,Pageable pageable);
    
    
    @Query(nativeQuery=true, value="select count(1) from merchandiser where uuid = ?1")
    int countIfMerchandiseExist(String uuid);
    
    @Query(nativeQuery=true, value="select merchBelongToUuid from merchandise where uuid = ?1")
    String loadBelongToUuid(String uuid);
    @Modifying
  	@Transactional  
      @Query("update OrderTest set autoConfirmed = :autoConfirmed where uuid =:uuid")
    void setOrderAutoConfirmed(@Param("autoConfirmed") Boolean autoConfirmed, @Param ("uuid") String uuid);
    
    @Query("select new OrderTest(orderNo, totalPrice, status, merchandiserUuid) from OrderTest where uuid=:uuid")
    List<OrderTest> selectOrderWhenConfirm(@Param("uuid")String uuid);
    
}
