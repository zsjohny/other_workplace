package org.finace.order.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.MerchStockAndPrice;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface MerchStockAndPriceRepository extends CrudRepository<MerchStockAndPrice,Integer>, JpaSpecificationExecutor<MerchStockAndPrice> {

	
	
	@Modifying
	@Transactional
	@Query("update MerchStockAndPrice set stock=stock-:quantity where  merchUuid=:merchUuid and merchStandardIndex = :merchStandardIndex and stock>=:quantity and price=:price")
	int checkStockAndPrice(@Param("quantity")Integer quantity,@Param("price")Double price,@Param("merchUuid")String merchUuid,@Param("merchStandardIndex")String merchStandardIndex);
	@Modifying
	@Transactional
	@Query("update MerchStockAndPrice set stock=stock+:quantity where  merchUuid=:merchUuid and merchStandardIndex = :merchStandardIndex")
	int increaseMerchStock(@Param("quantity")Integer quantity,@Param("merchUuid")String merchUuid,@Param("merchStandardIndex")String merchStandardIndex);
	
	
	@Query("select merchLog from Merchandise where uuid= :uuid")
	String loadMerchLogPic(@Param("uuid") String uuid);
	
	@Query("from MerchandiseStandard m where merchUuid=:merchUuid and deleted=false")
	List<MerchandiseStandard> loadMerchandiseStandard(@Param("merchUuid")String merchUuid);
	
	@Query("select new MerchandiseStandard(dimension,topCategoryNameByteArr,secondCateGoryNameByteArr,secondCateGoryNameByteArr_2) from MerchandiseStandard where merchUuid=:merchUuid")
	List<MerchandiseStandard> loadMerchandiseStandardByteArr(@Param("merchUuid")String merchUuid);
	@Query("from MerchStockAndPrice where merchUuid=:merchUuid")
	List<MerchStockAndPrice> loadMerchStockAndPrice(@Param("merchUuid")String merchUuid);
	
	
	
}
