package org.finace.order.utils;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.finace.utils.jms.JmsSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class JmsOrderSender {
	 	private JmsTemplate jmsTemplate;
	    private Destination destination;
	    private Logger logger = LoggerFactory.getLogger(JmsOrderSender.class);

	    /**
	     * 发送消息队列
	     *
	     * @param msg 需要发送的消息
	     */
	    public void sendMsg(final String msg) {
	        logger.info("开始发送消息组={},消息{}", destination, msg);
	        try {
	            jmsTemplate.send(destination, new MessageCreator() {

	                @Override
	                public Message createMessage(Session session) throws JMSException {
	                    TextMessage result = session.createTextMessage(msg);
	                    return result;
	                }

	            });
	            logger.info("结束发送消息组={},消息{}", destination, msg);
	        } catch (Exception e) {
	            logger.warn("发送消息组={},消息{}出错", destination, msg, e);
	        }

	    }

	    public JmsTemplate getJmsTemplate() {
	        return jmsTemplate;
	    }

	    public void setJmsTemplate(JmsTemplate jmsTemplate) {
	        this.jmsTemplate = jmsTemplate;
	    }

	    public Destination getDestination() {
	        return destination;
	    }

	    public void setDestination(Destination destination) {
	        this.destination = destination;
	    }
}
