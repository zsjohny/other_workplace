package org.finace.order.server;

import org.finace.utils.operate.Response;

import com.alibaba.fastjson.JSONArray;

public interface OrderBackUpService {

	Response saveOrders(String data, Integer validMinutes);

	JSONArray getOrderData();

	Response listOrders(String userUuid, Integer page, Integer pageCount);

	Response showSingleOrder(String orderNo);

	Response countNumberOfOrdersByStatus(String userUuid);

}
