package org.finace.order.repository;

import java.sql.Timestamp;
import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.ShoppingCartMerch;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by OTboy on 2016/12/24.
 */
public interface ShoppingCartRepository extends CrudRepository<ShoppingCartMerch,Integer>, JpaSpecificationExecutor<ShoppingCartMerch>{
	
    
    
//    @Query("")
//    int countShopCartByReceivedDatas(@Param("userUuid") String userUuid, @Param("uuid") String uuid, @Param("merchUuid")String merchUuid, @Param("merchStandardIndex")String merchStandardIndex);
    
    @Query("select new MerchandiseStandard(secondCateGoryName) from MerchandiseStandard where merchUuid=:merchUuid")
    List<MerchandiseStandard> loadSecondCateGoryNameArrayByMerchUuid(@Param("merchUuid") String merchUuid);
    
    @Query("select scm, mr.uuid,mr.name, msap.price,msap.stock,m.deleted,ms.secondCateGoryName,m.merchName,m.merchLog from ShoppingCartMerch scm left join Merchandise m with scm.merchUuid=m.uuid left join Merchandiser mr with m.merchBelongToUuid=mr.uuid left join MerchandiseStandard ms with scm.merchUuid=ms.merchUuid left join MerchStockAndPrice msap with (scm.merchUuid=msap.merchUuid and scm.merchStandardIndex=msap.merchStandardIndex) where scm.userUuid=:userUuid order by scm.createTime desc")
    List<Object[]> loadAllShopCartMerchByUserId(@Param("userUuid") String userUuid,Pageable pageable);
    
    
    
    @Query("select count(1) from ShoppingCartMerch where uuid=:uuid")
    int countShopCartMerchByUuid(@Param("uuid")String uuid);
    
    
    @Query("from ShoppingCartMerch where uuid=:uuid")
    List<ShoppingCartMerch> loadSingleShopCartMerchByUuid(@Param("uuid")String uuid);
    
    
    @Modifying
	@Transactional  
	@Query("delete ShoppingCartMerch where uuid = :uuid ")
    void deleteShoppingCartMerch(@Param("uuid") String uuid);
    
    @Modifying
	@Transactional  
	@Query("update ShoppingCartMerch set quantity=:number where  uuid = :uuid ")
    void changeCartMerchQuantity(@Param("uuid")String uuid, @Param("number") Integer number);
    
    @Modifying
	@Transactional  
	@Query("update ShoppingCartMerch set quantity=:number, createTime=:createTime where uuid=:uuid ")
    void addGoodToCart(@Param("uuid")String uuid, @Param("number") Integer number, @Param("createTime") Timestamp createTime);
    
	
    
    @Modifying
   	@Transactional  
   	@Query("update ShoppingCartMerch set quantity=:quantity, merchStandardIndex=:merchStandardIndex where  uuid = :uuid ")
       void changeCartMerchStandard(@Param("uuid")String uuid, @Param("quantity") Integer quantity,
    		   @Param("merchStandardIndex") String merchStandardIndex
    		   );
    
    
	@Query("select new ShoppingCartMerch(quantity,uuid) from ShoppingCartMerch where merchUuid=:merchUuid and  userUuid=:userUuid and merchStandardIndex=:merchStandardIndex")
    List<ShoppingCartMerch> checkShoppingCartMerchNumber(@Param("merchUuid")String merchUuid, @Param("merchStandardIndex") String merchStandardIndex, @Param("userUuid") String userUuid);
	
	   @Modifying
		@Transactional  
		@Query("delete ShoppingCartMerch where merchUuid = :merchUuid and merchStandardIndex=:merchStandardIndex and userUuid = :userUuid ")
	    void deleteShoppingCartMerchByIdAndIndex(@Param("merchUuid") String merchUuid,@Param("merchStandardIndex") String merchStandardIndex,@Param("userUuid") String userUuid);

	
	
}
