package org.finace.order.listener;

import org.finace.utils.jms.JmsListenter;

public class OrderReiceiveListener_1 implements JmsListenter{

	@Override
	public void onMsg(String msg) {
		if(msg.equals("1234")){
			System.out.println("士大夫撒旦法师的法师打发士大夫士大夫撒旦");
		}
		
	}

}
