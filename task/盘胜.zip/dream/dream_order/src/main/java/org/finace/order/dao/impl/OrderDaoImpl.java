package org.finace.order.dao.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.finace.order.dao.OrderDao;
import org.finace.order.repository.OrderCrudRepository;
import org.finace.order.repository.OrderTestRepository;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.MerchStanModel;
import org.finace.utils.entity.order.OrderTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;


/**
 * Created by Ness on 2016/12/16.
 */
@Component
public class OrderDaoImpl implements OrderDao {
    
	@Autowired
    private OrderCrudRepository orderCrudRepository;
    
//	@Autowired
//    private OrderRepository orderRepository;
	
//	@Autowired
//	private OrderMerchRepository orderMerchRepository;
	
	@Autowired
	private OrderTestRepository orderTestRepository;
    
	private Logger logger = LoggerFactory.getLogger(OrderDaoImpl.class);
	
	
	private int PAGE_COUNT = 20;
	
	/**
	 * order_save方法(old)
	 */
    
//	@Override
//    public void saveOrder(Orders order) {
//        orderCrudRepository.save(order);
//    }
    
    
    /**
     * OrderTest_save方法(new)
     * @param order 订单对象
     */
    
	@Override
    public void saveOrderTest(OrderTest order) {
    	orderTestRepository.save(order);
    }
  

	
	/**
	 * orderTest load方法(new)（不用了）
	 * 
	 */
    
	@Override
    public Page<OrderTest> findOrderTestByUserUuid (String userUuid, Integer sortOrder , Integer page, Integer pageCount,Integer status){
    	
    	String[] sortArr = new String[1];
    	sortArr[0] = "createTime";
    	//1是降序，默认是降序排列的
    	Sort sortFile = new Sort((sortOrder != null && sortOrder == 0 ? Sort.Direction.ASC : Sort.Direction.DESC), sortArr);
    	if (page == null || page <=0) {
            page = 1;
        }
    	
    	Pageable pageable = new PageRequest(page - 1, pageCount == null ? PAGE_COUNT : pageCount, sortFile);
    	
    	Specification<OrderTest> specification = new Specification<OrderTest>(){
    		@Override
            public Predicate toPredicate(Root<OrderTest> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {

                List<Predicate> list = new ArrayList<>();
                list.add(cb.equal(root.get("deleted").as(Boolean.class), false));
                if(status!=null){
                	list.add(cb.equal(root.get("status").as(Integer.class), status));
                }
                
                //查询订单的userUuid
                list.add(cb.equal(root.get("userUuid").as(String.class), userUuid));
                
                return cq.where(list.toArray(new Predicate[list.size()])).getRestriction();

            }
        };
        return orderTestRepository.findAll(specification, pageable);
    }
	
    /**
     * 改变订单状态方法(new)
     * @param uuid 订单id
     * @param status 订单状态
     */
    @Override
    public void changeOrderTestStatus(String uuid, Integer status){
    	orderCrudRepository.changeOrderStatus(uuid, status,Timestamp.from(Instant.now()));
  	}
    
    
    /**
     * 软删除订单(new)
     * @param uuid 订单id
     * @param deletedPersonUuid 删除者的id
     * 
     */
    @Override
    public void setOrderTestDeleted(String uuid ,String deletedPersonUuid){
    	orderCrudRepository.setOrderDeleted(uuid,deletedPersonUuid,Timestamp.from(Instant.now()));
    }
    /**
     * 把规格比如"(1,2)"解析成Intger数组
     *@param merchStandardIndex 要解析的规格
     */
    @Override
    public Integer[] splitMerchStanIndex(String merchStandardIndex){
    	if(merchStandardIndex == null){
    		return null;
    	}
    	if(merchStandardIndex.contains(",")){
    		String [] strarr = merchStandardIndex.split(",");
    		if(strarr.length!=2){
    			return null;
    		}
    		Integer a = null;
    		Integer b = null;
    		try {
				a = Integer.parseInt(strarr[0]);
				b = Integer.parseInt(strarr[1]);
			} catch (Exception e) {
				logger.warn("规格转换失败！");
				return null;
			}
    		if(a==null||b==null){
    			return null;
    		}
    		if(!String.valueOf(a).equals(strarr[0])||!String.valueOf(b).equals(strarr[1])){
    			logger.warn("虽然可以解析坐标，但是解析之后的整数和之前不同，可能是01转化成了1，请检查！");
    			return null;
    		}
    		return new Integer[]{
    				a,b
    		};
    		
    	}else {
    		Integer c = null;
    		try {
				c = Integer.parseInt(merchStandardIndex);
			} catch (Exception e) {
				logger.warn("规格转换失败！");
				return null;
			}
    		return new Integer[]{c};
    	}
    }
    
    
    
    /**
     * 根据一个商品的uuid及其规格索引，查找对应的商品价格和库存，需要先判断规格索引的格式(这个方法不用了)
     */
       
    @Override
    public MerchStanModel loadMerchStandardDetail(String merchStandardIndex,String merchUuid){

    	MerchStanModel msm = new MerchStanModel();
    	List <MerchandiseStandard> mslist = orderTestRepository.loadMerchandiseStandard(merchUuid);
    	MerchandiseStandard ms = null;

    	//获取数据库中商品规格数据
    	if(Regular.checkEmpty(mslist, null)){
    		logger.warn("数据库中没有id为{}的商品的规格！请检查！",merchUuid);
    		return null;
    	}
    	if(mslist.size()>1){
    		logger.warn("数据库中id为{}的商品的规格不唯一！",merchUuid);
    	}
    	ms = mslist.get(0);

    	if(ms==null){
    		return null;
    	}

    	if(merchStandardIndex==null){
    		logger.warn("id为{}的商品传入的规格索引为空！此商品无效！",merchUuid);
    		return null;
    	}

    	String[] topCategoryName = ms.getTopCategoryName();

    	if(topCategoryName==null||topCategoryName.length<1||topCategoryName.length>2){
    		logger.warn("id为{}的商品规格topCategoryName异常(为空或者长度小于一或大于二)！",merchUuid);	
    		return null;
    	}
    	if(ms.getPrices()==null){
    		logger.warn("id为{}的商品规格价格数组异常(为空)！",merchUuid);	
    		return null;
    	}
    	if(topCategoryName.length == 1){
    		Integer a = null;

    		try {
    			a = Integer.parseInt(merchStandardIndex);
    		} catch (NumberFormatException e) {
    			logger.warn("商品id为{}的商品规格索引格式不正确，原因有可能商品的规格是一维的，但是传入的规格是二维的，或者传入规格格式不符合'num'！此商品无效！",merchUuid);
    			e.printStackTrace();
    			return null;
    		}
    		if(a==null||a<0){
    			logger.warn("商品id为{}的商品规格索引格式不正确！此商品无效！",merchUuid);
    			return null;
    		}

    		if(a+1>ms.getPrices().length){
    			logger.warn("id为'{}',规格索引为'{}'的商品,索引（一维）数字大于数组实际长度！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}

    		String price_first_str = ms.getPrices()[a][0];

    		if(price_first_str == null){
    			logger.warn("id为'{}',规格索引为'{}',的商品,从数据库中获取价格失败（价格数据为null）！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}

    		Double price_first = null;

    		try {
    			price_first = Double.parseDouble(price_first_str);
    		} catch (NumberFormatException e) {
    			logger.warn("商品id为{}的商品，规格中价格的格式错误（不是Double型）！此商品无效！",merchUuid);
    			e.printStackTrace();
    			return null;
    		}
    		if(price_first==null||price_first<0){
    			logger.warn("id为'{}',规格索引为'{}',的商品,从数据库中获取价格失败(价格为空或者小于零)！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}
    		msm.setMerchPrice(price_first);



    		//寻找库存
    		String stocks_first_str = ms.getStocks()[a][0];
    		if(stocks_first_str == null){
    			logger.warn("id为{}的商品,规格索引为{}，获取库存为null！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}

    		Integer stocks_first = null;

    		try {
    			stocks_first = Integer.parseInt(stocks_first_str);
    		} catch (NumberFormatException e) {
    			logger.warn("商品id为{}的商品，规格中库存的格式错误（不是Integer型）！此商品无效！",merchUuid);
    			e.printStackTrace();
    			return null;
    		}
    		if(stocks_first==null||stocks_first<0){
    			logger.warn("id为{}的商品,规格索引为{}，获取库存失败！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}
    		msm.setStocks(stocks_first);

    	}

    	if(topCategoryName.length == 2){

    		String[] msiArr = merchStandardIndex.split(",");

    		if(msiArr==null||msiArr.length!=2){
    			logger.warn("商品id为{}的商品规格索引格式不正确！此商品无效！",merchUuid);
    			return null;
    		}
    		Integer a = null;
    		Integer b = null;

    		try {
    			a = Integer.parseInt(msiArr[0]);
    			b = Integer.parseInt(msiArr[1]);
    		} catch (NumberFormatException e) {
    			logger.warn("商品id为{}的商品规格索引格式不正确！此商品无效！",merchUuid);
    			e.printStackTrace();
    			return null;
    		}	
    		if(a==null||b==null){
    			logger.warn("商品id为{}的商品规格索引格式不正确！此商品无效！",merchUuid);
    			return null;
    		}
    		if(a+1>ms.getPrices().length||b+1>ms.getPrices()[0].length){
    			logger.warn("商品id为{}的商品传入的规格数据超出规格二维数组边界！请检查！");
    			return null;
    		}
    		//寻找价格
    		String price_two_str = ms.getPrices()[a][b];
    		if(price_two_str == null){
    			logger.warn("id为{}的商品,规格索引为{}，获取价格为null！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}

    		Double price_two = null;

    		try {
    			price_two = Double.parseDouble(price_two_str);
    		} catch (NumberFormatException e) {
    			e.printStackTrace();
    		}
    		if(price_two==null||price_two<0){
    			logger.warn("id为{}的商品,规格索引为{}，获取价格失败(价格为空或小于零)！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}
    		msm.setMerchPrice(price_two);



    		//寻找库存
    		String stocks_two_str = ms.getStocks()[a][b];
    		if(stocks_two_str == null){
    			logger.warn("id为{}的商品,规格索引为{}，获取库存为null！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}

    		Integer stocks_two = null;

    		try {
    			stocks_two = Integer.parseInt(stocks_two_str);
    		} catch (NumberFormatException e) {
    			e.printStackTrace();
    		}
    		if(stocks_two==null||stocks_two<0){
    			logger.warn("id为{}的商品,规格索引为{}，获取库存失败！此商品无效！",merchUuid,merchStandardIndex);
    			return null;
    		}
    		msm.setStocks(stocks_two);
    	}
    	return msm;
    }

}
