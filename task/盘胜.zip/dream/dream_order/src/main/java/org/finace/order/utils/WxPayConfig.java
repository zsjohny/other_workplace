package org.finace.order.utils;

public class WxPayConfig {
	
	
	 /**
     * 公众账号ID
     */
    public static final String appid = "wx3bcfa6c2f0a0a2d7";

    /**
     * 公众账号secret
     */
    public static final String appsecret = "903e2f7420372e5cb511d283f2dc0ea1";

    /**
     * 商户号（mch_id）
     */
    public static final String partner = "1434972002";

    public static final String partnerkey = "HANGZHOUyaoxinwangluojishu201702";

    /**
     * 交易类型
     */
    public static final String trade_type = "APP";

    public static final String signType = "MD5";
    public static final String notify_url = "http://api.welicn.com:9203/order/order/wxPayCallbackResult/tourist.do";

    private WxPayConfig() {

    }
	
	

}
