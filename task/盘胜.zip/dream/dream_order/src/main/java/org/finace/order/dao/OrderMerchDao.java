package org.finace.order.dao;

import java.util.List;

import org.finace.utils.entity.order.OrderMerch;

public interface OrderMerchDao {
		void saveOrderMerch(OrderMerch orderMerch);     

		List<OrderMerch> findOrderMerchBySingleOrder_uuid(String order_uuid);

}
