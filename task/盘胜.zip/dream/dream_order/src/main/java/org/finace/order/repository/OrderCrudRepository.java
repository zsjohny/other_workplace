package org.finace.order.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.finace.utils.entity.order.OrderMerch;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.Orders;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by Ness on 2016/12/16.
 */
public interface OrderCrudRepository extends CrudRepository<Orders,Integer>, JpaSpecificationExecutor<Orders>{

	
	@Modifying
	@Transactional  
	@Query("update Orders set deleted=1, updateTime=:deleteTime,deletedPersonUuid=:deletedPersonUuid where uuid=:uuid ")
    void setOrderDeleted(@Param("uuid") String uuid, @Param("deletedPersonUuid")String deletedPersonUuid, @Param("deleteTime")Date deleteTime);
	
	@Modifying
	@Query("update Orders set status=:status,updateTime=:updateTime where uuid=:uuid ")
    void changeOrderStatusByUuid(@Param("uuid") String uuid, @Param("status")Integer status,@Param("updateTime") Date updateTime);
	@Modifying
	@Query("update Orders set status=:status,updateTime=:updateTime where orderNo=:orderNo")
	void changeOrderStatusByOrderNo(@Param("orderNo") String orderNo, @Param("status")Integer status,@Param("updateTime") Timestamp updateTime);
	
	@Query("select o from Orders o  where o.userUuid=:userUuid")
	List<Orders> listOrdersByUserUuid(@Param("userUuid") String userUuid);
	
	@Query("select o from Orders o  where o.orderNo=:orderNo")
	List<Orders> selectSingleOrderByOrderNo(@Param("orderNo") String orderNo);
	
	@Query(nativeQuery=true,value="select merchBelongToUuid from merchandise where uuid=?1")
	String loadBelongToUuid(String uuid);
	@Query(nativeQuery=true,value="select count(1) from merchandiser where uuid=?1")
	int countIfMerchandiserExist(String merchandiserUuid);
	
	@Query("select o.status from Orders o where orderNo = :orderNo")
	Integer loadOrderStatusByOrderNo(@Param("orderNo") String orderNo);

	@Query("select status,count(1) from Orders where userUuid=:userUuid group by status order by status asc")
    List<Object[]> countNumberOfOrdersByStatus(@Param("userUuid") String userUuid);
    @Modifying
	@Transactional  
	@Query("update Orders set status=:status,updateTime=:updateTime where uuid=:uuid")
    void changeOrderStatus(@Param("uuid") String uuid, @Param("status")Integer status,@Param("updateTime") Timestamp updateTime);
    @Modifying
	@Transactional  
	@Query("update Orders set deleted=1, updateTime=:deleteTime,deletedPersonUuid=:deletedPersonUuid where uuid=:uuid ")
    void setOrderDeleted(@Param("uuid") String uuid, @Param("deletedPersonUuid")String deletedPersonUuid, @Param("deleteTime")Timestamp deleteTime);
}
