package org.finace.order.utils;

import org.finace.utils.enums.LockType;
import org.finace.utils.lock.Lock;
import org.finace.utils.screct.UserUtils;

public class TetsLock {
	public static void main(String[] args) {
		System.out.println("wx3bcfa6c2f0a0a2d7".length());
	}

}
