package org.finace.order.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.Orders;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;


public interface OrderRepository extends Repository<Orders, Integer>{
	@Query("from  Orders where userUuid=:userUuid order by creatTime desc")
    List<Orders> loadAllOrdersByUserUuid(@Param("userUuid") String userUuid);
	@Modifying
	@Query("update Orders set status=:deleted where uuid=:uuid ")
	void ddddddOrderStatus(@Param("uuid") String uuid,  @Param("deleted")Integer deleted);
	@Query("from  Orders where uuid=:orderUuid")
    List<Orders> loadSingleOrder(@Param("orderUuid") String orderUuid);
	@Query("select status,count(1) from  Orders where userUuid=:userUuid group by status")
    List<Object[]> countNumberOfOrdersByStatus(@Param("userUuid") String userUuid);
	
    @Query("select status from Orders where uuid=:uuid")
    String loadOrderStatus(@Param("uuid") String uuid);
    
    @Query("from MerchandiseStandard where merchUuid=:merchUuid")
    List <MerchandiseStandard> loadMerchandiseStandard(@Param("merchUuid")String merchUuid);
    
    
 
    
}
