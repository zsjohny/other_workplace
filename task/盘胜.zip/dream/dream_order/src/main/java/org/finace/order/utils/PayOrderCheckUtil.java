package org.finace.order.utils;

import java.util.List;

import org.finace.order.dao.OrderDao;
import org.finace.order.dao.impl.OrderDaoImpl;
import org.finace.order.repository.OrderTestRepository;
import org.finace.order.repository.ShoppingCartRepository;
import org.finace.order.repository.StandardRepository;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.MerchStanModel;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.math.Arith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class PayOrderCheckUtil {
	
	private static Logger logger = LoggerFactory.getLogger(OrderDaoImpl.class);
	@Autowired
	private static OrderDao orderDao;
	
	@Autowired
	private static ShoppingCartRepository shoppingCartRepository;
	
	@Autowired
	private static StandardRepository standardRepository;
	
	public static void deleteShopCartAfterOrder(OrderTest order){
		if(order==null||order.getMerchUuid()==null||order.getMerchStandardIndex()==null){
			return;
		}
		int length = order.getMerchUuid().length;
		System.out.println(length);
		for(int i=0; i<length; i++){
			//shoppingCartRepository.deleteShoppingCartMerchByIdAndIndex(order.getMerchUuid()[i], order.getMerchStandardIndex()[i]);
		}
	}
	public static void changeMerchStockAfterOrder(OrderTest order){
		if(order==null||order.getMerchQuantity()==null||order.getMerchUuid()==null||order.getMerchStandardIndex()==null){
			return;
		}
		int length = order.getMerchUuid().length;
		int quantity = 0;
		String merchUuid = null;
		String merchIndex = null;
		for(int i=0; i<length; i++){
			try {
				quantity = Integer.parseInt(order.getMerchQuantityStringArr()[i]);
				merchUuid = order.getMerchUuidStringArr()[i];
				merchIndex = order.getMerchStandardIndexStringArr()[i];
				changeSingleMerchStock(merchUuid, merchIndex, quantity, true);	
			} catch (Exception e) {
				logger.warn("订单生成时扣库存失败！有可能是订单中商品数量格式不正确请检查！");
				continue;
			}
			
		}
	}
	public static void changeSingleMerchStock(String merchUuid, String merchStandardIndex, int quantity, Boolean isReduce){
		if(merchUuid==null||merchStandardIndex==null||quantity<=0||isReduce==null){
			logger.warn("减少单个商品库存失败！商品id:{}",merchUuid);
			return;
		}
		
		List<MerchandiseStandard> msList = standardRepository.loadMerchandiseStandard(merchUuid);
		if(Regular.checkEmpty(msList,null)){
			logger.warn("找不到该商品对应的规格数据！请检查！");
			return;
		}
		if(msList.size()>1){
			logger.warn("单个商品在数据库中的规格数据不止一个！请检查！商品id:{}",merchUuid);
		}
		MerchandiseStandard ms = msList.get(0);
		if(Regular.checkEmpty(ms.getTopCategoryName(), null)){
			logger.warn("规格的topCategoryName为空！");
			return;
		}
		
		
		Integer [] intarr = splitMerchStanIndex(merchStandardIndex);
		if(intarr==null){
			logger.warn("商品规格转换成Integer数组失败！");
			return;
		}
		int length_1 = intarr.length;
		int length_2 = ms.getTopCategoryName().length;
		if(length_1!=length_2||length_1>2||length_1<1){
			logger.warn("规格索引解析出来的维度和规格的一级分类数组解析出来的维度不一致！");
			return;
		}
		if(ms.getStocks()==null){
			logger.warn("找不到该商品对应的规格的库存数据！请检查！");
			return;
		}
		String [][] stocksStrArr = null;
		String stockStr = null;
		int stock = 0;
		if(length_1==1){
			if(intarr[0]==null){
				logger.warn("一维索引数据解析不正常！");
				return;
			}
			stocksStrArr = ms.getStocks();
			stockStr = stocksStrArr[intarr[0]][0];
			try {
				stock = Integer.parseInt(stockStr);
			} catch (Exception e) {
				return;
			}
			if(isReduce==true){
				if(stock<=quantity){
					logger.warn("库存不足！可能是订单校验时出错！");
					return;
				}
				stock -= quantity;
			}
			else{
				stock += quantity;
			}
				stocksStrArr[intarr[0]][0] = String.valueOf(stock);
				ms.setStocks(stocksStrArr);
				standardRepository.save(ms);
			
			
		}
		if(length_1==2){
			if(intarr[0]==null||intarr[1]==null){
				logger.warn("一维索引数据解析不正常！");
				return;
			}
			
			stocksStrArr = ms.getStocks();
			stockStr = stocksStrArr[intarr[0]][intarr[1]];
			try {
				stock = Integer.parseInt(stockStr);
			} catch (Exception e) {
				return;
			}
			
			if(isReduce==true){
				if(stock<=quantity){
					logger.warn("库存不足！可能是订单校验时出错！");
					return;
				}
				stock -= quantity;
				System.out.println(stock);
			}else{
				stock += quantity;
			}
			stocksStrArr[intarr[0]][intarr[1]] = String.valueOf(stock);
			ms.setStocks(stocksStrArr);
			standardRepository.save(ms);
		}
	}
	
	
	public static Integer[] splitMerchStanIndex(String merchStandardIndex){
    	if(merchStandardIndex == null){
    		return null;
    	}
    	if(merchStandardIndex.contains(",")){
    		String [] strarr = merchStandardIndex.split(",");
    		if(strarr.length!=2){
    			return null;
    		}
    		Integer a = null;
    		Integer b = null;
    		try {
				a = Integer.parseInt(strarr[0]);
				b = Integer.parseInt(strarr[1]);
			} catch (Exception e) {
				logger.warn("规格转换失败！");
				return null;
			}
    		if(a==null||b==null){
    			return null;
    		}
    		return new Integer[]{
    				a,b
    		};
    		
    	}else{
    		Integer c = null;
    		try {
				c = Integer.parseInt(merchStandardIndex);
			} catch (Exception e) {
				logger.warn("规格转换失败！");
				return null;
			}
    		return new Integer[]{c};
    	}
    }

	public static void main(String[] args) {
		Integer[] intarr = splitMerchStanIndex("1");
		for(int i=0; i<intarr.length; i++){
			System.out.println(intarr[i]);
			
		}
	}
	
	
}
