package org.finace.order.dao;

import java.util.List;

import org.finace.utils.entity.order.OrderMerch;
import org.finace.utils.entity.order.Orders;
import org.springframework.data.domain.Page;

/**
 * Created by Ness on 2016/12/16.
 */
public interface ShopCartDao {

	List<Object[]> loadAllShopCartMerchByUserUuid(String userUuid, Integer page, Integer pageCount);
    
}
