package org.finace.order.dao.impl;

import java.util.List;

import org.finace.order.dao.OrderMerchDao;
import org.finace.order.repository.OrderMerchCrudRepository;
import org.finace.utils.entity.order.OrderMerch;
import org.springframework.stereotype.Component;
@Component
public class OrderMerchDaoImpl implements OrderMerchDao{   
    private OrderMerchCrudRepository orderMerchCrudRepository;

	@Override
	public void saveOrderMerch(OrderMerch orderMerch) {
		orderMerchCrudRepository.save(orderMerch);
	}
	@Override
	public List<OrderMerch> findOrderMerchBySingleOrder_uuid(String order_uuid){
		return null;
	}

}
