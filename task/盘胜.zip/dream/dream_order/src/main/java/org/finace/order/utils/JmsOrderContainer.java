package org.finace.order.utils;

import java.util.HashMap;
import java.util.Map;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.finace.utils.jms.JmsContainer;
import org.finace.utils.jms.JmsListenter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

/**
 * Created by Ness on 2016/12/6.
 */
public class JmsOrderContainer implements InitializingBean, BeanFactoryAware {
    private Logger logger = LoggerFactory.getLogger(JmsContainer.class);

    private ConnectionFactory connectionFactory;


    private Map<Destination, JmsListenter> listeners = new HashMap<>();


    private class MsgListenter implements MessageListener {
        private JmsListenter jmsListenter;

        public MsgListenter(JmsListenter jmsListenter) {
            this.jmsListenter = jmsListenter;
        }

        @Override
        public void onMessage(Message message) {
            try {
                logger.info("开始接受消息{}", message);
                TextMessage textMessage = (TextMessage) message;
                jmsListenter.onMsg(textMessage.getText());
            } catch (Exception e) {
                logger.warn("接受消息{},出错", message);
            }


        }
    }

    BeanFactory factory;


    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.factory = beanFactory;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        BeanDefinitionBuilder builder;
        for (Map.Entry<Destination, JmsListenter> enrtys : listeners.entrySet()) {
            builder = BeanDefinitionBuilder.genericBeanDefinition(DefaultMessageListenerContainer.class);
            builder.setLazyInit(false);
            builder.addPropertyValue("connectionFactory", connectionFactory);
            builder.addPropertyValue("destination", enrtys.getKey());
            builder.addPropertyValue("maxMessagesPerTask", 30);
            builder.addPropertyValue("messageListener", new MsgListenter(enrtys.getValue()));
            DefaultListableBeanFactory fac = (DefaultListableBeanFactory) factory;
            String beanName = enrtys.getKey().toString();
            fac.registerBeanDefinition(beanName, builder.getRawBeanDefinition());
        }


    }


    public ConnectionFactory getConnectionFactory() {
        return connectionFactory;
    }

    public void setConnectionFactory(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }

    public Map<Destination, JmsListenter> getListeners() {
        return listeners;
    }

    public void setListeners(Map<Destination, JmsListenter> listeners) {
        this.listeners = listeners;
    }
}
