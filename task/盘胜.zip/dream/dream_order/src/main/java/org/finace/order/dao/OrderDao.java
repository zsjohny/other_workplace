package org.finace.order.dao;

import java.util.List;

import org.finace.utils.entity.order.MerchStanModel;
import org.finace.utils.entity.order.OrderMerch;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.Orders;
import org.finace.utils.enums.ResponseType;
import org.springframework.data.domain.Page;

/**
 * Created by Ness on 2016/12/16.
 */
public interface OrderDao {

//	void saveOrder(Orders order);

//	Page<Orders> findOrdersByUuid(String userUuid, Integer order, Integer page, Integer pageCount, Integer status);





	MerchStanModel loadMerchStandardDetail(String merchStandardIndex, String merchUuid);

	void saveOrderTest(OrderTest order);

	Page<OrderTest> findOrderTestByUserUuid(String userUuid, Integer order, Integer page, Integer pageCount,
			Integer status);

	void setOrderTestDeleted(String uuid, String deletedPersonUuid);

	void changeOrderTestStatus(String uuid, Integer status);

	Integer[] splitMerchStanIndex(String merchStandardIndex);
    
}
