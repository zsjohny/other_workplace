package org.finace.order.server.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.finace.order.dao.OrderDao;
import org.finace.order.dao.ShopCartDao;
import org.finace.order.repository.MerchStockAndPriceRepository;
import org.finace.order.repository.OpmoRepository;
import org.finace.order.repository.OrderPayTempRepository;
import org.finace.order.repository.OrderTestRepository;
import org.finace.order.repository.PRRepository;
import org.finace.order.repository.ShoppingCartRepository;
import org.finace.order.repository.StandardRepository;
import org.finace.order.server.OrderService;
import org.finace.order.utils.AlipayConfig;
import org.finace.order.utils.FlashSaleTaskBus;
import org.finace.order.utils.MD5Util;
import org.finace.order.utils.WxPayConfig;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.concurrent.ExecutorService;
import org.finace.utils.conver.DataConverUtils;
import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.MerchStockAndPrice;
import org.finace.utils.entity.order.OnePaymentNoToManyOrderNo;
import org.finace.utils.entity.order.OrderPayTemp;
import org.finace.utils.entity.order.OrderStatusCount;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.PaymentReiceive;
import org.finace.utils.entity.order.ShoppingCartDTO;
import org.finace.utils.entity.order.ShoppingCartMerch;
import org.finace.utils.entity.order.TempMerchInfo;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.LockType;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.enums.ScheduleOperaType;
import org.finace.utils.enums.TimerTaskNameType;
import org.finace.utils.http.HttpTools;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.lock.Lock;
import org.finace.utils.math.Arith;
import org.finace.utils.operate.Response;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;

/**
 * Order的serveic Created by Ness on 2016/12/16.
 */
//@Transactional
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderDao orderDao;
	@Autowired
	private ExecutorService executorService;

	@Autowired
	private ShopCartDao shopCartDao;
	@Autowired
	private OrderTestRepository orderTestRepository;

	@Autowired
	private ShoppingCartRepository scr;
	@Autowired
	private FlashSaleTaskBus fstb;
	@Autowired
	private StandardRepository standardRepository;
	@Autowired
	private MerchStockAndPriceRepository msapResponsitory;

	private Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Autowired
	private JmsSender jmsSender;

	@Resource(name = "cacheTemplete")
	private CacheTemplete cache;

	@Autowired
	private OpmoRepository opmoRepository;
	
	
	@Override
	/**
	 * @param uuid
	 *            订单id
	 * @param status
	 *            订单状态
	 */
	public Response changeStatus(String uuid, Integer status) {
		logger.info("开始改变uuid为{}的订单状态为{}", uuid, status);
		if (uuid == null) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (status == null || status <= 0) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		orderDao.changeOrderTestStatus(uuid, status);
		logger.info("成功改变uuid为{}的订单状态为{}", uuid, status);
		return Response.success();
	}

	/**
	 * @param uuid              订单id
	 * @param deletedPersonUuid 删除者的id
	 */
	@Override
	public Response setOrderDeleted(String uuid, String deletedPersonUuid) {
		if (uuid == null) {
			logger.warn("传入的订单uuid为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (deletedPersonUuid == null) {
			logger.warn("传入的删除操作人uuid为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		logger.info("开始更改订单uuid为{}的订单状态为已失效", uuid);
		orderDao.setOrderTestDeleted(uuid, deletedPersonUuid);
		logger.info("结束更改订单uuid为{}的订单状态为已失效", uuid);
		return Response.success("成功删除订单！");

	}

	// 查询购物车数据

	/**
	 * @param userUuid  用户id
	 * @param page      第几页
	 * @param pageCount 每页数量
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Response loadAllShopCartMerchByUserUuid(String userUuid, Integer page, Integer pageCount) {
		logger.info("获取userUuid为：" + userUuid + "的购物车商品列表");
		List<Object[]> objlist = shopCartDao.loadAllShopCartMerchByUserUuid(userUuid, page, pageCount);
		
		
		Map<String, List<ShoppingCartMerch>> ownerMap = new LinkedHashMap<>();
		List<ShoppingCartDTO> scdtoList = new ArrayList<>();
		String omMerchUuid = null;
		String keyStr = null;
		Double price = null;
		int stock = -1;
		String[][] secondCateGoryName = null;
		Boolean merchDeleted = null;
		String merchStandardIndex = null;
		Integer[] interArr = null;
		ShoppingCartMerch om = null;
		if (objlist == null || objlist.size() == 0) {
			return Response.success("购物车数据为空");
		}
		// 看看该用户所有的购物车条目的读取过程中有多少条目是失败的
		int objListSize = objlist.size();
		for (Object[] o : objlist) {

			if (o == null || o.length != 9) {
				logger.warn("获取购物车条目失败1！object[]为null或者长度不为9！");
				objListSize--;
				continue;
			}
			om = (ShoppingCartMerch) o[0];

			if (om == null) {
				logger.warn("获取购物车条目失败1_1！object[0]预计得到购物车对象，但是现在为null，用的是leftjoin，见鬼了");
				objListSize--;
				continue;
			}
			omMerchUuid = om.getMerchUuid();
			if (omMerchUuid == null) {
				logger.warn("极罕见！该商品MerchUuid为空！跳过此购物车商品的读取！");
				objListSize--;
				continue;
			}
			om.setIsStockSufficient(true);
			boolean oflag = false;
			for (int i_1 = 3; i_1 < 9; i_1++) {
				if (o[i_1] == null) {
					logger.warn("Object[]第{}项为空！请检查！商品:{}", i_1, omMerchUuid);
					oflag = true;
				}
			}
			if (oflag) {
				objListSize--;
				//删除此条购物车记录
				continue;
			}
			price = (Double) o[3];
			stock = (int) o[4];
			merchDeleted = (Boolean) o[5];
			secondCateGoryName = (String[][]) o[6];
			om.setMerchName((String) o[7]);
			om.setMerchPic((String) o[8]);
			if (o[1] == null) {
				logger.warn("Object[]第1项为空！请检查！");
				objListSize--;
				continue;
			}
			om.setMerchandiserUuid((String) o[1]);
			if (om == null || om.getMerchStandardIndex() == null) {
				logger.warn("获取购物车条目失败2！om==null||om.getMerchStandardIndex()==null！商品id:{}", omMerchUuid);
				objListSize--;
				continue;
			}
			// IsMerchValid这个字段标志的是,如果购物车中有这个商品数据，但是实际商品库中这个商品已经被下架或者删除，那么要将这个商品修改为无效的，这是通过左链接商品表的deleted属性实现的
			om.setIsMerchValid(true);
			if (merchDeleted == null || merchDeleted == true) {
				logger.warn("购物车商品数据对应不到相应的商品列表，有可能此商品已经下架或者被删除！商品id:{}", omMerchUuid);
				om.setIsMerchValid(false);
			}

			if (price == null || stock < 0) {
				logger.warn("获取购物车条目失败2-1！price==null||stock<0 ,商品id:{}", omMerchUuid);
				objListSize--;
				continue;
			}
			merchStandardIndex = om.getMerchStandardIndex();
			interArr = orderDao.splitMerchStanIndex(merchStandardIndex);
			if (interArr == null || (interArr.length != 1 && interArr.length != 2)) {
				logger.warn("获取购物车条目失败3！索引字符串转成Integer数组失败！Integer数组为null或者长度不为1或者2，原因可能是商品索引为null或者索引格式不正确，商品id:{}",
						omMerchUuid);
				objListSize--;
				continue;
			}
			if (secondCateGoryName == null) {
				logger.warn("商品规格secondCateGoryName为null！商品id:{}", omMerchUuid);
				continue;
			}
			if (interArr.length == 1) {
				if (secondCateGoryName.length != 1) {
					logger.warn("传入的规格索引是一维的，然而规格对应的secondCateGoryName却不是一维的！请检查！商品id：{}", omMerchUuid);
					objListSize--;
					continue;
				}
				if (interArr[0] == null || interArr[0] < 0 || (interArr[0] + 1) > secondCateGoryName[0].length) {
					logger.warn("获取购物车条目失败3-1！interArr.length == 1，interArr[0]==null,或者规格坐标超出规格二级分类名称的范围！ 商品id:{}",
							omMerchUuid);
					objListSize--;
					continue;
				}
				if (stock < 0 || stock < om.getQuantity()) {
					om.setIsStockSufficient(false);
				}
				om.setStocks(stock);
				om.setMerchPrice(price);
				om.setMerchSpec(secondCateGoryName[0][interArr[0]]);

			}

			if (interArr.length == 2) {
				if (secondCateGoryName.length != 2) {
					logger.warn("传入的规格索引是二维的，然而规格对应的secondCateGoryName却不是二维的！请检查！商品id：{},规格：{}", omMerchUuid,
							merchStandardIndex);
					objListSize--;
					continue;
				}

				if (interArr[0] == null || interArr[1] == null || interArr[0] < 0 || interArr[1] < 0
						|| (interArr[0] + 1) > secondCateGoryName[0].length
						|| (interArr[1] + 1) > secondCateGoryName[1].length) {
					logger.warn(
							"获取购物车条目失败6！interArr.length == 2 ;interArr[0]==null||interArr[1]==null 或有小于0的索引，或者传入的索引数值越出了二维数组的统一边界！ 商品id:{}",
							omMerchUuid);
					objListSize--;
					continue;
				}

				om.setMerchSpec(secondCateGoryName[0][interArr[0]] + "," + secondCateGoryName[1][interArr[1]]);
				om.setMerchPrice(price);
				if (stock <= 0 || stock < om.getQuantity()) {
					om.setIsStockSufficient(false);
				}
				om.setStocks(stock);
			}
			keyStr = (String) o[2];
			if (keyStr == null) {
				logger.warn("商家名称为null，有可能是关联不到商家信息或者此商家信息不完整！");
				objListSize--;
				continue;
			}
			if (ownerMap.containsKey(keyStr) && ownerMap.get(keyStr) != null) {
				ownerMap.get(keyStr).add(om);
			} else {
				ownerMap.put(keyStr, new ArrayList<ShoppingCartMerch>());
				ownerMap.get(keyStr).add(om);
			}

		}
		Iterator<Entry<String, List<ShoppingCartMerch>>> iter = ownerMap.entrySet().iterator();
		ShoppingCartDTO scdto = null;
		while (iter.hasNext()) {
			scdto = new ShoppingCartDTO();
			@SuppressWarnings("rawtypes")
			Map.Entry entry = (Map.Entry) iter.next();
			scdto.setShopName((String) entry.getKey());
			scdto.setGoodsList((List<ShoppingCartMerch>) entry.getValue());
			scdtoList.add(scdto);
		}
		logger.info("成功获取userUuid为{}的购物车商品列表，其中，购物车条目有{}，成功获取了{}条", userUuid, objlist.size(), objListSize);
		if (scdtoList != null && scdtoList.size() > 0) {
			JSONObject json = new JSONObject();
			json.put("key", scdtoList);
			json.put("totalNumber", objlist.size());
			json.put("successNumber", objListSize);
			return Response.success(json);
		} else {
			return Response.success();
		}
	}

	// private static StringBuilder builder=new
	// StringBuilder(TimerTaskNameType.ORDER_AUTO_INVALID.getName());
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ss mm HH dd MM ?");

	/**
	 * 本方法是验证订单是否有效的方法
	 *
	 * @param order     订单对象
	 * @param reCheckId 同一批生成的订单的同一的id
	 * @return
	 */
	public Boolean checkOrderIsValidInUse(OrderTest order, String reCheckId) {
		if (order == null) {
			logger.warn("订单为null");
			return false;
		}
		Double merchPrice = null;
		Integer merchQuantity = null;
		Double orderPrice = 0.0;
		if(order.getIsFromCart() == null || order.getIsFromCart() == false){
			if(order.getMerchUuidStringArr() == null || order.getMerchUuidStringArr().length != 1){
				logger.warn("没从购物车提交的商品，商品id数组为空或者其长度不为一！");
				return false;
			}
			order.setMerchandiserUuid(orderTestRepository.loadBelongToUuid(order.getMerchUuidStringArr()[0]));

		}
		String merchandiserUuid = order.getMerchandiserUuid();
		if(order.getIsFromCart() != null && order.getIsFromCart() == true && (orderTestRepository.countIfMerchandiseExist(merchandiserUuid)<=0)){
			logger.warn("从购物车生成的该订单传入的商家数据为空或者找不到对应的商家！订单生成失败！");
			return false;
		}
		if (order.getUserUuid() == null || order.getMerchUuidStringArr() == null
				|| order.getMerchPriceStringArr() == null || order.getMerchStandardIndexStringArr() == null
				|| order.getMerchQuantityStringArr() == null) {
			logger.warn("此订单传入的1.用户id。2.商品id数组。3.价格数组。4.规格索引数组。5.商品数量数组 这些参数中有的为空值！");
			return false;
		}
		int merchNumber = order.getMerchUuidStringArr().length;
		int merchNumber_1 = order.getMerchQuantityStringArr().length;
		int merchNumber_2 = order.getMerchStandardIndexStringArr().length;
		if (merchNumber <= 0 || merchNumber != merchNumber_1 || merchNumber != merchNumber_2) {
			logger.warn("订单的价格数组、规格索引数组、商品数量数组三者的长度不一致！");
			return false;
		}
		String merchUuid = null;
		String merchStandardIndex = null;
		String idConcatIndex = null;

		ArrayList<TempMerchInfo> infoList = new ArrayList<>();
		// 标识着这个订单中是不是有商品校验失败，如果失败，在finally方法中会将扣除的库存增加
		boolean flag = false;
		try {
			for (int i = 0; i < merchNumber; i++) {
				merchUuid = order.getMerchUuidStringArr()[i];
				merchStandardIndex = order.getMerchStandardIndexStringArr()[i];
				idConcatIndex = merchUuid + merchStandardIndex;
				try {
					merchQuantity = Integer.parseInt(order.getMerchQuantityStringArr()[i]);
				} catch (NumberFormatException e) {
					logger.warn("商品{}数量不是正整数", merchUuid);
					flag = true;
					return false;
				}
				if (merchQuantity == null) {
					logger.warn("商品数量错误！");
					flag = true;
					return false;
				}
				try {
					merchPrice = Double.parseDouble(order.getMerchPriceStringArr()[i]);
				} catch (NumberFormatException e) {
					logger.warn("商品传入的价格格式不正确，转换失败！");
					flag = true;
					return false;
				}
				if (merchPrice == null) {
					logger.warn("商品传入的价格格式不正确，转换失败！");
					flag = true;
					return false;
				}
				String currentTime = "";
				try {
					// while(!lock.lock(LockType.MERCH_STOCK_LOCK,idConcatIndex)){
					// }
					int result = msapResponsitory.checkStockAndPrice(merchQuantity, merchPrice, merchUuid,
							merchStandardIndex);
					if (result == 0) {
						logger.warn("原因可能是：1、商品:{}规格:{}价格:{}与数据库价格不一致。2、该商品要求数量{}个，但是库存不足，3、该商品或者该商品规格不存在！", merchUuid,
								merchStandardIndex, merchPrice, merchQuantity);
						flag = true;
						// currentTime =
						// lock.getLock(LockType.MERCH_STOCK_LOCK,idConcatIndex);
						return false;
					}
					if (result > 1) {
						logger.warn("该商品{}规格{}对应的数据库条目不唯一！请检查！", merchUuid, merchStandardIndex);
					}
					infoList.add(new TempMerchInfo(merchUuid, merchStandardIndex, merchQuantity));
					// currentTime =
					// lock.getLock(LockType.MERCH_STOCK_LOCK,idConcatIndex);
				} finally {
					// lock.unLock(LockType.MERCH_STOCK_LOCK,idConcatIndex,currentTime);
				}

				orderPrice = Arith.add(2, orderPrice, Arith.multiplys(2, merchPrice, merchQuantity));
			}
			if (Math.abs(Arith.subtract(2, orderPrice, order.getTotalPrice())) > 0.00001) {
				logger.warn("订单实际总价与传入价格不一致！");
				flag = true;
				return false;
			}
		} finally {
			if (flag && infoList.size() > 0) {
				for (TempMerchInfo tmi_1 : infoList) {
					msapResponsitory.increaseMerchStock(tmi_1.getMerchQuantity(), tmi_1.getMerchUuid(),
							tmi_1.getMerchStandardIndex());
				}
			}
		}
		//写从缓存查询id的方法
		order.setOrderNo(UserUtils.generateOrderNo());
		order.setReCheckId(reCheckId);
		order.setUuid(UserUtils.generateIncrementId());
		order.setStatus(1);
		order.setCreateTime(Timestamp.from(Instant.now()));
		order.setMerchName(DataConverUtils.stringArr2ByteArr(order.getMerchNameStringArr()));
		order.setMerchPic(DataConverUtils.stringArr2ByteArr(order.getMerchPicStringArr()));
		order.setMerchPrice(DataConverUtils.stringArr2ByteArr(order.getMerchPriceStringArr()));
		order.setMerchQuantity(DataConverUtils.stringArr2ByteArr(order.getMerchQuantityStringArr()));
		String[] merchStandardIndexArr = order.getMerchStandardIndexStringArr();
		String[] merchSpecArr = order.getMerchSpecStringArr();
		int s = merchStandardIndexArr.length;
		int f = merchSpecArr.length;
		if(s!=f){
			logger.warn("提交的订单中，其中商品的规格字符串数组长度{}和索引字符串数组长度{}不同！",f,s);
		}
		for (int j = 0; j < s; j++) {
			merchStandardIndexArr[j] = merchStandardIndexArr[j].replace(",", "@");
			merchSpecArr[j] = merchSpecArr[j].replace(",", "@");
		}
		order.setMerchSpec(DataConverUtils.stringArr2ByteArr(order.getMerchSpecStringArr()));
		order.setMerchStandardIndex(DataConverUtils.stringArr2ByteArr(merchStandardIndexArr));
		order.setMerchStandardUuid(DataConverUtils.stringArr2ByteArr(order.getMerchStandardUuidStringArr()));
		order.setMerchUuid(DataConverUtils.stringArr2ByteArr(order.getMerchUuidStringArr()));
		order.setDeleted(false);
		return true;
	}

	// 待会用jms消息发送，处理
	/**
	 * 生成订单后如果是从购物车提交的，那么要从购物车删除购物车条目信息
	 *
	 * @param order 订单对象
	 */
	public void orderAfterMathInUse(OrderTest order) {
		int length = order.getMerchUuidStringArr().length;
		String merchStandardIndex = null;
		for (int i = 0; i < length; i++) {
			// 删除购物车中条目
			merchStandardIndex = order.getMerchStandardIndexStringArr()[i];
			if (merchStandardIndex != null) {
				merchStandardIndex = merchStandardIndex.replace("@", ",");
			}

			scr.deleteShoppingCartMerchByIdAndIndex(order.getMerchUuidStringArr()[i], merchStandardIndex,
					order.getUserUuid());
		}
	}

	/**
	 * 处理单个订单的方法
	 *
	 * @param order        订单对象
	 * @param validMinutes 订单失效时间
	 * @param reCheckId    一批订单查询的id
	 */
	public void dealwithSingleOrderInUse(OrderTest order, Integer validMinutes, String reCheckId) {
		if (!checkOrderIsValidInUse(order, reCheckId)) {
			logger.warn("订单校验失败");
			return;
		}
		if (order.getIsFlashSale() != null && order.getIsFlashSale() == true) {
			fstb.dealWithFlashSale(order.getUuid());
		} else {
			order.setIsFlashSale(false);
		}

		// jmsOrderSender.sendMsg(OrderOprType.ORDER_SAVE_TYPE.getKey()+JSON.toJSONString(order));
		orderDao.saveOrderTest(order);
		// 发送自动失效的定时信息
		TimeTask task = new TimeTask();
		task.setExecuteTime(LocalDateTime.now().plusMinutes(validMinutes).format(formatter));
		task.setParams(TimerTaskNameType.ORDER_AUTO_INVALID.getName() + order.getOrderNo());
		task.setTimeTaskName(TimerTaskNameType.ORDER_AUTO_INVALID.getName() + order.getOrderNo());
		task.setScheduleOperaType(ScheduleOperaType.ADD_TASK);
		jmsSender.sendMsg(JSON.toJSONString(task));

		// 当标记是来自购物车的时候，才执行删除购物车的操作
		if (order.getIsFromCart() != null && order.getIsFromCart() == true) {
			orderAfterMathInUse(order);
		}
		return;
	}
	// @Resource(name="jmsOrderSender")
	// private JmsOrderSender jmsOrderSender;

	@Override
	/*
	 * 保存订单
	 * 
	 * @param orderlist 订单列表
	 * 
	 * @param validMinutes 失效分钟数
	 */
	public Response saveOrdersInUse(List<OrderTest> orderlist, final Integer validMinutes) {
		JSONObject json = new JSONObject();
		String reCheckId = UserUtils.generateUUid();
		
		if (Regular.checkEmpty(orderlist, null)) {
			logger.warn("解析的订单列表为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}

		for (OrderTest order : orderlist) {
			// executorService.addTask(new ExecutorTask() {
			//
			// @Override
			// public void doJob() {
			dealwithSingleOrderInUse(order, validMinutes, reCheckId);
			// }
			// });
		}
		json.put("reCheckId", reCheckId);
		return Response.success(json);
	}

	@Override
	/**
	 * 改变某个商品的库存
	 *
	 * @param merchUuid
	 *            商品id
	 * @param merchstandarIndex
	 *            商品坐标
	 * @param quantity
	 *            要修改(添加或者删除)的商品数量
	 * @param isReduce
	 *            是否要减少，如果为true那么本方法是减库存，如果为false，本方法是加库存
	 */
	public void changeSingleMerchStock(String merchUuid, String merchStandardIndex, int quantity, Boolean isReduce) {
		if (merchUuid == null || merchStandardIndex == null || quantity <= 0 || isReduce == null) {
			logger.warn("减少单个商品库存失败！商品id:{}", merchUuid);
			return;
		}
		List<MerchandiseStandard> msList = standardRepository.loadMerchandiseStandard(merchUuid);
		if (Regular.checkEmpty(msList, null)) {
			logger.warn("找不到该商品对应的规格数据！请检查！");
			return;
		}
		if (msList.size() > 1) {
			logger.warn("单个商品在数据库中的规格数据不止一个！请检查！商品id:{}", merchUuid);
		}
		MerchandiseStandard ms = msList.get(0);
		if (Regular.checkEmpty(ms.getTopCategoryName(), null)) {
			logger.warn("规格的topCategoryName为空！");
			return;
		}
		Integer[] intarr = orderDao.splitMerchStanIndex(merchStandardIndex);
		if (intarr == null) {
			logger.warn("商品规格转换成Integer数组失败！");
			return;
		}
		int length_1 = intarr.length;
		int length_2 = ms.getTopCategoryName().length;
		if (length_1 != length_2 || length_1 > 2 || length_1 < 1) {
			logger.warn("规格索引解析出来的维度和规格的一级分类数组解析出来的维度不一致！");
			return;
		}
		if (ms.getStocks() == null) {
			logger.warn("找不到该商品对应的规格的库存数据！请检查！");
			return;
		}
		String[][] stocksStrArr = null;
		String stockStr = null;
		int stock = 0;
		if (length_1 == 1) {
			if (intarr[0] == null) {
				logger.warn("一维索引数据解析不正常！");
				return;
			}
			stocksStrArr = ms.getStocks();
			stockStr = stocksStrArr[intarr[0]][0];
			try {
				stock = Integer.parseInt(stockStr);
			} catch (Exception e) {
				return;
			}
			if (isReduce == true) {
				if (stock <= quantity) {
					logger.warn("库存不足！可能是订单校验时出错！");
					return;
				}
				stock -= quantity;
			} else {
				stock += quantity;
			}
			stocksStrArr[intarr[0]][0] = String.valueOf(stock);
			ms.setStocks(stocksStrArr);
			standardRepository.save(ms);

		}
		if (length_1 == 2) {
			if (intarr[0] == null || intarr[1] == null) {
				logger.warn("一维索引数据解析不正常！");
				return;
			}

			stocksStrArr = ms.getStocks();
			stockStr = stocksStrArr[intarr[0]][intarr[1]];
			try {
				stock = Integer.parseInt(stockStr);
			} catch (Exception e) {
				return;
			}

			if (isReduce == true) {
				if (stock <= quantity) {
					logger.warn("库存不足！可能是订单校验时出错！");
					return;
				}
				stock -= quantity;
			} else {
				stock += quantity;
			}
			stocksStrArr[intarr[0]][intarr[1]] = String.valueOf(stock);
			ms.setStocks(stocksStrArr);
			standardRepository.save(ms);
		}
	}

	@Override
	/**
	 * 查询不同状态下订单数目
	 *
	 * @param userUuid
	 *            用户id
	 */
	public Response countNumberOfOrdersByStatus(String userUuid) {
		if (userUuid == null) {
			logger.warn("查询不同状态订单数目的时候，useruuid为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		} else {
			logger.info("开始获取用户id为{}的不同状态订单的数目" + userUuid);
			List<Object[]> objlist = orderTestRepository.countNumberOfOrdersByStatus(userUuid);
			List<OrderStatusCount> osclist = new ArrayList<>();
			OrderStatusCount osc = null;
			for (Object[] objarr : objlist) {
				osc = new OrderStatusCount();
				osc.setStatus(objarr[0].toString());
				osc.setCount(objarr[1].toString());
				osclist.add(osc);
			}
			if (osclist != null && osclist.size() > 0) {
				logger.info("获取用户id为{}的不同状态订单的数目成功！" + userUuid);
				JSONObject json = new JSONObject();
				json.put("key", osclist);
				return Response.success(json);
			} else {
				return Response.success();
			}
		}
	}

	/**
	 * 根据订单号查询订单
	 *
	 * @param uuid 订单id
	 */
	@Override

	public Response findOrderTestsbyOrderUuid(String uuid) {

		List<OrderTest> orderlist = orderTestRepository.findOrderTestsbyOrderUuid(uuid);
		if (Regular.checkEmpty(orderlist, null)) {
			return Response.success();
		}
		if (orderlist.size() > 1) {
			logger.warn("订单号为{}的订单在数据库中的条目不唯一！请检查", uuid);
		}
		OrderTest order = orderlist.get(0);
		if(order == null){
			logger.warn("订单号为{}的订单order==null！请检查", uuid);
		}
		String[] merchStandardIndexStringArr = DataConverUtils.byteArr2StringArr(order.getMerchStandardIndex());
		String[] merchSpecStringArr = DataConverUtils.byteArr2StringArr(order.getMerchSpec());
		if(merchStandardIndexStringArr == null || merchSpecStringArr == null ||merchStandardIndexStringArr.length != merchSpecStringArr.length){
			logger.warn("查询订单的时候，orderUuid为{}的订单，坐标字符串数组为空，或者规格字符串数组为空，或者以上两者的长度不一致！",uuid);
			return Response.error("坐标字符串数组为空，或者规格字符串数组为空，或者以上两者的长度不一致！");
		}
		if (merchStandardIndexStringArr != null) {
			for (int j = 0; j < merchStandardIndexStringArr.length; j++) {
				merchStandardIndexStringArr[j] = merchStandardIndexStringArr[j].replace("@", ",");
				merchSpecStringArr[j] = merchSpecStringArr[j].replace("@", ",");
			}
		}

		order.setMerchStandardIndexStringArr(merchStandardIndexStringArr);
		order.setMerchNameStringArr(DataConverUtils.byteArr2StringArr(order.getMerchName()));
		order.setMerchPicStringArr(DataConverUtils.byteArr2StringArr(order.getMerchPic()));
		order.setMerchQuantityStringArr(DataConverUtils.byteArr2StringArr(order.getMerchQuantity()));
		order.setMerchSpecStringArr(merchSpecStringArr);
		order.setMerchStandardUuidStringArr(DataConverUtils.byteArr2StringArr(order.getMerchStandardUuid()));
		order.setMerchUuidStringArr(DataConverUtils.byteArr2StringArr(order.getMerchUuid()));
		order.setMerchPriceStringArr(DataConverUtils.byteArr2StringArr(order.getMerchPrice()));

		return Response.success(order);
	}

	/**
	 * 保存购物车条目
	 *
	 * @param incomescmlist 要保存的前端传入的购物车列表
	 * @param userUuid      用户id
	 */
	@Override
	public Response saveShopCartMerch(List<ShoppingCartMerch> incomescmlist, String userUuid) {
		if (Regular.checkEmpty(incomescmlist, null)) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (userUuid == null) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		Boolean flag = true;
		ShoppingCartMerch newScm = null;
		List<ShoppingCartMerch> scmlist = null;
		for (ShoppingCartMerch scm : incomescmlist) {
			// 如果列表中某个商品没有传递规格索引数据过来，那么将无法判定购物车中原本有没有这个规格的商品存在，所以添加失败。
			if (scm == null || scm.getMerchStandardIndex() == null || scm.getMerchUuid() == null
					|| scm.getQuantity() <= 0) {
				logger.warn("用户{}将要添加到购物车的商品中，出现了异常，原因有可能是1、商品索引为空或2、商品本身数据为空。3、商品uuid为空。4、商品数量不是正整数", userUuid);
				flag = false;
				continue;
			}
			if (scm.getUserUuid() == null) {
				logger.warn("商品{}，规格{}添加至购物车没有携带userUuid数据，请检查！", scm.getMerchUuid(), scm.getMerchStandardIndex());
			}
			if (!scm.getUserUuid().equals(userUuid)) {
				logger.warn("商品信息中传入的userUuid{}和直接做为参数传入的userUuid{}不一致！请检查！", scm.getUserUuid(), userUuid);
				flag = false;
				continue;
			}
			StringBuilder builder = new StringBuilder();
			builder.append(scm.getUserUuid()).append(scm.getMerchStandardIndex()).append(scm.getMerchUuid());
			String currentTime = "";
			try{
				int lockNumber = 0;
				String paramString = builder.toString();
				if(paramString == null){
					return Response.error("保存购物车商品时，准备加锁，但是用来加锁的字符串为null");
				}
				while(!lock.lock(LockType.SHOP_CART_LOCK, builder.toString())){
					//加入判断条件，不要永远循环下去
					lockNumber++;
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if(lockNumber > 100){
						return Response.error("等待锁的时间大于五秒！请求失败！");
					}
				}
				scmlist = scr.checkShoppingCartMerchNumber(scm.getMerchUuid(), scm.getMerchStandardIndex(), userUuid);
				if (scmlist != null && scmlist.size() > 0 && scmlist.get(0) != null) {// 说明数据库中
					// 购物车商品
					// 这个表中，已经含有这个规格的这款商品，所以只需要将数字加上去

					if (scmlist.size() > 1) {
						logger.warn("商品id为---{}---规格索引为---{}---用户id为---{}----的购物车商品数据条目并不唯一！", scm.getMerchUuid(),
								scm.getMerchStandardIndex(), userUuid);
						for(int i=1; i < scmlist.size(); i++){
							if(scmlist.get(i)!=null){
								scr.deleteShoppingCartMerch(scmlist.get(i).getUuid());
							}
						}
					}
					newScm = scmlist.get(0);
					int number = newScm.getQuantity() + scm.getQuantity();

					logger.info("开始添加" + scm.getMerchUuid() + "到购物车已有条目");
					scr.addGoodToCart(newScm.getUuid(), number, Timestamp.from(Instant.now()));
					logger.info("成功添加" + scm.getMerchUuid() + "到购物车已有条目");
				} else {
					logger.info("开始新增" + scm.getMerchUuid() + "到购物车");
					// 为 购物车商品 这个表的每一条数据生成一个uuid
					scm.setUuid(UserUtils.generateIncrementId());
					scm.setCreateTime(Timestamp.from(Instant.now()));
					scr.save(scm);
					logger.info("成功新增" + scm.getMerchUuid() + "到购物车");
				}
				currentTime = lock.getLock(LockType.SHOP_CART_LOCK, builder.toString());
			}finally {
				lock.unLock(LockType.SHOP_CART_LOCK, builder.toString(), currentTime);
			}
		}
		if (flag == false) {
			return Response.success("购物车商品全部或者有部分没有添加成功！请查看日志！原因有可能是1、该商品索引为空或2、商品本身数据为空");
		} else {
			return Response.success("成功添加所有商品到购物车！");
		}
	}

	/**
	 * 删除购物车条目
	 *
	 * @param scmlist 要删除的购物车条目列表
	 */
	@Override
	public Response deleteShoppingCartMerch(List<ShoppingCartMerch> scmlist) {
		Boolean flag = true;
		for (ShoppingCartMerch scm : scmlist) {
			if (scm == null) {
				logger.warn("删除购物车的时候，有商品条目数据为空！");
				flag = false;
				continue;
			}
			if (scm.getUuid() == null) {
				logger.warn("购物车商品条目的id为空！删除失败！");
				flag = false;
				continue;
			}
			logger.info("开始从购物车删除商品{}", scm.getMerchName());
			scr.deleteShoppingCartMerch(scm.getUuid());
			logger.info("成功从购物车删除商品{}", scm.getMerchName());
		}
		if (flag == false) {
			return Response.success("可能有部分条目没有完全删除！");
		} else {
			return Response.success("成功删除所有购物车条目");
		}

	}

	@Autowired
	private Lock lock;
	@Autowired
	private OrderPayTempRepository optr;

	@Override
	public Response appPayResultInfo(String out_trade_no, String userUuid, String random_code) {
		
		if (out_trade_no == null) {
			logger.warn("付款号为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
//		if(random_code == null){
//			logger.warn("random_code为null！");
//			return Response.response(ResponseType.EMPTY_CODE.getCode());
//		}
		if(userUuid == null){
			logger.warn("appPayResultInfo-----userUuid为null！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		
		logger.warn("付款号{}，接收到APP端**付款成功**的通知！",out_trade_no);
		
		String currentTime = "";

		//        String cacheResult = "";
		//        String resultKey = out_trade_no + "payResult";
		try {
			int lockNumber = 0;
			while (!lock.lock(LockType.PAY_RESULT_LOCK, out_trade_no)) {
				lockNumber++;
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(lockNumber>100){
					logger.warn("APP付款的时候，加锁时间等待了五秒，超时退出！");
					currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
					return Response.error("APP付款的时候，加锁时间等待了五秒，超时退出！");
				}
			}
			//            cacheResult = cache.getCache(resultKey);
			//            if (cacheResult == null || cacheResult.equals("") || !cacheResult.equals("thirdPaySuccess")) {
			//                cache.setCache(resultKey, "appSuccess");
			//            } else if (cacheResult.equals("thirdPaySuccess")) {
			//
			//
			//                String sbuildString = cache.getCache(out_trade_no);
			//
			//                if (sbuildString == null || sbuildString.equals("")) {
			//                    logger.warn("缓存中的存入的交易号为{}的value解析错误！");
			//                    return Response.error("缓存中的存入的交易号为" + out_trade_no + "的value解析错误");
			//                }
			//
			//                String[] keyArr = sbuildString.split(",");
			List<OrderPayTemp> optList = optr.loadAllOrderPayTemp(out_trade_no);

			if(optList == null || optList.size() == 0 || optList.get(0) == null){
				logger.warn("客户端结果返回的时候，数据库中的OrderPayTemp表中没有out_trade_no为{}的数据！请检查！", out_trade_no);
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return Response.error("数据库中的OrderPayTemp表中没有out_trade_no为{"+ out_trade_no +"}的数据！请检查！付款失败!"); 
			}

			OrderPayTemp opt = optList.get(0);
			
			if(opt.getTotal_amount() == null || opt.getOrderNo() == null){
				logger.warn("APP端结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{}的数据opt.getTotal_amount() == null || opt.getOrderNo() == null！请检查！", out_trade_no);
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return Response.error("APP端结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{"+ out_trade_no +"}的数据opt.getTotal_amount() == null || opt.getOrderNo() == null！请检查！付款失败!");  
			}
			if(opt.getUserUuid() == null || !opt.getUserUuid().equals(userUuid)){
				logger.warn("传入的userUuid{}和临时表中存的{}不同，或者临时表中的userUuid为null！",userUuid,opt.getUserUuid());
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return Response.error("APP端第三方结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{"+ out_trade_no +"}的数据传入的userUuid和临时表中存的不同，或者临时表中的userUuid为null！请检查！付款失败!");  
			}
			if(opt.getMercherName() == null || opt.getSingleOrderPrice() == null){
				logger.warn("APP端结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{}的数据opt.getMercherName() == null || opt.getSingleOrderPrice() == null！请检查！", out_trade_no);
			}
//			if(opt.getRandom_code() == null){
//				logger.warn("付款号{}对应的临时表中的Random_code为null！",out_trade_no);
//				return Response.error("APP在进行付款结果通知的时候，付款号{"+out_trade_no+"}临时表中的Random_code为null");
//			}
//			if(opt.getRandom_code() != random_code){
//				logger.warn("付款号{}对应的临时表中的random_code和APP传递进来的random_code不一致！",out_trade_no);
//				return Response.error("APP在进行付款结果通知的时候，付款号{"+out_trade_no+"}临时表中的random_code和APP传递进来的random_code不一致!");
//			}
			JSONObject json = new JSONObject();
			if(opt.getThirdPayResult() != null && opt.getThirdPayResult() == 1){
				logger.warn("已经接收到APP端成功付款通知的付款号{}，现在已经检测到第三方付款已经成功！准备修改所属订单为已付款！");
				String [] orderNoArr = opt.getOrderNo().split("@");
				String [] mercherNameArr = opt.getMercherName().split("@");
				String [] orderPriceArr = opt.getSingleOrderPrice().split("@");
				if(orderNoArr == null || mercherNameArr == null || orderPriceArr == null || orderNoArr.length != mercherNameArr.length || orderNoArr.length < 1){
					logger.warn("付款号：{}，在临时表中存储的 orderNo串 和 mercherName串 解析不正确！", out_trade_no);
					return Response.error("付款号：{"+out_trade_no+"}，在临时表中存储的 orderNo串 和 mercherName串 解析不正确！"); 
				}
				for(int i = 0; i< orderNoArr.length; i++){
					orderTestRepository.changeOrderStatusByOrderNo(orderNoArr[i], 2,Timestamp.from(Instant.now()));
					if(opmoRepository.countPaymentNoInOPMO(out_trade_no) == 0){
					OnePaymentNoToManyOrderNo opmo = new OnePaymentNoToManyOrderNo();
					opmo.setOrderNo(orderNoArr[i]);
					opmo.setCreateTime(Timestamp.from(Instant.now()));
					opmo.setMerchandiserUuid(mercherNameArr[i]);
					opmo.setPaymentNo(out_trade_no);
					try{
						opmo.setOrderAmount(Double.parseDouble(orderPriceArr[i]));
					}catch (Exception e){
						logger.warn("opmo.setOrderAmount(Double.parseDouble(orderPriceArr[i]))报错！收到支付宝支付成功通知的付款号{}", out_trade_no);
						return Response.error("opmo.setOrderAmount(Double.parseDouble(orderPriceArr[i]))报错！收到支付宝支付成功通知的付款号{"+out_trade_no+"}");
					}
					opmoRepository.save(opmo);
					}
				}
				logger.info("付款号{}成功付款，其所属订单全部改为已付款状态！", out_trade_no);
				optr.setPaymentPayed(out_trade_no);
				json.put("result", "success");
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return Response.success(json);
			}else{
				logger.warn("已经接收到APP端成功付款通知的付款号{},没有检测到第三方付款成功的标识，将持续请求检测！");
				optr.setAppResultTrue(out_trade_no);
				json.put("result", "wait");
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return Response.success(json);
			}

			//                cache.deleteCache(resultKey);
			//                cache.deleteCache(out_trade_no);
			//            }

		} finally {
			lock.unLock(LockType.PAY_RESULT_LOCK, out_trade_no, currentTime);
		}
	}
/**
 * 第三方付款结果通知
 */
	@Override
	public String thirdPayResultInfo(HttpServletRequest req) {

		String out_trade_no = req.getParameter("out_trade_no");
		String total_amount = req.getParameter("total_amount");
		String app_id = req.getParameter("app_id");
		logger.warn("接收到支付宝传递的回调参数，其中的参数有：out_trade_no=={}，total_amount=={}，app_id=={}",out_trade_no,total_amount,app_id);
		if (app_id == null || out_trade_no == null || total_amount == null || !app_id.equals(AlipayConfig.app_id)) {
			logger.warn("app_id == null || out_trade_no == null || total_amount == null || !app_id.equals(AlipayConfig.app_id)，返回给支付宝failture");
			return "failture";
		}
		String currentTime = "";
		try {
			int lockNumber = 0;
			
			while (!lock.lock(LockType.PAY_RESULT_LOCK, out_trade_no)) {
				lockNumber++;
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				logger.warn("app中的lockNumber={}",lockNumber);
				if(lockNumber > 100){
					currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
					return "failture";
				}
			}
			List<OrderPayTemp> optList = optr.loadAllOrderPayTemp(out_trade_no);
			if(optList == null || optList.size() == 0 || optList.get(0) == null){
				logger.warn("支付宝结果返回的时候，数据库中的OrderPayTemp表中没有out_trade_no为{}的数据！请检查！", out_trade_no);
				return "failture"; 
			}
			OrderPayTemp opt = optList.get(0);
			if(opt.getTotal_amount() == null || opt.getOrderNo() == null){
				logger.warn("支付宝结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{}的数据opt.getTotal_amount() == null || opt.getOrderNo() == null！请检查！", out_trade_no);
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return "failture"; 
			}
			if(opt.getMercherName() == null || opt.getSingleOrderPrice() == null){
				logger.warn("支付宝结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{}的数据opt.getMercherName() == null || opt.getSingleOrderPrice() == null！请检查！", out_trade_no);
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return "failture"; 
			}
			
			if(!total_amount.equals(opt.getTotal_amount())){
				logger.warn("支付宝结果返回的时候，数据库中的OrderPayTemp表中out_trade_no为{}的价格与支付宝回调传入的价格不一致！请检查！", out_trade_no);
				currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
				return "failture"; 
			}
			if(opt.getAppResult() != null && opt.getAppResult() == 1){
				logger.warn("收到支付宝支付成功通知的付款号{},现在检测到APP方付款已经成功！准备修改所属订单为已付款！", out_trade_no);
				logger.warn("第三方付款了当前时间是！===={}",System.currentTimeMillis());
				String [] orderNoArr = opt.getOrderNo().split("@");
				String [] mercherNameArr = opt.getMercherName().split("@");
				String [] orderPriceArr = opt.getSingleOrderPrice().split("@");
					if(orderNoArr == null || mercherNameArr == null || orderPriceArr == null || orderNoArr.length != mercherNameArr.length || orderNoArr.length < 1){
					logger.warn("付款号：{}，在临时表中存储的 orderNo串 和 mercherName串 解析不正确！", out_trade_no);
					currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
					return "failture"; 
				}
				for(int i = 0; i< orderNoArr.length; i++){
					orderTestRepository.changeOrderStatusByOrderNo(orderNoArr[i], 2,Timestamp.from(Instant.now()));
					if(opmoRepository.countPaymentNoInOPMO(out_trade_no) == 0){
						OnePaymentNoToManyOrderNo opmo = new OnePaymentNoToManyOrderNo();
						opmo.setOrderNo(orderNoArr[i]);
						opmo.setCreateTime(Timestamp.from(Instant.now()));
						opmo.setMerchandiserUuid(mercherNameArr[i]);
						opmo.setPaymentNo(out_trade_no);
						try{
							opmo.setOrderAmount(Double.parseDouble(orderPriceArr[i]));
						}catch (Exception e){
							logger.warn("opmo.setOrderAmount(Double.parseDouble(orderPriceArr[i]))报错！收到支付宝支付成功通知的付款号{}", out_trade_no);
							currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
							return "failture";
						}
						opmoRepository.save(opmo);
					}
					
				}
				logger.warn("付款号{},所属订单成功修改为已付款！", out_trade_no);
				optr.setPaymentPayed(out_trade_no);
			}else{
				logger.warn("付款号{}已经收到支付宝付款结果，然而在这之前，没有收到app端的通知结果，继续等待APP端结果！", out_trade_no);
				optr.setThirdResultTrue(out_trade_no);
			}
			currentTime = lock.getLock(LockType.PAY_RESULT_LOCK, out_trade_no);
		}finally{
			lock.unLock(LockType.PAY_RESULT_LOCK, out_trade_no, currentTime);
		}

		return "success";

		//            cacheResult = cache.getCache(resultKey);
		//            if (cacheResult == null || cacheResult.equals("") || !cacheResult.equals("appSuccess")) {
		//                cache.setCache(resultKey, "thirdPaySuccess");
		//            } else if (cacheResult.equals("appSuccess")) {
		//                for (int i = 1; i < keyArr.length; i++) {
		//                    orderTestRepository.changeOrderStatusByOrderNo(keyArr[i], 2,
		//                            Timestamp.from(Instant.now()));
		//                }
		//                cache.deleteCache(resultKey);
		//                cache.deleteCache(out_trade_no);
		//                return "success";
		//            }
	}


	@Override
	public String wxPayCallbackResult(HttpServletRequest req){
		logger.warn("到达service方法");

		return "success";
	}


	@Override
	/**
	 * 订单付款
	 *
	 * @param
	 */
	public Response payOrder(Integer payType, String data, String userUuid, Double totalPrice, Double balancePrice,
			String body, String subject) {

		logger.info("开始提交付款，用户id{}", userUuid);

		String paymentNo = UserUtils.generateIncrementId();

		OrderPayTemp opt = new OrderPayTemp();

		opt.setPaymentNo(paymentNo);


		List<OrderTest> orderlist = JSONArray.parseArray(data, OrderTest.class);

		if (orderlist == null || orderlist.size() <= 0) {
			logger.warn("要付款的订单列表解析为空！");
			return Response.error("要付款的订单列表解析为空！");
		}

		Double actualTotalPrice = 0.0;
		Double orderPrice = null;
		Integer status = null;
		OrderTest order = null;

		if (userUuid == null) {
			logger.warn("传入的用户id为空！");
			return Response.error("传入的用户id为空！");
		}
		// 验证传入数据是否和数据库中的订单一致！

		String orderNo = null;

		StringBuilder sbuilder = new StringBuilder();
		
		StringBuilder mercherName = new StringBuilder();
		
		StringBuilder singleOrderPrice = new StringBuilder();
		
		for (int i = 0; i < orderlist.size(); i++) {
			order = orderlist.get(i);
			orderNo = order.getOrderNo();
			if (orderNo == null) {
				return Response.error("要付款的订单中，有的订单的订单号为空！付款失败！");
			}

			List<OrderTest> otList = orderTestRepository.loadPriceAndStatusOfSingleOrder(order.getOrderNo());
			if (otList == null || otList.size() == 0 || otList.get(0) == null) {
				return Response.error("订单号" + order.getOrderNo() + "对应的数据为空");
			}
			OrderTest ot = otList.get(0);
			orderPrice = ot.getTotalPrice();
			if (orderPrice == null) {
				return Response.error("订单号" + order.getOrderNo() + "对应的价格为空");
			}
			if (ot.getUserUuid() == null || !userUuid.equals(ot.getUserUuid())) {
				return Response.error("订单号" + order.getOrderNo() + "中的用户id和传入的用户id不一致！");
			}
			status = ot.getStatus();
			if (status == null || status != 1) {
				return Response.error("订单号" + order.getOrderNo() + "对应的订单并不处于待付款状态或者状态为空！");
			}
			if (Math.abs(Arith.subtract(2, orderPrice, order.getTotalPrice())) > 0.001) {
				return Response.error("订单号" + order.getOrderNo() + "传入的价格和数据库中不一致，订单付款失败，请检查！");
			}
			actualTotalPrice = Arith.add(2, actualTotalPrice, orderPrice);
			sbuilder.append(orderNo);
			mercherName.append(ot.getMerchandiserUuid());
			singleOrderPrice.append(orderPrice);
			if (i != (orderlist.size() - 1)) {
				sbuilder.append("@");
				mercherName.append("@");
				singleOrderPrice.append("@");
			}
		}
		if (actualTotalPrice <= 0) {
			logger.warn("传入的订单总价不为正数！");
			return Response.error("传入的订单总价不为正数！");
		}
		if (Math.abs(Arith.subtract(4, totalPrice, actualTotalPrice)) > 0.0001) {
			return Response.error("订单实际总价与前端传入不一致！");
		}
		if (payType == null || payType < 1 || payType > 4) {
			logger.warn("付款方式为空或者不为约定的1-4，却为：{}", payType);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}

		//String random_code = UserUtils.generateIncrementId();
		
		// 1是余额付款，2是支付宝付款 4是微信付款
		switch (payType) {
		// 用余额付款
		case 1:

			return this.dealWithPayType_1(userUuid, totalPrice, orderlist);

		case 2:
			//把订单信息保存到临时表中，以便统计，比如说付款了，那么就统计当日销售额，确认收货了，就统计当日金钱收入。
			opt.setTotal_amount(String.valueOf(totalPrice));

			opt.setOrderNo(sbuilder.toString());
			
			//opt.setRandom_code(random_code);
			
			opt.setSingleOrderPrice(singleOrderPrice.toString());
			
			opt.setMercherName(mercherName.toString());
			
			opt.setUserUuid(userUuid);
			//用多线程做
			optr.save(opt);
			

			//把总价，及各种订单号拼接的数据和付款号放入缓存，暂时先用数据库存储，后续改成缓存
			//cache.setCache(paymentNo, sbuilder.toString());

			return this.dealWithPayType_2(body, subject, totalPrice, opt.getPaymentNo(), null);


		case 3:
			boolean flag_3 = true;
			if(this.dealWithPayType_1(userUuid, balancePrice, orderlist).getCode()!=200){
				flag_3 = false;
			}
//			if(this.dealWithPayType_2(body, subject, Arith.subtract(2, totalPrice, balancePrice),opt.getPaymentNo(), random_code).getCode() != 200){
//				flag_3 = false;
//			}
			if(flag_3){
				return Response.success();
			}else{
				return Response.error("付款失败！查看日志！");
			}
			//微信支付
		case 4:
			opt.setTotal_amount(String.valueOf(totalPrice));

			opt.setOrderNo(sbuilder.toString());

			optr.save(opt);

		}

		logger.info("结束提交付款,用户id{}", userUuid);

		return Response.success();
	}
	@Override
	//微信支付
	public Response dealWithPayType_4(HttpServletRequest req, String userUuid, String body, String subject, Double totalPrice, String out_trade_no){
		try {
			logger.info("用户{} 开始获取支付参数 支付的费用为{} 订单号为 {}", userUuid, totalPrice, out_trade_no);
			SortedMap<String, String> packageParams = new TreeMap<>();
			packageParams.put("appid", WxPayConfig.appid);
			packageParams.put("mch_id", WxPayConfig.partner);
			packageParams.put("nonce_str", UserUtils.generateUUid());
			packageParams.put("body", body);
			packageParams.put("out_trade_no", out_trade_no);
			packageParams.put("total_fee", Math.round(totalPrice*100)+"");
			//packageParams.put("spbill_create_ip", req.getRemoteAddr());
			packageParams.put("spbill_create_ip", "192.168.121.1");
			packageParams.put("notify_url", WxPayConfig.notify_url);
			packageParams.put("trade_type", WxPayConfig.trade_type);
			String sign = MD5Util.createSign(packageParams);

			packageParams.put("sign", sign);

			SortedMap<String,Object> objMap = new TreeMap<>();

			objMap.put("appid", WxPayConfig.appid);
			objMap.put("mch_id", WxPayConfig.partner);
			objMap.put("nonce_str", UserUtils.generateUUid());
			objMap.put("body", body);
			objMap.put("out_trade_no", out_trade_no);
			objMap.put("total_fee", Math.round(totalPrice*100)+"");
			objMap.put("spbill_create_ip", "192.168.121.1");
			objMap.put("notify_url", WxPayConfig.notify_url);
			objMap.put("trade_type", WxPayConfig.trade_type);
			objMap.put("sign", sign);


			StringBuilder builder = new StringBuilder();
			builder.append("<xml>");
			builder.append("<appid>");
			builder.append(WxPayConfig.appid);
			builder.append("</appid>");
			builder.append("<mch_id>");
			builder.append(WxPayConfig.partner);
			builder.append("</mch_id>");
			builder.append("<nonce_str>");
			builder.append(packageParams.get("nonce_str"));
			builder.append("</nonce_str>");
			builder.append("<sign>");
			builder.append(sign);
			builder.append("</sign>");
			builder.append("<body><![CDATA[");
			builder.append(body);
			builder.append("]]></body>");
			builder.append("<out_trade_no>");
			builder.append(out_trade_no);
			builder.append("</out_trade_no>");
			builder.append("<total_fee>");
			builder.append(packageParams.get("total_fee"));
			builder.append("</total_fee>");
			builder.append("<spbill_create_ip>");
			builder.append(packageParams.get("spbill_create_ip"));
			builder.append("</spbill_create_ip>");
			builder.append("<notify_url>");
			builder.append(packageParams.get("notify_url"));
			builder.append("</notify_url>");
			builder.append("<trade_type>");
			builder.append(WxPayConfig.trade_type);
			builder.append("</trade_type>");
			builder.append("</xml>");
			String prepay_id = HttpTools.doGets("https://api.mch.weixin.qq.com/pay/unifiedorder", "<xml></xml>");



		}catch (Exception e) {
			e.printStackTrace();
			logger.warn("用户{}  获取支付参数 支付的费用为{} 订单号为 {} 出错{}", userUuid, totalPrice, out_trade_no, e);
		}


		return null;
	}
	@Override
	public Response checkThirdPayResult(String paymentNo){
		List<Integer> ilist = optr.checkThirdPayResult(paymentNo);
		JSONObject json = new JSONObject();
		if(ilist != null && ilist.get(0) != null && ilist.get(0) == 1){
			json.put("result", "success");
		}else{
			json.put("result", "failture");
		}
		return Response.success(json);
	}
	
	
	private Response dealWithPayType_2(String body, String subject, Double totalPrice, String out_trade_no, String random_code) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		

		Map<String, String> map = new TreeMap<String, String>();
		map.put("app_id", AlipayConfig.app_id);
		map.put("method", "alipay.trade.app.pay");
		map.put("format", "json");
		map.put("charset", "utf-8");
		map.put("sign_type", "RSA");
		map.put("timestamp", LocalDateTime.now().format(formatter));
		map.put("version", "1.0");
		map.put("notify_url", AlipayConfig.service);

		JSONObject json = new JSONObject();
		json.put("app_id", AlipayConfig.app_id);
		json.put("method", "alipay.trade.app.pay");
		json.put("format", "json");
		json.put("charset", "utf-8");
		json.put("sign_type", "RSA");
		json.put("timestamp", LocalDateTime.now().format(formatter));
		json.put("version", "1.0");
		json.put("notify_url", AlipayConfig.service);

		Map<String, String> content = new TreeMap<String, String>();

		content.put("body", body);
		content.put("subject", subject);
		content.put("out_trade_no", out_trade_no);
		content.put("timeout_express", "30m");
		content.put("total_amount", String.valueOf(totalPrice));
		content.put("product_code", "QUICK_MSECURITY_PAY");
		//content.put("random_code", random_code);

		String contentJson = JSONObject.toJSONString(content);

		json.put("biz_content", contentJson);

		map.put("biz_content", contentJson);

		String rsaSign = null;

		try {

			rsaSign = AlipaySignature.rsaSign(map, AlipayConfig.private_key, "utf-8");

		} catch (AlipayApiException e) {

			e.printStackTrace();

		}

		json.put("sign", rsaSign);
		//json.put("random_code", random_code);
		json.put("out_trade_no", out_trade_no);

		StringBuilder builder_biz = new StringBuilder();
		builder_biz.append("{").append("\"body\":").append("\"").append(body).append("\",").append("\"subject\":").append("\"").append(subject).append("\",")
		.append("\"out_trade_no\":").append("\"").append(out_trade_no).append("\",").append("\"timeout_express\":").append("\"30m\",").append("\"total_amount\":").append(String.valueOf(totalPrice))
		.append(",").append("\"product_code\":").append("\"QUICK_MSECURITY_PAY\"").append("}");

		StringBuilder builder_url = new StringBuilder();

		builder_url.append("app_id=").append(AlipayConfig.app_id).append("&biz_content=").append(builder_biz.toString()).append("&charset=").append("utf-8").append("&format=").append("json").append("&method=").append("alipay.trade.app.pay")

		.append("&notify_url=").append(AlipayConfig.service).append("&sign=").append(rsaSign).append("&sign_type=").append("RSA").append("&timestamp=").append(LocalDateTime.now().format(formatter))
		.append("&version=").append("1.0");

		json.put("url", builder_url.toString());

		return Response.success(json);

	}

	public Response dealWithPayType_1(String userUuid, Double totalPrice, List<OrderTest> orderlist) {
		logger.warn("用户{}的用余额付款操作进入了！",userUuid);
		Double userCount = null;
		Map<String, Object> params = new HashMap<>();
		params.put("uuid", userUuid);
		String httpResult = HttpTools.doPost("http://api.welicn.com:9203/user/login/countMoney/tourist.do", params);
		JSONObject json = JSON.parseObject(httpResult);
		JSONObject money = new JSONObject();
		if(json != null && json.get("data") != null){
			money = JSON.parseObject(json.get("data").toString());
		}
		String userCountAmountStr = null;
		if(money!=null){
			userCountAmountStr = String.valueOf(money.get("money")) ;
		}
		if(userCountAmountStr == null){
			logger.warn("查询不到余额！");
			return Response.error("查询不到余额");
		}

		try {
			userCount = Double.parseDouble(userCountAmountStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (totalPrice > userCount) {
			logger.warn("用户{}余额不足！使用余额付款失败!payType=1", userUuid);
			return Response.error("用户" + userUuid + "余额不足！使用余额付款失败!payType=1");
		}
		// 发送请求，让user扣款，如果成功了
		// 直接发送tourist请求，进行减钱的操作是否稳妥？还是要用jms？
		params.put("money", totalPrice);
		String resultString = HttpTools.doPost("http://api.welicn.com:9203/user/login/delGold/tourist.do", params);
		int resultCode = 0;
		try {
			resultCode = Integer.parseInt(resultString);
		} catch (Exception e) {
		}
		if (resultCode > 0) {
			orderlist.forEach(item -> {
				logger.info("开始改变订单号为{}的订单为已付款！", item.getOrderNo());
				orderTestRepository.changeOrderStatusByOrderNo(item.getOrderNo(), 2, Timestamp.from(Instant.now()));
				logger.info("成功改变订单号为{}的订单为已付款！", item.getOrderNo());
			});
		} else {
			logger.warn("用户减钱失败！resultCode={}", resultCode);
			return Response.error("用户减钱失败！");
		}

		return Response.success();
	}


	/**
	 * 改变购物车商品数量
	 *
	 * @param uuid     购物车条目id
	 * @param 要改变的目的数量
	 */
	@Override
	public Response changeCartMerchQuantity(String uuid, Integer number) {
		if (uuid != null && number != null) {
			scr.changeCartMerchQuantity(uuid, number);
			return Response.success("成功改变购物车商品数量！");
		} else {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
	}

	/**
	 * 根据用户id查询其所有订单
	 *
	 * @param userUuid  用户id
	 * @param sortOrder 排序方向
	 * @param page      页数
	 * @param pageCount 每页订单数
	 * @param status    订单状态
	 */
	@Override
	public Response findOrdersByUserUuid_service(String userUuid, Integer sortOrder, Integer page, Integer pageCount,
			Integer status) {
		if (userUuid == null) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (pageCount == null || pageCount < 1) {
			pageCount = 20;
		}
		if (page == null || page < 1) {
			page = 0;
		} else {
			page = page - 1;
		}
		logger.info("开始获取用户id为{}的订单信息！",userUuid);
		Pageable pageable = new PageRequest(page, pageCount);
		List<OrderTest> orderList = null;
		if (status != null && status < 7 && status > 0) {
			orderList = orderTestRepository.listAllOrdersByUserUuid(userUuid, status, pageable);
		} else {
			orderList = orderTestRepository.listAllOrdersByUserUuidAllStatus(userUuid, pageable);
		}

		String[] merchStandardIndexStringArr = null;
		String[] merchSpecStringArr = null;
		JSONObject json = new JSONObject();
		if (orderList == null || orderList.size() <= 0) {
			json.put("content", null);
			return Response.success(json);
		}
		for (OrderTest order : orderList) {
			merchStandardIndexStringArr = DataConverUtils.byteArr2StringArr(order.getMerchStandardIndex());
			merchSpecStringArr = DataConverUtils.byteArr2StringArr(order.getMerchSpec());
			if (merchStandardIndexStringArr != null && merchSpecStringArr != null && merchSpecStringArr.length == merchStandardIndexStringArr.length) {
				for (int j = 0; j < merchStandardIndexStringArr.length; j++) {
					merchStandardIndexStringArr[j] = merchStandardIndexStringArr[j].replace("@", ",");
					merchSpecStringArr[j] = merchSpecStringArr[j].replace("@", ",");
				}
			}

			order.setMerchStandardIndexStringArr(merchStandardIndexStringArr);
			order.setMerchNameStringArr(DataConverUtils.byteArr2StringArr(order.getMerchName()));
			order.setMerchPicStringArr(DataConverUtils.byteArr2StringArr(order.getMerchPic()));
			order.setMerchQuantityStringArr(DataConverUtils.byteArr2StringArr(order.getMerchQuantity()));
			order.setMerchSpecStringArr(merchSpecStringArr);
			order.setMerchStandardUuidStringArr(DataConverUtils.byteArr2StringArr(order.getMerchStandardUuid()));
			order.setMerchUuidStringArr(DataConverUtils.byteArr2StringArr(order.getMerchUuid()));
			order.setMerchPriceStringArr(DataConverUtils.byteArr2StringArr(order.getMerchPrice()));

		}

		json.put("content", orderList);
		logger.info("结束获取用户id为{}的订单信息！",userUuid);
		return Response.success(json);

	}

	/**
	 * 改变购物车商品规格
	 *
	 * @param userUuid           用户id
	 * @param uuid               购物车条目id
	 * @param merchUuid          商品id
	 * @param merchStandardIndex 商品坐标
	 * @param quantity           要改变的目标数量
	 */
	@Override
	public Response changeShoppingcartMerchStandard(String userUuid, String uuid, String merchUuid,
			String merchStandardIndex, Integer quantity) {
		// 判断参数是否为空
		if (uuid == null) {
			logger.warn("uuid为空");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (merchUuid == null) {
			logger.warn("merchUuid为空");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (merchStandardIndex == null) {
			logger.warn("merchStandardIndex为空");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (quantity == null || quantity <= 0) {
			logger.warn("传入的商品数量为空或不为正！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}

		// 根据id获取要修改的原条目在数据库中的数据，和传入的数据做对比，以免出现异常情况。
		List<ShoppingCartMerch> scmList = scr.loadSingleShopCartMerchByUuid(uuid);

		if (scmList == null || scmList.size() < 1) {
			logger.warn("传入的uuid-->{}在数据库中没有数据！", uuid);
			return Response.error("传入的uuid" + uuid + "在数据库中没有数据！");
		}

		if (scmList.size() > 1) {
			logger.warn("传入的uuid-----{}对应到至少两个购物车条目！异常请检查！", uuid);
		}

		ShoppingCartMerch roughscm = scmList.get(0);
		// 如果数据库里这个购物车uuid查出来的商品id，用户id有空的或者和传入的不一致，那么说明本身传入的uuid、商品id、用户id三者就是不一致的，那么就不能修改
		if (roughscm == null || roughscm.getMerchUuid() == null || roughscm.getUserUuid() == null) {
			logger.warn("传入的uuid对应的购物车条目为空或者其中商品id为空，或者用户id为空！异常请检查！", uuid);
			return Response.error("传入的uuid" + uuid + "对应的数据库数据为空或商品id为空，或用户id为空！请检查数据库！");
		}

		if (!(roughscm.getMerchUuid().equals(merchUuid) && roughscm.getUserUuid().equals(userUuid))) {
			logger.warn("id--{}，在数据库中查出来的商品id/用户id与传入的商品id/用户id不同！请检查！", uuid);
			return Response.error("传入的uuid对应的购物车条目中的商品id或者用户id与要修改规格的商品的id和用户id不同！请检查！");
		}

		List<MerchandiseStandard> mslist = scr.loadSecondCateGoryNameArrayByMerchUuid(merchUuid);
		// 校验传入的坐标，是否正常，维度是否和secondCateGoryName维度一样，数字是否在secondCateGoryName的范围之内。
		if (mslist == null || mslist.size() < 1 || mslist.get(0) == null
				|| mslist.get(0).getSecondCateGoryName() == null) {
			logger.warn("传入的商品id{}查询不到二级规格分类secondCateGoryName[]！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		String[][] secondCateGoryNameArray = mslist.get(0).getSecondCateGoryName();
		int dimensionality = mslist.get(0).getSecondCateGoryName().length;
		if (dimensionality > 2 || dimensionality < 1) {
			logger.warn("商品id{}的secondCateGoryName.length不为一或者二", merchUuid);
			return Response.error("商品id{}的secondCateGoryName.length不为一或者二");
		}

		Integer[] indexIntArr = orderDao.splitMerchStanIndex(merchStandardIndex);
		if (indexIntArr == null) {
			logger.warn("商品id{}的坐标解析成Integer数组为null！", merchUuid);
			return Response.error("商品id{}的坐标解析成Integer数组为null！");
		}
		if (indexIntArr.length != dimensionality) {
			logger.warn("商品id{}的坐标解析成Integer数组的长度和secondCateGoryName的长度不一致！", merchUuid);
			return Response.error("商品id{}的坐标解析成Integer数组的长度和secondCateGoryName的长度不一致！");
		}
		if (indexIntArr.length == 1) {
			if (indexIntArr[0] < 0 || indexIntArr[0] > (secondCateGoryNameArray[0].length - 1)) {
				logger.warn("商品id{}的坐标超出secondCateGoryName数组范围！", merchUuid);
				return Response.error("商品id{}的坐标超出secondCateGoryName数组范围！");
			}
		}
		if (indexIntArr.length == 2) {
			if (indexIntArr[0] < 0 || indexIntArr[0] > (secondCateGoryNameArray[0].length - 1) || indexIntArr[1] < 0
					|| indexIntArr[1] > (secondCateGoryNameArray[1].length - 1)) {
				logger.warn("商品id{}的坐标超出secondCateGoryName数组范围！", merchUuid);
				return Response.error("商品id{}的坐标超出secondCateGoryName数组范围！");
			}
		}

		// 检索目的规格的商品，有没有在这个用户的购物车里面，如果有，那么加数量，删去之前的，如果没有，修改之前条目的规格即可
		ShoppingCartMerch newScm = null;
		List<ShoppingCartMerch> scmlist = scr.checkShoppingCartMerchNumber(merchUuid, merchStandardIndex, userUuid);
		if (scmlist != null && scmlist.size() > 0 && scmlist.get(0) != null) {

			newScm = scmlist.get(0);
			if (newScm == null) {
				logger.warn("要更改的目的购物车条目预计存在，但是结果为null");
				return Response.error("要更改的目的购物车条目预计存在，但是结果为null");
			}
			if (newScm.getUuid() == null) {
				logger.warn("目标条目找不到uuid！");
				return Response.error("目标条目找不到uuid！");
			}
			if (newScm.getUuid().equals(uuid)) {
				logger.warn("要改成的目标规格不能和原规格一样！本次请求无效！");
				return Response.success("要改成的目标规格不能和原规格一样！本次请求无效！");
			}
			int number = newScm.getQuantity() + quantity;

			logger.info("开始更改购物车商品规格(添加到已存在条目上)");
			scr.changeCartMerchQuantity(newScm.getUuid(), number);
			logger.info("成功更改购物车商品规格(添加到已存在条目上)");
			logger.info("开始删除原有购物车条目");
			scr.deleteShoppingCartMerch(uuid);
			logger.info("成功删除原有购物车条目");
			return Response.success("成功更改购物车商品规格(添加到已存在条目上)，并删除原有条目");
		} else {
			logger.info("开始更改购物车商品规格(更改自身规格)");
			// update自身数据

			scr.changeCartMerchStandard(uuid, quantity, merchStandardIndex);
			logger.info("成功更改购物车商品规格(更改自身规格)");
			return Response.success("成功更改购物车商品规格(仅更改自身规格)");
		}
	}

	@Autowired
	private MerchStockAndPriceRepository msapr;

	/**
	 * 查询商品规格
	 *
	 * @param merchUuid
	 *            商品id
	 */
	@Override
	public Response loadMerchStandardIndex(String merchUuid) {

		String pic = msapr.loadMerchLogPic(merchUuid);
		List<MerchandiseStandard> mslist = msapr.loadMerchandiseStandard(merchUuid);
		MerchandiseStandard ms = null;

		if (mslist != null && mslist.size() > 0) {
			ms = mslist.get(0);
		}
		if (ms == null) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}

		ms.setMerchLog(pic);

		String[] topName = ms.getTopCategoryName();
		String[][] secondName = ms.getSecondCateGoryName();
		if (topName == null || secondName == null) {
			logger.warn("merchuuid为{}的商品，规格的一级分类或二级分类为空！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (topName.length != 1 && topName.length != 2) {
			logger.warn("merchuuid为{}的商品的一级分类长度不为1或者2，出现异常！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		List<MerchStockAndPrice> msapList = msapr.loadMerchStockAndPrice(merchUuid);
		if (Regular.checkEmpty(msapList, null)) {
			logger.warn("merchuuid为{}的商品的价格和库存数据为空，出现异常！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		Integer index_1 = null;
		Integer index_2 = null;
		if (topName.length == 1) {
			if (secondName.length != 1 || secondName[0] == null || secondName[0].length <= 0) {
				logger.warn("merchuuid为{}的商品，规格的一级分类长度为1但是二级分类长度不为1！或者二级分类首元素为空！", merchUuid);
				return Response.response(ResponseType.EMPTY_CODE.getCode());
			}
			String[][] prices_1 = new String[secondName[0].length][1];
			String[][] stocks_1 = new String[secondName[0].length][1];
			for (int i_1 = 0; i_1 < secondName[0].length; i_1++) {
				prices_1[i_1][0] = "-1";
				stocks_1[i_1][0] = "-1";
			}
			for (MerchStockAndPrice msap : msapList) {
				if (msap == null || msap.getMerchStandardIndex() == null || msap.getPrice() == null) {
					logger.warn("merchuuid为{}的商品的价格和库存数据为空，出现异常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				try {
					index_1 = Integer.parseInt(msap.getMerchStandardIndex());

				} catch (Exception e) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				if (index_1 == null || index_1 < 0 || index_1 > (secondName[0].length - 1)) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！，坐标为空或者超出数组范围！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				prices_1[index_1][0] = String.valueOf(msap.getPrice());
				stocks_1[index_1][0] = String.valueOf(msap.getStock());
			}
			ms.setPrices(prices_1);
			ms.setStocks(stocks_1);

		}
		if (topName.length == 2) {
			if (secondName.length != 2 || secondName[0] == null || secondName[0].length <= 0 || secondName[1] == null
					|| secondName[1].length <= 0) {
				logger.warn("merchuuid为{}的商品，规格的一级分类长度为2但是二级分类长度不为2！或者二级分类数组中有元素为空！", merchUuid);
				return Response.response(ResponseType.EMPTY_CODE.getCode());
			}
			String[][] prices_2 = new String[secondName[0].length][secondName[1].length];
			String[][] stocks_2 = new String[secondName[0].length][secondName[1].length];
			for (int l_1 = 0; l_1 < secondName[0].length; l_1++) {
				for (int l_2 = 0; l_2 < secondName[1].length; l_2++) {
					prices_2[l_1][l_2] = "-1";
					stocks_2[l_1][l_2] = "-1";
				}
			}
			String msindex = null;
			String[] msindexarr = null;
			for (MerchStockAndPrice msap : msapList) {
				if (msap == null || msap.getMerchStandardIndex() == null || msap.getPrice() == null) {
					logger.warn("merchuuid为{}的商品的价格和库存数据为空，出现异常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				msindex = msap.getMerchStandardIndex();
				msindexarr = msindex.split(",");
				if (msindexarr == null || msindexarr.length != 2) {
					logger.warn("merchuuid为{}的商品有的规格坐标为二维，但是解析不正常，请检查！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}

				try {
					index_1 = Integer.parseInt(msindexarr[0]);
					index_2 = Integer.parseInt(msindexarr[1]);

				} catch (Exception e) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				if (index_1 == null || index_2 == null || index_1 < 0 || index_1 > (secondName[0].length - 1)
						|| index_2 < 0 || index_2 > (secondName[1].length - 1)) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				prices_2[index_1][index_2] = String.valueOf(msap.getPrice());
				stocks_2[index_1][index_2] = String.valueOf(msap.getStock());
			}
			ms.setPrices(prices_2);
			ms.setStocks(stocks_2);
		}
		return Response.success(ms);
	}

	/**
	 * 查询商品规格（改进方法）
	 *
	 * @param merchUuid 商品id
	 */
	@Override
	public Response loadMerchStandardIndex_test(String merchUuid) {
		String pic = msapr.loadMerchLogPic(merchUuid);
		// List<MerchandiseStandard> mslist =
		// msapr.loadMerchandiseStandard(merchUuid);
		List<MerchandiseStandard> mslist = null;
		mslist = msapr.loadMerchandiseStandardByteArr(merchUuid);
		MerchandiseStandard ms = null;

		if (mslist != null && mslist.size() > 0) {
			ms = mslist.get(0);
		}
		if (ms == null) {
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}

		ms.setMerchLog(pic);

		String[] topName = DataConverUtils.byteArr2StringArr(ms.getTopCategoryNameByteArr());
		ms.setTopCategoryName(topName);
		// String[][] secondName = ms.getSecondCateGoryName();
		String[] secondName_1 = DataConverUtils.byteArr2StringArr(ms.getSecondCateGoryNameByteArr());
		if (topName == null || secondName_1 == null) {
			logger.warn("merchuuid为{}的商品，规格的一级分类或二级分类为空！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if (topName.length != 1 && topName.length != 2) {
			logger.warn("merchuuid为{}的商品的一级分类长度不为1或者2，出现异常！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		List<MerchStockAndPrice> msapList = msapr.loadMerchStockAndPrice(merchUuid);
		if (Regular.checkEmpty(msapList, null)) {
			logger.warn("merchuuid为{}的商品的价格和库存数据为空，出现异常！", merchUuid);
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		Integer index_1 = null;
		Integer index_2 = null;
		if (topName.length == 1) {
			ms.setSecondCateGoryName(new String[][]{secondName_1});
			String[][] prices_1 = new String[secondName_1.length][1];
			String[][] stocks_1 = new String[secondName_1.length][1];
			for (int i_1 = 0; i_1 < secondName_1.length; i_1++) {
				prices_1[i_1][0] = "-1";
				stocks_1[i_1][0] = "-1";
			}
			for (MerchStockAndPrice msap : msapList) {
				if (msap == null || msap.getMerchStandardIndex() == null || msap.getPrice() == null) {
					logger.warn("merchuuid为{}的商品的价格和库存数据为空，出现异常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				try {
					index_1 = Integer.parseInt(msap.getMerchStandardIndex());

				} catch (Exception e) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				if (index_1 == null || index_1 < 0 || index_1 > (secondName_1.length - 1)) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！，坐标为空或者超出数组范围！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				prices_1[index_1][0] = String.valueOf(msap.getPrice());
				stocks_1[index_1][0] = String.valueOf(msap.getStock());
			}
			ms.setPrices(prices_1);
			ms.setStocks(stocks_1);

		}
		if (topName.length == 2) {
			String[] secondName_2 = DataConverUtils.byteArr2StringArr(ms.getSecondCateGoryNameByteArr_2());

			if (secondName_2 == null) {
				logger.warn("merchuuid为{}的商品，规格的二级分类第二部分为空！", merchUuid);
				return Response.response(ResponseType.EMPTY_CODE.getCode());
			}
			ms.setSecondCateGoryName(new String[][]{secondName_1, secondName_2});
			String[][] prices_2 = new String[secondName_1.length][secondName_2.length];
			String[][] stocks_2 = new String[secondName_1.length][secondName_2.length];
			for (int l_1 = 0; l_1 < secondName_1.length; l_1++) {
				for (int l_2 = 0; l_2 < secondName_2.length; l_2++) {
					prices_2[l_1][l_2] = "-1";
					stocks_2[l_1][l_2] = "-1";
				}
			}
			String msindex = null;
			String[] msindexarr = null;
			for (MerchStockAndPrice msap : msapList) {
				if (msap == null || msap.getMerchStandardIndex() == null || msap.getPrice() == null) {
					logger.warn("merchuuid为{}的商品的价格和库存数据为空，出现异常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				msindex = msap.getMerchStandardIndex();
				msindexarr = msindex.split(",");
				if (msindexarr == null || msindexarr.length != 2) {
					logger.warn("merchuuid为{}的商品有的规格坐标为二维，但是解析不正常，请检查！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}

				try {
					index_1 = Integer.parseInt(msindexarr[0]);
					index_2 = Integer.parseInt(msindexarr[1]);

				} catch (Exception e) {
					logger.warn("merchuuid为{}的商品的规格为一维，但是坐标解析不正常！", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				if (index_1 == null || index_2 == null || index_1 < 0 || index_1 > (secondName_1.length - 1)
						|| index_2 < 0 || index_2 > (secondName_2.length - 1)) {
					logger.warn("merchuuid为{}的商品的规格为二维，但是坐标解析不正常！坐标数字小于零或者大于数组长度", merchUuid);
					return Response.response(ResponseType.EMPTY_CODE.getCode());
				}
				prices_2[index_1][index_2] = String.valueOf(msap.getPrice());
				stocks_2[index_1][index_2] = String.valueOf(msap.getStock());
			}
			ms.setPrices(prices_2);
			ms.setStocks(stocks_2);
		}
		return Response.success(ms);
	}
	@Override
	public Response checkPaymentPayed(String paymentNo){
		List<Boolean> checklist = optr.checkPaymentPayed(paymentNo);
		if(checklist == null || checklist.size() == 0){
			logger.warn("根据paymentNo{}查询不到OrderPayTemp中的数据!",paymentNo);
			return Response.error("paymentNo"+ paymentNo +"在OrderPayTemp表中还未存储！!");
		}
		if(checklist.size() > 1){
			logger.warn("根据paymentNo{}查询到OrderPayTemp中的数据并不唯一！大于一条！!", paymentNo);
		}
		Boolean result = checklist.get(0);
		if(result == null){
			logger.warn("根据paymentNo{}查询OrderPayTemp中的payed属性为null，因为app和第三方的回调都没有接收到!", paymentNo);
			return Response.fail();
		}
		if(result){
			return Response.success();
		}else{
			return Response.fail();
		}
		
	}
	
	@Override
	public Response remindDelivery(String orderNo){
		logger.warn("收到发货提醒！{}",orderNo);
		return Response.success();
	}
	@Override
	public Response confirmReceiveOrder(String orderUuid, Boolean autoConfirmed){
		if(orderUuid == null){
			logger.warn("确认收货方法中，订单ID为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
	//判断是否是该用户的订单
//		if(userUuid == null){
//			logger.warn("确认收货方法中，用户id为空！");
//			return Response.response(ResponseType.EMPTY_CODE.getCode());
//		}
		List<OrderTest> orderlist = orderTestRepository.selectOrderWhenConfirm(orderUuid);
		if(orderlist == null || orderlist.size() == 0 || orderlist.get(0) == null){
			logger.warn("确认收货方法中，订单{}查询为空！",orderUuid);
			return Response.error("确认收货方法中，订单id"+orderUuid+"查询为空！");
		}
		OrderTest ot = orderlist.get(0);
		Integer orderStatus = ot.getStatus();
		if(orderStatus == null){
			logger.warn("确认收货方法中，订单状为空！");
			return Response.error("确认收货方法中，订单id"+orderUuid+"状态为空！");
		}
		if(autoConfirmed == null){
			logger.warn("确认收货方法中，autoConfirmed为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(orderStatus != 3){
			logger.warn("确认收货方法中，订单并不处于已发货状态！");
			return Response.error("确认收货方法中，订单id"+orderUuid+"状态查询为空！");
		}
		changeStatus(orderUuid,5);
		orderTestRepository.setOrderAutoConfirmed(autoConfirmed, orderUuid);
		PaymentReiceive pr = new PaymentReiceive();
		pr.setCreateTime(Timestamp.from(Instant.now()));
		pr.setMerchandiserUuid(ot.getMerchandiserUuid());
		pr.setOrderNo(ot.getOrderNo());
		pr.setTotal_amount(ot.getTotalPrice());
		prRepository.save(pr);
		//商家加钱，写接口
		return Response.success();
	}
	
	@Autowired
	private PRRepository prRepository;
	
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
		OrderService orderServiceImpl = (OrderService) context.getBean("orderServiceImpl");
		
		

	}
	
}
