package org.finace.order.server;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.ShoppingCartMerch;
import org.finace.utils.operate.Response;

/**
 * Created by Ness on 2016/12/16.
 */
public interface OrderService {

	Response changeStatus(String uuid, Integer status);
	Response setOrderDeleted(String uuid, String deletedPersonUuid);
	Response loadAllShopCartMerchByUserUuid(String userUuid, Integer page,
			Integer pageCount);
	Response countNumberOfOrdersByStatus(String userUuid);
//	Response findOrdersByUserUuid(String userUuid, Integer order, Integer page, Integer pageCount, Integer status);
	Response changeCartMerchQuantity(String uuid, Integer number);
	Response saveShopCartMerch(List<ShoppingCartMerch> scmlist, String userUuid);
	Response deleteShoppingCartMerch(List<ShoppingCartMerch> scmlist);
	Response findOrdersByUserUuid_service(String userUuid, Integer order, Integer page, Integer pageCount,
			Integer status);
	Response findOrderTestsbyOrderUuid(String uuid);
	void changeSingleMerchStock(String merchUuid, String merchStandardIndex, int quantity, Boolean isReduce);
	Response changeShoppingcartMerchStandard(String userUuid, String uuid, String merchUuid, String standardIndex,
			Integer quantity);
	Response loadMerchStandardIndex(String merchUuid);
	Response saveOrdersInUse(List<OrderTest> orderlist, Integer validMinutes);
	Response loadMerchStandardIndex_test(String merchUuid);
	Response payOrder(Integer payType, String data, String userUuid, Double totalPrice, Double balancePrice,
			String body, String subject);
	String thirdPayResultInfo(HttpServletRequest req);
	String wxPayCallbackResult(HttpServletRequest req);
	Response dealWithPayType_4(HttpServletRequest req, String userUuid, String body, String subject, Double totalPrice,
			String out_trade_no);
	Response checkPaymentPayed(String paymentNo);
	Response appPayResultInfo(String out_trade_no, String userUuid, String random_code);
	Response checkThirdPayResult(String paymentNo);
	Response remindDelivery(String orderNo);
	Response confirmReceiveOrder(String orderUuid, Boolean autoConfirmed);
}
