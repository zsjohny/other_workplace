package org.finace.order.server.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.finace.order.repository.MerchStockAndPriceRepository;
import org.finace.order.repository.OrderCrudRepository;
import org.finace.order.repository.OrderMerchCrudRepository;
import org.finace.order.server.OrderBackUpService;
import org.finace.utils.entity.order.OrderMerch;
import org.finace.utils.entity.order.OrderStatusCount;
import org.finace.utils.entity.order.Orders;
import org.finace.utils.entity.order.TempMerchInfo;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.LockType;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.enums.ScheduleOperaType;
import org.finace.utils.enums.TimerTaskNameType;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.lock.Lock;
import org.finace.utils.math.Arith;
import org.finace.utils.operate.Response;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Transactional
@Service
public class OrderBackUpServiceImpl implements OrderBackUpService{
	
	@Autowired
	private OrderCrudRepository ocr;
	
	@Autowired
	private OrderMerchCrudRepository omcr;
	
	@Autowired
	private Lock lock;
	
	@Autowired
	private MerchStockAndPriceRepository mspr;
	
	@Autowired
	private JmsSender jmsSender;
	
	private Logger logger = LoggerFactory.getLogger(OrderBackUpServiceImpl.class);
	
	//test model 测试的时候生成数据的方法
	@Override
	public JSONArray getOrderData(){
		JSONObject json = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		json.put("userUuid", "42414418073f187d3f7f5f18a50e47ae05632b868");
		json.put("merchandiserUuid", "92194912083c306b0bdb9b948cc44c36469372635");
		json.put("isFromCart", true);
		json.put("totalPrice", 192);
		json.put("merchandiserName", "商家123");
		json.put("isFlashSale", false);
		json.put("isAnonymous", false);
		json.put("receiveAddressDetail", "杭州123");
		json.put("orderMessage", "订单留言");
		
		JSONObject json_sub_1 = new JSONObject();
		json_sub_1.put("quantity", 2);
		json_sub_1.put("merchUuid", "9073202209f97909cf883614865843f2d211b3c07");
		json_sub_1.put("merchName", "随机123");
		json_sub_1.put("merchPrice", 65);
		json_sub_1.put("merchStandardIndex", "0,0");
		JSONObject json_sub_2 = new JSONObject();
		json_sub_2.put("quantity", 1);
		json_sub_2.put("merchUuid", "16920022021afe1edd779f06995b4087f08c99c3e");
		json_sub_2.put("merchName", "随机1111");
		json_sub_2.put("merchPrice", 62);
		json_sub_2.put("merchStandardIndex", "0,0");
		JSONArray jsonArr_1 = new JSONArray();
		jsonArr_1.add(json_sub_1);
		jsonArr_1.add(json_sub_2);
		json.put("omlist", jsonArr_1);
		jsonArr.add(json);
		return jsonArr;
	}
	private Boolean checkOrderValid(Orders order, String reCheckId){
		if(order == null){
			logger.warn("checkOrderValid中，order == null");
			return false;
		}
		//如果订单不是从购物车提交，那么从商品页面获取不到商家id，那么要去数据库中查找这个订单是哪个商家的
		if(order.getIsFromCart() == null || order.getIsFromCart() == false){
			if(order.getOmlist() == null || order.getOmlist().size() != 1){
				logger.warn(" order.getIsFromCart() == false 表明这个订单是不是从购物车提交而是从商品页面直接提交，那么订单中的商品列表里面只应该有一个商品"
						+ "，但是商品列表为空或者商品列表长度大于1，");
				return false;
			}
			if(order.getOmlist().get(0) == null || order.getOmlist().get(0).getMerchUuid() == null){
				logger.warn("order.getOmlist().get(0) == null || order.getOmlist().get(0).getMerchUuid() == null");
				return false;
			}
			String mercherUuid = ocr.loadBelongToUuid(order.getOmlist().get(0).getMerchUuid());
			if(mercherUuid == null){
				logger.warn("订单中的商品找不到商家信息！");
				return false;
			}
			order.setMerchandiserUuid(ocr.loadBelongToUuid(order.getOmlist().get(0).getMerchUuid()));
		}
		//判断传入的商家id是否正确
		String merchandiserUuid = order.getMerchandiserUuid();
		if(order.getIsFromCart() != null && order.getIsFromCart() == true && (ocr.countIfMerchandiserExist(merchandiserUuid) < 1 )){
			logger.warn("从购物车生成的该订单传入的商家数据为空或者找不到对应的商家！订单生成失败！");
			return false;
		}
		//遍历omlist，检测库存是否充足并扣库存,检查订单总价是否等于每个商品的价格之和
		String merchUuid = null;
		String merchStandardIndex = null;
		String idConcatIndex = null;
		int merchQuantity = 0;
		double merchPrice = 0.00;
		ArrayList<TempMerchInfo> infoList = new ArrayList<>();
		// 标识着这个订单中是不是有商品校验失败，如果失败，在finally方法中会将扣除的库存增加
		boolean merchFlag = false;
		Double orderTempPrice = 0.00;
		try{
			for(OrderMerch om : order.getOmlist()){
				merchUuid = om.getMerchUuid();
				merchStandardIndex = om.getMerchStandardIndex();
				if(merchUuid == null || merchStandardIndex == null){
					logger.warn("保存订单的时候有商品merchUuid为空或者merchStandardIndex为空");
					return false;
				}
				merchQuantity = om.getQuantity();
				if(merchQuantity < 1){
					logger.warn("保存订单的时候有的商品数量不为正整数");
					return false;
				}
				merchPrice = om.getMerchPrice();
				if(merchPrice <= 0){
					logger.warn("保存订单的时候有的商品价格不为正数");
					return false;
				}
				idConcatIndex = merchUuid + merchStandardIndex;
				String currentTime = "";
				try {
					int lockNumber = 0;
					while (!lock.lock(LockType.MERCH_STOCK_LOCK, idConcatIndex)){
						lockNumber ++ ;
						try {
							Thread.sleep(20);
						} catch (InterruptedException e) {
							e.printStackTrace();
							return false;
						}
						if(lockNumber > 200){
							logger.warn("商品校验时，分布式锁等待时间大于四秒！订单生成失败！");
							return false;
						}
					}
					
					int result = mspr.checkStockAndPrice(merchQuantity, merchPrice, merchUuid, merchStandardIndex);
					if(result == 0){
						logger.warn("原因可能是：1、商品:{}规格:{}价格:{}与数据库价格不一致。2、该商品要求数量{}个，但是库存不足，3、该商品或者该商品规格不存在！", 
								merchUuid, merchStandardIndex, merchPrice, merchQuantity);
						currentTime = lock.getLock(LockType.MERCH_STOCK_LOCK,idConcatIndex);
						return false;
					}
					if(result > 1){
						logger.warn("该商品{}规格{}对应的数据库条目不唯一！请检查！", merchUuid, merchStandardIndex);
					}
					
					//把已验证的商品添加进来，如果以后的商品出错导致订单不能生成，那么将已验证商品列表中的减掉的库存恢复
					infoList.add(new TempMerchInfo(merchUuid, merchStandardIndex, merchQuantity));
					
					orderTempPrice = Arith.add(2, orderTempPrice, Arith.multiplys(2, merchPrice, merchQuantity));
					currentTime = lock.getLock(LockType.MERCH_STOCK_LOCK, idConcatIndex);
				}finally{
					lock.unLock(LockType.MERCH_STOCK_LOCK, idConcatIndex, currentTime);
				}
			}
			if (Math.abs(Arith.subtract(2, orderTempPrice, order.getTotalPrice())) > 0.00001) {
				logger.warn("订单实际总价与传入价格不一致！");
				merchFlag = true;
				return false;
			}
		}finally{
			if (merchFlag && infoList.size() > 0) {
				for (TempMerchInfo tmi_1 : infoList) {
					mspr.increaseMerchStock(tmi_1.getMerchQuantity(), tmi_1.getMerchUuid(),
							tmi_1.getMerchStandardIndex());
				}
			}
		}
		order.setOrderNo(UserUtils.generateOrderNo());
		order.setReCheckId(reCheckId);
		order.setUuid(UserUtils.generateIncrementId());
		order.setStatus(1);
		order.setCreateTime(Timestamp.from(Instant.now()));
		order.setDeleted(false);
		return true;
	}
	
	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ss mm HH dd MM ?");
	
	//订单处理
	private void dealwithSingleOrder(Orders order, final Integer validMinutes, String reCheckId){
		if (!checkOrderValid(order, reCheckId)) {
			logger.warn("订单校验失败");
			return;
		}
		//保存订单
		saveSingleOrder(order);
		
		//jms发送失效信息
		TimeTask task = new TimeTask();
		task.setExecuteTime(LocalDateTime.now().plusMinutes(validMinutes).format(formatter));
		task.setParams(TimerTaskNameType.ORDER_AUTO_INVALID.getName() + order.getOrderNo());
		task.setTimeTaskName(TimerTaskNameType.ORDER_AUTO_INVALID.getName() + order.getOrderNo());
		task.setScheduleOperaType(ScheduleOperaType.ADD_TASK);
		jmsSender.sendMsg(JSON.toJSONString(task));
	}
	
	//保存单个订单方法
	private void saveSingleOrder(Orders order){
		if(order.getOmlist() == null){
			logger.warn("order.getOmlist() == null");
			return;
		}
		ocr.save(order);
		order.getOmlist().forEach(item->{
			item.setSingleOrder(order);
			item.setCreateTime(Timestamp.from(Instant.now()));
			item.setOrderNo(order.getOrderNo());
			omcr.save(item);
		});
		
	}
	
	@Override
	public Response saveOrders(String data, final Integer validMinutes){
		//同批多个订单生成的时候都会附带一个receckid，用来查找同批订单信息。
		String reCheckId = UserUtils.generateUUid();
		data = getOrderData().toJSONString();
		List<Orders> ordersList = JSONArray.parseArray(data,Orders.class);
		if(ordersList == null || ordersList.size() == 0){
			logger.warn("保存订单时，用前端数据解析生成订单列表为空！");
			return Response.error("保存订单时，用前端数据解析生成订单列表为空！");
		}
		for(Orders order : ordersList){
			dealwithSingleOrder(order, validMinutes, reCheckId);
		}
		
		return null;

	}
	//将订单列表转换成json格式，传给前端的方法
	private JSONArray orderToJsonArray(List<Orders> orderlist){
		JSONArray jsonarray = new JSONArray();
		if(orderlist == null || orderlist.size() == 0){
			return jsonarray;
		}
		for(Orders order : orderlist){
			if(order != null){	
				JSONObject json = new JSONObject();
				json.put("totalPrice", order.getTotalPrice() != null ? order.getTotalPrice() : 0.00);
				json.put("orderNo", order.getOrderNo() != null ? order.getOrderNo() : "");
				json.put("createTime", order.getCreateTime() != null ? order.getCreateTime():"");
				json.put("orderMessage", order.getOrderMessage() != null ? order.getOrderMessage():"");
				json.put("userUuid", order.getUserUuid() != null? order.getUserUuid() : "");
				json.put("merchandiserName", order.getMerchandiserName() != null? order.getMerchandiserName() : "");
				json.put("isAnonymous", order.getIsAnonymous() != null? order.getIsAnonymous() : false);
				json.put("diliveryCompanyNo", order.getDiliveryCompanyNo() !=null? order.getDiliveryCompanyNo() : "");
				json.put("deliveryNo", order.getDeliveryNo() != null ? order.getDeliveryNo() : "");
				JSONArray omlistArr = new JSONArray();
				List<OrderMerch> orderMerchlist = order.getOmlist();
				if(orderMerchlist != null && orderMerchlist.size() > 0){
					for(OrderMerch om : orderMerchlist){
						JSONObject omjson = new JSONObject();
						omjson.put("quantity", om.getQuantity());
						omjson.put("merchUuid", om.getMerchUuid() !=null ? om.getMerchUuid() : "");
						omjson.put("merchName", om.getMerchName() !=null ? om.getMerchName() : "");
						omjson.put("merchPic", om.getMerchPic() !=null ? om.getMerchPic() : "");
						omjson.put("merchSpec", om.getMerchSpec() !=null ? om.getMerchSpec() : "");
						omjson.put("merchPrice", om.getMerchPrice() !=null ? om.getMerchPrice() : 0.00);
						omjson.put("merchStandardUuid", om.getMerchStandardUuid() !=null ? om.getMerchStandardUuid() : "");
						omjson.put("merchStandardIndex", om.getMerchStandardIndex() !=null ? om.getMerchStandardIndex() : "");
						omlistArr.add(omjson);
					}
				}
				json.put("omlist", omlistArr);
				jsonarray.add(json);
			}
		}
		return jsonarray;
	}
	//根据用户id读取订单列表
	@Override
	public Response listOrders(String userUuid, Integer page, Integer pageCount){
		page = 0;
		pageCount = 20;
		userUuid = "42414418073f187d3f7f5f18a50e47ae05632b868";
		List<Orders> orderList = ocr.listOrdersByUserUuid(userUuid);
		return Response.success(orderToJsonArray(orderList));
	}
	//根据订单orderNo读取订单列表
	@Override
	public Response showSingleOrder(String orderNo){
		List<Orders> orderList = ocr.selectSingleOrderByOrderNo(orderNo);
		if(orderList == null || orderList.size() < 1 || orderList.get(0) == null){
			logger.warn("根据订单号{}查询不到订单信息！", orderNo);
		}
		if(orderList.size() > 1){
			logger.warn("根据订单号{}查询到订单数目大于一条！！", orderNo);
		}
		return Response.success(this.orderToJsonArray(orderList));
	}
	//查询不同状态下的订单数目
	@Override
	public Response countNumberOfOrdersByStatus(String userUuid){
		if (userUuid == null) {
			logger.warn("查询不同状态订单数目的时候，useruuid为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		} else {
			logger.info("开始获取用户id为{}的不同状态订单的数目" + userUuid);
			List<Object[]> objlist = ocr.countNumberOfOrdersByStatus(userUuid);
			List<OrderStatusCount> osclist = new ArrayList<>();
			OrderStatusCount osc = null;
			for (Object[] objarr : objlist) {
				if(objarr[0] != null){
					osc = new OrderStatusCount();
					osc.setStatus(objarr[0].toString());
					osc.setCount(objarr[1].toString());
					osclist.add(osc);
				}
			}
			if (osclist != null && osclist.size() > 0) {
				logger.info("获取用户id为{}的不同状态订单的数目成功！" + userUuid);
				JSONObject json = new JSONObject();
				json.put("key", osclist);
				return Response.success(json);
			} else {
				return Response.success();
			}
		}
	}
	
	
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
		OrderBackUpService orderBackUpServiceImpl = (OrderBackUpService) context.getBean("orderBackUpServiceImpl");
		//orderBackUpServiceImpl.saveOrders(orderBackUpServiceImpl.getOrderData().toJSONString(), 10);
		System.out.println(JSONObject.toJSONString(orderBackUpServiceImpl.countNumberOfOrdersByStatus("42414418073f187d3f7f5f18a50e47ae05632b868")));
	}
}
