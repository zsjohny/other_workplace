package org.finace.order.repository;

import org.finace.utils.entity.order.OnePaymentNoToManyOrderNo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface OpmoRepository extends CrudRepository<OnePaymentNoToManyOrderNo, Integer>{
	   @Query(nativeQuery=true,value="select count(1) from onePaymentNoToManyOrderNo where paymentNo=?1")
	    int countPaymentNoInOPMO(String paymentNo);
}
