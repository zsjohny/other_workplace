package org.finace.order.utils;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.finace.order.repository.MerchStockAndPriceRepository;
import org.finace.order.repository.OrderCrudRepository;
import org.finace.order.repository.OrderMerchCrudRepository;
import org.finace.order.repository.OrderTestRepository;
import org.finace.order.server.OrderService;
import org.finace.utils.Regular.Regular;
import org.finace.utils.concurrent.ExecutorService;
import org.finace.utils.concurrent.ExecutorTask;
import org.finace.utils.entity.order.OrderMerch;
import org.finace.utils.entity.order.OrderTest;
import org.finace.utils.entity.order.Orders;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.LockType;
import org.finace.utils.enums.ScheduleOperaType;
import org.finace.utils.enums.TimerTaskNameType;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.lock.Lock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

@Component
public class OrderTaskBus {
	@Autowired
	private OrderTestRepository otr;
	@Autowired
	private OrderService osi;
	private Logger logger = LoggerFactory.getLogger(OrderTaskBus.class);
	@Autowired
	private ExecutorService executorService;
	@Autowired
	private Lock lock;
	@Autowired
	private JmsSender jmsSender;
	@Autowired
	private MerchStockAndPriceRepository msapRepository;
	@Autowired
	private OrderCrudRepository ocr;
	@Autowired
	private OrderMerchCrudRepository omcr;
	
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ss mm HH dd MM ?");
	//订单5分钟不付款自动失效
	public void orderAutoInvalid(String msg){
		String orderNo = msg.substring(TimerTaskNameType.ORDER_AUTO_INVALID.getName().length(),msg.length());
		  String currentTime = "";
	        try {
					if(orderNo == null){
						logger.warn("jms传递过来的orderNO为空！");
						return;
					}
					while(lock.lock(LockType.ORDER_NUMBER_LOCK,orderNo)){
						Integer status = ocr.loadOrderStatusByOrderNo(orderNo);
						if(status == null || status != 1){
							logger.warn("改变订单状态失败！此时订单{}状态不为'待付款'！",orderNo);
							return;
						}
						List<OrderMerch> omlist = omcr.loadOrderMerchList(orderNo);
						logger.info("开始将订单{}设置为已取消状态",orderNo);
						ocr.changeOrderStatusByOrderNo(orderNo, 5, Timestamp.from(Instant.now()));
						logger.info("成功将订单{}设置为已取消状态",orderNo);
						omlist.forEach(item->{
							if(item != null){
							msapRepository.increaseMerchStock(item.getQuantity(), item.getMerchUuid(), item.getMerchStandardIndex());
							}
						});
						TimeTask task = new TimeTask();
						task.setExecuteTime(LocalDateTime.now().plusSeconds(20).format(formatter));
						task.setParams(msg);
						task.setTimeTaskName(msg);
						task.setScheduleOperaType(ScheduleOperaType.DELETE_TASK);
						jmsSender.sendMsg(JSON.toJSONString(task));
						currentTime = lock.getLock(LockType.ORDER_NUMBER_LOCK,orderNo);
					}
				}catch (Exception e) {
					e.printStackTrace();
				}finally {
					   lock.unLock(LockType.ORDER_NUMBER_LOCK,orderNo,currentTime);
				}
}
}
