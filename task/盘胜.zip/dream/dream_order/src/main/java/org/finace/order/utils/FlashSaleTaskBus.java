package org.finace.order.utils;

import org.springframework.stereotype.Component;

/**
 * 进行抢购的处理
 */
@Component
public class FlashSaleTaskBus {

    public void dealWithFlashSale(String orderUuid) {

    }

    public static void main(String[] args) {

    }
}
