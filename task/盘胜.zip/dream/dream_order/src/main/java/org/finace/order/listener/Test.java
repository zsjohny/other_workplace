package org.finace.order.listener;

import redis.clients.jedis.ShardedJedis;

public class Test {

	private ThreadLocal<ShardedJedis> jedis = new ThreadLocal<>();	
	
		public static void main(String[] args) {
			System.out.println(Long.parseLong(null));
		}

}
