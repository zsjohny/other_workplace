package org.finace.order.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.order.MerchStockAndPrice;
import org.finace.utils.entity.order.PaymentReiceive;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface PRRepository extends CrudRepository<PaymentReiceive,Integer>, JpaSpecificationExecutor<PaymentReiceive> {

	
	
	
}
