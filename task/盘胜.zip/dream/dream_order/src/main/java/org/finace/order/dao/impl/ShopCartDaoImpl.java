package org.finace.order.dao.impl;

import java.util.List;

import org.finace.order.dao.ShopCartDao;
import org.finace.order.repository.ShoppingCartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;


/**
 * Created by Ness on 2016/12/16.
 */
@Component
public class ShopCartDaoImpl implements ShopCartDao {
	@Autowired
	private ShoppingCartRepository scr;
	/**
	 * 查询所有购物车条目
	 * @param userUuid 用户id
	 * @param page 页数
	 * @param pageCount 每页大小
	 * 
	 */
	@Override
	public List<Object[]> loadAllShopCartMerchByUserUuid(String userUuid, Integer page, Integer pageCount){
		
		if (page == null || page <= 0) {
            page = 0;
        }else{
        	page = page -1;
        	
        }
        	
        
    	pageCount = 50;
    	Pageable pageable=new PageRequest(page,pageCount);
		
		return scr.loadAllShopCartMerchByUserId(userUuid,pageable);
	};
	

}
