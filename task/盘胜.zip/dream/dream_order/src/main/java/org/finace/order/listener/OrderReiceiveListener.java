package org.finace.order.listener;

import org.finace.order.repository.OrderPayTempRepository;
import org.finace.order.utils.OrderTaskBus;
import org.finace.utils.concurrent.ExecutorService;
import org.finace.utils.concurrent.ExecutorTask;
import org.finace.utils.enums.LockType;
import org.finace.utils.enums.OrderOprType;
import org.finace.utils.enums.PaymentType;
import org.finace.utils.enums.TimerTaskNameType;
import org.finace.utils.jms.JmsListenter;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.lock.Lock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class OrderReiceiveListener implements JmsListenter{
	@Autowired
	private OrderTaskBus orderTaskBus;
	
	private Logger logger = LoggerFactory.getLogger(OrderReiceiveListener.class);
	
	@Autowired
	private JmsSender jmsSender;

	@Autowired
	private Lock lock;

	@Autowired
	private OrderPayTempRepository orderPayTempRepository;
	
	@Autowired
	private ExecutorService executorService;
	
	
	@Override
	public void onMsg(String msg) {
		if(msg==null) return;
		if(msg.substring(0, PaymentType.BALANCE_PAYMENT.getName().length()).equals(PaymentType.BALANCE_PAYMENT.getName())){
			System.out.println(msg);
		}
		if(msg.equals("1234")){
			logger.warn("成功接收到！成功接收到！成功接收到！成功接收到！成功接收到！成功接收到！成功接收到！成功接收到！");
		}
		if(msg.substring(0,TimerTaskNameType.ORDER_AUTO_INVALID.getName().length()).equals(TimerTaskNameType.ORDER_AUTO_INVALID.getName())){
			executorService.addTask(new ExecutorTask(){
				@Override
				public void doJob(){
					orderTaskBus.orderAutoInvalid(msg);
					
				}
			});
			
		}
		if(msg.substring(0,TimerTaskNameType.ORDER_COUNT_PAYMENT.getName().length()).equals(TimerTaskNameType.ORDER_COUNT_PAYMENT.getName())){
			//orderTaskBus.userCountPayment(msg);
		}
	}
}