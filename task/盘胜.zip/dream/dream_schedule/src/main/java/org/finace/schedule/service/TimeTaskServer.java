package org.finace.schedule.service;


import org.finace.utils.entity.schedule.TimeTask;

import java.util.List;

/**
 * 定时任务的server
 * Created by Ness on 2016/12/10.
 */
public interface TimeTaskServer {
    Iterable<TimeTask> findTimeTaskAll();

    void saveTimeTask(TimeTask task);

    void updateTimeTask(TimeTask task);

    void deleteTimeTask(TimeTask task);
}
