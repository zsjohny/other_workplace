package org.finace.schedule.utils;

import org.finace.utils.Regular.Regular;
import org.finace.utils.enums.TimerTaskNameType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * 用来重启定时任务
 * Created by Ness on 2016/12/26.
 */
@Component
public class TimeRestTaskBus {


    @Autowired
    private TimeTaskBus timeTaskBus;

    private Logger logger = LoggerFactory.getLogger(TimeRestTaskBus.class);

    @PostConstruct
    public void initData() {

        while (!TimeTaskBus.IS_RESET_OVER) {
        }

        logger.info("开始恢复定时指定定时任务到缓存中");
        timeTaskBus.findRestTask(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName());
        logger.info("结束恢复定时指定定时任务到缓存中");
    }


    /**
     * 重启定时任务
     *
     * @param params 重启的定时任务列表
     */
    public void resetTask(String params) {
        if (Regular.checkEmpty(params, null)) {
            logger.warn("重启定时任务的参数为空");
            return;
        }
        logger.info("开始参数{}重启定时任务", params);

        try {
            timeTaskBus.findRestTask(params);

            logger.info("结束参数{}重启定时任务", params);

        } catch (Exception e) {
            logger.warn("重启参数{}定时任务失败", params, e);
        }

    }


}
