package org.finace.schedule.listenter;

import org.finace.schedule.utils.TimeRestTaskBus;
import org.finace.utils.Regular.Regular;
import org.finace.utils.jms.JmsListenter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 用来重启定时任务的监听类
 * Created by Ness on 2016/12/26.
 */
public class TimeRestTaskListener implements JmsListenter {
    private Logger logger = LoggerFactory.getLogger(TimeRestTaskListener.class);

    @Autowired
    private TimeRestTaskBus timeRestTaskBus;

    @Override
    public void onMsg(String s) {
        if (Regular.checkEmpty(s, null)) {
            logger.warn("重启定时任务的参数为空");
            return;
        }
        logger.info("重启定时任务开始,参数为{}",s);
        timeRestTaskBus.resetTask(s);

    }
}
