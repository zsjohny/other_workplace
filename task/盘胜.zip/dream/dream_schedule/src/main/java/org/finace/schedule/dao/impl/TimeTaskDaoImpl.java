package org.finace.schedule.dao.impl;

import org.finace.schedule.dao.TimeTaskDao;
import org.finace.schedule.repository.TimeTaskCrudRepository;
import org.finace.schedule.repository.TimeTaskRepository;
import org.finace.utils.entity.schedule.TimeTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Ness on 2016/12/10.
 */
@Repository
public class TimeTaskDaoImpl implements TimeTaskDao {
    @Autowired
    private TimeTaskCrudRepository timeTaskCrudRepository;
    @Autowired
    private TimeTaskRepository timeTaskRepository;


    @Override
    public Iterable<TimeTask> findTimeTaskAll() {

        return timeTaskCrudRepository.findAll();
    }

    @Override
    public void saveTimeTask(TimeTask task) {
        timeTaskCrudRepository.save(task);
    }

    @Override
    public void updateTimeTask(TimeTask task) {
        timeTaskRepository.updateTimeTaskByTimeTask(task.getScheduleTaskIndex(), task.getExecuteTime(), task.getParams(), task.getTimeTaskName());
    }
 

    @Override
    public void deleteTimeTask(TimeTask task) {
        task = timeTaskCrudRepository.findByTimeTaskName(task.getTimeTaskName());
        timeTaskCrudRepository.delete(task.getId());
    }
}
