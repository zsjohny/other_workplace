package org.finace.schedule.utils;

import com.alibaba.fastjson.JSONObject;
import org.finace.schedule.dao.TimeTaskDao;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.ScheduleOperaType;
import org.finace.utils.enums.TimerTaskNameType;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Ness on 2016/12/27.
 */
public class AutoTaskTest {


    public static void main(String[] args) {
        System.out.println("timeTask  111  ");
        Merchandise merchandise = new Merchandise();
        merchandise.setMerchName("快速党抢购 90%白鸭羽绒服抢购xxx");
        merchandise.setMerchLog("http://h.hiphotos.baidu.com/image/pic/item/8d5494eef01f3a2922e765c99b25bc315c607c8d.jpg");
        merchandise.setUuid("YzYyNmU4ZWItYWRjZC00MzQwLTg0ODUtZjQzNzVhNmZmYTQ3MTQ4MjI5NDc1Mzc5MA==");
        merchandise.setMerchPrice(1000.00);
        merchandise.setMerchDisPrice(800.00);
        merchandise.setPurcaseDes("顺丰包邮 赠送费险");

        TimeTask timeTask = new TimeTask();
        timeTask.setParams(JSONObject.toJSONString(merchandise));
        timeTask.setExecuteTime("*/10 * * * * ?");
        timeTask.setScheduleOperaType(ScheduleOperaType.ADD_TASK);
        timeTask.setTimeTaskName(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName() + "1");
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        System.out.println("timeTask  22  ");
        TimeTaskDao timeTaskDao = context.getBean("timeTaskDaoImpl", TimeTaskDao.class);

        System.out.println("timeTask  into  ");
        timeTaskDao.saveTimeTask(timeTask);

        timeTask = new TimeTask();
        timeTask.setParams(JSONObject.toJSONString(merchandise));
        timeTask.setExecuteTime("*/40 * * * * ?");
        timeTask.setScheduleOperaType(ScheduleOperaType.ADD_TASK);
        timeTask.setTimeTaskName(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName() + "2");
        timeTaskDao.saveTimeTask(timeTask);


        timeTask = new TimeTask();
        timeTask.setParams(JSONObject.toJSONString(merchandise));
        timeTask.setExecuteTime("*/30 * * * * ?");
        timeTask.setScheduleOperaType(ScheduleOperaType.ADD_TASK);
        timeTask.setTimeTaskName(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName() + "3");
        timeTaskDao.saveTimeTask(timeTask);
        System.out.println("timeTask  end  ");
    }
}
