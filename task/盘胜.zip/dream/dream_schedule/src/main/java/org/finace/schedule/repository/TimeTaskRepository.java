package org.finace.schedule.repository;

import org.finace.utils.entity.schedule.TimeTask;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

/**
 * 定时任务执行的reposiroty类
 * Created by Ness on 2016/12/8.
 */
public interface TimeTaskRepository extends Repository<TimeTask, Integer> {

    @Modifying
    @Query("update TimeTask set scheduleTaskIndex=:scheduleTaskIndex ,executeTime=:executeTime,params=:params where  timeTaskName=:timeTaskName")
    void updateTimeTaskByTimeTask(@Param("scheduleTaskIndex") String scheduleTaskIndex
            , @Param("executeTime") String executeTime, @Param("params") String params, @Param("timeTaskName") String timeTaskName);

}
