package org.finace.schedule.listenter;

import com.alibaba.fastjson.JSONObject;
import org.finace.schedule.utils.TimeTaskBus;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.jms.JmsListenter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by Ness on 2016/12/10.
 */
public class TimeTakListenter implements JmsListenter {
    private Logger logger = LoggerFactory.getLogger(TimeTakListenter.class);
    @Autowired
    private TimeTaskBus timeTaskBus;

    @Override
    public void onMsg(String s) {
        try {
            logger.info("接受监听定时任务的jms消息", s);

            if (Regular.checkEmpty(s, null)) {
                return;
            }
            TimeTask timeTask = JSONObject.parseObject(s, TimeTask.class);

            timeTaskBus.execute(timeTask);

        } catch (Exception e) {
            logger.warn("监听定时任务的jms消息{}出错", s, e);
        }
    }
}
