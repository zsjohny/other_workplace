package org.finace.schedule.service.impl;


import org.finace.schedule.dao.TimeTaskDao;
import org.finace.schedule.service.TimeTaskServer;
import org.finace.utils.entity.schedule.TimeTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Ness on 2016/12/10.
 */
@Transactional
@Service
public class TimeTaskServerImpl implements TimeTaskServer {
    @Autowired
    private TimeTaskDao timeTaskDao;

    @Override
    public Iterable<TimeTask> findTimeTaskAll() {

        return timeTaskDao.findTimeTaskAll();
    }

    @Override
    public void saveTimeTask(TimeTask task) {
        timeTaskDao.saveTimeTask(task);
    }

    @Override
    public void updateTimeTask(TimeTask task) {
        timeTaskDao.updateTimeTask(task);
    }


    @Override
    public void deleteTimeTask(TimeTask task) {
        timeTaskDao.deleteTimeTask(task);
    }


}
