package org.finace.schedule.job;

import org.finace.schedule.utils.TimeTaskBus;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.jms.JmsSender;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by Ness on 2016/12/10.
 */
@Component
public class TimeTaskJob implements Job {
    private Logger logger = LoggerFactory.getLogger(TimeTaskJob.class);

    @Autowired
    private JmsSender jmsSender;

    @Autowired
    private TimeTaskBus timeTaskBus;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        Collection<Object> values = jobExecutionContext.getMergedJobDataMap().values();
        TimeTask task;

        for (Object obj : values.toArray()) {
            task = (TimeTask) obj;
            if (Regular.checkEmpty(task.getParams(), null)) {
                continue;
            }
            logger.info("开始执行定时任务{}", task);

            //这里进行计算是否是商家的抢购活动 进行更新时刻表
            timeTaskBus.updateTaskByGroupName(task);

            jmsSender.sendMsg(task.getParams());
            logger.info("结束执行定时任务{}", task);
        }

    }
}
