package org.finace.schedule.repository;


import org.finace.utils.entity.schedule.TimeTask;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * 定时任务执行的reposiroty类
 * Created by Ness on 2016/12/8.
 */
public interface TimeTaskCrudRepository extends CrudRepository<TimeTask, Integer> {

    TimeTask findByTimeTaskName(String timeTaskName);



}
