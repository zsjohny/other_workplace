package org.finace.schedule.utils;


import com.alibaba.fastjson.JSONObject;
import org.finace.schedule.job.TimeTaskJob;
import org.finace.schedule.service.TimeTaskServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.db.MongodbTemplete;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.CacheType;
import org.finace.utils.enums.TimerTaskNameType;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.quartz.spi.JobFactory;
import org.quartz.spi.TriggerFiredBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Calendar;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * 定时任务的总工具类
 * Created by Ness on 2016/12/10.
 */
@Component
public class TimeTaskBus {
    private Logger logger = LoggerFactory.getLogger(TimeTaskBus.class);
    private String JOB_DETAIL_GROUP = "job_detail_group";
    private String JOB_TRIGGER_GROUP = "job_trigger_group";

    @Autowired
    private TimeTaskServer timeTaskServer;

    @Autowired
    private TimeTaskJob timeTaskJob;

    @Autowired
    private CacheTemplete cacheTemplete;

    @Autowired
    private MongodbTemplete mongodbTemplete;


    protected static Boolean IS_RESET_OVER = false;


    private Scheduler schedule;

    private JobDetail jobDetail;
    private JobKey jobKey;

    {

        try {
            SchedulerFactory factory = new StdSchedulerFactory();
            schedule = factory.getScheduler();

            /**
             * 初始化设置timeTask中的注入类
             */
            schedule.setJobFactory(new JobFactory() {

                @Override
                public Job newJob(TriggerFiredBundle bundle, Scheduler scheduler) throws SchedulerException {

                    if (bundle.getJobDetail().getJobClass().equals(TimeTaskJob.class)) {
                        return timeTaskJob;
                    }
                    try {
                        return bundle.getJobDetail().getJobClass().newInstance();
                    } catch (InstantiationException e) {

                    } catch (IllegalAccessException e) {

                    }
                    return null;
                }
            });
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 初始化定时任务列表
     *
     * @param jobName 定时任务的组名称
     */
    public void initSchedule(String jobName) {
        if (Regular.checkEmpty(jobName, null)) {
            return;
        }

        try {
            jobKey = new JobKey(jobName, JOB_DETAIL_GROUP);
            jobDetail = schedule.getJobDetail(jobKey);
            if (jobDetail == null) {
                jobDetail = JobBuilder.newJob(TimeTaskJob.class).withIdentity(jobName, JOB_DETAIL_GROUP).build();
            }
        } catch (SchedulerException e) {

        }
    }

    /**
     * 初始化定时任务
     */
    @PostConstruct
    private void initTask() {
        logger.info("开始初始化定时任务...");
        try {

            Iterable<TimeTask> timeTaskAll =
                    timeTaskServer.findTimeTaskAll();

            if (Regular.checkEmpty(timeTaskAll, null)) {
                logger.info("未检测到需要添加的定时任务");
                IS_RESET_OVER = true;
                return;
            }

            for (TimeTask task : timeTaskAll) {
                addTask(task);
            }

            schedule.start();
            IS_RESET_OVER = true;
            logger.info("初始化定时任务success...");
        } catch (Exception e) {
            logger.warn("初始化定时任务失败", e);
            throw new RuntimeException(e);
        }


    }

    public static void main(String[] args) throws InterruptedException {

        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        TimeTaskBus bus = (TimeTaskBus) context.getBean("timeTaskBus");

        if (1 == 1) {

            bus.findRestTask(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName());
            return;
        }

        TimeUnit.SECONDS.sleep(10);
        TimeTask timeTask = new TimeTask();
        timeTask.setExecuteTime("50 * * * * ?");
        timeTask.setTimeTaskName("111111");
        timeTask.setParams("3333333");
//        bus.updateTask(timeTask);
        bus.startNowTask(timeTask);
//        bus.deleteTask(timeTask);

        TimeUnit.SECONDS.sleep(50);
        System.err.println("50 seconds have arrived");

     /*   TimeTaskBus bus = new TimeTaskBus();
        bus.initTask();*/

    }


    /**
     * 添加定时任务
     *
     * @param task
     */
    private void addTask(TimeTask task) {

        logger.info("开始添加定时任务{}...", task);
        try {
            //检测是否已经存在
            if (schedule.checkExists(new JobKey(task.getTimeTaskName(), JOB_DETAIL_GROUP))) {
                logger.info("已经添加过定时任务{}...", task);
                return;
            }
            initSchedule(task.getTimeTaskName());

            jobDetail.getJobDataMap().put(task.getTimeTaskName(), task);
            String cronExpress = task.getExecuteTime();
            CronScheduleBuilder cronBuild = CronScheduleBuilder.cronSchedule(cronExpress);
            Trigger trigger = TriggerBuilder.newTrigger().withIdentity(task.getTimeTaskName(), JOB_TRIGGER_GROUP).withSchedule(cronBuild).build();
            schedule.scheduleJob(jobDetail, trigger);
            timeTaskServer.saveTimeTask(task);
            //判断是否需要重启
            if (!schedule.isStarted()) {
                logger.info("启动定时任务success");
                schedule.start();
            }

            logger.info("添加定时任务{}success...", task);
        } catch (Exception e) {
            logger.warn("添加定时任务{},失败", task, e);
            throw new RuntimeException(e);
        }


    }


    /**
     * 删除定时任务
     *
     * @param task
     */
    private void deleteTask(TimeTask task) {

        logger.info("开始删除定时任务{}...", task);
        try {

            jobKey = new JobKey(task.getTimeTaskName(), JOB_DETAIL_GROUP);
            if (schedule.checkExists(jobKey)) {
                schedule.deleteJob(jobKey);
                timeTaskServer.deleteTimeTask(task);
                logger.info("删除定时任务{}success...", task);
            } else {
                logger.info("没有查询到定时任务{}...", task);
            }


        } catch (Exception e) {
            logger.warn("删除定时任务{},失败", task, e);
            throw new RuntimeException(e);
        }


    }

    /**
     * 更新定时任务
     *
     * @param task
     */
    private void updateTask(TimeTask task) {

        logger.info("开始更新定时任务{}...", task);
        try {
            TriggerKey triggerKey = new TriggerKey(task.getTimeTaskName(), JOB_TRIGGER_GROUP);
            if (schedule.checkExists(triggerKey)) {
                String cronExpress = task.getExecuteTime();
                CronScheduleBuilder cron = CronScheduleBuilder.cronSchedule(cronExpress);
                Trigger trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).withSchedule(cron).build();
                trigger.getJobDataMap().put(task.getTimeTaskName(), task);
                schedule.rescheduleJob(triggerKey, trigger);
                timeTaskServer.updateTimeTask(task);
                logger.info("更新定时任务{}success...", task);
            } else {
                logger.info("没有查询到定时任务{}...", task);
            }


        } catch (Exception e) {
            logger.warn("更新定时任务{},失败", task, e);
            throw new RuntimeException(e);
        }


    }

    /**
     * 立即执行定时任务
     *
     * @param task
     */
    private void startNowTask(TimeTask task) {

        logger.info("开始立即执行定时任务{}...", task);
        try {
            TriggerKey triggerKey = new TriggerKey(task.getTimeTaskName(), JOB_TRIGGER_GROUP);
            String cronExpress = task.getExecuteTime();
            CronScheduleBuilder cron = CronScheduleBuilder.cronSchedule(cronExpress);
            Trigger trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).withSchedule(cron).startNow().build();
            trigger.getJobDataMap().put(task.getTimeTaskName(), task);
            if (schedule.checkExists(triggerKey)) {
                schedule.rescheduleJob(triggerKey, trigger);
                timeTaskServer.updateTimeTask(task);
                logger.info("更新已经存在的并开始立即执行定时任务{}success...", task);
            } else {
                initSchedule(task.getTimeTaskName());
                schedule.scheduleJob(jobDetail, trigger);
                timeTaskServer.saveTimeTask(task);
                logger.info("重新创建并开始立即执行定时任务{}success...", task);
            }

            //判断是否需要重启
            if (!schedule.isStarted()) {
                logger.info("立即启动定时任务success");
                schedule.start();
            }
        } catch (Exception e) {
            logger.warn("开始立即执行定时任务{},失败", task, e);
            throw new RuntimeException(e);
        }


    }

    /**
     * 更新活动表
     *
     * @param timeTask 活动的时实体类
     */
    public void updateTaskByGroupName(TimeTask timeTask) {
        if (timeTask == null) {
            logger.warn("更新活动表的实体类为空");
            return;
        }
        try {
            logger.info("开始更新活动表{}任务", timeTask);
            if (Regular.checkEmpty(timeTask.getParams(), null)) {
                logger.warn("更新活动表的实体类{} 传递参数为空", timeTask);
                return;
            }

            if (timeTask.getTimeTaskName().startsWith(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName())) {
                logger.info("检测到 更新活动表{}任务,开始进行更新", timeTask);

                //获得存储当前的定时任务列表
                Map<String, String> _oringalMap = cacheTemplete.getCacheForHashAll(CacheType.PURCASE_GROUP.getValue());
                ConcurrentHashMap<String, String> _saveMap = new ConcurrentHashMap<>();
                long currentTimes = System.currentTimeMillis();
                if (!Regular.checkEmpty(_oringalMap, null)) {
                    for (Map.Entry<String, String> entry : _oringalMap.entrySet()) {
                        //进行检测是否有过期时间
                        if (currentTimes - Long.parseLong(entry.getKey()) > 0) {
                            //进行删除过期时间
                            cacheTemplete.deleteCacheHash(CacheType.PURCASE_GROUP.getValue(), entry.getKey());
                            continue;
                        }
                        _saveMap.put(entry.getKey(), entry.getValue());
                    }
                }
                CronTriggerImpl cronTrigger = new CronTriggerImpl();

                Calendar calendar = Calendar.getInstance();
                int day = calendar.getTime().getDay();
                Set<String> set;
                cronTrigger.setCronExpression(timeTask.getExecuteTime());
                //计算首次时间
                cronTrigger.computeFirstFireTime(null);
                Date nextFireTime = cronTrigger.getNextFireTime();

                if (nextFireTime != null && (nextFireTime.getDay() - day == 1 || nextFireTime.getDay() - day == 0)) {
                    String result = _saveMap.get(String.valueOf(nextFireTime.getTime()));
                    if (Regular.checkEmpty(result, null)) {
                        set = new TreeSet<>();
                    } else {
                        set = JSONObject.parseObject(result, Set.class);
                    }
                    set.add(timeTask.getParams());
                    _saveMap.put(String.valueOf(nextFireTime.getTime()), JSONObject.toJSONString(set));
                }
                if (_saveMap.isEmpty()) {
                    logger.warn("存储 更新活动表{}任务,为空", timeTask);
                    return;
                }

                cacheTemplete.setCacheForHashAll(CacheType.PURCASE_GROUP.getValue(), _saveMap);
                /**
                 * 进行检测当天的sql数据库是否存在数据
                 */
                Query query = new Query(Criteria.where("date").is(String.valueOf(calendar.get(Calendar.DAY_OF_YEAR))));
                Object one = mongodbTemplete.findOne(query, ConcurrentHashMap.class);
                _saveMap.put("date", String.valueOf(calendar.get(Calendar.DAY_OF_YEAR)));
                if (one == null) {
                    mongodbTemplete.save(_saveMap);
                } else {
                    mongodbTemplete.update(query, _saveMap);
                }

                logger.info("检测到 更新活动表{}任务,结束进行更新", timeTask);
            }


            logger.info("结束更新活动表{}任务", timeTask);
        } catch (Exception e) {
            logger.warn("更新活动表{}任务出错", timeTask, e);
        }

    }


    /**
     * 查询所有的定时任务的执行下个时间和上个时间
     *
     * @param groupName 需要查询的当组的key
     */
    public void findRestTask(String groupName) {

        synchronized (this) {

            if (Regular.checkEmpty(groupName, null)) {
                logger.warn("查询所有任务参数为空");
                return;
            }


            try {
                if (cacheTemplete.exist(CacheType.IS_SET_PURCASE.getValue())) {
                    logger.warn("指定时间内已经重复设置过查询{}的所有定时任务", groupName);
                    return;
                }

                logger.info("开始查询{}的所有定时任务", groupName);
                Set<TriggerKey> triggerKeys = schedule.getTriggerKeys(GroupMatcher.anyGroup());
                if (triggerKeys.isEmpty()) {
                    logger.info("暂未查询{}的相关的所有定时任务", groupName);
                    return;
                }

                List<String> nowTaskName = new LinkedList<>();
                TriggerKey key;
                for (Iterator<TriggerKey> tk = triggerKeys.iterator(); tk.hasNext(); ) {
                    key = tk.next();
                    if (key.getName().startsWith(groupName)) {
                        nowTaskName.add(key.getName());
                    }

                }

                if (nowTaskName.isEmpty()) {
                    logger.warn("查询{}的定时任务列表为空", groupName);
                    return;
                }

                //获得存储当前的定时任务列表
                Map<String, String> _oringalMap = cacheTemplete.getCacheForHashAll(CacheType.PURCASE_GROUP.getValue());

                long currentTimes = System.currentTimeMillis();
                ConcurrentHashMap<String, String> _saveMap = new ConcurrentHashMap<>();
                if (!Regular.checkEmpty(_oringalMap, null)) {
                    for (Map.Entry<String, String> entry : _oringalMap.entrySet()) {
                        //进行检测是否有过期时间
                        if (currentTimes - Long.parseLong(entry.getKey()) > 0) {
                            //进行删除过期时间
                            cacheTemplete.deleteCacheHash(CacheType.PURCASE_GROUP.getValue(), entry.getKey());
                            continue;
                        }
                        _saveMap.put(entry.getKey(), entry.getValue());
                    }
                }

                String name;
                JobDetail jobDetail;
                CronTriggerImpl cronTrigger = new CronTriggerImpl();
                TimeTask timeTask;
                Date nextFireTime;
                Calendar calendar = Calendar.getInstance();
                int day = calendar.getTime().getDay();
                String result;
                Set<String> set;
                for (Iterator<String> nowTask = nowTaskName.iterator(); nowTask.hasNext(); ) {
                    name = nowTask.next();
                    jobDetail = schedule.getJobDetail(new JobKey(name, JOB_DETAIL_GROUP));

                    for (Object obj : jobDetail.getJobDataMap().values()) {
                        timeTask = (TimeTask) obj;
                        if (Regular.checkEmpty(timeTask.getExecuteTime(), null)) {
                            continue;
                        }
                        cronTrigger.setCronExpression(timeTask.getExecuteTime());
                        //计算首次时间
                        cronTrigger.computeFirstFireTime(null);
                        nextFireTime = cronTrigger.getNextFireTime();

                        if (nextFireTime != null && (nextFireTime.getDay() - day == 1 || nextFireTime.getDay() - day == 0)) {
                            result = _saveMap.get(String.valueOf(nextFireTime.getTime()));
                            if (Regular.checkEmpty(result, null)) {
                                set = new TreeSet<>();
                            } else {
                                set = JSONObject.parseObject(result, Set.class);
                            }
                            set.add(timeTask.getParams());
                            _saveMap.put(String.valueOf(nextFireTime.getTime()), JSONObject.toJSONString(set));
                        }
                    }
                }

                if (_saveMap.isEmpty()) {
                    logger.warn("存储{}的所有定时任务为空 ", groupName);
                    return;
                }

                cacheTemplete.setCacheForHashAll(CacheType.PURCASE_GROUP.getValue(), _saveMap);
                _saveMap.put("date", String.valueOf(calendar.get(Calendar.DAY_OF_YEAR)));
                mongodbTemplete.save(_saveMap);
                logger.info("结束查询{}的所有定时任务", groupName);
                /**
                 * 防止重复设置
                 */
                cacheTemplete.setCacheForExper(CacheType.IS_SET_PURCASE.getValue(), "true", 1000 * 60 * 60);
            } catch (Exception e) {
                logger.warn("查询{}的所有定时任务出错", groupName, e);
            }


        }
    }

    /**
     * 执行定时任务
     *
     * @param task 定时任务
     */
    public void execute(TimeTask task) {
        if (task == null) {
            return;
        }

        try {
            logger.info("开始处理定时任务{}", task);
            switch (task.getScheduleOperaType()) {
                case ADD_TASK:
                    addTask(task);
                    break;
                case UPDATE_TASK:
                    updateTask(task);
                    break;
                case DELETE_TASK:
                    deleteTask(task);
                    break;
                case STARTNOW_TASK:
                    startNowTask(task);
                    break;
                default:
                    logger.warn("所传处理定时任务{},不符合规范", task);
                    return;

            }


            logger.info("结束处理定时任务{}", task);
        } catch (Exception e) {
            logger.warn("处理定时任务{}失败", task, e);
        }


    }

    @PreDestroy
    private void destory() {

        try {
            if (schedule != null && !schedule.isShutdown()) {
                schedule.shutdown();
                logger.info("销毁定时任务成功");
            }

        } catch (SchedulerException e) {
            logger.warn("销毁定时任务失败", e);
        }
    }


}
