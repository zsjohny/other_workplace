package org.finace.user.util.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.db.MongodbTemplete;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.order.Orders;
import org.finace.utils.enums.CacheType;
import org.finace.utils.enums.TimerTaskNameType;
import org.finace.utils.http.Iptools;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 定时抢购的操作类
 * Created by Ness on 2016/12/26.
 */
@Component
public class PurchandiseBus {

    /**
     * 发送jms消息恢复定时任务的标注
     */
    private static Boolean HAVE_SEND = false;

    private Logger logger = LoggerFactory.getLogger(PurchandiseBus.class);

    @Autowired
    private MongodbTemplete mongodbTemplete;

    @Autowired
    private CacheTemplete cacheTemplete;

    @Autowired
    @Qualifier("jmsSenderForRestTask")
    private JmsSender jmsSender;




    /**
     * 获得当天所有时刻表和当前的商品数据
     *
     * @return
     */
    public Response getAll(HttpServletRequest request) {

        logger.info("用户{},开始访问所有商品数据和抢购时刻表", Iptools.gainRealIp(request));

        Map<String, String> _saveMap = cacheTemplete.getCacheForHashAll(CacheType.PURCASE_GROUP.getValue());
        if (Regular.checkEmpty(_saveMap, null)) {
            //通知提醒活动
            logger.info("进行通知所有商品数据和抢购时刻表");
            if (!cacheTemplete.exist(CacheType.IS_SET_PURCASE.getValue()) && !HAVE_SEND) {
                jmsSender.sendMsg(TimerTaskNameType.MERCHANDISE_AUTO_PPURCASE.getName());
                HAVE_SEND = true;
            }

            Query query = new Query(Criteria.where("date").is(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_YEAR))));

            Object one = mongodbTemplete.findOne(query, ConcurrentHashMap.class);
            if (one == null) {
                logger.warn("数据库查询到 当天没有抢购活动");
            } else {
                _saveMap = (Map<String, String>) one;
            }
        }

        if (Regular.checkEmpty(_saveMap, null)) {
            _saveMap = new HashMap<>();
        }
        JSONObject jsonObject = new JSONObject();
        JSONArray titleArray = new JSONArray();
        JSONArray contentArray = new JSONArray();
        Merchandise mer;
        JSONObject json;
        Set<String> treeSet;
        JSONArray childArray;
        for (Map.Entry<String, String> entry : _saveMap.entrySet()) {
            if (Regular.checkEmpty(entry.getKey(), null)) {
                continue;
            }
            titleArray.add(entry.getKey());
            try {
                treeSet = JSONObject.parseObject(entry.getValue(),Set.class);
                if (!treeSet.isEmpty()) {
                    childArray = new JSONArray();
                    for (Iterator<String> it = treeSet.iterator(); it.hasNext(); ) {
                        mer = JSONObject.parseObject(it.next(), Merchandise.class);
                        json = new JSONObject();
                        json.put("name", mer.getMerchName());
                        json.put("logo", mer.getMerchLog());
                        json.put("id", mer.getUuid());
                        json.put("price", mer.getMerchPrice());
                        json.put("discount", mer.getMerchDisPrice());
                        json.put("des", mer.getPurcaseDes());
                        //目前订单模块没开发，等待---------------
                        json.put("count", 500);
                        json.put("radio", 0.43);
                        //目前订单模块没开发，等待---------------
                        childArray.add(json);

                    }
                    contentArray.add(childArray);
                }

            } catch (Exception e) {
                logger.warn("用户{},解析数据异常 访问所有商品数据和抢购时刻表", Iptools.gainRealIp(request), e);
            }

        }

        jsonObject.put("time", titleArray);
        jsonObject.put("mers", contentArray);
        logger.info("用户{},结束访问所有商品数据和抢购时刻表", Iptools.gainRealIp(request));

        return Response.success(jsonObject);
    }

    public static void main(String[] args) {
        Merchandise merchandise = new Merchandise();
        merchandise.setMerchName("快速党抢购 90%白鸭羽绒服抢购xxx");
        merchandise.setMerchLog("http://h.hiphotos.baidu.com/image/pic/item/8d5494eef01f3a2922e765c99b25bc315c607c8d.jpg");
        merchandise.setUuid("YzYyNmU4ZWItYWRjZC00MzQwLTg0ODUtZjQzNzVhNmZmYTQ3MTQ4MjI5NDc1Mzc5MA==");
        merchandise.setMerchPrice(1000.00);
        merchandise.setMerchDisPrice(800.00);
        merchandise.setPurcaseDes("顺丰包邮 赠送费险");
    }

}
