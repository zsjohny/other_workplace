package org.finace.user.repository;

import org.finace.utils.entity.user.Province;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface ProvinceRepository extends Repository<Province, Integer>{

	@Query("select province from Province")
	String[] selectProvince();
	
	@Query("select provinceID from Province where province=:province")
	Integer affirmPtovince(@Param("province")String province);
}
  