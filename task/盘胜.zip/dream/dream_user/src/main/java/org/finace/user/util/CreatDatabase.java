package org.finace.user.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Created by Ness on 2016/10/11.
 */
public class CreatDatabase implements ServletContextListener {

    private String DEAFULT_DATABASES = "finace";

    private static Logger logger = LoggerFactory.getLogger(CreatDatabase.class);

    public void contextInitialized(ServletContextEvent sce) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {

            Properties properties = new Properties();
            properties.load(CreatDatabase.class.getClassLoader().getResourceAsStream("dev/root.properties"));

            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection(properties.getProperty("jdbc.init.url"),
                    properties.getProperty("jdbc.user"), properties.getProperty("jdbc.pass"));

            preparedStatement = connection
                    .prepareStatement("CREATE  database if NOT  EXISTS " + DEAFULT_DATABASES + " CHARACTER  SET  utf8");

            preparedStatement.execute();

            logger.info("创建数据库成功");

        } catch (Exception e) {
            logger.warn("创建数据库出错", e);
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

}
