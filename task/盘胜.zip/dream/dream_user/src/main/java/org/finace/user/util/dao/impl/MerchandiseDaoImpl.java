package org.finace.user.util.dao.impl;

import org.finace.user.util.dao.MerchandiseDao;
import org.finace.user.util.task.QueryMerchandise;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.enums.MerchadiseSortType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ness on 2016/12/18.
 */
@Repository
public class MerchandiseDaoImpl implements MerchandiseDao {
    @Autowired
    private QueryMerchandise queryMerchandise;


    private int PAGE_COUNT = 20;

    /**
     * 分页查询所有的商品
     *
     * @param page         开始的页数 默认从第一页开始
     * @param pageCount    每页展示的数量，一般为null,采取默认值
     * @param word         搜索的字段 为空的时候查询所有
     * @param qualityId    搜索的属性的Id  eg.. 热门 快手党 精品搭配
     * @param sort         排序的sort字段  0代表综合 1 代表销量  2 代表价格
     * @param order        排序的升或者降序 0 代表升序 1代表降序
     * @param cateGoryId   分类的id
     * @param isCateParent 是否是父类搜索 true表示父类搜索（一级搜索） false表示二级
     * @param merchadiseId 商家的Id
     * @return
     */
    @Override
    public Page<Merchandise> findMerchadiseAllByPage(Integer page, Integer pageCount, String word, String qualityId, Integer sort, Integer order, String cateGoryId, Boolean isCateParent, String merchadiseId) {
        String[] sortArr;
        if (sort == null || sort.equals(Merchandise.COLLGATE)) {
            sortArr = new String[2];
            sortArr[0] = MerchadiseSortType.SALE_COUNT.getSort();
            sortArr[1] = MerchadiseSortType.SALE_PRICE.getSort();

        } else if (sort.equals(Merchandise.SALE_COUNT)) {
            sortArr = new String[1];
            sortArr[0] = MerchadiseSortType.SALE_COUNT.getSort();
        } else if (sort.equals(Merchandise.SALE_PRICE)) {
            sortArr = new String[1];
            sortArr[0] = MerchadiseSortType.SALE_PRICE.getSort();
        } else {
            sortArr = new String[1];
            sortArr[0] = MerchadiseSortType.CREATE_TIME.getSort();
        }

        Sort sortFile = new Sort((order != null && order == Merchandise.SORT_ASC ? Sort.Direction.ASC : Sort.Direction.DESC), sortArr);

        if (page == null || page < 0) {
            page = 1;
        }
        Pageable pageable = new PageRequest(page - 1, pageCount == null ? PAGE_COUNT : pageCount, sortFile);

        final String searchWord = word;

        final String cateGoryUuid = cateGoryId;
        final String merchantUuid = merchadiseId;
        final String qualityUuid = qualityId;
        final Boolean isParent = isCateParent;

        Specification<Merchandise> specification = new Specification<Merchandise>() {
            @Override
            public Predicate toPredicate(Root<Merchandise> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {

                List<Predicate> list = new ArrayList<>();
                list.add(cb.equal(root.get("deleted").as(Boolean.class), false));
                //默认查询为空时候所有
                if (!Regular.checkEmpty(searchWord, null)) {
                    StringBuilder builder = new StringBuilder("%");
                    builder.append(searchWord);
                    builder.append("%");
                    list.add(cb.like(root.get("merchName").as(String.class), builder.toString()));
                }

                //查询分类的Uuid
                if (!Regular.checkEmpty(cateGoryUuid, null)) {
                    if (isParent == null || isParent) {
                        list.add(cb.equal(root.get("merchanBelogCLassId").as(String.class), cateGoryUuid));


                    } else {
                        list.add(cb.equal(root.get("merchaBelogClassParentId").as(String.class), cateGoryUuid));

                    }
                }
                //查询商家的商品
                if (!Regular.checkEmpty(merchantUuid, null)) {
                    list.add(cb.equal(root.get("merchBelongToUuid").as(String.class), merchantUuid));
                }

                //查询所属的分类的Id
                if (!Regular.checkEmpty(qualityUuid, null)) {
                    list.add(cb.equal(root.get("merchQualityId").as(String.class), qualityUuid));
                }


                return cq.where(list.toArray(new Predicate[list.size()])).getRestriction();


            }
        };

        return queryMerchandise.findAll(specification, pageable);
    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        MerchandiseDao merchandiseDao = (MerchandiseDao) context.getBean("merchandiseDaoImpl");
        Page<Merchandise> merchatDiseList = merchandiseDao.findMerchadiseAllByPage(1, null, "", null, 1, 2, null, null, null);
        for (Merchandise merchasdise : merchatDiseList) {
            System.out.println(merchasdise);
        }
    }

}
