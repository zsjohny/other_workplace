package org.finace.user.dao;

import java.util.List;

import org.finace.utils.entity.user.Collection;

public interface CollectionDao {
	
	void addCollection(Collection collection);
	
	void deletedCollection(String fatherId,String uuid);
	
	List<String> selectCollection(String fatherId);
	
}
