package org.finace.user.service;

import org.finace.utils.operate.Response;

public interface CollectionServer {
	
	Response addCollection(String fatherId,String uuid,Boolean merchandiser);
	
	Response deletedCollection(String fatherId,String uuid);
	
	Response selectMerchandiseCollection(String fatherId);
	
	Response selectMerchandiserCollection(String fatherId);
	
}
