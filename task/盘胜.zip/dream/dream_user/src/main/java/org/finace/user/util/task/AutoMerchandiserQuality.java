package org.finace.user.util.task;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.repository.CrudRepository;

public interface AutoMerchandiserQuality extends CrudRepository<Merchandiser, Integer>{
	List<Merchandiser> findByDeleted(Boolean deleted);
}
