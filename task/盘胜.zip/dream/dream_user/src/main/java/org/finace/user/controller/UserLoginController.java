package org.finace.user.controller;

import javax.servlet.http.HttpServletRequest;

import org.finace.user.entity.UserForm;
import org.finace.user.entity.UserInfoForm;
import org.finace.user.service.UserServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.enums.ParamType;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.math.Arith;
import org.finace.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
public class UserLoginController {
    @Autowired
    private UserServer userServer;

    /**
     * 发送验证码或者第三方注册
     *
     * @param name 用户名
     * @param uid  唯一标识
     * @return
     */
    @RequestMapping("/sendCodeOrAccessByThird/tourist")
    public Response sendCodeOrAccessByThird(HttpServletRequest request, String name, String uid, Integer type, Integer model,String diviceType) {


        if (Regular.checkEmpty(name, null) || Regular.checkEmpty(uid, ParamType.UID) || type == null) {
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }

        return userServer.sendCodeOrAccessByThird(request, name, uid, type, model,diviceType);


    }

    /**
     * 比对验证码
     *
     * @return
     */
    @RequestMapping("/checkCodeAndRegist/tourist")
    public Response checkCodeAndRegist(HttpServletRequest request, UserForm userForm) {
        if (userForm == null || Regular.checkEmpty(userForm.getName(), null) || Regular.checkEmpty(userForm.getUid(), ParamType.UUID) || Regular.checkEmpty(userForm.getUid(), null)) {
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }

        return userServer.checkCodeAndRegist(request, userForm);

    }

    /**
     * 登陆
     *
     * @return
     */
    @RequestMapping("/load/tourist")
    public Response loadByPassOrCode(UserForm userForm,String diviceType,String cid) {
        if (userForm == null || Regular.checkEmpty(userForm.getName(), null)) {

            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        
        return userServer.loadByPassOrCode(userForm,diviceType,cid);

    }

    /**
     * 修改个人信息
     *
     * @return
     */
    @RequestMapping("/modifyInfo")
    public Response modifyInfo(HttpServletRequest request, UserInfoForm userInfoForm) {
        if (userInfoForm == null) {
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        if (request.getAttribute("uuid") == null) {
            return Response.noAuthor();
        }
        userInfoForm.setUuid((String) request.getAttribute("uuid"));
        return userServer.modifyInfo(userInfoForm);

    }
    /*
     * 用户减钱
     */
    @RequestMapping("/delGold/tourist")
    public int DelGold(String uuid,Double money){
    	return userServer.delGold(uuid, money);
    }
    /*
     * 用户查钱
     */
    @RequestMapping("/countMoney/tourist")
    public Response countMoney(String uuid){
    	return userServer.countMoney(uuid);
    }
    /*
     * 添加银行卡
     */
    @RequestMapping("/addBankCard")
    public Response addBankCard(HttpServletRequest request,String name,String number,Integer step,String auth){
    	if(Regular.checkEmpty(name, null)||Regular.checkEmpty(number, null)||Regular.checkEmpty(step,null)||Regular.checkEmpty(auth, null)){
    		return Response.fail();
    	}
    	return userServer.addBankCard(request, name, number, step, auth);
    }
    
    
    
    
}
