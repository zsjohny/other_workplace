package org.finace.user.dao;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandiser;

public interface MerchandiserCollectionDao {
	
	List<Merchandiser> selectMerchandiser(String uuid);
	
	void addMerchandiser(Merchandiser merchandiser);
	
	List<Merchandiser> selectAttention(String uuid);
	
	void updateAttention(Integer attention,String uuid);

}
