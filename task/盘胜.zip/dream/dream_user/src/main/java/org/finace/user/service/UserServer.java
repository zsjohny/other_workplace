package org.finace.user.service;

import org.finace.user.entity.UserForm;
import org.finace.user.entity.UserInfoForm;
import org.finace.utils.operate.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * user的serverr层
 */
public interface UserServer {

    Response sendCodeOrAccessByThird(HttpServletRequest request, String name, String uid, Integer type,Integer mode,String diviceType);

    Response checkCodeAndRegist(HttpServletRequest request, UserForm userForm);

    Response loadByPassOrCode(UserForm userForm,String diviceType,String cid);

    Response modifyInfo(UserInfoForm userInfoForm);
    
    int delGold(String uuid,Double money);
    
    Response countMoney(String uuid);
    
    Response opularziuAdd(String uuid);
    
    Response addBankCard(HttpServletRequest request,String name,String number,Integer step,String auth);

}
