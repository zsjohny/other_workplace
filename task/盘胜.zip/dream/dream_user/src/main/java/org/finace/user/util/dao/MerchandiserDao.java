package org.finace.user.util.dao;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.domain.Page;

public interface MerchandiserDao {

	Page<Merchandiser> findMerchadiseAllByPage(Integer page, Integer pageCount,String word,String qualityId,  Integer sort, Integer order, String cateGoryId,Boolean isCateParent,String merchadiseId);
	
}
