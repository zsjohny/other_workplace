package org.finace.user.controller;

import org.finace.user.util.utils.PurchandiseBus;
import org.finace.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 定时抢购的controller
 * Created by Ness on 2016/12/26.
 */
@RestController
@RequestMapping("/purchanse")
public class PurchaseController {
    @Autowired
    private PurchandiseBus purchandiseBus;

    /**
     * 获取抢购时刻表和当前抢购的商品
     */
    @RequestMapping("/getAll/tourist")
    public Response getPurchaseMerchdinse(HttpServletRequest request) {

        return purchandiseBus.getAll(request);
    }


}
