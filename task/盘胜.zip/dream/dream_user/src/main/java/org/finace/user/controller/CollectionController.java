package org.finace.user.controller;

import javax.servlet.http.HttpServletRequest;

import org.finace.user.service.CollectionServer;
import org.finace.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/collection")
public class CollectionController {
	@Autowired
	CollectionServer collectionServer;
	/**
	 * 
	 * @param request 发送的请求
	 * @param uuid  商品或者商家的uuid（因为uuid是唯一的所以不用分类）
	 * @return  添加收藏
	 */
	@RequestMapping("/addCollection")
	public Response addCollection(HttpServletRequest request,String uuid,Boolean merchandiser){
		return collectionServer.addCollection((String)request.getAttribute("uuid"),uuid,merchandiser);
	}
	/**
	 * 
	 * @param request 发送请求
	 * @param uuid  需要删除的商品或者商家的uuid
	 * @return
	 */
	@RequestMapping("/deletedCollection")
	public Response deletedCollection(HttpServletRequest request,String uuid){
		return collectionServer.deletedCollection((String)request.getAttribute("uuid"),uuid);
	}
	/**
	 * 
	 * @param request 发送的请求
	 * @return  查询我的收藏商品
	 */
	@RequestMapping("/selectMerchandiseCollection")
	public Response selectCollection(HttpServletRequest request){
		if(request == null){
			return Response.error();
		}
		return collectionServer.selectMerchandiseCollection((String)request.getAttribute("uuid"));
	}
	/**
	 * 
	 * @param request 发送的请求
	 * @return 查询我的收藏商家
	 */
	@RequestMapping("/selectMerchandiserCollection")
	public Response selectMerchandiserCollection(HttpServletRequest request){
		if(request == null){
			return Response.error();
		}
		return collectionServer.selectMerchandiserCollection((String)request.getAttribute("uuid"));
	}
	
}
