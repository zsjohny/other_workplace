package org.finace.user.service;

import org.finace.utils.operate.Response;

public interface PushServer {
	
	public Response andriodPush(String uuid,String deviceNum,String sendTopic,String sendContent,Boolean deleted);
	
	public Response iosPush(String uuid,String deviceNum,String sendTopic,String sendContent,Boolean deleted);

}
