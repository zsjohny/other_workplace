package org.finace.user.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandise;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface MerchandiseCollectionRepository extends Repository<Merchandise,Integer>{

	@Query("select new Merchandise(uuid,merchLog,merchName,merchPrice,merchBelongToUuid) from Merchandise where uuid=:uuid and deleted=false")
	List<Merchandise> selectMerchandise(@Param("uuid")String uuid);
	
	@Query("select id from Merchandise")
	Integer[] selectMerchandiseId();	
	
	
}
