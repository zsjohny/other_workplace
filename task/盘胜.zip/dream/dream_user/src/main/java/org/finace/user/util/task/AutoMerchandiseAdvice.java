package org.finace.user.util.task;

import org.finace.utils.entity.merchandise.MerchandiseAdvertise;
import org.finace.utils.entity.merchandise.MerchandiseQuality;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * 首页的广告加载
 * Created by Ness on 2016/12/20.
 */
public interface AutoMerchandiseAdvice extends CrudRepository<MerchandiseAdvertise, Integer> {
    List<MerchandiseAdvertise> findByDeleted(Boolean deleted);
}
