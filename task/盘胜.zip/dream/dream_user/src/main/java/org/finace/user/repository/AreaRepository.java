package org.finace.user.repository;

import org.finace.utils.entity.user.Area;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;
public interface AreaRepository extends Repository<Area,Integer>{
	
	@Query("select area from Area where fatherID=(select cityID from City where city=:city)")
	String[] selectArea(@Param("city")String city);

	@Query("select areaID from Area where area=:area and fatherID=:fatherID")
	Integer affirmArea(@Param("area")String area,@Param("fatherID")Integer fatherID);
	
	@Query("select area from Area where areaID=:areaID and fatherID=:fatherID")
	String verifyArea(@Param("areaID")Integer areaID,@Param("fatherID")Integer fatherID); 
	
}
