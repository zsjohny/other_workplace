package org.finace.user.dao;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandise;

public interface MerchandiseCollectionDao {
	List<Merchandise> selectMerchandise(String uuid);
	
	Integer[] selectMerchandiserId();
}
