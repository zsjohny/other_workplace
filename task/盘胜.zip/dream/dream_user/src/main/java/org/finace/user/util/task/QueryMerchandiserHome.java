package org.finace.user.util.task;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface QueryMerchandiserHome extends CrudRepository<Merchandiser, Integer>, JpaSpecificationExecutor<Merchandiser>{
	Merchandiser findByDeletedAndUuid(Boolean deleted, String uuid);
}
