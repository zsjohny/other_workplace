package org.finace.user.repository;

import org.finace.utils.entity.merchandise.MerchandiseCategory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface MerchandiseCategoryRepository extends Repository<MerchandiseCategory,Integer>{

	@Query("select id from MerchandiseCategory where parentCate=:parentCate")
	Integer[] selectSunId(@Param("parentCate")Boolean parentCate);
	
}
