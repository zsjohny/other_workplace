package org.finace.user.controller; 
import org.finace.user.entity.MerchandiseForm;
import org.finace.user.util.service.MerchandiserServer; 
import org.finace.utils.operate.Response; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController; 
@RestController @RequestMapping("/merchandiserQuery") 
public class MerchandiserQueryController { 
	@Autowired MerchandiserServer merchandiserServer;
	/** * * @param merchandiseForm 详情请看 /entity/merchandiseFrom *
	 *  @param extendsId 一级分类Id 或者 二级 分类的Id *
	 *   @param fatherIdOrSunId true 就是一级分类，false就是二级分类 *
	 *    @return 商品的分页查询但是这个东西会被调走，其实可以不测的 */ 
	@RequestMapping("/selectMerchandiser/tourist")
	public Response selectMerchandiser(MerchandiseForm merchandiseForm,String extendsId,Boolean fatherIdOrSunId){ 
		return merchandiserServer.findMerchadiseAllByPage(merchandiseForm,extendsId,fatherIdOrSunId); 
		} 
	}