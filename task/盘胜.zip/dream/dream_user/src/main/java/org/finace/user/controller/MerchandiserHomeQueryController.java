package org.finace.user.controller;

import org.finace.user.util.service.MerchandiserHomeServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/merchandiserHome")
public class MerchandiserHomeQueryController {
	@Autowired
	MerchandiserHomeServer merchandiserHome;
	
	/**
	 * 
	 * @param uuid  商家UID
	 * @return 商家显示首页的详情
	 */
	@RequestMapping("/selectHome/tourist")
	public Response MerchandiserHome(String uuid){
		if(Regular.checkEmpty(uuid, null)){
			return Response.fail();
		}
		return merchandiserHome.findMerchadiserHomeUuid(uuid);
	}
	
	/**
	 * 店内商品查询
	 */
	@RequestMapping("/selectStore/tourist")
	public Response MerchandiserStore(String name,String merchBelongToUuid){
		if(Regular.checkEmpty(name, null)){
			return Response.fail();
		}
		return merchandiserHome.selectStore(name,merchBelongToUuid);
	}
	
}
