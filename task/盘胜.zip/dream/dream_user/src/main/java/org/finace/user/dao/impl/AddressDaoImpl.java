package org.finace.user.dao.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.finace.user.dao.AddressDao;
import org.finace.user.repository.AddressCrudRepository;
import org.finace.user.repository.AddressRepository;
import org.finace.user.repository.AreaRepository;
import org.finace.user.repository.CityRepository;
import org.finace.user.repository.ProvinceRepository;
import org.finace.utils.entity.user.Address;
import org.finace.utils.screct.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AddressDaoImpl implements AddressDao {
	@Autowired
	private AddressCrudRepository addressCrudRepository;
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	ProvinceRepository provinceRepository;
	@Autowired
	CityRepository cityReository;
	@Autowired
	AreaRepository areaRepository;
	
	@Override
	public void addAddress(Address address) {
		address.setUuid(UserUtils.generateUUid());
		address.setDeleted(false);
		address.setCreateTime(Timestamp.from(Instant.now()));
		addressCrudRepository.save(address);
	}
	@Override
	public void deletedAddress(String uuid,Timestamp updateTime) {
		addressRepository.deletedAddress(uuid,updateTime);
	}

	@Override
	public void updateAddress(Address address,String uuid) {
		addressRepository.updateSite(address.getAddressName(), address.getAddressPhone(), address.getAddressSite(),address.getAddressMinute(),address.isDefaultSite(),address.getUpdateTime(),address.getSiteId(), uuid);
	}

	@Override
	public List<Address> selectAddress(String fatherId) {
		return addressRepository.selectSite(fatherId);
	}
	@Override
	public String[] selectProvince() {
		return provinceRepository.selectProvince();
	}
	@Override
	public String[] selectCity(String province) {
		return cityReository.selectCity(province);
	}
	@Override
	public String[] selectArea(String city) {
		return areaRepository.selectArea(city);
	}
	@Override
	public void updateDefaultSite(String fatherId) {
		addressRepository.updateDefaultSite(fatherId);
	}
	@Override
	public Address selectDefaultSite(String fatherId) {
		return addressRepository.selectDefaultSite(fatherId);
	}
}
