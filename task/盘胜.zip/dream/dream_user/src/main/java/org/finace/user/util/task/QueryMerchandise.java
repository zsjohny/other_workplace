package org.finace.user.util.task;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandise;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Ness on 2016/12/18.
 */
public interface QueryMerchandise extends CrudRepository<Merchandise, Integer>, JpaSpecificationExecutor<Merchandise> {
	
    Merchandise findByDeletedAndUuid(Boolean deleted, String uuid);
    
    List<Merchandise> findByDeletedAndId(Boolean deleted,Integer Id);

}
