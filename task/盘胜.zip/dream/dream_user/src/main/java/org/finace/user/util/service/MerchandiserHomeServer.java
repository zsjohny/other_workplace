package org.finace.user.util.service;

import org.finace.utils.operate.Response;

public interface MerchandiserHomeServer {
	Response findMerchadiserHomeUuid(String uuid);
	
	Response selectStore(String name,String merchBelongToUuid);
}
