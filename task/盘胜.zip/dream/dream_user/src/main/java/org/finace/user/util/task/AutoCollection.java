package org.finace.user.util.task;

import java.util.List;

import org.finace.utils.entity.user.Collection;
import org.springframework.data.repository.CrudRepository;

public interface AutoCollection extends CrudRepository<Collection, Integer>{
	
	List<Collection> findByFatherIdAndUuidAndDeleted(String fatherId,String uuid,Boolean deleted);

}
