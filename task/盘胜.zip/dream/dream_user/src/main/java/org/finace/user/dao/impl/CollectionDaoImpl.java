package org.finace.user.dao.impl;

import java.util.List;

import org.finace.user.dao.CollectionDao;
import org.finace.user.repository.CollectionCrudRepository;
import org.finace.user.repository.CollectionRepository;
import org.finace.utils.entity.user.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CollectionDaoImpl implements CollectionDao{
	
	@Autowired
	CollectionCrudRepository collectionCru;
	
	@Autowired
	CollectionRepository collectionRepository;
	
	@Override
	public void addCollection(Collection collection) {
		collectionCru.save(collection);
	}

	@Override
	public void deletedCollection(String fatherId,String uuid) {
		collectionRepository.deletedCollection(fatherId,uuid);
	}
	
	@Override
	public List<String> selectCollection(String fatherId) {
		return collectionRepository.selectCollection(fatherId);
	}
}
