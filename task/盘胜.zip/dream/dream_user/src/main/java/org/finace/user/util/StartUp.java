package org.finace.user.util;

import org.finace.user.controller.UserLoginController;
import org.finace.utils.operate.Services;

import java.io.IOException;

/**
 * Created by Ness on 2017/3/6.
 */
public class StartUp {
    public static void main(String[] args) throws IOException {

        new Services().setDefaultUrl("/login/sendCodeOrAccessByThird/tourist.do").start();


    }
}
