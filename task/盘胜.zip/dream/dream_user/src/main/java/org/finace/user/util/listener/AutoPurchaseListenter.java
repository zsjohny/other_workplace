package org.finace.user.util.listener;

import org.finace.utils.jms.JmsListenter;

/**
 * 抢购定时任务
 * Created by Ness on 2016/12/26.
 */
public class AutoPurchaseListenter implements JmsListenter {
    @Override
    public void onMsg(String s) {

    }
}
