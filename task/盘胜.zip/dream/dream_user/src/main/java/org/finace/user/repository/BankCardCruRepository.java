package org.finace.user.repository;

import org.finace.utils.entity.user.BankCard;
import org.springframework.data.repository.CrudRepository;

public interface BankCardCruRepository extends CrudRepository<BankCard, Integer>{

}
