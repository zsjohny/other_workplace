 package org.finace.user.controller;

import javax.servlet.http.HttpServletRequest;

import org.finace.user.entity.MerchandiseForm;
import org.finace.user.util.service.MerchandiseServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.operate.Response;
import org.finace.utils.operate.Services;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/merchadise")
public class MerchandiseQueryController {

    private Logger logger = LoggerFactory.getLogger(MerchandiseQueryController.class);

    @Autowired
    private MerchandiseServer merchandiseServer;

    
    /**
     * 
     * @param merchandiseForm 这个东西，请阅读/entity/MerchandiseForm 文件
     * @return  查询商品
     */
    @RequestMapping("/disMerchadise/tourist")
    public Response disMerchadise(MerchandiseForm merchandiseForm) {

        if (merchandiseForm == null) {
            logger.warn("商品的查询传输的数据为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        return merchandiseServer.findMerchadiseAllByPage(merchandiseForm);

    }

    /**
     * 
     * @param id  一级分类ID
     * @return  一级分类查询
     */
    @RequestMapping("/cateGoryLists/tourist")
    public Response cateGoryLists(String id) {
        if (Regular.checkEmpty(id, null)) {
            logger.warn("商品的一级分类Id为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        return merchandiseServer.findCateGoryLists(id);

    }
    /**
     * 
     * @param id  商品id
     * @return  查询商品详情
     */
    @RequestMapping("/queryMerchandiseSingle/tourist")
    public Response queryMerchandiseSingle(String id) {

        if (Regular.checkEmpty(id, null)) {
            logger.warn("商品的Id为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        return merchandiseServer.queryMerchandiseSingle(id);

    }
    /**
     * 
     * @param request 登录时候需要的接口
     * @param id
     * @return
     */
    @RequestMapping("/collectionMerchandise")
    public Response collectionMerchandise(HttpServletRequest request,String id){
    	
    	if (Regular.checkEmpty(id, null)) {
            logger.warn("商品的Id为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        return merchandiseServer.collectionMerchandiseSingle((String)request.getAttribute("uuid"), id);

    }
    
    
    @RequestMapping("/selectRecommend/tourist")
	public Response selectRecommend(String name){
    	if(Regular.checkEmpty(name, null)){
    		return Response.fail();
    	}
		return merchandiseServer.selectRecommend(name);
	}
    
    /**
     * 
     * @param merchUuid
     * @return  这个东西我也忘记是什么了，好像没有用
     */
    @RequestMapping("/loadStandard/tourist")
    public Response loadMerchStandard(String merchUuid) {
        if (merchUuid == null) {
            merchUuid = "M2QyMmNmMTgtYzA4MS00Y2M4LWI2YjctNjc4ODk5ZjJiODNlMTQ4MjkwODUzMTIzOQ==";
        }

        return merchandiseServer.loadMerchStandard(merchUuid);
    }



}
