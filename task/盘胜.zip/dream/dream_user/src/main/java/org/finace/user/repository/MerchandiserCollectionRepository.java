package org.finace.user.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface MerchandiserCollectionRepository extends Repository<Merchandiser,Integer>{
	
	@Query("select new Merchandiser(uuid,headPic,name,merchReceivedSeveral) from Merchandiser where uuid=:uuid")
	List<Merchandiser> selectMerchandiser(@Param("uuid")String uuid);
	
	@Query("select id from Merchandiser")
	List<Integer> addMerchandiser();
	
	@Modifying
	@Query("update Merchandiser set merchandiseId=:merchandiseId where id=:id")
	void test1(@Param("id")Integer id,@Param("merchandiseId")byte[] merchandiseId);	
	
	@Query("select new Merchandiser(uuid,attention) from Merchandiser where uuid=:uuid and deleted=false")
	List<Merchandiser> selectAttention(@Param("uuid")String uuid);
	
	@Modifying
	@Query("update Merchandiser set attention=:attention where uuid=:uuid")
	void updateAttention(@Param("attention")Integer attention,@Param("uuid")String uuid);
	
}
