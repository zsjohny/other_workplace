package org.finace.user.controller;

import org.finace.utils.operate.Response;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.qiniu.util.Auth;


@RestController
@RequestMapping("qiniu")
public class CdnManager{
	/**
	 * 
	 * @return 7牛云的一个接口
	 */
	@RequestMapping("token/tourist")
	public Response QiNiu(){
		JSONObject jsonObject = new JSONObject();
		String accessKey = "3RgzaKuGN9CdyxLk0W5MeSIe44SEUp5Uxw6liiQ4";
		String secretKey = "2z9HIi36caNOUwjQaVj68DDeTWiwkAm-RNYtrqkV";
		String bucketName = "pskgcompany";
		Auth auth = Auth.create(accessKey, secretKey);
		String token = auth.uploadToken(bucketName);
		jsonObject.put("toKen",token);
	return Response.success(jsonObject);
	}
}
