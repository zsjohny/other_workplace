package org.finace.user.dao.impl;

import org.finace.user.dao.UserDao;
import org.finace.user.repository.UserCrudRepository;
import org.finace.user.repository.UserRepository;
import org.finace.utils.entity.user.User;
import org.finace.utils.screct.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;

@Component
public class UserDaoImpl implements UserDao {

    @Autowired
    private UserCrudRepository userCrudRepository;
    @Autowired
    private UserRepository userRepository;


    @Override
    public User findUserByOther(String name) {
        return userRepository.findUUidAndPassByPhoneOrEmailOrThirdId(name);
    }

    @Override
    public void saveUser(User user) {
        user.setCreateTime(Timestamp.from(Instant.now()));
        user.setDeleted(false);
        user.setName(UserUtils.generateName());
        userCrudRepository.save(user);
    }

    @Override
    public void removeUserByUuid(User user) {
        userRepository.removeUserByUuid(new Date(), user.getUuid());
    }

    @Override
    public void updatePassByUuid(String pass, String uuid) {
        userRepository.updatePassByUuid(pass, new Date(), uuid);
    }


    @Override
    public void  updatePhoneAndPassByUuid(String phone,String pass, String uuid) {
        userRepository. updatePhoneAndPassByUuid( phone, pass, new Date(), uuid);
    }

    @Override
    public void updateTimeAndUidByUuid(Date updateTime,String uid, String uuid,String diviceType,String cid) {
        userRepository.updateTimeAndUidByUuid(updateTime,uid, uuid,diviceType,cid);
    }

    @Override
    public void updateHeadPicByUuid(String headPic, String uuid) {
        userRepository.updateHeadPicByUuid(headPic, new Date(), uuid);
    }

    @Override
    public void updateNickNameByUuid(String nickName, String uuid) {
        userRepository.updateNickNameByUuid(nickName, new Date(), uuid);
    }

    @Override
    public void updateThirdQQIdByUuid(String thirdQQId, String uuid) {
        userRepository.updateThirdQQIdByUuid(thirdQQId, new Date(), uuid);
    }

    @Override
    public void updateThirdWechatIdByUuid(String thirdWechatId, String uuid) {
        userRepository.updateThirdWechatIdByUuid(thirdWechatId, new Date(), uuid);
    }

    @Override
    public void updateThirdWeBoIdIdByUuid(String thirdWeBoId, String uuid) {
        userRepository.updateThirdWeBoIdIdByUuid(thirdWeBoId, new Date(), uuid);
    }

    @Override
    public User findPhoneAndPassByUuid(String uuid) {
        return userRepository.findPhoneAndPassByUuid(uuid);
    }

	@Override
	public void updateBound(String uuid) {
		userRepository.updateBound(uuid);
	}
}
