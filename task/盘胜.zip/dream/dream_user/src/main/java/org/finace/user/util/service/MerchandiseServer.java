package org.finace.user.util.service;

import org.finace.user.entity.MerchandiseForm;
import org.finace.utils.operate.Response;

/**
 * Created by Ness on 2016/12/20.
 */
public interface MerchandiseServer {

	Response findMerchadiseAllByPage(MerchandiseForm merchandiseForm);

	Response findCateGoryLists(String id);
    
	Response queryMerchandiseSingle(String id);

	Response loadMerchStandard(String merchUuid);
	
	Response collectionMerchandiseSingle(String uuid,String id);
	
	Response selectRecommend(String name);


}
