package org.finace.user.service.impl;

import java.sql.Timestamp;
import java.time.Instant;

import org.finace.user.service.PushServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.push.Push;
import org.finace.utils.enums.PhoneType;
import org.finace.utils.operate.Response;
import org.finace.utils.push.PushUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;

@Service
@Transactional
public class PushServerImpl implements PushServer{
	/**
	 * 
	 * @param uuid 获取的用户的Uid
	 * @param deviceNum 设备编号
	 * @param sendTopic 信息主题
 	 * @param sendContent 信息内容
	 * @param deleted 是否删除
	 * @return
	 */
	@Override
	public Response iosPush(String uuid, String deviceNum, String sendTopic, String sendContent,
			Boolean deleted) {
		
		if(uuid==null||deviceNum==null||sendTopic==null||sendContent==null){
			return Response.error();
		}
		
		JSONObject jsonObject = new JSONObject();
		Push push = new Push();
		push.setSendDeviceType(PhoneType.ANDROID_KEY.getKey());
		push.setDeviceNum(deviceNum);
		push.setUuid(uuid);
		push.setSendTopic(sendTopic);
		push.setSendContent(sendContent);
		push.setCreateTime(Timestamp.from(Instant.now()));
		push.setDeleted(deleted);
		jsonObject.put("deviceNum",Regular.checkEmpty(push.getDeviceNum(),null)?"":push.getDeviceNum());
		jsonObject.put("sendTopic", Regular.checkEmpty(push.getSendTopic(), null)?"":push.getSendTopic());
		PushUtils.sendPush(push);
		
		return Response.success();
	}

	/**
	 * 
	 * @param uuid 获取的用户的Uid
	 * @param deviceNum 设备编号
	 * @param sendTopic 信息主题
 	 * @param sendContent 信息内容
	 * @param deleted 是否删除
	 * @return
	 */
	@Override
	public Response andriodPush(String uuid, String deviceNum, String sendTopic, String sendContent,
			Boolean deleted) {
		if(uuid==null||deviceNum==null||sendTopic==null||sendContent==null){
			return Response.error();
		}
		JSONObject jsonObject = new JSONObject();
		Push push = new Push();
		push.setSendDeviceType(PhoneType.IOS_KEY.getKey());
		push.setDeviceNum(deviceNum);
		push.setUuid(uuid);
		push.setSendTopic(sendTopic);
		push.setSendContent(sendContent);
		push.setCreateTime(Timestamp.from(Instant.now()));
		push.setDeleted(deleted);
		jsonObject.put("sendTopic", Regular.checkEmpty(push.getSendTopic(), null)?"":push.getSendTopic());
		jsonObject.put("deviceNum",Regular.checkEmpty(push.getDeviceNum(),null)?"":push.getDeviceNum());
		PushUtils.sendPush(push);
		
		return Response.success();
	}

	
	
}
