package org.finace.user.entity;

/**
 * 前端首页查询实体类
 * Created by Ness on 2016/12/20.
 */
public class MerchandiseForm {


    /**
     * 开始的页数 默认从第一页开始
     */
    private Integer page;
    /**
     * 搜索的字段 为空的时候查询所有
     */
    private String word;
    /**
     * 排序的sort字段  0代表综合 1 代表销量  2 代表价格
     */
    private Integer sort;
    /**
     * 排序的升或者降序 0 代表升序 1代表降序
     */
    private Integer order;

    /**
     * 分类的uuid
     */
    private String cateId;

    /**
     * 是否为一级代码 true为一级 false为二级
     */
    private Boolean catePar;

    /**
     * 商家的uuid
     */

    private String merId;

    /**
     * 所属分类的Id
     */
    private String quaId;


    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public String getCateId() {
        return cateId;
    }

    public void setCateId(String cateId) {
        this.cateId = cateId;
    }

    public String getMerId() {
        return merId;
    }

    public void setMerId(String merId) {
        this.merId = merId;
    }

    public String getQuaId() {
        return quaId;
    }

    public void setQuaId(String quaId) {
        this.quaId = quaId;
    }

    public Boolean getCatePar() {
        return catePar;
    }

    public void setCatePar(Boolean catePar) {
        this.catePar = catePar;
    }

    @Override
    public String toString() {
        return "MerchandiseForm{" +
                "page=" + page +
                ", word='" + word + '\'' +
                ", sort=" + sort +
                ", order=" + order +
                ", cateId='" + cateId + '\'' +
                ", catePar=" + catePar +
                ", merId='" + merId + '\'' +
                ", quaId='" + quaId + '\'' +
                '}';
    }
}
