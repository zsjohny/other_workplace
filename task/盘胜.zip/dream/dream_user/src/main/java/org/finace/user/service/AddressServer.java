package org.finace.user.service;

import org.finace.utils.operate.Response;

public interface AddressServer {
	Response addAddress(String fatherId,String addressName,String addressPhone,String site,String addressMinute,boolean defaultSite,String[] siteId);
	
	Response deletedAddress(String uuid);
	
	Response updateAddress(String fatherId,String uuid,String addressName,String addressPhone,String site,String addressMinute,Boolean defaultSite,String[] siteId);
	
	Response selectAddress(String fatherId);
	
	Response selectDefaultSite(String fatherId);
	
	Response selectProvince();
	
	Response selectCity(String province);
	
	Response selectArea(String city);
	
	Response requestAddress(String province,String city,String area);
}
