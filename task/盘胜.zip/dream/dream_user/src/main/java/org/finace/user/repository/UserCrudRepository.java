package org.finace.user.repository;


import org.finace.utils.entity.user.User;
import org.springframework.data.repository.CrudRepository;

public interface UserCrudRepository extends CrudRepository<User, Integer> {
	User findByUuid(String uuid);
	
    User findByThirdQQIdAndDeleted(String qq,Boolean deleted);
    
    User findByThirdWeBoIdAndDeleted(String webo,Boolean deleted);
    
    User findByThirdWechatIdAndDeleted(String weChat,Boolean deleted);
}
