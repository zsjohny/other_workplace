package org.finace.user.service.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.finace.user.dao.UserDao;
import org.finace.user.entity.UserForm;
import org.finace.user.entity.UserInfoForm;
import org.finace.user.repository.UserCrudRepository;
import org.finace.user.repository.UserRepository;
import org.finace.user.service.UserServer;
import org.finace.utils.Regular.BankUtil;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.entity.push.Push;
import org.finace.utils.entity.user.BankCard;
import org.finace.utils.entity.user.User;
import org.finace.utils.enums.NotifyType;
import org.finace.utils.enums.ParamType;
import org.finace.utils.enums.PhoneType;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.http.Iptools;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.math.Arith;
import org.finace.utils.operate.Response;
import org.finace.utils.prop.DataProperties;
import org.finace.utils.push.PushUtils;
import org.finace.utils.screct.DesUtil;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;

@Transactional
@Service
public class UserServerImpl implements UserServer {
    @Autowired
    private UserDao userDao;
    @Autowired
    CacheTemplete cacheTemplete;
    @Autowired
    DataProperties dataProperties;
    @Autowired
    private UserUtils userUtils;
    @Autowired
    private JmsSender jmsSender;
    @Autowired
    private UserCrudRepository userCrudRepository;
    @Autowired
    private UserRepository userRepoistory;

    private Logger logger = LoggerFactory.getLogger(UserServerImpl.class);


    /**
     * 发送验证码或者第三方注册
     *
     * @param name 用户名
     * @param uid  唯一标识
     */
    @Override
    public Response sendCodeOrAccessByThird(HttpServletRequest request, String name, String uid, Integer type, Integer model, String diviceType) {
        if (Regular.checkEmpty(name, null) || Regular.checkEmpty(uid, ParamType.UID) || type == null) {
            logger.warn("用户{},注册,时输入参数不符合规范uid={}", name, uid);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }

        //检测是否已经存在
        logger.info("用户{},开始注册,uid={}", name, uid);
        String token = "";
        User findUser = userDao.findUserByOther(name);
        if(Regular.checkEmpty(findUser, null)){
        	logger.info("出现问题={}",findUser);
        	
        }
        JSONObject json = new JSONObject();

        //判定是否是第三方登录  根据model字段判断
        /*
         * 快捷登录
         */
            //此刻判断用户是否是在同一台手机进行登录 不是的话  返回密码给他 进行解密登录
            if (findUser != null) {
                //不相同让用户 进行解密登录
                if (!findUser.getUid().equals(uid)) {
                    String passDes = "";
                    if (model.equals(User.MODEL_FOR_QQ)) {
                        passDes = DesUtil.encrypt(findUser.getThirdQQPass(), uid);
                    } else if (model.equals(User.MODEL_FOR_WECHAT)) {
                        passDes = DesUtil.encrypt(findUser.getThirdWechatId(), uid);

                    } else {
                        passDes = DesUtil.encrypt(findUser.getThirdWeboPass(), uid);
                    }
                    return Response.response(ResponseType.RESET_LOGIN.getCode(), passDes);
                }
                if (model.equals(User.MODEL_FOR_QQ)) {
                    token = userUtils.setAuthExper(findUser.getUuid(), findUser.getThirdQQPass(), uid);
                } else if (model.equals(User.MODEL_FOR_WECHAT)) {
                    token = userUtils.setAuthExper(findUser.getUuid(), findUser.getThirdWechatPass(), uid);
                } else {
                    token = userUtils.setAuthExper(findUser.getUuid(), findUser.getThirdWeboPass(), uid);
                }

                logger.info("用户{}, 第三方 存在,uid={} 生产token ", name, uid);
                json.put("token", token);
                json.put("nickName", Regular.checkEmpty(findUser.getNickName(), null) ? "" : findUser.getNickName());
                json.put("headPic", Regular.checkEmpty(findUser.getHeadPic(), null) ? "" : findUser.getHeadPic());
                json.put("qqIsBinging", Regular.checkEmpty(findUser.getThirdQQPass(), null) ? false : true);
                json.put("wechatIsBinging", Regular.checkEmpty(findUser.getThirdWechatPass(), null) ? false : true);
                json.put("weboIsBinging", Regular.checkEmpty(findUser.getThirdWeboPass(), null) ? false : true);
                logger.info("用户{},成功登陆,uid={}", findUser.getName(), uid);


                return Response.success(json);
            }
        }

        if ((findUser != null && type.equals(UserForm.REGISTER_PASS) || findUser == null && !type.equals(UserForm.REGISTER_PASS)) && model == null || (findUser != null && type.equals(UserForm.FIND_PASS))) {
            if ((findUser != null && type.equals(UserForm.REGISTER_PASS))) {
                logger.warn("用户{},已经存在,uid={}", name, uid);
            } else {
                logger.warn("用户{},不存在,uid={}", name, uid);
            }
            return Response.fail();
        }


        //手机注册
        
        Boolean phoneFlag = Regular.checkPhone(name);
        if (phoneFlag || Regular.checkEmail(name)) {

            if (cacheTemplete.exist(name)) {
                logger.warn("用户{},重复发送验证码,uid={}", name, uid);
                return Response.response(ResponseType.HAVE_SEND_CODE.getCode());
            }

            //本地测试把ip更改
            json.put("ip", Iptools.gainRealIp(request));
            json.put("number", name);
            json.put("type", phoneFlag ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
            jmsSender.sendMsg(json.toJSONString());
            try {

                //暂时没有短信模板   目前返回给前端 后续加上 去除

                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            json.clear();
            json.put("token", cacheTemplete.getCache(name));
        } else {
            if (model == null) {
                logger.warn("用户{},注册快捷登录类型输入参数不符合规范uid={}", name, uid);
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            User user = new User();
            user.setUuid(UserUtils.generateIncrementId());
            user.setUid(uid);
            if (model.equals(User.MODEL_FOR_QQ)) {
                if (Regular.checkEmpty(user.getThirdQQPass(), null)) {
                    user.setThirdQQId(name);
                    user.setThirdQQPass(UserUtils.generatePass());
                }
                token = userUtils.setAuthExper(user.getUuid(), user.getThirdQQPass(), name);
            } else if (model.equals(User.MODEL_FOR_WECHAT)) {
                if (Regular.checkEmpty(user.getThirdWechatPass(), null)) {
                    user.setThirdWechatId(name);
                    user.setThirdWechatPass(UserUtils.generatePass());
                }

                token = userUtils.setAuthExper(user.getUuid(), user.getThirdWechatPass(), name);
            } else {
                if (Regular.checkEmpty(user.getThirdWeboPass(), null)) {
                    user.setThirdWeBoId(name);
                    user.setThirdWeboPass(UserUtils.generatePass());
                }
                token = userUtils.setAuthExper(user.getUuid(), user.getThirdWeboPass(), name);
            }

            if (Regular.checkEmpty(token, null)) {
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            user.setDiviceType(diviceType);
            userDao.saveUser(user);
            json.put("token", token);
            //再次查询
            findUser = userDao.findUserByOther(name);

            json.put("nickName", Regular.checkEmpty(findUser.getNickName(), null) ? "" : findUser.getNickName());
            json.put("headPic", Regular.checkEmpty(findUser.getHeadPic(), null) ? "" : findUser.getHeadPic());
            json.put("qqIsBinging", Regular.checkEmpty(findUser.getThirdQQPass(), null) ? false : true);
            json.put("wechatIsBinging", Regular.checkEmpty(findUser.getThirdWechatPass(), null) ? false : true);
            json.put("weboIsBinging", Regular.checkEmpty(findUser.getThirdWeboPass(), null) ? false : true);
            logger.info("用户{},成功登陆,uid={}", findUser.getName(), uid);


        }
        logger.info("用户{},注册成功,uid={}", name, uid);

        return Response.success(json);

    }

    /**
     * 比对验证码或者手机注册成功
     *
     * @param userForm 传送的实体类
     * @return
     */
    @Override
    public Response checkCodeAndRegist(HttpServletRequest request, UserForm userForm) {
        if (userForm == null || Regular.checkEmpty(userForm.getName(), null) || Regular.checkEmpty(userForm.getUid(), ParamType.UID) || Regular.checkEmpty(userForm.getCode(), null)) {
            logger.warn("用户{},比对验证码输入参数不符合规范,uid={}", userForm.getName(), userForm.getUid());
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }

        Boolean flag = false;

        logger.info("用户{},开始比对验证码,uid={},userForm参数类型为{}", userForm.getName(), userForm.getUid(), userForm.getType());
        User user = userDao.findUserByOther(userForm.getName());
        //检测是否已经存在
        if ((user != null && (userForm.getType() == UserForm.REGISTER_PASS || userForm.getType() == UserForm.REGISTER_NEW || userForm.getType() == UserForm.MODIFY_PHONE)) || (user == null && userForm.getType() != UserForm.REGISTER_PASS && userForm.getType() != UserForm.MODIFY_PHONE && userForm.getType() != UserForm.REGISTER_NEW)) {
            String tip = "";
            if (userForm.getType() == UserForm.REGISTER_PASS) {
                tip = "注册时存在";
            } else {
                tip = "找回密码或者更改密码不存在";
            }

            logger.warn("用户{},{} ,uid={}", userForm.getName(), tip, userForm.getUid());

        }
        String code;
        String uuid = "";
        if (userForm.getType() == UserForm.MODIFY_PHONE) {
            //考虑到更换手机号需要发送验证  这里把权限直接加进去
            if (!userUtils.checkValid(request.getHeader("token"), request.getHeader("uid"))) {
                logger.warn("用户{}不正确,没有权限访问,uid={}", userForm.getName(), userForm.getUid());
                return Response.noAuthor();
            }
            uuid = userUtils.getUuid(request.getHeader("token"));
            user = userDao.findPhoneAndPassByUuid(uuid);
            if (user == null) {
                logger.warn("用户{},修改手机号检测该账号不存在 ,uid={}", userForm.getName(), userForm.getUid());

                return Response.fail();
            }

            logger.info("用户{},旧的手机号{},新的手机号{}", uuid, user.getPhone(), userForm.getName());
            code = cacheTemplete.getCache(Regular.checkEmpty(user.getPhone(), null) ? "" : user.getPhone());
        } else {
            code = cacheTemplete.getCache(userForm.getName());
        }


        if (Regular.checkEmpty(code, null)) {
            logger.warn("用户{},验证码没发送或者失效,,uid={}", userForm.getName(), userForm.getUid());
            return Response.response(ResponseType.HAVEN_INVALIAD_CODE.getCode());
        }

        if (!code.equals(userForm.getCode())) {
            logger.warn("用户{},比对验证码不正确,uid={},原验证{},输入验证{}", userForm.getName(), userForm.getUid(), code, userForm.getCode());
            return Response.response(ResponseType.INCORRECT_CODE.getCode());
        }

        if (userForm.getType() == UserForm.REGISTER_PASS) {

            if (Regular.checkEmpty(userForm.getPass(), ParamType.PASS)) {
                logger.warn("用户{}输入的密码{}不符合规范,uid={}", userForm.getName(), userForm.getPass(), userForm.getUid());
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            user = new User();

            if (Regular.checkPhone(userForm.getName())) {
                user.setPhone(userForm.getName());
                flag = true;
            } else if (Regular.checkEmail(userForm.getName())) {
                user.setEmail(userForm.getName());
                flag = true;

            }
            if (flag) {
                user.setUuid(UserUtils.generateIncrementId());
                user.setPass(DesUtil.encrypt(userForm.getPass(), user.getUuid()));
                userDao.saveUser(user);
            }


        }else if (userForm.getType() == UserForm.REGISTER_NEW) {
            if (Regular.checkEmpty(userForm.getPass(), ParamType.PASS)) {
                logger.warn("用户{}输入的密码{}不符合规范,uid={}", userForm.getName(), userForm.getPass(), userForm.getUid());
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }


            //这里是新加的内容考虑到后期的维护和 不太方便 先实现功能
            user = new User();
//            String generateUuid = UserUtils.generateUUid();
//            user.setUuid(generateUuid);
//            user.setUid(userForm.getUid());
//            user.setNickName(Regular.checkEmpty(userForm.getNickName(), null) ? "" : userForm.getNickName());
//            user.setPass(DesUtil.encrypt(userForm.getPass(), generateUuid));
//            user.setPhone(userForm.getName());
//            userDao.saveUser(user);
//
//            //进行获取信息
//            String token = userUtil.setAuthExper(user.getUuid(), userForm.getPass(), userForm.getUid());
            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("token", token);
//            jsonObject.put("vipGrade", user.getVipGrade() == null ? 0 : user.getVipGrade());
//            jsonObject.put("expireTime", user.getVipExpireTime() == null ? 0 : user.getVipExpireTime());
//            jsonObject.put("phone", Regular.checkEmpty(user.getPhone(), null) ? "" : user.getPhone());
//            jsonObject.put("nickName", Regular.checkEmpty(user.getNickName(), null) ? "" : user.getNickName());
//            jsonObject.put("headPic", Regular.checkEmpty(user.getHeadPic(), null) ? "" : user.getHeadPic());
//            jsonObject.put("birDay", Regular.checkEmpty(user.getBirthDay(), null) ? "" : user.getBirthDay());
//            jsonObject.put("sex", user.getGender() == null ? GenderType.MALE.getVlaue() : user.getGender() ? GenderType.FEMALE.getVlaue() : GenderType.MALE.getVlaue());
//            jsonObject.put("qqIsBinging", Regular.checkEmpty(user.getThirdQQPass(), null) ? false : true);
//            jsonObject.put("wechatIsBinging", Regular.checkEmpty(user.getThirdWechatPass(), null) ? false : true);
//            jsonObject.put("weboIsBinging", Regular.checkEmpty(user.getThirdWeboPass(), null) ? false : true);
//            jsonObject.put("aliPayRealName", Regular.checkEmpty(user.getAliPayRealName(), null) ? "" : user.getAliPayRealName());
//            jsonObject.put("aliPayAccount", Regular.checkEmpty(user.getAliPayAccount(), null) ? "" : user.getAliPayAccount());
//            jsonObject.put("money", user.getMoney() == null ? "0.00" : decimalFormat.format(user.getMoney()));

            return Response.success(jsonObject);


        } else if (userForm.getType() == UserForm.SIMPLE_ACCESS) {
            if (Regular.checkEmpty(userForm.getPass(), ParamType.PASS)) {
                logger.warn("用户{}输入的密码{}不符合规范,uid={}", userForm.getName(), userForm.getPass(), userForm.getUid());
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            userDao.updatePassByUuid(DesUtil.encrypt(userForm.getPass(), user.getUuid()), user.getUuid());
            flag = true;
        } else if (userForm.getType() == UserForm.MODIFY_PHONE) {
            if (!Regular.checkPhone(userForm.getName())) {
                logger.warn("用户输入的手机号{}不正确,uid={}", userForm.getName(), userForm.getUid());
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            //先进行解密
            String _Pass = DesUtil.decrypt(user.getPass(), uuid);
            _Pass = DesUtil.decrypt(_Pass, user.getPhone());
            if (Regular.checkEmpty(_Pass, null)) {
                logger.warn("用户输入的手机号{}原始密码解密出错,原始pass{},原始手机号{},uid={}", userForm.getName(), _Pass, user.getPhone(), userForm.getUid());
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            //重新进行加密
            _Pass = DesUtil.encrypt(_Pass, userForm.getName());
            _Pass = DesUtil.encrypt(_Pass, uuid);
            userDao.updatePhoneAndPassByUuid(userForm.getName(), _Pass, uuid);
            logger.info("用户{},成功比对验证码并设置新的手机成功,新密码为{},uid={}", userForm.getName(), _Pass, userForm.getUid());
            return Response.success();
        }

        if (flag) {

            String token = userUtils.setAuthExper(user.getUuid(), userForm.getPass(), userForm.getUid());
            if (Regular.checkEmpty(token, null)) {
                userDao.removeUserByUuid(user);
                logger.info("用户{},设置安全验证不正确，移除成功,uid={}", userForm.getName(), userForm.getUid());
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", token);
            logger.info("用户{},成功比对验证码,uid={}", userForm.getName(), userForm.getUid());
            return Response.success(jsonObject);
        } else {
            logger.warn("用户{},比对验证码是失败,uid={}", userForm.getName(), userForm.getUid());
            return Response.fail();
        }


    }


    /**
     * 根据密码或者验证码登录
     *
     * @param userForm
     * @return
     */
    @Override
    public Response loadByPassOrCode(UserForm userForm,String diviceType,String cid) {

        if (userForm == null || Regular.checkEmpty(userForm.getName(), null) || Regular.checkEmpty(userForm.getUid(), null)) {
            logger.warn("用户{},登陆输入参数不符合规范 name={},uid={}", userForm.getName(), userForm.getUid());
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        logger.info("用户{},开始校验登陆", userForm.getName());

        User user = userDao.findUserByOther(userForm.getName());

        //检测是否已经存在
        if (user == null) {
            logger.warn("登陆 用户{} 不存在", userForm.getName());
            return Response.fail();
        }
        //密码是否正确
        Boolean passFlag = false;


        if (Regular.checkEmpty(userForm.getCode(), null)) {
            if (Regular.checkPhone(userForm.getName()) || Regular.checkEmail(userForm.getName())) {
                //代表正常输入用户名登陆
                if (DesUtil.decrypt(user.getPass(), user.getUuid()).equals(userForm.getPass())) {
                    passFlag = true;
                }
            } else {

                if (userForm.getModel() == null) {
                    logger.warn("用户{},快捷登录类型输入参数不符合规范uid={}", userForm.getName(), userForm.getUid());
                    return Response.response(ResponseType.EMPTY_CODE.getCode());
                }


                if (userForm.getModel().equals(User.MODEL_FOR_QQ)) {
                    //代表正常输入用户名登陆
                    if (!Regular.checkEmpty(user.getThirdQQPass(), null) && user.getThirdQQPass().equals(userForm.getPass())) {
                        passFlag = true;

                    }
                } else if (userForm.getModel().equals(User.MODEL_FOR_WECHAT)) {
                    //代表正常输入用户名登陆
                    if (!Regular.checkEmpty(user.getThirdWechatPass(), null) && user.getThirdWechatPass().equals(userForm.getPass())) {
                        passFlag = true;

                    }
                } else {
                    //代表正常输入用户名登陆
                    if (!Regular.checkEmpty(user.getThirdWeboPass(), null) && user.getThirdWeboPass().equals(userForm.getPass())) {
                        passFlag = true;

                    }
                }


            }

        } else {
            String code = cacheTemplete.getCache(userForm.getName());

            if (Regular.checkEmpty(code, null)) {
                logger.warn("用户{},验证码没发送或者失效,,uid={}", userForm.getName(), user.getUid());
                return Response.response(ResponseType.HAVEN_INVALIAD_CODE.getCode());
            }

            if (code.equals(userForm.getCode())) {
                //短信验证登录 将用户密码替换
                if (Regular.checkEmpty(user.getPass(), null)) {
                    Random random = new Random();
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < 8; i++) {
                        builder.append(random.nextInt(10));
                    }
                    //更新前端密码
                    user.setPass(DesUtil.encrypt(DesUtil.encrypt(builder.toString(), userForm.getName()), user.getUuid()));
                    //更新密码
                    userDao.updatePassByUuid(user.getPass(), user.getUuid());

                }
                userForm.setPass(DesUtil.decrypt(user.getPass(), user.getUuid()));

                passFlag = true;
            }


        }


        if (passFlag) {

            String token = userUtils.setAuthExper(user.getUuid(), userForm.getPass(), userForm.getUid());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", token);
            jsonObject.put("nickName",Regular.checkEmpty(user.getNickName(),null) ? "" : user.getNickName());
            jsonObject.put("headPic",Regular.checkEmpty(user.getHeadPic(),null)?"":user.getHeadPic());
            jsonObject.put("qqIsBinging",Regular.checkEmpty(user.getThirdQQId(),null)?false:true);
            jsonObject.put("wechatIsBinging", Regular.checkEmpty(user.getThirdWechatId(),null)?false:true);
            jsonObject.put("weboIsBinging", Regular.checkEmpty(user.getThirdWeBoId(),null)?false:true);
            logger.info("用户{},成功登陆,uid={}", userForm.getName(), user.getUid());

            //更新登陆时间和Uid
            userDao.updateTimeAndUidByUuid(Timestamp.from(Instant.now()), userForm.getUid(), user.getUuid(),diviceType,cid);
            Push p = new Push();
            p.setSendDeviceType(PhoneType.ANDROID_KEY.getKey());
            p.setDeviceNum("f0c42d4d52328dc0e2db4ba9d5879ec3");
            p.setUuid("1811494807178be402f808029c974b88b1894265b");
            p.setSendTopic("test");
            p.setSendContent("123");
            PushUtils.sendPush(p);
            return Response.success(jsonObject);
        } else {
            logger.warn("用户{},登陆失败,uid={}", userForm.getName(), userForm.getUid());
            return Response.fail();
        }


    }

    /**
     * 修改个人信息
     *
     * @param userInfoForm 个人信息的表格
     * @return
     */
    @Override
    public Response modifyInfo(UserInfoForm userInfoForm) {

        if (userInfoForm == null) {
            logger.warn("用户登陆输入参数不符合规范");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        if (!Regular.checkEmpty(userInfoForm.getHeadPic(), null)) {
            userDao.updateHeadPicByUuid(userInfoForm.getHeadPic(), userInfoForm.getUuid());
        } else if (!Regular.checkEmpty(userInfoForm.getNickName(), null)) {
            userDao.updateNickNameByUuid(userInfoForm.getNickName(), userInfoForm.getUuid());
        } else if (userInfoForm.getModel() != null) {
            User findUser = userDao.findUserByOther(userInfoForm.getThirdUuid());

            if (findUser != null) {
                logger.warn("用户{},已经绑定,uid={}", userInfoForm.getThirdUuid(), findUser.getUuid());
                return Response.fail();
            }

            if (userInfoForm.getModel().equals(User.MODEL_FOR_QQ)) {
                userDao.updateThirdQQIdByUuid(userInfoForm.getThirdUuid(), userInfoForm.getUuid());
            } else if (userInfoForm.getModel().equals(User.MODEL_FOR_WECHAT)) {
                userDao.updateThirdWechatIdByUuid(userInfoForm.getThirdUuid(), userInfoForm.getUuid());
            } else if (userInfoForm.getModel().equals(User.MODEL_FOR_WEBO)) {
                userDao.updateThirdWeBoIdIdByUuid(userInfoForm.getThirdUuid(), userInfoForm.getUuid());
            } else {
                return Response.error();
            }

        } else {
            return Response.success();
        }


        return Response.success();
    }

    @Override
    public int delGold(String uuid, Double money) {
        User user = userCrudRepository.findByUuid(uuid);
        return userRepoistory.updateSubtractMoney(Arith.subtract(2, user.getMoney(), money), (String) uuid);
    }

    @Override
    public Response countMoney(String uuid) {
        JSONObject jsonObject = new JSONObject();
        User user = userCrudRepository.findByUuid(uuid);
        Double c = user.getMoney();
        jsonObject.put("money", c);
        return Response.success(jsonObject);
        
    }

    @Override
    public Response opularziuAdd(String uuid) {
        if (Regular.checkEmpty(userCrudRepository.findByUuid(uuid), null)) {
            logger.info("该uuid在用户中心未查询到");
            return Response.error();
        }
        return Response.success();
    }

	@Override
	public Response addBankCard(HttpServletRequest request, String name, String number,Integer step,String auth) {
		if(Regular.checkEmpty(name, null)||Regular.checkEmpty(number, null)||!Regular.checkNickName(name)||!Regular.checkBankCardMatch(number)){
			logger.info("参数出现问题={}",(String)request.getAttribute("uuid"));
			return Response.fail();
		}
		JSONObject json = new JSONObject();
		Boolean ok = false;
		if(step==0){
			String BankCard = BankUtil.getNameOfBank(number);
			json.put("bankCard",Regular.checkEmpty(BankCard, null)?"":BankCard);
			return Response.success(json);
		}
		if(step==1){
			json.put("ip", Iptools.gainRealIp(request));
            json.put("number", number);
            json.put("type",Regular.checkPhone(number) ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
            jmsSender.sendMsg(json.toJSONString());
		}
		if(step==2){
			String code = cacheTemplete.getCache(number);
			ok = code.equals(auth);
		}
		
		if(ok){
		BankCard bankCard = new BankCard();
		bankCard.setUuid((String)request.getAttribute("uuid"));
		bankCard.setName(name);
		bankCard.setBankCard(number);
		bankCard.setBankCard(BankUtil.getNameOfBank(number));
		bankCard.setCreateTime(Timestamp.from(Instant.now()));
		}
		return Response.error();
	}
}
