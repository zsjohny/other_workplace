package org.finace.user.util.task;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.CrudRepository;

public interface AutoMerchandiserHomeQuality extends CrudRepository<Merchandiser,Integer>{
	
	List<Merchandiser> findByDeletedAndUuid(Boolean deleted,String uuid);
	
}
