package org.finace.user.util.service.impl;

import java.util.Iterator;
import java.util.List;

import org.finace.user.entity.MerchandiseForm;
import org.finace.user.repository.MerchStandardRepository;
import org.finace.user.util.dao.MerchandiseDao;
import org.finace.user.util.service.MerchandiseServer;
import org.finace.user.util.task.AutoCollection;
/*import org.finace.user.util.task.AutoCollection;*/
import org.finace.user.util.task.AutoMerchandiseAdvice;
import org.finace.user.util.task.AutoMerchandiseQuality;
import org.finace.user.util.task.AutoMerchandiserHomeQuality;
import org.finace.user.util.task.AutoTaskMechandiser;
import org.finace.user.util.task.AutoTaskMerchandiseCatrgory;
/*import org.finace.user.util.task.AutoUserQuaity;*/
import org.finace.user.util.task.QueryMerchandise;
import org.finace.user.util.task.RepositoryMerchandise;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.merchandise.MerchandiseAdvertise;
import org.finace.utils.entity.merchandise.MerchandiseCategory;
import org.finace.utils.entity.merchandise.MerchandiseQuality;
import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.entity.user.Collection;
/*import org.finace.utils.entity.user.Collection;
import org.finace.utils.entity.user.User;*/
import org.finace.utils.enums.ResponseType;
import org.finace.utils.operate.Response;
import org.finace.utils.operate.Services;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * 商家的service层
 * Created by Ness on 2016/12/20.
 */
@Service
@Transactional
public class MerchandiseServerImpl implements MerchandiseServer {
    @Autowired
    private MerchandiseDao merchandiseDao;

    @Autowired
    private QueryMerchandise queryMerchandise;
    
    @Autowired
    private MerchStandardRepository msr;

    private Logger logger = LoggerFactory.getLogger(MerchandiseServerImpl.class);
    @Autowired
    private AutoMerchandiseQuality merchandiseQuality;

    @Autowired
    private AutoMerchandiseAdvice merchandiseAdvice;

    @Autowired
    private AutoTaskMechandiser autoTaskMechandiser;

    @Autowired
    private AutoTaskMerchandiseCatrgory autoTaskMerchandiseCatrgory;
    
    
    @Autowired
    private AutoCollection autoCollection;
    
    @Autowired
	private AutoMerchandiserHomeQuality merchandiserHome;
    
    @Autowired
    private RepositoryMerchandise repositoryMerchandise;
    
    
   /* @Autowired
    private AutoUserQuaity userQuaity;

    @Autowired
    private AutoCollection collection;*/
    

    @Override
    public Response findMerchadiseAllByPage(MerchandiseForm merchandiseForm) {

        if (merchandiseForm == null) {
            logger.warn("商品的查询的接受实体类为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        logger.info("商品的开始查询的接受实体类{}", merchandiseForm);

        //判断是否是首页
        JSONObject jsonObject = new JSONObject();
        if (Regular.checkEmpty(merchandiseForm.getWord(), null) && Regular.checkEmpty(merchandiseForm.getMerId(), null)&& Regular.checkEmpty(merchandiseForm.getQuaId(), null)&& Regular.checkEmpty(merchandiseForm.getCateId(), null)) {

            //首页查询出所有的广告，所有的属性分类

            JSONArray advise = new JSONArray();

            List<MerchandiseAdvertise> byDeleted = merchandiseAdvice.findByDeleted(false);
            if (!Regular.checkEmpty(byDeleted, null)) {
                byDeleted.stream().forEach(x -> {
                    JSONObject js = new JSONObject();
                    js.put("url", x.getAdviseUrl());
                    js.put("link", x.getAdviseLink());
                    advise.add(js);

                });
            }
            jsonObject.put("advice", advise);
            JSONArray quality = new JSONArray();
            List<MerchandiseQuality> meQualitys = merchandiseQuality.findByDeleted(false);
            if (!Regular.checkEmpty(meQualitys, null)) {
                meQualitys.stream().forEach(x -> {
                    JSONObject js = new JSONObject();
                    js.put("name", x.getQualityName());
                    js.put("id", x.getUuid());
                    Page<Merchandise> list = merchandiseDao.findMerchadiseAllByPage(merchandiseForm.getPage(), quality.size() == 3 ? null : 10, "", x.getUuid(), merchandiseForm.getSort(), merchandiseForm.getOrder(), merchandiseForm.getCateId(), merchandiseForm.getCatePar(), merchandiseForm.getMerId());
                   
                    JSONArray meArray = new JSONArray();
                    for (Iterator<Merchandise> i = list.iterator(); i.hasNext(); ) {
                        Merchandise mc = i.next();
                        JSONObject json = new JSONObject();
                        json.put("id", mc.getUuid());
                        json.put("logo", mc.getMerchLog());
                        json.put("name", mc.getMerchName());
                        json.put("area", mc.getMerchArea());
                        json.put("cateName", mc.getMerchBelogClass());
                        json.put("cateId", mc.getMerchanBelogCLassId());
                        json.put("activity", mc.getMerchActiveDes());
                        json.put("price", mc.getMerchPrice());
                        json.put("discount", mc.getMerchDisPrice());
                        meArray.add(json);

                    }
                    js.put("list", meArray);

                    quality.add(js);


                });

                jsonObject.put("quality", quality);


            }

        } else {


            //搜索中的分类
            List<MerchandiseCategory> byDeleted = autoTaskMerchandiseCatrgory.findByDeletedAndParentCate(false, true);

            JSONArray cateArr = new JSONArray();
            if (!Regular.checkEmpty(byDeleted, null)) {
                byDeleted.stream().forEach(x -> {
                    JSONObject js = new JSONObject();
                    js.put("name", x.getName());
                    js.put("id", x.getUuid());
                    cateArr.add(js);
                });
            }

            jsonObject.put("category", cateArr);

            Page<Merchandise> list = merchandiseDao.findMerchadiseAllByPage(merchandiseForm.getPage(), null, merchandiseForm.getWord(), merchandiseForm.getQuaId(), merchandiseForm.getSort(), merchandiseForm.getOrder(), merchandiseForm.getCateId(), merchandiseForm.getCatePar(), merchandiseForm.getMerId());


            JSONArray array = new JSONArray();
            JSONObject json;
            for (Merchandise mc : list) {
                if (mc == null) {
                    continue;
                }
                json = new JSONObject();
                json.put("id", mc.getUuid());
                json.put("logo", mc.getMerchLog());
                json.put("name", mc.getMerchName());
                json.put("area", mc.getMerchArea());
                json.put("price", mc.getMerchPrice());
                json.put("saleCount", mc.getMerchHaveSaleTotalCount());

                array.add(json);
            }
            jsonObject.put("list", array);
        }

        logger.info("商品的结束查询的接受实体类{}", merchandiseForm);
        return Response.success(jsonObject);
    }

    @Override
    public Response findCateGoryLists(String id) {

        if (Regular.checkEmpty(id, null)) {
            logger.warn("商品的一级分类Id为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        logger.info("商品的分类开始根据实体类 id={}", id);

        List<MerchandiseCategory> cateList = autoTaskMerchandiseCatrgory.findByDeletedAndParentCateAndParentUuid(false, false, id);
        JSONArray cateArr = new JSONArray();
        if (!Regular.checkEmpty(cateList, null)) {
            cateList.stream().forEach(x -> {
                JSONObject js = new JSONObject();
                js.put("name", x.getName());
                js.put("id", x.getUuid());
                js.put("jpg", x.getJpg());
                cateArr.add(js);
            });
        }

        logger.info("商品的分类结束根据实体类 id={}", id);
        return Response.success(cateArr);
    }

    @Override
    public Response queryMerchandiseSingle(String id) {
        if (Regular.checkEmpty(id, null)) {
            logger.warn("商品的Id为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        
        Merchandise merchandise = queryMerchandise.findByDeletedAndUuid(false, id);
        JSONObject jsonObject = new JSONObject();
        if (merchandise != null) {
           Merchandiser merchandiser = autoTaskMechandiser.findByDeletedAndUuid(false,merchandise.getMerchBelongToUuid());
            jsonObject.put("headPic", Regular.checkEmpty(merchandise.getHeadPics(), null) ? "" : merchandise.getHeadPics());
            jsonObject.put("name", Regular.checkEmpty(merchandise.getMerchName(), null) ? "" : merchandise.getMerchName());
            jsonObject.put("price", merchandise.getMerchPrice() == null ? "" : merchandise.getMerchPrice());
            jsonObject.put("transfer", Regular.checkEmpty(merchandise.getMechCarriageCate(), null) ? "" : merchandise.getMechCarriageCate());
            jsonObject.put("saleTotal", merchandise.getMerchHaveSaleTotalCount() == null ? "" : merchandise.getMerchHaveSaleTotalCount());
            jsonObject.put("saleMonth", merchandise.getMerchHaveSaleMonthCount() == null ? "" : merchandise.getMerchHaveSaleMonthCount());
            jsonObject.put("area", Regular.checkEmpty(merchandise.getMerchArea(), null) ? "" : merchandise.getMerchArea());
            jsonObject.put("advantage", Regular.checkEmpty(merchandise.getMerchHavDistange(), null) ? "" : merchandise.getMerchHavDistange());
            if (merchandiser == null) {
                logger.info("商品的商家为空 商家的Id={}", merchandise.getUuid());
                jsonObject.put("uuid", "");
                jsonObject.put("meName", "");
                jsonObject.put("meId", "");
                jsonObject.put("meHead", "");
                jsonObject.put("meTotalPro", "");
                jsonObject.put("meTotalTou", "");
                jsonObject.put("meGoodSco", "");
                jsonObject.put("meSalesSco", "");
                jsonObject.put("meCarrSco", "");
                jsonObject.put("mePhone", "");
            } else {
            	jsonObject.put("uuid", Regular.checkEmpty(merchandiser.getUuid(), null)?"":merchandiser.getUuid());
                jsonObject.put("meName", Regular.checkEmpty(merchandiser.getName(), null) ? "" : merchandiser.getName());
                jsonObject.put("meId", Regular.checkEmpty(merchandiser.getUuid(), null) ? "" : merchandiser.getUuid());
                jsonObject.put("meHead", Regular.checkEmpty(merchandiser.getHeadPic(), null) ? "" : merchandiser.getHeadPic());
                jsonObject.put("meTotalPro", merchandiser.getMerchTotalPro() == null ? "" : merchandiser.getMerchTotalPro());
                jsonObject.put("meTotalTou", merchandiser.getMerchTotalVIew() == null ? "" : merchandiser.getMerchTotalVIew());
                jsonObject.put("meGoodSco", merchandiser.getMerchGoodsDesScore() == null ? "" : merchandiser.getMerchGoodsDesScore());
                jsonObject.put("meSalesSco", merchandiser.getMerchSellerServScore() == null ? "" : merchandiser.getMerchSellerServScore());
                jsonObject.put("meCarrSco", merchandiser.getMerchLogisServScore() == null ? "" : merchandiser.getMerchLogisServScore());
                jsonObject.put("mePhone", Regular.checkEmpty(merchandiser.getPhone(), null) ? "" : merchandiser.getPhone());
            }

            jsonObject.put("artPic", Regular.checkEmpty(merchandise.getMerchantDetails(), null) ? "" : merchandise.getMerchantDetails());
            jsonObject.put("proParam", Regular.checkEmpty(merchandise.getMerchProParam(), null) ? "" : merchandise.getMerchProParam());

        }
        logger.info("商品的详情结束根据实体类 id={}", id);
        return Response.success(jsonObject);
        
    }

        

    
    @Override
    public Response loadMerchStandard(String merchUuid){
    	String pic = msr.loadMerchLogPic(merchUuid);
    	List<MerchandiseStandard> mslist = msr.loadMerchandiseStandard(merchUuid);
    	MerchandiseStandard ms = null;
    	if(mslist!=null&&mslist.size()>0){
    	ms = mslist.get(0);
    	}
    	if(ms!=null){
    		ms.setMerchLog(pic);
    	}
    	System.out.println("==============="+pic);
    	
    	return Response.success(ms);
    }
	@Override
	public Response collectionMerchandiseSingle(String uuid, String id) {
		  if (Regular.checkEmpty(id, null)) {
	            logger.warn("商品的Id为空");
	            return Response.response(ResponseType.EMPTY_CODE.getCode());
	        }
		  	Boolean n ;
		  	Boolean s = true;
		    List<Collection> collection = autoCollection.findByFatherIdAndUuidAndDeleted(uuid, id, false);
		    
		    if(Regular.checkEmpty(collection, null)){
		    	n = false;
		    }else{
		    	n = true;
		    }
		    
		    List<Merchandiser> list = merchandiserHome.findByDeletedAndUuid(false, id);
		    if(Regular.checkEmpty(list, null)){
		    	s = false;
		    }
		    
		    
		    
		    if(s){
				JSONObject json = new JSONObject();
		               for(Merchandiser md:list){
		            	   json.put("uid", Regular.checkEmpty(md.getUuid(),null)?"":md.getUuid());
		            	   json.put("headPic",Regular.checkEmpty(md.getHeadPic(), null)?"":md.getHeadPic());
		            	   json.put("name",Regular.checkEmpty(md.getName(),null)?"":md.getName());
		 	               String[] carrouselJpg = md.getCarrouselJpg().split(",");
		 	               json.put("carrouselJpg",Regular.checkEmpty(carrouselJpg, null)?"":carrouselJpg);
		 	               json.put("beanAmount", Regular.checkEmpty(md.getBeanAmount(),null)?0:md.getBeanAmount());
		 	               json.put("merchandiserRank",Regular.checkEmpty(md.getMerchandiserRank(), null)?"":md.getMerchandiserRank());
		 	               json.put("attention", Regular.checkEmpty(md.getAttention(), null)?0:md.getAttention());
		 	               json.put("merchTotalVIew", Regular.checkEmpty(md.getMerchTotalVIew(), null)?0:md.getMerchTotalVIew());
		 	               json.put("collection", n);
		 	             /*  advise.add(json);*/
		               }
		               
		                	logger.info("数据读取成功...");
						return Response.success(json);
		    	
		    	
		    }else{
	        Merchandise merchandise = queryMerchandise.findByDeletedAndUuid(false, id);
	        JSONObject jsonObject = new JSONObject();
	        if (merchandise != null) {
	           Merchandiser merchandiser = autoTaskMechandiser.findByDeletedAndUuid(false,merchandise.getMerchBelongToUuid());
	            jsonObject.put("headPic", Regular.checkEmpty(merchandise.getHeadPics(), null) ? "" : merchandise.getHeadPics());
	            jsonObject.put("name", Regular.checkEmpty(merchandise.getMerchName(), null) ? "" : merchandise.getMerchName());
	            jsonObject.put("price", merchandise.getMerchPrice() == null ? "" : merchandise.getMerchPrice());
	            jsonObject.put("transfer", Regular.checkEmpty(merchandise.getMechCarriageCate(), null) ? "" : merchandise.getMechCarriageCate());
	            jsonObject.put("saleTotal", merchandise.getMerchHaveSaleTotalCount() == null ? "" : merchandise.getMerchHaveSaleTotalCount());
	            jsonObject.put("saleMonth", merchandise.getMerchHaveSaleMonthCount() == null ? "" : merchandise.getMerchHaveSaleMonthCount());
	            jsonObject.put("area", Regular.checkEmpty(merchandise.getMerchArea(), null) ? "" : merchandise.getMerchArea());
	            jsonObject.put("advantage", Regular.checkEmpty(merchandise.getMerchHavDistange(), null) ? "" : merchandise.getMerchHavDistange());
	            jsonObject.put("collection",n);
	            if (merchandiser == null) {
	                logger.info("商品的商家为空 商家的Id={}", merchandise.getUuid());
	                jsonObject.put("meName", "");
	                jsonObject.put("meId", 0);
	                jsonObject.put("meHead", "");
	                jsonObject.put("meTotalPro", "");
	                jsonObject.put("meTotalTou", "");
	                jsonObject.put("meGoodSco", "");
	                jsonObject.put("meSalesSco", "");
	                jsonObject.put("meCarrSco", "");
	                jsonObject.put("mePhone", "");
	            } else {
	                jsonObject.put("meName", Regular.checkEmpty(merchandiser.getName(), null) ? "" : merchandiser.getName());
	                jsonObject.put("meId", Regular.checkEmpty(merchandiser.getUuid(), null) ? 0 : merchandiser.getUuid());
	                jsonObject.put("meHead", Regular.checkEmpty(merchandiser.getHeadPic(), null) ? "" : merchandiser.getHeadPic());
	                jsonObject.put("meTotalPro", merchandiser.getMerchTotalPro() == null ? "" : merchandiser.getMerchTotalPro());
	                jsonObject.put("meTotalTou", merchandiser.getMerchTotalVIew() == null ? "" : merchandiser.getMerchTotalVIew());
	                jsonObject.put("meGoodSco", merchandiser.getMerchGoodsDesScore() == null ? "" : merchandiser.getMerchGoodsDesScore());
	                jsonObject.put("meSalesSco", merchandiser.getMerchSellerServScore() == null ? "" : merchandiser.getMerchSellerServScore());
	                jsonObject.put("meCarrSco", merchandiser.getMerchLogisServScore() == null ? "" : merchandiser.getMerchLogisServScore());
	                jsonObject.put("mePhone", Regular.checkEmpty(merchandiser.getPhone(), null) ? "" : merchandiser.getPhone());
	            }

	            jsonObject.put("artPic", Regular.checkEmpty(merchandise.getMerchantDetails(), null) ? "" : merchandise.getMerchantDetails());
	            jsonObject.put("proParam", Regular.checkEmpty(merchandise.getMerchProParam(), null) ? "" : merchandise.getMerchProParam());

	        }
	        logger.info("商品的详情结束根据实体类 id={}", id);
	        return Response.success(jsonObject);
	        
	    }
	}

	@Override
	public Response selectRecommend(String name){
		String cc  = "%"+name+"%";
		List<Merchandise> merchandiseList = repositoryMerchandise.selectRecommend(cc);
		logger.info("参数name={}",name);
		if(Regular.checkEmpty(merchandiseList, null)){
			return Response.fail();
			
		}
		JSONObject json = new JSONObject();
		JSONArray add = new JSONArray();
		for(Merchandise merchandise:merchandiseList){
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("uuid",Regular.checkEmpty(merchandise.getUuid(), null)?"":merchandise.getUuid());
			jsonObject.put("merchName",Regular.checkEmpty(merchandise.getMerchName(), null)?"":merchandise.getMerchName());
			jsonObject.put("logo",Regular.checkEmpty(merchandise.getMerchLog(), null)?0:merchandise.getMerchLog());
			jsonObject.put("headPics", Regular.checkEmpty(merchandise.getHeadPics(), null)?"":merchandise.getHeadPics());
			jsonObject.put("merchHaveSaleTotalCount",Regular.checkEmpty(merchandise.getMerchHaveSaleTotalCount(), null)?0:merchandise.getMerchHaveSaleMonthCount());
			add.add(jsonObject);
		}
		json.put("merchandise", add);
		return Response.success(json);
	}
	
}
