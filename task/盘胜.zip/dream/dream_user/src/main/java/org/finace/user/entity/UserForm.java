package org.finace.user.entity;

/**
 * 前端参数接受
 * Created by Ness on 2016/12/15.
 */
public class UserForm {
    /**
     * 手机号或者邮箱或者第三方uuid
     */
    private String name;

    /**
     * 发送的验证码
     */
    private String code;


    /**
     * 密码
     */
    private String pass;


    /**
     * 发送类型  0 代表找回密码 1 代表修改密码 2 代表注册 3 代表更换手机号
     */
    private int type;

    /**
     * 用户的唯一标识
     */
    private String uid;


    /**
     * 快捷登录类型 0代表 qq 1代表 微信 2 代表 新浪微博
     */
    private Integer model;

    public final static int FIND_PASS = 0;
    public final static int REGISTER_NEW = 4;
    public final static int MODIFY_PHONE = 3;
    public final static int REGISTER_PASS = 2;
    public final static int SIMPLE_ACCESS = 1;
    //快捷登录
    public final static int QUICK_LOGIN = 4;
    
    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Integer getModel() {
        return model;
    }

    public void setModel(Integer model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return "UserForm{" +
                "name='" + name + '\'' +
                ", code='" + code + '\'' +
                ", pass='" + pass + '\'' +
                ", type=" + type +
                ", uid='" + uid + '\'' +
                ", model=" + model +
                '}';
    }
}
