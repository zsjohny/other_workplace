package org.finace.user.util.task;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandise;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface RepositoryMerchandise extends Repository<Merchandise,Integer>{
	
	@Query("select new Merchandise(uuid,merchName,merchLog,merchPrice,merchHaveSaleTotalCount) from Merchandise where merchName like :name ")
	List<Merchandise> selectRecommend(@Param("name")String name);

	@Query("select new Merchandise(uuid,merchName,merchLog,merchPrice,merchHaveSaleTotalCount) from Merchandise where merchName like :name and merchBelongToUuid=:merchBelongToUuid and deleted=:deleted")
	List<Merchandise> shopSearch(@Param("name")String name,@Param("merchBelongToUuid")String merchBelongToUuid,@Param("deleted")Boolean deleted);
}
