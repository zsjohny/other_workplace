package org.finace.user.util.service;

import org.finace.user.entity.MerchandiseForm;
import org.finace.utils.operate.Response;

public interface MerchandiserServer {

	
	Response findMerchadiseAllByPage(MerchandiseForm merchandiseForm,String extendsId,Boolean fatherIdOrSunId);
	}
