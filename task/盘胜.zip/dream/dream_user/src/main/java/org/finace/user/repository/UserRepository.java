	package org.finace.user.repository;


import org.finace.utils.entity.user.User;
import org.finace.utils.operate.Response;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

public interface UserRepository extends Repository<User, Integer> {

    @Query("select new User(uuid ,uid,pass,thirdQQPass,thirdWechatPass,thirdWeboPass,headPic,nickName) from  User where  (phone=:name or email=:name or thirdQQId=:name or thirdWechatId=:name or thirdWeBoId=:name  or name=:name  ) and deleted=false ")
    User findUUidAndPassByPhoneOrEmailOrThirdId(@Param("name") String name);

    @Query("select  new User(phone,pass) from  User where uuid=:uuid  and deleted=false ")
    User findPhoneAndPassByUuid(@Param("uuid") String uuid);

    @Modifying
    @Query("update  User set pass=:pass , updateTime=:updateTime  where  uuid=:uuid  and deleted=false ")
    void updatePassByUuid(@Param("pass") String pass, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);


    @Modifying
    @Query("update  User set phone=:phone ,pass=:pass , updateTime=:updateTime   where  uuid=:uuid   and deleted=false  ")
    void updatePhoneAndPassByUuid(@Param("phone") String phone, @Param("pass") String pass, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);


    @Modifying
    @Query("update  User set updateTime=:updateTime,uid=:uid,diviceType=:diviceType,cid=:cid  where  uuid=:uuid   and deleted=false  ")
    void updateTimeAndUidByUuid(@Param("updateTime") Date updateTime, @Param("uid") String uid,@Param("diviceType")String diviceType,@Param("cid")String cid, @Param("uuid") String uuid);

    @Modifying
    @Query("update  User set updateTime=:updateTime ,  deleted=true    where  uuid=:uuid   and deleted=false  ")
    void removeUserByUuid(@Param("updateTime") Date updateTime, @Param("uuid") String uuid);

    @Modifying
    @Query("update  User set headPic=:headPic ,updateTime=:updateTime   where  uuid=:uuid   and deleted=false  ")
    void updateHeadPicByUuid(@Param("headPic") String headPic, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);

    @Modifying
    @Query("update  User set nickName=:nickName ,updateTime=:updateTime   where  uuid=:uuid   and deleted=false  ")
    void updateNickNameByUuid(@Param("nickName") String nickName, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);


    @Modifying
    @Query("update  User set thirdQQId=:thirdQQId ,updateTime=:updateTime   where  uuid=:uuid   and deleted=false  ")
    void updateThirdQQIdByUuid(@Param("thirdQQId") String thirdQQId, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);


    @Modifying
    @Query("update  User set thirdWechatId=:thirdWechatId ,updateTime=:updateTime   where  uuid=:uuid   and deleted=false  ")
    void updateThirdWechatIdByUuid(@Param("thirdWechatId") String thirdWechatId, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);

    @Modifying
    @Query("update  User set thirdWeBoId=:thirdWeBoId ,updateTime=:updateTime   where  uuid=:uuid   and deleted=false  ")
    void updateThirdWeBoIdIdByUuid(@Param("thirdWeBoId") String thirdWeBoId, @Param("updateTime") Date updateTime, @Param("uuid") String uuid);

    @Modifying
    @Query("update User set money=:money where uuid=:uuid")
    int updateSubtractMoney(@Param("money") Double money, @Param("uuid") String uuid);

    @Modifying
    @Query("update User set thirdQQId= null where uuid=:uuid")
    void updateBound(@Param("uuid")String uuid);
    
    
}
