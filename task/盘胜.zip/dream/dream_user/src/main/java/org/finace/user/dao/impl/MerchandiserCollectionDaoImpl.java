package org.finace.user.dao.impl;

import java.util.List;

import org.finace.user.dao.MerchandiserCollectionDao;
import org.finace.user.repository.MerchandiserCollectionRepository;
import org.finace.user.repository.MerchandiserCrudRepository;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MerchandiserCollectionDaoImpl implements MerchandiserCollectionDao{
	
	@Autowired
	MerchandiserCollectionRepository mcr;
	
	@Autowired
	MerchandiserCrudRepository MerchandiserCR;

	@Override
	public List<Merchandiser> selectMerchandiser(String uuid) {
		return mcr.selectMerchandiser(uuid);
	}

	@Override
	public void addMerchandiser(Merchandiser merchandiser) {
		MerchandiserCR.save(merchandiser);
	}

	@Override
	public List<Merchandiser> selectAttention(String uuid) {
		return mcr.selectAttention(uuid);
	}

	@Override
	public void updateAttention(Integer attention, String uuid) {
		mcr.updateAttention(attention, uuid);
	}

}
