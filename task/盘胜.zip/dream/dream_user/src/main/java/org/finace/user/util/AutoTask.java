package org.finace.user.util;


import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.finace.user.util.task.AutoMerchandiseAdvice;
import org.finace.user.util.task.AutoMerchandiseQuality;
import org.finace.user.util.task.AutoMerchandiseStander;
import org.finace.user.util.task.AutoTaskMechandise;
import org.finace.user.util.task.AutoTaskMechandiser;
import org.finace.user.util.task.AutoTaskMerchandiseCatrgory;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.merchandise.MerchandiseAdvertise;
import org.finace.utils.entity.merchandise.MerchandiseCategory;
import org.finace.utils.entity.merchandise.MerchandiseQuality;
import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.prop.DataProperties;
import org.finace.utils.screct.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Ness on 2016/12/18.
 */
@Component
public class AutoTask {
    @Autowired
    private DataProperties dataProperties;
    @Autowired
    private AutoTaskMerchandiseCatrgory autoTaskMerchandiseCatrgory;
    @Autowired
    private AutoTaskMechandise autoTaskMechandise;
    @Autowired
    private AutoTaskMechandiser autoTaskMechandiser;
    @Autowired
    private AutoMerchandiseQuality autoMerchandiseQuality;
    @Autowired
    private AutoMerchandiseAdvice autoMerchandiseAdvice;
    @Autowired
    private AutoMerchandiseStander autoMerchandiseStander;
   /* @Autowired
    private AutoSiteProvince autoSiteProvince;
    @Autowired
    private AutoSiteCity autoSiteCity;
    @Autowired
    private AutoSiteArea autoSieArea;*/
    

//    @Autowired
//    private QueryMerchandiserRepository queryMerchandiserRepository;

    @PostConstruct
    public void init() throws Exception {

        if (dataProperties.getProperty("autoTask") != null) {
//            List<Merchandiser> merchandisers = queryMerchandiserRepository.finadALl();
//            System.out.println(merchandisers);
         /*   //autoMerchandiseStander();
            Merchandiser m = new Merchandiser();
            m.setFatherId(new String[]{"1", "2"});
            m.setSunId(new String[][]{{"1", "2"}});
            autoTaskMechandiser.save(m);
            System.out.println("__________________________________");
            System.out.println("__________________________________");
            System.out.println("__________________________________");
            System.out.println("__________________________________");
            System.out.println("__________________________________");
*/
            return;
        }
        autoMerchandiseAdvice();
        TimeUnit.SECONDS.sleep(2);
        autoMerchandiseCategory();
        TimeUnit.SECONDS.sleep(2);
        autoMerchandiseQuality();
        TimeUnit.SECONDS.sleep(2);
        autoMerchandiser();
        TimeUnit.SECONDS.sleep(2);
        autoMerchandise();
        TimeUnit.SECONDS.sleep(2);
        autoMerchandiseStander();
    }


    private void autoMerchandiseStander() {
        for (int i = 0; i < 5; i++) {

            String[] topCate = new String[]{

                    "颜色", "尺寸"

            };
            String[][] secCate = new String[][]{

                    new String[]{
                            "黑色", "白色", "绿色"
                    },
                    new String[]{
                            "s", "m", "xl", "3xl"
                    },
            };
            String[][] priceCate = new String[][]{

                    new String[]{
                            "65", "80", "90", "0"
                    },
                    new String[]{
                            "50", "60", "70", "80"
                    },
                    new String[]{
                            "50", "60", "70", "80"
                    },

            };
            String[][] stockCate = new String[][]{

                    new String[]{
                            "100", "200", "400", "0"
                    },
                    new String[]{
                            "400", "500", "0", "300"
                    },
                    new String[]{
                            "400", "500", "200", "300"
                    },
            };
            MerchandiseStandard mc = new MerchandiseStandard();

            mc.setTopCategoryName(topCate);
            mc.setSecondCateGoryName(secCate);
            mc.setPrices(priceCate);
            mc.setStocks(stockCate);
            mc.setUuid(UserUtils.generateIncrementId());
            mc.setCreateTime(new Date());
            mc.setDeleted(false);
            autoMerchandiseStander.save(mc);
        }
    }


    public void autoMerchandiseAdvice() {
        String[] advise = new String[]{
                "http://pic39.nipic.com/20140314/6640712_200101646135_2.jpg", "http://pic.58pic.com/58pic/12/15/14/93958PICMxh.jpg", "http://zunmi.com/uploads/allimg/121231/20124-1212310R1113E.jpg"
                , "http://e.hiphotos.baidu.com/image/pic/item/94cad1c8a786c917139f2a9ccb3d70cf3ac757f2.jpg", "http://c.hiphotos.baidu.com/image/pic/item/03087bf40ad162d960aed9aa14dfa9ec8b13cdc0.jpg"
                , "http://c.hiphotos.baidu.com/image/pic/item/203fb80e7bec54e73cb95b96bb389b504ec26ae4.jpg"
        };
        MerchandiseAdvertise advertise;
        for (int i = 0; i < 5; i++) {
            advertise = new MerchandiseAdvertise();
            advertise.setUuid(UserUtils.generateIncrementId());
            advertise.setCreateTime(new Date());
            advertise.setDeleted(false);
            advertise.setAdviseUrl(advise[i]);
            advertise.setAdviseLink("http://www.baidu.com");
            autoMerchandiseAdvice.save(advertise);
        }
    }


    private String[] chilId = new String[]{
            "护肤", "彩妆/香水", "个人护理/美容工具",
            "保健品", "进口食品", "饮料酒水",
            "宝宝食品", "宝宝服饰/玩具", "宝宝洗护", "孕产妇用品",
            "女装/女士内衣", "男装/男士内衣", "饰品/手表", "箱包/鞋靴", "运动户外",
            "家用电器", "数码音响", "家居生活", "厨房餐具/烹饪用具",
            "美食", "酒店", "KTV", "电影院", "电影院", "休闲娱乐", "运动健身", "丽人", "购物", "亲子", "学习培训", "婚庆", "爱车生活", "宠物", "进口商城"
    };
    private String[] childCateId = new String[34];


    private String[] cateGoryId = new String[3];
    private String[] parentId = new String[5];

    private String[] cateGory = new String[]{
            "伸手党", "精美搭配", "热门精选"
    };

    public void autoMerchandiseQuality() {

        MerchandiseQuality merchandiseQuality;
        for (int i = 0; i < cateGory.length; i++) {
            merchandiseQuality = new MerchandiseQuality();
            merchandiseQuality.setUuid(UserUtils.generateIncrementId());
            cateGoryId[i] = merchandiseQuality.getUuid();
            merchandiseQuality.setCreateTime(new Date());
            merchandiseQuality.setDeleted(false);
            merchandiseQuality.setQualityName(cateGory[i]);
            autoMerchandiseQuality.save(merchandiseQuality);
        }
    }

    private Map<String, String> childMap = new HashMap<>();

    public void autoMerchandiseCategory() {
        MerchandiseCategory mc;


        String[] parentCate = new String[]{
        		
                "美妆护肤", "食品保健", "服饰鞋包", "生活数码", "本地商城"
                
        };

        for (int i = 0; i < parentCate.length; i++) {
            mc = new MerchandiseCategory();
            mc.setUuid(UserUtils.generateIncrementId());
            mc.setName(parentCate[i]);
            mc.setParentCate(true);
            parentId[i] = mc.getUuid();
            mc.setParentUuid(parentId[i]);
            mc.setCreateTime(new Date());
            mc.setDeleted(false);
            autoTaskMerchandiseCatrgory.save(mc);
        }
        int k = 0;
        String childId;
        for (int i = 0; i < 34; i++) {
            if (i == 2) {
                k++;
            } else if (i == 5) {
                k++;
            } else if (i == 14) {
                k++;
            } else if (i == 18) {
                k++;
            } else if (i == 14) {
                k++;
            }
            mc = new MerchandiseCategory();
            childId = UserUtils.generateIncrementId();
            childCateId[i] = childId;

            mc.setUuid(childId);
            mc.setName(chilId[i]);
            mc.setParentCate(false);
            mc.setParentUuid(parentId[k]);
            childMap.put(childId, parentId[k]);
            mc.setCreateTime(new Date());
            mc.setDeleted(false);
            autoTaskMerchandiseCatrgory.save(mc);
            
        }

    }
    public void autoMerchandise() throws InterruptedException {
        Merchandise created ;
        Random cateRadom = new Random();
        for (int i = 0; i < 1000; i++) {
            created = new Merchandise();
            created.setMerchLog("http://sucai.dabaoku.com/meishu/logo/077cy.jpg");
            String[] add = new String[]{"http://d6.yihaodianimg.com/N01/M09/A5/3D/CgQCrlM-UFuAYSsKAAFpx8NllHE13901.jpg", "http://tgi12.jia.com/116/307/16307875.jpg"};
            created.setUuid(UserUtils.generateIncrementId());
            created.setHeadPics(add);
            created.setMerchName("随机生成名字" + i);
            created.setMerchBelongToUuid(merchandiserId[cateRadom.nextInt(9)]);
            int id = cateRadom.nextInt(34);
            created.setMerchBelogClass(chilId[id]);
            created.setMerchaBelogClassParentId(childCateId[id]);
            created.setMerchanBelogCLassId(childMap.get(childCateId[id]));
            created.setMerchIsNew("新产品");
            int key = cateRadom.nextInt(3);
            created.setMerchQuality(cateGory[key]);
            created.setMerchQualityId(cateGoryId[key]);
            created.setMerchPrice(9999.00);
            created.setMerchDisPrice(7999.00);
            created.setMerchHaveSaleTotalCount(99);
            created.setMerchHaveSaleMonthCount(77);
            created.setMerchArea("东莞");
            created.setMerchAreaDistId("79055");
            created.setMerchHavDistange(new String[]{"耐用", "好用", "多用"});
            created.setMerchProParam("非常可以");
            created.setMerchantDetails(new String[]{"http://pic87.nipic.com/file/20160114/17532527_080249767002_2.jpg", "http://img2.ooopic.com/15/49/63/32bOOOPIC4d_202.jpg"});
            created.setMerchActiveDes("开业大酬宾");
            created.setCreateTime(new Date());
            created.setDeleted(false);
            created.setBuyNNT(2500);
            autoTaskMechandise.save(created);
            TimeUnit.MICROSECONDS.sleep(2);
        }
        


    }

    private String[] merchandiserId = new String[10];

    public void autoMerchandiser() {
        Merchandiser seller;
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            seller = new Merchandiser();
            seller.setHeadPic("http://sucai.dabaoku.com/meishu/logo/077cy.jpg");
          /*  String[] add = new String[]{"https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1486203484&di=b830b4df0c12a1f4005bc64e89604ba7&src=http://p.store.itangyuan.com/p/book/cover/egIve_fSEf/EgfV4BbsEg2vE_-sEg-UElut46DqgbqHjS.jpg","https://timgsa.baidu.com/timg?image&quality=80&size=b10000_10000&sec=1486204998&di=3ac84607d69bbc1869502d9a4b1da944&src=http://pic1.win4000.com/mobile/d/527a082c859bc.jpg","https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1486205047&di=10facda323150721a2997f23de5a3a72&src=http://img3.duitang.com/uploads/item/201301/30/20130130133444_crw2G.thumb.700_0.jpeg"};
            seller.setCarrouselJpg(add);*/
            seller.setCarrouselJpg("https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1486203484&di=b830b4df0c12a1f4005bc64e89604ba7&src=http://p.store.itangyuan.com/p/book/cover/egIve_fSEf/EgfV4BbsEg2vE_-sEg-UElut46DqgbqHjS.jpg");
            seller.setUuid(UserUtils.generateIncrementId());
            merchandiserId[i] = seller.getUuid();
            seller.setName("百家旺" + i);
            seller.setMerchTotalPro(200);
            seller.setMerchTotalVIew(6000l);
            seller.setMerchGoodsDesScore(9.0);
            seller.setMerchSellerServScore(4.0);
            seller.setMerchLogisServScore(10.0);
            seller.setMerchHaveTotalRemark(6000l);
            seller.setPhone("13956368936");
            seller.setCreateTime(new Date());
            seller.setDeleted(false);
            autoTaskMechandiser.save(seller);
            	
            }
            
            
            int l = random.nextInt(5);
            String[] c = new String[]{parentId[l]};
            c.toString();
           /* seller.setFatherId();*/
            int randCount = random.nextInt(10)+1;
            int len = 0;
            String[] sId = new String[randCount];
            while (len == randCount) {
                int k = random.nextInt(35);
                if (k <= 2 && l == 0 || k <= 5 && l == 1 || k <= 14 && l == 2 || k <= 18 && l == 3 || k <= 14 && l == 4) {
                    sId[len] = chilId[k];
                    len++;
                }

            }
            /*seller.setSunId(sId)*/;

        }


    /*Integer[] Province = new Integer[34];*/
    
    
  /*  public void autoProvince(){
    	
    	Province province ;
    	
    	String[] provinceString = new String[]{"北京市","天 津市","上海市","重庆市","河北省","山西省","辽宁省","吉林省","黑龙江省","江苏省",
    			"浙江省","安徽省","福建省","台湾省","江西省","山东省","河南省","湖北省","湖南省","广东省",
    			"海南省","四川省","贵州省","云南省","陕西省","甘肃省","青海省","内蒙古自治区","广西壮族自治区","西藏自治区",
    			"宁夏回族自治区","新疆维吾尔自治区","香港特别行政区","澳门特别行政区",};
    	
    	for(int i = 0; i<provinceString.length ; i++ ){
    		province = new Province();
    		province.setProvince(provinceString[i]);
    		province.setProvinceID(province.getId());
    		autoSiteProvince.save(province);
    	}
    }
    
    public void autoCity(){
    	City city ;
    	
    	String[] cityString = new String[]{

    	};
    }
    
    public void autoArea(){
    	
    }
    */
    
    public static void main(String[] args) {
        Random random = new Random();
        while (true)
        {
            System.out.println(random.nextInt(6));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


}
