package org.finace.user.repository;

import org.finace.utils.entity.user.Address;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface AddressCrudRepository extends CrudRepository<Address,Integer>{
	
	
	
	/*@Query("select addressName from Address where fatherId=:fatherId and addressName=:addressName and addressPhone=:addressPhone and addressSite=:addressSite and addressMinute=:addressMinute and defaultSite=:defaultSite deleted=:deleted siteId=:siteId")
	List<Address> selectAddress(@Param("fatherId")String fatherId, @Param("addressName")String addressName,@Param("addressPhone") String addressPhone,@Param("addressSite") String[] addressSite,
			@Param("addressMinute")String addressMinute,@Param("defaultSite") boolean defaultSite,@Param("deleted") Boolean deleted, @Param("siteId")byte[] siteId);*/
	@Query("select siteId from Address where fatherId='612803130e4658a62fce5acc89084969597156dd6'")
	Object[] selectSiteId();
	@Modifying
	@Query("delete from Address where uuid=:uuid")
	int deleteAddress(@Param("uuid")String uuid);
	
}
