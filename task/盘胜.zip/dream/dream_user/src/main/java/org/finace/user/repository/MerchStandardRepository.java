package org.finace.user.repository;

import java.util.List;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.finace.utils.entity.user.Province;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface MerchStandardRepository extends Repository<Province, Integer>{
	@Query("select merchLog from Merchandise where uuid=:uuid")
	String loadMerchLogPic(@Param("uuid") String uuid);
	
	@Query("from MerchandiseStandard m where merchUuid=:merchUuid and deleted=false")
	List<MerchandiseStandard> loadMerchandiseStandard(@Param("merchUuid")String merchUuid);

}
