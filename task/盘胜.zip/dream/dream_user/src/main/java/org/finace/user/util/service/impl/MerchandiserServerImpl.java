package org.finace.user.util.service.impl;

import java.util.List;

import org.finace.user.entity.MerchandiseForm;
import org.finace.user.util.dao.MerchandiserDao;
import org.finace.user.util.service.MerchandiserServer;
import org.finace.user.util.task.AutoTaskMechandise;
import org.finace.user.util.task.AutoTaskMechandiser;
import org.finace.user.util.task.AutoTaskMerchandiseCatrgory;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.merchandise.MerchandiseCategory;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Service
@Transactional
public class MerchandiserServerImpl implements MerchandiserServer{
		@Autowired
	    private MerchandiserDao merchandiserDao;

		@Autowired
		private AutoTaskMerchandiseCatrgory autoTaskMerchandiseCatrgory;

		@Autowired
		private AutoTaskMechandise autoTaskMechandise;
		
		@Autowired
		private AutoTaskMechandiser autoTaskMechandiser;

	    private Logger logger = LoggerFactory.getLogger(MerchandiserServerImpl.class);
	 

	    public Response findMerchadiseAllByPage(MerchandiseForm merchandiseForm,String extendsId,Boolean fatherIdOrSunId) {

	    		JSONObject jsonObject = new JSONObject();
	    		
	            JSONArray advise = new JSONArray();
	            
	            Page<Merchandiser> list = merchandiserDao.findMerchadiseAllByPage(merchandiseForm.getPage(),merchandiseForm.getSort(), "", null, merchandiseForm.getSort(), merchandiseForm.getOrder(), merchandiseForm.getCateId(), merchandiseForm.getCatePar(), merchandiseForm.getMerId());
              
	            if(!(extendsId==null)){
            	if(fatherIdOrSunId){
            		//来取出根据分类能取出多少商品
            		List<Merchandise> merchandiseList = autoTaskMechandise.findByDeletedAndMerchanBelogCLassId(false,extendsId);
            		for(Merchandise merchandise:merchandiseList){
            			for(Merchandiser merchandiser:autoTaskMechandiser.findByUuidAndDeleted(merchandise.getMerchBelongToUuid(),false)){
            				JSONObject json = new JSONObject();
    					  
            				/*卖家uid*/
    					   
            				json.put("id",Regular.checkEmpty(merchandiser.getUuid(), null)?"":merchandiser.getUuid());
    					  
	    					  /*卖家头像*/
	    					   
	    					  json.put("headPic",Regular.checkEmpty(merchandiser.getHeadPic(),null)?"":merchandiser.getHeadPic());
	    					  
	    					   /*卖家名字*/
	    					   
	    					  json.put("name", Regular.checkEmpty(merchandiser.getName(), null)?"":merchandiser.getName());
	    					  
	    					  /*拥有的好评数*/
	    					   
	    					  json.put("merchReceivedSeveral", Regular.checkEmpty(merchandiser.getMerchReceivedSeveral(),null)?0:merchandiser.getMerchReceivedSeveral());
	    					  
	    					   /*销售量*/
	    					   
	    					  json.put("salesVolume",Regular.checkEmpty(merchandiser.getSalesVolume(),null)?0:merchandiser.getSalesVolume());
	    					  
	    					  advise.add(json);
            				}
	                	}
            	}else{
            		List<Merchandise> merchandiseList = autoTaskMechandise.findByDeletedAndMerchaBelogClassParentId(false, extendsId);
            		for(Merchandise merchandise:merchandiseList){
            			for(Merchandiser merchandiser:autoTaskMechandiser.findByUuidAndDeleted(merchandise.getMerchBelongToUuid(),false)){
            				JSONObject json = new JSONObject();
    					  
            				/*卖家uid*/
    					   
            				json.put("id",Regular.checkEmpty(merchandiser.getUuid(), null)?"":merchandiser.getUuid());
    					  
	    					  /*卖家头像*/
	    					   
	    					  json.put("headPic",Regular.checkEmpty(merchandiser.getHeadPic(),null)?"":merchandiser.getHeadPic());
	    					  
	    					   /*卖家名字*/
	    					   
	    					  json.put("name", Regular.checkEmpty(merchandiser.getName(), null)?"":merchandiser.getName());
	    					  
	    					  /*拥有的好评数*/
	    					   
	    					  json.put("merchReceivedSeveral", Regular.checkEmpty(merchandiser.getMerchReceivedSeveral(),null)?0:merchandiser.getMerchReceivedSeveral());
	    					  
	    					   /*销售量*/
	    					   
	    					  json.put("salesVolume",Regular.checkEmpty(merchandiser.getSalesVolume(),null)?0:merchandiser.getSalesVolume());
	    					  
	    					  advise.add(json);
            				}
	                	}
            		}
	        }else{
	        	for(Merchandiser merchandiser:list){
	        		
	        		JSONObject json = new JSONObject();
	        		 /*卖家uid*/
					   
					  json.put("id",Regular.checkEmpty(merchandiser.getUuid(), null)?"":merchandiser.getUuid());
					  
					  /*卖家头像*/
					   
					  json.put("headPic",Regular.checkEmpty(merchandiser.getHeadPic(),null)?"":merchandiser.getHeadPic());
					  
					   /*卖家名字*/
					   
					  json.put("name", Regular.checkEmpty(merchandiser.getName(), null)?"":merchandiser.getName());
					  
					  /*拥有的好评数*/
					   
					  json.put("merchReceivedSeveral", Regular.checkEmpty(merchandiser.getMerchReceivedSeveral(),null)?0:merchandiser.getMerchReceivedSeveral());
					  
					   /*销售量*/
					   
					  json.put("salesVolume",Regular.checkEmpty(merchandiser.getSalesVolume(),null)?0:merchandiser.getSalesVolume());
					  
					  advise.add(json);
	        	}
	        	
	        }
        //搜索中的分类
        List<MerchandiseCategory> byDeleted = autoTaskMerchandiseCatrgory.findByDeletedAndParentCate(false, true);

        JSONArray cateArr = new JSONArray();
        if (!Regular.checkEmpty(byDeleted, null)) {
            byDeleted.stream().forEach(x -> {
                JSONObject json = new JSONObject();
                json.put("classifyName", x.getName());
                json.put("id", x.getUuid());
                cateArr.add(json);
            	});
        	}
        	jsonObject.put("advice", advise);
        	jsonObject.put("category", cateArr);
	            return Response.success(jsonObject);
	        }
		}
            	  
