package org.finace.user.entity;

/**
 * User个人信息加载
 * Created by Ness on 2016/12/15.
 */
public class UserInfoForm {

    /**
     * 头像地址
     */
    private String headPic;

    /**
     * 昵称信息
     */
    private String nickName;


    /**
     * 自己的Uuid
     */
    private String uuid;

    /*
    *第三方Uuid
     */
    private String thirdUuid;

    /**
     * 快捷登录类型 0代表 qq 1代表 微信 2 代表 新浪微博
     */
    private Integer model;

    public String getThirdUuid() {
        return thirdUuid;
    }

    public void setThirdUuid(String thirdUuid) {
        this.thirdUuid = thirdUuid;
    }

    public Integer getModel() {
        return model;
    }

    public void setModel(Integer model) {
        this.model = model;
    }

    public String getHeadPic() {
        return headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

}
