package org.finace.user.util.dao;

import org.finace.utils.entity.merchandise.Merchandise;
import org.springframework.data.domain.Page;

/**
 * Created by Ness on 2016/12/18.
 */
public interface MerchandiseDao {

     Page<Merchandise> findMerchadiseAllByPage(Integer page, Integer pageCount,String word,String qualityId,  Integer sort, Integer order, String cateGoryId,Boolean isCateParent,String merchadiseId);

}
