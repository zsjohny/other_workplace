package org.finace.user.service.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.finace.user.dao.AddressDao;
import org.finace.user.repository.AddressCrudRepository;
import org.finace.user.repository.AreaRepository;
import org.finace.user.repository.CityRepository;
import org.finace.user.repository.ProvinceRepository;
import org.finace.user.service.AddressServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.conver.DataConverUtils;
import org.finace.utils.entity.user.Address;
import org.finace.utils.entity.user.City;
import org.finace.utils.enums.LockType;
import org.finace.utils.enums.NotifyType;
import org.finace.utils.enums.ResponseType;
import org.finace.utils.lock.Lock;
import org.finace.utils.operate.Response;
import org.finace.utils.prop.DataProperties;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Transactional
@Service
public class AddressServerImpl implements AddressServer{

	@Autowired
	AddressDao addressDao;
	
	@Autowired
	CacheTemplete cacheTemplete;
	
	@Autowired
	DataProperties dataProperties;
	
	@Autowired
	ProvinceRepository provinceRepository;
	
	@Autowired
	AreaRepository areaRepository;
	
	@Autowired
	CityRepository cityRepository;
	
	@Autowired
	AddressCrudRepository acr;
	
	@Autowired
	Lock lock;
	
	private Logger logger = LoggerFactory.getLogger(AddressServerImpl.class);
	/**
	 * 
	 * @param fatherid  用户的uid
	 * @param addressName  收货人姓名
	 * @param addressPhone  手机
	 * @param site 省市区 地址，中间用英文逗号间隔
	 * @param addressMinute 街道，门牌号等
	 * @param defaultSite 是否是默认地址
	 * @param siteId 省市区id
	 * @return  添加收货地址的
	 */
	@Override
	public Response addAddress(String fatherId,String addressName,String addressPhone,String site,String addressMinute,boolean defaultSite,String[] siteId) {
		if(fatherId == null){
			logger.warn("传入的用户uuid为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(addressName == null){
			logger.warn("传入的addressName为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(addressPhone == null){
			logger.warn("传入的addressPhone为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(site == null){
			logger.warn("传入的site为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(addressMinute == null){
			logger.warn("传入的addressMinute为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		if(siteId == null){
			logger.warn("传入的siteId为空！");
			return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		
		if(Regular.checkPhone(addressPhone)){
			JSONObject jsonObject = new JSONObject();
			
			Address address = new Address();
			
			address.setFatherId(fatherId);
			
			address.setAddressName(addressName);
			
			address.setAddressPhone(addressPhone);
			
			String[] addressSite = site.split(",");
			
			address.setAddressSite(addressSite);
			
			byte[] siteByte = DataConverUtils.stringArr2ByteArr(siteId);
			
			address.setSiteId(siteByte);
			
			address.setUuid(UserUtils.generateUUid());
			
			address.setDeleted(false);
			
			address.setCreateTime(Timestamp.from(Instant.now()));
			
			if(defaultSite){
				addressDao.updateDefaultSite(fatherId);
				address.setDefaultSite(true);
			}
			
			address.setAddressMinute(addressMinute);
			
			logger.info("地址正在注册...");
			
			
			String currentTime  = "";
			try{
			while(!lock.lock(LockType.ADDRESS_ADD_LOCK,site)){
			}
			currentTime = lock.getLock(LockType.ADDRESS_ADD_LOCK,site);
			acr.save(address);
			logger.info("地址注册成功...");
			}finally {
				lock.unLock(LockType.ADDRESS_ADD_LOCK,site,currentTime);
			}
		
		jsonObject.put("type", Regular.checkEmpty(address, null) ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(jsonObject);
		}
		return Response.error();
	}
	/**
	 * uuid  需要改的uuid
	 */
	@Override
	public Response deletedAddress(String uuid) {
		JSONObject jsonObject = new JSONObject();
		boolean addressSwitch = uuid!=null;
			logger.info("地址删除中...");
			acr.deleteAddress(uuid);
			logger.info("地址删除成功...");
		jsonObject.put("type", addressSwitch ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(jsonObject);
	}
	
	/**
	 * 
	 * @param fatherid  用户的uid
	 * @param addressName  收货地址名字
	 * @param addressPhone  收货手机
	 * @param site 省市区 地址，中间用英文逗号间隔
	 * @param addressMinute 详细地址
	 * @param defaultSite 默认地址
	 * @param siteId 收货地址ID
	 * @return  添加收货地址的
	 */
	@Override
	public Response updateAddress(String fatherId,String uuid,String addressName,String addressPhone,String site,String addressMinute,Boolean defaultSite,String[] siteId) {
		JSONObject jsonObject = new JSONObject();
		boolean addressSwitch =uuid!=null;
			logger.info("地址修改中...");
			String[] addressSite = site.split(",");
			Address address = new Address();
			if(defaultSite){
				addressDao.updateDefaultSite(fatherId);
				address.setDefaultSite(defaultSite);
				address.setUuid(uuid);
				address.setAddressName(addressName);
				address.setAddressPhone(addressPhone);
				address.setAddressSite(addressSite);
				byte[] siteByte = DataConverUtils.stringArr2ByteArr(siteId);
				if(siteByte==null){
					return Response.fail();
				}else{
					address.setSiteId(siteByte);
				}
				address.setAddressMinute(addressMinute);
				address.setUpdateTime(Timestamp.from(Instant.now()));
				address.setSiteId(DataConverUtils.stringArr2ByteArr(siteId));
				addressDao.updateAddress(address, uuid);
			}else{
			address.setDefaultSite(defaultSite);
			address.setUuid(uuid);
			address.setAddressName(addressName);
			address.setAddressPhone(addressPhone);
			address.setAddressSite(addressSite);
			byte[] siteByte = DataConverUtils.stringArr2ByteArr(siteId);
			if(siteByte==null){
				return Response.fail();
			}else{
				address.setSiteId(siteByte);
			}
			address.setAddressMinute(addressMinute);
			address.setUpdateTime(Timestamp.from(Instant.now()));
			addressDao.updateAddress(address, uuid);
			}
			logger.info("地址修改成功...");
			jsonObject.put("type", addressSwitch ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(jsonObject);
	}
	
	/**
	 * fatherId 用户Id
	 */
	@Override
	public Response selectAddress(String fatherId) {
		JSONObject json = new JSONObject();
		boolean addressSwitch = fatherId!=null;
		JSONArray jsarr = new JSONArray();
		if(!Regular.checkEmpty(addressDao.selectAddress(fatherId), null)){
			for(Address address: addressDao.selectAddress(fatherId)){
				JSONObject  jsonObject = new JSONObject();
				jsonObject.put("uuid", Regular.checkEmpty(address.getUuid(), null)?"":address.getUuid());
				jsonObject.put("addresName", Regular.checkEmpty(address.getAddressName(), null)?"":address.getAddressName());
				jsonObject.put("addressPhone",Regular.checkEmpty(address.getAddressPhone(), null)?"":address.getAddressPhone());
				jsonObject.put("addressSite",Regular.checkEmpty(address.getAddressSite(),null)?"":address.getAddressSite());
				jsonObject.put("addressMinute", Regular.checkEmpty(address.getAddressMinute(), null)?"":address.getAddressMinute());
				jsonObject.put("defaultSite",address.isDefaultSite()?true:"{}");
				String[] nu = DataConverUtils.byteArr2StringArr(address.getSiteId());
				if(nu==null){
					continue;
				}
				for(int i =0;i<nu.length;i++){
					
					if(nu[i]==null){
						continue;
					}
					jsonObject.put("siteId"+i,nu[i]);
				}
				
				jsarr.add(jsonObject);
			}
			json.put("select",jsarr);
		}
		json.put("type", addressSwitch ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(json);
	}
	/**
	 * 查询省
	 */
	@Override
	public Response selectProvince() {
		JSONObject jsonObject = new JSONObject();
		String[] province = addressDao.selectProvince();
		logger.info("正在获取省。。。");
		jsonObject.put("province",province);
		jsonObject.put("type", jsonObject!=null ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(jsonObject);
	}
	/**
	 * 查询市
	 * province 省
	 */
	@Override
	public Response selectCity(String province) {
		JSONObject jsonObject = new JSONObject();
		/*
		 * 缓存区
		 */
		//-------------------------------
		String[] city = addressDao.selectCity(province);
		cacheTemplete.setCacheForSerialize("CacheCity",city);
		String[] cacheCity = (String[]) cacheTemplete.getCacheForSerialize("CacheCity");
		//-------------------------------
		logger.info("正在获取市。。。");
		jsonObject.put("city",cacheCity);
		jsonObject.put("type", jsonObject!=null ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(jsonObject);
	}
	/**
	 * 查询区
	 * city  市
	 */
	@Override
	public Response selectArea(String city) {
		JSONObject jsonObject = new JSONObject();
		String[] area = addressDao.selectArea(city);
		/*
		 * 缓存区
		 */
		//-------------------------------
		cacheTemplete.setCacheForSerialize("CacheArea",area);
		String[] cacheArea = (String[]) cacheTemplete.getCacheForSerialize("CacheArea");
		//-------------------------------
		logger.info("正在获取区。。。");
		jsonObject.put("area",cacheArea);
		jsonObject.put("type", jsonObject!=null ? NotifyType.SEND_SMS.getType() : NotifyType.SEND_EAMIL.getType());
		return Response.success(jsonObject);
	}
	/**
	 * 确认省市区
	 * province 省
	 * city  市
	 * area  区
	 */
	@Override
	public Response requestAddress(String province, String city, String area){
		/*
		 * 确认省市区的ID都正确
		 */
		/**
		 * 当三个都不为空的时候
		 */
		Integer provinceId;
		
		Integer areaId;
		
		Integer cityId;
		
		if(city==""&&area==""||city==null&&area==null||city.equals("null")&&area.equals("null")||Regular.checkEmpty(city, null)&&Regular.checkEmpty(area, null)){
			provinceId = provinceRepository.affirmPtovince(province);
			JSONObject jsonObject =new JSONObject();
			String[] site = new String[]{province,"0","0"};
			String[] siteId = new String[]{provinceId.toString(),"0","0"};
			jsonObject.put("site", site);
			jsonObject.put("siteId", siteId);
			return Response.success(jsonObject);
		}else
		if(province!=null&&city!=null&&area!=null){
			JSONObject jsonObject = new JSONObject();
			provinceId = provinceRepository.affirmPtovince(province);
			cityId = cityRepository.affirmCity(city);
			areaId = areaRepository.affirmArea(area,cityId);
			String[] site = new String[]{province,city,area};
			String[] siteId = new String[]{provinceId.toString(),cityId.toString(),areaId.toString()};
			jsonObject.put("site", site);
			jsonObject.put("siteId",siteId);
			return Response.success(jsonObject);
		}
			
		return Response.error("参数不合法!");
	}
	/**
	 *fatherId 用户的uid
	 */
	@Override
	public Response selectDefaultSite(String fatherId) {
		JSONObject jsonObject = new JSONObject();
		Address address = addressDao.selectDefaultSite(fatherId);
		if(address==null){
			return Response.success();
		}else{
		jsonObject.put("uuid", Regular.checkEmpty(address.getUuid(),null)?"":address.getUuid());
		jsonObject.put("addresName", Regular.checkEmpty(address.getAddressName(), null)?"":address.getAddressName());
		jsonObject.put("addressPhone",Regular.checkEmpty(address.getAddressPhone(), null)?"":address.getAddressPhone());
		jsonObject.put("addressSite",Regular.checkEmpty(address.getAddressSite(),null)?"":address.getAddressSite());
		jsonObject.put("addressMinute", Regular.checkEmpty(address.getAddressMinute(), null)?"":address.getAddressMinute());
		jsonObject.put("defaultSite",address.isDefaultSite());
		return Response.success(jsonObject);
		}
	}
}
