package org.finace.user.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.finace.utils.entity.user.Address;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface AddressRepository extends Repository<Address, Integer>{
	/**
	 * 删除
	 * @param id           自增id
	 * @param updateTime   修改时间
	 * @param deleted      是否删除
	 */
	@Modifying
	@Query("update Address set updateTime=:updateTime,deleted=true where uuid=:uuid")
	void deletedAddress(@Param("uuid")String uuid,@Param("updateTime")Timestamp updateTime);
	
	@Modifying
	@Query("delete from Address where uuid=:uuid")
	int deleteAddress(@Param("uuid")String uuid);
	
	/**
	 * 修改
	 * @param addressName    收货人姓名
	 * @param addressPhone   收货人手机
	 * @param addressSite    收货人所在地区
	 * @param addressMinute  详细地址
	 * @param defaultSite    默认地址
	 * @param updateTime     修改时间
	 * @param deleted        是否删除
	 * @param id             自增id
	 */
	@Modifying
	@Query("update Address set addressName=:addressName,addressPhone=:addressPhone,addressSite=:addressSite,addressMinute=:addressMinute,defaultSite=:defaultSite,updateTime=:updateTime,siteId=:siteId where uuid=:uuid and deleted=false")
	void updateSite(@Param("addressName")String addressName,@Param("addressPhone")String addressPhone,@Param("addressSite")String[] addressSite,@Param("addressMinute")String addressMinute,@Param("defaultSite")boolean defaultSite,@Param("updateTime")Date updateTime,@Param("siteId")byte[] strings,@Param("uuid")String uuid);
	/**
	 * 查看
	 * @param id   与收货地址关联的id
	 * @return
	 */
	@Query("select new Address(uuid,addressName,addressPhone, addressSite,addressMinute,defaultSite,siteId) from Address where deleted=false and fatherId=:fatherId order by defaultSite desc")
	List<Address> selectSite(@Param("fatherId")String fatherId);
	/**
	 * 把所有的默认地址都修改
	 */
	@Modifying
	@Query("update Address set defaultSite=false where defaultSite=true and fatherId=:fatherId")
	void updateDefaultSite(@Param("fatherId")String fatherId);
	
	@Modifying
	@Query("update Address set defaultSite=false where fatherId=:userUuid and defaultSite=true")
	int setDefaultSiteFalseByUserUuid(@Param("userUuid")String userUuid);
	
	@Query("select new Address(uuid,addressName,addressPhone,addressSite,addressMinute,defaultSite,siteId) from Address where defaultSite=true and deleted=false and fatherId=:fatherId ")
	Address selectDefaultSite(@Param("fatherId")String fatherId); 
	
}
