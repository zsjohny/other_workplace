package org.finace.user.dao;

import org.finace.utils.entity.user.User;

import java.util.Date;

public interface UserDao {

    User findUserByOther(String name);

    void saveUser(User user);

    void removeUserByUuid(User user);

    void updatePassByUuid(String pass, String uuid);

    void updatePhoneAndPassByUuid(String phone, String pass, String uuid);

    void updateTimeAndUidByUuid(Date updateTime,String uid, String uuid,String diviceType,String cid);

    void updateHeadPicByUuid(String headPic, String uuid);

    void updateNickNameByUuid(String nickName, String uuid);

    void updateThirdQQIdByUuid(String thirdQQId, String uuid);

    void updateThirdWechatIdByUuid(String thirdWechatId, String uuid);

    void updateThirdWeBoIdIdByUuid(String thirdWeBoId, String uuid);

    User findPhoneAndPassByUuid(String uuid);

    void updateBound(String uuid);

}
