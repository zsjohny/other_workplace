	package org.finace.user.controller;

import javax.servlet.http.HttpServletRequest;

import org.finace.user.dao.AddressDao;
import org.finace.user.repository.AddressCrudRepository;
import org.finace.user.service.AddressServer;
import org.finace.utils.conver.DataConverUtils;
import org.finace.utils.operate.Response;
import org.finace.utils.prop.DataProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;

@RestController
@RequestMapping("/address")
public class AddressController {
	@Autowired
	AddressServer addressServer;
	
	@Autowired
	AddressDao addressDao;
	/**
	 * 
	 * @param request  发送的请求
	 * @param addressName  收货地址名字
	 * @param addressPhone  收货手机
	 * @param site 省市区 地址，中间用英文逗号间隔
	 * @param addressMinute 详细地址
	 * @param defaultSite 默认地址
	 * @param siteId 收货地址ID
	 * @return  添加收货地址的
	 */
	@RequestMapping("/addAddress")
	public Response addAddress(HttpServletRequest request,String addressName,String addressPhone,String site,String addressMinute,boolean defaultSite,String[] siteId){
		return addressServer.addAddress((String)request.getAttribute("uuid"),addressName,addressPhone,site,addressMinute,defaultSite,siteId);
	}
	/**
	 * 
	 * @param uuid 需要删除的uuid
	 * @return  删除收货地址的
	 */
	@RequestMapping("/deletedAddress")
	public Response deletedAddress(String uuid){
		return addressServer.deletedAddress(uuid);
	}
	/**
	 * 
	 * @param uuid  需要修改的uui
	 * @param addressName  收货人姓名
	 * @param addressPhone 收货人手机号
	 * @param site  省市区（用逗号间隔）
	 * @param addressMinute  详细地址
	 * @param defaultSite  是否是默认
	 * @param siteId 省市区ID
	 * @return  修改收货地址的
	 */
	@RequestMapping("/updateAddress")
	public Response updateAddress(HttpServletRequest request,String uuid,String addressName,String addressPhone,String site,String addressMinute,Boolean defaultSite,String[] siteId){
		return addressServer.updateAddress((String)request.getAttribute("uuid"),uuid,addressName,addressPhone,site,addressMinute,defaultSite,siteId);
	} 
	/**
	 * 
	 * @param request 发送的请求
	 * @return  获取收货地址的
	 */
	@RequestMapping("/selectAddress")
	public Response selectAddress(HttpServletRequest request){
		return addressServer.selectAddress((String)request.getAttribute("uuid"));
	}
	/**
	 * 
	 * @return  获取省的
	 */
	@RequestMapping("/selectProvince")
	public Response selectProvince(){
		return addressServer.selectProvince();
	}
	/**
	 * 
	 * @param province 省
	 * @return  获取市的
	 */
	@RequestMapping("/selectCity")
	public Response selectCity(String province){
		return addressServer.selectCity(province);
	}
	/**
	 * 
	 * @param city 市
	 * @return 获取区的
	 */
	@RequestMapping("/selectArea")
	public Response selectArea(String city){
		return addressServer.selectArea(city);
	}
	/**
	 * 
	 * @param province 省
	 * @param city 市
	 * @param area 区
	 * @return  这个是返回  省市区这个数组的
	 */
	@RequestMapping("/requestAddress")
	public Response requestAddress(String province,String city,String area){
		return addressServer.requestAddress(province, city, area);
	}
	
	/**
	 * 
	 * @param fatherId 用户的uuid
	 * @return 这个是查询默认地址的
	 */
	@RequestMapping("selectDefaultSite")
	public Response selectDefaultSite(String fatherId){
		return addressServer.selectDefaultSite(fatherId);
	}
	@Autowired
	private AddressCrudRepository acr;
	
	public static void main(String[] args) {
		 ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
		 AddressController s = (AddressController) context.getBean("addressController");
		//System.out.println(JSON.toJSONString(s.addressServer.selectAddress("612803130e4658a62fce5acc89084969597156dd6")));
//		 String [] stringArr = DataConverUtils.byteArr2StringArr(byteArr);
//		 for(String str : stringArr){
//			 
//			 System.out.println(str);
//		 }
		 System.out.println(JSON.toJSONString(s.addressServer.selectAddress("4206145318dc64b91a48dd70aaba414314b32c80e")));
	}

}
