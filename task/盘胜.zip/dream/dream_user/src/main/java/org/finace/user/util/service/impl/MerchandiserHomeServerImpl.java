package org.finace.user.util.service.impl;

import java.util.List;

import org.finace.user.util.service.MerchandiserHomeServer;
import org.finace.user.util.task.AutoMerchandiserHomeQuality;
import org.finace.user.util.task.AutoTaskMechandise;
import org.finace.user.util.task.QueryMerchandise;
import org.finace.user.util.task.RepositoryMerchandise;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Service
@Transactional
public class MerchandiserHomeServerImpl implements MerchandiserHomeServer{
	@Autowired
	AutoMerchandiserHomeQuality merchandiserHome;
	
	@Autowired
	QueryMerchandise queryMerchandise;
	
	@Autowired
	RepositoryMerchandise repositoryMerchandise;
	
	private Logger logger = LoggerFactory.getLogger(MerchandiserHomeServerImpl.class);
	@Override
	public Response findMerchadiserHomeUuid(String uuid) {

		/*JSONObject jsonObject = new JSONObject();
      
		JSONArray advise = new JSONArray();*/
        
		JSONObject json = new JSONObject();
               List<Merchandiser> list = merchandiserHome.findByDeletedAndUuid(false, uuid);	
               for(Merchandiser md:list){
            	   json.put("uid", Regular.checkEmpty(md.getUuid(),null)?"":md.getUuid());
            	   json.put("headPic",Regular.checkEmpty(md.getHeadPic(), null)?"":md.getHeadPic());
            	   json.put("name",Regular.checkEmpty(md.getName(),null)?"":md.getName());
 	               String[] carrouselJpg = md.getCarrouselJpg().split(",");
 	               json.put("carrouselJpg",Regular.checkEmpty(carrouselJpg, null)?"":carrouselJpg);
 	               json.put("beanAmount", Regular.checkEmpty(md.getBeanAmount(),null)?0:md.getBeanAmount());
 	               json.put("merchandiserRank",Regular.checkEmpty(md.getMerchandiserRank(), null)?"":md.getMerchandiserRank());
 	               json.put("attention", Regular.checkEmpty(md.getAttention(), null)?0:md.getAttention());
 	               json.put("merchTotalVIew", Regular.checkEmpty(md.getMerchTotalVIew(), null)?0:md.getMerchTotalVIew());
 	              /* advise.add(json);*/
               }
               /*jsonObject.put("merhandiser", advise);*/
               logger.info("商家详情uuid={}提取成功",uuid);
				return Response.success(json);
	}
	@Override
	public Response selectStore(String name,String merchBelongToUuid) {
		if(Regular.checkEmpty(name, null)){
			logger.info("查询内容出错 name={}",name);
			return Response.fail();
		}
		String z = "%"+name+"%";
		;
		
		List<Merchandise> merchandiseList = repositoryMerchandise.shopSearch(z, merchBelongToUuid,false);
		logger.info("参数name={}",name);
		JSONObject json = new JSONObject();
		JSONArray add = new JSONArray();
		for(Merchandise merchandise:merchandiseList){
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("uuid",Regular.checkEmpty(merchandise.getUuid(), null)?"":merchandise.getUuid());
			jsonObject.put("merchName",Regular.checkEmpty(merchandise.getMerchName(), null)?"":merchandise.getMerchName());
			jsonObject.put("logo",Regular.checkEmpty(merchandise.getMerchLog(), null)?0:merchandise.getMerchLog());
			jsonObject.put("headPics", Regular.checkEmpty(merchandise.getHeadPics(), null)?"":merchandise.getHeadPics());
			jsonObject.put("merchHaveSaleTotalCount",Regular.checkEmpty(merchandise.getMerchHaveSaleTotalCount(), null)?0:merchandise.getMerchHaveSaleMonthCount());
			add.add(jsonObject);
		}
		json.put("merchandise", add);
		return Response.success(json);
	}
}
