package org.finace.user.service.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.finace.user.dao.CollectionDao;
import org.finace.user.dao.MerchandiseCollectionDao;
import org.finace.user.dao.MerchandiserCollectionDao;
import org.finace.user.repository.CollectionCrudRepository;
import org.finace.user.repository.MerchandiseCategoryRepository;
import org.finace.user.service.CollectionServer;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.entity.user.Collection;
import org.finace.utils.http.HttpTools;
import org.finace.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Service
@Transactional
public class CollectionServerImpl implements CollectionServer{
	
	@Autowired
	CollectionDao collectionDao;

	@Autowired
	MerchandiserCollectionDao merchandiserCD;
	
	@Autowired
	MerchandiseCollectionDao merchandiseCD;
	
	@Autowired
	MerchandiseCategoryRepository mcr;
	
	@Autowired
	CollectionCrudRepository ccr;
	
	
	private Logger logger = LoggerFactory.getLogger(CollectionServerImpl.class);
	/**
	 * fatherId  用户的uid
	 * uuid  商品或者商家的id
	 * 
	 */
	@Override
	public Response addCollection(String fatherId,String uuid,Boolean merchandiser) {
		JSONObject jsonObject = new JSONObject();
		Collection collection = new Collection();
		if(merchandiser){
			List<Merchandiser> x= merchandiserCD.selectAttention(uuid);
			for(Merchandiser c:x){
				Integer v;
				if(c.getAttention()==null){
					 v = 0;
				}else{
					v = c.getAttention();
				}
				merchandiserCD.updateAttention(v+1,uuid);
			}
		}else{
			List<Merchandise> numberMerchandise = merchandiseCD.selectMerchandise(uuid);
			for(Merchandise z :numberMerchandise){
				List<Merchandiser> x= merchandiserCD.selectAttention(z.getMerchBelongToUuid());
				for(Merchandiser c:x){
					Integer v;
					if(c.getAttention()==null){
						 v = 0;
					}else{
						v = c.getAttention();
					}
					merchandiserCD.updateAttention(v, z.getMerchBelongToUuid());
				}
			}
		}
		
		if(!(ccr.findByfatherIdAndUuidAndDeleted(fatherId, uuid, false)==null)){
			jsonObject.put("collection", true);
			return Response.success(jsonObject);
		}else{
			collection.setFatherId(fatherId);
			collection.setUuid(uuid);
			collection.setDeleted(false);
			collection.setMerchandiser(merchandiser);
			collection.setNewTime(Timestamp.from(Instant.now()));
			collectionDao.addCollection(collection);
			return Response.success(jsonObject);
		}
		
	}
	/**
	 * fatherId 用户uid
	 * uuid 商品或者商家的Id
	 */
	@Override
	public Response deletedCollection(String fatherId,String uuid) {
		if(!Regular.checkEmpty(merchandiserCD.selectAttention(uuid), null)){
			List<Merchandiser> x= merchandiserCD.selectAttention(uuid);
			for(Merchandiser c:x){
				Integer v;
				if(c.getAttention()==null){
					 v = 0;
				}else{
					v = c.getAttention();
				}
				merchandiserCD.updateAttention(v-1,uuid);
			}
		}else{
			List<Merchandise> numberMerchandise = merchandiseCD.selectMerchandise(uuid);
			for(Merchandise z :numberMerchandise){
				List<Merchandiser> x= merchandiserCD.selectAttention(z.getMerchBelongToUuid());
				for(Merchandiser c:x){
					Integer v;
					if(c.getAttention()==null){
						 v = 0;
					}else{
						v = c.getAttention();
					}
					merchandiserCD.updateAttention(c.getAttention()-1, z.getMerchBelongToUuid());
				}
			}
		}
		collectionDao.deletedCollection(fatherId,uuid);
		return Response.success();
	}
	/**
	 *  fatherId 用户的Id
	 */
	@Override
	public Response selectMerchandiseCollection(String fatherId) {
			JSONObject jsonObject = new JSONObject();
			JSONArray jsArr = new JSONArray();
			for(String uuid :collectionDao.selectCollection(fatherId)){
				for(Merchandise merchandise:merchandiseCD.selectMerchandise(uuid)){
					JSONObject js = new JSONObject();
					js.put("uuid", Regular.checkEmpty(merchandise.getUuid(),null)?"":merchandise.getUuid());
					js.put("merchLog", Regular.checkEmpty(merchandise.getMerchLog(), null)?"":merchandise.getMerchLog());
					js.put("merchName", Regular.checkEmpty(merchandise.getMerchName(),null)?"":merchandise.getMerchName());
					js.put("merchPrice", Regular.checkEmpty(merchandise.getMerchPrice(),null)?"":merchandise.getMerchPrice());
					jsArr.add(js);
				}
			}
			logger.info("获取我的收藏商品成功。。。");
			jsonObject.put("js",jsArr);
		return Response.success(jsonObject);
	}
	/**
	 * fatherId 用户的uuid
	 */
	@Override
	public Response selectMerchandiserCollection(String fatherId) {
		JSONObject jsonObject = new JSONObject();
		JSONArray jsArr = new JSONArray();
		logger.info(fatherId);
		for(String uuid : collectionDao.selectCollection(fatherId)){
			for(Merchandiser merchandiser:merchandiserCD.selectMerchandiser(uuid)){
				JSONObject js = new JSONObject();
				js.put("uuid", Regular.checkEmpty(merchandiser.getUuid(),null)?"":merchandiser.getUuid());
				js.put("headPic", Regular.checkEmpty(merchandiser.getHeadPic(), null)?"":merchandiser.getHeadPic());
				js.put("name", Regular.checkEmpty(merchandiser.getName(),null)?"":merchandiser.getName());
				js.put("merchReceivedSeveral", Regular.checkEmpty(merchandiser.getMerchReceivedSeveral(),null)?0:merchandiser.getMerchReceivedSeveral());
				jsArr.add(js);
			}
		}
		logger.info("获取我的收藏商店成功。。。。");
		jsonObject.put("js",jsArr);
		return Response.success(jsonObject);
	}
	public static void main(String[] args) {
		HttpTools.doGet("localhost:8080/user/collection/addCollection/tourist.do","fatherId='dddd'&uuid='dafasdf'");
	
	}
}
