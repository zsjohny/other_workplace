package org.finace.user.repository;

import org.finace.utils.entity.user.City;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface CityRepository extends Repository<City, Integer>{
	
	@Query("select city from City where fatherID=(select provinceID from Province where province=:province)")
	String[] selectCity(@Param("province")String province); 
	
	@Query("select cityID from City where city=:city")
	Integer affirmCity(@Param("city")String city);
	
	@Query("select city from City where cityID=:cityID and fatherID=:fatherID")
	City verifyCity(@Param("cityID")Integer cityId,@Param("fatherID")Integer fatherID);
}
