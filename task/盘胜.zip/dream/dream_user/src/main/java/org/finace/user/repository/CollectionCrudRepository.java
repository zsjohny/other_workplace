package org.finace.user.repository;


import org.finace.utils.entity.user.Collection;
import org.springframework.data.repository.CrudRepository;

public interface CollectionCrudRepository extends CrudRepository<Collection, Integer>{
	
	Collection findByfatherIdAndUuidAndDeleted(String fatherId,String uuid,Boolean deleted);
}
