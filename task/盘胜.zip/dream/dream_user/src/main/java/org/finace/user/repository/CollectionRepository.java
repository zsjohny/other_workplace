package org.finace.user.repository;

import java.util.List;

import org.finace.utils.entity.user.Collection;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

public interface CollectionRepository extends Repository<Collection,Integer>{
	
	
	@Modifying
	@Query("delete from Collection where fatherId=:fatherId and uuid=:uuid")
	void deletedCollection(@Param("fatherId")String fatherId,@Param("uuid")String uuid);
	
	@Query("select uuid from Collection where fatherId=:fatherId and deleted=false")
	List<String> selectCollection(@Param("fatherId")String fatherId);
	
}
