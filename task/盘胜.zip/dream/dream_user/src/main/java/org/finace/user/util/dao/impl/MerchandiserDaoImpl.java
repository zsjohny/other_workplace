package org.finace.user.util.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.finace.user.util.dao.MerchandiserDao;
import org.finace.user.util.task.QueryMerchandiser;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.merchandise.Merchandise;
import org.finace.utils.entity.merchandise.Merchandiser;
import org.finace.utils.enums.MerchandiserSortType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;




@Repository
public class MerchandiserDaoImpl implements MerchandiserDao{
	
	
	@Autowired
	QueryMerchandiser queryMerchandiser;
	
	private int PAGE_COUNT = 20;
	
	    /**
	     * 分页查询所有的商品
	     *
	     * @param page         开始的页数 默认从第一页开始
	     * @param pageCount    每页展示的数量，一般为null,采取默认值
	     * @param word         搜索的字段 为空的时候查询所有
	     * @param qualityId    搜索的属性的Id  eg.. 热门 快手党 精品搭配
	     * @param sort         排序的sort字段  0代表综合 1 代表销量  2 代表价格
	     * @param order        排序的升或者降序 0 代表升序 1代表降序
	     * @param cateGoryId   分类的id
	     * @param isCateParent 是否是父类搜索 true表示父类搜索（一级搜索） false表示二级
	     * @param merchadiseId 商家的Id
	     * @return
	     */
	@Override
	public Page<Merchandiser> findMerchadiseAllByPage(Integer page, Integer pageCount, String word, String qualityId,
			Integer sort, Integer order, String cateGoryId, Boolean isCateParent, String merchadiseId) {
		String[] sortArr=null;
        if (sort == null || sort.equals(Merchandise.COLLGATE)) {
            sortArr = new String[2];
            sortArr[0] = MerchandiserSortType.SALE_COUNT.getKey();
            sortArr[1] = MerchandiserSortType.CREATE_TIME.getKey();
        } 
        Sort sortFile = new Sort((order != null && order == Merchandise.SORT_ASC ? Sort.Direction.ASC : Sort.Direction.DESC), sortArr);
        if (page == null || page < 0) {
            page = 1;
        }
        Pageable pageable = new PageRequest(page - 1, pageCount == null ? PAGE_COUNT : pageCount, sortFile);
        
        final String cateGoryUuid = cateGoryId;
        final Boolean isParent = isCateParent;
        
        Specification<Merchandiser> specification = new Specification<Merchandiser>() {
            @Override
            public Predicate toPredicate(Root<Merchandiser> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                list.add(cb.equal(root.get("deleted").as(Boolean.class), false));
                
                if (!Regular.checkEmpty(cateGoryUuid, null)) {
                    if (isParent == null || isParent) {
                        list.add(cb.equal(root.get("fatherId").as(String[].class), cateGoryUuid));
                    } else {
                        list.add(cb.equal(root.get("sunId").as(String[].class), cateGoryUuid));
                    }
                }
                return cq.where(list.toArray(new Predicate[list.size()])).getRestriction();
            	}

        	};
        return queryMerchandiser.findAll(specification, pageable);

	}
}
