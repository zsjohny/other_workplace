package org.finace.user.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.finace.utils.entity.user.Address;

public interface AddressDao {
	
	void addAddress(Address address);
	
	void deletedAddress(String uuid,Timestamp updateTime);
	
	void updateAddress(Address address,String uuid);
	
	void updateDefaultSite(String fatherId);
	
	Address selectDefaultSite(String fatherId);
	
	List<Address> selectAddress(String fatherId);
	
	String[] selectProvince();
	
	String[] selectCity(String province);
	
	String[] selectArea(String city);
	
	
	
	/*Address selectAddress(Address address);*/
}
