package org.finace.user.util.task;

import org.finace.utils.entity.merchandise.MerchandiseCategory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by Ness on 2016/12/18.
 */
public interface AutoTaskMerchandiseCatrgory extends CrudRepository<MerchandiseCategory, Integer> {
    List<MerchandiseCategory> findByDeletedAndParentCate(Boolean deleted, Boolean isParent);

    List<MerchandiseCategory> findByDeletedAndParentCateAndParentUuid(Boolean deleted, Boolean parent, String parentUuid);
    
}
