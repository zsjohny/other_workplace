package org.finace.user.util.task;

import org.finace.utils.entity.merchandise.MerchandiseQuality;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * 首页的属性全部加载
 * Created by Ness on 2016/12/20.
 */
public interface AutoMerchandiseQuality extends CrudRepository<MerchandiseQuality, Integer> {
	
    List<MerchandiseQuality> findByDeleted(Boolean deleted);
    
}
