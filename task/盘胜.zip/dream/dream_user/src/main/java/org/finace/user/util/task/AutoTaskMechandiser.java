package org.finace.user.util.task;

import java.util.List;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Ness on 2016/12/18.
 */
public interface AutoTaskMechandiser extends CrudRepository<Merchandiser, Integer> {

    Merchandiser findByDeletedAndUuid(Boolean deleted, String uuid);
    
    
    List<Merchandiser> findByUuidAndDeleted(String uuid,Boolean deleted);
    
}
