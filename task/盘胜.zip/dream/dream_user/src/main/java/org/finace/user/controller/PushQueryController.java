package org.finace.user.controller;

import javax.servlet.http.HttpServletRequest;

import org.finace.user.service.PushServer;
import org.finace.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
 * 推送的controller
 */
@RestController
@RequestMapping("/push")
public class PushQueryController {
	
	@Autowired
	PushServer pushServer;
	/**
	 * 
	 * @param request 发送的请求
	 * @param deviceNum 设备编号
	 * @param sendTopic 信息主题
 	 * @param sendContent 信息内容
	 * @param deleted 是否删除
	 * @return
	 */
	@RequestMapping("/andriod")
	public Response andriodPush(HttpServletRequest request,String deviceNum,String sendTopic,String sendContent,Boolean deleted){
		return pushServer.andriodPush((String)request.getAttribute("uuid"), deviceNum, sendTopic, sendContent, deleted);
	}
	/**
	 * 
	 * @param request 发送的请求
	 * @param deviceNum 设备编号
	 * @param sendTopic 信息主题
 	 * @param sendContent 信息内容
	 * @param deleted 是否删除
	 * @return
	 */
	@RequestMapping("/ios")
	public Response iosPush(HttpServletRequest request,String deviceNum,String sendTopic,String sendContent,Boolean deleted){
		return pushServer.iosPush((String)request.getAttribute("uuid"), deviceNum, sendTopic, sendContent, deleted);
	}
	
	
	
}
