package org.finace.user.dao.impl;

import java.util.List;

import org.finace.user.dao.MerchandiseCollectionDao;
import org.finace.user.repository.MerchandiseCollectionRepository;
import org.finace.utils.entity.merchandise.Merchandise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MerchandiseCollectionDaoImpl implements MerchandiseCollectionDao{
	
	@Autowired
	MerchandiseCollectionRepository mcr;
	
	
	@Override
	public List<Merchandise> selectMerchandise(String uuid) {
		return mcr.selectMerchandise(uuid);
	}

	@Override
	public Integer[] selectMerchandiserId() {
		return mcr.selectMerchandiseId();
	}

}
