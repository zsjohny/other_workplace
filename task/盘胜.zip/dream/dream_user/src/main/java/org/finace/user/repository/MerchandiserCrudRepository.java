package org.finace.user.repository;

import org.finace.utils.entity.merchandise.Merchandiser;
import org.springframework.data.repository.CrudRepository;

public interface MerchandiserCrudRepository extends CrudRepository<Merchandiser,Integer>{

}
