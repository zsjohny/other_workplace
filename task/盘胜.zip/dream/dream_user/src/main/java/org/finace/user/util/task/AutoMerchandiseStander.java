package org.finace.user.util.task;

import org.finace.utils.entity.merchandise.MerchandiseStandard;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * 规格的crud
 * Created by Ness on 2016/12/20.
 */
public interface AutoMerchandiseStander extends CrudRepository<MerchandiseStandard, Integer> {
	
    List<MerchandiseStandard> findByDeleted(Boolean deleted);
    
    MerchandiseStandard findByDeletedAndUuid(Boolean deleted,String uuid);
}
