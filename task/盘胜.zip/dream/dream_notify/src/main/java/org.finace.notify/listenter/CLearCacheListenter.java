package org.finace.notify.listenter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.finace.utils.Regular.Regular;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.ScheduleOperaType;
import org.finace.utils.jms.JmsListenter;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.annotation.PostConstruct;

/**
 * 清理缓存的监听类
 * Created by Ness on 2016/12/14.
 */
public class CLearCacheListenter implements JmsListenter {
    private Logger logger = LoggerFactory.getLogger(CLearCacheListenter.class);
    @Autowired
    @Qualifier(value = "jmsSenderForAuth")
    private JmsSender jmsSender;

    /**
     * 初始化清理定时任务
     */
    @PostConstruct
    private void initClearTask() {

        TimeTask timeTask = new TimeTask();
        timeTask.setExecuteTime("* * */6 * * ?");
        timeTask.setTimeTaskName("clearAuthTime");
        timeTask.setScheduleOperaType(ScheduleOperaType.ADD_TASK);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("clearAuthTime", true);
        timeTask.setParams(jsonObject.toJSONString());
        jmsSender.sendMsg(JSON.toJSONString(timeTask));
        logger.info("初始化清理用户失效信息成功");
    }


    @Autowired
    private UserUtils userUtils;

    public static void main(String[] args) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("clearAuthTime", true);
         jsonObject = JSONObject.parseObject(JSON.toJSONString(jsonObject.toJSONString()));
        System.out.println(jsonObject);
    }

    @Override
    public void onMsg(String s) {

        try {

            JSONObject jsonObject = JSONObject.parseObject(s);

            if (jsonObject == null) {
                logger.warn("接受缓存的监听消息转换为空,消息为{}", s);
                return;
            }
            if (Regular.checkEmpty(jsonObject.getString("clearAuthTime"), null)) {
                return;
            }

            logger.info("开始接受缓存的监听消息{}", s);
            userUtils.clearInvalidAuth();
            logger.info("结束处理缓存的监听消息{}", s);


        } catch (Exception e) {
            logger.info("接受缓存的监听消息{}出错", s, e);
        }


    }
}
