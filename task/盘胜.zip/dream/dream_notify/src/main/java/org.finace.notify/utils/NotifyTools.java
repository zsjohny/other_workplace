package org.finace.notify.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.HtmlEmail;
import org.finace.utils.Regular.Regular;
import org.finace.utils.cache.CacheTemplete;
import org.finace.utils.entity.schedule.TimeTask;
import org.finace.utils.enums.NotifyType;
import org.finace.utils.enums.ScheduleOperaType;
import org.finace.utils.jms.JmsSender;
import org.finace.utils.prop.DataProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

import static org.finace.utils.enums.CacheType.CACHE_DEVIDE;
import static org.finace.utils.enums.CacheType.NOTUFY_GROUP;

/**
 * Created by Ness on 2016/12/7.
 */
@Component
public class NotifyTools {

    private static Logger logger = LoggerFactory.getLogger(NotifyTools.class);

    @Autowired
    private DataProperties dataProperties;


    @Autowired
    private CacheTemplete cacheTemplete;
    private long MAX_WAIT_TIME = 86400000;//一天
    private int MAX_SEND_COUNT = 5;//次数
    private int ONCE_SEND_TIME = 60;//有效期
    private AtomicInteger newCount = new AtomicInteger(0);

    private Boolean sendEmail(String email, String msg) {
        Boolean flag = false;
        try {
            logger.info("邮箱={},消息={},开始发送", email, msg);
            HtmlEmail htmlEmail = new HtmlEmail();
            htmlEmail.setHostName(dataProperties.getProperty("email.host"));
            htmlEmail.setCharset("utf-8");
            htmlEmail.setFrom(
                    dataProperties.getProperty("email.sender"), dataProperties.getProperty("email.content"));
            htmlEmail.addTo(email, "", dataProperties.getProperty("email.sender"));
            htmlEmail.setSubject(dataProperties.getProperty("email.sendContent"));
            htmlEmail.setAuthenticator(new DefaultAuthenticator(dataProperties.getProperty("email.name"), dataProperties.getProperty("email.pass")));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(dataProperties.getProperty("email.sendStart"));
            stringBuilder.append(msg);
            stringBuilder.append(dataProperties.getProperty("email.sendEnd"));
            htmlEmail.setMsg(stringBuilder.toString());
            htmlEmail.send();
            flag = true;
            cacheTemplete.setCacheForExper(email, msg, ONCE_SEND_TIME);
            logger.info("邮箱={},消息={},结束发送", email, msg);
        } catch (Exception e) {
            logger.warn("邮箱={},消息={},访问出错", email, msg, e);
        }
        return flag;
    }

    private Boolean sendMsg(String phone, String msg) {
        Boolean flag = false;
        try {
            logger.info("手机={},消息={},开始发送", phone, msg);
            flag = true;

            //do something---发送模板
            cacheTemplete.setCacheForExper(phone, msg, ONCE_SEND_TIME);

            logger.info("手机={},消息={},结束发送", phone, msg);
        } catch (Exception e) {
            logger.warn("手机={},消息={},访问出错", phone, msg, e);
        }
        return flag;
    }

    /**
     * 发送通知
     *
     * @param ip     ip地址
     * @param number 手机或者邮箱
     * @param type   类型 0 代表 手机 1 代表邮箱
     */
    public void sendMsg(String ip, String number, Integer type) {

        if (type == null || cacheTemplete.exist(number)) {
            logger.warn("ip{},number{} 已经存在再缓存中，不在进行发送");
            return;
        }


        StringBuilder num = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            num.append((int) (Math.random() * 10));
        }
        JSONObject jsonObject;
        String cacheForHash = cacheTemplete.getCacheForHash(NOTUFY_GROUP.getValue(), ip + CACHE_DEVIDE.getValue() + number);
        if (Regular.checkEmpty(cacheForHash, null)) {
            jsonObject = new JSONObject();
            jsonObject.put("count", 1);
            jsonObject.put("time", System.currentTimeMillis());
        } else {
            jsonObject = JSON.parseObject(cacheForHash);
            long time = jsonObject.getLong("time");
            long nowTime = System.currentTimeMillis();
            if (nowTime - time > MAX_WAIT_TIME) {
                jsonObject.put("count", 1);

            } else {
                int count = jsonObject.getInteger("count");
                if (count > MAX_SEND_COUNT) {
                    return;
                } else {
                    newCount.set(count);
                    jsonObject.put("count", newCount.incrementAndGet());
                }

            }
            jsonObject.put("time", nowTime);

        }
        cacheTemplete.setCacheForHash(NOTUFY_GROUP.getValue(), ip + CACHE_DEVIDE.getValue() + number, JSON.toJSONString(jsonObject));


        logger.info("ip{},用户{},开始发送消息{}", ip, number, num);
        if (type.equals(NotifyType.SEND_EAMIL.getType())) {
            sendEmail(number, num.toString());
        } else {
            sendMsg(number, num.toString());
        }

        logger.info("ip{},用户{},结束发送消息{}", ip, number, num);
    }


    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");


        JmsSender jmsSender = (JmsSender) context.getBean("jmsSender");
        JSONObject json = new JSONObject();
        json.put("ip", "139.192.168.114");
        json.put("number", "455886786@qq.com");
        json.put("type", NotifyType.SEND_EAMIL.getType());
        jmsSender.sendMsg(JSON.toJSONString(json));

        TimeTask timeTask = new TimeTask();
        timeTask.setExecuteTime("*/15 * * * * ?");
        timeTask.setTimeTaskName("55555");
        timeTask.setScheduleOperaType(ScheduleOperaType.STARTNOW_TASK);
        timeTask.setParams("我最好");
//        jmsSender.sendMsg(JSON.toJSONString(timeTask));
        System.out.println("success");


    }

}
