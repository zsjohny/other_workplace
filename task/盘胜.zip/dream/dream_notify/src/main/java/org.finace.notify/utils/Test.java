package org.finace.notify.utils;

import org.finace.utils.operate.Services;

/**
 * Created by Ness on 2017/3/6.
 */
public class Test {

    public static void main(String[] args) {
        new Services().start();

    }
}
