package org.finace.notify.listenter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.finace.notify.utils.NotifyTools;
import org.finace.utils.Regular.Regular;
import org.finace.utils.concurrent.ExecutorService;
import org.finace.utils.concurrent.ExecutorTask;
import org.finace.utils.jms.JmsListenter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 监听发送的消息
 * Created by Ness on 2016/12/7.
 */
public class NotifyListenter implements JmsListenter {

    private Logger logger = LoggerFactory.getLogger(NotifyListenter.class);
    @Autowired
    private NotifyTools tools;

    @Autowired
    private ExecutorService executorService;

    @Override
    public void onMsg(String s) {
        try {

            if (Regular.checkEmpty(s, null)) {
                return;
            }

            JSONObject jsonObject = JSON.parseObject(s);
            String ip = jsonObject.getString("ip");
            String number = jsonObject.getString("number");
            Integer type = jsonObject.getInteger("type");


            if (Regular.checkEmpty(ip, null)) {
                logger.warn("ip为空");
                return;
            }
            if (Regular.checkEmpty(number, null)) {
                logger.warn("number为空");
                return;
            }
            if (type == null) {
                logger.warn("发送类型为空");
                return;
            }


            logger.info("开始给IP为{},的用户{},发送{}消息", ip, number, type);

            executorService.addTask(new ExecutorTask() {
                @Override
                public void doJob() {
                    tools.sendMsg(ip, number, type);
                }
            });


        } catch (Exception e) {

            logger.warn("消息发送失败", e);

        }


    }
}
