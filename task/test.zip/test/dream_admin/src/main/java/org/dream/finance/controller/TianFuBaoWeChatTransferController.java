package org.dream.finance.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.dream.admin.model.AdminUserModel;
import org.dream.finance.dao.FinanceCertDao;
import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.dao.FinanceTransferDao;
import org.dream.finance.service.FinanceService;
import org.dream.finance.service.TianFuBaoWeChatTransferService;
import org.dream.finance.util.tfbwc.ParamUtil;
import org.dream.finance.util.tfbwc.TFBMD5Utils;
import org.dream.finance.util.tfbwc.TFBRequestUtils;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.concurrent.Executors;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.controller.BaseController;
import org.dream.utils.math.Arith;
import org.dream.utils.mvc.Response;
import org.dream.utils.prop.SpringProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Controller
@RequestMapping("/finance")
public class TianFuBaoWeChatTransferController extends BaseController implements InitializingBean, DisposableBean {
	private Logger logger = LoggerFactory.getLogger(TianFuBaoWeChatTransferController.class);
	private static final Integer ERROR_CODE = 600;
	private static final String REDIS_KEY = "admin:filter:tianfubaowechat_transfer";
	@Autowired
	private SpringProperties springProperties;
	@Autowired
	private FinanceService financeService;
	@Autowired
	private FinanceIODao financeIODao;
	@Autowired
	private FinanceTransferDao transferDao;
	@Autowired
	private FinanceCertDao certDao;
	@Autowired
	private TianFuBaoWeChatTransferService transferService;
	@Autowired
	private RedisTemplate<String, Integer> redisTemplate;

	ScheduledExecutorService pool = Executors.newScheduledThreadPool(8, "天付宝微信转账定时任务");

	@RequestMapping("/tianFuBaoWeChatTransfer")
	@ResponseBody
	public Response transfer(String ioIds, HttpServletRequest request) {
		if (StringUtils.isBlank(ioIds)) {
			return Response.response(ERROR_CODE, "批量转账ID不能为空");
		}
		String redisKey = null;
		String[] ioIdsArray = null;
		List<FinanceTransferModel> list = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			HttpSession session = request.getSession();
			AdminUserModel loginUser = (AdminUserModel) session.getAttribute("user");
			String operator = loginUser.getUserAccount();
			list = financeService.saveTransfer(ioIds, FinanceTransferType.TIANFUBAO_WECHAT,
					FinancePayType.TIANFUBAO_WECHAT, operator);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + id;
				redisTemplate.delete(redisKey);
			}
		}
		Integer channelId = getDataId(request);
		FinanceCertModel model = new FinanceCertModel();
		model.setChannelId(channelId);
		model.setPlatform(FinancePayType.TIANFUBAO_WECHAT.getPlatform());
		model.setType(1);
		model.setStatus(0);
		final FinanceCertModel certModel = certDao.find(model);
		JSONObject parameter = JSON.parseObject(certModel.getParameter());
		String spid = parameter.getString("spid");
		String key = parameter.getString("md5Key");
		String publicKey = new String(ParamUtil.hex2Bytes(parameter.getString("publicKey")));

		for (FinanceTransferModel transferModel : list) {
			Double money = transferModel.getMoney();
			Double commission = transferModel.getCommission();
			Double transferMoney = Arith.subtract(money, commission);
			String realName = transferModel.getRealName();
			String cardNo = transferModel.getCardNo();
			final String selfOrderId = transferModel.getSelfOrderId();

			BigDecimal txn_amt_num = new BigDecimal(transferMoney).multiply(BigDecimal.valueOf(100));// 金额转换成分
			String txn_amt = String.valueOf(txn_amt_num.setScale(0, BigDecimal.ROUND_HALF_UP));// 支付金额
			TreeMap<String, String> paramsMap = new TreeMap<String, String>();
			paramsMap.put("spid", spid);
			paramsMap.put("version", "1.0");
			paramsMap.put("sp_serialno", selfOrderId);// 商户代付单号
			paramsMap.put("sp_reqtime", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
			paramsMap.put("tran_amt", txn_amt);
			paramsMap.put("cur_type", "1");// 金额类型
			paramsMap.put("acct_name", realName);
			paramsMap.put("acct_id", cardNo);
			paramsMap.put("acct_type", "0");// 账号类型 0-借记卡
			paramsMap.put("business_type", "20101");
			paramsMap.put("memo", "提现");
			String paramSrc = TFBRequestUtils.getParamSrc(paramsMap);// 拼接签名原串
			String sign = TFBMD5Utils.sign(paramSrc, key);// 生成签名
			paramsMap.put("sign", sign);
			String url = springProperties.getProperty("admin.tfbwc.transfer_url");

			String result = TFBRequestUtils.sendRequst(url, paramSrc + "&sign=" + sign, publicKey);

			// 为每个天付宝转账新建一个定时任务
			final Integer transferId = transferModel.getId();
			pool.schedule(new Callable<Object>() {
				@Override
				public Object call() throws Exception {
					logger.info("对转账ID为{}的提现进行天付宝微信转账定时任务", transferId);
					Response result = transferService.tianFuBaoWeChatResult(certModel.getParameter(), selfOrderId,
							transferId);
					if (result == null) {
						pool.schedule(this, 300, TimeUnit.SECONDS);
					}
					return null;
				}
			}, 1, TimeUnit.SECONDS);
		}
		return Response.response(ResponseCode.SUCCESS_CODE, "天付宝微信转账操作成功");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("初始化天付宝微信转账定时任务。。。");
		List<Map<String, Object>> list = transferDao.findTransferParam(2,
				FinanceTransferType.TIANFUBAO_WECHAT.getTypeDetail(), FinancePayType.TIANFUBAO_WECHAT.getPlatform());
		for (Map<String, Object> map : list) {
			final Integer transferId = (Integer) (map.get("id"));
			final String parameter = map.get("parameter").toString();
			final String selfOrderId = map.get("selfOrderId").toString();
			pool.schedule(new Callable<Object>() {
				@Override
				public Object call() throws Exception {
					logger.info("对转账ID为{}的提现进行天付宝微信转账定时任务", transferId);
					Response result = transferService.tianFuBaoWeChatResult(parameter, selfOrderId, transferId);
					if (result == null)
						pool.schedule(this, 300, TimeUnit.SECONDS);
					return null;
				}
			}, 1, TimeUnit.SECONDS);
		}
	}

	@Override
	public void destroy() throws Exception {
		logger.info("关闭天付宝微信转账定时任务线程池。。。");
		pool.shutdown();
	}

}
