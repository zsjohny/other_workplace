package org.dream.finance.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.dream.utils.constants.FinanceType;
import org.dream.utils.mvc.Response;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceTypeController {
	private Map<String, Integer> findFinanceType(String flow) {
		Map<String, Integer> type = new LinkedHashMap<String, Integer>();
		if ("money".equals(flow)) {
			type.put("充值", 1);
			type.put("提现", -1);
		}
		type.put("订单消费", 21);
		type.put("订单结算", 22);
		type.put("订单退单", 23);
		if ("money".equals(flow)) {
			type.put("内部资金存取", 31);
			type.put("系统资金存取", 41);
			type.put("佣金提现", 6);
			type.put("金币商城", 71);
		}
		if ("score".equals(flow)) {
			type.put("内部积分存取", 32);
			type.put("系统积分存取", 42);
			type.put("金币商城", 72);
		}
		return type;
	}

	@RequestMapping("/findFinanceMoneyType")
	@ResponseBody
	public Response findFinanceMoneyType(String flow) {
		flow = "money";
		return Response.success(findFinanceType(flow));
	}

	@RequestMapping("/findFinanceScoreType")
	@ResponseBody
	public Response findFinanceScoreType(String flow) {
		flow = "score";
		return Response.success(findFinanceType(flow));
	}

	@RequestMapping("/findFinanceTypeDetail")
	@ResponseBody
	public Response findFinanceTypeDetail(Integer type) throws Exception {
		Map<String, Integer> typeDatail = new LinkedHashMap<String, Integer>();
		List<FinanceType> list = FinanceType.getFinancyType();
		for (FinanceType financeType : list) {
			if (financeType.getType().equals(type)) {
				typeDatail.put(financeType.getRemark(), financeType.getTypeDetail());
			}
		}
		return Response.success(typeDatail);
	}

	@RequestMapping("/findFinanceDepositTypeDetail")
	@ResponseBody
	public Response findFinanceDepositTypeDetail() throws Exception {
		return findFinanceTypeDetail(1);
	}

	@RequestMapping("/findFinanceTransferTypeDetail")
	@ResponseBody
	public Response findFinanceTransferTypeDetail() throws Exception {
		return findFinanceTypeDetail(-4);
	}
}
