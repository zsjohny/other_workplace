package org.dream.config.service;

import java.util.List;

import org.dream.config.model.TaskTypeModel;
import org.dream.utils.mvc.Page;

/**
 * 
 * @author wangd
 *
 */
public interface TaskTypeService {

    /**
     * 保存任务类型
     * @param taskTypeModel
     */
    public void saveTaskTpe(TaskTypeModel taskTypeModel);
    /**
     * 获得所有的任务类型
     * @return
     */
    public List<TaskTypeModel> getAllTypes();
    
    public void deleteByIds(String ids);
    /**
     * 分页获得任务类型
     * @param pageIndex
     * @param pageSize
     * @return
     */
    public Page<TaskTypeModel> querypaging(Integer pageIndex, Integer pageSize);
    
    public TaskTypeModel getByTaskType (String taskType);
    
    public TaskTypeModel getById (Integer id);
}
