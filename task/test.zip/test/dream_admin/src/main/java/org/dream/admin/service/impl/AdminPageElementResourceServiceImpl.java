package org.dream.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.admin.dao.AdminResourceAssignmentDao;
import org.dream.admin.dao.AdminSecurityResourceDao;
import org.dream.admin.model.AdminPageElementResourceModel;
import org.dream.admin.model.AdminUserModel;
import org.dream.admin.service.AdminPageElementResourceService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminPageElementResourceServiceImpl implements AdminPageElementResourceService {

	@Autowired
	AdminSecurityResourceDao adminSecurityResourceDao;

	@Autowired
	AdminResourceAssignmentDao adminResourceAssignmentDao;

	@Override
	public void savePageElement(AdminPageElementResourceModel pageElementResourceModel) {

		adminSecurityResourceDao.createPageElement(pageElementResourceModel);
	}

	@Override
	public void updatePageElement(AdminPageElementResourceModel pageElementResourceModel) {
		adminSecurityResourceDao.updatePageElement(pageElementResourceModel);

	}

	@Override
	public void deletePageElement(List<Integer> ids) {
		for (Integer id : ids) {
			/**
			 * 删除分配纪录
			 */
			adminResourceAssignmentDao.deleteAdminResourceAssignmentsByAuthorityId(id);
			/**
			 * 删除页面元素
			 */
			adminSecurityResourceDao.updateStatus(id);
		}
	}

	@Override
	public Page<AdminPageElementResourceModel> pagingQueryPageElement(Integer pageIndex, Integer pageSize,
			Map<String, Object> param) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		param.put("limit", limit);
		param.put("size", pageSize);

		List<AdminPageElementResourceModel> data = adminSecurityResourceDao.pagingQueryPageElement(param);
		int resultCount = adminSecurityResourceDao.pagingQueryUrlAccess_count(param);
		Page<AdminPageElementResourceModel> page = new Page<>(pageIndex, pageSize, resultCount);
		page.setData(data);
		return page;
	}

	@Override
	public Page<AdminPageElementResourceModel> pagingQueryNotGrantPageElementsByRoleId(String name, String description,
			String identifier, Integer roleId, Integer dataId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<AdminPageElementResourceModel> pageElementResourceModels = adminSecurityResourceDao
				.pagingQueryNotGrantPageElementByRoleId(name, description, identifier, roleId, dataId, limit, pageSize);
		int resultCount = adminSecurityResourceDao.pagingQueryNotGrantPageElementByRoleId_count(name, description,
				identifier, roleId, dataId);
		Page<AdminPageElementResourceModel> page = new Page<>(pageIndex, pageSize, resultCount);
		page.setData(pageElementResourceModels);

		return page;
	}

	@Override
	public boolean hasPageElementByIdentifier(String identifier, Integer type) {

		Map<String, Object> param = new HashMap<String, Object>();
		param.put("identifier", identifier);
		param.put("category", AdminPageElementResourceModel.CATEGORY);
		param.put("type", type);
		return adminSecurityResourceDao.pagingQueryPageElement_count(param) > 0;
	}

	@Override
	public boolean hasRightByActorIdDdentifier(Integer actorId, String identifier, Integer dataId, Integer type,
			AdminUserModel user) {
		if ("admin".equals(user.getUserAccount())) {
			AdminPageElementResourceModel adminPageElementResourceModel = adminSecurityResourceDao
					.getPagelementByTypeDdentifier(identifier, dataId, type);
			return adminPageElementResourceModel != null && adminPageElementResourceModel.getId() != null;
		} else {
			AdminPageElementResourceModel pageElementResourceModel = adminSecurityResourceDao
					.getPagelementByActorIdIdDdentifier(actorId, identifier, dataId, type);
			return pageElementResourceModel != null && pageElementResourceModel.getId() != null;
		}
	}

	@Override
	public List<String> getPageElementByActorId(Integer actorId, Integer type,
			AdminUserModel user) {
		List<String> pageElementResourcesAll = new ArrayList<>();
		if ("admin".equals(user.getUserAccount())) {
			pageElementResourcesAll = adminSecurityResourceDao.getPageElementAll(AdminPageElementResourceModel.CATEGORY,
					type);
		} else {
			pageElementResourcesAll = adminSecurityResourceDao.getPageElementByActorId(actorId,
					AdminPageElementResourceModel.CATEGORY);
		}
		return pageElementResourcesAll;
	}

}
