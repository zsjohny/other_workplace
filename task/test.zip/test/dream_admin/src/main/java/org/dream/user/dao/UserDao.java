package org.dream.user.dao;

import org.dream.model.user.UserManageModel;
import org.dream.model.user.UserModel;
import org.dream.utils.validate.ValidateModel;

public interface UserDao {
	// V3
	public ValidateModel validate(UserModel userModel);

	// *******************************************************************
	public UserManageModel find(Integer userId);

	public void update(UserModel userModel);
}
