package org.dream.finance.service.impl;

import org.dream.finance.dao.FinanceAccDao;
import org.dream.finance.dao.FinanceFlowDao;
import org.dream.finance.dao.FinanceMainDao;
import org.dream.finance.service.BasicInnerService;
import org.dream.model.finance.FinanceAccModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.utils.constants.FinanceInnerType;
import org.dream.utils.constants.FinanceSystemType;
import org.dream.utils.math.Arith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BasicInnerServiceImpl implements BasicInnerService {
	@Autowired
	private FinanceMainDao financeMainDao;
	@Autowired
	private FinanceFlowDao financeFlowDao;
	@Autowired
	private FinanceAccDao financeAccDao;

	@Override
	public void innerDepositMoney(Integer userId, Double money) {
		// 修改main表
		FinanceMainModel mainModel = financeMainDao.find(userId);
		Double moneyUsable = Arith.add(mainModel.getMoneyUsable(), money);
		mainModel.setMoneyUsable(moneyUsable);
		Double moneyDrawUsable = Arith.add(mainModel.getMoneyDrawUsable(), money);
		mainModel.setMoneyDrawUsable(moneyDrawUsable);
		financeMainDao.update(mainModel);
		// 增加flow信息
		FinanceFlowModel flowModel = new FinanceFlowModel();
		flowModel.setUserId(userId);
		flowModel.setType(FinanceInnerType.DEPOSIT_MONEY.getType());
		flowModel.setTypeDetail(FinanceInnerType.DEPOSIT_MONEY.getTypeDetail());
		flowModel.setRemark(FinanceInnerType.DEPOSIT_MONEY.getRemark());
		flowModel.setMoney(money);
		flowModel.setMoneyLeft(moneyUsable);
		flowModel.setRedbag(0.0);
		flowModel.setRedbagLeft(mainModel.getRedbagUsable());
		financeFlowDao.save(flowModel);
		// 修改acc表
		FinanceAccModel accModel = financeAccDao.find(userId);
		accModel.setUserId(userId);
		Double depositMoney = Arith.add(accModel.getDepositMoney(), money);
		accModel.setDepositMoney(depositMoney);
		financeAccDao.update(accModel);
	}

	@Override
	public void innerDepositScore(Integer userId, Double score) {
		// 修改main表
		FinanceMainModel mainModel = financeMainDao.find(userId);
		Double scoreUsable = Arith.add(mainModel.getScoreUsable(), score);
		mainModel.setScoreUsable(scoreUsable);
		financeMainDao.update(mainModel);
		// 增加flow信息
		FinanceFlowModel flowModel = new FinanceFlowModel();
		flowModel.setUserId(userId);
		flowModel.setType(FinanceInnerType.DEPOSIT_SCORE.getType());
		flowModel.setTypeDetail(FinanceInnerType.DEPOSIT_SCORE.getTypeDetail());
		flowModel.setRemark(FinanceInnerType.DEPOSIT_SCORE.getRemark());
		flowModel.setScore(score);
		flowModel.setScoreLeft(scoreUsable);
		flowModel.setRedbag(0.0);
		flowModel.setRedbagLeft(mainModel.getRedbagUsable());
		financeFlowDao.saveScore(flowModel);
		// 修改acc表
		FinanceAccModel accModel = financeAccDao.find(userId);
		accModel.setUserId(userId);
		Double depositScore = Arith.add(accModel.getDepositScore(), score);
		accModel.setDepositScore(depositScore);
		financeAccDao.update(accModel);
	}

	@Override
	public void innerExtractMoney(Integer userId, Double money) {
		// 修改main表
		FinanceMainModel mainModel = financeMainDao.find(userId);
		Double moneyUsable = Arith.subtract(mainModel.getMoneyUsable(), money);
		mainModel.setMoneyUsable(moneyUsable);
		Double moneyDrawUsable = Arith.subtract(mainModel.getMoneyDrawUsable(), money);
		mainModel.setMoneyDrawUsable(moneyDrawUsable);
		financeMainDao.update(mainModel);
		// 增加flow信息
		FinanceFlowModel flowModel = new FinanceFlowModel();
		flowModel.setUserId(userId);
		flowModel.setType(FinanceInnerType.EXTRACT_MONEY.getType());
		flowModel.setTypeDetail(FinanceInnerType.EXTRACT_MONEY.getTypeDetail());
		flowModel.setRemark(FinanceInnerType.EXTRACT_MONEY.getRemark());
		flowModel.setMoney(money);
		flowModel.setMoneyLeft(moneyUsable);
		flowModel.setRedbag(0.0);
		flowModel.setRedbagLeft(mainModel.getRedbagUsable());
		financeFlowDao.save(flowModel);
		// 修改acc表
		// FinanceAccModel accModel = financeAccDao.find(userId);
		// accModel.setUserId(userId);
		// Double depositMoney = Arith.add(accModel.getDepositMoney(), money);
		// accModel.setDepositMoney(depositMoney);
		// financeAccDao.update(accModel);
	}

	@Override
	public void innerExtractScore(Integer userId, Double score) {
		// 修改main表
		FinanceMainModel mainModel = financeMainDao.find(userId);
		Double scoreUsable = Arith.subtract(mainModel.getScoreUsable(), score);
		mainModel.setScoreUsable(scoreUsable);
		financeMainDao.update(mainModel);
		// 增加flow信息
		FinanceFlowModel flowModel = new FinanceFlowModel();
		flowModel.setUserId(userId);
		flowModel.setType(FinanceInnerType.EXTRACT_SCORE.getType());
		flowModel.setTypeDetail(FinanceInnerType.EXTRACT_SCORE.getTypeDetail());
		flowModel.setRemark(FinanceInnerType.EXTRACT_SCORE.getRemark());
		flowModel.setScore(score);
		flowModel.setScoreLeft(scoreUsable);
		flowModel.setRedbag(0.0);
		flowModel.setRedbagLeft(mainModel.getRedbagUsable());
		financeFlowDao.saveScore(flowModel);
		// 修改acc表
		FinanceAccModel accModel = financeAccDao.find(userId);
		accModel.setUserId(userId);
		Double eraseScore = Arith.add(accModel.getEraseScore(), score);
		accModel.setDepositScore(eraseScore);
		financeAccDao.update(accModel);
	}

}
