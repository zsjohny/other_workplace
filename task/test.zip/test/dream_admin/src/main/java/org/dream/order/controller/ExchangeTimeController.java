package org.dream.order.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.order.ExchangeTimeModel;
import org.dream.order.service.ExchangeTimeService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * 市场和时间定时器
 * 
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author yehx
 * @date 2016年8月1日 下午4:14:24
 */
@Controller
@RequestMapping("/exchangetime")
public class ExchangeTimeController {
	@Autowired
	private ExchangeTimeService exchangeTimeService;
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	@ResponseBody
	public Response saveExchangeTime(ExchangeTimeModel etm,HttpServletRequest req){
		if(StringUtils.isBlank(String.valueOf(etm.getExchangeId()))||StringUtils.isBlank(etm.getExchangeName())||
		   StringUtils.isBlank(etm.getStartTimeStr())||
		   StringUtils.isBlank(etm.getEndTimeStr())||StringUtils.isBlank(etm.getCycleStr())||
		   StringUtils.isBlank(String.valueOf(etm.getExchangeStatus()))){
			return Response.response(600, "请求参数错误");
		}
		Map<String,Object> map = exchangeTimeService.saveExchangeTime(etm);
		if("0".equals(map.get("retCode"))){
			return Response.response(600,(String)map.get("retmsg") );
		}
		return Response.success();
	}
	/**
	 * 查询
	 * @auth yehx
	 * @date 2016年8月1日
	 */
	@RequestMapping("/pagingQuery")
	@ResponseBody
	public Response pagingQueryExchangeTime(Integer page, Integer pageSize, Integer exchangeId,String createTimeStart, String createTimeEnd){
		
		Page<ExchangeTimeModel> data = exchangeTimeService.pagingQueryExchangeTime(page, pageSize, exchangeId,createTimeStart, createTimeEnd);
		return Response.success(data);
		
	}
	@RequestMapping("/update")
	@ResponseBody
	public Response updateExchangeTime(ExchangeTimeModel etm){
		if(etm.getId()==null||StringUtils.isBlank(String.valueOf(etm.getExchangeId()))||
				   StringUtils.isBlank(etm.getStartTimeStr())||
				   StringUtils.isBlank(etm.getEndTimeStr())||StringUtils.isBlank(etm.getCycleStr())||
				   StringUtils.isBlank(String.valueOf(etm.getExchangeStatus()))){
					return Response.response(600, "请求参数错误");
		}
		Map<String,Object> map=exchangeTimeService.updateExchangeTime(etm);
		if("0".equals(map.get("retCode"))){
			return Response.response(600,(String)map.get("retmsg") );
		}
		return Response.success();
	}
	
	@RequestMapping("/delete")
	@ResponseBody
	public Response deleteExchangeTime(String id){
		if(StringUtils.isBlank(id)){
			return Response.response(600, "请求参数错误");
		}
		exchangeTimeService.deleteExchangeTime(id);
		return Response.success();
	}
	@RequestMapping("/getExchangeTimeInfo")
	@ResponseBody
	public Response getExchangeTimeInfo(int id){
		if(StringUtils.isBlank(String.valueOf(id))){
			return Response.response(600, "请求参数错误");
		}
		ExchangeTimeModel e=exchangeTimeService.getExchangeTimeInfo(id);
		return Response.success(e);
	}
	@RequestMapping("/getExchange")
	@ResponseBody
	public Response getExchange(){
		return Response.success(exchangeTimeService.getExchange());
	}
}
