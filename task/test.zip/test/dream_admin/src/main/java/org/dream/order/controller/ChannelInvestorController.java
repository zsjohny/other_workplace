package org.dream.order.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.ChannelInvestorModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.ChannelInvestorService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("channelInvestor")
public class ChannelInvestorController extends BaseController {

	@Autowired
	private ChannelInvestorService channelInvestorService;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	@Autowired
	private ChannelService channelService;

	@Autowired
	private TradingVarietyService tradingVarietyService;

	/**
	 * 获取渠道下的账户，作为下拉选
	 */
	@RequestMapping("/getAccounts")
	@ResponseBody
	public Response getAccountsByChannelId(HttpServletRequest request) {
		Integer channelId = getCurrentChannel(request).getId();
		return Response.success(channelInvestorService.getAccountsByChannelId(channelId));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/save")
	@ResponseBody
	public Response saveChannelInvestor(ChannelInvestorModel channelInvestorModel) {
		Map<String, Object> map = channelInvestorService.saveChannelInvestor(channelInvestorModel);
		if ("0".equals(map.get("retCode"))) {
			return Response.response(600, (String) map.get("retmsg"));
		}
		return Response.success();
	}

	/**
	 * 修改，需要更新缓存
	 */
	@RequestMapping("/update")
	@ResponseBody
	public Response updateChannelInvestor(ChannelInvestorModel channelInvestorModel) {
		String investorAccountBefore = channelInvestorService.getInfo(channelInvestorModel.getId())
				.getInvestorAccount();
		Map<String, Object> map = channelInvestorService.updateChannelInvestor(channelInvestorModel);
		if ("0".equals(map.get("retCode"))) {
			return Response.response(600, (String) map.get("retmsg"));
		}
		String investorAccountAfter = channelInvestorModel.getInvestorAccount();
		List<ChannelModel> firstChannellist = channelService.findAllFirstChannels();
		// 遍历一级渠道
		for (ChannelModel fcm : firstChannellist) {
			Integer cId = fcm.getId();
			List<TradingVarietyModel> tvlist = tradingVarietyService.getEffectiveTradingVarieties();
			// 遍历交易品种
			for (TradingVarietyModel tvm : tvlist) {
				Integer tvId = tvm.getId();
				String iAccount = (String) redisTemplate.opsForHash().get(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT,
						cId + "_" + tvId);
				if (iAccount == investorAccountBefore) {
					redisTemplate.opsForHash().delete(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT, cId + "_" + tvId);
					redisTemplate.opsForHash().put(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT, cId + "_" + tvId,
							investorAccountAfter);
				}
			}
		}
		return Response.success();
	}

	@RequestMapping("/pagingQuery")
	@ResponseBody
	public Response pagingQueryChannelInvestor(Integer page, Integer pageSize, Integer channelId) {
		Page<ChannelInvestorModel> data = channelInvestorService.pagingQueryChannelInvestor(page, pageSize, channelId);
		return Response.success(data);

	}

	/**
	 * 删除，需要更新缓存
	 */
	@RequestMapping("/remove")
	@ResponseBody
	public Response removeChannelInvestor(String ids) {
		if (StringUtils.isBlank(ids)) {
			return Response.response(600, "请求参数出错");
		}
		channelInvestorService.removeChannelInvestor(ids);
		// 缓存中也要清除，需要遍历key：channelId+"_"+varietyId
		List<Integer> idList = handleIds(ids);
		for (Integer iid : idList) {
			ChannelInvestorModel cim = channelInvestorService.getInfo(iid);
			List<ChannelModel> firstChannellist = channelService.findAllFirstChannels();
			// 遍历一级渠道
			for (ChannelModel fcm : firstChannellist) {
				Integer cId = fcm.getId();
				List<TradingVarietyModel> tvlist = tradingVarietyService.getEffectiveTradingVarieties();
				// 遍历交易品种
				for (TradingVarietyModel tvm : tvlist) {
					Integer tvId = tvm.getId();
					String iAccount = (String) redisTemplate.opsForHash()
							.get(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT, cId + "_" + tvId);
					if (iAccount == cim.getInvestorAccount()) {
						redisTemplate.opsForHash().delete(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT,
								cId + "_" + tvId);
					}
				}
			}

		}
		return Response.success();
	}

	@RequestMapping("/getInfo")
	@ResponseBody
	public Response getInfo(Integer id) {
		return Response.success(channelInvestorService.getInfo(id));
	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}
}
