package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinancePayPlatformModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;

public interface FinancePayPlatformService {

	public Response saveFinancePayPlatform(FinancePayPlatformModel financePayPlatformModel);

	public Response updateFinancePayPlatform(FinancePayPlatformModel financePayPlatformModel);

	public FinancePayPlatformModel getById(Integer id);

	public Page<FinancePayPlatformModel> querypaging(FinancePayPlatformModel model, Integer pageIndex, Integer size);

	public void removeFinancePayPlatform(String ids);

	public List<FinancePayPlatformModel> findPayPlatformAll(FinancePayPlatformModel payPlatformModel);
}
