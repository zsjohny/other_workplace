package org.dream.live.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.live.dao.LiveNoticeDao;
import org.dream.live.service.LiveNoticeService;
import org.dream.model.live.LiveNoticeModel;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LiveNoticeServiceImpl implements LiveNoticeService {

	@Autowired
	LiveNoticeDao liveNoticeDao;

	@Override
	public void createLiveNotice(LiveNoticeModel liveNoticeModel) {
		liveNoticeDao.createLiveNotice(liveNoticeModel);
	}

	@Override
	public void removeLiveNotice(String ids) {
		liveNoticeDao.removeLiveNotice(handleIds(ids));
	}

	@Override
	public void updateLiveNotice(LiveNoticeModel liveNoticeModel) {
		liveNoticeDao.updateLiveNotice(liveNoticeModel);
	}

	@Override
	public List<LiveNoticeModel> getAll(Integer channelId, Integer status) {
		return liveNoticeDao.getAll(channelId, status);
	}

	@Override
	public LiveNoticeModel getById(Integer id) {
		return liveNoticeDao.getById(id);
	}

	@Override
	public Page<LiveNoticeModel> querypaging(Integer channelId, Integer status, Integer page, Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;// limit作为查询数据库用
		List<LiveNoticeModel> liveNoticeModels = liveNoticeDao.qureypaging(channelId, status, limit, pageSize);
		Integer totalCount = liveNoticeDao.qureypaging_count(channelId, status);
		Page<LiveNoticeModel> resultPage = new Page<LiveNoticeModel>(page, pageSize, totalCount);
		resultPage.setData(liveNoticeModels);
		return resultPage;
	}

	private List<Integer> handleIds(String ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

}
