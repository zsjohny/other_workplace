package org.dream.admin.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.admin.model.AdminDepartmentModel;

/**
 * 部门相关数据操作接口
 * 
 * @author wangd
 *
 */
public interface AdminDepartmentDao {

	public void createDeparment(AdminDepartmentModel deparmentMoudel);

	public void updateDeparment(AdminDepartmentModel deparmentMoudel);

	public void delteDeparment(@Param(value = "id") Integer id, @Param(value = "dataId") Integer dataId);

	public void delteDeparmentByIds(@Param(value = "ids") List<Integer> ids, @Param(value = "dataId") Integer dataId);

	public AdminDepartmentModel getDeparment(@Param(value = "id") Integer id, @Param(value = "dataId") Integer dataId);

	/**
	 * 多条件分页查询
	 * 
	 * @param sn
	 * @param fullName
	 * @param shortName
	 * @param description
	 * @param parentId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<AdminDepartmentModel> pagingQueryDeparment(@Param(value = "sn") String sn,
			@Param(value = "fullName") String fullName, @Param(value = "shortName") String shortName,
			@Param(value = "description") String description, @Param(value = "parentId") Integer parentId,
			@Param(value = "level") Integer level, @Param(value = "dataId") Integer dataId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer pagingQueryDeparment_count(@Param(value = "sn") String sn,
			@Param(value = "fullName") String fullName, @Param(value = "shortName") String shortName,
			@Param(value = "parentId") Integer parentId, @Param(value = "level") Integer level,
			@Param(value = "description") String description, @Param(value = "dataId") Integer dataId);

	/**
	 * 查询部门下所有的子部门
	 * 
	 * @param parentId
	 * @return
	 */
	public List<AdminDepartmentModel> queryDepatmentsByParentId(@Param(value = "parentId") Integer parentId,
			@Param(value = "dataId") Integer dataId);

	/**
	 * 查询顶级部门，顶级部门的层级数是1
	 * 
	 * @return
	 */
	public List<AdminDepartmentModel> queryTopDepartments(@Param(value = "dataId") Integer dataId);

	/**
	 * 删除跟部门相关联的用户记录
	 * 
	 * @param departmentId
	 */
	public void deleteByDepartmentId(@Param(value = "departmentId") Integer departmentId);
}
