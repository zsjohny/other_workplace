package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.order.VarietyPriceModel;
import org.dream.order.dao.VarietyPriceDao;
import org.dream.order.service.VarietyPriceService;
import org.dream.utils.mvc.Page;
import org.dream.utils.prop.SpringProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class VarietyPriceServiceImpl implements VarietyPriceService {

	@Autowired
	VarietyPriceDao varietyPriceDao;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	@Autowired
	SpringProperties springProperties;

	@Override
	public Map<String, Object> saveVarietyPrice(VarietyPriceModel varietyPriceModel) {
		Map<String, Object> mapdata = new HashMap<String, Object>();
		// 首先判断这个品种数据库中是否已经新增了
		int count = varietyPriceDao.getVarietyPriceCountById(varietyPriceModel.getVarietyId());
		if (count > 0) {
			mapdata.put("resCode", "0");
			mapdata.put("resMgs", "该品种的价格配置已存在");
			return mapdata;
		}

		// 先根据varietyId，找出品种名称和品种类型
		Map<String, Object> map = varietyPriceDao.getVarietyNameAndTypeByVarietyId(varietyPriceModel.getVarietyId());
		varietyPriceModel.setVarietyName((String) map.get("variety_name"));
		String varietyType = (String) map.get("variety_type");
		varietyPriceModel.setVarietyType(varietyType);
		varietyPriceDao.insertSelective(varietyPriceModel);
		redisTemplate.opsForHash().put(VarietyPriceModel.VARIETY_PRICE,
				varietyPriceModel.getVarietyId(), varietyPriceModel);
		// 缓存中再放一个key为varietyType的缓存
		redisTemplate.opsForHash().put(VarietyPriceModel.VARIETY_PRICE, varietyType,
				varietyPriceModel);
		mapdata.put("resCode", "1");
		mapdata.put("resMgs", "成功");

		return mapdata;
	}

	@Override
	public Map<String, Object> updateVarietyPrice(VarietyPriceModel varietyPriceModel) {
		Map<String, Object> mapdata = new HashMap<String, Object>();

		varietyPriceDao.updateByPrimaryKeySelective(varietyPriceModel);
		mapdata.put("resCode", "1");
		mapdata.put("resMgs", "修改成功");
		redisTemplate.opsForHash().delete(VarietyPriceModel.VARIETY_PRICE,
				varietyPriceModel.getVarietyId());
		redisTemplate.opsForHash().put(VarietyPriceModel.VARIETY_PRICE,
				varietyPriceModel.getVarietyId(), varietyPriceModel);
		// 缓存中再放一个key为varietyType的缓存
		String varietyType = varietyPriceDao.getVarietyTypeByVarietyId(varietyPriceModel.getVarietyId());
		redisTemplate.opsForHash().delete(VarietyPriceModel.VARIETY_PRICE, varietyType);
		redisTemplate.opsForHash().put(VarietyPriceModel.VARIETY_PRICE, varietyType,
				varietyPriceModel);
		return mapdata;

	}

	@Override
	public void removeVarietyPrice(Integer id) {
		// 根据id得到品种id
		Integer varietyId = varietyPriceDao.getVarietyIdById(id);
		// 根据品种id获取品种类型
		String varietyType = varietyPriceDao.getVarietyTypeByVarietyId(varietyId);
		varietyPriceDao.removeVarietyPrice(id);
		redisTemplate.opsForHash().delete(VarietyPriceModel.VARIETY_PRICE, varietyId);
		redisTemplate.opsForHash().delete(VarietyPriceModel.VARIETY_PRICE, varietyType);
	}

	@Override
	public Page<VarietyPriceModel> pagingQueryVarietyPrice(Integer page, Integer pageSize, Integer varietyId,
			String createTimeStart, String createTimeEnd) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Integer limit = page > 0 ? page  * pageSize : 0 * pageSize;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("limit", limit);
		map.put("pageSize", pageSize);
		map.put("varietyId", varietyId);
		map.put("createTimeStart", createTimeStart);
		map.put("createTimeEnd", createTimeEnd);
		List<VarietyPriceModel> data = varietyPriceDao.pagingQueryVarietyPrice(map);
		int totalCount = varietyPriceDao.pagingQueryVarietyPriceCount(map);
		Page<VarietyPriceModel> pagelist = new Page<VarietyPriceModel>(page, pageSize, totalCount);
		pagelist.setData(data);
		return pagelist;
	}

	@Override
	public VarietyPriceModel getVarietyPriceById(Integer id) {
		return varietyPriceDao.selectByPrimaryKey(id);
	}

	@Override
	public List<Map<String, Object>> getVariety() {
		return varietyPriceDao.getVariety();
	}

	@Override
	public String getVarietyTypeByVarietyId(Integer varietyId) {
		return varietyPriceDao.getVarietyTypeByVarietyId(varietyId);
	}

}
