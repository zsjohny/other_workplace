package org.dream.sms.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.sms.SmsTemplate;
import org.dream.utils.mvc.Page;

public interface SmsTemplateService {

	public void addTemplate(SmsTemplate smsTemplate);

	public void updateTemplate(SmsTemplate smsTemplate);

	public List<SmsTemplate> getTemplate(Integer channelId);

	public SmsTemplate getById(Integer id);

	public Page<SmsTemplate> pagingQuery(String name, String template, Integer channelId, Integer pageIndex,
			Integer pageSize);

	public void remove(Integer id);

	public boolean hasSmsTemplate(String name, Integer channelId);

	public SmsTemplate findTemplate(String name, String template, Integer channelId);

}
