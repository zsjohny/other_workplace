package org.dream.order.service;

import java.util.List;

import org.dream.model.order.FuturesContractsModel;
import org.dream.utils.mvc.Page;

public interface FuturesContractsService {
	public void saveFutureContracts(FuturesContractsModel contractsMoudel);

	public void updateFutureContracts(FuturesContractsModel contractsMoudel);

	public FuturesContractsModel getById(Integer Id);

	public List<FuturesContractsModel> getAll();

	public Page<FuturesContractsModel> querypaging(String exchangeName, String varietyName, Integer status,
			Integer pageIndex, Integer size);

	public void changeStatusByIds(String ids, Integer status);

	public Integer getVarietyIdByCode(String contractsCode);

	public Integer qureypaging_count(String exchangeName, String varietyName, String contractsCode, Integer status);

	public Integer qureypagingHasContractsCode(String contractsCode);

	public void putContractsRedis(FuturesContractsModel fCModel);

	public void deleteContractsRedis(FuturesContractsModel fCModel);
}
