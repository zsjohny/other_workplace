package org.dream.admin.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dream.config.model.TaskTypeModel;
import org.dream.config.model.TimedTaskModel;
import org.dream.config.service.TaskTypeService;
import org.dream.config.service.TimedTaskService;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

@Controller
@RequestMapping(value = "/timedTask")
public class TimedTaskController {

	private static Logger logger = LoggerFactory.getLogger(TimedTaskController.class);

	@Autowired
	TimedTaskService timedTaskService;

	@Autowired
	TaskTypeService taskTypeService;

	@Autowired
	JmsSender timedTaskChangendSender;

	@RequestMapping(value = "/saveTimedTask", method = { RequestMethod.POST })
	@ResponseBody
	public Response saveTimedTask(Integer typeId, String timePeriod, String timeTrigger, String parameters,
			String remark) {

		Assert.notNull(typeId, "定时任务类型不能为空");
		Assert.notNull(timeTrigger, "任务执行时间不能为空");

		TaskTypeModel taskTypeModel = taskTypeService.getById(typeId);

		if (taskTypeModel != null) {
			TimedTaskModel timedTaskModel = new TimedTaskModel();

			timedTaskModel.setTypeId(typeId);
			timedTaskModel.setTaskType(taskTypeModel.getTaskType());
			timedTaskModel.setTypeName(taskTypeModel.getTaskName());
			timedTaskModel.setTimePeriod(timePeriod);
			timedTaskModel.setTimeTrigger(timeTrigger);
			timedTaskModel.setParameters(parameters);
			timedTaskModel.setRemark(remark);
			timedTaskModel.setIsOpen(true);
			timedTaskModel.setCreateDate(new Timestamp(System.currentTimeMillis()));

			timedTaskService.saveTiemdTask(timedTaskModel);
			Map<String, Object> message = new HashMap<String, Object>();
			message.put("action", "ADD");
			message.put("id", timedTaskModel.getId());
			timedTaskChangendSender.sendMessage(JSON.toJSONString(message));
		} else {
			return Response.error("保存失败，未能找到指定的任务类型");
		}

		return Response.success();
	}

	@RequestMapping(value = "/updateTimedTask", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateTimedTask(Integer id, String timePeriod, String timeTrigger, String parameters, String remark,
			HttpServletRequest request) {

		Assert.notNull(id, "要修改的定时任务id不能为空");
		Assert.notNull(timeTrigger, "任务执行时间不能为空");
		logger.info("修改定时任务：id={},userId={}", id, request.getAttribute("userId"));
		TimedTaskModel timedTaskModel = new TimedTaskModel();
		timedTaskModel.setTimePeriod(timePeriod);
		timedTaskModel.setTimeTrigger(timeTrigger);
		timedTaskModel.setParameters(parameters);
		timedTaskModel.setRemark(remark);

		timedTaskService.updateTiemdTask(timedTaskModel);
		Map<String, Object> message = new HashMap<String, Object>();
		message.put("action", "UPDATE");
		message.put("id", timedTaskModel.getId());
		timedTaskChangendSender.sendMessage(JSON.toJSONString(message));

		return Response.success();
	}

	/**
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteTimedTask", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteTimedTask(String ids, HttpServletRequest request) {
		Assert.notNull(ids, "请求参数出错");
		logger.info("删除定时任务：ids={},userId={}", ids, request.getAttribute("userId"));
		timedTaskService.deleteByIds(ids);
		Map<String, Object> message = new HashMap<String, Object>();
		message.put("action", "DELETE");
		message.put("id", ids);
		timedTaskChangendSender.sendMessage(JSON.toJSONString(message));
		return Response.success();
	}

	/**
	 * 分页查询
	 * 
	 * @param page
	 * @param pagesize
	 * @return
	 */
	@RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
	@ResponseBody
	public Response querypaging(Integer typeId, Boolean isOpen, Integer page, Integer pageSize) {

		Page<TimedTaskModel> pageTaskType = timedTaskService.querypaging(typeId, isOpen, page, pageSize);
		return Response.success(pageTaskType);
	}

	@RequestMapping(value = "/instantlyExecute", method = { RequestMethod.POST })
	@ResponseBody
	public Response instantlyExecute(Integer taskId, String taskType, String parameters) {
		timedTaskService.instantlyExecute(taskId, taskType, parameters);
		return Response.success();
	}
}
