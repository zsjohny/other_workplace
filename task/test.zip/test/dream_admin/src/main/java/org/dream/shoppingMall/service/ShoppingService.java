package org.dream.shoppingMall.service;

import org.dream.model.shoppingMall.ShoppingModel;
import org.dream.utils.mvc.Response;

public interface ShoppingService {
	public Response findShoppingByPage(ShoppingModel shoppingModel, Integer page, Integer pageSize);
}
