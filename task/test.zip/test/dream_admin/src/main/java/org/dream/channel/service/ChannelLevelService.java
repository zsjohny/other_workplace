package org.dream.channel.service;

import java.util.List;

import org.dream.model.channel.ChannelLevelModel;
import org.dream.utils.mvc.Page;

public interface ChannelLevelService {

	public void saveChannelLevel(ChannelLevelModel channelLevelModel);

	public void updateChannelLevelById(ChannelLevelModel channelLevelModel);

	public Integer findEverCount(Integer channelId, Integer isDisplay, Integer isDefault, String levelName, Integer id);

	public void removeByIds(String ids);

	public Page<ChannelLevelModel> querypaging(Integer channelId, Integer isDisplay, String levelName,
			Integer pageIndex, Integer pageSize);

	public ChannelLevelModel findEver(Integer channelId, Integer id, String levelName);

	public List<ChannelLevelModel> getLevelsForUser(Integer channelId);

	public ChannelLevelModel getLevelsByIsDefault(Integer channelId, Integer isDefault);
}
