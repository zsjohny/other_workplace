package org.dream.finance.service.impl;

import java.util.List;

import org.dream.finance.dao.FinanceChannelPayDao;
import org.dream.finance.service.FinanceChannelPayService;
import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceChannelPayServiceImpl implements FinanceChannelPayService {
	@Autowired
	private FinanceChannelPayDao channelPayDao;

	private static final Integer SUCCESS_CODE = 200;
	private static final Integer ERROR_CODE = 600;

	@Override
	public Response findByPage(FinanceChannelPayModel channelPayModel, Integer offset, Integer pageSize) {
		Integer limit = offset > 0 ? offset * pageSize : 0;
		List<FinanceChannelPayModel> resultList = channelPayDao.findByPage(channelPayModel, limit, pageSize);
		if (resultList == null) {
			return Response.response(ERROR_CODE, "查询失败");
		}
		Integer resultCount = channelPayDao.findByPage_count(channelPayModel);
		Page<FinanceChannelPayModel> pageResult = new Page<>(offset, pageSize, resultCount);
		pageResult.setData(resultList);
		return Response.response(SUCCESS_CODE, "查询成功", pageResult);
	}

	@Override
	public Response find(FinanceChannelPayModel channelPayModel) {
		FinanceChannelPayModel payModel = channelPayDao.find(channelPayModel);
		if (payModel == null) {
			return Response.response(ERROR_CODE, "查询失败");
		}
		return Response.response(SUCCESS_CODE, "查询成功", payModel);
	}

	@Override
	public Response save(FinanceChannelPayModel channelPayModel) {
		FinanceChannelPayModel payModel = channelPayDao.find(channelPayModel);
		if (payModel != null) {
			return Response.response(ERROR_CODE, "该规则已保存，请勿重复保存");
		}
		channelPayDao.save(channelPayModel);
		return Response.response(SUCCESS_CODE, "保存成功");
	}

	@Override
	public Response update(FinanceChannelPayModel channelPayModel) {
		// FinanceChannelPayModel payModel =
		// channelPayDao.find(channelPayModel);
		// if (payModel != null) {
		// return Response.response(ERROR_CODE, "该规则已保存，请勿重复保存");
		// }
		channelPayDao.update(channelPayModel);
		return Response.response(SUCCESS_CODE, "更新成功");
	}

	@Override
	public Response findChannelPayBankList(Integer channelId, Integer status) {
		List<FinanceBankModel> list = channelPayDao.findBankList(channelId, status);
		return Response.response(SUCCESS_CODE, "查询成功", list);
	}
}
