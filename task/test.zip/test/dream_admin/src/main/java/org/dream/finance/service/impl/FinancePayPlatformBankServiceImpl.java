package org.dream.finance.service.impl;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.finance.dao.FinancePayPlatformBankDao;
import org.dream.finance.service.FinancePayPlatformBankService;
import org.dream.model.finance.FinanceBankModel;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.model.finance.FinancePayPlatformModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinancePayPlatformBankServiceImpl implements FinancePayPlatformBankService {
	private static final Integer SUCCESS_CODE = 200;
	private static final Integer ERROR_CODE = 600;
	private static final Integer SUCCEED_CODE = 200;

	@Autowired
	FinancePayPlatformBankDao financePayPlatformBankDao;

	@Autowired
	FinancePayPlatformBankDao payPlatformBankDao;

	// V2

	// ****************************************************************

	@Override
	public Response saveFinancePayPlatformBank(FinancePayPlatformBankModel payPlatformBankModel) {
		FinancePayPlatformBankModel model = financePayPlatformBankDao.check(payPlatformBankModel);
		if (model != null)
			return Response.response(ERROR_CODE, "该支付平台对应的银行已存在");
		financePayPlatformBankDao.saveFinancePayPlatformBank(payPlatformBankModel);
		return Response.response(SUCCEED_CODE, "保存支付平台银行成功");
	}

	@Override
	public Response updateFinancePayPlatformBank(FinancePayPlatformBankModel payPlatformBankModel) {
		// FinancePayPlatformBankModel model =
		// financePayPlatformBankDao.check(payPlatformBankModel);
		// if (model != null)
		// return Response.response(ERROR_CODE, "该支付平台对应的银行已存在");
		financePayPlatformBankDao.updateFinancePayPlatformBank(payPlatformBankModel);
		return Response.response(SUCCEED_CODE, "更新支付平台银行成功");
	}

	@Override
	public void remoceFinancePayPlatformBank(Integer id) {
		financePayPlatformBankDao.remoceFinancePayPlatformBank(id);

	}

	@Override
	public FinancePayPlatformBankModel getById(Integer id) {

		return financePayPlatformBankDao.getById(id);
	}

	@Override
	public Page<FinancePayPlatformBankModel> querypaging(String bankName, String payPlatform, Integer status,
			Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;

		List<FinancePayPlatformBankModel> data = financePayPlatformBankDao.querypaging(bankName, payPlatform, status,
				limit, pageSize);
		Integer totalCount = financePayPlatformBankDao.querypaging_count(bankName, payPlatform, status);

		Page<FinancePayPlatformBankModel> page = new Page<>(pageIndex, pageSize, totalCount);

		page.setData(data);

		return page;
	}

	@Override
	public Response findPayPlatformBankAll(FinanceCertModel certModel) {
		List<FinanceBankModel> list = payPlatformBankDao.findBankAll(certModel);
		return Response.response(SUCCESS_CODE, "查询银行列表成功", list);
	}

	@Override
	public Response findChannelPayPlatformAll(FinanceCertModel certModel, Integer bankId) {
		List<FinancePayPlatformModel> list = payPlatformBankDao.findPayPlatformAll(certModel, bankId);
		return Response.response(SUCCESS_CODE, "查询支付平台成功", list);
	}

}
