package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.order.ExchangeTimeModel;
import org.dream.model.order.FuturesExchangeModel;
import org.dream.utils.mvc.Page;

public interface ExchangeTimeService {
	
	public Map<String,Object> saveExchangeTime(ExchangeTimeModel etm);
	
	public Page<ExchangeTimeModel> pagingQueryExchangeTime(Integer page,Integer pageSize, Integer exchangeId,String createTimeStart, String createTimeEnd);
	
	public void deleteExchangeTime(String id);
	
	public Map<String,Object>  updateExchangeTime(ExchangeTimeModel etm);
	
	public ExchangeTimeModel getExchangeTimeInfo(int id);
	
	public List<FuturesExchangeModel> getExchange();
}
