package org.dream.admin.service;

import java.util.List;
import java.util.Map;

import org.dream.admin.model.AdminPerssionModel;
import org.dream.utils.mvc.Page;

/**
 * 权限管理Service
 * 授权的细粒度表示，只涉及权限相关的Service
 * @author wangd
 *
 */
public interface AdminPermissionService {
    

    /**
     * 保存权限数据
     * @param perssionModel
     */
    public void createPermission(AdminPerssionModel perssionModel);
    /**
     * 动态更新权限
     * @param perssionModel
     */
    public void updatePermission(AdminPerssionModel perssionModel);
    
    /**
     * 批量删除权限，
     * 删除权限之前需要是否需要验证该权限已经关联了角色或者分配给用户了
     * 目前逻辑是：删除权限之前首先删除权限和角色之间的关系了权限参与者之间的关系
     * 原因删除权限之前默认为，操作者已经认为该权限是无效的了，不考虑误操作问题
     * @param idList
     */
    public void deletePermissionsByIds(List<Integer> idList, Integer dataId);
    
    /**
     * 根据查询条件分页查询权限信息
     * @param pageIndex 页码
     * @param pageSize 页大小
     * @param queryPermissionCondition 查询条件集合
     * @return 分页集合 {@link Page}
     */
    public Page<AdminPerssionModel> pagingQueryPermissions(Integer pageIndex, Integer pageSize, Map<String, Object> queryPermissionCondition);
           
    /**
     * 根据参与者Id分页查询授权给参与者的权限
     * @param page
     * @param pageSize
     * @param actorId
     * @return
     */
    public Page<AdminPerssionModel> pagingQueryGrantPermissionByUserId(Integer page, Integer pageSize, Integer actorId);
    /**
     * 根据参与者Id分页查询未授权给参与者权限
     * @param page
     * @param pagesize
     * @param actorId
     * @param name
     * @return
     */
    public Page<AdminPerssionModel> pagingQueryNotGrantPermissionsByUserId(Integer page, Integer pageSize, Integer actorI);
    
    /**
     *根据权限标识验证权限是否已经存在
     *权限标识不能重复
     * @param identifier
     * @return true : 该标识对应的权限已经存在；false 不存在该标识对应的权限
     */
    public boolean hasPermissionByIdentifier(String identifier);
}
