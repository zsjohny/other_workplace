package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.channel.dao.ChannelDao;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.OrderModel;
import org.dream.order.dao.ReportFormDao;
import org.dream.order.service.ReportFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportFormServiceImpl implements ReportFormService {

	@Autowired
	ReportFormDao reportFormDao;

	@Autowired
	ChannelDao channelDao;

	/**
	 * 二级渠道的报表
	 */
	@Override
	public Map<String, Object> countSecondChannelFees(Integer channelId, String orderTimeStart, String orderTimeEnd) {
		// 先分品种计算出各品种的统计值
		List<OrderModel> orderlist = reportFormDao.countSecondLastWeekFees(channelId, orderTimeStart, orderTimeEnd);
		Map<String, Object> map = new HashMap<String, Object>();
		if (orderlist != null && orderlist.size() > 0) {
			// 这里不分品种，计算总值
			OrderModel orderTotal = reportFormDao.countSecondTotal(channelId, orderTimeStart, orderTimeEnd);
			orderTotal.setVarietyName("总计");
			map.put("total", orderTotal);
			map.put("list", orderlist);
		} else {
			map.put("list", null);
		}
		return map;
	}

	/**
	 * 一级渠道的报表
	 */
	@Override
	public List<Map<String, Object>> countFirstChannelFees(Integer oneChannelId, String orderTimeStart,
			String orderTimeEnd) {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();// 结果
		// 先获取一级渠道自己的统计值
		OrderModel selfTotal = reportFormDao.countFirstTotal(oneChannelId, orderTimeStart, orderTimeEnd);
		// 如果一级渠道自己都没有值，则报表为空
		if (selfTotal == null) {
			return null;
		}
		// 获取一级渠道自己品种分类的统计值
		List<OrderModel> selfOrderlist = reportFormDao.countFirstLastWeekFees(oneChannelId, orderTimeStart,
				orderTimeEnd);
		for (OrderModel som : selfOrderlist) {
			som.setChannelName("无");// 标记，使excel一眼看出这个是他自己的统计值。
			som.setOneChannelName("总计");
		}
		selfTotal.setOneChannelName("总计");
		selfTotal.setChannelName("无");
		selfTotal.setVarietyName("总计");
		// 获取自己的值，并放入list
		Map<String, Object> selfMap = new HashMap<String, Object>();
		selfMap.put("total", selfTotal);
		selfMap.put("list", selfOrderlist);
		result.add(selfMap);
		// 获取该二级渠道下的所有子渠道,然后遍历，获取子渠道的统计值。
		List<ChannelModel> secondChannels = channelDao.findSecondChannelsBySuperId(oneChannelId);
		if (secondChannels != null && secondChannels.size() > 0) {
			for (ChannelModel scm : secondChannels) {
				OrderModel secondTotal = reportFormDao.countSecondTotal(scm.getId(), orderTimeStart, orderTimeEnd);
				if (secondTotal == null) {
					continue;
				}
				List<OrderModel> secondOrderlist = reportFormDao.countSecondLastWeekFees(scm.getId(), orderTimeStart,
						orderTimeEnd);
				secondTotal.setVarietyName("总计");
				Map<String, Object> secondMap = new HashMap<String, Object>();
				secondMap.put("total", secondTotal);
				secondMap.put("list", secondOrderlist);
				result.add(secondMap);
			}
		}
		return result;
	}

	/**
	 * 平台的报表
	 */
	@Override
	public List<Map<String, Object>> countPlatformFees(String orderTimeStart, String orderTimeEnd) {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();// 结果
		// 先获取平台自己的统计值
		OrderModel selfTotal = reportFormDao.countPlatformTotal(orderTimeStart, orderTimeEnd);
		// 如果平台自己都没有值，则报表为空
		if (selfTotal == null) {
			return null;
		}
		// 获取平台自己品种分类的统计值
		List<OrderModel> selfOrderlist = reportFormDao.countPlatformLastWeekFees(orderTimeStart, orderTimeEnd);
		for (OrderModel som : selfOrderlist) {
			som.setOneChannelName("平台");// 标记，使excel一眼看出这个是他自己的统计值。
			som.setChannelName("无");
		}
		selfTotal.setOneChannelName("平台");
		selfTotal.setChannelName("无");
		selfTotal.setVarietyName("总计");
		// 获取自己的值，并放入list
		Map<String, Object> selfMap = new HashMap<String, Object>();
		selfMap.put("total", selfTotal);
		selfMap.put("list", selfOrderlist);
		result.add(selfMap);
		// 获取平台上所有一级渠道,然后遍历，获取渠道的统计值。
		List<ChannelModel> firstChannels = channelDao.findAllFirstChannels();
		if (firstChannels != null && firstChannels.size() > 0) {
			for (ChannelModel fcm : firstChannels) {
				OrderModel firstTotal = reportFormDao.countFirstTotal(fcm.getId(), orderTimeStart, orderTimeEnd);
				if (firstTotal == null) {
					continue;
				}
				List<OrderModel> fisrtOrderlist = reportFormDao.countFirstLastWeekFees(fcm.getId(), orderTimeStart,
						orderTimeEnd);
				for (OrderModel fom : fisrtOrderlist) {
					fom.setChannelName("无");
				}
				firstTotal.setVarietyName("总计");
				firstTotal.setChannelName("无");
				Map<String, Object> firstMap = new HashMap<String, Object>();
				firstMap.put("total", firstTotal);
				firstMap.put("list", fisrtOrderlist);
				result.add(firstMap);
			}
		}
		return result;
	}

	/**
	 * 二级渠道的报表,订单原始币种
	 */
	@Override
	public Map<String, Object> countSecondChannelFeesLocalUnit(Integer channelId, String orderTimeStart,
			String orderTimeEnd) {
		// 先分品种计算出各品种的统计值
		List<OrderModel> orderlist = reportFormDao.countSecondLastWeekFeesLocalUnit(channelId, orderTimeStart,
				orderTimeEnd);
		Map<String, Object> map = new HashMap<String, Object>();
		if (orderlist != null && orderlist.size() > 0) {
			// 这里不分品种，计算总值
			map.put("list", orderlist);
		} else {
			map.put("list", null);
		}
		return map;
	}

	/**
	 * 一级渠道的报表,订单原始币种
	 */
	@Override
	public List<Map<String, Object>> countFirstChannelFeesLocalUnit(Integer oneChannelId, String orderTimeStart,
			String orderTimeEnd) {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();// 结果
		// 获取一级渠道自己品种分类的统计值
		List<OrderModel> selfOrderlist = reportFormDao.countFirstLastWeekFeesLocalUnit(oneChannelId, orderTimeStart,
				orderTimeEnd);
		if (selfOrderlist != null && selfOrderlist.size() > 0) {
			for (OrderModel som : selfOrderlist) {
				som.setChannelName("无");// 标记，使excel一眼看出这个是他自己的统计值。
				som.setOneChannelName("总计");
			}
		}
		// 获取自己的值，并放入list
		Map<String, Object> selfMap = new HashMap<String, Object>();
		selfMap.put("list", selfOrderlist);
		result.add(selfMap);
		// 获取该二级渠道下的所有子渠道,然后遍历，获取子渠道的统计值。
		List<ChannelModel> secondChannels = channelDao.findSecondChannelsBySuperId(oneChannelId);
		if (secondChannels != null && secondChannels.size() > 0) {
			for (ChannelModel scm : secondChannels) {
				List<OrderModel> secondOrderlist = reportFormDao.countSecondLastWeekFeesLocalUnit(scm.getId(),
						orderTimeStart, orderTimeEnd);
				Map<String, Object> secondMap = new HashMap<String, Object>();
				secondMap.put("list", secondOrderlist);
				result.add(secondMap);
			}
		}
		return result;
	}

	/**
	 * 平台渠道的报表,订单原始币种
	 */
	@Override
	public List<Map<String, Object>> countPlatformFeesLocalUnit(String orderTimeStart, String orderTimeEnd) {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();// 结果
		// 获取平台自己品种分类的统计值
		List<OrderModel> selfOrderlist = reportFormDao.countPlatformLastWeekFeesLocalUnit(orderTimeStart, orderTimeEnd);
		if (selfOrderlist != null && selfOrderlist.size() > 0) {
			for (OrderModel som : selfOrderlist) {
				som.setOneChannelName("平台");// 标记，使excel一眼看出这个是他自己的统计值。
				som.setChannelName("无");
			}

		}
		// 获取自己的值，并放入list
		Map<String, Object> selfMap = new HashMap<String, Object>();
		selfMap.put("list", selfOrderlist);
		result.add(selfMap);
		// 获取平台上所有一级渠道,然后遍历，获取渠道的统计值。
		List<ChannelModel> firstChannels = channelDao.findAllFirstChannels();
		if (firstChannels != null && firstChannels.size() > 0) {
			for (ChannelModel fcm : firstChannels) {
				List<OrderModel> fisrtOrderlist = reportFormDao.countFirstLastWeekFeesLocalUnit(fcm.getId(),
						orderTimeStart, orderTimeEnd);
				if (fisrtOrderlist != null && fisrtOrderlist.size() > 0) {
					for (OrderModel fom : fisrtOrderlist) {
						fom.setChannelName("无");
					}
				}
				Map<String, Object> firstMap = new HashMap<String, Object>();
				firstMap.put("list", fisrtOrderlist);
				result.add(firstMap);
			}
		}
		return result;
	}

}
