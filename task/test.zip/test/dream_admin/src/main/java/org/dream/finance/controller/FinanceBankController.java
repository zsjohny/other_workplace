package org.dream.finance.controller;

import org.dream.finance.service.FinanceBankService;
import org.dream.model.finance.FinanceBankModel;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceBankController {
	@Autowired
	private FinanceBankService bankService;

	@RequestMapping("/findBankAll")
	@ResponseBody
	public Response findBankAll() {
		return Response.success(bankService.findBankAll());
	}

	@RequestMapping("/saveFinanceBank")
	@ResponseBody
	public Response saveFinanceBank(FinanceBankModel bankModel) {
		return bankService.saveBank(bankModel);
	}

	@RequestMapping("/updateFinanceBank")
	@ResponseBody
	public Response updateFinanceBank(FinanceBankModel bankModel) {
		return bankService.updateBank(bankModel);
	}
}
