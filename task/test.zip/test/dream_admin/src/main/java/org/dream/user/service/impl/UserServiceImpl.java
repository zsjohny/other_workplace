package org.dream.user.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.user.UserBankCardModel;
import org.dream.model.user.UserManageModel;
import org.dream.model.user.UserModel;
import org.dream.user.dao.UserBankCardDao;
import org.dream.user.dao.UserDao;
import org.dream.user.dao.UserManageDao;
import org.dream.user.service.UserService;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.dream.utils.regular.Regular;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
	private static Logger logger = LoggerFactory.getLogger(UserService.class);
	@Autowired
	private UserManageDao userManageDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private UserBankCardDao userBankCardDao;

	@Override
	public Page<UserManageModel> findByPage(Integer id, Integer level, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, String createTimeStart, String createTimeEnd,
			String lastLoginTimeStart, String lastLoginTimeEnd, String realName, String idCard, Integer status,
			Integer page, Integer pageSize, String orderBy) {
		if (level == 1) {
			topChannelId = id;
		} else if (level == 2) {
			channelId = id;
		}
		Integer offset = page > 0 ? page * pageSize : 0;
		List<UserManageModel> list = userManageDao.findByPage(userId, userName, userPhone, channelId, topChannelId,
				createTimeStart, createTimeEnd, lastLoginTimeStart, lastLoginTimeEnd, realName, idCard, status, offset,
				pageSize, orderBy);
		Integer rows = userManageDao.findRows(userId, userName, userPhone, channelId, topChannelId, createTimeStart,
				createTimeEnd, lastLoginTimeStart, lastLoginTimeEnd, realName, idCard, status);
		Page<UserManageModel> userPage = new Page<>(page, pageSize, rows);
		userPage.setData(list);
		return userPage;
	}

	@Override
	public UserManageModel findUser(Integer userId) {
		return userDao.find(userId);
	}

	@Override
	public UserBankCardModel findUserBankCard(Integer userId) {
		return userBankCardDao.find(userId);
	}

	@Override
	public Response updateUserBankCard(UserBankCardModel bankCardModel) {
		if (bankCardModel.getIdStatus() != null) {
			userBankCardDao.update(bankCardModel);
			return Response.response(ResponseCode.SUCCESS_CODE, "解绑身份证成功");
		}
		if (bankCardModel.getCardState() != null) {
			userBankCardDao.update(bankCardModel);
			return Response.response(ResponseCode.SUCCESS_CODE, "解绑银行卡成功");
		}
		if (StringUtils.isBlank(bankCardModel.getRealName())) {
			return Response.response(ResponseCode.ERROR_CODE, "姓名不能为空");
		}
		if (!Regular.checkNameMatch(bankCardModel.getRealName())) {
			return Response.response(ResponseCode.ERROR_CODE, "姓名不正确");
		}
		if (StringUtils.isBlank(bankCardModel.getIdCard())) {
			return Response.response(ResponseCode.ERROR_CODE, "身份证号不能为空");
		}
		if (!Regular.checkIdCardMatch(bankCardModel.getIdCard())) {
			return Response.response(ResponseCode.ERROR_CODE, "身份证号填写错误");
		}
		if (StringUtils.isBlank(bankCardModel.getCardNumber())) {
			return Response.response(ResponseCode.ERROR_CODE, "银行卡号不能为空");
		}
		if (!Regular.checkBankCardMatch(bankCardModel.getCardNumber())) {
			return Response.response(ResponseCode.ERROR_CODE, "银行卡填写错误");
		}
		UserBankCardModel cardModel = userBankCardDao.findByIdCard(bankCardModel.getUserId(),
				bankCardModel.getIdCard());
		if (cardModel != null && cardModel.getUserId() != bankCardModel.getUserId()) {
			return Response.response(ResponseCode.ERROR_CODE, "身份证号已被填写");
		}
		userBankCardDao.update(bankCardModel);
		return Response.response(ResponseCode.SUCCESS_CODE, "更新用户信息成功");
	}

	@Override
	public Response updateUser(UserModel userModel) {
		if (userModel.getStatus() != null) {
			userDao.update(userModel);
			return Response.response(ResponseCode.SUCCESS_CODE, "解绑手机号成功");
		}
		if (StringUtils.isBlank(userModel.getUserName())) {
			return Response.response(ResponseCode.ERROR_CODE, "用户昵称不能为空");
		}
		if (StringUtils.isBlank(userModel.getUserPhone())) {
			return Response.response(ResponseCode.ERROR_CODE, "手机号不能为空");
		}
		if (!Regular.checkPhone(userModel.getUserPhone())) {
			return Response.response(ResponseCode.ERROR_CODE, "手机号不正确");
		}
		userDao.update(userModel);
		return Response.response(ResponseCode.SUCCESS_CODE, "更新用户信息成功");
	}

}
