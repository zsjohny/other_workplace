package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.VarietyAssetsModel;

public interface VarietyAssetsIntegralDao {

	public Integer getVarietyAssetsCountById(Integer varietyId);

	public Integer getVarietyAssetsCountByChannelAndVariety(@Param("varietyId") Integer varietyId,
			@Param("channelId") Integer channelId, @Param("id") Integer id);

	int insertSelective(VarietyAssetsModel record);

	public void updateByPrimaryKeySelective(VarietyAssetsModel varietyAssetsModel);

	public void removeVarietyAssets(Integer id);

	public List<VarietyAssetsModel> pagingQueryVarietyAssets(Map map);

	public int pagingQueryVarietyAssetsCount(Map map);

	public VarietyAssetsModel selectByPrimaryKey(Integer id);

	public void insertFees(@Param("assetsId") Integer assetsId, @Param("channelId") Integer channelId,
			@Param("channelName") String channelName, @Param("userId") Integer userId);

	public int getVarietyIdByassetsId(Integer assetsId);

	public List<VarietyAssetsModel> getTest(@Param("channelId") Integer channelId,
			@Param("varietyId") Integer varietyId);


	public List<VarietyAssetsModel>  getAssetsByVarietyIdAndChannelIdForIntegral(@Param("varietyId")int varietyId,@Param("channelId")int channelId);
}
