package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceCommissionIOModel;

public interface FinanceCommissionIODao {
	// v2
	public List<FinanceCommissionIOModel> findByPage(@Param("model") FinanceCommissionIOModel commissionIOModel,
			@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

	public Integer findRows(@Param("model") FinanceCommissionIOModel commissionIOModel);

	public List<FinanceCommissionIOModel> findByIds(@Param("list") List<Integer> list);

	public Integer update(@Param("list") List<Integer> list, @Param("status") Integer status);
	// ************************************************************
}
