package org.dream.utils.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.dream.admin.model.AdminUserModel;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 基础Controller，
 * 提供Controller中常用的操作如：在Session中获得登录者的信息
 * 所有登录后才能访问的Controller建议继承该Controller
 * @author wangd
 *
 */
public class BaseController {

    @Autowired
    ChannelService channelService;
    /**
     * 获得当前登录用户的所属的数据id，即干用户所属的渠道的id
     * <strong>如果无法获得当前等的用户的数据id将会抛出异常，因为访问该方法之前如果是Session过期的话，过滤器应该会起作用了.
     * </strong>
     * @param request
     * @return
     */
    public Integer getDataId(HttpServletRequest request) {
	HttpSession session = request.getSession();
	
	AdminUserModel loginUser = (AdminUserModel) session.getAttribute("user");
	if (loginUser == null) {
	    throw new RuntimeException("无法获得当前登录用户的信息");
	}
	
	return loginUser.getDataId();
    }
    
    /**
     * 获得当前登录用户所属的渠道信息
     * @param request
     * @return
     */
    public ChannelModel getCurrentChannel(HttpServletRequest request) {
	HttpSession session = request.getSession();
	
	ChannelModel channel = (ChannelModel) session.getAttribute("channel");
	/**
	 * 如果在Session中获取不到渠道信息则根据访问路径来确定渠道信息
	 * 
	 */
	if (channel == null) {
	    // 根据登录用户的域名确定用户所属的渠道
	    String url = request.getRemoteHost();// 客户端的主机名

	    channel = channelService.findChannelByBackstageDomain(url);
	}
	return channel;
    }
}
