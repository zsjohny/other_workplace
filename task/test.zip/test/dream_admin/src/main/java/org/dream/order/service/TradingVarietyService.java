package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.order.TradingVarietyModel;
import org.dream.utils.mvc.Page;

public interface TradingVarietyService {

	public Map<String,Object> saveFutureExchange(TradingVarietyModel tradingVarietyModel);

	public void updateFutureExchange(TradingVarietyModel tradingVarietyModel);

	public TradingVarietyModel getById(Integer Id);

	public Page<TradingVarietyModel> querypaging(String varietyName, String varietyType, String exchangeName,
			String varietyRemark, Integer status, Integer pageIndex, Integer pageSize);

	public List<TradingVarietyModel> getEffectiveTradingVarieties();

	public List<TradingVarietyModel> getAllTradingVarieties();

	public void removeTradingVarietyById(Integer id, Integer status);

	public void removeByIds(String ids);

	public List<TradingVarietyModel> getByExchangeId(Integer exchangeId);
}
