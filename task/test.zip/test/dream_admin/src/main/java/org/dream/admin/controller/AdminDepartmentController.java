package org.dream.admin.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminDepartmentModel;
import org.dream.admin.service.AdminDepartmentService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/adminDepartment")
public class AdminDepartmentController extends BaseController {

	@Autowired
	AdminDepartmentService adminDepartmentService;

	@RequestMapping(value = "/department-tree", method = { RequestMethod.POST })
	@ResponseBody
	public Response departmentTree(HttpServletRequest request) {

		/**
		 * 首先获得顶级组织机构
		 */
		List<AdminDepartmentModel> topDepartments = adminDepartmentService.getTopDepartments(super.getDataId(request));

		this.handleChildDepartments(topDepartments,request);
		return Response.success(topDepartments);
	}

	/**
	 * 递归处理子部门数据
	 * 
	 * @param topDepartments
	 */
	private void handleChildDepartments(List<AdminDepartmentModel> topDepartments,HttpServletRequest request) {
		for (AdminDepartmentModel departmentMoudel : topDepartments) {
			List<AdminDepartmentModel> childDepartments = adminDepartmentService
					.getDepatementsByParentId(departmentMoudel.getId(),super.getDataId(request));
			if (childDepartments != null && childDepartments.size() > 0) {
				this.handleChildDepartments(childDepartments,request);
				departmentMoudel.setChildDepartments(childDepartments);
			}
		}

	}

	/**
	 * 部门保存
	 * 
	 * @param sn
	 * @param fullName
	 * @param shortName
	 * @param description
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value = "/saveDepartment", method = { RequestMethod.POST })
	@ResponseBody
	public Response saveDepartment(String sn, String fullName, String shortName, String description, Integer parentId,
			HttpServletRequest request) {
		Assert.notNull(sn, "部门编号不能为空");
		Assert.notNull(fullName, "部门全称不能为空");
		Integer dataId = getDataId(request);
		if (adminDepartmentService.hasDeparmentBySn(sn)) {
			return Response.error("保存失败，已存在的部门编码");
		}
		AdminDepartmentModel departmentMoudel = new AdminDepartmentModel();

		departmentMoudel.setSn(sn);
		departmentMoudel.setFullName(fullName);
		departmentMoudel.setShortName(shortName);
		departmentMoudel.setDescription(description);
		departmentMoudel.setDataId(dataId);

		if (parentId != null) {
			AdminDepartmentModel parentDepartment = adminDepartmentService.getDeparmentById(parentId, dataId);
			departmentMoudel.setParentDeparment(parentId);
			departmentMoudel.setLevelCode(parentDepartment != null ? parentDepartment.getLevelCode() + 1 : 1);
		}
		adminDepartmentService.saveDeparment(departmentMoudel);

		return Response.success();
	}

	/**
	 * 
	 * @param id
	 * @param sn
	 * @param fullName
	 * @param shortName
	 * @param description
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value = "/updateDepartment", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateDepartment(Integer id, String shortName, String description, Integer parentId,
			HttpServletRequest request) {
		Assert.notNull(id, "部门id不能为空");

		AdminDepartmentModel departmentMoudel = new AdminDepartmentModel();

		departmentMoudel.setId(id);
		departmentMoudel.setShortName(shortName);
		departmentMoudel.setDescription(description);

		if (parentId != null) {
			AdminDepartmentModel parentDepartment = adminDepartmentService.getDeparmentById(parentId,
					super.getDataId(request));
			departmentMoudel.setLevelCode(parentDepartment != null ? parentDepartment.getLevelCode() + 1 : 1);
		}
		adminDepartmentService.updateDeparment(departmentMoudel);

		return Response.success();
	}

	/**
	 * 分页查询部门数据 默认查询出一级部门数据
	 * 
	 * @param sn
	 * @param fullName
	 * @param shortName
	 * @param description
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value = "/pagingQueryDepartment", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryDepartment(String sn, String fullName, String shortName, String description,
			Integer parentId, Integer page, Integer pageSize, HttpServletRequest request) {
		Page<AdminDepartmentModel> resultPage = adminDepartmentService.pagingQueryDeparment(sn, fullName, shortName,
				description, parentId, super.getDataId(request), page, pageSize);

		return Response.success(resultPage);
	}

	/**
	 * 批量撤销部门 含有子部门的部门不能撤销
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteDepartments", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteDepartments(String ids, HttpServletRequest request) {
		Assert.notNull(ids, "需要撤销的部门Id不能为空");
		Integer dataId = getDataId(request);
		String idsArray[] = ids.split(",");
		List<Integer> idList = new ArrayList<Integer>();
		for (int i = 0; i < idsArray.length; i++) {
			idList.add(Integer.valueOf(idsArray[i]));
		}
		return Response.success(adminDepartmentService.removeDeparmentsByIds(idList, dataId));
	}
}
