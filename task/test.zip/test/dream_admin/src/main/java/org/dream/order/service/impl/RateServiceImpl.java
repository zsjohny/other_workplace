package org.dream.order.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.Rate;
import org.dream.order.dao.RateDao;
import org.dream.order.service.RateService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
@Service
public class RateServiceImpl implements RateService {
	
	@Autowired
	RateDao rateDao;
	@Autowired
	RedisTemplate<String, Object> redisTemplate;

	@Override
	public Map<String, Object> saveRate(Rate rate,int userId,int channelId) {
		Map<String,Object> mapdata =new HashMap<String,Object>();
		int count =rateDao.getRate(rate.getCurrency(),channelId);
		if(count>0){
			mapdata.put("retCode","0" );
			mapdata.put("retmsg","该币种已存在");
			return mapdata;
		}
		rate.setChannelId(channelId);
		rate.setCreateUserId(userId);
		rateDao.insertSelective(rate);
		if(channelId !=0){
			redisTemplate.opsForHash().put(Rate.CURRENCY_RATE, channelId+"_"+rate.getCurrency(), rate);
		}
		mapdata.put("resCode","1" );
		return mapdata;
	}

	@Override
	public void updateRate(Rate rate,int userId,ChannelModel channelModel) {
		rate.setUpdateUserId(userId);
		if(channelModel.getLevel()!=0){
			rateDao.updateByPrimaryKeySelective(rate);
			//得到汇率
			rate=rateDao.selectByPrimaryKey(rate.getId());
			redisTemplate.opsForHash().put(Rate.CURRENCY_RATE, channelModel.getId()+"_"+rate.getCurrency(), rate);
		}else{
			//首先修改所有的该币种的数据
			rateDao.updateRate(rate);
			//根据币种找到所有的Rate
			List<Rate> rates=rateDao.getRatesByCurrency(rate.getCurrency());
			System.out.println(JSON.toJSONString(rates));
			if(rates !=null && rates.size()>0){
				for(Rate r : rates){
					redisTemplate.opsForHash().put(Rate.CURRENCY_RATE, r.getChannelId()+"_"+r.getCurrency(), r);
				}
			}
		}
		
	}

	@Override
	public Map<String,Object> removeRate(String id,int channelId) {
		Map<String,Object> map = new HashMap<String,Object>();
		if(channelId == 0){
			//先判断该币种下面是否有
			int count  =rateDao.hasSunRate(Integer.valueOf(id));
			if(count >0){
				map.put("retCode", "0");
				map.put("retmsg", "该币种,有一级渠道正在使用,删除失败");
				return map;
			}else{
				rateDao.remove(Integer.valueOf(id));
				
			}
		}else{
			String[]ids=id.split(",");
			//先根据id得到所有的rate
			List<Rate> rate=rateDao.getRates(ids);
			rateDao.removeByPrimaryKey(ids);
			for(int i=0;i<rate.size();i++){
				redisTemplate.opsForHash().delete(Rate.CURRENCY_RATE,channelId+"_"+rate.get(i).getCurrency());
			}
		}
		map.put("retCode", "1");
		map.put("retmsg", "该币种,有一级渠道正在使用,删除失败");
		return map;
		
	}

	@Override
	public Page<Rate> pagingQueryRate(Integer page, Integer pageSize, String currency,int channelId) {
		 pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
	     page = page == null ? 0 : page;
	     Integer limit = page  > 0 ? page* pageSize : 0 * pageSize;
	     Map<String,Object> map=new HashMap<String,Object>();
	     map.put("limit", limit);
	     map.put("pageSize", pageSize);
	     map.put("currency",currency);
	     map.put("channelId", channelId);
	     List<Rate> data=rateDao.pagingQueryRate(map);
	     int totalCount = rateDao.pagingQueryRateCount(map);
	     Page<Rate> pagelist=new Page<Rate>(page,pageSize,totalCount);
	     pagelist.setData(data);
		return pagelist;
	}

	@Override
	public Rate getRateById(Integer rateId) {
		
		return rateDao.selectByPrimaryKey(rateId);
	}

	@Override
	public List<Rate> getCurrency() {
		
		return rateDao.getCurrency();
	}

	@Override
	public Rate getRateByCurrency(String currency) {
		// TODO Auto-generated method stub
		return rateDao.getRateByCurrency(currency) ;
	}

}
