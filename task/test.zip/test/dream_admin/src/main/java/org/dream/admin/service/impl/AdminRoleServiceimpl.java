package org.dream.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.admin.dao.AdminActorDao;
import org.dream.admin.dao.AdminAuthorityDao;
import org.dream.admin.dao.AdminAuthorizationDao;
import org.dream.admin.dao.AdminResourceAssignmentDao;
import org.dream.admin.model.AdminRoleModel;
import org.dream.admin.service.AdminRoleService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 
 * @author SUNDONG_
 *
 */
@Service
public class AdminRoleServiceimpl implements AdminRoleService {

	@Autowired
	AdminAuthorityDao adminAuthorityDao;

	@Autowired
	AdminActorDao adminActorDao;

	@Autowired
	AdminAuthorizationDao adminAuthorizationDao;

	@Autowired
	AdminResourceAssignmentDao adminResourceAssignmentDao;

	@Override
	public void createAdminRole(AdminRoleModel adminRoleModel) {
		adminAuthorityDao.createAdminRole(adminRoleModel);
	}

	@Override
	public void updateAdminRole(AdminRoleModel adminRoleModel) {
		adminAuthorityDao.updateAdminRole(adminRoleModel);
	}

	@Override
	public void deleteAdminRole(Integer roleId) {
		adminAuthorityDao.deleteAdminRole(roleId);
	}

	@Override
	public Page<AdminRoleModel> pagingQueryPermissions(String name, String description, String category, Integer dataId,
			Integer pageIndex, Integer pageSize) {

		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;

		List<AdminRoleModel> data = adminAuthorityDao.pagingQueryRole(name, description, category, dataId, limit,
				pageSize);
		int resultCount = adminAuthorityDao.pagingQueryRole_count(name, description, category, dataId);

		Page<AdminRoleModel> page = new Page<>(pageIndex, pageSize, resultCount);
		page.setData(data);
		return page;
	}

	@Override
	public List<AdminRoleModel> deleteRoles(List<Integer> ids) {
		List<AdminRoleModel> result = new ArrayList<AdminRoleModel>();
		for (Integer id : ids) {
			// 验证该角色是否是 系统角色 否则该角色不能被删除
			AdminRoleModel roleModel = adminAuthorityDao.getRole(id);
			if (roleModel.getIsAdmin() == 0) {
				// 验证带角色下是否已经有用户了，有的就不能删除，需要先清空该角色下面的用户，然后再删除角色
				adminAuthorizationDao.deleteAuthorizationByActorIdAuthorityIds(null, ids, null);
				// 删除角色权限、角色页面元素资源、角色URL、角色菜单等配置数据
				adminResourceAssignmentDao.deleteAdminResourceAssignments(id, null, null);
				adminAuthorityDao.deleteAdminRole(id);
			}

		}
		return result;
	}

	@Override
	public Page<AdminRoleModel> pagingQueryGrantRoles(Integer page, Integer pageSize, Integer actorId, String name,
			Integer dataId) {
		Integer limit = (page - 1) > 0 ? (page - 1) : 0 * pageSize;
		List<AdminRoleModel> resultList = adminAuthorityDao.pagingQueryGrantRolesByUserId(limit, pageSize, actorId,
				AdminRoleModel.CATEGORY, name, dataId);
		Integer count = adminAuthorityDao.pagingQueryGrantRolesByUserId_count(actorId, AdminRoleModel.CATEGORY, name,
				dataId);

		Page<AdminRoleModel> resultPage = new Page<AdminRoleModel>(page, pageSize, count);
		resultPage.setData(resultList);
		return resultPage;
	}

	@Override
	public Page<AdminRoleModel> pagingQueryNotGrantRoles(Integer page, Integer pageSize, Integer actorId, String name,
			Integer dataId) {
		Integer limit = (page - 1) > 0 ? (page - 1) : 0 * pageSize;

		List<AdminRoleModel> resultList = adminAuthorityDao.pagingQueryNotGrantRolesByUserId(limit, pageSize, actorId,
				AdminRoleModel.CATEGORY, name, dataId);
		Integer count = adminAuthorityDao.pagingQueryNotGrantRolesByUserId_count(actorId, AdminRoleModel.CATEGORY, name,
				dataId);

		Page<AdminRoleModel> resultPage = new Page<AdminRoleModel>(page, pageSize, count);
		resultPage.setData(resultList);
		return resultPage;
	}

	@Override
	public void terminateAuthorizationByUserIdAuthorithIds(Integer userId, List<Integer> authorityIds, Integer dataId) {
		adminAuthorizationDao.deleteAuthorizationByActorIdAuthorityIds(userId, authorityIds, dataId);

	}

	@Override
	public List<AdminRoleModel> queryGrantRoles(Integer actorId, Integer dataId) {

		return adminAuthorityDao.queryGrantRolesByUserId(actorId, AdminRoleModel.CATEGORY);
	}

	@Override
	public Page<AdminRoleModel> pagingQueryChannelRoles(Integer dataId, Integer type, Integer page, Integer pageSize) {
		Integer limit = (page - 1) > 0 ? (page - 1) : 0 * pageSize;
		List<AdminRoleModel> resultLists = adminAuthorityDao.pagingQueryRolesByIsAdmin(dataId, type, limit, pageSize);
		Integer resultCount = adminAuthorityDao.pagingQueryRolesByIsAdmin_count(dataId, type);
		Page<AdminRoleModel> resultPage = new Page<AdminRoleModel>(page, pageSize, resultCount);
		resultPage.setData(resultLists);
		return resultPage;

	}

	@Override
	public List<AdminRoleModel> findRoles(Integer dataId) {
		List<AdminRoleModel> roleList = adminAuthorityDao.findRoles(dataId);
		return roleList;
	}

}
