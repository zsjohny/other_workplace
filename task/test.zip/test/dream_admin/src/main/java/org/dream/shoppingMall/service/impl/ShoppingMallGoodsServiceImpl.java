package org.dream.shoppingMall.service.impl;

import java.util.List;

import org.dream.model.shoppingMall.ShoppingMallGoodsModel;
import org.dream.shoppingMall.dao.ShoppingMallGoodsDao;
import org.dream.shoppingMall.service.ShoppingMallGoodsService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShoppingMallGoodsServiceImpl implements ShoppingMallGoodsService {

	public static final Integer SUCCESS_CODE = 200;
	public static final Integer ERROR_CODE = 600;
	public static final Integer STATUS_DISABLE = 1;
	public static final Integer STATUS_ABLE = 0;
	@Autowired
	ShoppingMallGoodsDao shoppingMallGoodsDao;

	@Override
	public Response create(ShoppingMallGoodsModel goodsModel) {
		shoppingMallGoodsDao.create(goodsModel);
		return Response.response(SUCCESS_CODE, "保存商品成功");

	}

	@Override
	public Response update(ShoppingMallGoodsModel goodsModel) {
		shoppingMallGoodsDao.update(goodsModel);
		return Response.response(SUCCESS_CODE, "更新商品成功");
	}

	@Override
	public Response unavailable(List<Integer> idList) {
		shoppingMallGoodsDao.updateStatus(STATUS_DISABLE, idList);
		return Response.response(SUCCESS_CODE, "下架成功");
	}

	@Override
	public Response sale(List<Integer> idList) {
		shoppingMallGoodsDao.updateStatus(STATUS_ABLE, idList);
		return Response.response(SUCCESS_CODE, "上架成功");
	}

	@Override
	public Response pagingQuery(Integer channelId, Integer page, Integer pageSize) {
		Integer limit = page > 0 ? page * pageSize : 0 * pageSize;
		List<ShoppingMallGoodsModel> resultList = shoppingMallGoodsDao.pagingQuery(channelId, limit, pageSize);
		Integer resultCount = shoppingMallGoodsDao.pagingQuery_count(channelId);
		Page<ShoppingMallGoodsModel> result = new Page<ShoppingMallGoodsModel>(page, pageSize, resultCount);
		result.setData(resultList);
		return Response.response(SUCCESS_CODE, "查询商品成功", result);
	}

	@Override
	public Response delete(Integer id) {
		shoppingMallGoodsDao.delete(STATUS_DISABLE, id);
		return Response.response(SUCCESS_CODE, "删除停用商品成功");
	}

	@Override
	public Response findGoodsById(Integer id,Integer channelId) {
		ShoppingMallGoodsModel result = shoppingMallGoodsDao.findGoodsById(id,channelId);
		return Response.response(SUCCESS_CODE, "查询商品成功", result);
	}

}
