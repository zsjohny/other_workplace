package org.dream.channel.service;

import java.util.List;

import org.dream.model.channel.ChannelPromoterModel;
import org.dream.utils.mvc.Page;

public interface ChannelPromoterService {
	public List<ChannelPromoterModel> findChannelPromoterAll();

	public Page<ChannelPromoterModel> querypaging(Integer channelId, Integer levelId, Integer pageIndex,
			Integer pageSize);

	public void updateChannelPromoter(ChannelPromoterModel channelPromoterModel);

	public Page<ChannelPromoterModel> qureypagingSonUser(Integer promoterId, Integer pageIndex, Integer pageSize);

	public Integer getPromoterIdByUserId(Integer userId);
}
