package org.dream.order.service;

import org.dream.model.order.QuotationConfigureModel;
import org.dream.utils.mvc.Page;

/**
 * 行情配置Service
 * 
 * @author wangd
 *
 */
public interface QuotationConfigureService {

	public void saveQuotationConfigure(QuotationConfigureModel quotationConfigureModel);

	public void updateQuotationConfigure(QuotationConfigureModel quotationConfigureModel);

	public void delteByIds(String ids);

	public QuotationConfigureModel getBy(Integer id);

	public Page<QuotationConfigureModel> querypaging(Integer exchangeId, Integer pageIndex, Integer pageSize);

	public Integer getVarietyCount(Integer varietyId);
}
