package org.dream.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.finance.dao.FinanceAccDao;
import org.dream.finance.dao.FinanceDrawDao;
import org.dream.finance.dao.FinanceFlowDao;
import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.dao.FinanceMainDao;
import org.dream.finance.dao.FinancePayPlatformBankDao;
import org.dream.finance.dao.FinanceTransferDao;
import org.dream.finance.service.BasicFinanceService;
import org.dream.model.finance.FinanceAccModel;
import org.dream.model.finance.FinanceDrawModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.model.push.PushModel;
import org.dream.model.user.UserBankCardModel;
import org.dream.model.user.UserModel;
import org.dream.user.dao.UserBankCardDao;
import org.dream.user.dao.UserDao;
import org.dream.utils.constants.FinanceIOType;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceSystemType;
import org.dream.utils.constants.FinanceTransferType;
import org.dream.utils.constants.FinanceType;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.math.Arith;
import org.dream.utils.validate.ValidateModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

@Service
public class BasicFinanceServiceImpl implements BasicFinanceService {
	@Autowired
	private FinanceIODao financeIODao;
	@Autowired
	private FinanceMainDao financeMainDao;
	@Autowired
	private FinanceFlowDao financeFlowDao;
	@Autowired
	private FinanceAccDao financeAccDao;
	@Autowired
	private FinanceDrawDao financeDrawDao;
	@Autowired
	private FinanceTransferDao transferDao;
	@Autowired
	private UserBankCardDao bankCardDao;
	@Autowired
	private FinancePayPlatformBankDao payPlatformBankDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	@Qualifier(value = "jmsSenderForPush")
	private JmsSender jmsSender;

	@Override
	public FinanceMainModel findMain(Integer userId) {
		return financeMainDao.find(userId);
	}

	@Override
	public FinanceAccModel findAcc(Integer userId) {
		return financeAccDao.find(userId);
	}

	@Override
	public List<FinanceDrawModel> findDrawByPage(Integer status, Integer channelId, Integer offset, Integer pageSize) {
		return financeDrawDao.findByPage(status, channelId, offset, pageSize);
	}

	@Override
	public Integer findDrawRows(Integer status, Integer channelId) {
		return financeDrawDao.findRows(status, channelId);
	}

	@Override
	public void checkDraw(Integer status, List<Integer> idList) {
		if (status == 4) {
			List<FinanceIOModel> list = financeIODao.findByIds(idList);
			for (FinanceIOModel financeIOModel : list) {
				Integer userId = financeIOModel.getUserId();
				Double money = financeIOModel.getMoney();
				FinanceMainModel financeMainModel = financeMainDao.find(userId);
				Double moneyUsable = Arith.add(financeMainModel.getMoneyUsable(), money);
				financeMainModel.setMoneyUsable(moneyUsable);
				financeMainModel.setMoneyDrawUsable(moneyUsable);
				Double moneyFrozen = Arith.subtract(financeMainModel.getMoneyFrozen(), money);
				financeMainModel.setMoneyFrozen(moneyFrozen);
				financeMainDao.update(financeMainModel);
				FinanceFlowModel financeFlowModel = new FinanceFlowModel();
				financeFlowModel.setUserId(userId);
				financeFlowModel.setType(FinanceIOType.DRAW_REFUSE.getType());
				financeFlowModel.setTypeDetail(FinanceIOType.DRAW_REFUSE.getTypeDetail());
				financeFlowModel.setRemark(FinanceIOType.DRAW_REFUSE.getRemark());
				financeFlowModel.setMoney(money);
				financeFlowModel.setMoneyLeft(moneyUsable);
				financeFlowModel.setRedbagLeft(financeMainModel.getRedbagUsable());
				financeFlowModel.setIoOrderId(financeIOModel.getId());
				financeFlowDao.save(financeFlowModel);
				String msg = "您的提现审核未通过，可能您的账号存在异常，如有异议请联系客服处理。";
				String topic = "提现拒绝";
				push(financeIOModel.getUserId(), money, msg, topic, false);
			}
		} else if (status == 3) {
			List<FinanceIOModel> list = financeIODao.findByIds(idList);
			FinanceTransferManageModel transferModel = new FinanceTransferManageModel();
			for (FinanceIOModel financeIOModel : list) {
				if (financeIOModel.getStatus() != 2 && financeIOModel.getStatus() != 5) {
					continue;
				}
				transferModel.setIoId(financeIOModel.getId());
				transferModel.setStatus(3);
				transferModel.setSelfOrderId(financeIOModel.getSelfOrderId());
				transferDao.update(transferModel);
				Integer userId = financeIOModel.getUserId();
				Double money = financeIOModel.getMoney();
				FinanceMainModel mainModel = financeMainDao.find(userId);
				Double moneyFrozen = Arith.subtract(mainModel.getMoneyFrozen(), money);
				mainModel.setMoneyFrozen(moneyFrozen);
				financeMainDao.update(mainModel);
				FinanceAccModel accModel = financeAccDao.find(userId);
				accModel.setDrawMoney(Arith.add(accModel.getDrawMoney(), money));
				financeAccDao.update(accModel);
				UserBankCardModel bankCardModel = new UserBankCardModel();
				bankCardModel.setIdStatus(2);
				bankCardModel.setCardState(2);
				bankCardModel.setUserId(userId);
				bankCardDao.update(bankCardModel);
			}
		} else if (status == 5) {
			List<FinanceIOModel> list = financeIODao.findByIds(idList);
			FinanceTransferManageModel transferModel = new FinanceTransferManageModel();
			for (FinanceIOModel financeIOModel : list) {
				if (financeIOModel.getStatus() != 2) {
					continue;
				}
				transferModel.setIoId(financeIOModel.getId());
				transferModel.setStatus(5);
				transferModel.setSelfOrderId(financeIOModel.getSelfOrderId());
				transferDao.update(transferModel);
			}
		} else if (status == 1) {
			List<FinanceIOModel> list = financeIODao.findByIds(idList);
			FinanceTransferManageModel transferModel = new FinanceTransferManageModel();
			for (FinanceIOModel financeIOModel : list) {
				Double money = financeIOModel.getMoney();
				String msg = "您申请的提现" + money + "元已审核通过,系统将于1-2个工作日转入您绑定的银行账户。请注意查收。";
				String topic = "提现审核通过";
				push(financeIOModel.getUserId(), money, msg, topic, true);
			}
		}
		financeIODao.updateByIOIds(status, idList);
	}

	private void push(Integer userId, Double money, String msg, String topic, boolean success) {
		PushModel pushModel = new PushModel();
		pushModel.setUserId(userId);
		UserModel userModel = new UserModel();
		userModel.setId(userId);
		ValidateModel validateModel = userDao.validate(userModel);
		pushModel.setChannelId(validateModel.getChannelId());
		pushModel.setPushMsg(msg);
		pushModel.setPushTopic(topic);
		pushModel.setPushContent(msg);
		pushModel.setTaskType(PushModel.WITHDRAM_TASK);
		pushModel.setPushType(PushModel.TRADE_INFO);
		pushModel.setSuccess(success);
		jmsSender.sendMessage(JSONObject.toJSONString(pushModel));
	}

	@Override
	public void transferNotify(Integer transferId, String selfOrderId, String thirdOrderId, Double money,
			Integer status, FinanceIOType financeIOType) {
		FinanceTransferModel transferModel = transferDao.findById(transferId);
		FinanceIOModel ioModel = financeIODao.findByTransferIOId(transferModel.getIoId());
		Integer userId = ioModel.getUserId();
		// 转账成功修改main表
		if (status == 3) {
			FinanceMainModel mainModel = financeMainDao.find(userId);
			Double moneyFrozen = Arith.subtract(mainModel.getMoneyFrozen(), money);
			mainModel.setMoneyFrozen(moneyFrozen);
			financeMainDao.update(mainModel);
			FinanceAccModel accModel = financeAccDao.find(userId);
			accModel.setDrawMoney(Arith.add(accModel.getDrawMoney(), money));
			financeAccDao.update(accModel);
			UserBankCardModel bankCardModel = new UserBankCardModel();
			bankCardModel.setIdStatus(2);
			bankCardModel.setCardState(2);
			bankCardModel.setUserId(userId);
			bankCardDao.update(bankCardModel);
		}
		financeIODao.update(status, thirdOrderId, selfOrderId);
	}

	@Override
	public List<FinanceFlowManageModel> findFlowByPage(String createTimeStart, String createTimeEnd, Integer userId,
			String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, Integer offset, Integer pageSize, String flow) {
		return financeFlowDao.findByPage(createTimeStart, createTimeEnd, userId, userName, userPhone, channelId,
				topChannelId, type, typeDetail, remark, offset, pageSize, flow);
	}

	@Override
	public Integer findFlowRows(String createTimeStart, String createTimeEnd, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, Integer type, Integer typeDetail, String remark,
			String flow) {
		return financeFlowDao.findRows(createTimeStart, createTimeEnd, userId, userName, userPhone, channelId,
				topChannelId, type, typeDetail, remark, flow);
	}

	@Override
	public List<FinanceIOManageModel> findIOByPage(FinanceIOManageModel model, Integer offset, Integer pageSize) {
		return financeIODao.findByPage(model, offset, pageSize);
	}

	@Override
	public Integer findIORows(FinanceIOManageModel model) {
		return financeIODao.findRows(model);
	}

	@Override
	public List<FinanceTransferModel> saveTransfer(List<Integer> idList, FinanceTransferType transferType,
			FinancePayType payType, String operator) {
		List<FinanceTransferModel> list = new ArrayList<FinanceTransferModel>();
		List<FinanceIOModel> ioModels = financeIODao.findByIds(idList);
		for (FinanceIOModel ioModel : ioModels) {
			if (ioModel.getStatus() != 1) {
				continue;
			}
			FinanceTransferModel transferModel = new FinanceTransferModel();
			transferModel.setIoId(ioModel.getId());
			transferModel.setTypeDetail(transferType.getTypeDetail());
			transferModel.setRemark(transferType.getRemark());
			transferModel.setUserId(ioModel.getUserId());
			transferModel.setMoney(ioModel.getMoney());
			transferModel.setCommission(ioModel.getCommission());
			transferModel.setSelfOrderId(ioModel.getSelfOrderId());
			transferModel.setStatus(ioModel.getStatus());
			UserBankCardModel bankCardModel = bankCardDao.find(ioModel.getUserId());
			FinancePayPlatformBankModel payPlatformBankModel = new FinancePayPlatformBankModel();
			payPlatformBankModel.setPayPlatform(payType.getPlatform());
			payPlatformBankModel.setBankId(bankCardModel.getBankId());
			payPlatformBankModel.setStatus(0);
			payPlatformBankModel = payPlatformBankDao.find(payPlatformBankModel);
			transferModel.setRealName(bankCardModel.getRealName());
			transferModel.setCardNo(bankCardModel.getCardNumber());
			transferModel.setBankName(payPlatformBankModel.getBankName());
			transferModel.setCardPhone(bankCardModel.getCardPhone());
			transferModel.setOperator(operator);
			list.add(transferModel);
		}
		if (list.size() > 0) {
			transferDao.save(list);
			financeIODao.updateByIOIds(2, idList);
		}
		return list;
	}

	public static void main(String[] args) {
		String conf = "classpath:app*.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(conf);
		BasicFinanceService financeService = context.getBean(BasicFinanceService.class);
		financeService.transferNotify(1, "tx321470103025879", "1699080296302493308", 0.01, 3, null);
	}

	@Override
	public List<FinanceTransferManageModel> findTransferByPage(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId, Integer offset,
			Integer pageSize) {
		return transferDao.findByPage(userId, userName, userPhone, realName, transferType, status, operator,
				createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd, topChannelId, offset, pageSize);
	}

	@Override
	public Integer findTransferRows(Integer userId, String userName, String userPhone, String realName,
			String transferType, Integer status, String operator, String createTimeStart, String createTimeEnd,
			String updateTimeStart, String updateTimeEnd, Integer topChannelId) {
		return transferDao.findRows(userId, userName, userPhone, realName, transferType, status, operator,
				createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd, topChannelId);
	}

	@Override
	public FinanceTransferManageModel findTransfer(Integer topChannelId, Integer transferId) {
		return transferDao.find(topChannelId, transferId);
	}

	@Override
	public FinanceIOManageModel findById(Integer id) {
		return financeIODao.findById(id);
	}

	// V2
	@Override
	public void systemMakeMoney(Integer id, Double money) {
		// 补单成功修改io表
		FinanceIOModel ioModel = new FinanceIOModel();
		ioModel = financeIODao.findById(id);
		if (ioModel.getStatus() == 3) {
			return;
		}
		ioModel.setStatus(3);
		ioModel.setThirdOrderId("bd" + ioModel.getUserId() + System.currentTimeMillis());
		financeIODao.updateById(ioModel);
		Integer userId = ioModel.getUserId();
		// 修改main表
		FinanceMainModel mainModel = financeMainDao.find(userId);
		Double moneyUsable = Arith.add(mainModel.getMoneyUsable(), money);
		mainModel.setMoneyUsable(moneyUsable);
		Double moneyDrawUsable = Arith.add(mainModel.getMoneyDrawUsable(), money);
		mainModel.setMoneyDrawUsable(moneyDrawUsable);
		financeMainDao.update(mainModel);
		// 增加flow信息
		FinanceFlowModel flowModel = new FinanceFlowModel();
		flowModel.setUserId(userId);
		flowModel.setType(FinanceSystemType.MAKE_MONEY.getType());
		flowModel.setTypeDetail(FinanceSystemType.MAKE_MONEY.getTypeDetail());
		flowModel.setRemark(FinanceSystemType.MAKE_MONEY.getRemark());
		flowModel.setMoney(money);
		flowModel.setMoneyLeft(moneyUsable);
		flowModel.setRedbag(0.0);
		flowModel.setRedbagLeft(mainModel.getRedbagUsable());
		flowModel.setIoOrderId(id);
		financeFlowDao.save(flowModel);
		// 修改acc表
		FinanceAccModel accModel = financeAccDao.find(userId);
		accModel.setUserId(userId);
		Double depositMoney = Arith.add(accModel.getDepositMoney(), money);
		accModel.setDepositMoney(depositMoney);
		financeAccDao.update(accModel);
	}

	// ***************************************************************************************
}
