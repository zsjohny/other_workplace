package org.dream.sms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.dream.model.sms.SmsSenderTemplate;
import org.dream.model.sms.SmsTemplate;
import org.dream.sms.dao.SmsSenderTemplateDao;
import org.dream.sms.dao.SmsTemplateDao;
import org.dream.sms.service.SmsTemplateService;
import org.dream.utils.jms.JmsSender;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class SmsTemplateServiceImpl implements SmsTemplateService {

	@Resource(name = "smsTempalteChangendSender")
	JmsSender jmsSender;

	@Autowired
	SmsTemplateDao smsTemplateDao;

	@Autowired
	SmsSenderTemplateDao smsSenderTemplateDao;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	public static final String REDIS_KEY = "sms:";
	public static final String SENDER_TEMPLATE = "sms_sender_template";
	public static final Integer SMS_ISDELETE = 1;// 表示未删除状态

	@Override
	public void addTemplate(SmsTemplate smsTemplate) {
		smsTemplateDao.createTemplate(smsTemplate);

	}

	@Override
	public void updateTemplate(SmsTemplate smsTemplate) {
		smsTemplateDao.updateTemplate(smsTemplate);
		SmsTemplate template = smsTemplateDao.getTemplate(smsTemplate.getId());
		sendMsg(template);

	}

	@Override
	public List<SmsTemplate> getTemplate(Integer channelId) {
		List<SmsTemplate> smsTemplates = smsTemplateDao.getAll(SMS_ISDELETE, channelId);
		return smsTemplates;
	}

	@Override
	public SmsTemplate getById(Integer id) {
		SmsTemplate smsTemplate = smsTemplateDao.getById(id, SMS_ISDELETE);
		return smsTemplate;
	}

	@Override
	public Page<SmsTemplate> pagingQuery(String name, String template, Integer channelId, Integer pageIndex,
			Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<SmsTemplate> smsTemplates = smsTemplateDao.pagingQuery(name, template, SMS_ISDELETE, channelId, limit,
				pageSize);
		int totalCOunt = smsTemplateDao.pagingQuery_count(name, template, SMS_ISDELETE, channelId);
		Page<SmsTemplate> resultPage = new Page<SmsTemplate>(pageIndex, pageSize, totalCOunt);
		resultPage.setData(smsTemplates);
		return resultPage;
	}

	/**
	 * 进行软删除
	 */
	@Override
	public void remove(Integer id) {
		smsTemplateDao.remove(id);
		smsSenderTemplateDao.removeByTemplateId(id);
		SmsTemplate template = smsTemplateDao.getTemplate(id);
		HashOperations<String, String, SmsSenderTemplate> hashOperations = redisTemplate.opsForHash();
		String redisSmsMsgKey = REDIS_KEY + SENDER_TEMPLATE;
		List<SmsSenderTemplate> list = smsSenderTemplateDao.getAll(SMS_ISDELETE, null, id);
		if (list != null) {
			for (SmsSenderTemplate senderTemplate : list) {
				Integer channelId = senderTemplate.getChannelId();
				Integer type = senderTemplate.getType();
				hashOperations.delete(redisSmsMsgKey, "" + id + channelId + type);
			}
		}
		sendMsg(template);
	}

	/**
	 * 当后台发生改变或删除时 发送信息
	 * 
	 * @param smsTemplate
	 */
	private void sendMsg(SmsTemplate smsTemplate) {
		jmsSender.sendMessage(JSON.toJSONString(smsTemplate));
	}

	@Override
	public boolean hasSmsTemplate(String name, Integer channelId) {
		return smsTemplateDao.pagingQuery_count(name, null, SMS_ISDELETE, channelId) > 0;
	}

	@Override
	public SmsTemplate findTemplate(String name, String template, Integer channelId) {
		return smsTemplateDao.findTemplate(name, template, channelId);
	}

}
