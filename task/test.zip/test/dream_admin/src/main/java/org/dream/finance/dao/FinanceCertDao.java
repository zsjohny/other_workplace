package org.dream.finance.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformModel;

public interface FinanceCertDao {
	// V3
	public List<FinancePayPlatformModel> findPayPlatformByCert(FinanceCertModel certModel);
	// ********************************************************************

	// V2
	public List<FinanceCertModel> findByPage(@Param("model") FinanceCertModel certModel,
			@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

	public Integer findRows(@Param("model") FinanceCertModel certModel);

	public FinanceCertModel find(FinanceCertModel certModel);

	public Integer save(FinanceCertModel certModel);

	public Integer update(FinanceCertModel certModel);

	public List<String> findPlatformAll(FinanceCertModel certModel);

	// *************************************************
}
