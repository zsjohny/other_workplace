package org.dream.admin.controller;

import org.dream.config.model.SystemConfigModel;
import org.dream.config.service.SystemConfigService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/systemConfig")
public class SystemConfigController {

    @Autowired
    SystemConfigService systemConfigService;

    @RequestMapping(value = "/saveSystemConfig", method = { RequestMethod.POST })
    @ResponseBody
    public Response saveSystemConfig(String key, String value, String remark,String configSystem) throws Exception {

	Assert.notNull("key", "要保存的配置的名称不能为空");

	SystemConfigModel systemConfigModel = systemConfigService.getByKey(key);
	if (systemConfigModel == null) {
	    systemConfigModel = new SystemConfigModel();
	    systemConfigModel.setConfigKey(key);
	    systemConfigModel.setConfigValue(value);
	    systemConfigModel.setRemark(remark);
	    systemConfigModel.setConfigSystem(configSystem);
	    systemConfigService.saveSystemConfig(systemConfigModel);
	} else {
	    return Response.error("保存失败，已存在相同的配置名称");
	}

	return Response.success();
    }

    @RequestMapping(value = "/updateSystemConfig", method = { RequestMethod.POST })
    @ResponseBody
    public Response updateSystemConfig(Integer id, String key, String value, String remark,String configSystem) throws Exception {

	Assert.notNull(id, "要修改的纪录id不能为空");

	systemConfigService.updateSystemConfig(id, key, value, remark,configSystem);
	return Response.success();
    }

    /**
     * 
     * @param ids
     * @param request
     * @throws Exception
     */
    @RequestMapping(value = "/deleteSystemConfig", method = { RequestMethod.POST })
    @ResponseBody
    public Response deleteSystemConfig(String ids) throws Exception {
	Assert.notNull(ids, "要删除的id不能为空");
	systemConfigService.deleteByIds(ids);
	return Response.success();
    }

    /**
     * 分页查询
     * 
     * @param page
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
    @ResponseBody
    public Response querypaging(Integer page, Integer pageSize) {

	Page<SystemConfigModel> systemConfig = systemConfigService.querypaging(page, pageSize);
	return Response.success(systemConfig);
    }
}
