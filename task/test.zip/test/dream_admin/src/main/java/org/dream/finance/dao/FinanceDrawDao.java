package org.dream.finance.dao;

import java.util.List;

import org.dream.model.finance.FinanceDrawModel;

public interface FinanceDrawDao {
	public List<FinanceDrawModel> findByPage(Integer status, Integer channelId, Integer offset, Integer pageSize);

	public Integer findRows(Integer status, Integer channelId);
}
