package org.dream.finance.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.dream.finance.service.FinanceProduceExcelService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/finance")
public class FinanceProduceExcelController extends BaseController {

	@Autowired
	private FinanceProduceExcelService financeProduceExcelService;

	/**
	 * 现金流水
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/importExcel")
	public Response importExcelFlow(HttpServletRequest request, HttpServletResponse response, String createTimeStart,
			String createTimeEnd, Integer userId, String userName, String userPhone, Integer channelId,
			Integer topChannelId, Integer type, Integer typeDetail, String remark, String flow) throws Exception {
		flow = "money";
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		if (level == 1) {
			topChannelId = id;
		} else if (level == 2) {
			channelId = id;
		}
		// 获得要导出的数据集
		List<FinanceFlowManageModel> list = financeProduceExcelService.findAllFlow(createTimeStart, createTimeEnd,
				userId, userName, userPhone, channelId, topChannelId, type, typeDetail, remark, flow);
		// 创建excel工作簿
		Workbook wb = new HSSFWorkbook();
		// 创建第一个sheet（页），并命名
		Sheet sheet = wb.createSheet();
		// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
		sheet.setColumnWidth((short) 0, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 1, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 2, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 3, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 4, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 5, (short) (35.7 * 150));
		sheet.setColumnWidth((short) 6, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 7, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 8, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 9, (short) (35.7 * 150));

		// 创建第一行
		Row row = sheet.createRow((short) 0);

		// 创建两种单元格格式
		CellStyle cs = wb.createCellStyle();
		CellStyle cs2 = wb.createCellStyle();
		DataFormat df = wb.createDataFormat();

		// 创建两种字体
		Font f = wb.createFont();
		Font f2 = wb.createFont();

		// 创建第一种字体样式
		f.setFontHeightInPoints((short) 10);
		f.setColor(IndexedColors.RED.getIndex());
		f.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 创建第二种字体样式
		f2.setFontHeightInPoints((short) 10);
		f2.setColor(IndexedColors.BLACK.getIndex());
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 设置第一种单元格的样式
		cs.setFont(f);
		cs.setBorderLeft(CellStyle.BORDER_THIN);
		cs.setBorderRight(CellStyle.BORDER_THIN);
		cs.setBorderTop(CellStyle.BORDER_THIN);
		cs.setBorderBottom(CellStyle.BORDER_THIN);
		cs.setDataFormat(df.getFormat("#,##0.0"));
		cs.setAlignment(CellStyle.ALIGN_CENTER);
		// 设置第二种单元格的样式
		cs2.setFont(f2);
		cs2.setBorderLeft(CellStyle.BORDER_THIN);
		cs2.setBorderRight(CellStyle.BORDER_THIN);
		cs2.setBorderTop(CellStyle.BORDER_THIN);
		cs2.setBorderBottom(CellStyle.BORDER_THIN);
		cs2.setDataFormat(df.getFormat("text"));
		cs2.setAlignment(CellStyle.ALIGN_CENTER);
		// 创建列（每行里的单元格）
		Cell cell = row.createCell(0);
		cell.setCellValue("用户ID");
		cell.setCellStyle(cs);

		cell = row.createCell(1);
		cell.setCellValue("流水ID");
		cell.setCellStyle(cs);

		cell = row.createCell(2);
		cell.setCellValue("昵称");
		cell.setCellStyle(cs);

		cell = row.createCell(3);
		cell.setCellValue("收/支");
		cell.setCellStyle(cs);

		cell = row.createCell(4);
		cell.setCellValue("现金余额");
		cell.setCellStyle(cs);

		cell = row.createCell(5);
		cell.setCellValue("流水详情");
		cell.setCellStyle(cs);

		cell = row.createCell(6);
		cell.setCellValue("一级渠道");
		cell.setCellStyle(cs);

		cell = row.createCell(7);
		cell.setCellValue("二级渠道");
		cell.setCellStyle(cs);

		cell = row.createCell(8);
		cell.setCellValue("关联订单号");
		cell.setCellStyle(cs);

		cell = row.createCell(9);
		cell.setCellValue("创建时间");
		cell.setCellStyle(cs);
		DateFormat date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		for (int i = 0; i < list.size(); i++) {
			// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的
			// 创建一行，在页sheet上
			row = sheet.createRow(i + 1);
			// 在row行上创建一个方格
			cell = row.createCell(0);
			cell.setCellValue(list.get(i).getUserId());
			cell.setCellStyle(cs2);

			cell = row.createCell(1);
			cell.setCellValue(list.get(i).getId());
			cell.setCellStyle(cs2);

			cell = row.createCell(2);
			cell.setCellValue(list.get(i).getUserName());
			cell.setCellStyle(cs2);

			cell = row.createCell(3);
			cell.setCellValue((list.get(i).getTypeDetail() > 0 ? list.get(i).getMoney() : -list.get(i).getMoney()));
			cell.setCellStyle(cs2);

			cell = row.createCell(4);
			cell.setCellValue(list.get(i).getMoneyLeft());
			cell.setCellStyle(cs2);

			cell = row.createCell(5);
			cell.setCellValue(list.get(i).getRemark());
			cell.setCellStyle(cs2);

			cell = row.createCell(6);
			cell.setCellValue(list.get(i).getTopChannelName());
			cell.setCellStyle(cs2);

			cell = row.createCell(7);
			cell.setCellValue(list.get(i).getChannelName());
			cell.setCellStyle(cs2);

			cell = row.createCell(8);
			cell.setCellValue(list.get(i).getcOrderId());
			cell.setCellStyle(cs2);

			cell = row.createCell(9);
			cell.setCellValue(date.format(list.get(i).getCreateTime()));
			cell.setCellStyle(cs2);
		}
		String str = "现金流水";
		this.giveExcelBack(response, str, wb);
		return null;
	}

	/**
	 * 明细提现
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/importExcelDraw")
	public Response importExcelDraw(HttpServletRequest request, HttpServletResponse response,
			FinanceIOManageModel model) throws Exception {
		model.setType(-1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		if (level == 1) {
			model.setTopChannelId(id);
		} else if (level == 2) {
			model.setChannelId(id);
		}
		// 获得要导出的数据集
		List<FinanceIOManageModel> list = financeProduceExcelService.findAllIO(model);
		// 创建excel工作簿
		Workbook wb = new HSSFWorkbook();
		// 创建第一个sheet（页），并命名
		Sheet sheet = wb.createSheet();
		// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
		sheet.setColumnWidth((short) 0, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 1, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 2, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 3, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 4, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 5, (short) (35.7 * 150));
		sheet.setColumnWidth((short) 6, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 7, (short) (35.7 * 150));
		sheet.setColumnWidth((short) 8, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 9, (short) (35.7 * 150));
		sheet.setColumnWidth((short) 10, (short) (35.7 * 150));

		// 创建第一行
		Row row = sheet.createRow((short) 0);

		// 创建两种单元格格式
		CellStyle cs = wb.createCellStyle();
		CellStyle cs2 = wb.createCellStyle();
		DataFormat df = wb.createDataFormat();

		// 创建两种字体
		Font f = wb.createFont();
		Font f2 = wb.createFont();

		// 创建第一种字体样式
		f.setFontHeightInPoints((short) 10);
		f.setColor(IndexedColors.RED.getIndex());
		f.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 创建第二种字体样式
		f2.setFontHeightInPoints((short) 10);
		f2.setColor(IndexedColors.BLACK.getIndex());
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 设置第一种单元格的样式
		cs.setFont(f);
		cs.setBorderLeft(CellStyle.BORDER_THIN);
		cs.setBorderRight(CellStyle.BORDER_THIN);
		cs.setBorderTop(CellStyle.BORDER_THIN);
		cs.setBorderBottom(CellStyle.BORDER_THIN);
		cs.setDataFormat(df.getFormat("#,##0.0"));
		cs.setAlignment(CellStyle.ALIGN_CENTER);
		// 设置第二种单元格的样式
		cs2.setFont(f2);
		cs2.setBorderLeft(CellStyle.BORDER_THIN);
		cs2.setBorderRight(CellStyle.BORDER_THIN);
		cs2.setBorderTop(CellStyle.BORDER_THIN);
		cs2.setBorderBottom(CellStyle.BORDER_THIN);
		cs2.setDataFormat(df.getFormat("text"));
		cs2.setAlignment(CellStyle.ALIGN_CENTER);
		// 创建列（每行里的单元格）
		Cell cell = row.createCell(0);
		cell.setCellValue("昵称");
		cell.setCellStyle(cs);

		cell = row.createCell(1);
		cell.setCellValue("流水ID");
		cell.setCellStyle(cs);

		cell = row.createCell(2);
		cell.setCellValue("姓名");
		cell.setCellStyle(cs);

		cell = row.createCell(3);
		cell.setCellValue("提现金额");
		cell.setCellStyle(cs);

		cell = row.createCell(4);
		cell.setCellValue("可用余额");
		cell.setCellStyle(cs);

		cell = row.createCell(5);
		cell.setCellValue("状态");
		cell.setCellStyle(cs);

		cell = row.createCell(6);
		cell.setCellValue("二级渠道");
		cell.setCellStyle(cs);

		cell = row.createCell(7);
		cell.setCellValue("订单Id");
		cell.setCellStyle(cs);

		cell = row.createCell(8);
		cell.setCellValue("银行名称");
		cell.setCellStyle(cs);

		cell = row.createCell(9);
		cell.setCellValue("创建时间");
		cell.setCellStyle(cs);

		cell = row.createCell(10);
		cell.setCellValue("更新时间");
		cell.setCellStyle(cs);
		DateFormat date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		for (int i = 0; i < list.size(); i++) {
			// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的
			// 创建一行，在页sheet上
			row = sheet.createRow(i + 1);
			// 在row行上创建一个方格
			cell = row.createCell(0);
			cell.setCellValue(list.get(i).getUserName());
			cell.setCellStyle(cs2);

			cell = row.createCell(1);
			cell.setCellValue(list.get(i).getId());
			cell.setCellStyle(cs2);

			cell = row.createCell(2);
			cell.setCellValue(list.get(i).getRealName());
			cell.setCellStyle(cs2);

			cell = row.createCell(3);
			cell.setCellValue((list.get(i)).getMoney());
			cell.setCellStyle(cs2);

			cell = row.createCell(4);
			cell.setCellValue(list.get(i).getMoneyUsable());
			cell.setCellStyle(cs2);

			Integer status = list.get(i).getStatus();
			String remak = "";
			cell = row.createCell(5);
			switch (status) {
			case 0:
				remak = "待审核";
				break;
			case 1:
				remak = "审批通过";
				break;
			case 2:
				remak = "转账中";
				break;
			case 3:
				remak = "提现成功";
				break;
			case 4:
				remak = "提现拒绝";
				break;
			case 5:
				remak = "提现失败";
				break;
			}
			cell.setCellValue(remak);
			cell.setCellStyle(cs2);

			cell = row.createCell(6);
			cell.setCellValue(list.get(i).getChannelName());
			cell.setCellStyle(cs2);

			cell = row.createCell(7);
			cell.setCellValue(list.get(i).getSelfOrderId());
			cell.setCellStyle(cs2);

			cell = row.createCell(8);
			cell.setCellValue(list.get(i).getIssuingBankName());
			cell.setCellStyle(cs2);

			cell = row.createCell(9);
			cell.setCellValue(date.format(list.get(i).getCreateTime()));
			cell.setCellStyle(cs2);

			cell = row.createCell(10);
			cell.setCellValue(date.format(list.get(i).getUpdateTime()));
			cell.setCellStyle(cs2);
		}
		String str = "明细提现";
		this.giveExcelBack(response, str, wb);
		return null;
	}

	/**
	 * 明细充值
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/importExcelDeposit")
	public Response importExcelDeposit(HttpServletRequest request, HttpServletResponse response,
			FinanceIOManageModel model) throws Exception {
		model.setType(1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		if (level == 1) {
			model.setTopChannelId(id);
		} else if (level == 2) {
			model.setChannelId(id);
		}
		// 获得要导出的数据集
		List<FinanceIOManageModel> list = financeProduceExcelService.findAllIO(model);
		// 创建excel工作簿
		Workbook wb = new HSSFWorkbook();
		// 创建第一个sheet（页），并命名
		Sheet sheet = wb.createSheet();
		// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
		sheet.setColumnWidth((short) 0, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 1, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 2, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 3, (short) (35.7 * 200));
		sheet.setColumnWidth((short) 4, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 5, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 6, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 7, (short) (35.7 * 150));

		// 创建第一行
		Row row = sheet.createRow((short) 0);

		// 创建两种单元格格式
		CellStyle cs = wb.createCellStyle();
		CellStyle cs2 = wb.createCellStyle();
		DataFormat df = wb.createDataFormat();

		// 创建两种字体
		Font f = wb.createFont();
		Font f2 = wb.createFont();

		// 创建第一种字体样式
		f.setFontHeightInPoints((short) 10);
		f.setColor(IndexedColors.RED.getIndex());
		f.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 创建第二种字体样式
		f2.setFontHeightInPoints((short) 10);
		f2.setColor(IndexedColors.BLACK.getIndex());
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 设置第一种单元格的样式
		cs.setFont(f);
		cs.setBorderLeft(CellStyle.BORDER_THIN);
		cs.setBorderRight(CellStyle.BORDER_THIN);
		cs.setBorderTop(CellStyle.BORDER_THIN);
		cs.setBorderBottom(CellStyle.BORDER_THIN);
		cs.setDataFormat(df.getFormat("#,##0.0"));
		cs.setAlignment(CellStyle.ALIGN_CENTER);
		// 设置第二种单元格的样式
		cs2.setFont(f2);
		cs2.setBorderLeft(CellStyle.BORDER_THIN);
		cs2.setBorderRight(CellStyle.BORDER_THIN);
		cs2.setBorderTop(CellStyle.BORDER_THIN);
		cs2.setBorderBottom(CellStyle.BORDER_THIN);
		cs2.setDataFormat(df.getFormat("text"));
		cs2.setAlignment(CellStyle.ALIGN_CENTER);
		// 创建列（每行里的单元格）
		Cell cell = row.createCell(0);
		cell.setCellValue("流水ID");
		cell.setCellStyle(cs);

		cell = row.createCell(1);
		cell.setCellValue("昵称");
		cell.setCellStyle(cs);

		cell = row.createCell(2);
		cell.setCellValue("充值方式");
		cell.setCellStyle(cs);

		cell = row.createCell(3);
		cell.setCellValue("内部订单id");
		cell.setCellStyle(cs);

		cell = row.createCell(4);
		cell.setCellValue("充值金额");
		cell.setCellStyle(cs);

		cell = row.createCell(5);
		cell.setCellValue("状态");
		cell.setCellStyle(cs);

		cell = row.createCell(6);
		cell.setCellValue("渠道名称");
		cell.setCellStyle(cs);

		cell = row.createCell(7);
		cell.setCellValue("创建时间");
		cell.setCellStyle(cs);
		DateFormat date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		for (int i = 0; i < list.size(); i++) {
			// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的
			// 创建一行，在页sheet上
			row = sheet.createRow(i + 1);
			// 在row行上创建一个方格
			cell = row.createCell(0);
			cell.setCellValue(list.get(i).getId());
			cell.setCellStyle(cs2);

			cell = row.createCell(1);
			cell.setCellValue(list.get(i).getUserName());
			cell.setCellStyle(cs2);

			cell = row.createCell(2);
			cell.setCellValue(list.get(i).getRemark());
			cell.setCellStyle(cs2);

			cell = row.createCell(3);
			cell.setCellValue((list.get(i)).getSelfOrderId());
			cell.setCellStyle(cs2);

			cell = row.createCell(4);
			cell.setCellValue(list.get(i).getMoney());
			cell.setCellStyle(cs2);

			Integer status = list.get(i).getStatus();
			String remak = "";
			cell = row.createCell(5);
			switch (status) {
			case 0:
				remak = "发起";
				break;
			case 1:
				remak = "通过审批";
				break;
			case 2:
				remak = "转账中";
				break;
			case 3:
				remak = "成功";
				break;
			case 4:
				remak = "拒绝";
				break;
			case 5:
				remak = "失败";
				break;
			}
			cell.setCellValue(remak);
			cell.setCellStyle(cs2);

			cell = row.createCell(6);
			cell.setCellValue(list.get(i).getChannelName());
			cell.setCellStyle(cs2);

			cell = row.createCell(7);
			cell.setCellValue(date.format(list.get(i).getCreateTime()));
			cell.setCellStyle(cs2);

		}
		String str = "明细充值";
		this.giveExcelBack(response, str, wb);
		return null;
	}

	/**
	 * 明细转账
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/importExcelTransfer")
	public Response importExcelTransfer(HttpServletRequest request, HttpServletResponse response, Integer userId,
			String userName, String userPhone, String realName, String transferType, Integer status, String operator,
			String createTimeStart, String createTimeEnd, String updateTimeStart, String updateTimeEnd)
			throws Exception {
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// 获得要导出的数据集
		List<FinanceTransferManageModel> list = financeProduceExcelService.findAllTransfer(userId, userName, userPhone,
				realName, transferType, status, operator, createTimeStart, createTimeEnd, updateTimeStart,
				updateTimeEnd, channelId);
		// 创建excel工作簿
		Workbook wb = new HSSFWorkbook();
		// 创建第一个sheet（页），并命名
		Sheet sheet = wb.createSheet();
		// 手动设置列宽。第一个参数表示要为第几列设；，第二个参数表示列的宽度，n为列高的像素数。
		sheet.setColumnWidth((short) 0, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 1, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 2, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 3, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 4, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 5, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 6, (short) (35.7 * 200));
		sheet.setColumnWidth((short) 7, (short) (35.7 * 200));
		sheet.setColumnWidth((short) 8, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 9, (short) (35.7 * 100));
		sheet.setColumnWidth((short) 10, (short) (35.7 * 250));
		sheet.setColumnWidth((short) 11, (short) (35.7 * 150));
		sheet.setColumnWidth((short) 12, (short) (35.7 * 150));

		// 创建第一行
		Row row = sheet.createRow((short) 0);

		// 创建两种单元格格式
		CellStyle cs = wb.createCellStyle();
		CellStyle cs2 = wb.createCellStyle();
		DataFormat df = wb.createDataFormat();

		// 创建两种字体
		Font f = wb.createFont();
		Font f2 = wb.createFont();

		// 创建第一种字体样式
		f.setFontHeightInPoints((short) 10);
		f.setColor(IndexedColors.RED.getIndex());
		f.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 创建第二种字体样式
		f2.setFontHeightInPoints((short) 10);
		f2.setColor(IndexedColors.BLACK.getIndex());
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);

		// 设置第一种单元格的样式
		cs.setFont(f);
		cs.setBorderLeft(CellStyle.BORDER_THIN);
		cs.setBorderRight(CellStyle.BORDER_THIN);
		cs.setBorderTop(CellStyle.BORDER_THIN);
		cs.setBorderBottom(CellStyle.BORDER_THIN);
		cs.setDataFormat(df.getFormat("#,##0.0"));
		cs.setAlignment(CellStyle.ALIGN_CENTER);
		// 设置第二种单元格的样式
		cs2.setFont(f2);
		cs2.setBorderLeft(CellStyle.BORDER_THIN);
		cs2.setBorderRight(CellStyle.BORDER_THIN);
		cs2.setBorderTop(CellStyle.BORDER_THIN);
		cs2.setBorderBottom(CellStyle.BORDER_THIN);
		cs2.setDataFormat(df.getFormat("text"));
		cs2.setAlignment(CellStyle.ALIGN_CENTER);
		// 创建列（每行里的单元格）
		Cell cell = row.createCell(0);
		cell.setCellValue("昵称");
		cell.setCellStyle(cs);

		cell = row.createCell(1);
		cell.setCellValue("转账id");
		cell.setCellStyle(cs);

		cell = row.createCell(2);
		cell.setCellValue("姓名");
		cell.setCellStyle(cs);

		cell = row.createCell(3);
		cell.setCellValue("提现金额");
		cell.setCellStyle(cs);

		cell = row.createCell(4);
		cell.setCellValue("提现手续费");
		cell.setCellStyle(cs);

		cell = row.createCell(5);
		cell.setCellValue("一级类型");
		cell.setCellStyle(cs);

		cell = row.createCell(6);
		cell.setCellValue("内部订单号");
		cell.setCellStyle(cs);

		cell = row.createCell(7);
		cell.setCellValue("第三方订单号");
		cell.setCellStyle(cs);

		cell = row.createCell(8);
		cell.setCellValue("转账状态");
		cell.setCellStyle(cs);

		cell = row.createCell(9);
		cell.setCellValue("操作员");
		cell.setCellStyle(cs);

		cell = row.createCell(10);
		cell.setCellValue("备注");
		cell.setCellStyle(cs);

		cell = row.createCell(11);
		cell.setCellValue("创建时间");
		cell.setCellStyle(cs);

		cell = row.createCell(12);
		cell.setCellValue("更新时间");
		cell.setCellStyle(cs);
		DateFormat date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		for (int i = 0; i < list.size(); i++) {
			// Row 行,Cell 方格 , Row 和 Cell 都是从0开始计数的
			// 创建一行，在页sheet上
			row = sheet.createRow(i + 1);
			// 在row行上创建一个方格
			cell = row.createCell(0);
			cell.setCellValue(list.get(i).getUserName());
			cell.setCellStyle(cs2);

			cell = row.createCell(1);
			cell.setCellValue(list.get(i).getId());
			cell.setCellStyle(cs2);

			cell = row.createCell(2);
			cell.setCellValue(list.get(i).getRealName());
			cell.setCellStyle(cs2);

			cell = row.createCell(3);
			cell.setCellValue((list.get(i)).getMoney());
			cell.setCellStyle(cs2);

			cell = row.createCell(4);
			cell.setCellValue(list.get(i).getCommission());
			cell.setCellStyle(cs2);

			cell = row.createCell(5);
			cell.setCellValue(list.get(i).getRemark());
			cell.setCellStyle(cs2);

			cell = row.createCell(6);
			cell.setCellValue(list.get(i).getSelfOrderId());
			cell.setCellStyle(cs2);

			cell = row.createCell(7);
			cell.setCellValue(list.get(i).getThirdOrderId());
			cell.setCellStyle(cs2);

			Integer TransFerStatus = list.get(i).getStatus();
			String remak = "";
			cell = row.createCell(8);
			switch (TransFerStatus) {
			case 2:
				remak = "转账中";
				break;
			case 3:
				remak = "转账成功";
				break;
			case 5:
				remak = "转账失败";
				break;
			}
			cell.setCellValue(remak);
			cell.setCellStyle(cs2);

			cell = row.createCell(9);
			cell.setCellValue(list.get(i).getOperator());
			cell.setCellStyle(cs2);

			cell = row.createCell(10);
			cell.setCellValue(list.get(i).getComments());
			cell.setCellStyle(cs2);

			cell = row.createCell(11);
			cell.setCellValue(date.format(list.get(i).getCreateTime()));
			cell.setCellStyle(cs2);

			cell = row.createCell(12);
			cell.setCellValue(date.format(list.get(i).getUpdateTime()));
			cell.setCellStyle(cs2);

		}
		String str = "明细转账";
		this.giveExcelBack(response, str, wb);
		return null;
	}

	
	private void giveExcelBack(HttpServletResponse response, String str, Workbook wb)
			throws UnsupportedEncodingException, IOException {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			wb.write(os);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte[] content = os.toByteArray();
		InputStream is = new ByteArrayInputStream(content);
		// 设置response参数，可以打开下载页面
		response.reset();
		response.setContentType("application/vnd.ms-excel;charset=utf-8");
		response.setHeader("Content-Disposition",
				"attachment;filename=" + new String((str + ".xls").getBytes(), "iso-8859-1"));
		ServletOutputStream out = response.getOutputStream();
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			bis = new BufferedInputStream(is);
			bos = new BufferedOutputStream(out);
			byte[] buff = new byte[2048];
			int bytesRead;
			// Simple read/write loop.
			while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
				bos.write(buff, 0, bytesRead);
			}
		} catch (final IOException e) {
			throw e;
		} finally {
			if (bis != null)
				bis.close();
			if (bos != null)
				bos.close();
		}
	}
}
