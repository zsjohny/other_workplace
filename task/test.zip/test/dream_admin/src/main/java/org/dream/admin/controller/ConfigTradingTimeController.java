package org.dream.admin.controller;

import java.sql.Timestamp;

import org.apache.commons.lang3.StringUtils;
import org.dream.config.model.TradingTimeModel;
import org.dream.config.service.TradingTimeService;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 交易时间配置Controller
 * 
 * @author wangd
 *
 */
@Controller
@RequestMapping("/configTradingTime")
public class ConfigTradingTimeController {

    @Autowired
    TradingVarietyService tradingVarietyService;

    @Autowired
    TradingTimeService tradingTimeService;

    /**
     * 保存交易时间配置， 对于交易所暂时不做处理，因为交易时间配置给品种 如果需要配置的品种较多可以添加交易所的处理，已达到快速选择品种
     * 
     * @param exchangeId
     * @param varietyId
     * @param timePeriod
     * @param timeTrigger
     * @param action
     * @param remark
     * @return
     */
    @RequestMapping(value = "/saveTradingTime", method = { RequestMethod.POST })
    @ResponseBody
    public Response saveTradingTime(Integer exchangeId, Integer varietyId, String timePeriod, String timeTrigger,
	    Integer action, String remark) {
	Assert.notNull(varietyId, "要配置的品种不能为空");
	Assert.notNull(timePeriod, "交易时间段不能为空");
	Assert.notNull(timeTrigger, "时间验证规则不能为空");
	Assert.notNull(action, "执行的操作不能为空");

	TradingTimeModel timeModel = new TradingTimeModel();
	TradingVarietyModel varietyModel = tradingVarietyService.getById(varietyId);

	if (varietyModel == null) {
	    return Response.error("保存失败，要配置的品种不存在");
	} else {
	    timeModel.setVarietyId(varietyId);
	    timeModel.setVarietyName(varietyModel.getVarietyName());
	    timeModel.setVarietyType(varietyModel.getVarietyType());
	    timeModel.setTimePeriod(timePeriod);
	    timeModel.setTimeTrigger(timeTrigger);
	    timeModel.setAction(action);
	    timeModel.setRemark(remark);
	    timeModel.setCreateDate(new Timestamp(System.currentTimeMillis()));
	    
	    tradingTimeService.saveTradingTimeConfig(timeModel);
	}
	return Response.success();

    }

    /**
     * 
     * @param id
     * @param varietyId
     * @param timePeriod
     * @param timeTrigger
     * @param action
     * @param remark
     * @return
     */
    @RequestMapping(value = "/updateTradingTime", method = { RequestMethod.POST })
    @ResponseBody
    public Response updateTradingTime(Integer id, Integer varietyId, String timePeriod, String timeTrigger,
	    Integer action, String remark) {
	Assert.notNull(id, "要修改的配置id不能为空");

	TradingTimeModel timeModel = new TradingTimeModel();
	TradingVarietyModel varietyModel = tradingVarietyService.getById(varietyId);
	timeModel.setId(id);

	if (varietyModel != null) {
	    timeModel.setVarietyId(varietyId);
	    timeModel.setVarietyName(varietyModel.getVarietyName());
	    timeModel.setVarietyType(varietyModel.getVarietyType());
	}

	timeModel.setTimePeriod(timePeriod);
	timeModel.setTimeTrigger(timeTrigger);
	timeModel.setAction(action);
	timeModel.setRemark(remark);

	tradingTimeService.saveTradingTimeConfig(timeModel);
	return Response.success();

    }

    /**
     * 分页多条件查询
     * 
     * @param varietyId
     * @param action
     * @param remark
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/querypagingTradingTimes", method = { RequestMethod.POST })
    @ResponseBody
    public Response querypagingTradingTimes(Integer varietyId, Integer action, String remark, Integer page,
	    Integer pagesize) {

	if (StringUtils.isNotEmpty(remark)) {
	    remark = "%" + remark + "%";
	}
	Page<TradingTimeModel> tradingTImePage = tradingTimeService.querypaging(varietyId, action, remark, page,
		pagesize);
	return Response.success(tradingTImePage);

    }

    @RequestMapping(value = "/deleteTradingTimeByIds", method = { RequestMethod.POST })
    @ResponseBody
    public Response deleteTradingTimeByIds(String ids) {

	tradingTimeService.delteTradingTimes(ids);
	return Response.success();

    }
    
    /**
     * 修改交易时间的状态
     * 使其生效或失效
     * @param id
     * @param status
     * @return
     */
    @RequestMapping(value = "/changeStatusById", method = { RequestMethod.POST })
    @ResponseBody
    public Response changeStatusById(Integer id, Integer status) {

	tradingTimeService.changeStatus(id, status);
	return Response.success();

    }
}
