package org.dream.push.controller;

import org.apache.commons.lang.StringUtils;
import org.dream.admin.model.AdminUserModel;
import org.dream.model.push.PushModel;
import org.dream.push.service.PushService;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 推送的controller层
 * Created by nessary on 16-9-27.
 */
@Controller
@RequestMapping(value = "push")
public class PushController {
    @Autowired
    private PushService pushService;
    private Logger logger = LoggerFactory.getLogger(PushController.class);


    @RequestMapping(value = {"modifyForPush", "addForPush", "passForPush", "removeForPush"}, method = {RequestMethod.POST})
    @ResponseBody
    public Response saveForPush(HttpServletRequest request, @RequestParam(value = "pushMsg", required = false) String pushMsg,
                                @RequestParam(value = "pushTopic", required = false) String pushTopic, @RequestParam(value = "isRead", required = false) Boolean isRead, @RequestParam(value = "pushStatus", required = false) Integer pushStatus,
                                @RequestParam(value = "isPass", required = false) Boolean isPass, @RequestParam(value = "pushType", required = false) Integer pushType, @RequestParam(value = "idsStr", required = false) String idsStr, @RequestParam(value = "pushContent", required = false) String pushContent, @RequestParam(value = "id", required = false) Integer id, @RequestParam(value = "isDeleted", required = false) Boolean isDeleted, @RequestParam(value = "isText", required = false) Boolean isText, @RequestParam(value = "htmlLink", required = false) String htmlLink) {

        try {
            //获取当前用户所有所属渠道信息
            AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


            if (userModel == null) {
                return Response.error();

            }


            PushModel pushModel = new PushModel();
            pushModel.setChannelId(userModel.getDataId());
            pushModel.setPushMsg(pushMsg);
            pushModel.setPushTopic(pushTopic);
            pushModel.setRead(isRead);
            //前端修改状态只能传 0和 1  审核 和代发布
            if (pushStatus != null) {

                pushModel.setPushStatus(0 == pushStatus ? 0 : 1);
            }
            pushModel.setText(isText);
            pushModel.setHtmlLink(htmlLink);
            pushModel.setPushContent(pushContent);
            pushModel.setOperatorId(userModel.getId());
            pushModel.setOperatorName(userModel.getName());
            pushModel.setDeleted(isDeleted);
            pushModel.setIdsStr(idsStr);
            pushModel.setPushType(pushType);
            pushModel.setPass(isPass);
            if (id != null || StringUtils.isNotEmpty(idsStr)) {
                pushModel.setId(id);
                pushService.updatePushModel(pushModel);
            } else {
                pushModel.setPass(false);
                pushService.savePushModel(pushModel);
            }


        } catch (Exception e) {
            logger.warn("保存推送失败", e);
            return Response.error();
        }
        return Response.success();
    }


    @RequestMapping(value = "getPushById", method = {RequestMethod.POST})
    @ResponseBody
    public Response getPushById(HttpServletRequest request, @RequestParam(value = "id") Integer id) {

        try {
            //获取当前用户所有所属渠道信息
            AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


            if (userModel == null) {
                return Response.error();

            }


            PushModel pushModel = new PushModel();

            pushModel.setChannelId(userModel.getDataId());
            pushModel.setId(id);


            pushModel = pushService.findPushModelById(pushModel);

            if (pushModel == null) {
                return Response.error();
            } else {
                return Response.response(200, "", pushModel);
            }


        } catch (Exception e) {
            logger.warn("获取推送失败", e);
            return Response.error();
        }
    }

    @RequestMapping(value = {"loadForPush", "findPushByCondition"}, method = {RequestMethod.POST})
    @ResponseBody
    public Response loadForPush(HttpServletRequest request,
                                @RequestParam(value = "pushTopic", required = false) String pushTopic,
                                @RequestParam(value = "pushContent", required = false) String pushContent,
                                @RequestParam(value = "isText", required = false) Boolean isText,
                                @RequestParam(value = "pushStatus", required = false) Integer pushStatus,
                                @RequestParam(value = "pushType", required = false) Integer pushType, @RequestParam(value = "page", defaultValue = "0", required = false) Integer start, @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageCount) {

        try {


            //获取当前用户所有所属渠道信息
            AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


            if (userModel == null) {
                return Response.error();

            }

            PushModel pushModel = new PushModel();
            pushModel.setChannelId(userModel.getDataId());
            pushModel.setOperatorId(userModel.getId());
            pushModel.setStart(start * pageCount);
            pushModel.setPageCount(pageCount);
            pushModel.setPushType(pushType);

            //搜索条件
            pushModel.setPushTopic(pushTopic);
            pushModel.setPushContent(pushContent);
            pushModel.setText(isText);
            pushModel.setPushStatus(pushStatus);

            List<PushModel> allPushModel =
                    pushService.findAllPushModel(pushModel);

            Map<String, Object> map = new HashMap<>();

            if (allPushModel.isEmpty()) {
                map.put("start", 0);
                map.put("pageSize", 0);
                map.put("resultCount", 0);
                map.put("total", 0);

            } else {
                map.put("start", start);
                map.put("pageSize", pageCount);
                map.put("resultCount", allPushModel.get(0).getTotalCount());
                if (allPushModel.get(0).getTotalCount().equals(0)) {
                    map.put("total", 0);
                } else {

                    map.put("total", (int) (Math.floor(pageCount / allPushModel.get(0).getTotalCount()) + 1));
                }

            }
            map.put("data", allPushModel);

            return Response.response(200, "", map);

        } catch (Exception e) {
            logger.warn("保存推送失败", e);
            return Response.error();
        }

    }


    @RequestMapping(value = "executePush", method = {RequestMethod.POST})
    @ResponseBody
    public Response executePush(HttpServletRequest request, Integer id) {

        try {
            //获取当前用户所有所属渠道信息
            AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");


            if (userModel == null) {
                return Response.error();

            }

            PushModel pushModel = new PushModel();
            pushModel.setId(id);
            pushModel.setOperatorId(userModel.getId());
            pushModel.setChannelId(userModel.getDataId());

            pushService.executePush(pushModel);


            return Response.success();

        } catch (Exception e) {
            logger.warn("保存推送失败", e);
            return Response.error();
        }

    }


}
