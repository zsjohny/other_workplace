package org.dream.sms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.sms.SmsSenderMessage;

public interface SmsSenderMessageDao {

	public void createSenderMessage(SmsSenderMessage senderMseeage);

	public void updateSenderMessage(SmsSenderMessage senderMseeage);

	public List<SmsSenderMessage> pagingQuery(@Param("type") Integer type, @Param("channelId") Integer channelId,
			@Param("status") Integer status, @Param("isDelete") Integer isDelete, @Param("limit") Integer limit,
			@Param("size") Integer size);

	public Integer pagingQuery_count(@Param("type") Integer type, @Param("channelId") Integer channelId,
			@Param("status") Integer status, @Param("isDelete") Integer isDelete);

	public SmsSenderMessage getSenderByStatus(@Param("status") Integer status, @Param("channelId") Integer channelId,
			@Param("isDelete") Integer isDelete);
	
	public void remove(@Param("id") Integer id);
	
	public SmsSenderMessage getSenderMsgById(@Param("type") Integer type,@Param("channelId") Integer channelId,@Param("id") Integer id);
	
}
