package org.dream.push.dao;

import org.apache.ibatis.annotations.Param;
import org.dream.model.push.PushModel;

import java.util.List;

/**
 * 推送的dao
 * Created by nessary on 16-9-27.
 */
public interface PushDao {
    /**
     * 保存推送实体类
     *
     * @param pushModel 推送实体类
     */
    void savePushModel(PushModel pushModel);


    /**
     * 更改推送的内容 包含软删除 之类的
     *
     * @param pushModel 推送实体类
     */
    void updatePushModel(PushModel pushModel);


    /**
     * 分页查找当前渠道下的所有的设置的信息
     *
     * @param pushModel 推送实体类
     * @return
     */
    List<PushModel> findAllPushModel(PushModel pushModel);


    /**
     * 根据推送信息查询推送的个数
     *
     * @param pushModel 推送实体类
     * @return
     */
    Integer findCountPushModel(PushModel pushModel);

    /**
     * 根据Id寻找推送内容
     *
     * @param pushModel 推送实体类
     * @return
     */
    PushModel findPushModelById(PushModel pushModel);


}
