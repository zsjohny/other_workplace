package org.dream.shoppingMall.service;

import java.util.List;

import org.dream.model.shoppingMall.ShoppingMallGoodsModel;
import org.dream.utils.mvc.Response;

public interface ShoppingMallGoodsService {

	public Response create(ShoppingMallGoodsModel goodsModel);

	public Response update(ShoppingMallGoodsModel goodsModel);

	public Response unavailable(List<Integer> ids);
	
	public Response sale(List<Integer> ids);

	public Response pagingQuery(Integer channelId, Integer page, Integer pageSize);

	public Response delete(Integer id);
	
	public Response findGoodsById(Integer id ,Integer channelId);
}
