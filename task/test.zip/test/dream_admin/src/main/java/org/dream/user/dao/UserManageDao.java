package org.dream.user.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.user.UserManageModel;

public interface UserManageDao {
	public List<UserManageModel> findByPage(@Param("id") Integer userId, @Param("userName") String userName,
			@Param("userPhone") String userPhone, @Param("channelId") Integer channelId,
			@Param("topChannelId") Integer topChannelId, @Param("createTimeStart") String createTimeStart,
			@Param("createTimeEnd") String createTimeEnd, @Param("lastLoginTimeStart") String lastLoginTimeStart,
			@Param("lastLoginTimeEnd") String lastLoginTimeEnd, @Param("realName") String realName,
			@Param("idCard") String idCard, @Param("status") Integer status, @Param("offset") Integer offset,
			@Param("pageSize") Integer pageSize, @Param("orderBy") String orderBy);

	public Integer findRows(@Param("id") Integer userId, @Param("userName") String userName,
			@Param("userPhone") String userPhone, @Param("channelId") Integer channelId,
			@Param("topChannelId") Integer topChannelId, @Param("createTimeStart") String createTimeStart,
			@Param("createTimeEnd") String createTimeEnd, @Param("lastLoginTimeStart") String lastLoginTimeStart,
			@Param("lastLoginTimeEnd") String lastLoginTimeEnd, @Param("realName") String realName,
			@Param("idCard") String idCard, @Param("status") Integer status);
}
