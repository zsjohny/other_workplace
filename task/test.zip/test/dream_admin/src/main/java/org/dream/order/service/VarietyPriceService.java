package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.order.VarietyPriceModel;
import org.dream.utils.mvc.Page;

public interface VarietyPriceService {

	public Map<String, Object> saveVarietyPrice(VarietyPriceModel varietyPriceModel);

	public Map<String, Object> updateVarietyPrice(VarietyPriceModel varietyPriceModel);

	public void removeVarietyPrice(Integer id);

	public Page<VarietyPriceModel> pagingQueryVarietyPrice(Integer page, Integer pageSize, Integer varietyId,
			String createTimeStart, String createTimeEnd);

	public VarietyPriceModel getVarietyPriceById(Integer id);

	public List<Map<String, Object>> getVariety();

	public String getVarietyTypeByVarietyId(Integer varietyId);

}
