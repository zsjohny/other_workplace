package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.TradingVarietyModel;

/**
 * 期货品种Dao
 *
 */
public interface TradingVarietyDao {

	public void createTradingVariety(TradingVarietyModel tradingVarietyModel);

	public void updateTradingVariety(TradingVarietyModel tradingVarietyModel);

	public TradingVarietyModel getById(@Param(value = "id") Integer id);

	public List<TradingVarietyModel> qureypaging(@Param(value = "varietyName") String varietyName,
			@Param(value = "varietyType") String varietyType, @Param(value = "exchangeName") String exchangeName,
			@Param(value = "varietyRemark") String varietyRemark, @Param(value = "status") Integer status,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "varietyName") String varietyName,
			@Param(value = "varietyType") String varietyType, @Param(value = "exchangeName") String exchangeName,
			@Param(value = "varietyRemark") String varietyRemark, @Param(value = "status") Integer status);

	/**
	 * 获取平台下所有可售品种
	 */
	public List<TradingVarietyModel> getEffectiveTradingVarieties();

	/**
	 * 获取平台下所有品种(不管status的值)
	 */
	public List<TradingVarietyModel> getAllTradingVarieties();

	/**
	 * 删除平台下某一品种
	 */
	public void removeTradingVarietyById(@Param(value = "id") Integer id, @Param(value = "status") Integer status);

	/**
	 * 关闭平台下某一些品种的显示
	 */
	public void removeByIds(@Param(value = "ids") List<Integer> ids);

	/**
	 * 查询交易所下所有的品种
	 *
	 * @return
	 */
	public List<TradingVarietyModel> getByExchangeId(Integer exchangeId);
	
	public int getCountByVareityName(String varietyName);
	
	public int getCountByVareityType(String varietyType);
	
	public int getCountByQuotaExchangeCode(String quotaExchangeCode);
	
	public int getCountByQuotaVarietyCode(String quotaVarietyCode);

}
