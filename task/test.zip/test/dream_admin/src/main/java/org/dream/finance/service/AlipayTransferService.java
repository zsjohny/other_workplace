package org.dream.finance.service;

import org.dream.utils.mvc.Response;

public interface AlipayTransferService {

	public Response alipayResult(String parameter, String selfOrderId, Integer transferId);
}
