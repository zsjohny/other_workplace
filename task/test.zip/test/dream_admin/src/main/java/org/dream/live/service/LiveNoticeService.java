package org.dream.live.service;

import java.util.List;

import org.dream.model.live.LiveNoticeModel;
import org.dream.utils.mvc.Page;

/**
 * 直播公告Service
 * 
 * @author ZY
 * @date 2016年10月13日
 */
public interface LiveNoticeService {
	public void createLiveNotice(LiveNoticeModel liveNoticeModel);

	public void removeLiveNotice(String ids);

	public void updateLiveNotice(LiveNoticeModel liveNoticeModel);

	public List<LiveNoticeModel> getAll(Integer channelId, Integer status);

	public LiveNoticeModel getById(Integer id);

	public Page<LiveNoticeModel> querypaging(Integer channelId, Integer status, Integer page, Integer pageSize);

}
