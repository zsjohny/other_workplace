package org.dream.finance.controller;

import org.dream.finance.service.FinanceInnerService;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceInnerController {
	@Autowired
	private FinanceInnerService innerService;

	@RequestMapping("/innerDepositMoney")
	@ResponseBody
	public Response innerDepositMoney(Integer userId, Double money) {
		return innerService.innerDepositMoney(userId, money);
	}

	@RequestMapping("/innerDepositScore")
	@ResponseBody
	public Response innerDepositScore(Integer userId, Double score) {
		return innerService.innerDepositScore(userId, score);
	}

	@RequestMapping("/innerExtractMoney")
	@ResponseBody
	public Response innerExtractMoney(Integer userId, Double money) {
		return innerService.innerExtractMoney(userId, money);
	}

	@RequestMapping("/innerExtractScore")
	@ResponseBody
	public Response innerExtractScore(Integer userId, Double score) {
		return innerService.innerExtractScore(userId, score);
	}
}
