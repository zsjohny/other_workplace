package org.dream.finance.dao;

import org.dream.model.finance.FinanceAccModel;

public interface FinanceAccDao {
	public FinanceAccModel find(Integer userId);

	public void update(FinanceAccModel financeAccModel);
}
