package org.dream.order.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.model.order.FuturesContractsModel;
import org.dream.order.dao.FuturesContractsDao;
import org.dream.order.service.FuturesContractsService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class FutureContractsServiceImpl implements FuturesContractsService {

	@Autowired
	FuturesContractsDao futuresContractsDao;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	@Override
	public void saveFutureContracts(FuturesContractsModel contractsMoudel) {
		futuresContractsDao.createFuturesContracts(contractsMoudel);

	}

	@Override
	public void updateFutureContracts(FuturesContractsModel contractsMoudel) {
		futuresContractsDao.updateFuturesContracts(contractsMoudel);

	}

	@Override
	public FuturesContractsModel getById(Integer id) {
		return futuresContractsDao.getById(id);
	}

	@Override
	public Page<FuturesContractsModel> querypaging(String exchangeName, String varietyName, Integer status,
			Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<FuturesContractsModel> futuresContractsMoudels = futuresContractsDao.qureypaging(exchangeName, varietyName,
				status, limit, pageSize);
		int totalCount = futuresContractsDao.qureypaging_count(exchangeName, varietyName, status);

		Page<FuturesContractsModel> resultPage = new Page<>(pageIndex, pageSize, totalCount);
		resultPage.setData(futuresContractsMoudels);
		return resultPage;
	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public void changeStatusByIds(String ids, Integer status) {

		List<Integer> list = this.handleIds(ids);

		futuresContractsDao.changeStatusByIds(status, list);

	}

	@Override
	public List<FuturesContractsModel> getAll() {
		return futuresContractsDao.getAll();
	}

	@Override
	public Integer qureypaging_count(String exchangeName, String varietyName, String contractsCode, Integer status) {

		return futuresContractsDao.qureypaging_count(exchangeName, varietyName, status);
	}

	@Override
	public Integer getVarietyIdByCode(String contractsCode) {
		return futuresContractsDao.getVarietyIdByCode(contractsCode);
	}

	@Override
	public Integer qureypagingHasContractsCode(String contractsCode) {

		return futuresContractsDao.qureypagingHasContractsCode(contractsCode);
	}

	@Override
	public void putContractsRedis(FuturesContractsModel fCModel) {
		// 打开的时候，redis中也要添加hash
		redisTemplate.opsForHash().put(FuturesContractsModel.VARIETY_SALE_CONTRACTS, fCModel.getVarietyId(), fCModel);
		redisTemplate.opsForHash().put(FuturesContractsModel.VARIETY_SALE_CONTRACTS, fCModel.getContractsCode(),
				fCModel.getVarietyType());
	}

	@Override
	public void deleteContractsRedis(FuturesContractsModel fCModel) {
		// 关闭的时候，redis中也要删除hash
		if (redisTemplate.opsForHash().hasKey(FuturesContractsModel.VARIETY_SALE_CONTRACTS, fCModel.getVarietyId())) {
			redisTemplate.opsForHash().delete(FuturesContractsModel.VARIETY_SALE_CONTRACTS, fCModel.getVarietyId());
		}
		// key为合约代码的缓存
		if (redisTemplate.opsForHash().hasKey(FuturesContractsModel.VARIETY_SALE_CONTRACTS,
				fCModel.getContractsCode())) {
			redisTemplate.opsForHash().delete(FuturesContractsModel.VARIETY_SALE_CONTRACTS, fCModel.getContractsCode());
		}
	}
}
