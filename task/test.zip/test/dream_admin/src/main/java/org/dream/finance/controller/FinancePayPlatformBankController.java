package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinancePayPlatformBankService;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinancePayPlatformBankController extends BaseController {

	@Autowired
	private FinancePayPlatformBankService payPlatformBankService;

	@RequestMapping("/findPayPlatformBankByPage")
	@ResponseBody
	public Response findPayPlatformBankByPage(String payPlatform, String bankName, Integer status, Integer page,
			Integer pageSize) {
		Page<FinancePayPlatformBankModel> list = payPlatformBankService.querypaging(bankName, payPlatform, status, page,
				pageSize);
		return Response.success(list);
	}

	@RequestMapping("/savePayPlatformBank")
	@ResponseBody
	public Response savePayPlatformBank(FinancePayPlatformBankModel payPlatformBankModel) {
		return payPlatformBankService.saveFinancePayPlatformBank(payPlatformBankModel);
	}

	@RequestMapping("/updatePayPlatformBank")
	@ResponseBody
	public Response updatePayPlatformBank(FinancePayPlatformBankModel payPlatformBankModel) {
		return payPlatformBankService.updateFinancePayPlatformBank(payPlatformBankModel);
	}

	@RequestMapping("/findPayPlatformBankAll")
	@ResponseBody
	public Response findPayPlatformBankAll(FinanceCertModel certModel, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		certModel.setChannelId(channelId);
		certModel.setType(0);
		certModel.setStatus(0);
		return payPlatformBankService.findPayPlatformBankAll(certModel);
	}

	@RequestMapping("/findChannelPayPlatformAll")
	@ResponseBody
	public Response findChannelPayPlatformAll(FinanceCertModel certModel, Integer bankId, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		certModel.setChannelId(channelId);
		certModel.setType(0);
		certModel.setStatus(0);
		return payPlatformBankService.findChannelPayPlatformAll(certModel, bankId);
	}
}
