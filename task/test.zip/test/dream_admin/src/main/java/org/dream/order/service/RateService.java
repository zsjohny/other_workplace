package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.Rate;
import org.dream.utils.mvc.Page;

public interface RateService {
	
	public Map<String,Object> saveRate(Rate rate,int userId,int channelId);
	
	public void updateRate(Rate rate,int userId,ChannelModel channelModel);
	
	public Map<String,Object> removeRate(String id,int channelId);
	
	public Page<Rate> pagingQueryRate(Integer page, Integer pageSize, String currency,int channelId);
	
	public Rate getRateById(Integer rateId);
	
	public List<Rate> getCurrency();
	
	public Rate getRateByCurrency(String currency);
	
	

}
