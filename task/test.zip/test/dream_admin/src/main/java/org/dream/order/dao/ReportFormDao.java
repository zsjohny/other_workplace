package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.OrderModel;

public interface ReportFormDao {

	// 做二级渠道上周分类
	public List<OrderModel> countSecondLastWeekFees(@Param("channelId") Integer channelId,
			@Param("orderTimeStart") String orderTimeStart, @Param("orderTimeEnd") String orderTimeEnd);

	// 二级渠道上周汇总
	public OrderModel countSecondTotal(@Param("channelId") Integer channelId,
			@Param("orderTimeStart") String orderTimeStart, @Param("orderTimeEnd") String orderTimeEnd);

	// 做一级渠道上周分类
	public List<OrderModel> countFirstLastWeekFees(@Param("oneChannelId") Integer oneChannelId,
			@Param("orderTimeStart") String orderTimeStart, @Param("orderTimeEnd") String orderTimeEnd);

	// 一级渠道上周汇总
	public OrderModel countFirstTotal(@Param("oneChannelId") Integer oneChannelId,
			@Param("orderTimeStart") String orderTimeStart, @Param("orderTimeEnd") String orderTimeEnd);

	// 做平台上周分类
	public List<OrderModel> countPlatformLastWeekFees(@Param("orderTimeStart") String orderTimeStart,
			@Param("orderTimeEnd") String orderTimeEnd);

	// 做平台上周汇总
	public OrderModel countPlatformTotal(@Param("orderTimeStart") String orderTimeStart,
			@Param("orderTimeEnd") String orderTimeEnd);

	/**
	 * 新的需求：不需要乘以汇率，也不需要统计
	 */
	// 做二级渠道上周分类原始币种
	public List<OrderModel> countSecondLastWeekFeesLocalUnit(@Param("channelId") Integer channelId,
			@Param("orderTimeStart") String orderTimeStart, @Param("orderTimeEnd") String orderTimeEnd);

	// 做一级渠道上周分类原始币种
	public List<OrderModel> countFirstLastWeekFeesLocalUnit(@Param("oneChannelId") Integer oneChannelId,
			@Param("orderTimeStart") String orderTimeStart, @Param("orderTimeEnd") String orderTimeEnd);

	// 做平台上周分类
	public List<OrderModel> countPlatformLastWeekFeesLocalUnit(@Param("orderTimeStart") String orderTimeStart,
			@Param("orderTimeEnd") String orderTimeEnd);

}
