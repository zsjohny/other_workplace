package org.dream.shoppingMall.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.channel.ChannelModel;
import org.dream.shoppingMall.service.ShoppingMallCheckService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/shoppingMall")
public class ShoppingMallCheckController extends BaseController {

	private static final String REDIS_KEY = "admin:shopping:";

	@Autowired
	ShoppingMallCheckService shoppingMallCheckService;

	@Autowired
	private RedisTemplate<String, Integer> redisTemplate;

	/**
	 * 审核成功
	 * 
	 * @param status
	 * @param ids
	 * @param request
	 * @return
	 */
	@RequestMapping("/updateShopSuccess")
	@ResponseBody
	public Response updateShopSuccess(Integer status, String ids, HttpServletRequest request) {
		status = 1;
		Assert.notNull(ids, "审核ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		String redisKey = null;
		String[] idsArray = null;
		try {
			idsArray = ids.split(",");
			for (String id : idsArray) {
				redisKey = REDIS_KEY + "update_shopping_status_success" + id;
				RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
				if (!integer.compareAndSet(0, 1)) {
					return null;
				}
			}
			List<Integer> idList = new ArrayList<Integer>();
			for (int i = 0; i < idsArray.length; i++) {
				idList.add(Integer.valueOf(idsArray[i]));
			}

			if (idList.size() > 0) {
				shoppingMallCheckService.checkSuccessShopping(status, channelId, idList);
			}
		} finally {
			for (String id : idsArray) {
				redisKey = REDIS_KEY + "update_shopping_status_success" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");

	}

	/**
	 * 审核拒绝
	 * 
	 * @param status
	 * @param ids
	 * @param request
	 * @return
	 */
	@RequestMapping("/updateShopFail")
	@ResponseBody
	public Response updateFailSuccess(Integer status, String ids, HttpServletRequest request) {
		status = 2;
		Assert.notNull(ids, "审核ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		String redisKey = null;
		String[] idsArray = null;
		try {
			idsArray = ids.split(",");
			for (String id : idsArray) {
				redisKey = REDIS_KEY + "update_shopping_status_fail" + id;
				RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
				if (!integer.compareAndSet(0, 1)) {
					return null;
				}
			}
			List<Integer> idList = new ArrayList<Integer>();
			for (int i = 0; i < idsArray.length; i++) {
				idList.add(Integer.valueOf(idsArray[i]));
			}
			if (idList.size() > 0) {
				shoppingMallCheckService.checkFailShopping(status, channelId, idList);
			}
		} finally {
			for (String id : idsArray) {
				redisKey = REDIS_KEY + "update_shopping_status_fail" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");

	}

}
