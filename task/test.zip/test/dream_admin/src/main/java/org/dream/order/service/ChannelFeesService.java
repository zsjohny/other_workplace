package org.dream.order.service;

import java.util.Map;

import org.dream.model.order.ChannelFeesModel;
import org.dream.utils.mvc.Page;

public interface ChannelFeesService {
	
	public Map<String,Object> saveChannelFees(ChannelFeesModel channelFeesModel);
	
	public void updateChannelFees(ChannelFeesModel channelFeesModel);
	
	public void removeChannelFees(Integer id);
	
	public Page<ChannelFeesModel> pagingQueryChannelFees(Integer page,Integer pageSize,Integer channelId,Integer assetsId,String createTimeStart,String createTimeEnd);
	
	public ChannelFeesModel getChannelFeesById(Integer id);
	
	

}
