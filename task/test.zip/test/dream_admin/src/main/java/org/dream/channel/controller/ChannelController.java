package org.dream.channel.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.dream.utils.mvc.Response.DataResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/channel")
public class ChannelController extends BaseController {
	@Autowired
	private ChannelService channelService;

	@RequestMapping("/findAll")
	@ResponseBody
	public DataResponse<List<ChannelModel>> findChannelAll() {
		List<ChannelModel> list = channelService.findChannelAll();
		return DataResponse.success(list);
	}

	/**
	 * 获得所有的一级渠道数据 只有平台才能获得该数据
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/findAllFirstChannels")
	@ResponseBody
	public Response findAllFirstChannels(HttpServletRequest request) {
		ChannelModel channelModel = super.getCurrentChannel(request);
		// List<ChannelModel> list = channelService.findAllFirstChannels();
		return Response.success(channelModel.getLevel() == 0 ? channelService.findAllFirstChannels() : null);
	}

	@RequestMapping("/findSecondChannelsBySuperId")
	@ResponseBody
	public Response findSecondChannelsBySuperId(Integer id) {
		List<ChannelModel> list = channelService.findSecondChannelsBySuperId(id);
		return Response.success(list);
	}

	/**
	 * 根据一级渠道的id获得该渠道下的二级渠道集合 如果一级渠道的ID为空，则渠道id为当前登录人所属的渠道
	 * 
	 * @param channelId
	 * @param request
	 * @return
	 */
	@RequestMapping("/getSecondChannelByparentId")
	@ResponseBody
	public Response getSecondChannelByparentId(Integer channelId, HttpServletRequest request) {
		if (channelId == null) {
			channelId = super.getCurrentChannel(request).getId();
		}
		
		return Response.success(channelService.findSecondChannelsBySuperId(channelId));
	}

	/**
	 * 添加一个渠道和该渠道的管理员
	 * 
	 * @param domain
	 * @param name
	 * @param description
	 * @return
	 */
	@RequestMapping("/save")
	@ResponseBody
	public Response saveChannel(String domain, String name, String description, String sign, String userNamePrefix,
			String backstageDomain,String productName,String qq,String phone,Integer qqType, String channelQrCode,HttpServletRequest request) {

		ChannelModel channelModel = new ChannelModel();
		if (channelService.hasChannel(domain, null, null)) {
			return Response.error("添加渠道失败,已存在的渠道域名");
		}
		channelModel.setDomain(domain);
		if (channelService.hasChannel(null, name, null)) {
			return Response.error("添加渠道失败,已存在的渠道名称");
		}
		channelModel.setName(name);
		channelModel.setDescription(description);
		channelModel.setSign(sign);
		channelModel.setUserNamePrefix(userNamePrefix);
		if(channelService.hasChannel(null, null, backstageDomain)){
			return Response.error("添加渠道失败,已存在的管理端域名");
		}
		channelModel.setProductName(productName);
		channelModel.setQq(qq);
		channelModel.setPhone(phone);
		channelModel.setBackstageDomain(backstageDomain);
		ChannelModel channelModelSuper=super.getCurrentChannel(request);
		channelModel.setSuperId(channelModelSuper.getId());
		channelModel.setQqType(qqType);
		channelModel.setChannelQrCode(channelQrCode);
		if(channelModelSuper.getLevel() ==0){
			channelModel.setLevel(1);
		}else if(channelModelSuper.getLevel() ==1){
			channelModel.setLevel(2);
		}
		channelService.saveChannel(channelModel);
		return Response.success();
	}

	@RequestMapping(value = "/update")
	@ResponseBody
	public Response updateChannel(Integer id, String domain, String name, String description, String sign,
			String userNamePrefix, String backstageDomain,String productName,String qq,String phone,Integer qqType,String channelQrCode, HttpServletRequest request) {

		Assert.notNull(id, "要修改的渠道的id不能为空");
		ChannelModel channelModel = new ChannelModel();
		channelModel.setId(id);
		if(channelService.findCount(domain, null, null, id)>0){
			return Response.error("修改渠道失败,已存在的渠道域名");
		}
		channelModel.setDomain(domain);
		if(channelService.findCount(null, name, null, id)>0){
			return Response.error("修改渠道失败,已存在的渠道名称");
		}
		channelModel.setName(name);
		channelModel.setDescription(description);
		channelModel.setSign(sign);
		channelModel.setUserNamePrefix(userNamePrefix);
		if(channelService.findCount(null, null, backstageDomain, id)>0){
			return Response.error("修改渠道失败,已存在的渠道管理端域名");
		}
		channelModel.setBackstageDomain(backstageDomain);
		channelModel.setProductName(productName);
		channelModel.setQq(qq);
		channelModel.setPhone(phone);
		channelModel.setQqType(qqType);
		channelModel.setSuperId(super.getCurrentChannel(request).getId());
		channelModel.setChannelQrCode(channelQrCode);
		ChannelModel channelModelSuper=super.getCurrentChannel(request);
		if(channelModelSuper.getLevel() ==0){
			channelModel.setLevel(1);
		}else if(channelModelSuper.getLevel() ==1){
			channelModel.setLevel(2);
		}
		channelService.updateChannel(channelModel);
		return Response.success();
	}

	/**
	 * 分页查询渠道数据
	 * 
	 * @param domain
	 * @param name
	 * @param description
	 * @param pageSize
	 * @param pageIndex
	 * @return
	 */
	@RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
	@ResponseBody
	public Response querypaging(String domain, String name, String description, String backstageDomain,
			Integer pageSize, Integer page, HttpServletRequest request) {
		Page<ChannelModel> channels = channelService.querypaging(domain, name, description, super.getDataId(request),
				backstageDomain, page, pageSize);

		return Response.success(channels);
	}
}
