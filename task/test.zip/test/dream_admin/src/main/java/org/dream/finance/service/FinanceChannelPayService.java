package org.dream.finance.service;

import org.dream.model.finance.FinanceChannelPayModel;
import org.dream.utils.mvc.Response;

public interface FinanceChannelPayService {
	public Response findByPage(FinanceChannelPayModel channelPayModel, Integer offset, Integer pageSize);

	public Response find(FinanceChannelPayModel channelPayModel);

	public Response save(FinanceChannelPayModel channelPayModel);

	public Response update(FinanceChannelPayModel channelPayModel);

	public Response findChannelPayBankList(Integer channelId, Integer status);
}
