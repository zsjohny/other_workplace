package org.dream.news.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminUserModel;
import org.dream.model.news.NewsModel;
import org.dream.news.service.NewsService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/news")
public class NewsController extends BaseController {
	@Autowired
	private NewsService newsService;

	@RequestMapping("/findNewsByPage")
	@ResponseBody
	public Response findNewsByPage(NewsModel newsModel, Integer page, Integer pageSize, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		newsModel.setChannelId(channelId);
		return newsService.findNewsByPage(newsModel, page, pageSize);
	}

	@RequestMapping("/findNews")
	@ResponseBody
	public Response findNews(NewsModel newsModel, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		newsModel.setChannelId(channelId);
		return newsService.findNews(newsModel);
	}

	@RequestMapping("/saveNews")
	@ResponseBody
	public Response saveNews(NewsModel newsModel, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		newsModel.setChannelId(channelId);
		AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");
		newsModel.setOperator(userModel.getUserAccount());
		return newsService.saveNews(newsModel);
	}

	@RequestMapping("/updateNews")
	@ResponseBody
	public Response updateNews(NewsModel newsModel, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		newsModel.setChannelId(channelId);
		return newsService.updateNews(newsModel);
	}

	@RequestMapping("/deleteNews")
	@ResponseBody
	public Response deleteNews(String ids, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		return newsService.deleteNews(ids, channelId);
	}
}
