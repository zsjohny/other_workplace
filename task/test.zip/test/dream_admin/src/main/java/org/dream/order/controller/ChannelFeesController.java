package org.dream.order.controller;


import java.util.Map;

import org.dream.model.order.ChannelFeesModel;
import org.dream.order.service.ChannelFeesService;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping("/ChannelFees")
@Controller
public class ChannelFeesController {
	private static Logger logger=LoggerFactory.getLogger(ChannelFeesController.class);
	@Autowired
	ChannelFeesService channelFeesService;
		
	
	/**
	 * 新增
	 * @auth yehx
	 * @date 2016年7月4日
	 */
	@RequestMapping("/save")
	@ResponseBody
	public Response saveChannelFees(ChannelFeesModel channelFeesModel){
		Map<String,Object> map=channelFeesService.saveChannelFees(channelFeesModel);
		return Response.success(map);
	}
	@RequestMapping("/update")
	@ResponseBody
	public Response updateChannelFees(ChannelFeesModel channelFeesModel){
		channelFeesService.updateChannelFees(channelFeesModel);
		return Response.success();
	}
	
	@RequestMapping("/remove")
	@ResponseBody
	public Response removeChannelFees(Integer id){
		channelFeesService.removeChannelFees(id);
		return Response.success();		
	}
	@RequestMapping("/pagingQuery")
	@ResponseBody
	public Response pagingQueryChannelFees(Integer page, Integer pageSize, Integer channelId,Integer assetsId,String createTimeStart,String createTimeEnd){
		Page<ChannelFeesModel> data=channelFeesService.pagingQueryChannelFees(page, pageSize, channelId,assetsId,createTimeStart, createTimeEnd);
		return Response.success(data);
	}
	
	@RequestMapping("/getChannelFees")
	@ResponseBody
	public Response getChannelFeesById(Integer id){
		ChannelFeesModel v=channelFeesService.getChannelFeesById(id);
		return Response.success(v);
	}

}
