package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinanceTransferType;

public interface FinanceTransferService {

	public List<FinanceTransferModel> saveTransfer(String ioIds, FinanceTransferType transferType, String operator);
}
