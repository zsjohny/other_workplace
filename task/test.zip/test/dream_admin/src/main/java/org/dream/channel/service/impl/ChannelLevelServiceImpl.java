package org.dream.channel.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.channel.dao.ChannelLevelDao;
import org.dream.channel.service.ChannelLevelService;
import org.dream.model.channel.ChannelLevelModel;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChannelLevelServiceImpl implements ChannelLevelService {
	@Autowired
	private ChannelLevelDao channelLevelDao;

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public void saveChannelLevel(ChannelLevelModel channelLevelModel) {
		// �ж��Ƿ���һ��Ĭ�ϵĵȼ�
		if (channelLevelModel.getIsDefault() == 1) {
			List<ChannelLevelModel> lists = channelLevelDao.getAllByChannelId(channelLevelModel.getChannelId());
			if (lists != null && lists.size() > 0) {
				for (ChannelLevelModel cl : lists) {
					cl.setIsDefault(0);
					channelLevelDao.updateChannelLevelById(cl);
				}
			}
		}
		channelLevelDao.save(channelLevelModel);
	}

	@Override
	public void updateChannelLevelById(ChannelLevelModel channelLevelModel) {
		// �ж��Ƿ���һ��Ĭ�ϵĵȼ�
		if (channelLevelModel.getIsDefault() == 1) {
			List<ChannelLevelModel> lists = channelLevelDao.getAllByChannelId(channelLevelModel.getChannelId());
			if (lists != null && lists.size() > 0) {
				for (ChannelLevelModel cl : lists) {
					cl.setIsDefault(0);
					channelLevelDao.updateChannelLevelById(cl);
				}
			}
		}
		channelLevelDao.updateChannelLevelById(channelLevelModel);
	}

	@Override
	public void removeByIds(String ids) {
		List<Integer> list = this.handleIds(ids);
		channelLevelDao.removeByIds(list);
	}

	@Override
	public Page<ChannelLevelModel> querypaging(Integer channelId, Integer isDisplay, String levelName,
			Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<ChannelLevelModel> channelLevelModels = channelLevelDao.qureypaging(channelId, isDisplay, levelName, limit,
				pageSize);
		int totalCount = channelLevelDao.qureypaging_count(channelId, isDisplay, levelName);
		Page<ChannelLevelModel> resultPage = new Page<>(pageIndex, pageSize, totalCount);
		resultPage.setData(channelLevelModels);
		return resultPage;
	}

	@Override
	public Integer findEverCount(Integer channelId, Integer isDisplay, Integer isDefault, String levelName,
			Integer id) {
		return channelLevelDao.findEverCount(channelId, isDisplay, isDefault, levelName, id);
	}

	@Override
	public ChannelLevelModel findEver(Integer channelId, Integer id, String levelName) {
		return channelLevelDao.findEver(channelId, id, levelName);
	}

	@Override
	public List<ChannelLevelModel> getLevelsForUser(Integer channelId) {
		return channelLevelDao.getLevelsForUser(channelId);
	}

	@Override
	public ChannelLevelModel getLevelsByIsDefault(Integer channelId, Integer isDefault) {
		return channelLevelDao.getLevelsByIsDefault(channelId, isDefault);
	}

}
