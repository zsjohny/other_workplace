package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.ChannelLevelComModel;
import org.dream.utils.mvc.Page;

public interface ChannelLevelComService {

	public List<Map<String, Object>> getChannelLevel(int id);

	public Map<String, Object> saveChannelLevelCom(ChannelLevelComModel channelLevelComModel, int userId,
			ChannelModel cm);

	public void updateChannelLevelCom(ChannelLevelComModel channelLevelComModel, int userId);

	public void removeChannelLevelCom(String id);

	public Page<ChannelLevelComModel> pagingQueryChannelLevelCom(Integer page, Integer pageSize, Integer levelId,
			Integer varietyId, String createTimeStart, String createTimeEnd, int channelId);

	public ChannelLevelComModel getChannelLevelComById(Integer id);

	public ChannelLevelComModel getById(Integer id);
}
