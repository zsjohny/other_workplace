package org.dream.finance.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeMap;
import org.dream.finance.dao.FinanceTransferDao;
import org.dream.finance.service.AlipayTransferService;
import org.dream.finance.service.BasicFinanceService;
import org.dream.finance.service.TianFuBaoWeChatTransferService;
import org.dream.finance.util.tfbwc.ParamUtil;
import org.dream.finance.util.tfbwc.TFBMD5Utils;
import org.dream.finance.util.tfbwc.TFBRequestUtils;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinanceIOType;
import org.dream.utils.math.Arith;
import org.dream.utils.mvc.Response;
import org.dream.utils.prop.SpringProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Service
public class TianFuBaoWeChatTransferServiceImpl implements TianFuBaoWeChatTransferService {
	private Logger logger = LoggerFactory.getLogger(AlipayTransferService.class);
	@Autowired
	private SpringProperties springProperties;
	@Autowired
	private BasicFinanceService basicFinanceService;
	@Autowired
	private FinanceTransferDao transferDao;

	@Override
	public Response tianFuBaoWeChatResult(String certParameter, String selfOrderId, Integer transferId) {
		JSONObject parameter = JSON.parseObject(certParameter);
		String spid = parameter.getString("spid");
		String key = parameter.getString("md5Key");
		String publicKey = new String(ParamUtil.hex2Bytes(parameter.getString("publicKey")));
		String privateKey = new String(ParamUtil.hex2Bytes(parameter.getString("privateKey")));

		TreeMap<String, String> paramsMap = new TreeMap<String, String>();
		paramsMap.put("spid", spid);
		paramsMap.put("version", "1.0");
		paramsMap.put("sp_serialno", selfOrderId);// 商户代付单号
		paramsMap.put("sp_reqtime", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));

		String paramSrc = TFBRequestUtils.getParamSrc(paramsMap);// 拼接签名原串
		String sign = TFBMD5Utils.sign(paramSrc, key);// 生成签名
		String url = springProperties.getProperty("admin.tfbwc.transfer_query_url");
		String result = TFBRequestUtils.sendRequst(url, paramSrc + "&sign=" + sign, publicKey);
		logger.info("tfbQueryResult  result : {}", result);
		TreeMap<String, String> resultMap = TFBRequestUtils.parseResult(result, privateKey);
		logger.info("tfbQueryResult  resultMap : {}", resultMap);
		String retcode = resultMap.get("retcode");
		String serialnoState = resultMap.get("serialno_state");
		String tfbSerialno = resultMap.get("tfb_serialno");
		Double money = Arith.divide(Double.valueOf(resultMap.get("tran_amt")), 100.0, 6);
		if (retcode.equals("00")) {
			Integer status = null;
			if (("1").equals(serialnoState)) {
				status = 3;
				basicFinanceService.transferNotify(transferId, selfOrderId, tfbSerialno, money, status, null);
			} else if ((("3").equals(serialnoState) || ("4").equals(serialnoState))) {
				status = 5;
				basicFinanceService.transferNotify(transferId, selfOrderId, tfbSerialno, money, status, null);
			}
			FinanceTransferModel transferModel = new FinanceTransferModel();
			transferModel.setId(transferId);
			transferModel.setThirdOrderId(tfbSerialno);
			transferModel.setComments(resultMap.get("serialno_desc"));
			transferModel.setStatus(status);
			transferDao.update(transferModel);
			return Response.success();
		} else {
			return null;
		}

		// if (retcode.equals("00") && ("1").equals(serialnoState)) {
		// basicFinanceService.transferNotify(selfOrderId, tfbSerialno, money,
		// 3, FinanceIOType.DRAW_SUCCESS);
		// } else if (retcode.equals("00") && (("3").equals(serialnoState) ||
		// ("4").equals(serialnoState))) {
		// basicFinanceService.transferNotify(selfOrderId, tfbSerialno, money,
		// 5, FinanceIOType.TRANSFER_FAIL);
		// }
		// FinanceTransferModel transferModel = new FinanceTransferModel();
		// transferModel.setId(transferId);
		// transferModel.setComments(resultMap.get("memo"));
		// transferDao.update(transferModel);
		// return Response.success();
	}
}
