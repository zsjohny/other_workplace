package org.dream.admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminPerssionModel;
import org.dream.admin.service.AdminPermissionService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 管理员权限
 * @author SUNDONG_
 *
 */
@Controller
@RequestMapping("/permission")
public class AdminPermissionsController extends BaseController{
    
    @Autowired
    AdminPermissionService adminPermissionService;
    /**
     * 根据条件分页查询权限
     * TODO 查询条件后补
     * @param page
     * @param pageSize
     * @return
     */
    @RequestMapping(value="/pagingQuery", method= {RequestMethod.POST})
    @ResponseBody
    public Response pagingQuery(Integer page, Integer pageSize, String name, String description, String identifier, String levelCode) {
        pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
        page = page == null ? 0 : page;
        Map<String, Object> param = new HashMap<String, Object>();
        if (name != null) {
            param.put("name", name);
        }
        if (description != null) {
            param.put("description", description);
        }
        if (identifier != null) {
            param.put("identifier", identifier);
        }
        if (levelCode != null) {
            param.put("levelCode", levelCode);
        }
        param.put("category", AdminPerssionModel.CATEGORY);
        Page<AdminPerssionModel> pageResult = adminPermissionService.pagingQueryPermissions(page, pageSize, param);
        
        return Response.success(pageResult);
    }
    
    /**
     * 添加权限
     * @param name
     * @param identifier
     * @param description
     * @return
     */
    @RequestMapping(value="/add", method= {RequestMethod.POST})
    @ResponseBody
    public Response add(String name, String identifier, String description) {
        
        AdminPerssionModel perssionModel = new AdminPerssionModel();
        perssionModel.setName(name);
        perssionModel.setDescription(description);
        perssionModel.setIdentifier(identifier);
        
        if (adminPermissionService.hasPermissionByIdentifier(identifier)) {
            return Response.error("保存权限失败，权限标识重复");
        }
        
        adminPermissionService.createPermission(perssionModel);
        return Response.success();
    }
    
    /**
     * 
     * @param id
     * @param name
     * @param identifier
     * @param description
     * @return
     */
    @RequestMapping(value="/update", method= {RequestMethod.POST})
    @ResponseBody
    public Response update(Integer id,String name, String identifier, String description) {
        
        Assert.notNull(id, "需要修改的权限ID不能为空");
        AdminPerssionModel perssionModel = new AdminPerssionModel();
        perssionModel.setId(id);
        perssionModel.setName(name);
        perssionModel.setDescription(description);
        perssionModel.setIdentifier(identifier);
        
        adminPermissionService.updatePermission(perssionModel);
        return Response.success();
    }
    
    
    /**
     * 
     * @param ids
     * @return
     */
    @RequestMapping(value="/deletePermissions", method= {RequestMethod.POST})
    @ResponseBody
    public Response deletePermissions(String ids, HttpServletRequest request) {
        
        Assert.notNull(ids, "需要删除的权限ID不能为空");
        List<Integer> idList = new ArrayList<Integer>();
        String id_temp [] = ids.split(",");
        for (int i = 0; i < id_temp.length; i++) {
            idList.add(Integer.valueOf(id_temp[i]));
        }
        
        adminPermissionService.deletePermissionsByIds(idList, super.getDataId(request));
        return Response.success();
    }
}
