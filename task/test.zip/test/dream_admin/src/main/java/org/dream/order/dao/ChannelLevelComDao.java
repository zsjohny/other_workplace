package org.dream.order.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.ChannelLevelComModel;

public interface ChannelLevelComDao {

	public List<Map<String, Object>> getChannelLevel(int id);

	public int getChannelLevelComByLevelIdAndVarietyId(@Param("levelId") Integer levelId,
			@Param("varietyId") Integer varietyId, @Param("channelId") Integer channelId);

	public int insertSelective(ChannelLevelComModel channelLevelComModel);

	int updateByPrimaryKeySelective(ChannelLevelComModel channelLevelComModel);

	void removeByPrimaryKey(String[] ids);

	public List<ChannelLevelComModel> pagingQueryChannelLevelCom(Map map);

	public int pagingQueryChannelLevelComCount(Map map);

	public ChannelLevelComModel selectByPrimaryKey(Integer id);

	public ChannelLevelComModel getById(@Param("id") Integer id);
}
