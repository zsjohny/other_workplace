package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.order.ChannelInvestorModel;
import org.dream.utils.mvc.Page;

public interface ChannelInvestorService {

	public Map<String, Object> saveChannelInvestor(ChannelInvestorModel channelInvestorModel);

	public Map<String, Object> updateChannelInvestor(ChannelInvestorModel channelInvestorModel);

	public Page<ChannelInvestorModel> pagingQueryChannelInvestor(Integer page, Integer pageSize, Integer channelId);

	public void removeChannelInvestor(String ids);

	public ChannelInvestorModel getInfo(Integer id);

	public List<ChannelInvestorModel> getAccountsByChannelId(Integer channelId);

}
