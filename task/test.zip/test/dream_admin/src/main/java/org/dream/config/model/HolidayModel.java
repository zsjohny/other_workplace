package org.dream.config.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 假期配置Model
 * <strong>
 * 关于假期配置：</br>
 * 通常情况下国内假期时的开市休市规则为：
 * 1：假期开始时，如果某品种的夜盘的休市时间在假期内则该夜盘为休市
 * 2：假期结束时，如果某品种的夜盘开市时间在假期内则该盘为休市。
 * 交易所假期的配置应该是在假期之前的最后一个休市时间（该休市时间不在假期时间段内）到假期结束后第一个开市时间（开市时间也不在假期时间内）。
 * 这一点很重要
 * <p>
 * 所有假期配置应该以品种为准，即开市和休市状态粒度控制到某个品种，不是整个交易所。避免在某个假期时交易所的品种之间的开市和休市时间上的不一致的尴尬
 * 配置时可以以交易所来配置，系统自动为交易所下所有的品种配置相应的假期
 * </strong>
 *
 * @author wangd
 */
public class HolidayModel implements Serializable {

    private static final long serialVersionUID = -6807488439989340969L;


    private Integer id;
    /**
     * 交易所id
     */
    private Integer exchangeId;
    /**
     * 交易所名称
     */
    private String exchangeName;
    /**
     * 品种id
     */
    private Integer varietyId;
    /**
     * 品种名称
     */
    private String varietyName;

    /**
     * 品种类型
     */
    private String varietyType;
    /**
     * 假期名称
     */
    private String holidayName;
    /**
     * 假期开始时间
     */
    private Timestamp startDate;
    /**
     * 假期结束时间
     */
    private Timestamp endDate;
    /**
     * 创建时间
     */
    private Timestamp createDate;
    /**
     * 配置状态
     * 0：新建配置；1：已过期配置
     */
    private Integer status = 1;

    private String remark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(Integer exchangeId) {
        this.exchangeId = exchangeId;
    }

    public String getExchangeName() {
        return exchangeName;
    }

    public void setExchangeName(String exchangeName) {
        this.exchangeName = exchangeName;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getHolidayName() {
        return holidayName;
    }

    public void setHolidayName(String holidayName) {
        this.holidayName = holidayName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getVarietyId() {
        return varietyId;
    }

    public void setVarietyId(Integer varietyId) {
        this.varietyId = varietyId;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public String getVarietyType() {
        return varietyType;
    }

    public void setVarietyType(String varietyType) {
        this.varietyType = varietyType;
    }


}
