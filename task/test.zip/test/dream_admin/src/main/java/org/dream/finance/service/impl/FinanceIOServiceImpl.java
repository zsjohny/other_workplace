package org.dream.finance.service.impl;

import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.service.FinanceIOService;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceIOServiceImpl implements FinanceIOService {
	@Autowired
	private FinanceIODao ioDao;

	@Override
	public FinanceIOManageModel findIODetail(Integer id) {
		return ioDao.findDailById(id);
	}

	@Override
	public Response adjustCommission(FinanceIOModel ioModel) {
		ioDao.updateCommissionById(ioModel);
		return Response.response(ResponseCode.SUCCESS_CODE, "调整手续费成功");
	}

}
