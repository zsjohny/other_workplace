package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceFlowManageModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.model.finance.FinanceTransferManageModel;

public interface FinanceProduceExcelService {
	
	public List<FinanceFlowManageModel> findAllFlow(String createTimeStart, String createTimeEnd, Integer userId,
			String userName, String userPhone, Integer channelId, Integer topChannelId, Integer type,
			Integer typeDetail, String remark, String flow);
	
	public List<FinanceIOManageModel> findAllIO(FinanceIOManageModel model);
	
	public List<FinanceTransferManageModel> findAllTransfer(Integer userId, String userName, String userPhone,
			String realName, String transferType, Integer status, String operator, String createTimeStart,
			String createTimeEnd, String updateTimeStart, String updateTimeEnd, Integer topChannelId);
}
