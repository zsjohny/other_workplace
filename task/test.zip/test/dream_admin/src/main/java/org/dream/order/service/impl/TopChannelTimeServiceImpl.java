package org.dream.order.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.dream.config.dao.TaskTypeDao;
import org.dream.config.dao.TimedTaskDao;
import org.dream.config.model.TaskTypeModel;
import org.dream.config.model.TimedTaskModel;
import org.dream.model.order.ChannelExchangeModel;
import org.dream.model.order.ExchangeTimeModel;
import org.dream.model.order.TopChannelModel;
import org.dream.order.dao.ChannelExchangeDao;
import org.dream.order.dao.TopChannelTaskTimeDao;
import org.dream.order.service.TopChannelTimeService;
import org.dream.utils.enums.TopChannelErrMsgEnum;
import org.dream.utils.jms.JmsSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 一级渠道下的业务层的实现类
 * Created by nessary on 16-7-22.
 */
@Service
public class TopChannelTimeServiceImpl implements TopChannelTimeService {

    private static Logger logger = LoggerFactory.getLogger(TopChannelTimeServiceImpl.class);

    //系统任务
    private static String SCHEDULE_TO_ORDER = "order.all.varietyInventory";
    private String SCHEDULE_TO_ORDER_NAME = "一级渠道下市场的时间任务";


    //系统结束的时间
    private static String TASK_TIME_MIDDLE = "? * ";
    private static String TASK_TIME_SPACE = " ";
    private static String TASK_TIME_LINK = ",";

    @Autowired
    private TopChannelTaskTimeDao topChannelTaskTimeDao;

    @Autowired
    private ChannelExchangeDao firstChannelExchangeDao;


    @Autowired
    private TimedTaskDao timedTaskDao;

    @Autowired
    private TaskTypeDao taskTypeDao;


    private static Map<String, Integer> map = new Hashtable<>();


    private ThreadLocal<SimpleDateFormat> simple = new ThreadLocal<SimpleDateFormat>() {

        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat("HH:mm:ss");
        }

    };

    @Autowired
    private JmsSender timedTaskChangendSender;


    /**
     * 根据一级渠道 修改渠道的时间信息
     *
     * @param topChannelId 一级渠道的Id
     */
    @Override
    public int modifyExchangeSechedulByExchangeId(Integer topChannelId, Integer exchangeId, String exchangeTime, String exchangeWeek, String exchangeStatus, Long topChannelModelId, String inventory, Integer varietyId, Long varietyInventoryId) {

        try {


            //参数检验
            if (topChannelId == null || exchangeId == null || StringUtils.isEmpty(exchangeTime) || StringUtils.isEmpty(exchangeStatus) || !exchangeTime.contains(":") || StringUtils.isEmpty(exchangeWeek) || StringUtils.isEmpty(inventory)) {

                logger.error("进行修改一级渠道对应的时间表格，没有传参数 ,topChannelId={} ,exchangeId={} ,exchangeTime={} ,exchangeWeek={} , exchangeStatus={} ,topChannelModelId={} , inventory={} ", topChannelId, exchangeId, exchangeTime, exchangeWeek, exchangeStatus, topChannelModelId, inventory);
                return TopChannelErrMsgEnum.NO_PARAMS.getKey();

            }


            String[] times = exchangeTime.split(":");


            String weeks = exchangeWeek;

            //获取定时周期
            if (exchangeWeek.contains(",")) {


                String[] arr = exchangeWeek.split(",");

                //初始化
                weeks = arr[0];

                for (int i = 1; i < arr.length; i++) {

                    if (StringUtils.isEmpty(arr[i])) {
                        continue;
                    }
                    weeks = weeks + TASK_TIME_LINK + arr[i];
                }
            }


            Map<String, String> map = new HashMap<>();
            map.put("id", String.valueOf(exchangeId));


           /* String message = HttpTools.doGet(springProperties.getProperty("sys.host") + springProperties.getProperty("sys.order.queryExchangeStatusUrl"), map);

            JSONObject object;
            try {


                object = JSON.parseObject(message);
            } catch (Exception e) {

                logger.error("获取市场状态转为JsonObject失败,status={}", message, e);

                return flag;

            }

            if (StringUtils.isEmpty(message) || StringUtils.isEmpty(object.getString("data")) || object.getString("data").matches("[^1234]")) {


                logger.error("获取的市场此时的状态不是整数,status={}", message);

                return flag;
            } else {

                if (Integer.valueOf(object.getString("data")) == OpenOrClosed.closed.value || Integer.valueOf(object.getString("data")) == OpenOrClosed.todaytradeend.value) {
                    //强制将状态变成不可交易,不管用户的操作
                    exchangeStatus = "false";
                }


            }
*/

            if (times.length != 3 || weeks == null) {

                logger.error("时间传入参数没有按照 xx:xx:xx,进行传输 ,topChannelId={} ,exchangeId={} ,exchangeTime={} ,exchangeWeek={} ,exchangeStatus={} ,topChannelModelId={} ,inventory ={}", topChannelId, exchangeId, exchangeTime, exchangeWeek, exchangeStatus, topChannelModelId, inventory);
                return TopChannelErrMsgEnum.TIME_ERR.getKey();
            }


            //判断时间是否合规
            ExchangeTimeModel exchangeTimeModel = topChannelTaskTimeDao.getExchangeTimeByExchangeId(exchangeId);
            if (exchangeTimeModel == null || exchangeTimeModel.getStartTime() == null || exchangeTimeModel.getEndTime() == null) {
                logger.error("当前市场没有设置时间 ,topChannelId={} ,exchangeId={} ,exchangeTime={} ,exchangeWeek={} ,exchangeStatus={} ,topChannelModelId={} ,inventory ={}", topChannelId, exchangeId, exchangeTime, exchangeWeek, exchangeStatus, topChannelModelId, inventory);
                return TopChannelErrMsgEnum.EXCHANGE_NO_TIME.getKey();

            }


//            //增加周期的判断 #设计错误，暂不考虑
//            String dataweek = exchangeTimeModel.getCycleStr();
//
//            for (String inputWeek : exchangeWeek.split(",")) {
//
//                if (StringUtils.isEmpty(inputWeek)) {
//                    continue;
//                }
//
//                switch (inputWeek) {
//                    case "1":
//
//                        inputWeek = "周日";
//
//                        break;
//                    case "2":
//
//                        inputWeek = "周一";
//                        break;
//                    case "3":
//                        inputWeek = "周二";
//
//                        break;
//                    case "4":
//
//                        inputWeek = "周三";
//                        break;
//                    case "5":
//                        inputWeek = "周四";
//
//                        break;
//                    case "6":
//                        inputWeek = "周五";
//                        break;
//
//                    default:
//                        inputWeek = "周六";
//
//                }
//
//                if (!dataweek.contains(inputWeek)) {
//                    logger.error("用户传入的{}不对,对应市场Id的周期{}没有 ,topChannelId={} ,exchangeId={} ,exchangeTime={} ,exchangeWeek={} , exchangeStatus={} ,topChannelModelId={} , inventory={} ", inputWeek, dataweek, topChannelId, exchangeId, exchangeTime, exchangeWeek, exchangeStatus, topChannelModelId, inventory);
//
//
//                    return TopChannelErrMsgEnum.WEEK_ERR.getKey();
//                }
//
//            }


            //获取定时器执行的时间

            String executeTime = times[2] + TASK_TIME_SPACE + times[1] + TASK_TIME_SPACE + times[0] + TASK_TIME_SPACE + TASK_TIME_MIDDLE + weeks;

            TopChannelModel topChannelModel = new TopChannelModel();
            topChannelModel.setTopChannelId(topChannelId);
            topChannelModel.setExchangeId(exchangeId);
            topChannelModel.setTaskType(SCHEDULE_TO_ORDER);
            topChannelModel.setTaskStartTime(executeTime);
            topChannelModel.setInventory("true".equals(inventory) ? true : false);
            topChannelModel.setExchangeWeek(exchangeWeek);
            topChannelModel.setVarietyId(varietyId);
            try {
                topChannelModel.setExchangeTime(simple.get().parse(exchangeTime));
            } catch (ParseException ex) {
                logger.error("时间格式转换失败 , topChannelModel={} ", topChannelModel, ex);
                return TopChannelErrMsgEnum.TIME_ERR.getKey();
            }


            topChannelModel.setExchangeStatus("true".equals(exchangeStatus) ? true : false);


            JSONObject jsonObject = new JSONObject();
            jsonObject.put("topChannelId", topChannelId);
            jsonObject.put("exchangeId", exchangeId);
            jsonObject.put("varietyId", varietyId);
            jsonObject.put("executeTime", exchangeTime);
            jsonObject.put("nowStatus", topChannelModel.getExchangeStatus());


            topChannelModel.setTaskSendParameters(JSON.toJSONString(jsonObject));


            //保存到taskTime中
            TimedTaskModel timedTaskModel = new TimedTaskModel();


            timedTaskModel.setTimeTrigger(executeTime);
            timedTaskModel.setParameters(jsonObject.toJSONString());
            timedTaskModel.setTopChannelId(topChannelId);
            timedTaskModel.setExchangeId(exchangeId);


            //先查询是否存在---根据时间
            TopChannelModel result = topChannelTaskTimeDao.findChannelIdByIdsAndExchangeTime(topChannelId, exchangeId, varietyId, simple.get().parse(exchangeTime));

            if (result != null && result.getId() != null && !result.getId().equals(topChannelModelId)) {
                logger.error("一分钟内重复进行存储 定时任务 ,topChannelId={} ,exchangeId={} ,exchangeTime={} ,exchangeWeek={} ,exchangeStatus={} ,topChannelModelId={} ,inventory={} ", topChannelId, exchangeId, exchangeTime, exchangeWeek, exchangeStatus, topChannelModelId, inventory);
                return TopChannelErrMsgEnum.REAPIR_TASK.getKey();
            }


            //根据topChannelModelId判断是新增还是修改
            if (topChannelModelId == null) {

                timedTaskModel.setTypeName(SCHEDULE_TO_ORDER_NAME);
                timedTaskModel.setTaskType(SCHEDULE_TO_ORDER);
                timedTaskModel.setTypeId(getTypeIdByScheduleToOrder());
                timedTaskModel.setRemark("");
                timedTaskModel.setIsOpen(true);
                timedTaskModel.setCreateDate(new Timestamp(System.currentTimeMillis()));


                topChannelTaskTimeDao.saveTopChannelTime(topChannelModel);

                //新增时候 将topChannelModelId查询出来
                topChannelModelId = topChannelTaskTimeDao.findChannelIdByIdsAndExchangeTime(topChannelId, exchangeId, varietyId, simple.get().parse(exchangeTime)).getId();
                timedTaskModel.setTopTimeTaskId(topChannelModelId);
                timedTaskDao.createTimedTask(timedTaskModel);

            } else {

                topChannelModel.setId(topChannelModelId);

                timedTaskModel.setTopTimeTaskId(topChannelModelId);
                timedTaskDao.updateTimedByExchangeIdAndTopChannelId(timedTaskModel);

                topChannelTaskTimeDao.updateTopChannelTimeById(topChannelModel);
            }

            //添加通知schedule

            try {

                //查找获取Id
                TimedTaskModel task = timedTaskDao.findTimedTaskIdByIds(exchangeId, topChannelId, topChannelModelId);

                if (task != null && task.getId() != null) {
                    Map<String, Object> json = new HashMap<>();

                    if (topChannelModelId != null) {

                        json.put("action", "UPDATE");
                    } else {
                        json.put("action", "ADD");


                    }
                    json.put("id", task.getId());
                    timedTaskChangendSender.sendMessage(JSON.toJSONString(json));


                }


                //添加品种的时间
                //modifyVarietyInventoryByIds(topChannelId, exchangeId, varietyId, topChannelModelId, varietyInventoryId, exchangeStatus);


            } catch (Exception e) {

                logger.error("一级渠道对应修改时间标,通知MQ出错 , topChannelId={} ,exchangeId={},exchangeTime={},exchangeWeek={}", topChannelId, exchangeId, exchangeTime, exchangeWeek, e);

            }


        } catch (Exception e) {
            logger.error("一级渠道对应修改时间标出错 , topChannelId={} ,exchangeId={},exchangeTime={},exchangeWeek={}", topChannelId, exchangeId, exchangeTime, exchangeWeek, e);

        }


        return TopChannelErrMsgEnum.SUCCESS.getKey();

    }


    /**
     * 根据一级渠道找到所有的交易所
     *
     * @param topChannelId 一级渠道的Id
     * @return
     */
    @Override
    public List<TopChannelModel> findAllExchangeByExchangeId(Integer topChannelId, Integer start, Integer pageCount) {

        try {
            //根据当前渠道的id 获取一级渠道下的所有交易所
            List<ChannelExchangeModel> list = firstChannelExchangeDao.getExchangesByChannelId(topChannelId);


            if (list == null || list.size() == 0) {
                logger.error("当前的一级渠道 topChannelId={} 下没有任何的交易所", topChannelId);

                return null;
            }

            Set<Integer> exchangeIds = new HashSet<>();

            for (ChannelExchangeModel model : list) {

                Integer exchangeId = model.getExchangeId();
                if (exchangeId == null) {
                    continue;
                }

                exchangeIds.add(exchangeId);
            }


            //将展示内容格式化
            if (start < 0) {
                start = 0;
            }

            start = start * pageCount;


            List<TopChannelModel> topChannelList = topChannelTaskTimeDao.findTopChannelTimeByChannelIdAndExchangeIds(topChannelId, exchangeIds, start, pageCount);
            if (topChannelList == null || topChannelList.isEmpty()) {
                logger.error("当前的一级渠道 topChannelId={} 下没有任何的时间", topChannelId);

                return null;
            }

            //返回总数目到第一个集合中
            int totalCount = topChannelTaskTimeDao.findTopChannelTimeCountByChannelIdAndExchangeIds(topChannelId, exchangeIds);

            topChannelList.get(0).setTotalCount(totalCount);

            return topChannelList;
        } catch (Exception e) {
            logger.error("当前的一级渠道 topChannelId={} 下出现错误信息 ", topChannelId, e);
            return null;

        }
    }

    /**
     * 根据 id 删除对应的 一级渠道的记录
     *
     * @param topChannelId      一级渠道的Id
     * @param exchangeId        交易所的Id
     * @param topChannelModelId 一级渠道对应的时间表的id
     * @return
     */
    @Override
    public boolean removeTopChannelTimeByIds(Integer topChannelId, Integer exchangeId, Long topChannelModelId) {
        //是否修改成功
        Boolean flag = false;

        try {

            if (topChannelId == null || exchangeId == null || topChannelModelId == null) {
                return flag;

            }

            //先查找 是否存在
            int effectCount = topChannelTaskTimeDao.findChannelIdCountByIds(topChannelId, exchangeId, topChannelModelId);

            if (effectCount == 0) {

                logger.error("已经删除过,重复删除 ,topChannelId={} , exchangeId={} ,topChannelModelId={}", topChannelId, exchangeId, topChannelModelId);

                return flag;
            }

            effectCount = topChannelTaskTimeDao.removeTopChannelTimeById(topChannelId, exchangeId, topChannelModelId);

            if (effectCount != 0) {

                flag = true;
                TimedTaskModel task = timedTaskDao.findTimedTaskIdByIds(exchangeId, topChannelId, topChannelModelId);
                if (task != null) {
                    Map<String, Object> json = new HashMap<>();

                    json.put("action", "DELETE");
                    json.put("id", task.getId());
                    timedTaskChangendSender.sendMessage(JSON.toJSONString(json));


                }
                //删除对应的定时任务
                timedTaskDao.deleteByExchangeIdAndTopChannelId(exchangeId, topChannelId, topChannelModelId);

            }


        } catch (Exception e) {
            logger.error("一级渠道删除失败 , topChannelModelId ={} ", topChannelModelId, e);

        }


        return flag;
    }


    /**
     * 获取任务Id
     *
     * @return
     */

    private Integer getTypeIdByScheduleToOrder() {


        Integer typeId = map.get(SCHEDULE_TO_ORDER);

        try {

            if (typeId == null) {
                //判断是否有该任务
                TaskTypeModel taskTypeModel = taskTypeDao.findCountTaskTypeByTaskType(SCHEDULE_TO_ORDER);


                if (taskTypeModel == null) {

                    taskTypeModel = new TaskTypeModel();

                    taskTypeModel.setTaskType(SCHEDULE_TO_ORDER);
                    taskTypeModel.setTaskName(SCHEDULE_TO_ORDER_NAME);
                    taskTypeModel.setRemark("分配给一级渠道进行清仓和可交易设置");
                    taskTypeDao.creatTaskType(taskTypeModel);

                    taskTypeModel = taskTypeDao.findCountTaskTypeByTaskType(SCHEDULE_TO_ORDER);

                }

                typeId = taskTypeModel.getId();
                //存入map
                map.put(SCHEDULE_TO_ORDER, typeId);

            }

        } catch (Exception e) {
            logger.error("获取任务Id出错 ", e);
        }
        return typeId;

    }


}
