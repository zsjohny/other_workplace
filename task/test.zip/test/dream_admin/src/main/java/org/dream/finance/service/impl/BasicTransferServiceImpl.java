package org.dream.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.dao.FinancePayPlatformBankDao;
import org.dream.finance.dao.FinanceTransferDao;
import org.dream.finance.service.BasicTransferService;
import org.dream.model.finance.FinanceIOModel;
import org.dream.model.finance.FinancePayPlatformBankModel;
import org.dream.model.finance.FinanceTransferModel;
import org.dream.model.user.UserBankCardModel;
import org.dream.user.dao.UserBankCardDao;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BasicTransferServiceImpl implements BasicTransferService {
	private static final Integer WITHDRAW_PERMIT = 1;
	private static final Integer WITHDRAW_TRANSFER = 2;
	@Autowired
	private FinanceIODao ioDao;
	@Autowired
	private UserBankCardDao bankCardDao;
	@Autowired
	private FinancePayPlatformBankDao payPlatformBankDao;
	@Autowired
	private FinanceTransferDao transferDao;

	@Override
	public List<FinanceTransferModel> saveTransfer(List<Integer> idList, FinanceTransferType transferType,
			FinancePayType payType, String operator) {
		List<FinanceTransferModel> list = new ArrayList<FinanceTransferModel>();
		List<FinanceIOModel> ioModels = ioDao.findByIds(idList);
		for (FinanceIOModel ioModel : ioModels) {
			if (!WITHDRAW_PERMIT.equals(ioModel.getStatus())) {
				continue;
			}
			FinanceTransferModel transferModel = new FinanceTransferModel();
			transferModel.setIoId(ioModel.getId());
			transferModel.setTypeDetail(transferType.getTypeDetail());
			transferModel.setRemark(transferType.getRemark());
			transferModel.setUserId(ioModel.getUserId());
			transferModel.setMoney(ioModel.getMoney());
			transferModel.setSelfOrderId(ioModel.getSelfOrderId());
			UserBankCardModel bankCardModel = bankCardDao.find(ioModel.getUserId());
			FinancePayPlatformBankModel payPlatformBankModel = new FinancePayPlatformBankModel();
			payPlatformBankModel.setPayPlatform(payType.getPlatform());
			payPlatformBankModel.setBankId(bankCardModel.getBankId());
			payPlatformBankModel.setStatus(0);
			payPlatformBankModel = payPlatformBankDao.find(payPlatformBankModel);
			transferModel.setRealName(bankCardModel.getRealName());
			transferModel.setCardNo(bankCardModel.getCardNumber());
			transferModel.setBankName(payPlatformBankModel.getPlatformBankName());
			transferModel.setCardPhone(bankCardModel.getCardPhone());
			transferModel.setOperator(operator);
			list.add(transferModel);
		}
		if (list.size() > 0) {
			transferDao.save(list);
			ioDao.updateByIOIds(WITHDRAW_TRANSFER, idList);
		}
		return list;
	}
}
