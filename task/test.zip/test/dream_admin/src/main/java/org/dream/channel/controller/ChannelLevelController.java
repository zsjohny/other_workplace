package org.dream.channel.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.channel.service.ChannelLevelService;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelLevelModel;
import org.dream.model.channel.ChannelModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("channelLevel")
public class ChannelLevelController extends BaseController {

	@Autowired
	private ChannelLevelService channelLevelService;

	@Autowired
	private ChannelService channelService;

	@RequestMapping("/save")
	@ResponseBody
	public Response saveChannelLevel(HttpServletRequest request, Integer level, String levelName, Integer isDefault,
			Integer isDisplay, String advertisement) {
		Assert.notNull(level, "推广等级不能为空");// 默认为1
		Assert.notNull(levelName, "等级名称不能为空");
		Assert.notNull(isDefault, "是否默认不能为空");
		Assert.notNull(isDisplay, "是否展示不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Integer channelId = channelModel.getId();
		// 必須存在一個默認並且展示的推廣等級
		Integer lCount = channelLevelService.findEverCount(channelId, 1, 1, null, null);
		if (lCount == 0) {// 如果表中没有默認並且展示的推廣等級
			if (isDefault == 0 || isDisplay == 0) {// 那么存入的必须是默认且展示的推广等级
				return Response.response(600, "必须设置一个默认并且展示的推广等級");
			}
		}
		Integer nameCount = channelLevelService.findEverCount(channelId, null, null, levelName, null);
		if (nameCount > 0) {
			return Response.response(700, "该等级已存在，请更换等级名称");
		}
		String channelName = channelService.findChannelNameById(channelId);
		ChannelLevelModel channelLevelModel = new ChannelLevelModel();
		channelLevelModel.setChannelId(channelId);
		channelLevelModel.setChannelName(channelName);
		channelLevelModel.setLevel(level);
		channelLevelModel.setLevelName(levelName);
		channelLevelModel.setIsDefault(isDefault);
		channelLevelModel.setIsDisplay(isDisplay);
		channelLevelModel.setAdvertisement(advertisement);
		// 如果该渠道下已经存在默认的推广等级，并且新的是默认，那么将他修改为默认等级
		channelLevelService.saveChannelLevel(channelLevelModel);
		return Response.success();
	}

	/**
	 * 后台分页获取当前渠道下的推广等级
	 */
	@RequestMapping(value = "/querypaging")
	@ResponseBody
	public Response pagingquery(HttpServletRequest request, String levelName, Integer isDisplay, Integer page,
			Integer pageSize) {
		ChannelModel channelModel = getCurrentChannel(request);
		Integer channelId = channelModel.getId();
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		Page<ChannelLevelModel> data = channelLevelService.querypaging(channelId, isDisplay, levelName, page, pageSize);
		return Response.success(data);
	}

	/**
	 * 获取推广等级给用户展示
	 */
	@RequestMapping(value = "/getLevelsForUser")
	@ResponseBody
	public Response getLevelsForUser(HttpServletRequest request) {
		ChannelModel channelModel = getCurrentChannel(request);
		return Response.success(channelLevelService.getLevelsForUser(channelModel.getId()));
	}

	@RequestMapping("/removeByIds")
	@ResponseBody
	public Response removeByIds(String ids, HttpServletRequest request) {
		Assert.notNull(ids, "推广等级id不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		List<Integer> idList = handleIds(ids);
		// 获取目前默认等级的id
		Integer everId = channelLevelService.getLevelsByIsDefault(channelModel.getId(), 1).getId();
		if (idList != null && idList.size() > 0) {
			for (Integer i : idList) {
				if (i == everId) {
					return Response.response(600, "必须设置一个默认并且展示的推广等級");
				}
			}
		}
		channelLevelService.removeByIds(ids);
		return Response.success();
	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@RequestMapping("/updateById")
	@ResponseBody
	public Response updateChannelLevelById(Integer id, Integer channelId, Integer level, String levelName,
			Integer isDefault, Integer isDisplay, String advertisement) {
		Assert.notNull(id, "推广等级id不能为空");
		Assert.notNull(channelId, "渠道id不能为空");
		Assert.notNull(level, "推广等级不能为空");// 默认为1
		Assert.notNull(levelName, "等级名称不能为空");
		Assert.notNull(isDefault, "是否默认不能为空");
		Assert.notNull(isDisplay, "是否展示不能为空");
		ChannelLevelModel channelLevelModel = new ChannelLevelModel();
		/**
		 * 修改前需要做若干判定，1必须有默认且展示的等级，2修改名字不能重复
		 */
		// 判定新的名字除了自己之外是否存在
		Integer aCount = channelLevelService.findEverCount(channelId, null, null, levelName, id);
		if (aCount > 0) {
			return Response.response(700, "该等级已存在，请更换等级名称");
		}
		// 必須存在一個默認並且展示的推廣等級
		if (isDefault == 0 || isDisplay == 0) {
			Integer lCount = channelLevelService.findEverCount(channelId, 1, 1, null, id);
			if (lCount < 1) {
				return Response.response(600, "必须设置一个默认并且展示的推广等級");
			}
		}
		channelLevelModel.setChannelId(channelId);
		channelLevelModel.setLevel(level);
		channelLevelModel.setLevelName(levelName);
		channelLevelModel.setIsDefault(isDefault);
		channelLevelModel.setIsDisplay(isDisplay);
		channelLevelModel.setId(id);
		channelLevelModel.setAdvertisement(advertisement);
		channelLevelService.updateChannelLevelById(channelLevelModel);
		return Response.success();
	}
}
