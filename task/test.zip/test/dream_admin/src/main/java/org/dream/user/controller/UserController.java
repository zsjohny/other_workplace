package org.dream.user.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.model.channel.ChannelModel;
import org.dream.model.user.UserBankCardModel;
import org.dream.model.user.UserManageModel;
import org.dream.model.user.UserModel;
import org.dream.user.service.UserService;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.dream.utils.validate.ValidateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/user")
public class UserController extends BaseController {
	@Autowired
	private UserService userService;

	@RequestMapping("/findByPage")
	@ResponseBody
	public Response findByPage(Integer userId, String userName, String userPhone, Integer channelId,
			Integer topChannelId, String createTimeStart, String createTimeEnd, String lastLoginTimeStart,
			String lastLoginTimeEnd, String realName, String idCard, Integer status, Integer page, Integer pageSize,
			String orderBy, HttpServletRequest request) {
		// status = 0;
		ChannelModel channelModel = getCurrentChannel(request);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		Page<UserManageModel> list = userService.findByPage(id, level, userId, userName, userPhone, channelId,
				topChannelId, createTimeStart, createTimeEnd, lastLoginTimeStart, lastLoginTimeEnd, realName, idCard,
				status, page, pageSize, orderBy);
		return Response.success(list);
	}

	@RequestMapping("/findUser")
	@ResponseBody
	public Response findUser(Integer userId, HttpServletRequest request) {
		Assert.notNull(userId);
		return Response.success(userService.findUser(userId));
	}

	@RequestMapping("/findUserBankCard")
	@ResponseBody
	public Response findUserBankCard(Integer userId, HttpServletRequest request) {
		Assert.notNull(userId);
		return Response.success(userService.findUserBankCard(userId));
	}

	@RequestMapping(value = { "/updateUserBankCard", "/unbundleIDCard" })
	@ResponseBody
	public Response updateUserBankCard(UserBankCardModel bankCardModel, HttpServletRequest request) {
		// 修改权限问题
		return userService.updateUserBankCard(bankCardModel);
	}

	@RequestMapping(value = { "/updateUser", "/unbundlePhone" })
	@ResponseBody
	public Response updateUser(UserModel userModel, HttpServletRequest request) {
		// 修改权限问题
		return userService.updateUser(userModel);
	}
}
