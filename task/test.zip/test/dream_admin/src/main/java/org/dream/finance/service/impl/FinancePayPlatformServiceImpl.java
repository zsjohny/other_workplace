package org.dream.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.dream.finance.dao.FinancePayPlatformDao;
import org.dream.finance.service.FinancePayPlatformService;
import org.dream.model.finance.FinancePayPlatformModel;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinancePayPlatformServiceImpl implements FinancePayPlatformService {
	private static final Integer ERROR_CODE = 600;
	private static final Integer SUCCEED_CODE = 200;
	@Autowired
	FinancePayPlatformDao financePayPlatformDao;

	@Override
	public Response saveFinancePayPlatform(FinancePayPlatformModel payPlatformModel) {
		FinancePayPlatformModel model = financePayPlatformDao.check(payPlatformModel);
		if (model != null)
			return Response.response(ERROR_CODE, "支付平台已存在");
		financePayPlatformDao.saveFinancePayPlatform(payPlatformModel);
		return Response.response(SUCCEED_CODE, "保存支付平台成功");
	}

	@Override
	public Response updateFinancePayPlatform(FinancePayPlatformModel payPlatformModel) {
//		FinancePayPlatformModel model = financePayPlatformDao.check(payPlatformModel);
//		if (model != null)
//			return Response.response(ERROR_CODE, "支付平台已存在");
		financePayPlatformDao.updateFinancePayPlatform(payPlatformModel);
		return Response.response(SUCCEED_CODE, "更新支付平台成功");
	}

	@Override
	public FinancePayPlatformModel getById(Integer id) {

		return financePayPlatformDao.getById(id);
	}

	@Override
	public Page<FinancePayPlatformModel> querypaging(FinancePayPlatformModel model, Integer pageIndex,
			Integer size) {
		Integer limit = pageIndex > 0 ? pageIndex * size : 0 * size;

		List<FinancePayPlatformModel> result = financePayPlatformDao.querypaging(model, limit, size);
		Integer totalCount = financePayPlatformDao.querypaging_count(model);
		Page<FinancePayPlatformModel> page = new Page<>(pageIndex, size, totalCount);
		page.setData(result);

		return page;
	}

	@Override
	public void removeFinancePayPlatform(String ids) {

		List<Integer> idList = this.handleIds(ids);
		for (Integer id : idList) {
			financePayPlatformDao.removeFinancePayPlatform(id);
		}
	}

	private List<Integer> handleIds(String ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	@Override
	public List<FinancePayPlatformModel> findPayPlatformAll(FinancePayPlatformModel payPlatformModel) {
		return financePayPlatformDao.findAll(payPlatformModel);
	}

}
