package org.dream.order.service.impl;

import java.util.List;

import org.dream.model.order.ChannelExchangeModel;
import org.dream.order.dao.ChannelExchangeDao;
import org.dream.order.service.ChannelExchangeService;
import org.dream.utils.mvc.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChannelExchangeServiceImpl implements ChannelExchangeService {

	@Autowired
	ChannelExchangeDao ChannelExchangeDao;

	@Override
	public List<ChannelExchangeModel> getExchangesByChannelId(Integer channelId) {
		return ChannelExchangeDao.getExchangesByChannelId(channelId);
	}

	@Override
	public void insert(ChannelExchangeModel exchangeModel) {
		ChannelExchangeDao.insert(exchangeModel);
	}

	@Override
	public Page<ChannelExchangeModel> querypaging(Integer channelId, Integer pageIndex, Integer pageSize) {
		Integer limit = pageIndex > 0 ? pageIndex * pageSize : 0 * pageSize;
		List<ChannelExchangeModel> channelExchangeModels = ChannelExchangeDao.qureypaging(channelId, limit, pageSize);
		int totalCount = ChannelExchangeDao.qureypaging_count(channelId);
		Page<ChannelExchangeModel> resultPage = new Page<ChannelExchangeModel>(pageIndex, pageSize, totalCount);
		resultPage.setData(channelExchangeModels);
		return resultPage;
	}

}
