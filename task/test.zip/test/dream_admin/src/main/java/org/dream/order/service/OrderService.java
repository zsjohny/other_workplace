package org.dream.order.service;

import java.util.List;
import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.OrderCashCount;
import org.dream.model.order.OrderSunModel;
import org.dream.utils.mvc.Page;

public interface OrderService {

	public Page<OrderSunModel> queryIntegralOrderList(OrderSunModel ordersun, ChannelModel cm);

	public List<Map<String, Object>> getVarietyIdAndVarietyName();

	public OrderSunModel getOrderSunModelByIdForIntegral(int id);

	public OrderSunModel getOrderSunModelByIdForCash(int id);

	public Page<OrderSunModel> queryCashOrderList(OrderSunModel ordersun, ChannelModel cm);

	public Map<String, Object> dealWithPositionFailure(int id, int oneChannelId);

	public Map<String, Object> dealWithPosition(int id, String realAvgPrice, int realHandsNum, String time,
			int oneChannelId);

	public Map<String, Object> dealWithUnwindProcessFailure(int id, int oneChannelId);

	public Map<String, Object> dealWithUnwind(int id, String unwindAvgPrice, String time, int unwindType,
			int oneChannelId,String userAccount);

	public Map<String, Object> batchFailure(String orderms, int oneChannelId);

	public Map<String, Object> batchSuccess(String orderms, String userAccount, String price, String time,
			Integer unwindType, int oneChannelId);

	public OrderCashCount getOrderCashCount(ChannelModel cm);

	public Integer getBearishCount(ChannelModel cm);

	public Integer getCandoCoun(ChannelModel cm);

	public OrderCashCount countCashOrderList(OrderSunModel ordersun, ChannelModel cm);
	
	public Map<String,Object> dealWithOpsitionSettle(int id, String unwindAvgPrice, String time, int unwindType,
			int oneChannelId,String userAccount);
	
	public Map<String,Object> opsitionRiskUnwind(int id , int unwindType,int oneChannelId);
	
}
