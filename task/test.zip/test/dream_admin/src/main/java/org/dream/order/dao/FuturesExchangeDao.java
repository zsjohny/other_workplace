package org.dream.order.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.order.FuturesExchangeModel;

/**
 * 期货交易市场Dao
 * 
 * @author
 *
 */
public interface FuturesExchangeDao {

	public void createFuturesExchange(FuturesExchangeModel futuresExchangeMoudel);

	public void updateFuturesExchange(FuturesExchangeModel futuresExchangeMoudel);

	public void removeFuturesExchangeByIds(@Param(value = "ids") List<Integer> ids);

	public FuturesExchangeModel getById(@Param(value = "id") Integer id);

	public List<FuturesExchangeModel> qureypaging(@Param(value = "exchangeName") String exchangeName,
			@Param(value = "exchangeCode") String exchangeCode, @Param(value = "futuresRemark") String futuresRemark,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "exchangeName") String exchangeName,
			@Param(value = "exchangeCode") String exchangeCode, @Param(value = "futuresRemark") String futuresRemark);

	public List<FuturesExchangeModel> getAll();

	public List<FuturesExchangeModel> getExchangeForSelect();
	
	public int getCountByExchangeName(String exchangeName);
	
	public int getCountByExchangeCode(String exchangeCode);
}
