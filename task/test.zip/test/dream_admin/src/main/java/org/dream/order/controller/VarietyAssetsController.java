package org.dream.order.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.VarietyAssetsModel;
import org.dream.order.service.VarietyAssetsService;
import org.dream.order.service.VarietyPriceService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping("/varietyAssets")
@Controller
public class VarietyAssetsController extends BaseController {
	@Autowired
	private VarietyAssetsService varietyAssetsService;

	@Autowired
	private VarietyPriceService varietyPriceService;

	/**
	 * 查找品种，用于前端的下拉框显示
	 * 
	 */
	@RequestMapping(value = "getVariety", method = { RequestMethod.POST })
	@ResponseBody
	public Response getVariety() {
		List<Map<String, Object>> map = varietyPriceService.getVariety();
		return Response.success(map);
	}

	/**
	 * 新增
	 * 
	 * 前台需要传入：varietyId,varietyType,
	 * handsMultiple,marginBeat,stopLossBeat,stopWinBeat,isdefault
	 */
	@RequestMapping(value = "/save", method = { RequestMethod.POST })
	@ResponseBody
	public Response saveVarietyAssets(VarietyAssetsModel varietyAssetsModel, HttpServletRequest request) {
		// 新增前，需要获取渠道id和用户id
		if (StringUtils.isBlank(varietyAssetsModel.getVarietyId().toString())
				|| StringUtils.isBlank(varietyAssetsModel.getVarietyType())
				|| StringUtils.isBlank(varietyAssetsModel.getHandsMultiple())
				|| StringUtils.isBlank(varietyAssetsModel.getMarginBeat().toString())
				|| StringUtils.isBlank(varietyAssetsModel.getStopWinBeat())
				|| StringUtils.isBlank(varietyAssetsModel.getStopLossBeat().toString())
				|| StringUtils.isBlank(varietyAssetsModel.getIsdefault().toString())) {
			return Response.response(600, "请求参数错误");
		}
		ChannelModel channelModel = getCurrentChannel(request);
		Integer userId = (Integer) request.getSession().getAttribute("userId");
		// 首先判断这个品种，在相同渠道下是否已经有默认配资了
		if (varietyAssetsModel.getIsdefault() == 1) {
			Integer count = varietyAssetsService.getVarietyAssetsCountByChannelAndVariety(
					varietyAssetsModel.getVarietyId(), channelModel.getId(), null);
			if (count > 0) {
				return Response.response(700, "该品种的默认价格配置已存在");
			}

		}
		varietyAssetsModel.setCreateUserId(userId);
		varietyAssetsModel.setChannelId(channelModel.getId());
		varietyAssetsModel.setStopWinBeat(VarietyAssetsController.bubbleSort(varietyAssetsModel.getStopWinBeat()));
		varietyAssetsModel.setHandsMultiple(VarietyAssetsController.bubbleSort(varietyAssetsModel.getHandsMultiple()));
		Map<String, Object> map = varietyAssetsService.saveVarietyAssets(varietyAssetsModel);
		return Response.success(map);
	}

	/**
	 * 修改
	 * 
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateVarietyAssets(VarietyAssetsModel varietyAssetsModel, HttpServletRequest request) {
		if (StringUtils.isBlank(varietyAssetsModel.getId().toString())
				|| StringUtils.isBlank(varietyAssetsModel.getHandsMultiple())
				|| StringUtils.isBlank(varietyAssetsModel.getMarginBeat().toString())
				|| StringUtils.isBlank(varietyAssetsModel.getStopWinBeat())
				|| StringUtils.isBlank(varietyAssetsModel.getStopLossBeat().toString())
				|| StringUtils.isBlank(varietyAssetsModel.getIsdefault().toString())) {
			return Response.response(600, "请求参数错误");
		}
		ChannelModel channelModel = getCurrentChannel(request);
		// 首先判断这个品种，在相同渠道下是否已经有默认配资了
		if (varietyAssetsModel.getIsdefault() == 1) {
			Integer count = varietyAssetsService.getVarietyAssetsCountByChannelAndVariety(
					varietyAssetsModel.getVarietyId(), channelModel.getId(), varietyAssetsModel.getId());
			// 还要判定是否是同一条数据,如果只是对一个默认配资进行了修改，则要排除这个情况。
			if (count > 0) {
				VarietyAssetsModel vam = varietyAssetsService.getVarietyAssetsById(varietyAssetsModel.getId());

				return Response.response(700, "该品种的默认价格配置已存在");
			}

		}
		// String[] strs = varietyAssetsModel.getHandsMultiple();

		Integer userId = (Integer) request.getSession().getAttribute("userId");
		varietyAssetsModel.setUpdateUserId(userId);
		varietyAssetsModel.setStopWinBeat(VarietyAssetsController.bubbleSort(varietyAssetsModel.getStopWinBeat()));
		varietyAssetsModel.setHandsMultiple(VarietyAssetsController.bubbleSort(varietyAssetsModel.getHandsMultiple()));
		Map<String, Object> map = varietyAssetsService.updateVarietyAssets(varietyAssetsModel,
				getCurrentChannel(request));
		return Response.success(map);
	}

	/**
	 * 删除
	 * 
	 */
	@RequestMapping(value = "/remove", method = { RequestMethod.POST })
	@ResponseBody
	public Response delVarietyAssets(String ids, HttpServletRequest request) {
		Assert.notNull(ids, "ids不能为空");
		// List<Integer> idList = handleIds(ids);
		// for (Integer id : idList) {
		varietyAssetsService.removeVarietyAssets(ids, getCurrentChannel(request).getId());
		// }
		return Response.success();
	}

	/**
	 * 查询
	 * 
	 */
	@RequestMapping(value = "/querypaging", method = { RequestMethod.POST })
	@ResponseBody
	public Response pagingQueryVarietyAssets(Integer page, Integer pageSize, Integer varietyId, String createTimeStart,
			String createTimeEnd, HttpServletRequest request) {
		Page<VarietyAssetsModel> data = varietyAssetsService.pagingQueryVarietyAssets(page, pageSize, varietyId,
				createTimeStart, createTimeEnd, getCurrentChannel(request).getId());
		return Response.success(data);
	}

	/**
	 * 根据id得到某个品种的配资表
	 * 
	 */
	@RequestMapping(value = "/getVarietyAssets", method = { RequestMethod.POST })
	@ResponseBody
	public Response getVarietyAssetsById(Integer id) {
		Assert.notNull(id, "id不能为空");
		VarietyAssetsModel v = varietyAssetsService.getVarietyAssetsById(id);
		return Response.success(v);
	}

	// public static void main(String[] args) {
	// String a = "1,5,2,3,4";
	// bubbleSort(a);
	// }

	/**
	 * 冒泡排序
	 * 基本思想：在要排序的一组数中，对当前还未排好序的范围内的全部数，自上而下对相邻的两个数依次进行比较和调整，让较大的数往下沉，较小的往上冒。即：
	 * 每当两相邻的数比较后发现它们的排序与排序要求相反时，就将它们互换。
	 */
	public static String bubbleSort(String str) {
		String[] strarr = str.split(",");
		int[] array = new int[strarr.length];
		for (int i = 0; i < strarr.length; i++) {
			array[i] = Integer.parseInt(strarr[i]);
		}
		int temp;
		for (int i = 0; i < array.length; i++) {// 趟数
			for (int j = 0; j < array.length - i - 1; j++) {// 比较次数
				if (array[j] > array[j + 1]) {
					temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;
				}
			}
		}
		String s = Arrays.toString(array).replace(" ", "");
		return s.substring(1, s.length() - 1);
	}

}
