package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceCollectService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceCollectModel;
import org.dream.model.finance.FinanceCommissionIOModel;
import org.dream.model.finance.FinanceIOManageModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceCollectController extends BaseController {

	@Autowired
	FinanceCollectService financeCollectService;

	/**
	 * 现金流水的汇总
	 */
	@RequestMapping("/findCollectMoneyFlow")
	@ResponseBody
	public Response findCollectMoneyFlow(String createTimeStart, String createTimeEnd, Integer userId, String userName,
			String userPhone, Integer channelId, Integer topChannelId, Integer type, Integer typeDetail, String remark,
			String flow, HttpServletRequest request) {
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		FinanceCollectModel data = financeCollectService.findCollectMoneyFlow(id, level, createTimeStart, createTimeEnd,
				userId, userName, userPhone, channelId, topChannelId, type, typeDetail, remark, flow);
		return Response.success(data);

	}

	/**
	 * 明细提现 汇总
	 * 
	 * @param model
	 * @param page
	 * @param pageSize
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectDraw")
	@ResponseBody
	public Response findCollectDraw(FinanceIOManageModel model, HttpServletRequest request) {
		model.setType(-1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		FinanceCollectModel data = financeCollectService.findCollect(model, id, level);
		return Response.success(data);

	}

	/**
	 * 明细充值 汇总
	 * 
	 * @param model
	 * @param page
	 * @param pageSize
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectRecharge")
	@ResponseBody
	public Response findCollectRecharge(FinanceIOManageModel model, HttpServletRequest request) {
		model.setType(1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		FinanceCollectModel data = financeCollectService.findCollect(model, id, level);
		return Response.success(data);
	}

	/**
	 * 明细转账 汇总
	 * 
	 * @param userId
	 * @param userName
	 * @param userPhone
	 * @param realName
	 * @param transferType
	 * @param status
	 * @param operator
	 * @param createTimeStart
	 * @param createTimeEnd
	 * @param updateTimeStart
	 * @param updateTimeEnd
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectTransfer")
	@ResponseBody
	public Response findCollectTransfer(Integer userId, String userName, String userPhone, String realName,
			String transferType, Integer status, String operator, String createTimeStart, String createTimeEnd,
			String updateTimeStart, String updateTimeEnd, HttpServletRequest request) {
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		FinanceCollectModel data = financeCollectService.findCollectTransfer(userId, userName, userPhone, realName,
				transferType, status, operator, createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd,
				channelId);
		return Response.success(data);
	}

	/**
	 * 审核提现 汇总
	 * 
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectDrawCheck")
	@ResponseBody
	public Response findCollectDrawCheck(FinanceIOManageModel model, HttpServletRequest request) {
		model.setType(-1);
		model.setStatus(0);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		FinanceCollectModel data = financeCollectService.findCollect(model, id, level);
		return Response.success(data);
	}

	/**
	 * 操作转账 汇总
	 * 
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectDrawChecked")
	@ResponseBody
	public Response findCollectDrawChecked(FinanceIOManageModel model, HttpServletRequest request) {
		model.setType(-1);
		model.setStatus(1);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		FinanceCollectModel data = financeCollectService.findCollect(model, id, level);
		return Response.success(data);
	}

	/**
	 * 佣金流水 汇总
	 * 
	 * @param commissionIOModel
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectCommission")
	@ResponseBody
	public Response findCollectCommission(FinanceCommissionIOModel commissionIOModel, HttpServletRequest request) {
		Integer channelId = getDataId(request);
		commissionIOModel.setChannelId(channelId);
		FinanceCollectModel data = financeCollectService.findCollectCommission(commissionIOModel);
		return Response.success(data);

	}
	
	/**
	 * 操作转账恢复 汇总
	 * 
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/findCollectTransferFailed")
	@ResponseBody
	public Response findCollectTransferFailed(FinanceIOManageModel model, HttpServletRequest request) {
		model.setType(-1);
		model.setStatus(5);
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer id = channelModel.getId();
		Integer level = channelModel.getLevel();
		FinanceCollectModel data = financeCollectService.findCollect(model, id, level);
		return Response.success(data);
	}
}
