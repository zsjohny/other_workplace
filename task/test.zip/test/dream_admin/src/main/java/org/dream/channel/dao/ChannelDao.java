package org.dream.channel.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.channel.ChannelModel;

public interface ChannelDao {

	/**
	 * 根据id获得一个渠道对象
	 * 
	 * @param id
	 * @return
	 */
	public ChannelModel getById(@Param(value = "id") Integer id);

	public ChannelModel findChannelByDomain(String domain);

	/**
	 * 根据后台的域名获得Channel实体
	 * 
	 * @param backstageDomain
	 * @return
	 */
	public ChannelModel findChannelByBackstageDomain(@Param(value = "backstageDomain") String backstageDomain);

	public List<ChannelModel> findChannelAll();

	public void saveChannel(ChannelModel channelModel);

	/**
	 * 展示所有一级渠道
	 * 
	 * @return
	 */
	public List<ChannelModel> findAllFirstChannels();

	/**
	 * \ 根据id获取一级渠道下的子渠道
	 * 
	 * @param id
	 * @return
	 */
	public List<ChannelModel> findSecondChannelsBySuperId(Integer id);

	public void updateChannel(ChannelModel channelModel);

	public void removeChannel(Integer id);

	public String findChannelNameById(Integer id);

	/**
	 * 分页查询渠道列表
	 * 
	 * @param domain
	 * @param name
	 * @param description
	 * @param status
	 * @param superId
	 * @param limit
	 * @param size
	 * @return
	 */
	public List<ChannelModel> querypaging(@Param(value = "domain") String domain, @Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "status") Integer status,
			@Param(value = "superId") Integer superId, @Param(value = "backstageDomain") String backstageDomain,
			@Param(value = "userAccount") String userAccount, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer querypaging_count(@Param(value = "domain") String domain, @Param(value = "name") String name,
			@Param(value = "description") String description, @Param(value = "status") Integer status,
			@Param(value = "superId") Integer superId, @Param(value = "backstageDomain") String backstageDomain,
			@Param(value = "userAccount") String userAccount);

	public Integer findCount(@Param(value = "domain") String domain, @Param(value = "name") String name,
			@Param(value = "backstageDomain") String backstageDomain, @Param(value = "id") Integer id);
}
