package org.dream.shoppingMall.service.impl;

import java.util.List;

import org.dream.finance.dao.FinanceAccDao;
import org.dream.finance.dao.FinanceFlowDao;
import org.dream.finance.dao.FinanceMainDao;
import org.dream.model.finance.FinanceAccModel;
import org.dream.model.finance.FinanceFlowModel;
import org.dream.model.finance.FinanceMainModel;
import org.dream.model.shoppingMall.ShoppingModel;
import org.dream.shoppingMall.dao.ShoppingMallCheckDao;
import org.dream.shoppingMall.service.ShoppingMallCheckService;
import org.dream.utils.constants.FinanceShoppingType;
import org.dream.utils.math.Arith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShoppingMallCheckServiceImpl implements ShoppingMallCheckService {

	@Autowired
	private ShoppingMallCheckDao shoppingMallCheckDao;

	@Autowired
	private FinanceMainDao financeMainDao;

	@Autowired
	private FinanceAccDao financeAccDao;

	@Autowired
	private FinanceFlowDao financeFlowDao;

	@Override
	public void checkSuccessShopping(Integer status, Integer channelId, List<Integer> idList) {
		List<ShoppingModel> list = shoppingMallCheckDao.findByIds(channelId,idList);
		for (ShoppingModel model : list) {
			if (model.getStatus() != 0) {
				return;
			}
			Integer userId = model.getUserId();
			Double score = model.getScore();
			FinanceMainModel financeMainModel = financeMainDao.find(userId);
			Double scoreFrozen = Arith.subtract(financeMainModel.getScoreFrozen(), score);
			financeMainModel.setScoreFrozen(scoreFrozen);
			financeMainDao.update(financeMainModel);
			FinanceAccModel financeAccModel = financeAccDao.find(userId);
			Double shoppingScore = Arith.add(financeAccModel.getShoppingScore(), score);
			financeAccModel.setShoppingScore(shoppingScore);
			financeAccDao.update(financeAccModel);
		}
		shoppingMallCheckDao.checkShoppingByIds(status, channelId, idList);
	}

	@Override
	public void checkFailShopping(Integer status, Integer channelId, List<Integer> idList) {
		List<ShoppingModel> list = shoppingMallCheckDao.findByIds(channelId,idList);
		for (ShoppingModel model : list) {
			if (model.getStatus() != 0) {
				return;
			}
			Integer userId = model.getUserId();
			Double score = model.getScore();
			FinanceMainModel financeMainModel = financeMainDao.find(userId);
			Double scoreUsable = Arith.add(financeMainModel.getScoreUsable(), score);
			Double scoreFrozen = Arith.subtract(financeMainModel.getScoreFrozen(), score);
			financeMainModel.setScoreUsable(scoreUsable);
			financeMainModel.setScoreFrozen(scoreFrozen);
			financeMainDao.update(financeMainModel);
			FinanceFlowModel financeFlowModel = new FinanceFlowModel();
			financeFlowModel.setUserId(userId);
			financeFlowModel.setType(FinanceShoppingType.PURCHASE_REFUSE.getType());
			financeFlowModel.setTypeDetail(FinanceShoppingType.PURCHASE_REFUSE.getTypeDetail());
			financeFlowModel.setRemark(FinanceShoppingType.PURCHASE_REFUSE.getRemark());
			financeFlowModel.setScore(score);
			financeFlowModel.setScoreLeft(scoreUsable);
			financeFlowDao.save(financeFlowModel);
		}
		shoppingMallCheckDao.checkShoppingByIds(status, channelId, idList);
	}

}
