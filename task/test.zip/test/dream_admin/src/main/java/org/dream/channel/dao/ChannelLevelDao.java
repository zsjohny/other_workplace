package org.dream.channel.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.channel.ChannelLevelModel;

public interface ChannelLevelDao {
	public void save(ChannelLevelModel channelLevelModel);

	public void updateChannelLevelById(ChannelLevelModel channelLevelModel);

	public List<ChannelLevelModel> getAllByChannelId(@Param(value = "channelId") Integer channelId);

	public Integer findEverCount(@Param(value = "channelId") Integer channelId,
			@Param(value = "isDisplay") Integer isDisplay, @Param(value = "isDefault") Integer isDefault,
			@Param(value = "levelName") String levelName, @Param(value = "id") Integer id);

	public void removeByIds(@Param(value = "ids") List<Integer> ids);

	public List<ChannelLevelModel> qureypaging(@Param(value = "channelId") Integer channelId,
			@Param(value = "isDisplay") Integer isDisplay, @Param(value = "levelName") String levelName,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "channelId") Integer channelId,
			@Param(value = "isDisplay") Integer isDisplay, @Param(value = "levelName") String levelName);

	public ChannelLevelModel findEver(@Param(value = "channelId") Integer channelId, @Param(value = "id") Integer id,
			@Param(value = "levelName") String levelName);

	public List<ChannelLevelModel> getLevelsForUser(@Param(value = "channelId") Integer channelId);

	public ChannelLevelModel getLevelsByIsDefault(@Param(value = "channelId") Integer channelId,
			@Param(value = "isDefault") Integer isDefault);

}
