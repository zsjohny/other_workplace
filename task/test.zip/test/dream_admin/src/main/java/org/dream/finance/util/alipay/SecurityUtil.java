package org.dream.finance.util.alipay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.SignatureException;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;

public class SecurityUtil {
	/**
	 * 生成文件摘要
	 * 
	 * @param strFile
	 *            文件字节
	 * @param file_digest_type
	 *            摘要算法
	 * @return 文件摘要结果
	 */
	public static String getAbstract(byte[] strFile, String file_digest_type) throws IOException {
		if (file_digest_type.equals("MD5")) {
			return DigestUtils.md5Hex(strFile);
		} else if (file_digest_type.equals("SHA")) {
			return DigestUtils.sha256Hex(strFile);
		} else {
			return "";
		}
	}

	/**
	 * 签名字符串
	 * 
	 * @param text
	 *            需要签名的字符串
	 * @param key
	 *            密钥
	 * @param input_charset
	 *            编码格式
	 * @return 签名结果
	 */
	public static String sign(String text, String key, String input_charset) {
		text = text + key;
		return DigestUtils.md5Hex(getContentBytes(text, input_charset));
	}

	/**
	 * @param content
	 * @param charset
	 * @return
	 * @throws SignatureException
	 * @throws UnsupportedEncodingException
	 */
	private static byte[] getContentBytes(String content, String charset) {
		if (charset == null || "".equals(charset)) {
			return content.getBytes();
		}
		try {
			return content.getBytes(charset);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("MD5签名过程中出现错误,指定的编码集不对,您目前指定的编码集是:" + charset);
		}
	}

	/**
	 * 生成签名结果
	 * 
	 * @param sPara
	 *            要签名的数组
	 * @return 签名结果字符串
	 */
	public static String buildRequestMysign(Map<String, String> sPara, String md5Key) {
		String prestr = ParamUtil.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		String mysign = "";
		if (ParamUtil.sign_type.equals("MD5")) {
			mysign = sign(prestr, md5Key, ParamUtil.input_charset);
		}
		return mysign;
	}
}
