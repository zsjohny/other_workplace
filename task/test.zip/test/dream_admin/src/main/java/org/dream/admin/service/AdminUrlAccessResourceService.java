package org.dream.admin.service;

import java.util.List;
import java.util.Map;

import org.dream.admin.model.AdminSecurityResourceModel;
import org.dream.admin.model.AdminUrlAccessResourceModel;
import org.dream.utils.mvc.Page;

/**
 * URL 访问资源权限
 * 
 * @author wangd
 *
 */
public interface AdminUrlAccessResourceService {

	public void saveUrlAccess(AdminUrlAccessResourceModel accessResourceModel);

	public void updateUrlAccess(AdminUrlAccessResourceModel accessResourceModel);

	public void deleteUrlAccess(List<Integer> ids);

	public Page<AdminUrlAccessResourceModel> pagingQueryPermissions(Integer page, Integer pageSize,
			Map<String, Object> param);

	/**
	 * 根据角色ID批量删除角色下的URL访问资源纪录
	 * 
	 * @param roleId
	 * @param urlAccessResourceIdList
	 *            URL权限访问记录Id集合
	 */
	public void terminateUrlAccessResourcesFromRole(Integer roleId, List<Integer> urlAccessResourceIdList,
			Integer dataId);

	/**
	 * 根据url地址判断该地址是否已经存在， 适用于数据保存之前的验证和保存的时候的验证
	 * 
	 * @param url
	 * @return true : URL 地址已经存在； false： 不存在该URL地址
	 */
	public boolean hasUrlAccessByUrlAddress(String url, Integer type);

	/**
	 * 根据参与者Id获得分配给参与者的URL资源
	 * 
	 * @param actorId
	 * @return
	 */
	public List<AdminUrlAccessResourceModel> getUrlAccessResourcesByActorId(Integer actorId, Integer dataId);

	public List<AdminUrlAccessResourceModel> getUrlAccessByRoleId(Integer roleId, Integer dataId);

	/**
	 * 
	 * @param menuId
	 * @param category
	 * @param type
	 * @return
	 */
	public List<AdminSecurityResourceModel> getAllByMenuId(Integer menuId, String category, Integer type);

	/**
	 * 获取用户下的权限
	 * 
	 * @param actorId
	 * @param dataId
	 * @return
	 */
	public List<AdminSecurityResourceModel> getSecurityResourcesByActorId(Integer actorId, Integer dataId,
			String category);
}
