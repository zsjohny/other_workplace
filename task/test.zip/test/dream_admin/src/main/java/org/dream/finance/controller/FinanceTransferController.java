package org.dream.finance.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.service.FinanceCertService;
import org.dream.finance.service.FinanceService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceCertModel;
import org.dream.model.finance.FinanceTransferManageModel;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceTransferController extends BaseController {
	@Autowired
	private FinanceService financeService;
	@Autowired
	private FinanceCertService certService;

	@RequestMapping("/findTransferByPage")
	@ResponseBody
	public Response findTransferByPage(Integer userId, String userName, String userPhone, String realName,
			String transferType, Integer status, String operator, String createTimeStart, String createTimeEnd,
			String updateTimeStart, String updateTimeEnd, Integer page, Integer pageSize, HttpServletRequest request) {
		Assert.notNull(page, "页面不能为空");
		Assert.notNull(pageSize, "页面数不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		Page<FinanceTransferManageModel> list = financeService.findTransferByPage(userId, userName, userPhone, realName,
				transferType, status, operator, createTimeStart, createTimeEnd, updateTimeStart, updateTimeEnd,
				channelId, page, pageSize);
		return Response.success(list);
	}

	@RequestMapping("/findTransferPlatform")
	@ResponseBody
	public Response findTransferPlatform(HttpServletRequest request) {
		FinanceCertModel certModel = new FinanceCertModel();
		certModel.setType(1);
		certModel.setStatus(0);
		certModel.setChannelId(getDataId(request));
		List<String> list = certService.findPlatformAll(certModel);
		return Response.response(ResponseCode.SUCCESS_CODE, "获取转账平台成功", list);
	}
}
