package org.dream.config.service;

import java.util.List;

import org.dream.config.model.TimedTaskModel;
import org.dream.utils.mvc.Page;

/**
 * 定时任务管理Service
 * 
 * @author wangd
 *
 */
public interface TimedTaskService {

	public void saveTiemdTask(TimedTaskModel taskModel);

	public void updateTiemdTask(TimedTaskModel taskModel);

	public void deleteByIds(String ids);

	public List<TimedTaskModel> getAllOpenTasks();

	public void changeIsOpenByIds(String ids, Boolean isOpen);

	public Page<TimedTaskModel> querypaging(Integer typeId, Boolean isOpen, Integer pageIndex, Integer pageSize);

	public void instantlyExecute(int taskId, String taskType, String parameters);
}
