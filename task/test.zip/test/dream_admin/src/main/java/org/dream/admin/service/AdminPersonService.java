package org.dream.admin.service;

import java.util.List;

import org.dream.admin.model.AdminPersonModel;
import org.dream.utils.mvc.Page;

/**
 * 人员服务层接口
 * @author wangd
 *
 */
public interface AdminPersonService {

    public void savePerson(AdminPersonModel personMoudel, Integer dempatmentId);
    
    public void updatePerson(AdminPersonModel personMoudel);
    
    public AdminPersonModel getById(Integer id);
    
    public void deleteByPersonId(Integer id);
    
    public void deletePersonsByIds(List<Integer> ids);
    
    public Page<AdminPersonModel> pagingQueryPersons(String name, String gender, String idNumber, String mobilePhone, String familyPhone, String email, String description, Integer pageIndex, Integer pageSize);
    
    
}
