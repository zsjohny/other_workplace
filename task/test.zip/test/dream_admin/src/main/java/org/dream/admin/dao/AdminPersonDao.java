package org.dream.admin.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.admin.model.AdminPersonModel;

/**
 * 人员数据库操作接口
 * @author wangd
 *
 */
public interface AdminPersonDao {

    public void createPerson(AdminPersonModel personMoudel);
    
    public void updatePerson(AdminPersonModel personMoudel);
    
    public AdminPersonModel getById(@Param(value="id")Integer id);
    
    public void deltePerson(@Param(value="id")Integer id, @Param(value="ids")List<Integer> ids);
    
    public void deletePersonsByIds(@Param(value="ids")List<Integer> ids);
    
    public List<AdminPersonModel> pagingQueryPersons(
            @Param(value = "name") String name,
            @Param(value = "gender") String gender,
            @Param(value = "idNumber") String idNumber,
            @Param(value = "mobilePhone") String mobilePhone,
            @Param(value = "familyPhone") String familyPhone,
            @Param(value = "email") String email,
            @Param(value = "description") String description,
            @Param(value = "limit") Integer limit,
            @Param(value = "size") Integer size);

    public Integer pagingQueryPersons_count(@Param(value = "name") String name,
            @Param(value = "gender") String gender,
            @Param(value = "idNumber") String idNumber,
            @Param(value = "mobilePhone") String mobilePhone,
            @Param(value = "familyPhone") String familyPhone,
            @Param(value = "email") String email,
            @Param(value = "description") String description);
    /**
     * 保存部门人员关系
     * @param departmentId
     * @param personId
     */
    public void createDepartmentPerson(@Param(value="departmentId")Integer departmentId, @Param(value="personId")Integer personId);
    
    public void deleteDepartmentPersonByPersonId(@Param(value="personId")Integer personId, @Param(value="personIds")List<Integer> ids);
}
