package org.dream.channel.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.channel.ChannelPromoterModel;

public interface ChannelPromoterDao {
	// V2
	public Integer update(ChannelPromoterModel channelPromoterModel);

	// **************************************************************
	public List<ChannelPromoterModel> findChannelPromoterAll();

	public ChannelPromoterModel findChannelPromoterById(Integer id);

	public List<ChannelPromoterModel> qureypaging(@Param(value = "channelId") Integer channelId,
			@Param(value = "levelId") Integer levelId, @Param(value = "limit") Integer limit,
			@Param(value = "size") Integer size);

	public Integer qureypaging_count(@Param(value = "channelId") Integer channelId,
			@Param(value = "levelId") Integer levelId);

	public void updateChannelPromoter(ChannelPromoterModel channelPromoterModel);

	public List<ChannelPromoterModel> qureypagingSonUser(@Param(value = "promoterId") Integer promoterId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer qureypagingSonUser_count(@Param(value = "promoterId") Integer promoterId);

	public Integer getTotalHandsNumByUserId(@Param(value = "userId") Integer userId);

	public Integer getPromoterIdByUserId(@Param(value = "userId") Integer userId);
}
