package org.dream.order.service;

import java.util.Map;

import org.dream.model.channel.ChannelModel;
import org.dream.model.order.VarietyAssetsModel;
import org.dream.utils.mvc.Page;

public interface VarietyAssetsService {
	public Map<String, Object> saveVarietyAssets(VarietyAssetsModel varietyAssetsModel);

	public Map<String, Object> updateVarietyAssets(VarietyAssetsModel varietyAssetsModel, ChannelModel cm);

	public void removeVarietyAssets(String ids, Integer channelId);

	public Page<VarietyAssetsModel> pagingQueryVarietyAssets(Integer page, Integer pageSize, Integer varietyId,
			String createTimeStart, String createTimeEnd, int channelId);

	public VarietyAssetsModel getVarietyAssetsById(Integer id);

	public Integer getVarietyAssetsCountByChannelAndVariety(Integer varietyId, Integer channelId, Integer id);

}
