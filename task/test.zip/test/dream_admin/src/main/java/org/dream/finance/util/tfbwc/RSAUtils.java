package org.dream.finance.util.tfbwc;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

import javax.crypto.Cipher;

/**
 *
 * 描述:天付宝rsa
 *
 * @author C.C
 * @created 2016年8月30日 下午3:34:34
 * @since v1.0.0
 */
public class RSAUtils {

	public static final String GC_PUBLIC_KEY_PATH = "/stock/tomcat_admin/webapps/adminstock/WEB-INF/classes/gczf_rsa_public.pem";

	public static final String PUBLIC_KEY_PATH = "/stock/tomcat_admin/webapps/adminstock/WEB-INF/classes/dj_rsa_pub.pem";

	public static final String PRIVATE_KEY_PATH = "/stock/tomcat_admin/webapps/adminstock/WEB-INF/classes/dj_rsa_pkcs8.pem";

	/**
	 * 加密算法RSA
	 */
	public static final String KEY_ALGORITHM = "RSA";

	/**
	 * 签名算法
	 */
	public static final String SIGNATURE_ALGORITHM = "SHA1WithRSA";

	/**
	 * RSA最大加密明文大小
	 */
	private static final int MAX_ENCRYPT_BLOCK = 117;

	/**
	 * RSA最大解密密文大小
	 */
	private static final int MAX_DECRYPT_BLOCK = 128;

	/**
	 * <p>
	 * 用私钥对信息生成数字签名
	 * </p>
	 * 
	 * @param data
	 *            已加密数据
	 * @param privateKey
	 *            私钥(BASE64编码)
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String sign(byte[] data, String privateKey) throws Exception {
		byte[] digest = sha1(data);
		byte[] encryptData = encryptByPrivateKey(digest, privateKey);
		return TfbBase64.encode(encryptData);
	}

	private static byte[] sha1(byte[] data) throws NoSuchAlgorithmException {
		MessageDigest md = null;
		md = MessageDigest.getInstance("SHA-1"); // 选择SHA-1，也可以选择MD5
		byte[] digest = md.digest(data); // 返回的是byet[]，要转化为String存储比较方便
		return digest;
	}

	/**
	 * <p>
	 * 校验数字签名
	 * </p>
	 * 
	 * @param data
	 *            已加密数据
	 * @param publicKey
	 *            公钥(BASE64编码)
	 * @param sign
	 *            数字签名
	 * 
	 * @return
	 * @throws Exception
	 * 
	 */
	public static boolean verify(byte[] data, String publicKey, String sign) throws Exception {
		byte[] digest = sha1(data);
		byte[] encryptData = decryptByPublicKey(TfbBase64.decode(sign), publicKey);
		if (Arrays.equals(digest, encryptData)) {
			return true;
		} else {
			return false;
		}
	}

	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder("");
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}

	/**
	 * <P>
	 * 私钥解密
	 * </p>
	 * 
	 * @param encryptedData
	 *            已加密数据
	 * @param privateKey
	 *            私钥(BASE64编码)
	 * @return
	 * @throws Exception
	 */
	public static String decryptByPrivateKey(byte[] encryptedData, String privateKey) throws Exception {
		byte[] keyBytes = TfbBase64.decode(privateKey);
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
		cipher.init(Cipher.DECRYPT_MODE, privateK);
		int inputLen = encryptedData.length;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] cache;
		int i = 0;
		// 对数据分段解密
		while (inputLen - offSet > 0) {
			if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
				cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
			} else {
				cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
			}
			out.write(cache, 0, cache.length);
			i++;
			offSet = i * MAX_DECRYPT_BLOCK;
		}
		byte[] decryptedData = out.toByteArray();
		out.close();
		return new String(decryptedData, "ISO-8859-1");
	}

	/**
	 * <p>
	 * 公钥解密
	 * </p>
	 * 
	 * @param encryptedData
	 *            已加密数据
	 * @param publicKey
	 *            公钥(BASE64编码)
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptByPublicKey(byte[] encryptedData, String publicKey) throws Exception {
		byte[] keyBytes = TfbBase64.decode(publicKey);
		X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		Key publicK = keyFactory.generatePublic(x509KeySpec);
		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
		cipher.init(Cipher.DECRYPT_MODE, publicK);
		int inputLen = encryptedData.length;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] cache;
		int i = 0;
		// 对数据分段解密
		while (inputLen - offSet > 0) {
			if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
				cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
			} else {
				cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
			}
			out.write(cache, 0, cache.length);
			i++;
			offSet = i * MAX_DECRYPT_BLOCK;
		}
		byte[] decryptedData = out.toByteArray();
		out.close();
		return decryptedData;
	}

	/**
	 * <p>
	 * 公钥加密
	 * </p>
	 * 
	 * @param data
	 *            源数据
	 * @param publicKey
	 *            公钥(BASE64编码)
	 * @return
	 * @throws Exception
	 */
	public static String encryptByPublicKey(byte[] data, String publicKey) throws Exception {
		byte[] keyBytes = TfbBase64.decode(publicKey);
		X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		Key publicK = keyFactory.generatePublic(x509KeySpec);
		// 对数据加密
		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
		cipher.init(Cipher.ENCRYPT_MODE, publicK);
		int inputLen = data.length;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] cache;
		int i = 0;
		// 对数据分段加密
		while (inputLen - offSet > 0) {
			if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
				cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
			} else {
				cache = cipher.doFinal(data, offSet, inputLen - offSet);
			}
			out.write(cache, 0, cache.length);
			i++;
			offSet = i * MAX_ENCRYPT_BLOCK;
		}
		byte[] encryptedData = out.toByteArray();
		out.close();
		return TfbBase64.encode(encryptedData);
	}

	/**
	 * <p>
	 * 私钥加密
	 * </p>
	 * 
	 * @param data
	 *            源数据
	 * @param privateKey
	 *            私钥(BASE64编码)
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptByPrivateKey(byte[] data, String privateKey) throws Exception {
		byte[] keyBytes = TfbBase64.decode(privateKey);
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
		cipher.init(Cipher.ENCRYPT_MODE, privateK);
		int inputLen = data.length;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] cache;
		int i = 0;
		// 对数据分段加密
		while (inputLen - offSet > 0) {
			if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
				cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
			} else {
				cache = cipher.doFinal(data, offSet, inputLen - offSet);
			}
			out.write(cache, 0, cache.length);
			i++;
			offSet = i * MAX_ENCRYPT_BLOCK;
		}
		byte[] encryptedData = out.toByteArray();
		out.close();
		return encryptedData;
	}

	/**
	 * <p>
	 * 从文件中加载私钥
	 * </p>
	 * 
	 * @param keyFileName
	 *            公钥文件名
	 * @return
	 */
	public static String loadPublicKey(String publicKey) {
		try {
			// br = new BufferedReader(new FileReader(fileName));
			// String readLine = null;
			// StringBuilder sb = new StringBuilder();
			// while ((readLine = br.readLine()) != null) {
			// if (readLine.charAt(0) == '-') {
			// continue;
			// } else {
			// sb.append(readLine);
			// sb.append('\r');
			// }
			// }
			String[] publicStr = publicKey.split("\n");
			StringBuffer sb = new StringBuffer();
			for (String string : publicStr) {
				if (string.charAt(0) == '-') {
					continue;
				} else {
					sb.append(string);
					sb.append('\r');
				}
			}
			byte[] buffer = TfbBase64.decode(sb.toString());
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
			RSAPublicKey rsaPublicKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
			String publickey = TfbBase64.encode(rsaPublicKey.getEncoded());
			return publickey;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 从文件中加载私钥
	 * 
	 * @param keyFileName
	 *            私钥文件名
	 * @return 是否成功
	 */
	public static String loadPrivateKey(String privateKey) {
		try {
			// br = new BufferedReader(new FileReader(filename));
			// String readLine = null;
			// StringBuilder sb = new StringBuilder();
			// while ((readLine = br.readLine()) != null) {
			// if (readLine.charAt(0) == '-') {
			// continue;
			// } else {
			// sb.append(readLine);
			// sb.append('\r');
			// }
			// }
			String[] publicStr = privateKey.split("\n");
			StringBuffer sb = new StringBuffer();
			for (String string : publicStr) {
				if (string.charAt(0) == '-') {
					continue;
				} else {
					sb.append(string);
					sb.append('\r');
				}
			}
			byte[] buffer = TfbBase64.decode(sb.toString());
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(buffer);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			byte[] binaryData = ((RSAPrivateKey) keyFactory.generatePrivate(keySpec)).getEncoded();
			return TfbBase64.encode(binaryData);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) throws Exception {
		String str = RSAUtils.loadPublicKey("D:\\Java\\certs\\gczf_rsa_public.pem");
		System.out.println(str);
		String byteStr = "2d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d0a4d4"
				+ "947664d413047435371475349623344514542415155414134474e414443426951"
				+ "4b426751436a44726b6f56627976346a5478654b744b45694b326d5a69650a7a5"
				+ "176664a563373476869774f6e422b4279357361355361364c7334647435414756"
				+ "714b48787951564b5270752f757477744574324d696a57783435503179320a784"
				+ "765376f447a3268555850306a38735361314e503236546d5748774f37637a674a"
				+ "787872644a36524e71736b53666a77736135594d73716d6372756d7855490a786"
				+ "5436735454f6b67553236626e506f5a514944415141420a2d2d2d2d2d454e4420"
				+ "5055424c4943204b45592d2d2d2d2d0a";
		byte[] publicKey = ParamUtil.hex2Bytes(byteStr);
		String publicStr = new String(publicKey);
		String[] publicStrs = publicStr.split("\n");
		StringBuffer buffer = new StringBuffer();
		for (String string : publicStrs) {
			if (string.charAt(0) == '-') {
				continue;
			} else {
				buffer.append(string);
				// buffer.append('\r');
			}
		}
		// System.out.println(buffer);
	}
}