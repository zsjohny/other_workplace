package org.dream.finance.controller;

import javax.servlet.http.HttpServletRequest;

import org.dream.finance.dao.FinanceIODao;
import org.dream.finance.service.FinanceIOService;
import org.dream.finance.service.FinanceService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.finance.FinanceIOModel;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/finance")
public class FinanceDrawOperateController extends BaseController {
	private static final String REDIS_KEY = "admin:filter:";
	@Autowired
	private FinanceService financeService;
	@Autowired
	private FinanceIOService ioService;
	@Autowired
	private RedisTemplate<String, Integer> redisTemplate;
	@Autowired
	private FinanceIODao ioDao;

	@RequestMapping("/adjustCommission")
	@ResponseBody
	public Response adjustCommission(FinanceIOModel ioModel) {
		return ioService.adjustCommission(ioModel);
	}

	@RequestMapping("/updateIOStatusAdopt")
	@ResponseBody
	public Response updateIOStatusAdopt(Integer status, String ioIds, HttpServletRequest request) {
		status = 1;
		Assert.notNull(ioIds, "提现ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// status=1审核通过，=4审核拒绝
		String redisKey = null;
		String[] ioIdsArray = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + "update_io_status_adopt" + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			financeService.checkDraw(status, ioIds);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status_adopt" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");
	}

	@RequestMapping("/updateIOStatusRefuse")
	@ResponseBody
	public Response updateIOStatusCheck(Integer status, String ioIds, HttpServletRequest request) {
		status = 4;
		Assert.notNull(ioIds, "提现ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// status=1审核通过，=4审核拒绝
		String redisKey = null;
		String[] ioIdsArray = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + "update_io_status_refuse" + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			financeService.checkDraw(status, ioIds);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status_refuse" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");
	}

	@RequestMapping("/updateIOStatusRecover")
	@ResponseBody
	public Response updateIOStatusRecover(Integer status, String ioIds, HttpServletRequest request) {
		status = 1;
		Assert.notNull(ioIds, "提现ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// status=1审核通过，=4审核拒绝
		String redisKey = null;
		String[] ioIdsArray = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + "update_io_status_adopt" + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			financeService.newSelfOrderId(ioIds);
			financeService.checkDraw(status, ioIds);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status_adopt" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");
	}

	@RequestMapping(value = { "/updateIOStatusSuccess", "/updateIOStatusSuccess2" })
	@ResponseBody
	public Response updateIOStatusSuccess(Integer status, String ioIds, HttpServletRequest request) {
		status = 3;
		Assert.notNull(ioIds, "提现ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// status=1审核通过，=4审核拒绝
		String redisKey = null;
		String[] ioIdsArray = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + "update_io_status_success" + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			financeService.checkDraw(status, ioIds);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status_success" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");
	}

	@RequestMapping("/updateIOStatusFail")
	@ResponseBody
	public Response updateIOStatusFail(Integer status, String ioIds, HttpServletRequest request) {
		status = 5;
		Assert.notNull(ioIds, "提现ID不能为空");
		ChannelModel channelModel = getCurrentChannel(request);
		Assert.notNull(channelModel);
		Integer channelId = channelModel.getId();
		// status=1审核通过，=4审核拒绝
		String redisKey = null;
		String[] ioIdsArray = null;
		ioIdsArray = ioIds.split(",");
		for (String id : ioIdsArray) {
			redisKey = REDIS_KEY + "update_io_status_fail" + id;
			RedisAtomicInteger integer = new RedisAtomicInteger(redisKey, redisTemplate);
			if (!integer.compareAndSet(0, 1)) {
				return null;
			}
		}
		try {
			financeService.checkDraw(status, ioIds);
		} finally {
			for (String id : ioIdsArray) {
				redisKey = REDIS_KEY + "update_io_status_fail" + id;
				redisTemplate.delete(redisKey);
			}
		}
		return Response.response(200, "操作成功");
	}
}
