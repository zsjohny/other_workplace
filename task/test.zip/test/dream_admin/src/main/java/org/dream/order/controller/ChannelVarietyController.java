package org.dream.order.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dream.admin.model.AdminUserModel;
import org.dream.channel.service.ChannelService;
import org.dream.model.channel.ChannelModel;
import org.dream.model.order.ChannelInvestorModel;
import org.dream.model.order.ChannelVarietyModel;
import org.dream.model.order.TradingVarietyModel;
import org.dream.order.service.ChannelVarietyService;
import org.dream.order.service.TradingVarietyService;
import org.dream.utils.controller.BaseController;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * 平台为一级渠道分配品种， 以及一级渠道为二级渠道分配品种。
 *
 * @author ZY
 */
@RequestMapping("/channelVariety")
@Controller
public class ChannelVarietyController extends BaseController {

	private Logger logger = LoggerFactory.getLogger(ChannelVarietyController.class);

	@Autowired
	private ChannelVarietyService channelVarietyService;

	@Autowired
	private TradingVarietyService tradingVarietyService;

	@Autowired
	private ChannelService channelService;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	/**
	 * 德丰要一个接口：根据当前用户的渠道id获取下面的品种
	 */
	@RequestMapping(value = "/getCurrentChannelVarieties")
	@ResponseBody
	public Response getCurrentChannelVarieties(HttpServletRequest request) {
		ChannelModel channelModel = getCurrentChannel(request);

		JSONArray array = new JSONArray();
		// 当渠道的id为0，即平台时，获取所有品种
		if (channelModel.getLevel() == 0) {
			List<TradingVarietyModel> tradingVarietyModels = tradingVarietyService.getEffectiveTradingVarieties();
			if (tradingVarietyModels != null && tradingVarietyModels.size() > 0) {
				for (TradingVarietyModel tvm : tradingVarietyModels) {
					// map.put("varietyId", tvm.getId().toString());
					JSONObject object = new JSONObject();
					object.put("varietyId", tvm.getId().toString());
					object.put("varietyName", tvm.getVarietyName());
					object.put("varietyType", tvm.getVarietyType());
					array.add(object);
				}
			}
			return Response.success(array);
		} else {
			List<ChannelVarietyModel> channelVarietyModels = channelVarietyService
					.findChannelVarietyModelAllByChannelId(channelModel.getId());
			if (channelVarietyModels != null && channelVarietyModels.size() > 0) {
				for (ChannelVarietyModel cvm : channelVarietyModels) {
					JSONObject object = new JSONObject();
					object.put("varietyId", cvm.getVarietyId());
					object.put("varietyName", cvm.getVarietyName());
					object.put("varietyType", cvm.getVarietyType());
					array.add(object);
				}
			}
			return Response.success(array);
		}

	}

	private List<Integer> handleIds(String Ids) {
		List<Integer> result = new ArrayList<Integer>();
		String[] temp_id = Ids.split(",");
		for (int i = 0; i < temp_id.length; i++) {
			result.add(Integer.valueOf(temp_id[i]));
		}
		return result;
	}

	/**
	 * 获取该登录用户的一级渠道id，并返回该一级渠道的子级渠道
	 */
	@RequestMapping(value = "/getSecondChannels", method = { RequestMethod.POST })
	@ResponseBody
	public Response saveVarietyAssets(HttpServletRequest request) {
		ChannelModel channelModel = getCurrentChannel(request);
		List<ChannelModel> channelModels = channelService.findSecondChannelsBySuperId(channelModel.getId());
		return Response.success(channelModels);

	}

	/**
	 * 平台为一级渠道分配品种，品种可多选,获取一级渠道下拉选：(/channel/findAllFirstChannels.do)
	 * <p>
	 * 一级渠道为二级渠道分配品种也可用该接口，获取二级渠道下拉选：(/channel/findSecondChannelsBySuperId.do)
	 *
	 * 
	 */
	@RequestMapping(value = "/addVarieties", method = { RequestMethod.POST })
	@ResponseBody
	public Response addFirstChannelVarieties(Integer channelId, String varietyIds, HttpServletRequest request) {
		Assert.notNull(channelId, "子渠道id不能为空");// 传送过来的渠道id是要分配的渠道id
		Assert.notNull(varietyIds, "品种id不能为空");
		if (varietyIds.equals("")) {
			return Response.response(600, "未选择任一品种");
		}
		List<Integer> vIdList = handleIds(varietyIds);
		/**
		 * 这里要区分是平台还是一级渠道。两个地方分配调用的是同一个接口。
		 */
		ChannelModel channelModel = super.getCurrentChannel(request);
		if (channelModel.getLevel() == 0) {// 表示这个是平台在分配给一级渠道品种
			ChannelVarietyModel firstChannelVarietyModel = new ChannelVarietyModel();
			firstChannelVarietyModel.setChannelId(channelId);
			firstChannelVarietyModel.setChannelLevel(channelModel.getLevel() + 1);
			firstChannelVarietyModel.setFees(0.0);
			firstChannelVarietyModel.setUserCosts(0.0);
			for (Integer vId : vIdList) {
				TradingVarietyModel tradingVarietyModel = tradingVarietyService.getById(vId);
				firstChannelVarietyModel.setVarietyId(vId);
				firstChannelVarietyModel.setStatus(1);// 默认为可售
				firstChannelVarietyModel.setVarietyName(tradingVarietyModel.getVarietyName());
				firstChannelVarietyModel.setVarietyType(tradingVarietyModel.getVarietyType());
				firstChannelVarietyModel.setSort(tradingVarietyModel.getVarietySort());
				firstChannelVarietyModel.setExchangeId(tradingVarietyModel.getExchangeId());
				firstChannelVarietyModel.setExchangeName(tradingVarietyModel.getExchangeName());
				// 插入数据
				channelVarietyService.insertChannelVariety(firstChannelVarietyModel);
			}

		} else {// 表示这个是一级渠道给二级渠道分配品种
			// 新建要分配的二级渠道品种
			ChannelVarietyModel secondChannelVarietyModel = new ChannelVarietyModel();
			secondChannelVarietyModel.setChannelId(channelId);
			secondChannelVarietyModel.setChannelLevel(channelModel.getLevel() + 1);
			secondChannelVarietyModel.setFees(0.0);
			secondChannelVarietyModel.setUserCosts(0.0);
			for (Integer vId : vIdList) {
				// 根据父级渠道id和品种id获取要分配给二级渠道的品种的基本信息
				ChannelVarietyModel cvm = channelVarietyService.getChannelVarietyById(null, channelModel.getId(), vId);
				secondChannelVarietyModel.setStatus(cvm.getStatus());
				secondChannelVarietyModel.setVarietyName(cvm.getVarietyName());
				secondChannelVarietyModel.setVarietyId(cvm.getVarietyId());
				secondChannelVarietyModel.setVarietyType(cvm.getVarietyType());
				secondChannelVarietyModel.setSort(cvm.getSort());
				secondChannelVarietyModel.setExchangeId(cvm.getExchangeId());
				secondChannelVarietyModel.setExchangeName(cvm.getExchangeName());
				// 插入数据
				channelVarietyService.insertChannelVariety(secondChannelVarietyModel);
			}

		}

		return Response.success();
	}

	/**
	 * 通过渠道id分页获取在售种类 (此接口为做改动，留给一级渠道：商品列表使用)
	 */
	@RequestMapping(value = { "/getChannelVarietyByChannelId" }, method = { RequestMethod.POST })
	@ResponseBody
	public Response querypagingChannelVarietyByChannelId(HttpServletRequest request, Integer channelId, Integer page,
			Integer pageSize) {
		Page<ChannelVarietyModel> data = null;
		try {
			// Assert.notNull(channelId, "渠道id不能为空");
			if (channelId == null) {
				ChannelModel channelModel = getCurrentChannel(request);
				channelId = channelModel.getId();
			}
			pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
			page = page == null ? 0 : page;

			data = channelVarietyService.qureypagingForFirstChannel(channelId, page, pageSize);
		} catch (Exception e) {
			logger.error("出错：e={}", e);
		}

		return Response.success(data);
	}

	/**
	 * 通过渠道id分页获取在售种类,这里多了一个佣金汇率等字段 这里涉及到一级渠道分配品种，和二级渠道商品列表，故做了一个区分
	 */
	@RequestMapping(value = { "/querypagingByChannelId" }, method = { RequestMethod.POST })
	@ResponseBody
	public Response getChannelVarietyByChannelId(HttpServletRequest request, Integer channelId, Integer page,
			Integer pageSize) {
		pageSize = pageSize == null ? Page.DEFAULE_PAGESIZE : pageSize;
		page = page == null ? 0 : page;
		/**
		 * 如果channelId为空，则表示是《 二级渠道》 管理员登录的，获取商品列表的接口
		 * 
		 */
		if (channelId == null) {
			ChannelModel channelModel = getCurrentChannel(request);
			channelId = channelModel.getId();
		}

		Page<ChannelVarietyModel> data = channelVarietyService.qureypagingSecondChannel(channelId, page, pageSize);
		return Response.success(data);
	}

	/**
	 * 通过渠道id获取在售种类
	 */
	@RequestMapping(value = "/findAll", method = { RequestMethod.POST })
	@ResponseBody
	public Response findChannelVarietyAll(HttpServletRequest request) {
		// 获取当前用户所有所属渠道信息
		AdminUserModel userModel = (AdminUserModel) request.getSession().getAttribute("user");

		if (userModel == null) {
			// 当前没有用户登录
			return Response.response(500, "当前没用权限");

		}

		List<ChannelVarietyModel> channelVarietyModels = channelVarietyService
				.findChannelVarietyModelAllByChannelId(userModel.getDataId());

		return Response.success(channelVarietyModels);
	}

	/**
	 * 获取当前渠道所没有的品种list
	 */
	@RequestMapping(value = "/findChannelNotHave", method = { RequestMethod.POST })
	@ResponseBody
	public Response findChannelNotHave(Integer channelId) {
		Assert.notNull(channelId, "渠道id不能为空");
		// 先获取该渠道下的所有品种
		List<ChannelVarietyModel> allChVarieties = channelVarietyService
				.findChannelVarietyModelAllByChannelId(channelId);
		// 再获取平台上面可供分配的品种
		List<TradingVarietyModel> allVarieties = tradingVarietyService.getEffectiveTradingVarieties();
		// 返回的品种，进行筛选
		Iterator<TradingVarietyModel> iterator = allVarieties.iterator();
		while (iterator.hasNext()) {
			TradingVarietyModel tvModel = iterator.next();
			Integer tvId = tvModel.getId();
			if (allChVarieties != null && allChVarieties.size() > 0) {
				// 嵌套循环渠道品种，去掉重复的品种
				for (ChannelVarietyModel cvModel : allChVarieties) {
					Integer cvId = cvModel.getVarietyId();
					if (cvId == tvId) {
						iterator.remove();
						break;
					}
				}
			}
		}
		return Response.success(allVarieties);
	}

	/**
	 * 获取当前二级渠道相对于一级渠道所没有的品种list-- channelId表示二级渠道的ID
	 */
	@RequestMapping(value = "/findSecondChannelNotHave", method = { RequestMethod.POST })
	@ResponseBody
	public Response findSecondChannelNotHave(HttpServletRequest request, Integer channelId) {
		Assert.notNull(channelId, "渠道id不能为空");
		// 先获取该二级渠道下的所有品种
		List<ChannelVarietyModel> allChVarieties = channelVarietyService
				.findChannelVarietyModelAllByChannelId(channelId);
		// 再获取一级渠道上面可供分配的品种
		// List<TradingVarietyModel> allVarieties =
		// tradingVarietyService.getEffectiveTradingVarieties();
		ChannelModel channelModel = getCurrentChannel(request);
		List<ChannelVarietyModel> allVarieties = channelVarietyService
				.findChannelVarietyModelAllByChannelId(channelModel.getId());
		// 返回的品种，进行筛选
		Iterator<ChannelVarietyModel> iterator = allVarieties.iterator();
		while (iterator.hasNext()) {
			ChannelVarietyModel tvModel = iterator.next();
			Integer tvId = tvModel.getVarietyId();
			if (allChVarieties != null && allChVarieties.size() > 0) {
				// 嵌套循环渠道品种，去掉重复的品种
				for (ChannelVarietyModel cvModel : allChVarieties) {
					Integer cvId = cvModel.getVarietyId();
					if (cvId == tvId) {
						iterator.remove();
						break;
					}
				}
			}
		}
		return Response.success(allVarieties);
	}

	/**
	 * 批量修改一级渠道下品种的佣金
	 * <p>
	 * 此处传过来的jsonArrayData格式为[{"id":"1","com":"2.0"},{"id":"3","com": "4.0"}]
	 *
	 * @param
	 */
	// @RequestMapping(value = "/updateVarietiesComs", method = {
	// RequestMethod.POST })
	// @ResponseBody
	// public Response updateVarietiesComs(String jsonArrayData) {
	// Assert.notNull(jsonArrayData, "渠道id和价格不能为空");
	// JSONArray jsonArray = JSONArray.parseArray(jsonArrayData);
	// for (int i = 0; i < jsonArray.size(); i++) {
	// Map<String, Object> obj = (Map<String, Object>) jsonArray.get(i);
	// ChannelVarietyModel channelVarietyModel = new ChannelVarietyModel();
	// Integer id = new Integer(obj.get("id").toString());
	// Double com = new Double(obj.get("com").toString());
	// // 根据id批量更新佣金
	// channelVarietyModel.setId(id);
	// channelVarietyModel.setCom(com);
	// Integer channelId = (Integer) obj.get("channelId");
	// Integer varietyId = (Integer) obj.get("varietyId");
	// channelVarietyService.updateChannelVarietyCom(channelVarietyModel,
	// channelId, varietyId);
	// }
	// return Response.success();
	// }

	/**
	 * 批量修改二级渠道下品种的费率
	 * <p>
	 * 此处传过来的jsonArrayData格式为[{"id":"1","fees":"2.0"},{"id":"3","fees": "4.0"}]
	 *
	 * @param
	 */
	@RequestMapping(value = "/updateVarietiesFees", method = { RequestMethod.POST })
	@ResponseBody
	public Response updateVarietiesFees(String jsonArrayData) {
		Assert.notNull(jsonArrayData, "渠道id和费率不能为空");
		JSONArray jsonArray = JSONArray.parseArray(jsonArrayData);
		for (int i = 0; i < jsonArray.size(); i++) {
			Map<String, Object> obj = (Map<String, Object>) jsonArray.get(i);
			ChannelVarietyModel channelVarietyModel = new ChannelVarietyModel();
			Integer id = new Integer(obj.get("id").toString());
			Double fees = new Double(obj.get("fees").toString());
			// 根据id批量更新费率
			channelVarietyModel.setId(id);
			channelVarietyModel.setFees(fees);
			Integer channelId = (Integer) obj.get("channelId");
			Integer varietyId = (Integer) obj.get("varietyId");
			channelVarietyService.updateChannelVarietyFees(channelVarietyModel, channelId, varietyId);
		}
		return Response.success();
	}

	/**
	 * 
	 * 此处可修改 二级渠道下品种的 佣金，标签，广告等
	 */
	@RequestMapping(value = "/updateSecondChannelVariety")
	@ResponseBody
	public Response updateSecondChannelVariety(ChannelVarietyModel channelVarietyModel) {
		Assert.notNull(channelVarietyModel.getUserCosts(), "用户佣金不能为空");
		ChannelVarietyModel cvm = channelVarietyService.getChannelVarietyById(channelVarietyModel.getId(), null, null);
		if (cvm.getFees() == null) {
			return Response.response(800, "请先联系一级渠道设定佣金");
		}
		// if (cvm.getFees() > channelVarietyModel.getUserCosts()) {
		// return Response.response(600, "一级渠道佣金不能大于用户佣金，请重新设置");
		// }
		channelVarietyService.updateSecondChannelVariety(channelVarietyModel);
		return Response.success();
	}

	/**
	 * 
	 * 一级渠道上对商品修改 账户,传入：(channelId,varietyId,id,investorAccount)
	 */
	@RequestMapping(value = "/updateFirstInvestorAccount")
	@ResponseBody
	public Response updateFirstInvestorAccount(ChannelVarietyModel channelVarietyModel) {

		Integer channelId = channelVarietyModel.getChannelId();
		Integer varietyId = channelVarietyModel.getVarietyId();
		String investorAccount = channelVarietyModel.getInvestorAccount();
		Assert.notNull(channelVarietyModel.getId(), "渠道品种id不能为空");
		Assert.notNull(channelId, "渠道id不能为空");
		Assert.notNull(varietyId, "品种id不能为空");
		Assert.notNull(investorAccount, "账户不能为空");
		channelVarietyService.updateFirstInvestorAccount(channelVarietyModel);
		channelVarietyService.updateRedisFirstInvestorAccount(channelId, varietyId, investorAccount);
//		// 放入缓存
//		if (redisTemplate.opsForHash().get(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT,
//				channelId + "_" + varietyId) != null) {
//			redisTemplate.opsForHash().delete(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT,
//					channelId + "_" + varietyId);
//		}
//		redisTemplate.opsForHash().put(ChannelInvestorModel.CHANNEL_INVESTOR_ACCOUNT, channelId + "_" + varietyId,
//				investorAccount);
		return Response.success();
	}

	/**
	 * ********************* 平台上面涉及的关闭某渠道品种的操作 ******************** 包含：
	 * 1.一级渠道关闭某二级渠道的可售品种 2.一级渠道关闭自己的可售品种，同时二级渠道下的该品种也关闭
	 * 3.平台关闭某一级渠道的可售品种，同时会关闭一级渠道下所有该品种的可售状态
	 * 4.平台关闭自身的的可售品种，同时整个一级渠道和二级渠道所有该品种均关闭(TradingVarietyController中实现)
	 */

	/**
	 * 一级渠道关闭二级渠道的品种 物理删除
	 *
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/firstDeleteSecondByIds", method = { RequestMethod.POST })
	@ResponseBody
	public Response firstDeleteSecondByIds(String ids) {
		channelVarietyService.deleteChannelVarietiesByIds(ids);
		return Response.success();
	}

	/**
	 * 平台关闭一级渠道的可售状态:(软删除)同时还涉及到打开：
	 *
	 * 平台关闭某一级渠道的可售品种，同时会关闭一级渠道下所有该品种的可售状态。同时还可以打开，但打开只能打开自己的。（渠道不为空）
	 * 一级渠道也可以关闭或打开自己的可售品种。(渠道为空)
	 */
	@RequestMapping(value = "/closeFirstVariety")
	@ResponseBody
	public Response closeFirstVariety(HttpServletRequest request, Integer id, Integer channelId, Integer status) {
		Assert.notNull(channelId, "渠道id不能为空");
		Assert.notNull(id, "渠道品种id不能为空");
		Assert.notNull(status, "status不能为空");
		// 如果此处是关闭，则关闭该渠道下的品种，和子渠道下的品种
		if (status == 0) {
			// 先通过渠道Id获取该一级渠道的子渠道，对相同的品种进行操作，关闭
			ChannelVarietyModel channelVarietyModel = channelVarietyService.getChannelVarietyById(id, null, null);
			List<ChannelModel> list = channelService.findSecondChannelsBySuperId(channelId);
			// 遍历所有二级渠道
			if (list != null && list.size() > 0) {
				for (ChannelModel channelmodel : list) {
					// 获取渠道的id
					Integer id2 = channelmodel.getId();
					// 根据渠道id获取所有在售品种
					List<ChannelVarietyModel> list2 = channelVarietyService.getChannelVarietyByChannelId(id2);
					// 匹配与要关闭的品种相同的品种
					for (ChannelVarietyModel model2 : list2) {
						// 如果品种相同，则关闭
						if (model2.getVarietyId().equals(channelVarietyModel.getVarietyId())
								&& model2.getStatus().equals(1)) {
							channelVarietyService.changeChannelVarietyStatusByIds(model2.getId().toString(), 0);
						}
					}
				}
			}
			// 再关闭自己的品种
			channelVarietyService.changeChannelVarietyStatusByIds(id.toString(), 0);
		} else if (status == 1) {// 如果是打开，则打开自己的该品种
			channelVarietyService.openVarietyById(id);
		}
		return Response.success();
	}

	/**
	 * 删除一级渠道的某些品种（同时也会删除该一级渠道 下的二级渠道 的该品种）
	 *
	 * @param ids
	 * @param channelId
	 * @return
	 */
	@RequestMapping(value = "/deleteFirstVariety", method = { RequestMethod.POST })
	@ResponseBody
	public Response deleteFirstVariety(String ids, Integer channelId) {
		Assert.notNull(channelId, "渠道id不能为空");
		Assert.notNull(ids, "渠道品种id不能为空");
		List<Integer> chVrtIds = handleIds(ids);
		// 循环遍历要删除的渠道品种id
		for (Integer id : chVrtIds) {
			// 删除redis里面费用信息
			// redisTemplate.opsForHash().delete(ChannelVarietyModel.PLATFORM_COM,
			// channelId+"_"+id);
			// 先通过渠道Id获取该一级渠道的子渠道，对相同的品种进行操作，关闭
			List<ChannelModel> list = channelService.findSecondChannelsBySuperId(channelId);
			ChannelVarietyModel channelVarietyModel = channelVarietyService.getChannelVarietyById(id, null, null);
			// 遍历所有二级渠道
			if (list != null && list.size() > 0) {
				for (ChannelModel channelmodel : list) {
					// 获取渠道的id
					Integer id2 = channelmodel.getId();

					// 根据渠道id获取所有在售品种
					List<ChannelVarietyModel> list2 = channelVarietyService.getChannelVarietyByChannelId(id2);
					channelVarietyService.deleteRedisChannelFees(id, id2);
					// 删除二级渠道的费用
//					redisTemplate.opsForHash().delete(ChannelVarietyModel.oneChannel_Fees, id2 + "_" + id);
					// 删除二级渠道的对用户的费用
//					redisTemplate.opsForHash().delete(ChannelVarietyModel.twoChannel_user_costs, id2 + "_" + id);
					// 匹配与要关闭的品种相同的品种
					if (list2 != null && list2.size() > 0) {
						for (ChannelVarietyModel model2 : list2) {
							// 如果品种相同，则关闭
							if (model2.getVarietyId().equals(channelVarietyModel.getVarietyId())) {
								// channelVarietyService.deleteVarietyByVarietyId(model2.getId());
								channelVarietyService.deleteChannelVarietiesByIds(model2.getId().toString());
							}
						}
					}
				}
			}
		}
		channelVarietyService.deleteChannelVarietiesByIds(ids);

		return Response.success();
	}

	/**
	 * 二级渠道接口：修改二级渠道下品种的可售状态(挨个操作，不进行批量操作)
	 * 
	 * @param ids
	 *            渠道品种
	 * @return
	 */
	@RequestMapping(value = "/changeSecondCVStatus")
	@ResponseBody
	public Response changeSecondCVStatus(HttpServletRequest request, Integer id, Integer channelId, Integer status,
			Integer varietyId) {
		Assert.notNull(id, "渠道品种id不能为空");
		Assert.notNull(status, "状态不能为空");
		Assert.notNull(varietyId, "品种id不能为空");
		Assert.notNull(channelId, "渠道id不能为空");
		if (status == 0) {
			channelVarietyService.changeChannelVarietyStatusByIds(id.toString(), 0);
			return Response.success();
		} else if (status == 1) {
			// 打开的时候要先做一个判定，父级渠道的该品种是否处于可售状态。先获取当前登录用户的渠道id，再获取父渠道
			ChannelModel channelModel = channelService.getById(channelId);
			ChannelVarietyModel channelVarietyModel = channelVarietyService.getChannelVarietyById(null,
					channelModel.getSuperId(), varietyId);
			if (channelVarietyModel.getStatus() == 0) {// 表示父级的该品种都没有打开
				return Response.response(600, "该品种处于关闭状态，无法打开");
			}
			channelVarietyService.changeChannelVarietyStatusByIds(id.toString(), 1);
			return Response.success();
		}
		return Response.error();
	}

	public static void main(String[] args) {

	}
}
