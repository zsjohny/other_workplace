package org.dream.push.service.impl;

import org.apache.commons.lang.StringUtils;
import org.dream.model.push.PushModel;
import org.dream.model.user.UserModel;
import org.dream.push.dao.PushDao;
import org.dream.push.dao.UserFindDao;
import org.dream.push.service.PushService;
import org.dream.utils.push.PushUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


/**
 * 推送实体类的操作
 * Created by nessary on 16-9-27.
 */
@Service
public class PushServiceImpl implements PushService {

    @Autowired
    private PushDao pushDao;

    @Autowired
    private UserFindDao userDao;


    private Logger logger = LoggerFactory.getLogger(PushServiceImpl.class);

    @Override

    public void savePushModel(PushModel pushModel) {
        try {

            pushDao.savePushModel(pushModel);
        } catch (Exception e) {
            logger.warn("保存推送实体类出错", e);
        }


    }

    @Override
    public void updatePushModel(PushModel pushModel) {
        try {


            if (pushModel.getIdsStr() != null) {

                String[] arr = pushModel.getIdsStr().split(",");
                List<Integer> ids = new ArrayList<>();

                for (String str : arr) {

                    ids.add(Integer.valueOf(str));
                }

                pushModel.setIds(ids);

            }

            pushDao.updatePushModel(pushModel);
        } catch (Exception e) {
            logger.warn("更新推送实体类出错", e);
        }

    }

    @Override
    public List<PushModel> findAllPushModel(PushModel pushModel) {
        List<PushModel> pushModels = new ArrayList<>();
        try {
            pushModels = pushDao.findAllPushModel(pushModel);
            if (pushModels == null || pushModels.isEmpty()) {
                pushModels = new ArrayList<>();
                pushModels.add(new PushModel());
            }
            pushModels.get(0).setTotalCount(pushDao.findCountPushModel(pushModel));


        } catch (Exception e) {
            logger.warn("查找推送实体类出错", e);
        }


        return pushModels;
    }

    @Override
    public PushModel findPushModelById(PushModel pushModel) {
        try {

            if (pushModel == null) {
                return pushModel;
            }

            return pushDao.findPushModelById(pushModel);

        } catch (Exception e) {
            logger.warn("查找推送{}实体类出错", pushModel, e);
        }
        return pushModel;
    }

    @Override
    public void executePush(PushModel pushModel) {
        try {

            if (pushModel == null) {
                return;
            }


            //获取详细信息
            PushModel result = pushDao.findPushModelById(pushModel);

            if (result == null) {
                logger.warn("查不到此任务,push={}", pushModel);
                return;
            }

            //判断是否审核通过
            if (result.getPushStatus() != PushModel.HAVE_PASS) {
                logger.warn("此任务未审核,push={}", pushModel);

                return;
            }


            logger.info("执行推送开始，渠道Id{},推送pushModel{}", result.getChannelId(), result);


            //状态改成代发送
            pushModel.setPushStatus(PushModel.HAVE_PUSH);

            pushDao.updatePushModel(pushModel);


            List<UserModel> users = userDao.findUserAllByChannelId(pushModel.getChannelId());


            for (UserModel user : users) {

                if (user == null || StringUtils.isEmpty(user.getDeviceId()) || user.getPlatform() == null) {
                    continue;
                }

                result.setDeviceId(user.getDeviceId());
                result.setDeviceType(user.getPlatform());
                PushUtils.sendPush(result);


            }

            logger.info("执行推送结束，渠道Id{},推送{}", result.getChannelId(), result.getPushContent());

        } catch (Exception e) {
            logger.warn("执行推送{}实体类出错", pushModel, e);
        }

    }


}
