package org.dream.sms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.dream.model.sms.SmsTemplate;

public interface SmsTemplateDao {

	public void createTemplate(SmsTemplate smsTemplate);

	public void updateTemplate(SmsTemplate smsTemplate);

	public List<SmsTemplate> getAll(@Param(value = "isDelete") Integer isDelete,
			@Param(value = "channelId") Integer channelId);

	public SmsTemplate getById(@Param(value = "id") Integer id, Integer isDelete);

	public SmsTemplate getTemplate(@Param(value = "id") Integer id);

	public List<SmsTemplate> pagingQuery(@Param(value = "name") String name, @Param(value = "template") String template,
			@Param(value = "isDelete") Integer isDelete, @Param(value = "channelId") Integer channelId,
			@Param(value = "limit") Integer limit, @Param(value = "size") Integer size);

	public Integer pagingQuery_count(@Param(value = "name") String name, @Param(value = "template") String template,
			@Param(value = "isDelete") Integer isDelete, @Param(value = "channelId") Integer channelId);

	public void remove(Integer id);

	public SmsTemplate findTemplate(@Param(value = "name") String name, @Param(value = "template") String template,
			@Param(value = "channelId") Integer channelId);

}
