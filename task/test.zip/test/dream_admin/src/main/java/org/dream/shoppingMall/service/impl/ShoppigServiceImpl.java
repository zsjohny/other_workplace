package org.dream.shoppingMall.service.impl;

import java.util.List;

import org.dream.model.news.NewsModel;
import org.dream.model.shoppingMall.ShoppingModel;
import org.dream.shoppingMall.dao.ShoppingDao;
import org.dream.shoppingMall.service.ShoppingService;
import org.dream.utils.constants.ResponseCode;
import org.dream.utils.mvc.Page;
import org.dream.utils.mvc.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShoppigServiceImpl implements ShoppingService {
	@Autowired
	private ShoppingDao shoppingDao;

	@Override
	public Response findShoppingByPage(ShoppingModel shoppingModel, Integer page, Integer pageSize) {
		Integer offset = page > 0 ? page * pageSize : 0;
		List<ShoppingModel> list = shoppingDao.findByPage(shoppingModel, offset, pageSize);
		Integer rows = shoppingDao.findRows(shoppingModel);
		Page<ShoppingModel> shoppingPage = new Page<>(page, pageSize, rows);
		shoppingPage.setData(list);
		return Response.response(ResponseCode.SUCCESS_CODE, "查询兑换列表成功", shoppingPage);
	}

}
