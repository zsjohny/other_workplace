package org.dream.finance.service;

import java.util.List;

import org.dream.model.finance.FinanceTransferModel;
import org.dream.utils.constants.FinancePayType;
import org.dream.utils.constants.FinanceTransferType;

public interface BasicTransferService {
	public List<FinanceTransferModel> saveTransfer(List<Integer> idList, FinanceTransferType transferType,
			FinancePayType payType, String operator);

}
