package org.dream.dreamlock.server.concurrency;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.dream.utils.distributelock.codec.Monitor;

import com.alibaba.fastjson.JSON;

public class MonitorHub {
	private static int WORKER_NUM = 16;
	private static Map<Integer, Executor> executors = new HashMap<>();
	static {
		for (int i = 0; i <= WORKER_NUM; i++) {
			Executor exe= Executors.newSingleThreadExecutor();
			exe.execute(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					
				}
			});
			executors.put(i,exe);
		}
		JSON.toJSON("");
	}
	public static void init(){};
	public static void dispatch(Monitor m) {
		int hash = m.monitor.hashCode() % WORKER_NUM;
		hash=Math.abs(hash);
		System.out.println(m+"  "+System.currentTimeMillis());
		executors.get(hash).execute(new MonitorDispatcher(m));
	}

	public static class MonitorDispatcher implements Runnable {
		Monitor mon;
		private static Map<String, Queue<Monitor>> monitors = new HashMap<>();

		public  MonitorDispatcher(Monitor m) {
			mon = m;
		}

		@Override
		public void run() {
			Queue<Monitor> queue = monitors.get(mon.monitor);
			if (mon.cmdId == Monitor.CMD_REQ_LOCK) {
				if (queue == null) {
					queue = new LinkedList<>();
					monitors.put(mon.monitor, queue);
				}
				queue.offer(mon);
				ChannelHub.notifyUnlock(mon.equals(queue.peek()) ? Monitor.CMD_RESP_UNLOCK : Monitor.CMD_RESP_LOCK, mon);
			} else if (mon.cmdId == Monitor.CMD_REQ_UNLOCK) {
				if (queue == null || !mon.equals(queue.peek())) {
					return;
				}
				queue.poll();
				if (queue.peek() != null) {
					ChannelHub.notifyUnlock(Monitor.CMD_RESP_UNLOCK, queue.peek());
				}
			}

		}

	}

}
