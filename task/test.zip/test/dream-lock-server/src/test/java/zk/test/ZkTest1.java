package zk.test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.curator.CuratorZookeeperClient;
import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.data.Stat;

/**
 * @author Boyce 2016年6月21日 下午7:14:56
 */
public class ZkTest1 {
	public static void main(String[] args) throws Exception {
//		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
//	    final	CuratorFramework client = CuratorFrameworkFactory.newClient("192.168.0.88:2181",5000,5000, retryPolicy);
//		client.start();
//		client.getChildren().usingWatcher(arg0).forPath("/sys_conf").
		reloadConf(null);
		while(true){}
	}
	
	private static void reloadConf(String path) {
	
		try {
			String zk_cfg_root="/sys_conf";
			RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		    final	CuratorFramework client = CuratorFrameworkFactory.newClient("192.168.0.88:2181",5000,5000, retryPolicy);
			client.start();
		
			if (path == null) {//遍历所有子节点来绑定属性
				List<String> confs = client.getChildren().usingWatcher(notify).forPath(zk_cfg_root);
				for (Iterator iterator = confs.iterator(); iterator.hasNext();) {
					String conf = (String) iterator.next();
					String data = new String(client.getData().usingWatcher(notify).forPath(zk_cfg_root+"/"+conf));
					System.out.println("11:"+conf+":"+data);
				}
			} else {//访问变化的子节点来改变属性
				String data =  new String(client.getData().usingWatcher(notify).forPath(path));
				System.out.println("22:"+path+":"+data);
			}
		} catch (Exception e) {
		}

	}
	private static void deleteConf(String path){
		System.out.println(path);
	}
	private static Watcher notify = new Watcher() {

		@Override
		public void process(WatchedEvent event) {
			if (event.getType() == EventType.NodeChildrenChanged) {
				reloadConf(null);
			} else if (event.getType() == EventType.NodeDataChanged) {
				reloadConf(event.getPath());
			}else if(event.getType()==EventType.NodeDeleted){
				deleteConf(event.getPath());
			}
		}
	};
}
