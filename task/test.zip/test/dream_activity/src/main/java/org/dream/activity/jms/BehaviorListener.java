package org.dream.activity.jms;

import org.dream.utils.jms.Listener;

/**
 * @author Boyce
 * 2016年7月7日 下午2:11:27 
 */
public class BehaviorListener implements Listener{

	@Override
	public void onMessage(String message) {
		
	}

}
