package com.goldplusgold.td.expert.controller.index;

import com.goldplusgold.td.expert.common.enumeration.LinkUrlTypeEnum;
import com.goldplusgold.td.expert.config.H5Config;
import com.goldplusgold.td.expert.entity.Article;
import com.goldplusgold.td.expert.entity.Banner;
import com.goldplusgold.td.expert.exception.IndexException;
import com.goldplusgold.td.expert.parammodel.index.ArticleDetailPM;
import com.goldplusgold.td.expert.parammodel.index.ArticlePagingPM;
import com.goldplusgold.td.expert.service.ArticleService;
import com.goldplusgold.td.expert.service.BannerService;
import com.goldplusgold.td.expert.viewmodel.index.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "index")
public class IndexController {
    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);

    @Autowired
    private BannerService bannerService;

    @Autowired
    private ArticleService articleService;

    @Autowired
    private H5Config h5Config;

    @RequestMapping(value = "banners", method = RequestMethod.GET)
    public BannerListVM getBannerList() {
        BannerListVM vm = new BannerListVM();
        List<BannerVM> bannerVMS = new ArrayList<>();
        try {
            List<Banner> banners = bannerService.selectBanners();
            bannerVMS = banners.stream().map(banner -> {
                banner = objectConverter(banner);
                BannerVM vm1 = new BannerVM(banner);
                return vm1;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new IndexException(IndexException.Info.BANNERS_DATA_ERROR);
        }
        vm.setBannerList(bannerVMS);
        return vm;
    }

    @RequestMapping(value = "articles", method = RequestMethod.GET)
    public ArticleListVM getArticleList(ArticlePagingPM pm) {
        ArticleListVM vm = new ArticleListVM();
        try {
            List<Article> articles = articleService.selectArticles(pm.getNewsType(),
                    pm.getOffset(),
                    pm.getCount());
            List<ArticleVM> articleVMS = new ArrayList<>();
            articles.stream().map(article -> {
                ArticleVM articleVM = new ArticleVM(article);
                articleVM.setLinkUrl(h5Config.getAgreementBaseUrl() + "/banner/detail?bannerId=" + article.getId());
                articleVMS.add(articleVM);
                return articleVM;
            }).collect(Collectors.toList());

            vm.setArticleList(articleVMS);

        }catch (Exception e) {
            logger.error(e.getMessage());
            throw new IndexException(IndexException.Info.ARTICLES_DATA_ERROR);
        }
        return vm;
    }

//    @RequestMapping(value = "article_detail", method = RequestMethod.GET)
//    public ArticleDetailVM getArticleDetail(ArticleDetailPM pm) {
//        ArticleDetailVM vm;
//        try {
//            Article article = articleService.selectArticleById(pm.getArticleID());
//            vm = new ArticleDetailVM(article);
//        } catch (Exception e) {
//            logger.error(e.getMessage());
//            throw new IndexException(IndexException.Info.ARTICLE_DATA_ERROR);
//        }
//        return vm;
//    }

    private Banner objectConverter(Banner banner) {
        if (banner.getLinkUrlType() != null && banner.getLinkUrlType().intValue() == LinkUrlTypeEnum.IMAGE.toValue().intValue()) {
            String url = h5Config.getAgreementBaseUrl() + "/banner/detail?bannerId=" + banner.getId();
            banner.setLinkUrl(url);
        }
        return banner;
    }

}
