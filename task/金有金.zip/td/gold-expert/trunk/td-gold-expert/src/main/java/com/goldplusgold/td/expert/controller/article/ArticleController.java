package com.goldplusgold.td.expert.controller.article;

import com.goldplusgold.td.expert.common.enumeration.LinkUrlTypeEnum;
import com.goldplusgold.td.expert.entity.Article;
import com.goldplusgold.td.expert.entity.Banner;
import com.goldplusgold.td.expert.exception.IndexException;
import com.goldplusgold.td.expert.parammodel.index.ArticleDetailPM;
import com.goldplusgold.td.expert.service.ArticleService;
import com.goldplusgold.td.expert.service.BannerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "article")
public class ArticleController {
    private static final Logger logger = LoggerFactory.getLogger(ArticleController.class);

    @Autowired
    private ArticleService articleService;

    @RequestMapping(value = "detail", method = RequestMethod.GET)
    public String getArticleDetail(ArticleDetailPM pm, Model model) {

        Article article = articleService.selectArticleById(pm.getArticleID());

        if (article == null) {
            throw new IndexException(IndexException.Info.ARTICLE_DATA_ERROR);
        }

        model.addAttribute("title", article.getNewsTitle());
        model.addAttribute("content", article.getContent());

        return "article/detail";
    }
}
