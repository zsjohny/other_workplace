package com.goldplusgold.td.expert.viewmodel.index;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.goldplusgold.td.expert.entity.Banner;

import java.io.Serializable;

/**
 * banner信息VM
 */
@JsonPropertyOrder(alphabetic = true)
public class BannerVM implements Serializable {

    private static final long serialVersionUID = 1182089996208895941L;
    /**
     * 图片地址
     */
    private String imgUrl;

    /**
     * 图片链接地址
     */
    private String linkUrl;

    private Banner model;

    public BannerVM(Banner model) {
        this.model = model;
    }

    public String getLinkUrl() {
        return this.model.getLinkUrl();
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getImgUrl() {
        return this.model.getImgUrl();
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
