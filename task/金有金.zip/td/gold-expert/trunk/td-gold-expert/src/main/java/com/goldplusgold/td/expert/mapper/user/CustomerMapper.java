package com.goldplusgold.td.expert.mapper.user;

import com.goldplusgold.td.expert.entity.Customer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * banner mapper
 */
@Mapper
public interface CustomerMapper {

    Customer selectCustomer(@Param("userName")String userName);

}
