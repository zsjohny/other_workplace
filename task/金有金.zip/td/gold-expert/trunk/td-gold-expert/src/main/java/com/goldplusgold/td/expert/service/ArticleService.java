package com.goldplusgold.td.expert.service;


import com.goldplusgold.td.expert.entity.Article;
import com.goldplusgold.td.expert.mapper.index.IArticleMapper;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.validation.constraints.NotNull;
import java.util.List;

@Service
public class ArticleService {

    @Autowired
    private IArticleMapper mapper;

    public List<Article> selectArticles(@NotBlank String newsType, @NotNull Integer offset, @NotNull Integer count){
        return mapper.selectArticles(newsType, offset, count);
    }

    public Article selectArticleById(@NotNull String articleId){
        return mapper.selectArticleById(articleId);
    }
}
