/**
 * Created by Administrator on 2017/5/12.
 */
(function () {
    var Code=function () {
        this.itemContent=$(".item-content");
    };
    Code.prototype={
        init:function () {
            this.eventList();
        },
        switchTab:function (obj) {
            var  i=obj.index(),
                showVal=obj.find(".visible").val();
            if(showVal=='close'){
                obj.find(".card").show();
                obj.find(".td-iconArrow").removeClass("icon-down").addClass("icon-up");
                obj.find(".visible").val('show')
            }else{
                obj.find(".card").hide();
                obj.find(".td-iconArrow").removeClass("icon-up").addClass("icon-down");
                obj.find(".visible").val('close')
            }
        },
        eventList:function () {
            var _this=this;
            this.itemContent.click(function () {
                _this.switchTab($(this));
            });
        },
    };
    new Code().init();




})();