(function(){
    var commonJs = function() {

    };
    commonJs.prototype={
        getAjax:function (types, url, data,successfn, bool) {
            var _this=this;
            var  asyncBool = bool && true;
            if(typeof asyncBool == 'undefined') {
                asyncBool = true;
            } else {
                asyncBool = false;
            };
            var xhr=$.ajax({
                type: types, //请求方式
                url: url, //请求的url地址
                dataType: "json", //返回格式为json
                timeout: 10000,
                async: asyncBool, //请求是否异步，默认为异步，这也是ajax重要特性
                data: data,
                success: function(data){
                    $.hideIndicator();
                    successfn(data);
                },
                complete: function(XMLHttpRequest, status){
                    if(status == 'timeout') {
                        xhr.abort(); // 超时后中断请求
                        _this.requestTimeout(); //请求超时方法
                    }
                }
            });
        },
        getUrlKey:function(name){
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
            var result = window.location.search.substr(1).match(reg);
            return result ? decodeURIComponent(result[2]) : null;
        },
        requestTimeout:function () {
            $.hideIndicator();
            this.toast("请求超时,请稍后重试");
            console.log("请求超时");
        },
        toast:function (text) {
            $.toast(text);
        },
        alertPopup:function(describe, title, fn){
            $.alert(describe, title, fn);
        },
        confirmBox:function (describe, title, successfn, failfn) {
            var failfn=failfn||function () {
                    $.hideIndicator();
                };
            $.confirm(describe, title, successfn, failfn);
        },
        eventList:function () {//添加事件订阅
            var clientList={};
            function add(key,fn) {
                if(!key in clientList){
                    clientList[key]=[];
                };
                return clientList[key].push(fn);
            };
            function trigger() {
                var key=Array.prototype.shift.call(arguments),fns=clientList[key];
                if(!fns||fns.length === 0){
                    return false;
                }
                for(var i=0,fn;fn=fns[i++];){
                    fn.apply(this,arguments);
                }
            };
            function remove(key,fn) {
                var fns=clientList[key];
                if(!fns){
                    return false;
                }
                if(!fn){
                    clientList[key].length=0;
                }else {
                    for(var l=fns.length-1;l>=0;l--){
                        var _fns=fns[l];
                        if(_fns === fn){
                            fns.splice(l,1);
                        }
                    }
                }

            };
            return {
                add:add,
                trigger:trigger,
                remove:remove
            }
        },
        strategies:{//校验信息
            isNonEmpty:function (value,errorMsg) {//判断为空
                if(value === ''){
                    return errorMsg;
                }
            },
            minLength:function (value,length,errorMsg) {//最小长度
                if(value.length < length){
                    return errorMsg;
                }

            },
            isMobile:function (value,errorMsg) {
                if ( !/(^1[3|5|8][0-9]{9}$)/.test( value ) ){//正则手机
                    return errorMsg;
                }
            },
            isEqual:function (value,secondValue,errorMsg) {//判断两值是否相等
                if (value != $(secondValue).val()){
                    return errorMsg;
                }
            }
        },
        validator:function () {//添加校验信息方法
           var cache=[],cacheDom=[],
               _this=this;
           function add(dom,rules) {
                for(var i=0,rule;rule=rules[i++];){
                    (function (rule) {
                        var errorMsg=rule.errorMsg;
                        cacheDom.push(dom);
                        cache.push(function () {
                            var strategyAry=rule.strategy.split(':');
                            var strategy=strategyAry.shift();
                            strategyAry.unshift(dom.val());
                            strategyAry.push(errorMsg);
                            return _this.strategies[strategy].apply(dom,strategyAry);
                        });
                    }(rule));
                };
                return this;
           };
           function start() {
                for ( var i = 0, l=cache.length;i<l;i++ ){
                    var msg = cache[i]();
                    if ( msg ){
                        cacheDom[i].val('');
                        return msg;
                    }
                }
           };
           return {
                add:add,
                start:start
            }
        },
    };
    window.commonJs=new commonJs();
    return commonJs;
})();
(function () {
    var api ={
        loginOut:dataUrl+'/user/login',//退出登录 方式:post
        modifyPassword:dataUrl+'/user/password_set',//修改登录密码 方式:put
    };
    window.api=api;
    return api;
})();