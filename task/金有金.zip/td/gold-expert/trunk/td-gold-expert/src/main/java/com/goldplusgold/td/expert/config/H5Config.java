package com.goldplusgold.td.expert.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class H5Config {
    @Value("${h5Config.agreementBaseUrl}")
    private String agreementBaseUrl;

    public String getAgreementBaseUrl() {
        return agreementBaseUrl;
    }

    public void setAgreementBaseUrl(String agreementBaseUrl) {
        this.agreementBaseUrl = agreementBaseUrl;
    }
}
