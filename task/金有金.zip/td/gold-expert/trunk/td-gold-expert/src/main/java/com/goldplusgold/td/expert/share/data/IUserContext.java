package com.goldplusgold.td.expert.share.data;


import com.goldplusgold.td.expert.common.enumeration.PlatformEnum;

/**
 * 上下文所带的用户必要信息接口定义
 */
public interface IUserContext {

    String getUserID();

    void setUserID(String userID);

    String getUserName();

    void setUserName(String userName);

    PlatformEnum getPlatform();

    void setPlatform(PlatformEnum platform);

    String getImei();

    void setImei(String imei);

    String getClientID();

    void setClientID(String clientID);

    String getVersion();

    void setVersion(String version);

    void setLoginTime(String loginTime);

    String getLoginTime();

}
