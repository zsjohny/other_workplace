package com.goldplusgold.td.expert.parammodel.index;

import com.goldplusgold.td.expert.exception.PMValidateException;
import com.goldplusgold.td.expert.parammodel.PagingPM;
import org.apache.commons.lang3.StringUtils;

public class ArticlePagingPM extends PagingPM {

    private static final long serialVersionUID = -8428564369670258033L;
    
    /**
     * news类型
     * 0-新闻
     * 5-动态
     * 6-资讯
     */
    private String newsType;

    public String getNewsType() {
        return newsType;
    }

    public void setNewsType(String newsType) {
        this.newsType = newsType;
    }

    @Override
    public void validate() {
        super.validate();
        if (StringUtils.isBlank(newsType)) {
            throw new PMValidateException(PMValidateException.Info.PARAM_MODEL_VALIDATE_ERROR);
        }
    }
}
