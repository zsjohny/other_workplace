package com.goldplusgold.td.expert.share.data;

import com.goldplusgold.td.expert.common.enumeration.PlatformEnum;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * 用户上下文数据（包含金有金的用户数据，TD的用户）
 */
@Component("userContextData")
@Scope(value = "request")
public class UserContextData implements Serializable {

    /**
     * 用户ID
     */
    private String userID;

    /**
     * 登录帐号,就是手机号码
     */
    private String userName;

    /**
     * 平台
     */
    private PlatformEnum platform;

    /**
     * 识别码
     */
    private String imei;

    /**
     * 友盟ID
     */
    private String clientID;

    /**
     * app版本
     */
    private String version;

    /**
     * 登录的时间戳
     */
    private String loginTime;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public PlatformEnum getPlatform() {
        return platform;
    }

    public void setPlatform(PlatformEnum platform) {
        this.platform = platform;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }
}
