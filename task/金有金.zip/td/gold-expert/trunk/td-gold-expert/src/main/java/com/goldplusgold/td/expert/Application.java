package com.goldplusgold.td.expert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 行情应用程序的入口
 */
@SpringBootApplication(scanBasePackages = "com.goldplusgold.td.expert")
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
