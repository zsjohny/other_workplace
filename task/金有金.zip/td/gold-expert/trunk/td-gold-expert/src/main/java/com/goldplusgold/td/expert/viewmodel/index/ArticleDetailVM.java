package com.goldplusgold.td.expert.viewmodel.index;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.goldplusgold.td.expert.common.utils.DateUtil;
import com.goldplusgold.td.expert.common.utils.StringConverterUtil;
import com.goldplusgold.td.expert.entity.Article;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@JsonPropertyOrder(alphabetic = true)
public class ArticleDetailVM implements Serializable {
    
    private static final long serialVersionUID = -6409738312342343990L;
    
    private Article article;

    public ArticleDetailVM(Article article) {
        super();
        this.article = article;
    }
    
    public String getTitle() {
        return StringConverterUtil.unescapeHtml(this.article.getNewsTitle());
    }
    
    public String getIssuanceTime() {
        DateFormat df = new SimpleDateFormat(DateUtil.simpleShortM);
        return df.format(this.article.getDeliveryTime());
    }

    public String getNickname() {
        return this.article.getNewsFrom() == null ? "金专家" : this.article.getNewsFrom();
    }
    
    public String getContent() {
        return StringConverterUtil.unescapeHtml(this.article.getContent());
    }

    public String getImageUrl() {
        return this.article.getThumbnail();
    }

    public String getSummary() {
        return StringConverterUtil.unescapeHtml(this.article.getSummary());
    }

    public String getCategory() {
        return this.article.getCategory();
    }
    public String getPhotoUrl(){
        return this.article.getFromLogo();
    }

}
