package com.goldplusgold.td.expert.share.auth;

import com.goldplusgold.td.expert.common.constant.TokenInfo;
import com.goldplusgold.td.expert.common.enumeration.ExpirationTimeEnum;
import com.goldplusgold.td.expert.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.expert.exception.JwtTokenException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * 刷新JWT TOKEN
 */
public class RefreshJWTTokenUtil {

    private static final Logger logger = LoggerFactory.getLogger(RefreshJWTTokenUtil.class);


    /**
     * 刷新JWT TOKEN
     */
    public static void refreshJWTToken(HttpServletRequest request,
                                 HttpServletResponse response) {

        String userId = (String)request.getAttribute(LoginParamsEnum.USERID.toName());
        String userName = (String)request.getAttribute(LoginParamsEnum.USERNAME.toName());
        String platform = (String)request.getAttribute(LoginParamsEnum.PLATFORM.toName());
        String imei = (String)request.getAttribute(LoginParamsEnum.IMEI.toName());
        String clientId = (String)request.getAttribute(LoginParamsEnum.CLIENTID.toName());
        String loginTime = (String)request.getAttribute(LoginParamsEnum.LOGINTIME.toName());

        try {
            checkArgument(StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(userName) &&
                    StringUtils.isNotEmpty(platform));
        } catch (IllegalArgumentException e) {
            logger.error(JwtTokenException.Info.REFRESH_JWT_PARAM_MISS.toInfo(), e);
            throw new JwtTokenException(JwtTokenException.Info.REFRESH_JWT_PARAM_MISS, e);
        }

        String jwt_token = JwtUtils.createJWT(userId, userName, platform, imei, clientId, loginTime,
                ExpirationTimeEnum.MOBILE_EXPIR.toMillisecond());
        response.setHeader(TokenInfo.HTTP_RESPONSE_HEADER_TOKEN_NAME, jwt_token);

        //添加debug日志用做调试
        if (logger.isDebugEnabled()) {
            logger.debug("~~~~~~~~~~~~~~~~~~~~ refreshJWTToken() REFRESH JWT TOKEN ~~~~~~~~~~~~~~~~~~~~");
            logger.debug("userId: {}", userId);
            logger.debug("userName: {}", userName);
            logger.debug("platform: {}", platform);
            logger.debug("imei: {}", imei);
            logger.debug("clientId: {}", clientId);
            logger.debug("loginTime: {}", loginTime);
            logger.debug("JWT TOKEN: {}", jwt_token);
            logger.debug("==================== refreshJWTToken() REFRESH JWT TOKEN =====================");
        }

    }

}
