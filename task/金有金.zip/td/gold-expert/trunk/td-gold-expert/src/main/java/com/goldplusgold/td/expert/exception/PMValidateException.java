package com.goldplusgold.td.expert.exception;

import javax.validation.constraints.NotNull;

/**
 * ParamModel数据校验异常
 */
public class PMValidateException extends AbstractException {

    private static final long serialVersionUID = 4905457476199964576L;

    public PMValidateException(@NotNull PMValidateException.Info info) {

        super(info.toCode(), info.toInfo(), null, info.toInfo());
    }

    public PMValidateException(@NotNull PMValidateException.Info info,
                               Exception e) {

        super(info.toCode(), info.toInfo(), e, info.toInfo());
    }

    public enum Info {

        PARAM_MODEL_VALIDATE_ERROR("PVE01", "参数不合法");

        /**
         * 异常编码
         */
        private String code;
        /**
         * 异常信息
         */
        private String info;

        Info(@NotNull String code,
             @NotNull String info) {

            this.code = code;
            this.info = info;
        }

        public String toCode() {
            return this.code;
        }

        public String toInfo() {
            return this.info;
        }
    }
}
