package com.goldplusgold.td.expert.parammodel.index;

import com.goldplusgold.td.expert.exception.PMValidateException;
import com.goldplusgold.td.expert.parammodel.IPMValidator;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

public class ArticleDetailPM implements Serializable, IPMValidator {

    private static final long serialVersionUID = 4735636877447848871L;
    private String articleID;

    public String getArticleID() {
        return articleID;
    }

    public void setArticleID(String articleID) {
        this.articleID = articleID;
    }

    @Override
    public void validate() {
        if (StringUtils.isBlank(articleID)) {
            throw new PMValidateException(PMValidateException.Info.PARAM_MODEL_VALIDATE_ERROR);
        }
    }
}

