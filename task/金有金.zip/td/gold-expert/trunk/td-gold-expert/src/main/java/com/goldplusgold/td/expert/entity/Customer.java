package com.goldplusgold.td.expert.entity;

import com.goldplusgold.td.expert.viewmodel.BaseModel;

/**
 * banner信息
 */
public class Customer extends BaseModel {

    private static final long serialVersionUID = 1053982774147227896L;
    /**
     *
     */
    private String userName;
    /**
     *
     */
    private String nickName;
    /**
     *
     */
    private String headImage;
    /**
     *
     */
    private String clientId;
    /**
     *
     */
    private Integer delFlag;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHeadImage() {
        return headImage;
    }

    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

}
