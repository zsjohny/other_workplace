package com.goldplusgold.td.expert.viewmodel.index;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.goldplusgold.td.expert.common.utils.DateUtil;
import com.goldplusgold.td.expert.common.utils.StringConverterUtil;
import com.goldplusgold.td.expert.entity.Article;

import java.io.Serializable;
import java.text.SimpleDateFormat;

@JsonPropertyOrder(alphabetic = true)
public class ArticleVM implements Serializable {

    private static final long serialVersionUID = 8906002779169651032L;

    private Article model;

    private String linkUrl;

    public ArticleVM(Article model) {
        this.model = model;
    }

    public String getSummary() {
        return StringConverterUtil.unescapeHtml(this.model.getSummary());
    }

    public String getTitle() {

        return StringConverterUtil.unescapeHtml(this.model.getNewsTitle());
    }

    public String getIssuanceTime() {
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtil.simpleShortM);
        return sdf.format(this.model.getDeliveryTime());
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public Integer getPageviewCount() {
        return this.model.getClickCount();
    }

    public String getNickname() {
        return model.getNewsFrom() == null ? "金专家" : model.getNewsFrom();
    }

    public String getImageUrl() {
        return this.model.getThumbnail();
    }

    public String getPhotoUrl() {
        return this.model.getFromLogo();
    }
    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }
}
