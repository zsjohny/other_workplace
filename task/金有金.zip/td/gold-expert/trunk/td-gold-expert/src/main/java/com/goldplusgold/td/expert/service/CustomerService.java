package com.goldplusgold.td.expert.service;


import com.goldplusgold.td.expert.entity.Customer;
import com.goldplusgold.td.expert.mapper.user.CustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private CustomerMapper mapper;

    public Customer selectCustomer(String userName){
        return mapper.selectCustomer(userName);
    }
}
