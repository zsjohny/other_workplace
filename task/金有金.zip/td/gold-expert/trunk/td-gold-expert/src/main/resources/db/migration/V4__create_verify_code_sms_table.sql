CREATE TABLE `message_template` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `create_by` varchar(64) NOT NULL COMMENT '创建者',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `del_flag` varchar(64) NOT NULL COMMENT '逻辑删除标记（0：显示；1：隐藏）',
  `name` varchar(64) NOT NULL COMMENT '模板名称',
  `content` text NOT NULL COMMENT '模板内容',
  `category` varchar(2) NOT NULL COMMENT '模板类别 0 手机注册,1 修改密码',
  `apply_status` varchar(1) NOT NULL COMMENT '模板启用状态 0-启用 1-不启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='短信/推送模版';

CREATE TABLE `message_record_log` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `phone` varchar(1000) DEFAULT NULL COMMENT '手机号码',
  `content` varchar(255) DEFAULT NULL COMMENT '短信内容',
  `send_type` varchar(2) DEFAULT NULL COMMENT '发送类别',
  `ip` varchar(64) DEFAULT NULL COMMENT '请求ip',
  `return_code` varchar(10) DEFAULT NULL COMMENT '返回结果',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `del_flag` varchar(64) DEFAULT NULL COMMENT '逻辑删除标记（0：显示；1：隐藏）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='短信记录';

CREATE TABLE `verify_code` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `del_flag` varchar(64) DEFAULT NULL COMMENT '逻辑删除标记（0：显示；1：隐藏）',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `verify_code` varchar(6) DEFAULT NULL COMMENT '验证码',
  PRIMARY KEY (`id`),
  KEY `del_flag` (`del_flag`(1)) USING BTREE,
  KEY `phone` (`phone`) USING BTREE,
  KEY `verify_code` (`verify_code`(4)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='验证码库';

CREATE TABLE `verify_code_log` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `del_flag` varchar(64) DEFAULT NULL COMMENT '逻辑删除标记（0：显示；1：隐藏）',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `message` varchar(64) DEFAULT NULL COMMENT '短信内容',
  `device_ip` varchar(32) DEFAULT NULL COMMENT 'ip地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='验证码发送记录';