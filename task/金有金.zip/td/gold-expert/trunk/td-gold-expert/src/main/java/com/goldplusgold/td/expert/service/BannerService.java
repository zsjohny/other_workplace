package com.goldplusgold.td.expert.service;


import com.goldplusgold.td.expert.entity.Banner;
import com.goldplusgold.td.expert.mapper.index.IBannerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.validation.constraints.NotNull;
import java.util.List;

@Service
public class BannerService {

    @Autowired
    private IBannerMapper mapper;

    public List<Banner> selectBanners(){
        return mapper.selectBanners();
    }

    public Banner selectBannerById(@NotNull String bannerId){
        return mapper.selectBannerById(bannerId);
    }
}
