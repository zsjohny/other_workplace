package com.goldplusgold.td.expert.viewmodel.index;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

/**
 * bannner信息列表VM
 */
@JsonPropertyOrder(alphabetic = true)
public class BannerListVM implements Serializable {

    private static final long serialVersionUID = -1589686628947471421L;
    private List<BannerVM> bannerList;

    public List<BannerVM> getBannerList() {
        return bannerList;
    }

    public void setBannerList(List<BannerVM> bannerList) {
        this.bannerList = bannerList;
    }
}
