package com.goldplusgold.td.expert.controller.banner;

import com.goldplusgold.td.expert.common.enumeration.LinkUrlTypeEnum;
import com.goldplusgold.td.expert.entity.Banner;
import com.goldplusgold.td.expert.exception.IndexException;
import com.goldplusgold.td.expert.service.BannerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "banner")
public class BannerController {
    private static final Logger logger = LoggerFactory.getLogger(BannerController.class);

    @Autowired
    private BannerService bannerService;

    @RequestMapping(value = "detail", method = RequestMethod.GET)
    public String getBannerDetail(String bannerId, Model model) {

        Banner banner = bannerService.selectBannerById(bannerId);

        if (banner == null ||
                banner.getLinkUrlType() == null ||
                banner.getLinkUrlType().intValue() != LinkUrlTypeEnum.IMAGE.toValue().intValue()) {
            throw new IndexException(IndexException.Info.BANNER_DATA_ERROR);
        }

        model.addAttribute("title", banner.getName());
        model.addAttribute("imgUrl", banner.getLinkUrl());

        return "banner/detail";
    }
}
