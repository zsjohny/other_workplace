package com.goldplusgold.td.expert.viewmodel.user;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * Customer信息
 */
@JsonPropertyOrder(alphabetic = true)
public class UserInfoVM implements Serializable {

    private static final long serialVersionUID = -8679858157491738193L;
    /**
     * 用户名
     */
    private String userName;

    /**
     * 头像
     */
    private String headImage;

    private Boolean loginState;

    private Boolean wechatState;

    public UserInfoVM() {
        this.loginState = false;
        this.wechatState = false;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHeadImage() {
        return headImage;
    }

    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }

    public Boolean getLoginState() {
        return loginState;
    }

    public void setLoginState(Boolean loginState) {
        this.loginState = loginState;
    }

    public Boolean getWechatState() {
        return wechatState;
    }

    public void setWechatState(Boolean wechatState) {
        this.wechatState = wechatState;
    }
}
