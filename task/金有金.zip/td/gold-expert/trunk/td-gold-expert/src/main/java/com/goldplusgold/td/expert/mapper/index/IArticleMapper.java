package com.goldplusgold.td.expert.mapper.index;


import com.goldplusgold.td.expert.entity.Article;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * banner mapper
 */
@Mapper
public interface IArticleMapper {

    List<Article> selectArticles(@Param("newsType")String newsType, @Param("offset")Integer offset, @Param("count")Integer count);
    Article selectArticleById(@Param("id")String articleId);
}
