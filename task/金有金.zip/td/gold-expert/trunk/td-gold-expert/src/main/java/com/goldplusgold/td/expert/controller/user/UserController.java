package com.goldplusgold.td.expert.controller.user;

import com.goldplusgold.td.expert.entity.Customer;
import com.goldplusgold.td.expert.service.CustomerService;
import com.goldplusgold.td.expert.share.data.IUserContext;
import com.goldplusgold.td.expert.viewmodel.user.UserInfoVM;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "user")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private IUserContext userContext;

    @Autowired
    private CustomerService customerService;

    @RequestMapping(value = "user_info", method = RequestMethod.GET)
    public UserInfoVM getUserInfo() {
        UserInfoVM userInfoVM = new UserInfoVM();
        try{
            String userName = userContext.getUserName();
            userInfoVM.setUserName(userName);
            Customer customer = customerService.selectCustomer(userName);
            if(null != customer){
                userInfoVM.setHeadImage(customer.getHeadImage());
                userInfoVM.setLoginState(true);
            }
            //TODO 微信状态
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
       return userInfoVM;
    }

}
