package com.goldplusgold.td.expert.exception;

import javax.validation.constraints.NotNull;

public class PagingException extends AbstractException {
    
    private static final long serialVersionUID = -3269482218236121354L;
    
    public PagingException(String errorCode,
                         String errorMsg) {
        super(errorCode, errorMsg, null, errorMsg);
    }
    
    public PagingException(Info info) {
        super(info.toCode(), info.toInfo(), null, info.toInfo());
    }
    
    public enum Info {
        
        PAGE_ERROR("No01", "页码传入不正确");
        
        /**
         * 异常编码
         */
        private String code;
                       
        /**
         * 异常信息
         */
        private String info;
                       
        Info(@NotNull String code,
             @NotNull String info) {
             
            this.code = code;
            this.info = info;
        }
        
        public String toCode() {
            return this.code;
        }
        
        public String toInfo() {
            return this.info;
        }
    }
}
