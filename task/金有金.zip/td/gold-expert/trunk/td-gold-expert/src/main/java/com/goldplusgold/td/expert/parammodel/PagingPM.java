package com.goldplusgold.td.expert.parammodel;

import com.goldplusgold.td.expert.exception.PagingException;
import java.io.Serializable;

/**
 * 用于客户端传值的基类
 */
public class PagingPM implements Serializable, IPMValidator {

    private static final long serialVersionUID = -1744744244271473962L;

    private Integer offset;
    
    private Integer count;
                              
    public Integer getOffset() {
        return offset;
    }
    
    public void setOffset(Integer offset) {
        this.offset = offset;
    }
    
    public Integer getCount() {
        return count;
    }
    
    public void setCount(Integer count) {

        this.count = count;
    }

    @Override
    public void validate() {
        if(null == offset || null == count || offset < 0 || count < 0 ){
            throw new PagingException(PagingException.Info.PAGE_ERROR) ;
        }
    }
}
