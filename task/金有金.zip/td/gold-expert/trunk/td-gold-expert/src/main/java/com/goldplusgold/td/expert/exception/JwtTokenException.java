package com.goldplusgold.td.expert.exception;

import javax.validation.constraints.NotNull;

/**
 * jwt token在其生命周期中出现的异常
 */
public class JwtTokenException extends AbstractException {

    public JwtTokenException(@NotNull Info info) {

        super(info.toCode(), info.toInfo(), null, info.toInfo());
    }

    public JwtTokenException(@NotNull Info info,
                             Exception e) {

        super(info.toCode(), info.toInfo(), e, info.toInfo());
    }

    public JwtTokenException(String errorCode,
                             String errorMsg,
                             Exception e,
                             String viewInfo) {
        super(errorCode, errorMsg, e, viewInfo);
    }

    public enum Info {

        CREATE_JWT_PARAM_MISS("JTE01", "创建 JWT TOKEN 时，缺少创建 JWT TOKEN 的参数"),
        VERIFY_JWT_ERROR("JTE02", "JWT TOKEN 验证异常"),
        VERIFY_JWT_PARAM_MISS("JTE03", "验证 JWT TOKEN 时，解析出来的参数出现缺失"),
        REFRESH_JWT_PARAM_MISS("JTE04", "刷新 JWT TOKEN 时，发现缺少了创建 JWT TOKEN 的参数"),
        REQUEST_GET_JWT_ERROR("JTE05", "没有从访问请求中获取到 JWT TOKEN 信息"),
        ACCESS_ERROR("JTE06", "从访问请求中，获取 JWT TOKEN 信息，并验证权限时出错"),
        TOKEN_EXPIRATION("JTE07", "JWT TOKEN已经过期."),
        MOBILE_UNIQUE_LOGIN_ERROR("JTE08", "当前用户已经从其它移动端登录");

        /**
         * 异常编码
         */
        private String code;
        /**
         * 异常信息
         */
        private String info;


        Info(String code, String info) {

            this.code = code;
            this.info = info;
        }

        public String toCode() {
            return this.code;
        }

        public String toInfo() {
            return this.info;
        }
    }
}
