package com.goldplusgold.td.expert.exception;

import javax.validation.constraints.NotNull;

public class IndexException extends AbstractException {
    
    private static final long serialVersionUID = 6311323176613295478L;

    public IndexException(@NotNull Info info) {
        super(info.toCode(), info.toInfo(),null,info.toInfo());
    }
    
    public IndexException(@NotNull Info info, Exception e) {
        super(info.toCode(), info.toInfo(), e,info.toInfo());
    }
    
    public enum Info {

        ARTICLES_DATA_ERROR("Article01", "专家评论数据异常"),
        ARTICLE_DATA_ERROR("Article02", "专家评论详情数据异常"),
        BANNERS_DATA_ERROR("Banner01", "首页banner数据异常"),
        BANNER_DATA_ERROR("Banner02", "首页banner详情数据异常");


        /**
         * 异常编码
         */
        private String code;
        /**
         * 异常信息
         */
        private String info;
        
        Info(String code,
             String info) {
            this.code = code;
            this.info = info;
        }
        
        public String toCode() {
            return this.code;
        }
        
        public String toInfo() {
            return this.info;
        }
    }
    
}
