package com.goldplusgold.td.expert.config;

import com.goldplusgold.td.expert.share.auth.*;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.DelegatingFilterProxy;
import javax.servlet.Filter;
import javax.servlet.ServletException;
import java.util.HashMap;
import java.util.Map;

/**
 * 认证与授权相关的配置（shiro）
 */

@Configuration
public class ShiroConfig {

    @Bean
    public FilterRegistrationBean filterRegistrationBean() throws ServletException {
        FilterRegistrationBean filterRegistration = new FilterRegistrationBean();
        DelegatingFilterProxy proxy = new DelegatingFilterProxy("shiroFilter");
        proxy.setTargetFilterLifecycle(true);
        filterRegistration.setFilter(proxy);
        filterRegistration.setEnabled(true);
        filterRegistration.addUrlPatterns("/*");
        return filterRegistration;
    }

    @Bean
    public LifecycleBeanPostProcessor createLifecycleBeanPostProcessor() {
        return new LifecycleBeanPostProcessor();
    }

    @Bean(name = "shiroFilter")
    public ShiroFilterFactoryBean createShiroFilter(@Autowired AppAnonFilter appAnonFilter,
                                                    @Autowired AppAuthcFilter appAuthcFilter,
                                                    @Autowired H5AnonFilter h5AnonFilter,
                                                    @Autowired H5AuthcFilter h5AuthcFilter) {

        ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
        bean.setSecurityManager(new DefaultWebSecurityManager());

        Map<String, Filter> filters = new HashMap<>();
        filters.put("appAnon", appAnonFilter);
        filters.put("appAuthc", appAuthcFilter);
        filters.put("h5Anon", h5AnonFilter);
        filters.put("h5Authc", h5AuthcFilter);
        bean.setFilters(filters);

        Map<String, String> chains = new HashMap<>();

        //权限在这里添加


        bean.setFilterChainDefinitionMap(chains);

        return bean;
    }
}
