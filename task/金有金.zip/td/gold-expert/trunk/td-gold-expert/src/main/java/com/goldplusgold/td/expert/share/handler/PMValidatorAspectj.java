package com.goldplusgold.td.expert.share.handler;

import com.goldplusgold.td.expert.parammodel.IPMValidator;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.Optional;

@Aspect
@Component
public class PMValidatorAspectj {

    private static final Logger logger = LoggerFactory.getLogger(PMValidatorAspectj.class);

    @Pointcut("execution(public * com.goldplusgold.td.expert.controller.*.*.*(..))")
    public void declareJoinPointExpression() {
    }

    @Before("declareJoinPointExpression()")
    public void validatorPM(JoinPoint point) {
        Object[] args = point.getArgs();
        Optional oreq = Arrays.stream(args).filter(arg -> arg instanceof IPMValidator).findFirst();
        if (oreq.isPresent()) {
            IPMValidator pmv = (IPMValidator) oreq.get();
            pmv.validate();
            logger.info("IPMValidator.validate()");
        }
    }

}
