package com.goldplusgold.td.expert.share.common.utils;

import com.goldplusgold.td.expert.common.constant.TokenInfo;
import com.goldplusgold.td.expert.common.enumeration.ExpirationTimeEnum;
import com.goldplusgold.td.expert.share.auth.JwtUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.Optional;

public class TokenAndCookieOperation {

    public static void handleTokenCookie(HttpServletRequest request,
                                         HttpServletResponse response, String m_domain) {

        Cookie jwtCookie;
        Optional<Cookie> tokenCookie = Optional.empty();
        if (ArrayUtils.isNotEmpty(request.getCookies())) {
            tokenCookie = Arrays.stream(request.getCookies()).
                    filter(cookie -> TokenInfo.HTTP_RESPONSE_HEADER_TOKEN_NAME.equals(cookie.getName()))
                    .findAny();
        }
        if (tokenCookie.isPresent()) {
            jwtCookie = OperationCookie.getUpdatedCookie(tokenCookie.get(),
                    ExpirationTimeEnum.WEB_EXPIR.toSecond(),
                    m_domain);
            response.addCookie(jwtCookie);
        } else {
            String jwtToken = JwtUtils.getJWTTokenFromCookie(request);
            if (StringUtils.isNotEmpty(jwtToken)) {
                jwtCookie = OperationCookie.getNewCookie(
                        TokenInfo.HTTP_RESPONSE_HEADER_TOKEN_NAME,
                        jwtToken,
                        ExpirationTimeEnum.WEB_EXPIR.toSecond(),
                        m_domain);
                response.addCookie(jwtCookie);
            }
        }
    }

}
