package com.goldplusgold.td.expert.entity;

import com.goldplusgold.td.expert.viewmodel.BaseModel;

/**
 * banner信息
 */
public class Banner extends BaseModel {

    private static final long serialVersionUID = -1026985331671110944L;
    /**
     * 图片名
     */
    private String name;

    /**
     * 图片地址
     */
    private String imgUrl;
    /**
     * 图片类型 0-banner，1-活动图，2-开机图
     */
    private Integer imgType;
    /**
     * 图片链接地址

     */
    private String linkUrl;
    /**
     * 逻辑删除标记（0：显示；1：隐藏）
     */
    private Integer delFlag;
    /**
     *链接类型0页面1图片
     */
    private Integer linkUrlType;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public Integer getImgType() {
        return imgType;
    }

    public void setImgType(Integer imgType) {
        this.imgType = imgType;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public Integer getLinkUrlType() {
        return linkUrlType;
    }

    public void setLinkUrlType(Integer linkUrlType) {
        this.linkUrlType = linkUrlType;
    }

}
