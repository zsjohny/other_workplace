package com.goldplusgold.td.expert.viewmodel.index;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder(alphabetic = true)
public class ArticleListVM implements Serializable {
    
    private static final long serialVersionUID = -7637893123702362019L;
    

    private List<ArticleVM> articleList;

    public List<ArticleVM> getArticleList() {
        return articleList;
    }

    public void setArticleList(List<ArticleVM> articleList) {
        this.articleList = articleList;
    }
}
