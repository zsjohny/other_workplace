package com.goldplusgold.td.expert.share.auth;

import com.goldplusgold.td.expert.share.data.IUserContext;
import com.goldplusgold.td.expert.share.data.UserContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.web.filter.authc.AnonymousFilter;
import org.apache.shiro.web.util.WebUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * shiro拦截器(针对app原生界面，处理匿名的情况，可能是登录过的，也可能是未登录过）
 */
@Component
public class AppAnonFilter extends AnonymousFilter {


    @Autowired
    private IUserContext m_userContext;

    @Override
    protected boolean onPreHandle(ServletRequest request,
                                  ServletResponse response,
                                  Object mappedValue) {

        final HttpServletRequest req = WebUtils.toHttp(request);
        String jwtToken = JwtUtils.getJWTTokenFromHeader(req);
        if (StringUtils.isNotEmpty(jwtToken)) {
            JwtUtils.verifyJWT(jwtToken, req);
            RefreshJWTTokenUtil.refreshJWTToken(req, WebUtils.toHttp(response));
            UserContextUtils.set(req, m_userContext);
        }

        return super.onPreHandle(request, response, mappedValue);
    }
}
