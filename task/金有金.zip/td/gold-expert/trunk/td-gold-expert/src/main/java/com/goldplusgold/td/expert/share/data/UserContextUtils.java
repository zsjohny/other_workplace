package com.goldplusgold.td.expert.share.data;


import com.goldplusgold.td.expert.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.expert.common.enumeration.PlatformEnum;

import javax.servlet.http.HttpServletRequest;

public class UserContextUtils {

    /**
     * 设置一些金有金与TD用户常用数据，在上下文中使用
     */
    public static void set(HttpServletRequest req,
                           IUserContext userContext) {

        String userId = (String) req.getAttribute(LoginParamsEnum.USERID.toName());
        String userName = (String) req.getAttribute(LoginParamsEnum.USERNAME.toName());
        String platform = (String) req.getAttribute(LoginParamsEnum.PLATFORM.toName());
        String imei = (String) req.getAttribute(LoginParamsEnum.IMEI.toName());
        String clientId = (String) req.getAttribute(LoginParamsEnum.CLIENTID.toName());
        String loginTime = (String) req.getAttribute(LoginParamsEnum.LOGINTIME.toName());

        userContext.setUserID(userId);
        userContext.setUserName(userName);
        userContext.setImei(imei);
        userContext.setClientID(clientId);
        userContext.setPlatform(PlatformEnum.getPlatform(platform));
        userContext.setLoginTime(loginTime);
    }
}
