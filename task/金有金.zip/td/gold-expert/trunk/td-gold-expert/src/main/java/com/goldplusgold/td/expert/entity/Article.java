package com.goldplusgold.td.expert.entity;

import com.goldplusgold.td.expert.viewmodel.BaseModel;
import java.util.Date;

/**
 * 客户端新闻
 */
public class Article extends BaseModel {

    private static final long serialVersionUID = 1075684451653749729L;
    /**
     * 新闻标题
     */
    private String newsTitle;

    /**
     * 新闻内容
     */
    private String content;

    /**
     * 新闻类型
     */
    private String newsType;

    /**
     * 阅读人数
     */
    private Integer clickCount;

    /**
     * 权重
     */
    private String important;

    /**
     * 发布时间
     */
    private Date deliveryTime;

    /**
     * 新闻来源
     */
    private String newsFrom;

    /**
     * 来源logo
     */
    private String fromLogo;

    /**
     * 状态
     * 0  可用
     * 1不可用
     */
    private String isEnable;

    /**
     * 内容简介
     */
    private String summary;

    /**
     * 缩略图
     */
    private String thumbnail;

    public String getNewsTitle() {
        return newsTitle;
    }

    public void setNewsTitle(String newsTitle) {
        this.newsTitle = newsTitle == null ? null : newsTitle.trim();
    }

    public String getNewsType() {
        return newsType;
    }

    public void setNewsType(String newsType) {
        this.newsType = newsType == null ? null : newsType.trim();
    }

    public Integer getClickCount() {
        return clickCount;
    }

    public void setClickCount(Integer clickCount) {
        this.clickCount = clickCount == null ? null : clickCount;
    }

    public String getImportant() {
        return important;
    }

    public void setImportant(String important) {
        this.important = important == null ? null : important.trim();
    }

    public Date getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(Date deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getNewsFrom() {
        return newsFrom;
    }

    public void setNewsFrom(String newsFrom) {
        this.newsFrom = newsFrom == null ? null : newsFrom.trim();
    }

    public String getFromLogo() {
        return fromLogo;
    }

    public void setFromLogo(String fromLogo) {
        this.fromLogo = fromLogo == null ? null : fromLogo.trim();
    }

    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable == null ? null : isEnable.trim();
    }


    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary == null ? null : summary.trim();
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail == null ? null : thumbnail.trim();
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }


    /**
     * TODO 此处代码为临时解决方案
     * 给PC端多返回一个类目字段，便于SEO优化
     */
    public String getCategory() {
        switch (newsType) {
            case "0":
                return "专家评论";
            default:
                return "";
        }
    }
}