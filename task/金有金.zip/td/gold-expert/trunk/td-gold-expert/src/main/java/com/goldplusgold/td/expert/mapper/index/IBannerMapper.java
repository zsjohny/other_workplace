package com.goldplusgold.td.expert.mapper.index;


import com.goldplusgold.td.expert.entity.Banner;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * banner mapper
 */
@Mapper
public interface IBannerMapper {

    List<Banner> selectBanners();
    Banner selectBannerById(@Param("id")String bannerId);

}
