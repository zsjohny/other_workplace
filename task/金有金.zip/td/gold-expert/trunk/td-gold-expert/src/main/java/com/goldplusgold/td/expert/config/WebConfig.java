package com.goldplusgold.td.expert.config;

import com.goldplusgold.td.expert.common.utils.Jackson2ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.util.List;

/**
 * web配置
 */
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {


    @Bean
    public MappingJackson2HttpMessageConverter createMappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter jackson2Converter = new MappingJackson2HttpMessageConverter();
        Jackson2ObjectMapper jackson2 = new Jackson2ObjectMapper();
        jackson2Converter.setObjectMapper(jackson2);
        return jackson2Converter;
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/about_me").setViewName("aboutMe"); //关于我们
        registry.addViewController("/service_agreement").setViewName("serviceAgreement"); //服务协议
        registry.addViewController("/novice_classroom").setViewName("noviceClassroom"); //新手课堂
        registry.addViewController("/minute_introduce").setViewName("novice/minuteIntroduce"); //一分钟看懂T+D
        registry.addViewController("/open_close_account").setViewName("novice/openCloseAccount"); //开户和销户
        registry.addViewController("/relation").setViewName("novice/tdRelation"); //交易相关类
        registry.addViewController("/liquidation_rules").setViewName("novice/liquidationRules"); //清算规则
        registry.addViewController("/risk_control").setViewName("novice/riskControl"); //如何有效控制投资风险
    }

    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(createMappingJackson2HttpMessageConverter());
    }

}
