package com.goldplusgold.td.expert.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * 数据库配置（redis）
 */
@Configuration
public class RedisConfig {

    @Value("${redis.host}")
    private String hostName;

    @Value("${redis.port}")
    private Integer port;

    @Value("${redis.password}")
    private String password;

    @Value("${redis.maxIdle}")
    private Integer maxIdle;

    @Value("${redis.maxTotal}")
    private Integer maxTotal;

    @Value("${redis.maxWaitMillis}")
    private Long maxWaitMillis;

    @Value("${redis.testOnBorrow}")
    private Boolean testOnBorrow;

    @Value("${redis.testOnReturn}")
    private Boolean testOnReturn;

    @Value("${redis.database}")
    private Integer dbIndex;

    @Autowired
    private JedisPoolConfig poolConfig;

    @Bean
    public JedisPoolConfig createJedisPoolConfig(){
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        jedisPoolConfig.setMaxIdle(maxIdle);
        jedisPoolConfig.setMaxTotal(maxTotal);
        jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
        jedisPoolConfig.setTestOnBorrow(testOnBorrow);
        jedisPoolConfig.setTestOnReturn(testOnReturn);

        return jedisPoolConfig;
    }


    @Bean
    public JedisConnectionFactory createJedisConnectionFactory() {
        JedisConnectionFactory jedisFactory = new JedisConnectionFactory();

        jedisFactory.setHostName(hostName);
        jedisFactory.setPort(port);
        jedisFactory.setPassword(password);
        jedisFactory.setUsePool(true);
        jedisFactory.setPoolConfig(poolConfig);
        jedisFactory.setDatabase(dbIndex);

        return jedisFactory;
    }

    @Bean
    public JedisPool createJedisPool(){
        return new JedisPool(poolConfig, hostName);
    }

}
