CREATE TABLE `banner` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `name` varchar(64) DEFAULT NULL COMMENT '图片名',
  `img_url` varchar(800) DEFAULT NULL COMMENT '图片的地址',
  `img_type` varchar(1) DEFAULT NULL COMMENT '图片类型 0-banner，1-活动图，2-开机图',
  `link_url` varchar(255) DEFAULT NULL COMMENT '图片的链接地址',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `del_flag` varchar(64) DEFAULT NULL COMMENT '逻辑删除标记（0：显示；1：隐藏）',
  `link_url_type` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='banner图片表';

CREATE TABLE `article` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `title` varchar(64) DEFAULT NULL COMMENT '标题',
  `content` longtext COMMENT '内容',
  `article_type` varchar(2) DEFAULT NULL COMMENT '类型 0 专家点评',
  `click_count` varchar(64) DEFAULT NULL COMMENT '点击量',
  `important` varchar(64) DEFAULT NULL COMMENT '权重',
  `delivery_time` datetime DEFAULT NULL COMMENT '发布时间',
  `article_from` varchar(20) DEFAULT NULL COMMENT '新闻来源',
  `from_logo` varchar(255) DEFAULT NULL COMMENT '来源logo',
  `is_enable` varchar(1) DEFAULT NULL COMMENT '状态 0：待发布 1：已发布',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `del_flag` varchar(64) DEFAULT NULL COMMENT '逻辑删除标记（0：显示；1：隐藏）',
  `summary` varchar(2555) DEFAULT NULL COMMENT '内容简介',
  `thumbnail` varchar(255) DEFAULT NULL COMMENT '缩略图',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文章表';