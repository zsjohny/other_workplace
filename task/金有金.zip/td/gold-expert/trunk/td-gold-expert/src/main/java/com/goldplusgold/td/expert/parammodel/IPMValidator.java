package com.goldplusgold.td.expert.parammodel;

public interface IPMValidator {

    void validate();
}
