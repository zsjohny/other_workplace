package com.goldplusgold.td.expert.common.utils;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

public class StringConverterUtil {
    
    public static String unescapeHtml(String htmlEscaped) {
        return StringEscapeUtils.unescapeHtml4(htmlEscaped);
    }
    
    public static String hideImportantPhoneNo(String phone) {
        if (StringUtils.isEmpty(phone)) {
            return "*";
        } else if (phone.matches("^[0-9]+$")) {
            return phone.substring(0,
                                   3)
                   + "****" + phone.substring(7);
        } else {
            return phone.substring(0,
                                   1)
                   + "**";
        }
    }
}
