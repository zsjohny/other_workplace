package com.goldplusgold.td.expert.common.enumeration;

/**
 * jwt token的过期时间设置
 */
public enum ExpirationTimeEnum {

    /**
     * Cookie过期时间，设置为10天
     */
    WEB_EXPIR(10 * 24 * 60 * 60 * 1000L),

    /**
     * 移动端过期时间，设置为20天
     */
    MOBILE_EXPIR(20 * 24 * 60 * 60 * 1000L);

    private long expirMillis;

    ExpirationTimeEnum(long expirMillis) {
        this.expirMillis = expirMillis;
    }

    /**
     * 返回毫秒时间
     */
    public long toMillisecond() {
        return this.expirMillis;
    }

    /**
     * 返回秒时间
     */
    public int toSecond() {
        return (int) this.expirMillis / 1000;
    }
}
