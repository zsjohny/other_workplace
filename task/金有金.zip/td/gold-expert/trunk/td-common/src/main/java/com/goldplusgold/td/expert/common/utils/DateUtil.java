package com.goldplusgold.td.expert.common.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/* *
 *功能：自定义订单类
 *详细：工具类，可以用作获取系统日期、订单编号等
 */
public class DateUtil {

    /**
     * 年月日时分秒(无下划线) yyyyMMddHHmmss
     */
    public static final String dtLong = "yyyyMMddHHmmss";

    /** 完整时间 yyyy-MM-dd HH:mm:ss */
    public static final String simple = "yyyy-MM-dd HH:mm:ss";

    /** 年月日(无下划线) yyyyMMdd */
    public static final String dtShort = "yyyyMMdd";

    /** 年月日有下划线的 */
    public static final String simpleShort = "yyyy-MM-dd";

    /* 到分的日期格式 */
    public static final String simpleShortM = "yyyy-MM-dd HH:mm";

    /** 时分秒HH:mm:ss */
    public static final String dtDay = "HHmmss";

    /** 点乐开奖时间 */
    public static final String dele_time = " 20:50:00";

    /**
     * 时间毫秒级
     */
    public static final String MILISECOND = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * 含年月日的时间格式
     */
    public static final String ChinesizationDate = "yyyy年MM月dd日";

    /**
     * 获取系统当前日期(精确到毫秒)，格式：yyyy-MM-dd HH:mm:ss
     *
     * @return
     */
    public static String getDateFormatter() {
        Date date = new Date();
        DateFormat df = new SimpleDateFormat(simple);
        return df.format(date);
    }

    /**
     * 获取系统当期年月日(精确到天)，格式：yyyyMMdd
     *
     * @return
     */
    public static String getDate() {
        Date date = new Date();
        DateFormat df = new SimpleDateFormat(dtShort);
        return df.format(date);
    }

    /**
     * 获取下一天时间格式20150401
     *
     * @return
     */
    public static String getNextDay() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.set(Calendar.DATE, cal.get(Calendar.DATE) + 1);
        SimpleDateFormat sdf = new SimpleDateFormat(dtShort);
        return sdf.format(cal.getTime());
    }

    /**
     * 获取当前点乐出奖时间
     *
     * @return
     */
    public static Date getDele_y_m_d() throws Exception {
        Date date = new Date();
        DateFormat df = new SimpleDateFormat(simpleShort);
        String deleTime = df.format(date) + dele_time;
        SimpleDateFormat sdf = new SimpleDateFormat(simple);
        return sdf.parse(deleTime);
    }

    /**
     * 获取当前时间减一天
     *
     * @param date
     * @return
     */
    public static Date getDate_one_day_before(Date date) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DATE, cal.get(Calendar.DATE) - 1);
        Date beforeDate = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat(simple);
        return sdf.parse(sdf.format(beforeDate));
    }

    /**
     * 获取后一天时间
     *
     * @param date
     * @return
     * @return String
     * @author jason
     * @date 2016年4月12日
     */
    public static String getDateAfterToday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DATE, cal.get(Calendar.DATE) + 1);
        Date afterToday = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat(simpleShort);
        return sdf.format(afterToday);
    }

    /**
     * 获取一年中第几天 date类型YYmmdd
     *
     * @param date
     * @return
     */
    public static int getTheNthDayOfYear(String date) {
        int nthDay = 0;
        int year = Integer.parseInt(date.substring(0, 4));
        int month = Integer.parseInt(date.substring(4, 6));
        int day = Integer.parseInt(date.substring(6, 8));
        for (int i = 1; i < month; i++) {
            switch (i) {
            case 1:
                nthDay += 31;
                break;
            case 2:
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                    nthDay += 29;
                } else {
                    nthDay += 28;
                }
                break;
            case 3:
                nthDay += 31;
                break;
            case 4:
                nthDay += 30;
                break;
            case 5:
                nthDay += 31;
                break;
            case 6:
                nthDay += 30;
                break;
            case 7:
                nthDay += 31;
                break;
            case 8:
                nthDay += 31;
                break;
            case 9:
                nthDay += 30;
                break;
            case 10:
                nthDay += 31;
                break;
            case 11:
                nthDay += 30;
                break;
            case 12:
                nthDay += 31;
                break;
            }
        }
        nthDay += day;

        return nthDay;
    }

    /**
     * 根据当前时间判断属于第几期
     *
     * @return
     */
    public static String getPeriodFromDate() throws Exception {
        Date deleTime = getDele_y_m_d();
        Date date = new Date();
        /* 判断当前时间是否先于点乐开奖时间 */
        if (date.before(deleTime)) {
            return getDate();
        }
        return getNextDay();
    }

    /**
     * 获取这个月的最后一天是一年中的第几天
     *
     * @return
     * @throws Exception
     */
    public static int getThisMonthLastDayOfYear() throws Exception {
        String year = getPeriodFromDate().substring(0, 4);
        String month = getPeriodFromDate().substring(4, 6);
        if ("12".equals(month)) {
            String lastDay = year + month + "31";
            return getTheNthDayOfYear(lastDay);
        }
        String nextMonth = (Integer.parseInt(month) + 1) + "";
        if (nextMonth.length() < 2) {
            nextMonth = "0" + nextMonth;
        }
        String firstDay = year + nextMonth + "01";
        return getTheNthDayOfYear(firstDay) - 1;
    }

    /**
     * 获取下个月第一天的期数
     *
     * @return
     * @throws Exception
     */
    public static String getFirstDayOfNextMonthPeriod() throws Exception {
        String period = getPeriodFromDate();
        int year = Integer.parseInt(period.substring(0, 4));
        String month = period.substring(4, 6);
        if ("12".equals(month)) {
            year++;
            month = "01";
        } else {
            int nextMonth = Integer.parseInt(month) + 1;
            if (nextMonth < 10) {
                month = "0" + nextMonth;
            } else {
                month = nextMonth + "";
            }
        }
        return year + month + "01";
    }

    /**
     * 根据期数返回下个月第一天的期数
     */
    public static String getFirstDayOfNextMonthPeriod(String period) throws Exception {
        int year = Integer.parseInt(period.substring(0, 4));
        String month = period.substring(4, 6);
        if ("12".equals(month)) {
            year++;
            month = "01";
        } else {
            int nextMonth = Integer.parseInt(month) + 1;
            if (nextMonth < 10) {
                month = "0" + nextMonth;
            } else {
                month = nextMonth + "";
            }
        }
        return year + month + "01";
    }

    /**
     * 获取这个月最后一天是第几期
     *
     * @return
     * @throws Exception
     */
    public static String getLastDayPeriodOfThisMonth() throws Exception {
        int year = Integer.parseInt(getPeriodFromDate().substring(0, 4));
        String month = getPeriodFromDate().substring(4, 6);
        String lastDay = "";
        switch (Integer.parseInt(month)) {
        case 1:
            lastDay = "31";
            break;
        case 2:
            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                lastDay = "29";
            } else {
                lastDay = "28";
            }
            break;
        case 3:
            lastDay = "31";
            break;
        case 4:
            lastDay = "30";
            break;
        case 5:
            lastDay = "31";
            break;
        case 6:
            lastDay = "30";
            break;
        case 7:
            lastDay = "31";
            break;
        case 8:
            lastDay = "31";
            break;
        case 9:
            lastDay = "30";
            break;
        case 10:
            lastDay = "31";
            break;
        case 11:
            lastDay = "30";
            break;
        case 12:
            lastDay = "31";
            break;
        }
        return year + month + lastDay;
    }

    /**
     * 获取上个月的年份和月份
     *
     * @param period
     * @return
     * @throws Exception
     */
    public static String getLastMonthPeriod(String period) throws Exception {
        String result = "";
        int year = Integer.parseInt(period.substring(0, 4));
        int month = Integer.parseInt(period.substring(4, 6));
        if (month == 1) {
            year--;
            month = 12;
        } else {
            month--;
        }
        if (month < 10) {
            result = "0" + month;
        } else {
            result = "" + month;
        }
        return year + result;
    }

    /**
     * 格式化时间yy-MM-dd
     *
     * @param date
     * @return
     * @return String
     * @author jason
     * @date 2016年3月28日
     */
    public static String getSimpleShortDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(simpleShort);
        return sdf.format(date);
    }

    /**
     * 获取定期期限
     *
     * @param status
     * @return
     * @return String
     * @author jason
     * @date 2016年3月28日
     */
    public static String getTimeLimitStr(String status) {
        String result = "永久";
        if (status.endsWith("D")) {
            result = Integer.parseInt(status.substring(0, status.length()-1)) + "天";
        } else if (status.endsWith("M")) {
            result = (Integer.parseInt(status.substring(0, status.length()-1))*30) + "天";
        } else if (status.endsWith("Y")) {
            result = (Integer.parseInt(status.substring(0, status.length()-1))*365) + "天";
        }
        return result;
    }

    public static void main(String[] args) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        System.out.print(daysBetween(new Date(),sdf.parse("2017-01-20 23:23:00")));

//        long current=System.currentTimeMillis();//当前时间毫秒数
//        long zero=current/(1000*3600*24)*(1000*3600*24)-TimeZone.getDefault().getRawOffset();//今天零点零分零秒的毫秒数
//        long twelve=zero+24*60*60*1000-1;//今天23点59分59秒的毫秒数
//        long yesterday=System.currentTimeMillis()-24*60*60*1000;//昨天的这一时间的毫秒数
//        System.out.println(new Timestamp(current));//当前时间
//        System.out.println(new Timestamp(yesterday));//昨天这一时间点
//        System.out.println(new Timestamp(zero));//今天零点零分零秒
//        System.out.println(new Timestamp(twelve));//今天23点59分59秒

    }

    public static int daysBetweenDate(Date nowDate, Date bookDate) {
        @SuppressWarnings("deprecation")
        int weekDay = nowDate.getDay();
        Calendar cal = Calendar.getInstance();
        cal.setTime(nowDate);
        if (weekDay==0) {
            cal.add(Calendar.DAY_OF_MONTH, 5);
        } else if (weekDay==1) {
            cal.add(Calendar.DAY_OF_MONTH, 7);
        } else if (weekDay==2) {
            cal.add(Calendar.DAY_OF_MONTH, 6);
        } else if (weekDay==3) {
            cal.add(Calendar.DAY_OF_MONTH, 5);
        } else if (weekDay==4) {
            cal.add(Calendar.DAY_OF_MONTH, 5);
        } else if (weekDay==5) {
            cal.add(Calendar.DAY_OF_MONTH, 5);
        } else if (weekDay==6) {
            cal.add(Calendar.DAY_OF_MONTH, 5);
        }
        long time1 = cal.getTimeInMillis();
        cal.setTime(bookDate);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        return Integer.parseInt(String.valueOf(between_days));
    }

    public static int daysBetween(Date date1, Date date2) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date1);
        int day1 = cal.get(Calendar.DAY_OF_YEAR);
        cal.setTime(date2);
        int day2 = cal.get(Calendar.DAY_OF_YEAR);

        return day2 - day1 - 10;
    }

    /**
     * 返回一周日期格式{"21", "22", "23"}
     * @return
     * @return String[]
     * @author jason
     * @date 2016年4月28日
     */
    public static String[] createOneWeekDate() {
        String[] date = new String[7];
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -7);
        for (int i=0; i<7; i++) {
            cal.add(Calendar.DATE, 1);
            date[i] = String.valueOf(cal.get(Calendar.DATE));
        }
        return date;
    }

    /**
     * 获取一个月日期
     * @return
     * @return String[]
     * @author jason
     * @date 2016年4月28日
     */
    public static String[] createOneMonthDate() {
        String[] date = new String[30];
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -30);
        for (int i=0; i<30; i++) {
            cal.add(Calendar.DATE, 1);
            date[i] = String.valueOf(cal.get(Calendar.DATE));
        }
        return date;
    }

    public static Integer activeIsStart(Date startDate,Date endDate) {
        int isStart = 0;
        if (startDate != null && startDate.compareTo(new Date()) == 1) {
            isStart = 1;
        }
        if (endDate != null && endDate.compareTo(new Date()) == -1) {
            isStart = 2;
        }

        return isStart;
    }

    public static String getChinesizationDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(ChinesizationDate);

        return sdf.format(date);
    }

    public static int getYearBetweenDate(Date startDate, Date endDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        long startTime = cal.getTimeInMillis();
        cal.setTime(endDate);
        long endTime = cal.getTimeInMillis();
        long between_days=(endTime-startTime)/(1000*3600*24);

        return Integer.parseInt(String.valueOf(between_days))/365 ;
    }

}
