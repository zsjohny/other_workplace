package com.goldplusgold.td.expert.common.enumeration;

public enum LinkUrlTypeEnum {

    PAGE(0),

    IMAGE(1);

    private Integer value;

    LinkUrlTypeEnum(Integer value) {
        this.value = value;
    }

    public Integer toValue() {
        return this.value;
    }
}
