package com.goldplusgold.td.user.common.constant;

/**
 * 与jwt token相关的常量
 */
public class TokenInfo {

    /**
     * 过期参数
     */
    public static final String EXPIRATION = "expiration";

    /**
     * HTTP header中的Authorization参数
     */
    public static final String HTTP_HEADER_AUTHORIZATION = "Authorization";

    /**
     * http响应中返回的token名称
     */
    public static final String HTTP_RESPONSE_HEADER_TOKEN_NAME = "_x-access-token";

    /**
     * HTTP header中的Authorization参数的Bearer认证类型
     */
    public static final String HTTP_HEADER_AUTHORIZATION_BEARER = "Bearer";


    public static final String HTTP_HEADER_LOGIN_TIME_STAMP = "loginTime";

    /**
     * 是否刷新JWT Token的key
     */
    public static final String REFRESH_JWT_TOKEN_FLAG_KEY = "RefreshJWTTokenFlag";

    public static final String REFRESH_JWT_TOKEN_FLAG_VALUE = "RefreshJWTTokenValue";
}
