package com.goldplusgold.td.user.common.constant;

/**
 * 云融正通短信返回结果属性名
 */
public class YrztSMSCode {

    /**
     * 结果码
     */
    public static final String RESULT_CODE = "resultCode";

    /**
     * 错误码
     */
    public static final String ERROR_CODE = "errorCode";
}
