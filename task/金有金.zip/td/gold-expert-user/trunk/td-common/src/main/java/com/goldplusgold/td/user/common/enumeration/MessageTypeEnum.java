package com.goldplusgold.td.user.common.enumeration;

public enum MessageTypeEnum {


    /**
     * 注册
     */
    REGISTER(0),

    /**
     * 忘记密码
     */
    MODIFY_PASSWORD(1);

    private Integer value;

    MessageTypeEnum(Integer value) {
        this.value = value;
    }

    public Integer toValue() {
        return this.value;
    }


}
