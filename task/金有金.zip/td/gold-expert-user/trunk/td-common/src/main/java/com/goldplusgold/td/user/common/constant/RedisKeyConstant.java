package com.goldplusgold.td.user.common.constant;

/**
 * Redis的key
 */
public class RedisKeyConstant {

    /**
     * 移动端登录互踢的标志前缀
     */
    private static final String MOBILE_UNIQUE_LOGIN_KEY = "td_unique_login_userid:%s";

    public static String getMobileUniqueLoginKey(String userID) {
        return String.format(MOBILE_UNIQUE_LOGIN_KEY, userID);
    }
}
