package com.goldplusgold.td.user.common.enumeration;

/**
 * jwt token的过期时间设置
 */
public enum ExpirationTimeEnum {

    /**
     * 移动端过期时间，设置为20天
     */
    MOBILE_EXPIR(20 * 24 * 60 * 60 * 1000L);

    private long expirMillis;

    ExpirationTimeEnum(long expirMillis) {
        this.expirMillis = expirMillis;
    }

    /**
     * 返回毫秒时间
     */
    public long toMillisecond() {
        return this.expirMillis;
    }

    /**
     * 返回秒时间
     */
    public int toSecond() {
        return (int) this.expirMillis / 1000;
    }
}
