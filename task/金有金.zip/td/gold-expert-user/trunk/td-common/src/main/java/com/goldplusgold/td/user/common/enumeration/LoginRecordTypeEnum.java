package com.goldplusgold.td.user.common.enumeration;


public enum LoginRecordTypeEnum {
    SUCCESS(0),

    FAILED(1);

    private Integer  value;

    LoginRecordTypeEnum(Integer value) {
        this.value = value;
    }

    public Integer toValue() {
        return this.value;
    }
}
