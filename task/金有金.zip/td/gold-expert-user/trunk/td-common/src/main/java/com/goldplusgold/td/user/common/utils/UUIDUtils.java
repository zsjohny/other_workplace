package com.goldplusgold.td.user.common.utils;


import java.util.UUID;

/**
 * UUID操作工具类
 */
public class UUIDUtils {

    /**
     * 创建uuid值
     */
    public static String createUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }

}
