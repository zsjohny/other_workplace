package com.goldplusgold.td.user.common.constant;

/**
 * Created by Administrator on 2017/5/12.
 */
public class Constant {

    /**
     * 登录失败次数限制
     */
    public static final Integer DEFAULT_FAIL_LOGIN_TIMES = 5;

    /**
     * 验证码失效时间（单位：分钟）
     */
    public static final Integer CODE_EXPIRED_TIME = 5;
}
