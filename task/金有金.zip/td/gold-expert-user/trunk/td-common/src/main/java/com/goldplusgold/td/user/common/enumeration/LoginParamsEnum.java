package com.goldplusgold.td.user.common.enumeration;

/**
 * 登录时，必须要的相关常量
 */
public enum LoginParamsEnum {

    /**
     * 金专家用户ID
     */
    USERID("id"),

    /**
     * 金专家登录帐号,就是手机号码
     */
    USERNAME("userName"),

    /**
     * 密码
     */
    PASSWORD("password"),

    /**
     * 客户端平台
     */
    PLATFORM("platform"),

    /**
     * 客户端ID
     */
    IMEI("imei"),

    /**
     * 推送ID
     */
    CLIENTID("clientId");

    private String name;

    LoginParamsEnum(String name) {
        this.name = name;
    }

    public String toName() {
        return this.name;
    }
}
