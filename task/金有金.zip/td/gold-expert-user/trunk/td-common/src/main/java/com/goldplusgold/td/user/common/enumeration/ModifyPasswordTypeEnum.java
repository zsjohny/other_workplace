package com.goldplusgold.td.user.common.enumeration;

public enum ModifyPasswordTypeEnum {

    MODIFY_PASSWORD(0),

    FORGET_WITH_MODIFY_PASSWORD(1);

    private Integer value;

    ModifyPasswordTypeEnum(Integer value) {
        this.value = value;
    }

    public Integer toValue() {
        return value;
    }

}
