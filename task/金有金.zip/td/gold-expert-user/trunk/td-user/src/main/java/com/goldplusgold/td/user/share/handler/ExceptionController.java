package com.goldplusgold.td.user.share.handler;


import com.goldplusgold.td.user.exception.AbstractException;
import com.goldplusgold.td.user.exception.message.ResponseError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

/**
 * 异常控制器
 */
@RestController
@ControllerAdvice
public class ExceptionController {

    @ExceptionHandler(AbstractException.class)
    public ResponseError responseError(AbstractException e) {

        ResponseError error = new ResponseError();
        error.setErrorCode(e.getErrorCode());

        StringBuffer msg = new StringBuffer(e.getViewInfo());
        error.setErrorMsg(msg.toString());

        return error;
    }
}
