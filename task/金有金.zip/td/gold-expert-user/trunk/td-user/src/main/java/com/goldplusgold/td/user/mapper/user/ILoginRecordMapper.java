package com.goldplusgold.td.user.mapper.user;

import com.goldplusgold.td.user.entity.user.LoginRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 登录日志
 */
@Mapper
public interface ILoginRecordMapper {

    int saveLoginRecord(LoginRecord loginRecord);

    Integer selectFailedCountOfLogin(String userId);

    Integer updateLoginTypeByUserId(@Param("loginType")Integer loginType, @Param("customerID") String userId);
}
