package com.goldplusgold.td.user.entity.config;


import com.goldplusgold.td.user.entity.BaseModel;

/**
 * 系统配置
 */
public class Config extends BaseModel {
	private static final long serialVersionUID = 1854384304360776525L;

	/**
	 * 配置名称
	 */
    private String configName;

	/**
	 * 配置的值
	 */
    private String configValue;

	/**
	 * 描述
	 */
    private String description;


    public String getConfigName() {
        return configName;
    }

    public void setConfigName(String configName) {
        this.configName = configName == null ? null : configName.trim();
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue == null ? null : configValue.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }
}