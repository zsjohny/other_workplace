package com.goldplusgold.td.user.mapper.sms;


import com.goldplusgold.td.user.entity.sms.MessageTemplate;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 短信模板DAO接口
 */
@Mapper
public interface IMessageTemplateMapper {

    List<MessageTemplate> selectTemplates(MessageTemplate mt);
}