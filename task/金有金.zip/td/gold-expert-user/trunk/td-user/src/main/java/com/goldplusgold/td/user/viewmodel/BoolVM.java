package com.goldplusgold.td.user.viewmodel;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 * 用于相应客户端返回成功(true)或失败(false)
 */
@JsonPropertyOrder(alphabetic = true)
public class BoolVM implements Serializable {

    private static final long serialVersionUID = 8329839614050678378L;

    public BoolVM() {
        this.status = false;
    }
    
    /**
     * 返回客户端状态
     */
    private boolean status;


    /**
     * 返回信息
     */
    private String info;


    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getInfo() {
        return StringUtils.isBlank(info) ? "" : info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
