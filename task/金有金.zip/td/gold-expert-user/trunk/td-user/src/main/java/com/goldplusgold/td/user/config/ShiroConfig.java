package com.goldplusgold.td.user.config;

import com.goldplusgold.td.user.share.auth.*;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authc.credential.PasswordMatcher;
import org.apache.shiro.authc.credential.PasswordService;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.DelegatingFilterProxy;

import javax.servlet.Filter;
import javax.servlet.ServletException;
import java.util.HashMap;
import java.util.Map;

/**
 * 认证与授权相关的配置（shiro）
 */

@Configuration
public class ShiroConfig {

    @Bean
    public FilterRegistrationBean filterRegistrationBean() throws ServletException {
        FilterRegistrationBean filterRegistration = new FilterRegistrationBean();
        DelegatingFilterProxy proxy = new DelegatingFilterProxy("shiroFilter");
        proxy.setTargetFilterLifecycle(true);
        filterRegistration.setFilter(proxy);
        filterRegistration.setEnabled(true);
        filterRegistration.addUrlPatterns("/*");
        return filterRegistration;
    }

    @Bean
    public LifecycleBeanPostProcessor createLifecycleBeanPostProcessor() {
        return new LifecycleBeanPostProcessor();
    }

    private PasswordService createPasswordService() {
        return new UserPasswordService();
    }

    private CredentialsMatcher createCredentialsMatcher() {
        PasswordMatcher matcher = new PasswordMatcher();
        matcher.setPasswordService(createPasswordService());
        return matcher;
    }

    @Bean
    public AuthorizingRealm createUserRealm() {
        AuthorizingRealm realm = new UserRealm();
        realm.setName("TDRealm");
        realm.setCredentialsMatcher(createCredentialsMatcher());
        realm.setCachingEnabled(false);
        realm.setAuthenticationCachingEnabled(false);
        realm.setAuthorizationCachingEnabled(false);
        return realm;
    }

    private DefaultWebSecurityManager createSecurityManager() {
        DefaultWebSecurityManager manager = new DefaultWebSecurityManager();
        manager.setRealm(createUserRealm());
        return manager;
    }

    @Bean(name = "shiroFilter")
    public ShiroFilterFactoryBean createShiroFilter(@Autowired AppAnonFilter appAnonFilter,
                                                    @Autowired AppAuthcFilter appAuthcFilter,
                                                    @Autowired H5AnonFilter h5AnonFilter,
                                                    @Autowired H5AuthcFilter h5AuthcFilter) {

        ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
        bean.setSecurityManager(createSecurityManager());

        Map<String, Filter> filters = new HashMap<>();
        filters.put("appAnon", appAnonFilter);
        filters.put("appAuth", appAuthcFilter);
        filters.put("h5Anon", h5AnonFilter);
        filters.put("h5Auth", h5AuthcFilter);
        bean.setFilters(filters);

        Map<String, String> chains = new HashMap<>();

        //权限在这里添加
        chains.put("/user/login", "appAuth");
        chains.put("/user/register", "appAnon");
        chains.put("/user/logout", "h5Auth");
        chains.put("/user/password_set", "h5Auth");

        bean.setFilterChainDefinitionMap(chains);

        return bean;
    }
}
