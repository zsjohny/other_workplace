package com.goldplusgold.td.user.share.auth;

import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.service.user.CustomerService;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * shiro的认证与授权
 */
public class UserRealm extends AuthorizingRealm {

    @Autowired
    private CustomerService customerService;

    /**
     * 用户授权
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        return null;
    }

    /**
     * 用户认证
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken)
            throws AuthenticationException {

        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        Customer customer = customerService.getByUserName(token.getUsername());
        if (customer == null) throw new UnknownAccountException();
        AuthenticationInfo info = new SimpleAuthenticationInfo(customer.getUserName(),
                customer.getPassword(), this.getName());
        return info;

    }

}
