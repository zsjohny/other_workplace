package com.goldplusgold.td.user.controller.user;

import com.goldplusgold.td.user.common.constant.Constant;
import com.goldplusgold.td.user.common.constant.RedisKeyConstant;
import com.goldplusgold.td.user.common.enumeration.ExpirationTimeEnum;
import com.goldplusgold.td.user.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.user.common.enumeration.LoginRecordTypeEnum;
import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.exception.user.LoginOperateException;
import com.goldplusgold.td.user.parammodel.user.LoginPM;
import com.goldplusgold.td.user.service.user.CustomerService;
import com.goldplusgold.td.user.service.user.LoginRecordService;
import com.goldplusgold.td.user.share.common.utils.IpUtil;
import com.goldplusgold.td.user.share.redis.ICacheService;
import com.goldplusgold.td.user.viewmodel.BoolVM;
import com.goldplusgold.td.user.viewmodel.user.LoginVM;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 金专家子用户系统登录、登出操作
 */
@RestController
@RequestMapping(value = "user")
public class LoginOutController {

    private static final Logger logger = LoggerFactory.getLogger(LoginOutController.class);

    @Autowired
    private ICacheService<String> cacheService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private LoginRecordService loginRecordService;

    /**
     * 登录
     */
    @RequestMapping(value = "login") //TODO 登录需要是post提交，但是注册是重定向时是get请求，所以暂时去掉method
    public LoginVM login(LoginPM pm, HttpServletRequest request) {
        LoginVM vm = new LoginVM();
        Customer customer = null;
        try {
            customer = customerService.getByUserName(pm.getUserName());

            if (customer != null) {
                isAllowLogin(customer.getId());
            }

            Subject subject = SecurityUtils.getSubject();
            UsernamePasswordToken token = new UsernamePasswordToken(pm.getUserName(), pm.getPassword());
            subject.login(token);

            if (subject.isAuthenticated()) {
                updateImeiOrClientId(pm);

                handleCommonAttribute(request, customer, pm);

                //设置移动端互踢标志
                if (StringUtils.isNotEmpty(pm.getImei())) {
                    refreshUniqueLoginKey(pm.getImei(), customer.getId());
                }

                addLoginRecord(customer.getId(), pm, IpUtil.getIp(request), LoginRecordTypeEnum.SUCCESS);

                loadUserInfo(customer, vm);
            }
        } catch (LoginOperateException e){
            logger.error(LoginOperateException.Info.LOGIN_FAILED_MSG.toInfo());
            throw new LoginOperateException(LoginOperateException.Info.LOGIN_FAILED_MSG);
        } catch (UnknownAccountException e) {
            logger.error(LoginOperateException.Info.LOGIN_ACCOUNTS_ERROR.toInfo());
            throw new LoginOperateException(LoginOperateException.Info.LOGIN_ACCOUNTS_ERROR);
        } catch (IncorrectCredentialsException e) {
            addLoginRecord(customer.getId(), pm, IpUtil.getIp(request), LoginRecordTypeEnum.FAILED);
            logger.error(LoginOperateException.Info.LOGIN_PWD_ERROR.toInfo());
            throw new LoginOperateException(LoginOperateException.Info.LOGIN_ACCOUNTS_OR_PWD_ERROR);
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new LoginOperateException(LoginOperateException.Info.LOGIN_ERROR);
        }

        logger.debug("{}: 登录成功", pm.getUserName());

        return vm;
    }

    /**
     * 登出
     */
    @RequestMapping(value = "logout", method = RequestMethod.GET)
    public BoolVM logout() {
        BoolVM boolVM = new BoolVM();

        try {
            //shiro退出会话
            Subject subject = SecurityUtils.getSubject();
            subject.logout();
            boolVM.setStatus(true);
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new LoginOperateException(LoginOperateException.Info.LOGOUT_ERROR);
        }

        return boolVM;
    }

    private void isAllowLogin(String userId) {
        if (loginRecordService.getFailedCountOfLogin(userId) >= Constant.DEFAULT_FAIL_LOGIN_TIMES) {
            throw new LoginOperateException(LoginOperateException.Info.LOGIN_FAILED_MSG);
        }
    }

    private void updateImeiOrClientId(LoginPM pm) throws Exception {

        if (StringUtils.isNotEmpty(pm.getClientId()) || StringUtils.isNotEmpty(pm.getImei())) {
            Customer customer = new Customer();
            customer.setUserName(pm.getUserName());
            customer.setClientId(pm.getClientId());
            customer.setImei(pm.getImei());
            customerService.updateCustomerInfo(customer);
        }
    }

    private void addLoginRecord(String userId, LoginPM pm, String ip, LoginRecordTypeEnum typeEnum) {

        loginRecordService.saveLoginRecord(userId, ip, pm.getImei(), pm.getPlatform(), typeEnum.toValue());

    }

    private void refreshUniqueLoginKey(String imei, String userID) {
        String key = RedisKeyConstant.getMobileUniqueLoginKey(userID);
        cacheService.set(key, imei, ExpirationTimeEnum.MOBILE_EXPIR.toSecond());
    }

    private void loadUserInfo(Customer customer,LoginVM loginVM) throws Exception{

        loginVM.setUserName(customer.getUserName());
        loginVM.setUserId(customer.getId());
        loginVM.setHeadImage(customer.getHeadImage());

    }

    private void handleCommonAttribute(HttpServletRequest request,
                                       Customer customer,
                                       LoginPM pm) {

        request.setAttribute(LoginParamsEnum.USERID.toName(), customer.getId());
        request.setAttribute(LoginParamsEnum.USERNAME.toName(), customer.getUserName());
        request.setAttribute(LoginParamsEnum.PLATFORM.toName(), pm.getPlatform());
        request.setAttribute(LoginParamsEnum.IMEI.toName(), pm.getImei());
        request.setAttribute(LoginParamsEnum.CLIENTID.toName(), pm.getClientId());
    }
}
