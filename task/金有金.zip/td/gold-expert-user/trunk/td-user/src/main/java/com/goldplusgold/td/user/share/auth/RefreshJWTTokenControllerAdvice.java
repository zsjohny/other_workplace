package com.goldplusgold.td.user.share.auth;

import com.goldplusgold.td.user.common.constant.TokenInfo;
import com.goldplusgold.td.user.common.enumeration.ExpirationTimeEnum;
import com.goldplusgold.td.user.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.user.exception.JwtTokenException;
import com.goldplusgold.td.user.share.common.utils.OperationCookie;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * 刷新JWT TOKEN
 */
@Order(1)
@ControllerAdvice(basePackages = "com.goldplusgold.td.user.controller")
public class RefreshJWTTokenControllerAdvice implements ResponseBodyAdvice<Object> {

    private static final Logger logger = LoggerFactory.getLogger(RefreshJWTTokenControllerAdvice.class);

    @Value("${shiro.loginUrl}")
    private String m_loginUrl;

    @Value("${cookie.domain}")
    private String m_domain;

    /**
     * 默认支持所有
     */
    @Override
    public boolean supports(MethodParameter methodParameter,
                            Class<? extends HttpMessageConverter<?>> aClass) {
        return true;
    }

    /**
     * controller返回之前，根据条件刷新jwt token
     */
    @Override
    public Object beforeBodyWrite(Object o,
                                  MethodParameter methodParameter,
                                  MediaType mediaType,
                                  Class<? extends HttpMessageConverter<?>> aClass,
                                  ServerHttpRequest serverHttpRequest,
                                  ServerHttpResponse serverHttpResponse) {

        HttpServletRequest request = ((ServletServerHttpRequest)serverHttpRequest).getServletRequest();
        HttpServletResponse response = ((ServletServerHttpResponse)serverHttpResponse).getServletResponse();
        Object refreshJWTTokenFlagObj = request.getAttribute(TokenInfo.REFRESH_JWT_TOKEN_FLAG_KEY);

        if (refreshJWTTokenFlagObj != null && TokenInfo.REFRESH_JWT_TOKEN_FLAG_VALUE.equals(refreshJWTTokenFlagObj)) {
            if (m_loginUrl.equals(request.getRequestURI())) {
                Subject subject = SecurityUtils.getSubject();
                if (!subject.isAuthenticated()) return o;
            }
            refreshJWTToken(request, response);
        }

        return o;
    }

    /**
     * 刷新JWT TOKEN
     */
    private void refreshJWTToken(HttpServletRequest req,
                                 HttpServletResponse res) {

        String userId = (String)req.getAttribute(LoginParamsEnum.USERID.toName());
        String userName = (String)req.getAttribute(LoginParamsEnum.USERNAME.toName());
        String platform = (String)req.getAttribute(LoginParamsEnum.PLATFORM.toName());
        String imei = (String)req.getAttribute(LoginParamsEnum.IMEI.toName());
        String clientId = (String)req.getAttribute(LoginParamsEnum.CLIENTID.toName());

        try {
            checkArgument(StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(userName) &&
                    StringUtils.isNotEmpty(platform));
        } catch (IllegalArgumentException e) {
            logger.error(JwtTokenException.Info.REFRESH_JWT_PARAM_MISS.toInfo(), e);
            throw new JwtTokenException(JwtTokenException.Info.REFRESH_JWT_PARAM_MISS, e);
        }

        handleTokenToCookie(userId, userName, platform, imei, clientId, res);
        String jwt_token = JwtUtils.createJWT(userId, userName, platform, imei, clientId,
                ExpirationTimeEnum.MOBILE_EXPIR.toMillisecond());
        res.setHeader(TokenInfo.HTTP_RESPONSE_HEADER_TOKEN_NAME, jwt_token);


        //添加debug日志用做调试
        if (logger.isDebugEnabled()) {
            logger.debug("~~~~~~~~~~~~~~~~~~~~ refreshJWTToken() REFRESH JWT TOKEN ~~~~~~~~~~~~~~~~~~~~");
            logger.debug("userId: {}", userId);
            logger.debug("userName: {}", userName);
            logger.debug("platform: {}", platform);
            logger.debug("imei: {}", imei);
            logger.debug("clientId: {}", clientId);
            logger.debug("JWT TOKEN: {}", jwt_token);
            logger.debug("==================== refreshJWTToken() REFRESH JWT TOKEN =====================");
        }

    }

    private String handleTokenToCookie(String userId,
                                       String userName,
                                       String platform,
                                       String imei,
                                       String clientId,
                                       HttpServletResponse res) {

        String jwt_token = JwtUtils.createJWT(userId, userName, platform, imei, clientId,
                ExpirationTimeEnum.MOBILE_EXPIR.toMillisecond());
        Cookie cookie = OperationCookie.getNewCookie(TokenInfo.HTTP_RESPONSE_HEADER_TOKEN_NAME,
                jwt_token,
                ExpirationTimeEnum.MOBILE_EXPIR.toSecond(),
                m_domain);
        res.addCookie(cookie);
        return jwt_token;
    }

}
