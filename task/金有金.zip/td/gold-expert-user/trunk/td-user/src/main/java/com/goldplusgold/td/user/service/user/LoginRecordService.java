package com.goldplusgold.td.user.service.user;

import com.goldplusgold.td.user.common.enumeration.LoginRecordTypeEnum;
import com.goldplusgold.td.user.common.enumeration.PlatformEnum;
import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.entity.user.LoginRecord;
import com.goldplusgold.td.user.mapper.user.ICustomerMapper;
import com.goldplusgold.td.user.mapper.user.ILoginRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Date;

/**
 * 登录日志Service
 */
@Service
public class LoginRecordService {

    @Autowired
    private ILoginRecordMapper loginRecordMapper;
    @Autowired
    private ICustomerMapper customerMapper;

    public Boolean saveLoginRecord(String userId,
                                   String ip,
                                   String imei,
                                   String platform,
                                   Integer loginType) {
        LoginRecord loginRecord = new LoginRecord();

        Date date = new Date();
        loginRecord.setCustomerID(userId);
        if (PlatformEnum.ANDROID.toName().equalsIgnoreCase(platform)) {
            loginRecord.setDeviceType(PlatformEnum.ANDROID.toValue());
        } else if (PlatformEnum.IOS.toName().equalsIgnoreCase(platform)) {
            loginRecord.setDeviceType(PlatformEnum.IOS.toValue());
        }
        loginRecord.setLoginType(loginType);
        loginRecord.setImei(imei);
        loginRecord.setIp(ip);
        loginRecord.setCreateBy("1");
        loginRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
        loginRecord.setUpdateBy("2");
        loginRecord.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        loginRecord.setRemarks("");

        return loginRecordMapper.saveLoginRecord(loginRecord) == 1 ? true : false;
    }

    public Integer getFailedCountOfLogin(String userId) {

        return loginRecordMapper.selectFailedCountOfLogin(userId);
    }

    public Boolean updateLoginType(String userName) {
        Integer count = 0;
        Customer customer = customerMapper.selectByUserName(userName);
        if (customer != null) {
            count = loginRecordMapper.updateLoginTypeByUserId(LoginRecordTypeEnum.SUCCESS.toValue(),customer.getId());
        }
        return count > 0 ? true : false;
    }
}
