package com.goldplusgold.td.user.mapper.user;

import com.goldplusgold.td.user.entity.user.Customer;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户Mapper
 */
@Mapper
public interface ICustomerMapper {

    Customer selectByUserName(String userName);

    int saveCustomer(Customer customer);

    int updateCustomer(Customer customer);

    Customer selectById(String userID);
}
