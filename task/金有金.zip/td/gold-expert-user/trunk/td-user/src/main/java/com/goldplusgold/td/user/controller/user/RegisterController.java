package com.goldplusgold.td.user.controller.user;

import com.goldplusgold.td.user.common.constant.Constant;
import com.goldplusgold.td.user.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.user.common.utils.MD5Util;
import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.exception.user.UserOperateException;
import com.goldplusgold.td.user.parammodel.user.RegisterPM;
import com.goldplusgold.td.user.service.user.CustomerService;
import com.goldplusgold.td.user.service.verifycode.VerifyCodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * 用户注册操作
 */
@Controller
@RequestMapping(value = "user",method = RequestMethod.POST)
public class RegisterController {

    private static final Logger logger = LoggerFactory.getLogger(RegisterController.class);

    @Autowired
    private CustomerService userService;

    @Autowired
    private VerifyCodeService verifyCodeService;

    /**
     * 用户注册
     */
    @RequestMapping(value = "register",method = RequestMethod.POST)
    public String register(HttpServletRequest request, RegisterPM pm, RedirectAttributes attr) {

        try {
            Customer user = userService.getByUserName(pm.getUserName());
            if (user != null)
                throw new UserOperateException(UserOperateException.Info.REGISTER_SMS_USER_EXIST);

            isTimeout(pm.getUserName());
            isCorrect(pm.getUserName(), pm.getCode());

            userService.addCustomer(pm.getUserName(),
                                         MD5Util.md5Pwd(pm.getPassword()),
                                         pm.getImei(),
                                         pm.getPlatform(),
                                         pm.getClientId());

            logger.debug("{} 用户注册成功", pm.getUserName());

        } catch (UserOperateException e) {
            logger.error("UserOperateException: ", e);
            throw e;
        } catch (Exception e) {
            logger.error("Exception: ", e);
            throw new UserOperateException(UserOperateException.Info.USER_OPERATE_ERROR);
        }

        logger.debug("{}: 注册成功", pm.getUserName());


        attr.addAttribute(LoginParamsEnum.CLIENTID.toName(), pm.getClientId());
        attr.addAttribute(LoginParamsEnum.IMEI.toName(), pm.getImei());
        attr.addAttribute(LoginParamsEnum.PLATFORM.toName(), pm.getPlatform());
        attr.addAttribute(LoginParamsEnum.USERNAME.toName(), pm.getUserName());
        attr.addAttribute(LoginParamsEnum.PASSWORD.toName(), pm.getPassword());

        return "redirect:/user/login";
    }

    private void isTimeout(String phone) {
        if (verifyCodeService.verifyCodeExpiredTime(phone, Constant.CODE_EXPIRED_TIME)) {
            throw new UserOperateException(UserOperateException.Info.CODE_TIMEOUT);
        }
    }

    private void isCorrect(String phone, String verifyCode) {
        if (!verifyCodeService.checkCodeIsCorrect(phone, verifyCode)) {
            throw new UserOperateException(UserOperateException.Info.CODE_IS_ERROR);
        }
    }
}
