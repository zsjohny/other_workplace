package com.goldplusgold.td.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 行情应用程序的入口
 */
@SpringBootApplication(scanBasePackages = "com.goldplusgold.td.user")
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
