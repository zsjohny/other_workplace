/**
 * Created by Administrator on 2017/5/12.
 */
(function () {
    var Code=function () {
        this.oldPassword=$(".oldPassword");
        this.comfirmPassword=$(".comfirmPassword");
        this.changeinto=$(".td-changeinto");
        this.changeintoText=$(".td-changeinto-text");
        this.input=$("input");
    };
    Code.prototype={
        init:function () {
            var _this=this;
            this.modifyLogIn();
            this.input.focus(function () {
                _this.changeinto.css('visibility','hidden');
            });
        },
        visibilityTips:function (info) {
            this.changeinto.css('visibility','visible');
            this.changeintoText.text(info);
        },
        validataFunc:function () {
            this.validator=commonJs.validator();
            this.validator.add($(".oldPassword"),[{
                strategy: 'isNonEmpty',
                errorMsg: '请正确输入原密码'
            }, {
                strategy: 'minLength:6',
                errorMsg: '原密码长度不能小于6位'
            }]).add($(".newPassword"),[{
                strategy: 'isNonEmpty',
                errorMsg: '请正确输入新密码'
            }, {
                strategy: 'minLength:6',
                errorMsg: '新密码需要设置为6 - 20位'
            }]).add($(".comfirmPassword"),[{
                strategy: 'isNonEmpty',
                errorMsg: '请正确输入确认密码'
            }, {
                strategy: 'isEqual:.newPassword',
                errorMsg: '请输入正确密码与新密码一致'
            }]);

            var errorMsg=this.validator.start();
            return errorMsg;
        },
        getDataSuccessFn:function(data){
            if(data.hasOwnProperty('errorCode')){
                commonJs.toast(data.errorMsg);
            }else {
                this.visibilityTips(data.info);
                window.history.back();
            }
        },
        requestData:function () {
            commonJs.getAjax('put',api.modifyPassword, this.dataAjax,function (data) {
                this.getDataSuccessFn(data);
            }.bind(this));
        },
        modifyPassword:function () {
            var errorMsg=this.validataFunc();
            var _this=this;
            if(errorMsg){
                this.visibilityTips(errorMsg);
                return false
            }
            this.dataAjax={
                'oldPassword': _this.oldPassword.val(),
                'newPassword': _this.comfirmPassword.val()
            };
            $.showIndicator();
            this.requestData();
        },
        modifyLogIn:function () {
            $(".button").on('click',function(){
                this.modifyPassword();
            }.bind(this));
        },
    };
    new Code().init();
})();