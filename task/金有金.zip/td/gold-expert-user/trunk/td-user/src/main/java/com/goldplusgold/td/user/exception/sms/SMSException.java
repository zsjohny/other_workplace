package com.goldplusgold.td.user.exception.sms;

import com.goldplusgold.td.user.exception.AbstractException;

import javax.validation.constraints.NotNull;

/**
 * 短信模块异常
 */
public class SMSException extends AbstractException {

    private static final long serialVersionUID = 7996171181861062902L;

    public SMSException(@NotNull Info info) {
        super(info.toCode(), info.toInfo(), null, info.toInfo());
    }

    public SMSException(@NotNull Info info,
                        Exception e) {

        super(info.toCode(), info.toInfo(), e, info.toInfo());
    }

    public enum Info {

        SMS_TEMPLATE_ERROR("SMS01", "短信模板缺失"),
        REGISTER_SMS_ERROR("SMS02", "发送注册验证码失败"),
        MODIFY_PASSWORD_SMS_ERROR("SMS03", "发送修改密码验证码失败"),
        SENT_MSG_BY_IP_ERROR("SMS04", "该IP当日获取验证码次数已超最大次数，请切换至运营商网络重试，或明日再试");

        /**
         * 异常编码
         */
        private String code;

        /**
         * 异常信息
         */
        private String info;

        Info(@NotNull String code,
             @NotNull String info) {

            this.code = code;
            this.info = info;
        }

        public String toCode() {
            return this.code;
        }

        public String toInfo() {
            return this.info;
        }
    }
}
