package com.goldplusgold.td.user.entity.sms;

import com.goldplusgold.td.user.entity.BaseModel;


public class MessageRecordLog extends BaseModel {

    private static final long serialVersionUID = -2690417954416760494L;

    /**
     * 电话号码
     */
    private String phone;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 发送类别
     */
    private String sendType;

    /**
     * 客户端IP
     */
    private String ip;

    /**
     *短信发送返回结果
     */
    private String returnCode;

    public MessageRecordLog() {

    }
    public MessageRecordLog(String phone, String content, String sentType, String ip) {
        this.phone = phone;
        this.content = content;
        this.sendType = sentType;
        this.ip = ip;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getSendType() {
        return sendType;
    }

    public void setSendType(String sendType) {
        this.sendType = sendType == null ? null : sendType.trim();
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode == null ? null : returnCode.trim();
    }

}