package com.goldplusgold.td.user.mapper.verifycode;

import com.goldplusgold.td.user.entity.verifycode.VerifyCode;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import javax.validation.constraints.NotNull;

@Mapper
public interface IVerifyCodeMapper {
    
    VerifyCode selectVerifyCodeByPhone(@NotNull String phone);

    int verifyCodeExpriedTime(@NotNull @Param("phone") String phone,
                                  @NotNull @Param("expireTime") Integer expireTime);

    int verifyCodeIsCorrect(VerifyCode verifyCode);

    int saveVerifyCode(VerifyCode verifyCode);

    int updateVerifyCode(VerifyCode verifyCode);
}
