package com.goldplusgold.td.user.controller.user;

import com.goldplusgold.td.user.common.constant.Constant;
import com.goldplusgold.td.user.common.constant.TokenInfo;
import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.exception.AbstractException;
import com.goldplusgold.td.user.exception.user.UserOperateException;
import com.goldplusgold.td.user.parammodel.user.ModifyPasswordPM;
import com.goldplusgold.td.user.parammodel.user.VerifyCodePM;
import com.goldplusgold.td.user.service.user.CustomerService;
import com.goldplusgold.td.user.service.verifycode.VerifyCodeService;
import com.goldplusgold.td.user.share.common.utils.OperationCookie;
import com.goldplusgold.td.user.share.data.IUserContext;
import com.goldplusgold.td.user.viewmodel.BoolVM;
import com.goldplusgold.td.user.viewmodel.user.ModifyPasswordVM;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping(value = "user")
public class ModifyPasswordController {

    private static final Logger logger = LoggerFactory.getLogger(ModifyPasswordController.class);

    @Value("${cookie.domain}")
    private String                      m_jwtCookieDomain;

    @Autowired
    private VerifyCodeService           m_verifyCodeService;

    @Autowired
    private CustomerService             m_userService;

    @Autowired
    private IUserContext m_userContext;

    @RequestMapping(value = "password_set", method = RequestMethod.PUT)
    public ModifyPasswordVM setPassword(ModifyPasswordPM passwordPM,
                                        HttpServletResponse response) {
        ModifyPasswordVM passwordVM = new ModifyPasswordVM();

        try {

           validateOldPassword(passwordPM.getOldPassword());

            m_userService.updateUserPassword(m_userContext.getUserName(), passwordPM.getNewPassword());

//            处理cookie与token过期
            refreshCookieAndToken(response);

            loadUserInfo(m_userContext.getUserName(),passwordVM);

            passwordVM.setStatus(true);
            passwordVM.setInfo("密码修改成功");

        } catch (Exception e) {
            logger.error("modifyPasswordVerifyCode: ", e);
            throw new UserOperateException(UserOperateException.Info.USER_MODIFY_PWD_FAILED);
        }

        return passwordVM;
    }

    @RequestMapping(value = "code_check", method = RequestMethod.GET)
    public BoolVM checkCode(VerifyCodePM verifyCodePM) {
        BoolVM boolVM = new BoolVM();
        try {
            if (checkCodeIsTimeout(verifyCodePM.getPhone())) {
                throw new UserOperateException(UserOperateException.Info.CODE_TIMEOUT);
            }

            if (!checkCodeIsCorrect(verifyCodePM.getPhone(),verifyCodePM.getVerifyCode())) {
                throw new UserOperateException(UserOperateException.Info.CODE_IS_ERROR);
            }
            boolVM.setStatus(true);
        } catch (UserOperateException e) {
            throw e;
        } catch (Exception e) {
            logger.error("checkCodeIsCorrect error :", e);
            throw new UserOperateException(UserOperateException.Info.CODE_IS_ERROR);
        }

        return boolVM;
    }


    public void validateOldPassword(String oldPassword) {

        if (!m_userService.validatePassword(m_userContext.getUserID(), oldPassword)) {
            throw new UserOperateException(UserOperateException.Info.PASSWORD_ERROR);
        }
    }

    private void refreshCookieAndToken(HttpServletResponse response) {

        response.setHeader(TokenInfo.HTTP_HEADER_AUTHORIZATION, null);
        Cookie cookie = OperationCookie.getDelCookie(TokenInfo.HTTP_RESPONSE_HEADER_TOKEN_NAME, m_jwtCookieDomain);
        response.addCookie(cookie);
    }


    private boolean checkCodeIsCorrect(String phone, String verifyCode) {

        return m_verifyCodeService.checkCodeIsCorrect(phone, verifyCode);
    }


    private boolean checkCodeIsTimeout(String phone) {

        return m_verifyCodeService.verifyCodeExpiredTime(phone, Constant.CODE_EXPIRED_TIME);
    }


    private void loadUserInfo(String userName, ModifyPasswordVM passwordVM) throws Exception{

        Customer customer = m_userService.getByUserName(userName);
        if (customer == null) {
            throw  new UserOperateException(UserOperateException.Info.USER_MODIFY_PWD_FAILED);
        }

        passwordVM.setUserName(customer.getUserName());
        passwordVM.setUserId(customer.getId());

    }

}
