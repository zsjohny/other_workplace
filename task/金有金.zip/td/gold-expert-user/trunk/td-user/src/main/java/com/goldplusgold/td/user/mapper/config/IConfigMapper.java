package com.goldplusgold.td.user.mapper.config;

import com.goldplusgold.td.user.entity.config.Config;
import org.apache.ibatis.annotations.Mapper;

/**
 * 配置Config Mapper
 */
@Mapper
public interface IConfigMapper {

    Config selectById(String id);

    Config selectValueByName(String name);
}
