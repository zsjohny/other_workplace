package com.goldplusgold.td.user.mapper.sms;

import com.goldplusgold.td.user.entity.sms.MessageRecordLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 短信日志Mapper
 */
@Mapper
public interface IMessageRecordLogMapper {

    int saveMessageMessageLog(MessageRecordLog message);

    List<MessageRecordLog> selectMessageMessageLogs(MessageRecordLog message);

    Integer selectVerifyCodeIsIntervalTime(@Param("phone") String phone, @Param("intervalTime") int intervalTime);
}
