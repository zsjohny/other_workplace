package com.goldplusgold.td.user.entity.user;

import com.goldplusgold.td.user.entity.BaseModel;

/**
 * 登录日志实体类
 */
public class LoginRecord extends BaseModel {

    private static final long serialVersionUID = -7794013920900160571L;

    /**
     * 用户id
     */
    private String customerID;

    /**
     * 用户ip
     */
    private String ip;

    /**
     * 手机imei
     */
    private String imei;

    /**
     *  来源
     */
    private Integer deviceType;

    /**
     * 登录类型
     * 0：成功
     * 2：密码错误
     */
    private Integer loginType;

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Integer deviceType) {
        this.deviceType = deviceType;
    }

    public Integer getLoginType() {
        return loginType;
    }

    public void setLoginType(Integer loginType) {
        this.loginType = loginType;
    }
}
