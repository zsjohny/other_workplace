package com.goldplusgold.td.user.config;

import com.goldplusgold.td.user.common.utils.Jackson2ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.util.List;

/**
 * web配置
 */
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {


    @Bean
    public MappingJackson2HttpMessageConverter createMappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter jackson2Converter = new MappingJackson2HttpMessageConverter();
        Jackson2ObjectMapper jackson2 = new Jackson2ObjectMapper();
        jackson2Converter.setObjectMapper(jackson2);
        return jackson2Converter;
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/setup").setViewName("setUp"); //设置
        registry.addViewController("/modify_login_password").setViewName("modifyLogInPassword"); //修改登录密码
    }

    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(createMappingJackson2HttpMessageConverter());
    }
}
