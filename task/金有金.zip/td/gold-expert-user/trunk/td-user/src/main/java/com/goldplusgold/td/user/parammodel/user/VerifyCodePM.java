package com.goldplusgold.td.user.parammodel.user;

import java.io.Serializable;

public class VerifyCodePM implements Serializable{

    private static final long serialVersionUID = 8865775921130138163L;

    private String            verifyCode;

    private String            phone;

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
