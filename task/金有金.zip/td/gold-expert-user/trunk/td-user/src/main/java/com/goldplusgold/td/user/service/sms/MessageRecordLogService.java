package com.goldplusgold.td.user.service.sms;

import com.goldplusgold.td.user.entity.sms.MessageRecordLog;
import com.goldplusgold.td.user.exception.sms.SMSException;
import com.goldplusgold.td.user.exception.user.UserOperateException;
import com.goldplusgold.td.user.mapper.sms.IMessageRecordLogMapper;
import com.goldplusgold.td.user.service.config.ConfigService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 短信日志Service
 */
@Service
public class MessageRecordLogService {

    @Autowired
    private IMessageRecordLogMapper messageRecordLogMapper;

    @Autowired
    private ConfigService configService;

    @Value("${config.limitTimesByPhoneID}")
    private String configPhoneId;

    @Value("${config.limitTimesByIpID}")
    private String configIpId;

    @Value("${config.intervalTimeID}")
    private String intervalTimeID;

    @Transactional
    public Boolean addMessageMessageLog(MessageRecordLog message) {

        return messageRecordLogMapper.saveMessageMessageLog(message) == 1 ? true : false;
    }

    @Transactional(readOnly = true)
    public Integer getSentMessageTimes(String phone, String ip) {

        MessageRecordLog message = new MessageRecordLog();

        message.setPhone(phone);
        message.setIp(ip);

        List<MessageRecordLog> messageList = messageRecordLogMapper.selectMessageMessageLogs(message);

        if (CollectionUtils.isNotEmpty(messageList)) {
            return messageList.size();
        }

        return 0;
    }

    public Boolean isAllowSendMsg(String phone, String ip) {

        // 1分钟内不能连续发送短信
        String intervalTime =  configService.getConfigValueById(intervalTimeID);
        int count = messageRecordLogMapper.selectVerifyCodeIsIntervalTime(phone, Integer.parseInt(intervalTime));
         if (count > 0) {
             throw new UserOperateException(UserOperateException.Info.FREQUENTLY_REQUEST_WARNING);
         }

        Integer sentMsgTimesByPhone = getSentMessageTimes(phone,null);

        // TODO 添加每个用户手机号每天的发送短信记录次数在config表中,IP 限制次数
        String limitTimesByPhone =  configService.getConfigValueById(configPhoneId);

        // 手机号次数限制
        if (StringUtils.isNotBlank(limitTimesByPhone) && sentMsgTimesByPhone >= Integer.parseInt(limitTimesByPhone) - 1) {
            throw new UserOperateException(UserOperateException.Info.SENT_MSG_BY_PHONE_ERROR);
        }

        // TODO 添加每个用户手机号每天的发送短信记录次数在config表中,IP 限制次数
        String limitTimesByIp =  configService.getConfigValueById(configIpId);

        Integer sentMsgTimesByIp = getSentMessageTimes(null,ip);

        // IP次数限制
        if (StringUtils.isNotBlank(limitTimesByIp) && sentMsgTimesByIp >= Integer.parseInt(limitTimesByIp) - 1) {
            throw new SMSException(SMSException.Info.SENT_MSG_BY_IP_ERROR);
        }

        return true;
    }
}
