package com.goldplusgold.td.user.service.sms;

import com.goldplusgold.td.user.common.enumeration.MessageTypeEnum;
import com.goldplusgold.td.user.entity.sms.MessageTemplate;
import com.goldplusgold.td.user.exception.sms.SMSException;
import com.goldplusgold.td.user.mapper.sms.IMessageTemplateMapper;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 短信模板服务实现
 */
@Service
@Transactional
public class SMSTemplateService {

    @Autowired
    private IMessageTemplateMapper messageTemplateMapper;

    @Transactional(readOnly = true)
    public String getMessageTemplateByType(@NotNull MessageTypeEnum messageType){
        MessageTemplate mt = new MessageTemplate();

        mt.setCategory(messageType.toValue().toString());
        List<MessageTemplate> mtList = getTemplates(mt);

        if (CollectionUtils.isEmpty(mtList)) {
            throw new SMSException(SMSException.Info.SMS_TEMPLATE_ERROR);
        }

        return mtList.get(0).getContent().trim();
    }

    public List<MessageTemplate> getTemplates(MessageTemplate mt) {
        return messageTemplateMapper.selectTemplates(mt);
    }
}
