package com.goldplusgold.td.user.service.user;

import com.goldplusgold.td.user.common.enumeration.PlatformEnum;
import com.goldplusgold.td.user.common.utils.MD5Util;
import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.mapper.user.ICustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

/**
 * 用户Service
 */
@Service
public class CustomerService {

    @Autowired
    private ICustomerMapper customerMapper;

    public Customer getByUserName(String userName) {
        return customerMapper.selectByUserName(userName);
    }

    @Transactional
    public Boolean addCustomer(String userName,
                               String password,
                               String imei,
                               String platform,
                               String clientId) {

        Customer customer = new Customer();
        customer.setUserName(userName);
        customer.setPassword(password);
        customer.setHeadImage("");
        customer.setClientId(clientId);
        customer.setImei(imei);
        if (platform.equals(PlatformEnum.ANDROID.toName())) {
            customer.setSource(PlatformEnum.ANDROID.toValue().toString());
        } else {
            customer.setSource(PlatformEnum.IOS.toValue().toString());
        }
        customer.setCreateBy("1");
        customer.setCreateTime(new Timestamp(System.currentTimeMillis()));
        customer.setUpdateBy("2");
        customer.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        customer.setRemarks("");

        return customerMapper.saveCustomer(customer) == 1 ? true : false;
    }

    @Transactional
    public Boolean updateCustomerInfo(Customer customer) {
        return customerMapper.updateCustomer(customer) == 1 ? true : false;
    }

    @Transactional
    public Boolean updateUserPassword(@NotNull String userName, @NotNull String password) {
        Customer customer = new Customer();
        customer.setUserName(userName);
        customer.setPassword(MD5Util.md5Pwd(password));

        return customerMapper.updateCustomer(customer) == 1 ? true : false;
    }

    @Transactional(readOnly = true)
    public Boolean validatePassword(String userID, String password) {
        Customer customer = customerMapper.selectById(userID);

        if (MD5Util.md5Pwd(password).equals(customer.getPassword())) {
            return true;
        }
        return false;
    }
}
