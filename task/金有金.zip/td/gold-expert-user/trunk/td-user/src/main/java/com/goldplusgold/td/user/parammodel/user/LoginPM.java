package com.goldplusgold.td.user.parammodel.user;

/**
 * Created by Administrator on 2017/5/10.
 */
public class LoginPM {

    /**
     * 平台
     */
    private String platform;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 密码
     */
    private String password;

    /**
     * 客户端ID，也就是pushId
     */
    private String clientId;

    /**
     * android,ios的唯一标志
     */
    private String imei;

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }
}
