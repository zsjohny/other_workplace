package com.goldplusgold.td.user.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.castor.CastorMarshaller;

/**
 * Yrzt配置
 */
@Configuration
public class YrztConfig {

    @Bean(name = "castorMarshaller")
    public CastorMarshaller createCastorMarshaller() {
        CastorMarshaller castorMarshaller = new CastorMarshaller();
        castorMarshaller.setMappingLocation(new ClassPathResource("sms/mapping.xml"));
        return castorMarshaller;
    }

}
