package com.goldplusgold.td.user.service.config;

import com.goldplusgold.td.user.entity.config.Config;
import com.goldplusgold.td.user.mapper.config.IConfigMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 配置Config Service
 */
@Service
public class ConfigService {

    @Autowired
    private IConfigMapper configMapper;

    @Transactional(readOnly = true)
    public String getConfigValueById(String id) {
        Config config = configMapper.selectById(id);
        if(config == null){
            return "0";
        }
        return config.getConfigValue() == null ? "0" : config.getConfigValue();
    }

    public String getValueByName(String name) {
        Config config = configMapper.selectValueByName(name);
        return config == null ? null : config.getConfigValue();
    }
}
