/**
 * Created by Administrator on 2017/5/12.
 */
(function () {
    var Code=function () {
    };
    Code.prototype={
        init:function () {
            this._logOUt();
        },
        iosFn: function() {
            var ua = navigator.userAgent.toLowerCase();
            if(ua.match(/iphone|ipod|ipad|iphone os/i) != null) {
                signOutGoldExpertIOS();
            }
        },
        androidFn:function() {
            var ua = navigator.userAgent;
            if(ua.match(/Android/i) != null) {
                android.signOutGoldExpertAndroid();
            }
        },
        _getDataSuccessFn:function(data){
            if(data.hasOwnProperty('errorCode')){
                commonJs.toast(data.errorMsg);
            }else {
                commonJs.toast(data.info);
            }
        },
        _btnDetermine:function () {
          /*  commonJs.getAjax('post',api.loginOut,null,function (data) {
                this._getDataSuccessFn(data);
            }.bind(this));*/
            $.hideIndicator();
            this.iosFn();
            this.androidFn();
        },
        _bombBox:function () {
            $.showIndicator();
            commonJs.confirmBox('<div style="text-align:center">是否退出登录</div>','温馨提示',function(){
                this._btnDetermine();
            }.bind(this));
        },
        _logOUt:function () {
            $(".button").on('click',function(){
                this._bombBox();
            }.bind(this));
        },
    };
    new Code().init();
})();