package com.goldplusgold.td.user.service.sms.yrzt;

import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.InputStream;

/**
 * 云融正通短信xml转java对象的工具
 */
@Component
public class YrztSMSOXMService {

    @Resource(name = "castorMarshaller")
    private Unmarshaller m_unmarshaller;

    public YrztSMSResults smsXmlToBean(InputStream in) throws IOException {
        return (YrztSMSResults)m_unmarshaller.unmarshal(new StreamSource(in));
    }
}
