package com.goldplusgold.td.user.viewmodel.user;


import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonPropertyOrder(alphabetic = true)
public class ModifyPasswordVM implements Serializable{

    private static final long serialVersionUID = -763048118371432943L;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 用户id
     */
    private String userId;

    private Boolean status;

    private String info;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
