package com.goldplusgold.td.user.parammodel.sms;

import java.io.Serializable;

/**
 * 注册短信接口，传入Model
 */
public class RegisterSMSPM implements Serializable {
    
    private static final long serialVersionUID = 2175322670810768680L;
    
    /**
     * 电话号码
     */
    private String            phone;
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }

//    @Override
    public void validate() {
//        if (StringUtils.isBlank(phone)) {
//            throw new PMValidateException(PMValidateException.Info.PARAM_MODEL_VALIDATE_ERROR);
//        }
//
//        if (!ValidateNumberUtils.isPhone(phone)) {
//            throw new PMValidateException(PMValidateException.Info.PHONE_IS_ERROR);
//        }
        
    }
}
