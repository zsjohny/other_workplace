package com.goldplusgold.td.user.service.verifycode;

import com.goldplusgold.td.user.entity.verifycode.VerifyCode;
import com.goldplusgold.td.user.mapper.verifycode.IVerifyCodeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 验证码Service
 */
@Service
public class VerifyCodeService {

    @Autowired
    private IVerifyCodeMapper verifyCodeMapper;

    @Transactional(readOnly = true)
    public Boolean verifyCodeExpiredTime(String phone, Integer outOfServiceTime) {

        return verifyCodeMapper.verifyCodeExpriedTime(phone, outOfServiceTime) > 0 ? true : false;
    }

    @Transactional(readOnly = true)
    public Boolean checkCodeIsCorrect(String phone, String code) {

        VerifyCode verifyCode = new VerifyCode();
        verifyCode.setPhone(phone);
        verifyCode.setVerifyCode(code);

        return verifyCodeMapper.verifyCodeIsCorrect(verifyCode) == 1 ? true : false;
    }

    @Transactional
    public Boolean modifyVerifyCodeByPhone(String phone, String code) {
        int isSuccess = 0;

        if (isExist(phone)) {
            isSuccess = verifyCodeMapper.saveVerifyCode(verifyCodeParamSet(phone, code));
        } else {
            isSuccess = verifyCodeMapper.updateVerifyCode(verifyCodeParamSet(phone, code));
        }

        return isSuccess == 1 ? true : false;
    }

    private boolean isExist(String phone) {

        return verifyCodeMapper.selectVerifyCodeByPhone(phone) == null ? true : false;
    }

    private VerifyCode verifyCodeParamSet(String phone, String code) {

        VerifyCode verifyCode = new VerifyCode();
        verifyCode.setCreateBy("system");
        verifyCode.setUpdateBy("system");
        verifyCode.setDelFlag("0");
        verifyCode.setPhone(phone);
        verifyCode.setVerifyCode(code);
        verifyCode.setRemarks("");

        return verifyCode;
    }
}
