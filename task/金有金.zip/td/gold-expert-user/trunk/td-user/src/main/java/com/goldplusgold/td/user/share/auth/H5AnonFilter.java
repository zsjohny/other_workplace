package com.goldplusgold.td.user.share.auth;

import com.goldplusgold.td.user.common.constant.TokenInfo;
import com.goldplusgold.td.user.share.data.IUserContext;
import com.goldplusgold.td.user.share.data.UserContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.web.filter.authc.AnonymousFilter;
import org.apache.shiro.web.util.WebUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * shiro拦截器(针对app加载h5后,h5发起的请求，处理匿名的情况，可能是登录过的，也可能是未登录过）
 */
@Component
public class H5AnonFilter extends AnonymousFilter {

    @Autowired
    private IUserContext userContext;

    @Value("${cookie.domain}")
    private String m_domain;

    @Override
    protected boolean onPreHandle(ServletRequest request,
                                  ServletResponse response,
                                  Object mappedValue) {

        final HttpServletRequest req = WebUtils.toHttp(request);
        String jwtToken = JwtUtils.getJWTTokenFromCookie(req);
        if (StringUtils.isNotEmpty(jwtToken)) {
            JwtUtils.verifyJWT(jwtToken, req);
            request.setAttribute(TokenInfo.REFRESH_JWT_TOKEN_FLAG_KEY, TokenInfo.REFRESH_JWT_TOKEN_FLAG_VALUE);
            UserContextUtils.set(req, userContext);
        }

        return super.onPreHandle(request, response, mappedValue);
    }
}
