package com.goldplusgold.td.user.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.stereotype.Component;

/**
 * Servlet容器配置
 */
@Component
public class EmbeddedServletContainerConfig implements EmbeddedServletContainerCustomizer {

    @Value("${servlet.container.port}")
    private Integer port;
    @Value("${servlet.container.timeout}")
    private Integer timeout;

    @Override
    public void customize(ConfigurableEmbeddedServletContainer container) {
        container.setPort(port);
        container.setSessionTimeout(timeout);
    }
}
