package com.goldplusgold.td.user.entity.sms;

import com.goldplusgold.td.user.entity.BaseModel;


/**
 * 短信模板实现类
 */
public class MessageTemplate extends BaseModel {

    private static final long serialVersionUID = 6425902742007073003L;

    /**
     * 模板名称
     */
    private String name;

    /**
     * 模板类别
     * <p>
     * 0 手机注册
     * 1 修改密码
     */
    private String category;

    /**
     * 模板启用状态
     * <p>
     * 0 启用
     * 1 不启用
     */
    private String applyStatus;

    /**
     * 模板内容
     */
    private String content;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getApplyStatus() {
        return applyStatus;
    }

    public void setApplyStatus(String applyStatus) {
        this.applyStatus = applyStatus;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}