package com.goldplusgold.td.user.viewmodel.user;


import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 * 登录时，用于返回的显示对象
 */
public class LoginVM implements Serializable {

    private static final long serialVersionUID = 6912623365759107128L;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 用户id
     */
    private String userId;

    /**
     * 头像
     */
    private String headImage;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getHeadImage() {
        return StringUtils.isBlank(headImage) ? "" : headImage;
    }

    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }
}
