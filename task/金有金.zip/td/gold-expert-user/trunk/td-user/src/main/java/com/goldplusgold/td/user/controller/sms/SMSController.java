package com.goldplusgold.td.user.controller.sms;

import com.goldplusgold.td.user.common.constant.YrztSMSCode;
import com.goldplusgold.td.user.common.enumeration.MessageTypeEnum;
import com.goldplusgold.td.user.entity.sms.MessageRecordLog;
import com.goldplusgold.td.user.entity.sms.MessageTemplate;
import com.goldplusgold.td.user.entity.user.Customer;
import com.goldplusgold.td.user.exception.sms.SMSException;
import com.goldplusgold.td.user.exception.user.UserOperateException;
import com.goldplusgold.td.user.parammodel.sms.RegisterSMSPM;
import com.goldplusgold.td.user.service.sms.MessageRecordLogService;
import com.goldplusgold.td.user.service.sms.SMSTemplateService;
import com.goldplusgold.td.user.service.sms.yrzt.ISmsService;
import com.goldplusgold.td.user.service.user.CustomerService;
import com.goldplusgold.td.user.service.verifycode.VerifyCodeService;
import com.goldplusgold.td.user.share.common.utils.IpUtil;
import com.goldplusgold.td.user.share.data.IUserContext;
import com.goldplusgold.td.user.viewmodel.BoolVM;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * 短信服务
 */
@RestController
@RequestMapping(value = "sms")
public class SMSController {
    
    private static final Logger logger = LoggerFactory.getLogger(SMSController.class);
    @Autowired
    ISmsService<Map<String, String>> smsService;
    @Autowired
    private CustomerService          customerService;
    @Autowired
    private SMSTemplateService       smsTemplateServiceService;
    @Autowired
    private MessageRecordLogService  messageRecordLogService;
    @Autowired
    private VerifyCodeService        verifyCodeService;
    @Autowired
    private IUserContext             userContext;
                                            
    /**
     * 注册用短信服务
     *
     * @param sms
     * @return
     */
    @RequestMapping(value = "register", method = RequestMethod.GET)
    public BoolVM createRegisterCode(RegisterSMSPM sms, HttpServletRequest request) {
        
        BoolVM boolVM = new BoolVM();
        boolVM.setStatus(false);
        
        try {
            Customer user = customerService.getByUserName(sms.getPhone());
            if (user != null)
                throw new UserOperateException(UserOperateException.Info.REGISTER_SMS_USER_EXIST);

            messageRecordLogService.isAllowSendMsg(sms.getPhone(),
                                                     IpUtil.getIp(request));

            String code = getRandomCode();
            boolean isSuccess = isSendMessageSuccess(sms.getPhone(),
                                                     MessageTypeEnum.REGISTER,
                                                     code,
                                                     IpUtil.getIp(request));
            if (isSuccess) {
                verifyCodeService.modifyVerifyCodeByPhone(sms.getPhone(),
                                                            code);
            }
            boolVM.setStatus(isSuccess);
                                                  
        } catch (UserOperateException e){
            logger.error("USER_EXIST error: ", e);
            throw e;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(SMSException.Info.REGISTER_SMS_ERROR.toInfo());
            throw new SMSException(SMSException.Info.REGISTER_SMS_ERROR);
        }
        
        return boolVM;
    }


    @RequestMapping(value = "forget_password", method = RequestMethod.GET)
    public BoolVM forgetPassword(RegisterSMSPM sms, HttpServletRequest request) {
        BoolVM boolVM = new BoolVM();

        try {

            Customer user = customerService.getByUserName(sms.getPhone());

            if (user == null)
                throw new UserOperateException(UserOperateException.Info.USER_NONEXISTENCE);

            messageRecordLogService.isAllowSendMsg(sms.getPhone(),
                    IpUtil.getIp(request));

            String code = getRandomCode();
            boolean isSuccess = isSendMessageSuccess(sms.getPhone(),
                    MessageTypeEnum.MODIFY_PASSWORD,
                    code,
                    IpUtil.getIp(request));
            if (isSuccess) {
                verifyCodeService.modifyVerifyCodeByPhone(sms.getPhone(),
                        code);
            }

            boolVM.setStatus(isSuccess);

        }catch (UserOperateException e){
            logger.error("USER_NONEXISTENCE error: ", e);
            throw e;

        }catch (Exception e) {
            logger.error("forgetPassword: ", e);
            throw new SMSException(SMSException.Info.MODIFY_PASSWORD_SMS_ERROR);
        }

        return boolVM;
    }
    
    private String getSmsInfo(String smsCode,
                              MessageTypeEnum type) throws Exception {
                              
        MessageTemplate mt = new MessageTemplate();
        
        mt.setCategory(type.toValue().toString());
        List<MessageTemplate> mtList = smsTemplateServiceService.getTemplates(mt);
        
        checkArgument(mtList != null && mtList.size() > 0);
        
        String message = String.format(mtList.get(0).getContent().trim(),
                                       smsCode);
                                       
        logger.debug(message);
        return message;
    }
    
    private boolean isSendMessageSuccess(String phone,
                                         MessageTypeEnum type,
                                         String code,
                                         String ip) throws Exception {
        String content = getSmsInfo(code, type);
        Map<String, String> result = smsService.sendMessage(phone, content);
        checkNotNull(result);
        
        boolean status = Integer.valueOf(result.get(YrztSMSCode.RESULT_CODE)).intValue() == 0 ? true : false;

        MessageRecordLog message = new MessageRecordLog(phone, content, type.toValue().toString(),
                                          ip);
        message.setReturnCode(status == true ? "0": "1");
        messageRecordLogService.addMessageMessageLog(message);

        return status;
    }
    
    // 生成随机短信码
    private String getRandomCode() {
        
        Random random = new Random();
        return String.valueOf(random.nextInt(9000) + 1000);
        
    }
    
}
