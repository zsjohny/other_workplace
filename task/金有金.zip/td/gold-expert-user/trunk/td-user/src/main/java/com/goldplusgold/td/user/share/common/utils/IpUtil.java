package com.goldplusgold.td.user.share.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IpUtil {

    private static final Logger logger = LoggerFactory.getLogger(IpUtil.class);
    private static final String IP_REG = "^(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|[1-9])\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|[0-9])$";
    private static final String LOCALHOST_ADDRESS = "0:0:0:0:0:0:0:1";
    private static final String LOCALHOST_IP = "127.0.0.1";
    private static final String SEPERATOR = ",";

    public static String getIp(HttpServletRequest request) {
        String ip = "";
        try {
            ip = IpUtil.getIpAddress(request);
        } catch (Exception e) {
            logger.error("", "获取IP异常");
        }

        return ip;
    }

    public static boolean isValidIP(String ip) {
        if (StringUtils.isBlank(ip)) {
            return false;
        } else {
            Pattern patt = Pattern.compile(IP_REG);
            Matcher mat = patt.matcher(ip);
            return mat.matches();
        }
    }

    public static String filterDuplicatedIP(String ipList) {
        String[] ipArray = ipList.split("\\,");
        Set<String> ipSet = new LinkedHashSet<String>();
        for (int i = 0; i < ipArray.length; i++) {
            ipSet.add(ipArray[i]);
        }

        return StringUtils.join(ipSet, ",");
    }

    public static boolean isInIpArray(String ip, String[] ipArray) {
        for (int i = 0; i < ipArray.length; i++) {
            if (ip.equalsIgnoreCase(ipArray[i].trim())) {
                return true;
            }
        }

        return false;
    }

    public static String getIpAddress(HttpServletRequest request) throws Exception {
        String ipArray = request.getHeader("x-forwarded-for");

        String ip = getFirstIp(ipArray);

        if (isInvalidIP(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }

        if (isInvalidIP(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }

        if (isInvalidIP(ip)) {
            ip = request.getRemoteAddr();
        }

        ip = convertLocalhostFromV6toV4(ip);

        if (!ip.matches(IP_REG)) {
            throw new Exception("Ip格式不合法: " + ip);
        }

        return ip;
    }

    private static String convertLocalhostFromV6toV4(String ip) {
        if (LOCALHOST_ADDRESS.equals(ip)) {
            return LOCALHOST_IP;
        } else {
            return ip;
        }
    }

    private static boolean isInvalidIP(String ip) {
        return ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip);
    }

    private static String getFirstIp(String ip) {
        if (StringUtils.isNotBlank(ip)) {
            String[] ipArray = ip.split(SEPERATOR);

            if (ipArray.length > 1) {
                ip = ipArray[0].trim();
            }
        }

        return ip;
    }
}
