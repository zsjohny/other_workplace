package com.goldplusgold.td.user.controller.user;

import com.goldplusgold.td.user.common.constant.Constant;
import com.goldplusgold.td.user.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.user.exception.user.UserOperateException;
import com.goldplusgold.td.user.parammodel.user.ForgetPasswordPM;
import com.goldplusgold.td.user.service.user.CustomerService;
import com.goldplusgold.td.user.service.user.LoginRecordService;
import com.goldplusgold.td.user.service.verifycode.VerifyCodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping(value = "user")
public class ForgetPasswordController {

    private static final Logger logger = LoggerFactory.getLogger(ForgetPasswordController.class);

    @Autowired
    private VerifyCodeService m_verifyCodeService;

    @Autowired
    private CustomerService m_userService;

    @Autowired
    private LoginRecordService m_customerLoginRecordService;

    @RequestMapping(value = "password",method = RequestMethod.POST)
    public String modifyPassword(ForgetPasswordPM passwordPM, RedirectAttributes attr) {
        try {
            if (checkCodeIsTimeout(passwordPM.getPhone())) {
                throw new UserOperateException(UserOperateException.Info.CODE_TIMEOUT);
            }

            if (!checkCodeIsCorrect(passwordPM.getPhone(),passwordPM.getCode())) {
                throw new UserOperateException(UserOperateException.Info.CODE_IS_ERROR);
            }

            m_userService.updateUserPassword(passwordPM.getPhone(), passwordPM.getNewPassword());

            logger.debug("{} 用户密码修改成功", passwordPM.getPhone());

            m_customerLoginRecordService.updateLoginType(passwordPM.getPhone());

        } catch (Exception e) {
            logger.error("modifyPasswordVerifyCode: ", e);
            throw new UserOperateException(UserOperateException.Info.USER_MODIFY_PWD_FAILED);
        }

        attr.addAttribute(LoginParamsEnum.CLIENTID.toName(), passwordPM.getClientId());
        attr.addAttribute(LoginParamsEnum.IMEI.toName(), passwordPM.getImei());
        attr.addAttribute(LoginParamsEnum.PLATFORM.toName(), passwordPM.getPlatform());
        attr.addAttribute(LoginParamsEnum.USERNAME.toName(), passwordPM.getPhone());
        attr.addAttribute(LoginParamsEnum.PASSWORD.toName(), passwordPM.getNewPassword());

        return "redirect:/user/login";
    }

    private boolean checkCodeIsTimeout(String phone) {

        return m_verifyCodeService.verifyCodeExpiredTime(phone, Constant.CODE_EXPIRED_TIME);
    }

    private boolean checkCodeIsCorrect(String phone, String verifyCode) {

        return m_verifyCodeService.checkCodeIsCorrect(phone, verifyCode);
    }
}
