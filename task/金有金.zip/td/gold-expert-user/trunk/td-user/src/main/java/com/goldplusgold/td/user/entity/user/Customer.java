package com.goldplusgold.td.user.entity.user;

import com.goldplusgold.td.user.entity.BaseModel;

/**
 * 金专家用户实体类
 */
public class Customer extends BaseModel {

    /**
     * 用户名，手机号
     */
    private String userName;

    /**
     * 用户密码
     */
    private String password;

    /**
     * 昵称
     */
    private String nickname;

    /**
     * 头像
     */
    private String headImage;

    /**
     * 客户端ID，也就是pushId
     */
    private String clientId;

    /**
     * android,ios的唯一标志
     */
    private String imei;

    /**
     * 注册来源
     */
    private String source;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getHeadImage() {
        return headImage;
    }

    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
