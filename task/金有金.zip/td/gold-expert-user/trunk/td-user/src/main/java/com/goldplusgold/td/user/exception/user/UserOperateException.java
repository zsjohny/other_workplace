package com.goldplusgold.td.user.exception.user;

import com.goldplusgold.td.user.exception.AbstractException;

import javax.validation.constraints.NotNull;

/**
 * 与用户操作相关异常
 */
public class UserOperateException extends AbstractException {

    private static final long serialVersionUID = -2298926739642912686L;

    public UserOperateException(@NotNull Info info) {
        super(info.toCode(), info.toInfo(), null, info.toInfo());
    }

    public UserOperateException(@NotNull Info info,
                                Exception e) {

        super(info.toCode(), info.toInfo(), e, info.toInfo());
    }

    public enum Info {

        USER_REGISTER_ERROR("UO01", "注册失败"),
        USER_OPERATE_ERROR("UO09", "操作失败"),
        REGISTER_SMS_USER_EXIST("RO01", "该手机号已经被使用"),
        USER_NONEXISTENCE("RO02", "该手机号未注册"),
        USER_MODIFY_PWD_FAILED("MO02", "密码修改失败"),
        CODE_TIMEOUT("MO03", "验证码失效"),
        CODE_IS_ERROR("MO04", "验证码错误"),
        NUMBER_FORMAT_ERROR("NO01","数字格式化错误"),
        INVITATION_ERROR("IN01","无效的邀请码"),
        SURNAME_ERROR("SO01","身份信息不符"),
        IDENTITY_NUMBER("SO02","请输入正确的身份证号码"),
        IDENTITY_BE_USED("SO03","该身份证号被使用"),
        IDENTITY_AUTHENTICATION_TIMES("SO04","1天内认证次数不能超过3次"),
        IDENTITY_AUTHENTICATION_FAILED("SO05","实名认证失败"),
        PASSWORD_ERROR("PO01","密码错误"),
        PASSWORD_IS_ERROR("PO07","密码格式错误"),
        SENT_MSG_BY_PHONE_ERROR("PO09", "该手机号当日获取验证码次数已超最大次数，请明日再试"),
        FREQUENTLY_REQUEST_WARNING ("PO11","请不要频繁获取验证码");

        /**
         * 异常编码
         */
        private String code;

        /**
         * 异常信息
         */
        private String info;

        Info(@NotNull String code,
             @NotNull String info) {

            this.code = code;
            this.info = info;
        }

        public String toCode() {
            return this.code;
        }

        public String toInfo() {
            return this.info;
        }
    }
}
