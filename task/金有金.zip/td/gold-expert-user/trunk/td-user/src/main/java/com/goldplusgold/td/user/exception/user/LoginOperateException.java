package com.goldplusgold.td.user.exception.user;

import com.goldplusgold.td.user.exception.AbstractException;

import javax.validation.constraints.NotNull;

/**
 * 登录或登出操作异常
 */
public class LoginOperateException extends AbstractException {

    private static final long serialVersionUID = 3740986673690687517L;

    public LoginOperateException(@NotNull Info info) {
        super(info.toCode(), info.toInfo(), null, info.toInfo());
    }

    public LoginOperateException(@NotNull Info info,
                                 Exception e) {

        super(info.toCode(), info.toInfo(), e, info.toInfo());
    }

    public enum Info {

        LOGIN_ACCOUNTS_OR_PWD_ERROR("Login01", "登录帐户或密码不正确"),
        LOGIN_ERROR("Login02", "登录异常"),
        LOGIN_ACCOUNTS_ERROR("Login03", "当前登录帐号不正确"),
        LOGIN_PWD_ERROR("Login04", "当前登录密码不正确"),
        LOGOUT_ERROR("Login02", "退出异常"),
        LOGIN_FAILED_MSG("Login06", "您的输错次数已超过最大次数5次，账户将被冻结30分钟。");
        /**
         * 异常编码
         */
        private String code;
        /**
         * 异常信息
         */
        private String info;

        Info(@NotNull String code,
             @NotNull String info) {

            this.code = code;
            this.info = info;
        }

        public String toCode() {
            return this.code;
        }

        public String toInfo() {
            return this.info;
        }
    }
}
