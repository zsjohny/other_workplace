package com.goldplusgold.td.user.service.sms.yrzt;

import com.goldplusgold.td.user.common.constant.YrztSMSCode;
import com.goldplusgold.td.user.entity.sms.MessageRecordLog;
import com.goldplusgold.td.user.service.sms.MessageRecordLogService;
import com.google.common.io.CharStreams;
import org.apache.http.Consts;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.validation.constraints.NotNull;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 云融正通短信服务
 */
@Component
public class YrztSMSServiceImpl implements ISmsService<Map<String, String>> {

    private static final String YRZT_PATH = "http://101.201.238.246/MessageTransferWebAppJs/servlet/messageTransferServiceServletByXml";
    private static final String USERNAME = "hjbhy";
    private static final String PASSWORD = "888888";
    private static final Logger logger = LoggerFactory.getLogger(YrztSMSServiceImpl.class);

    @Autowired
    private YrztSMSOXMService m_oxmService;
    private CloseableHttpClient m_httpclient;
    private RequestConfig m_requestConfig;

    @Autowired
    private MessageRecordLogService messageRecordLogService;

    @PostConstruct
    public void init() {
        m_requestConfig = RequestConfig
                .custom()
                .setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        m_httpclient = HttpClients
                .custom()
                .setRetryHandler(new DefaultHttpRequestRetryHandler())
                .build();
    }

    @PreDestroy
    public void destroy() {
        try {
            m_httpclient.close();
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("CloseableHttpClient close error: {}", e.getMessage());
        }
    }

    /**
     * 发送一条短信
     *
     * @param phone
     * @param msg
     * @return
     */
    @Override
    public Map<String, String> sendMessage(@NotNull String phone,
                                           @NotNull String msg) {

        Map<String, String> results = null;

        HttpPost httpPost = new HttpPost(YRZT_PATH);
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(getYrztSmsParams(phone, msg), Consts.UTF_8);
        httpPost.setEntity(entity);
        httpPost.setConfig(m_requestConfig);

        try (CloseableHttpResponse httpResponse = m_httpclient.execute(httpPost);
             InputStream in = httpResponse.getEntity().getContent()) {

            String xml = CharStreams.toString(new InputStreamReader(in)).trim();
            logger.debug(xml);

            YrztSMSResults sms = m_oxmService.smsXmlToBean(new ByteArrayInputStream(xml.getBytes()));

            logger.debug("resultCode: {}", sms.getResults().get(YrztSMSCode.RESULT_CODE));
            logger.debug("errorCode: {}", sms.getResults().get(YrztSMSCode.ERROR_CODE));

            results = sms.getResults();

        } catch (IOException e) {
            e.printStackTrace();
            logger.error("sendMessage() error: {}", e.getMessage());
        }
        return results;
    }

    /**
     * 组织请求参数
     */
    private List<NameValuePair> getYrztSmsParams(@NotNull String phone,
                                                 @NotNull String msg) {

        List<NameValuePair> params = new ArrayList<>();

        params.add(new BasicNameValuePair("cmd", "sendMessage"));
        params.add(new BasicNameValuePair("userName", USERNAME));
        params.add(new BasicNameValuePair("passWord", PASSWORD));
        params.add(new BasicNameValuePair("contentType", "sms/mt"));
        params.add(new BasicNameValuePair("mobilePhone", phone));
        params.add(new BasicNameValuePair("body", msg));

        return params;
    }

    @Transactional
    @Override
    public Boolean sendMessageWithLogInsert(MessageRecordLog message) throws Exception {

        Map<String, String> map = sendMessage(message.getPhone(), message.getContent());

        if ("0".equals(map.get(YrztSMSCode.RESULT_CODE))) {
            message.setReturnCode("0");
            messageRecordLogService.addMessageMessageLog(message);
            return true;
        }
        message.setReturnCode("1");
        message.setRemarks(map.get(YrztSMSCode.RESULT_CODE));
        messageRecordLogService.addMessageMessageLog(message);

        return false;
    }
}
