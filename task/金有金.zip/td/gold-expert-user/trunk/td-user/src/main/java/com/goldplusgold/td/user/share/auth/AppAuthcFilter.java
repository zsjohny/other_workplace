package com.goldplusgold.td.user.share.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.goldplusgold.td.user.common.constant.RedisKeyConstant;
import com.goldplusgold.td.user.common.constant.TokenInfo;
import com.goldplusgold.td.user.common.enumeration.ExpirationTimeEnum;
import com.goldplusgold.td.user.common.enumeration.LoginParamsEnum;
import com.goldplusgold.td.user.common.enumeration.PlatformEnum;
import com.goldplusgold.td.user.exception.JwtTokenException;
import com.goldplusgold.td.user.exception.message.ResponseError;
import com.goldplusgold.td.user.share.data.IUserContext;
import com.goldplusgold.td.user.share.data.UserContextUtils;
import com.goldplusgold.td.user.share.redis.ICacheService;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.web.filter.authc.UserFilter;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * shiro拦截器(对app原生界面传过来的token进行处理,token与金有金方案一样)
 */
@Component
public class AppAuthcFilter extends UserFilter {

    private static final Logger logger = LoggerFactory.getLogger(AppAuthcFilter.class);

    @Autowired
    private IUserContext userContext;

    @Autowired
    private ICacheService<String> cacheService;

    @Value("${shiro.loginUrl}")
    private String m_loginUrl;

    @Autowired
    private MappingJackson2HttpMessageConverter jackson2Converter;

    /**
     * 表示是否允许访问,如果返回 true 表示需要继续处理；如果返回 false表示该拦截器实例已经处理了，将直接返回即可；
     * 我们在这里验证jwt token是否有效，是否过期等
     * <p>
     * 从http header的authentication中取出Bearer Token信息，这里存储的就是jwt。
     */
    @Override
    protected boolean isAccessAllowed(ServletRequest request,
                                      ServletResponse response,
                                      Object mappedValue) {

        if (m_loginUrl.equals(WebUtils.toHttp(request).getRequestURI())) {

            request.setAttribute(TokenInfo.REFRESH_JWT_TOKEN_FLAG_KEY, TokenInfo.REFRESH_JWT_TOKEN_FLAG_VALUE);
            return true;

        }

        boolean flag = false;
        String jwtToken = null;

        try {
            final HttpServletRequest req = WebUtils.toHttp(request);

            jwtToken = JwtUtils.getJWTTokenFromHeader(req);

            checkArgument(StringUtils.isNotEmpty(jwtToken));
            JwtUtils.verifyJWT(jwtToken, req);
            //验证token是否过期
            Long expir = (Long) req.getAttribute(TokenInfo.EXPIRATION);
            if (expir < new Date().getTime()) {
                throw new JwtTokenException(JwtTokenException.Info.TOKEN_EXPIRATION);
            }

            //移动端互踢
            String platform = (String) req.getAttribute(LoginParamsEnum.PLATFORM.toName());
            if (PlatformEnum.IOS.toName().equals(platform) || PlatformEnum.ANDROID.toName().equals(platform)) {
                String imei = (String) req.getAttribute(LoginParamsEnum.IMEI.toName());
                String userID = (String) req.getAttribute(LoginParamsEnum.USERID.toName());
                boolean mobileUniqueFlag = confirmUniqueLogin(imei, userID);
                if (!mobileUniqueFlag) {
                    throw new JwtTokenException(JwtTokenException.Info.MOBILE_UNIQUE_LOGIN_ERROR);
                }
                refreshUniqueLoginKey(imei, userID);
            }

            request.setAttribute(TokenInfo.REFRESH_JWT_TOKEN_FLAG_KEY, TokenInfo.REFRESH_JWT_TOKEN_FLAG_VALUE);
            UserContextUtils.set(req, userContext);

            flag = true;
        } catch (IllegalArgumentException e) {
            logger.error(JwtTokenException.Info.REQUEST_GET_JWT_ERROR.toInfo(), e);
            ResponseError error = createResponseError(JwtTokenException.Info.REQUEST_GET_JWT_ERROR.toCode(),
                    JwtTokenException.Info.REQUEST_GET_JWT_ERROR.toInfo());
            request.setAttribute("error", error);
        } catch (JwtTokenException e) {
            logger.error(e.getErrorMsg());
            ResponseError error = createResponseError(e.getErrorCode(), e.getViewInfo());
            request.setAttribute("error", error);
        } catch (Exception e) {
            logger.error(JwtTokenException.Info.ACCESS_ERROR.toInfo(), e);
            ResponseError error = createResponseError(JwtTokenException.Info.REQUEST_GET_JWT_ERROR.toCode(),
                    JwtTokenException.Info.REQUEST_GET_JWT_ERROR.toInfo());
            request.setAttribute("error", error);
        }
        PrintJwtDebugLog.printDebugLog(request, flag, jwtToken);

        return flag;
    }


    @Override
    protected boolean onAccessDenied(ServletRequest request,
                                     ServletResponse response) throws Exception {

        HttpServletRequest req = WebUtils.toHttp(request);
        ResponseError error = (ResponseError) req.getAttribute("error");
        writeErrorInfoToResponse(WebUtils.toHttp(response), error);
        return false;
    }


    private ResponseError createResponseError(String errorCode,
                                              String errorMsg) {

        ResponseError error = new ResponseError();
        error.setErrorCode(errorCode);
        error.setErrorMsg(errorMsg);
        return error;
    }


    private void writeErrorInfoToResponse(HttpServletResponse response,
                                          ResponseError error) throws JsonProcessingException {

        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        String errorJson = jackson2Converter.getObjectMapper().writeValueAsString(error);
        try (PrintWriter out = response.getWriter()) {
            out.write(errorJson);
            out.flush();
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    private boolean confirmUniqueLogin(String imei, String userID) {
        boolean b = false;
        String key = RedisKeyConstant.getMobileUniqueLoginKey(userID);
        String value = cacheService.get(key);
        if (StringUtils.isEmpty(value) || imei.equals(value)) {
            b = true;
        }
        return b;
    }

    private void refreshUniqueLoginKey(String imei, String userID) {
        String key = RedisKeyConstant.getMobileUniqueLoginKey(userID);
        cacheService.set(key, imei, ExpirationTimeEnum.MOBILE_EXPIR.toSecond());
    }
}
