package com.goldplusgold.td.user.parammodel.user;

import java.io.Serializable;

/**
 * 注册时，传入参数Model
 */
public class RegisterPM implements Serializable {

    private static final long serialVersionUID = -7556182040182841388L;

    /**
     * 平台
     */
    private String platform;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 密码
     */
    private String password;

    /**
     * 客户端ID，也就是pushId
     */
    private String clientId;

    /**
     * android,ios的唯一标志
     */
    private String imei;

    /**
     * 短信验证码
     */
    private String code;

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
