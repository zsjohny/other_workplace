package com.goldplusgold.td.user.share.auth;

import com.goldplusgold.td.user.common.utils.MD5Util;
import org.apache.shiro.authc.credential.PasswordService;
import org.apache.shiro.util.ByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.constraints.NotNull;
import java.nio.charset.StandardCharsets;

/**
 * shiro密码服务，目前还是使用已经在使用的Md5Utils来实现（已经在使用中，暂时也改变不了）
 */
public class UserPasswordService implements PasswordService {

    private static final Logger logger = LoggerFactory.getLogger(UserPasswordService.class);

    /**
     * 加密
     */
    @Override
    public String encryptPassword(@NotNull Object plaintext) throws IllegalArgumentException {

        String pwd = MD5Util.md5Pwd(plaintext.toString());
        logger.debug("encryptPassword(): {}", pwd);

        return pwd;
    }

    /**
     * 密码匹配
     */
    @Override
    public boolean passwordsMatch(@NotNull Object submittedPlaintext,
                                  @NotNull String saved) {

        ByteSource plaintextBytes = ByteSource.Util.bytes(submittedPlaintext);
        String plainText = new String(plaintextBytes.getBytes(), StandardCharsets.UTF_8);
        boolean flag = encryptPassword(plainText).equals(saved);
        logger.debug("passwordsMatch(): {}", flag);

        return flag;
    }
}
