package com.goldplusgold.td.user.entity;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.Date;

/**
 * Model基类，通用属性都在这里
 */@JsonPropertyOrder
public abstract class BaseModel implements Serializable {

    private static final long serialVersionUID = -8450987476492249772L;

    public BaseModel() {
            this.delFlag = "0";
        }

        /**
         * 主键
         */
        private String id;

        /**
         * 创建者，这里只代表客户端
         */
        private String createBy;

        /**
         * 创建时间
         */
        private Date createTime;

        /**
         * 更新者，这里只代表客户端
         */
        private String updateBy;

        /**
         * 更新时间,也作为乐观锁的控制字段
         */
        private Date updateTime;

        /**
         * 备注信息
         */
        private String remarks;

        /**
         * 逻辑删除标记（0：显示；1：隐藏）
         */
        private String delFlag;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreateBy() {
            return createBy;
        }

        public void setCreateBy(String createBy) {
            this.createBy = createBy;
        }

        public String getUpdateBy() {
            return updateBy;
        }

        public void setUpdateBy(String updateBy) {
            this.updateBy = updateBy;
        }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public String getDelFlag() {
            return delFlag;
        }

        public void setDelFlag(String delFlag) {
            this.delFlag = delFlag;
        }

}
