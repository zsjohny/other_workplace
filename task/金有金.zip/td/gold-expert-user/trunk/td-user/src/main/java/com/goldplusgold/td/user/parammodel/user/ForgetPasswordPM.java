package com.goldplusgold.td.user.parammodel.user;

public class ForgetPasswordPM {

    private String            newPassword;

    private String            phone;

    private String            code;

    /**
     * 客户端ID，也就是pushId
     */
    private String clientId;

    /**
     * android,ios的唯一标志
     */
    private String imei;

    /**
     * 平台
     */
    private String platform;


    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }
}
