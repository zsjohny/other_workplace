package com.goldplusgold.td.user.service.sms.yrzt;


import com.goldplusgold.td.user.entity.sms.MessageRecordLog;

/**
 * 短信服务接口
 */
public interface ISmsService<T> {

    /**
     * 发送一条短信
     */
    T sendMessage(String phone, String msg);

    Boolean sendMessageWithLogInsert(MessageRecordLog message)  throws Exception ;

}
