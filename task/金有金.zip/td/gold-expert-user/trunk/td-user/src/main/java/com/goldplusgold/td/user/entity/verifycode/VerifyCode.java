package com.goldplusgold.td.user.entity.verifycode;

import com.goldplusgold.td.user.entity.BaseModel;

/**
 * 验证码实体类
 */
public class VerifyCode extends BaseModel {
    
    private static final long serialVersionUID = 1714530070731339651L;
                                               
    /**
     * 用户手机号
     */
    private String            phone;
                              
    /**
    * 验证码
    */
    private String            verifyCode;
                              
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getVerifyCode() {
        return verifyCode;
    }
    
    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }
    
}