package com.goldplusgold.td.user.share.data;

import com.goldplusgold.td.user.common.enumeration.PlatformEnum;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

/**
 * 上下文所带的用户必要信息实现
 */
@Component
public class UserContextImpl implements IUserContext {

    @Lookup("userContextData")
    public UserContextData getUserContextData() {
        return null;
    }

    @Override
    public String getUserID() {
        return this.getUserContextData().getUserID();
    }

    @Override
    public void setUserID(String hjbUserID) {
        this.getUserContextData().setUserID(hjbUserID);
    }

    @Override
    public PlatformEnum getPlatform() {
        return this.getUserContextData().getPlatform();
    }

    @Override
    public void setPlatform(PlatformEnum platform) {
        this.getUserContextData().setPlatform(platform);
    }

    @Override
    public String getUserName() {
        return this.getUserContextData().getUserName();
    }

    @Override
    public void setUserName(String hjbUserName) {
        this.getUserContextData().setUserName(hjbUserName);
    }

    @Override
    public String getImei() {
        return this.getUserContextData().getImei();
    }

    @Override
    public void setImei(String imei) {
        this.getUserContextData().setImei(imei);
    }

    @Override
    public String getClientID() {
        return this.getUserContextData().getClientID();
    }

    @Override
    public void setClientID(String clientID) {
        this.getUserContextData().setClientID(clientID);
    }

    @Override
    public String getVersion() {
        return this.getUserContextData().getVersion();
    }

    @Override
    public void setVersion(String version) {
        this.getUserContextData().setVersion(version);
    }
}
