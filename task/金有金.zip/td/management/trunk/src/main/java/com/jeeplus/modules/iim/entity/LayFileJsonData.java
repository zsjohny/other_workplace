package com.jeeplus.modules.iim.entity;

public class LayFileJsonData {
	
	private String name;//文件存储的名字
	
	private String src;//文件存储的路径

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getSrc() {
		return src;
	}

}
