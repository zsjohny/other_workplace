package com.jeeplus.common.utils;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.ObjectMetadata;
import com.aliyun.oss.model.PutObjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;

/**
 * This sample demonstrates how to upload/download an object to/from Aliyun OSS
 * using the OSS SDK for Java.
 */
public class OSSUpload {

    private static final Logger logger = LoggerFactory.getLogger(OSSUpload.class);

    private static final String endpoint = "oss-cn-hangzhou.aliyuncs.com";
    private static final String accessKeyId = "rAjd1tJma5Ho9qmi";
    private static final String accessKeySecret = "Q9fqDTylxkd6ACsoYKCb72QJo7s8H6";

    private static final String bucketName = "huangjinbao";
    private static final String base_url = "http://huangjinbao.oss-cn-hangzhou.aliyuncs.com/";

    /**
     * OSS上传文件
     *
     * @param file
     * @return String
     * @author jason
     * @date 2016年4月20日
     */
    public static String uploadFile(File file, String path, String newFileName) {
        StringBuilder key = new StringBuilder("app/");
        OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);
        try {
            String fileName = file.getName();
            String fileSuffix = fileName.substring(fileName.indexOf("."), fileName.length());
            key.append(path).append("/")
                .append(MyDateUtils.convertDateToString(MyDateUtils.getCurrentDate(), MyDateUtils.YYYYMMDDHHMMSSSSS))
                .append("/").append(newFileName).append(fileSuffix);

            client.putObject(new PutObjectRequest(bucketName, key.toString(), file));
        } finally {
            client.shutdown();
        }
        return key.insert(0, base_url).toString();
    }

    /**
     * 通过文件上传图片到OSS服务器
     *
     * @param file 需要上传的文件
     * @param path 上传的路径
     * @return
     */
    public static String uploadObject(MultipartFile file, String path) {
        // 获取期数
        String today = MyDateUtils.convertDateToString(MyDateUtils.getCurrentDate(), MyDateUtils.YYYYMMDD);
        // 例如：newsController中controllerName可以取news
        StringBuilder key = new StringBuilder(bucketName).append(path).append("/").append(today).append("/");
        OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);
        try {
            // 初始化OSSClient
            client.createBucket(bucketName); // bucketName

            // 获取指定文件的输入流
            InputStream content = file.getInputStream();

            // 创建上传Object对象的Metadata
            ObjectMetadata meta = new ObjectMetadata();

            // 必须设置ContentLength
            meta.setContentLength(file.getSize());

            String dateString = MyDateUtils.convertDateToString(MyDateUtils.getCurrentDate(), MyDateUtils.YYYYMMDDHHMMSS);
            String fileName = file.getOriginalFilename();
            String fileFileName = Md5Utils.md5LowerCase(fileName.substring(0, fileName.lastIndexOf(".")))
                    + fileName.substring(fileName.lastIndexOf("."));
            fileFileName = dateString + fileFileName;
            key.append(fileFileName);

            // 上传Object
            client.putObject(bucketName, key.toString(), content, meta);
        } catch (NoSuchAlgorithmException | IOException e) {
            logger.error("uploadFile error : ",e);
            //TODO 没有从金有金引入异常体系, 需要建立我们自己的异常体系
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            client.shutdown();
        }
        return key.insert(0, base_url).toString();
    }
}