/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.modules.tools.web;

import com.jeeplus.common.sms.YrztMessageUtil;
import com.jeeplus.common.web.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 发送短信
 * @author lgf
 * @version 2016-01-07
 */
@Controller
@RequestMapping(value = "${adminPath}/tools/sms")
public class SMSController extends BaseController {

//	@Autowired
//	private SystemConfigService systemConfigService;
	
	/**
	 * 打开短信页面
	 */
	@RequestMapping(value = {"index", ""})
	public String index() {
		return "modules/tools/sendSMS";
	}

	/**
	 * 发送短信
	 */
	@RequestMapping("send")
	public String send(String tels, String content, Model model) throws Exception {
		String result;
		String resultCode = YrztMessageUtil.sendMessage(tels, content + "【金有金】");
		if (!resultCode.equals("0")) {
			result = "短信发送失败，错误代码：" + resultCode + "，请联系管理员。";
		} else {
			result = "短信发送成功";
		}
		model.addAttribute("result", result);
		return "modules/tools/sendSMSResult";
	}

}