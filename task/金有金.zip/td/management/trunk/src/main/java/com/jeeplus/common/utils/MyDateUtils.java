package com.jeeplus.common.utils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MyDateUtils {

    public static final String YYYYMMDD = "yyyyMMdd";
    public static final String HHMMSS = "HHmmss";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String YYYYMMDDHHMM = "yyyyMMddHHmm";
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String YYYYMMDDHHMMSSSSS = "yyyyMMddHHmmssSSS";
    public static final String YYYYMMDD_HH_MM_SS = "yyyyMMdd HH:mm:ss";
    public static final String YYYY1MM1DDHHMMSS_SSS = "yyyy/MM/dd:HH:mm:ss.SSS";
    public static final String YYYY1MM1DDHHMMSSSSSZZ = "yyyy/MM/dd:HH:mm:ss.SSS ZZ";
    public static final String YYYY1MM1DDHHMMSS = "yyyy/MM/dd HH:mm:ss";
    public static final String YYYY_MM_DDHHMMSS = "yyyy-MM-dd HH:mm:ss";

    public static Timestamp getCurrentTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    public static Date getCurrentDate() {
        return new Date();
    }

    public static Date getYesterday(Date date) {
        Calendar cal = Calendar.getInstance();
        if (null != date) {
            cal.setTime(date);
        }
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

    public static Timestamp getIntervalDay(Date date, int day) {
        return getIntervalHours(date, day * 24);
    }

    public static Timestamp getIntervalHours(Date date, int hours) {
        return getIntervalMinutes(date, hours * 60);
    }

    public static Timestamp getIntervalMinutes(Date date, int minutes) {
        return getIntervalSeconds(date, minutes * 60);
    }

    public static Timestamp getIntervalMinutes(int minutes) {
        return getIntervalSeconds(minutes * 60);
    }

    public static Timestamp getIntervalSeconds(int seconds) {
        return getIntervalSeconds(new Date(), seconds);
    }

    public static Timestamp getIntervalSeconds(Date date, int seconds) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.SECOND, seconds);
        return new Timestamp(calendar.getTimeInMillis());
    }

    public static Date convertStringToDate(String date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);

        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
            throw new RuntimeException("日期转换异常： " + date, e);
        }
    }

    public static String convertDateToString(Date date, String format) {
        return new SimpleDateFormat(format).format(date);
    }

    public static String convertTimestampToString(Timestamp timestamp, String format) {
        return convertDateToString(timestamp, format);
    }

    public static Timestamp convertStringToTimestamp(String date, String format) {
        return new Timestamp(convertStringToDate(date, format).getTime());
    }

    public static String getIntervalDate(Date date, String format, int days) {
        return getIntervalMinute(date, format, days * 24 * 60L);
    }

    public static String getIntervalMinute(Date date, String format, long minutes) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        Date expectedDate = new Date(date.getTime() + minutes * 60 * 1000);
        return dateFormat.format(expectedDate);
    }

    public static Date getStartTimeOfSpecifiedDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static Date getInterestDateTime(Date day, String hhMMss) {
        String dayString = convertDateToString(day, MyDateUtils.YYYYMMDD);
        String interestDate = dayString + hhMMss;
        return convertStringToDate(interestDate, MyDateUtils.YYYYMMDDHHMMSS);
    }
}
