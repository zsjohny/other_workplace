package com.jeeplus.modules.business.entity.bannerimage;

import com.jeeplus.common.persistence.DataEntity;
import com.jeeplus.common.utils.excel.annotation.ExcelField;
import org.hibernate.validator.constraints.Length;

/**
 * banner图片管理Entity
 *
 * @author 白鲁宁
 * @version 2016-04-06
 */
public class Banner extends DataEntity<Banner> {

    private static final long serialVersionUID = 1L;
    private String name;                 // 图片名
    private String imgUrl;               // 图片的地址
    private String useTo;                // 使用对象（0-pc、1-app）
    private String imgType;              // 图片类型 0-banner，1-活动图，2-其他
    private String description;          // 描述说明
    private String clickCount;           // 点击量
    private String linkUrl;              // 图片的链接地址
    private String carouselType;              // 轮播类型
    private String linkUrlType;          //链接地址类型

    public Banner() {
        super();
    }

    public Banner(String id) {
        super(id);
    }

    @Length(min = 1, max = 64, message = "图片名长度必须介于 1 和 64 之间")
    @ExcelField(title = "图片名", align = 2, sort = 1)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Length(min = 0, max = 255, message = "图片的地址长度必须介于 0 和 255 之间")
    @ExcelField(title = "图片的地址", align = 2, sort = 2)
    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    @Length(min = 0, max = 1, message = "使用对象（0-pc、1-app）长度必须介于 0 和 1 之间")
    @ExcelField(title = "使用对象（0-pc、1-app）", dictType = "use_to", align = 2, sort = 3)
    public String getUseTo() {
        return useTo;
    }

    public void setUseTo(String useTo) {
        this.useTo = useTo;
    }

    @Length(min = 0, max = 1, message = "图片类型 0-banner，1-活动图，2-其他长度必须介于 0 和 1 之间")
    @ExcelField(title = "图片类型 0-banner，1-活动图，2-其他", dictType = "img_type", align = 2, sort = 4)
    public String getImgType() {
        return imgType;
    }

    public void setImgType(String imgType) {
        this.imgType = imgType;
    }

    @Length(min = 0, max = 255, message = "描述说明长度必须介于 0 和 255 之间")
    @ExcelField(title = "描述说明", align = 2, sort = 5)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Length(min = 0, max = 11, message = "点击量长度必须介于 0 和 11 之间")
    @ExcelField(title = "点击量", align = 2, sort = 6)
    public String getClickCount() {
        return clickCount;
    }

    public void setClickCount(String clickCount) {
        this.clickCount = clickCount;
    }

    @Length(min = 0, max = 255, message = "图片的链接地址长度必须介于 0 和 255 之间")
    @ExcelField(title = "图片的链接地址", align = 2, sort = 7)
    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getCarouselType() {
        return carouselType;
    }

    public void setCarouselType(String carouselType) {
        this.carouselType = carouselType;
    }

    public void setLinkUrlType(String linkUrlType) {
        this.linkUrlType = linkUrlType;
    }

    public String getLinkUrlType() {
        return linkUrlType;
    }
}