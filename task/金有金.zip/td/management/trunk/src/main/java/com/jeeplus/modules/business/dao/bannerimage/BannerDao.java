package com.jeeplus.modules.business.dao.bannerimage;

import com.jeeplus.common.persistence.CrudDao;
import com.jeeplus.common.persistence.annotation.MyBatisDao;
import com.jeeplus.modules.business.entity.bannerimage.Banner;

/**
 * banner图片管理DAO接口
 *
 * @author 白鲁宁
 * @version 2016-04-06
 */
@MyBatisDao
public interface BannerDao extends CrudDao<Banner> {

}