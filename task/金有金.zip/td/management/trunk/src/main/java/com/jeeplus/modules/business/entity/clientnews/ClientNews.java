package com.jeeplus.modules.business.entity.clientnews;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jeeplus.common.persistence.DataEntity;
import com.jeeplus.common.utils.excel.annotation.ExcelField;
import org.hibernate.validator.constraints.Length;

import java.util.Date;

/**
 * 媒体新闻Entity
 *
 * @author luocx
 * @version 2016-04-18
 */
public class ClientNews extends DataEntity<ClientNews> {

    private static final long serialVersionUID = 1L;
    private String newsTitle;            // 标题
    private String content;              // 内容
    private String summary;              // 简介
    private String newsType;             // 类型
    private String clickCount;           // 点击量
    private String important;            // 权重
    private Date deliveryTime;         // 发布时间
    private String newsUrl;              // 图片地址
    private String newsFrom;             // 新闻来源
    private String fromLogo;             // 来源logo
    private String fromUrl;              // 来源地址
    private String isEnable;             // 状态
    private String thumbnail;            // 缩络图
    private String isHot;                // 是否是热点 0-不是热点，1-热点
    private String isNominate;           // 是否推荐 0-不推荐，1-推荐
    private Date beginDeliveryTime;    // 开始 发布时间
    private Date endDeliveryTime;      // 结束 发布时间
    private Integer resourceId;           // 标题

    public ClientNews() {
        super();
    }

    public ClientNews(String id) {
        super(id);
    }

    @Length(min = 1, max = 64, message = "标题长度必须介于 1 和 64 之间")
    @ExcelField(title = "标题", align = 2, sort = 1)
    public String getNewsTitle() {
        return newsTitle;
    }

    public void setNewsTitle(String newsTitle) {
        this.newsTitle = newsTitle;
    }

    @ExcelField(title = "内容", align = 2, sort = 2)
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @ExcelField(title = "类型", dictType = "news_type", align = 2, sort = 3)
    public String getNewsType() {
        return newsType;
    }

    public void setNewsType(String newsType) {
        this.newsType = newsType;
    }

    @ExcelField(title = "点击量", align = 2, sort = 4)
    public String getClickCount() {
        return clickCount;
    }

    public void setClickCount(String clickCount) {
        this.clickCount = clickCount;
    }

    @Length(min = 1, max = 64, message = "权重长度必须介于 1 和 64 之间")
    @ExcelField(title = "权重", align = 2, sort = 5)
    public String getImportant() {
        return important;
    }

    public void setImportant(String important) {
        this.important = important;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelField(title = "发布时间", align = 2, sort = 6)
    public Date getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(Date deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    @ExcelField(title = "图片地址", align = 2, sort = 7)
    public String getNewsUrl() {
        return newsUrl;
    }

    public void setNewsUrl(String newsUrl) {
        this.newsUrl = newsUrl;
    }

    @ExcelField(title = "新闻来源", align = 2, sort = 8)
    public String getNewsFrom() {
        return newsFrom;
    }

    public void setNewsFrom(String newsFrom) {
        this.newsFrom = newsFrom;
    }

    @ExcelField(title = "来源logo", align = 2, sort = 9)
    public String getFromLogo() {
        return fromLogo;
    }

    public void setFromLogo(String fromLogo) {
        this.fromLogo = fromLogo;
    }

    @ExcelField(title = "来源地址", align = 2, sort = 10)
    public String getFromUrl() {
        return fromUrl;
    }

    public void setFromUrl(String fromUrl) {
        this.fromUrl = fromUrl;
    }

    @Length(min = 1, max = 1, message = "状态长度必须介于 1 和 1 之间")
    @ExcelField(title = "状态", dictType = "is_release", align = 2, sort = 11)
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    public Date getBeginDeliveryTime() {
        return beginDeliveryTime;
    }

    public void setBeginDeliveryTime(Date beginDeliveryTime) {
        this.beginDeliveryTime = beginDeliveryTime;
    }

    public Date getEndDeliveryTime() {
        return endDeliveryTime;
    }

    public void setEndDeliveryTime(Date endDeliveryTime) {
        this.endDeliveryTime = endDeliveryTime;
    }

    @Length(min = 1, max = 225, message = "简介必须介于 1 和 225之间")
    @ExcelField(title = "简介", align = 2, sort = 10)
    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getIsHot() {
        return isHot;
    }

    public void setIsHot(String isHot) {
        this.isHot = isHot;
    }

    public String getIsNominate() {
        return isNominate;
    }

    public void setIsNominate(String isNominate) {
        this.isNominate = isNominate;
    }

    public Integer getResourceId() {
        return resourceId;
    }

    public void setResourceId(Integer resourceId) {
        this.resourceId = resourceId;
    }

}