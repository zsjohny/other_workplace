package com.jeeplus.common.sms;

import java.util.Map;

/**
 * 云融正通短信服务返回的结果对象
 */
public class YrztMessageResults {

    private Map<String, String> results;

    public Map<String, String> getResults() {
        return results;
    }

    public void setResults(Map<String, String> results) {
        this.results = results;
    }
}
