package com.jeeplus.modules.business.web.bannerimage;

import com.google.common.collect.Lists;
import com.jeeplus.common.config.Global;
import com.jeeplus.common.persistence.Page;
import com.jeeplus.common.utils.DateUtils;
import com.jeeplus.common.utils.MyBeanUtils;
import com.jeeplus.common.utils.OSSUpload;
import com.jeeplus.common.utils.StringUtils;
import com.jeeplus.common.utils.excel.ExportExcel;
import com.jeeplus.common.utils.excel.ImportExcel;
import com.jeeplus.common.web.BaseController;
import com.jeeplus.modules.business.entity.bannerimage.Banner;
import com.jeeplus.modules.business.service.bannerimage.BannerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * banner图片管理Controller
 *
 * @author 白鲁宁
 * @version 2016-04-06
 */
@Controller
@RequestMapping(value = "${adminPath}/business/bannerimage/banner")
public class BannerController extends BaseController {

    @Autowired
    private BannerService bannerService;

    @ModelAttribute
    public Banner get(@RequestParam(required = false) String id) {
        Banner entity = null;
        if (StringUtils.isNotBlank(id)) {
            entity = bannerService.get(id);
        }
        if (entity == null) {
            entity = new Banner();
        }
        return entity;
    }

    /**
     * banner图片管理列表页面
     */
    @RequestMapping(value = {"list", ""})
    public String list(Banner banner, HttpServletRequest request, HttpServletResponse response, Model model) {
        Page<Banner> page = bannerService.findPage(new Page<Banner>(request, response), banner);
        model.addAttribute("page", page);
        return "modules/business/bannerimage/bannerList";
    }

    /**
     * 查看，增加，编辑banner图片管理表单页面
     */
    @RequestMapping(value = "form")
    public String form(Banner banner, Model model) {
        model.addAttribute("banner", banner);
        return "modules/business/bannerimage/bannerForm";
    }

    /**
     * 保存banner图片管理
     */
    @RequestMapping(value = "save")
    public String save(Banner banner, Model model, @RequestParam("file") MultipartFile[] file, RedirectAttributes redirectAttributes) throws Exception {
        if (!beanValidator(model, banner)) {
            return form(banner, model);
        }
        if (null != file && file.length > 0 && file[0].getSize() > 0) {
            banner.setImgUrl(OSSUpload.uploadObject(file[0], "/bannerimage"));
            addMessage(redirectAttributes, String.format("%s图片保存成功", file[0].getName()));
            if (file.length > 1 && file[1].getSize() > 0) {//Banner落地页为图片
                banner.setLinkUrl(OSSUpload.uploadObject(file[1], "/bannerimage"));
                addMessage(redirectAttributes, String.format("%s图片保存成功", file[1].getName()));
            }
        } else {
            addMessage(redirectAttributes, "图片不存在，保存失败");
            return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
        }
        if (!banner.getIsNewRecord()) {// 编辑表单保存
            Banner t = bannerService.get(banner.getId());// 从数据库取出记录的值
            MyBeanUtils.copyBeanNotNull2Bean(banner, t);// 将编辑表单中的非NULL值覆盖数据库记录中的值
            bannerService.save(t);// 保存
        } else {// 新增表单保存
            bannerService.save(banner);// 保存
        }
        return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
    }

    /**
     * 删除banner图片管理
     */
    @RequestMapping(value = "delete")
    public String delete(Banner banner, RedirectAttributes redirectAttributes) {
        bannerService.delete(banner);
        addMessage(redirectAttributes, "删除banner图片管理成功");
        return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
    }

    /**
     * 批量删除banner图片管理
     */
    @RequestMapping(value = "deleteAll")
    public String deleteAll(String ids, RedirectAttributes redirectAttributes) {
        String idArray[] = ids.split(",");
        for (String id : idArray) {
            bannerService.delete(bannerService.get(id));
        }
        addMessage(redirectAttributes, "删除banner图片管理成功");
        return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
    }

    /**
     * 导出excel文件
     */
    @RequestMapping(value = "export", method = RequestMethod.POST)
    public String exportFile(Banner banner, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            String fileName = "banner图片管理" + DateUtils.getDate("yyyyMMddHHmmss") + ".xlsx";
            Page<Banner> page = bannerService.findPage(new Page<Banner>(request, response, -1), banner);
            new ExportExcel("banner图片管理", Banner.class).setDataList(page.getList()).write(response, fileName).dispose();
            return null;
        } catch (Exception e) {
            addMessage(redirectAttributes, "导出banner图片管理记录失败！失败信息：" + e.getMessage());
        }
        return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
    }

    /**
     * 导入Excel数据
     */
    @RequestMapping(value = "import", method = RequestMethod.POST)
    public String importFile(MultipartFile file, RedirectAttributes redirectAttributes) {
        try {
            int successNum = 0;
            ImportExcel ei = new ImportExcel(file, 1, 0);
            List<Banner> list = ei.getDataList(Banner.class);
            for (Banner banner : list) {
                bannerService.save(banner);
            }
            addMessage(redirectAttributes, "已成功导入 " + successNum + " 条banner图片管理记录");
        } catch (Exception e) {
            addMessage(redirectAttributes, "导入banner图片管理失败！失败信息：" + e.getMessage());
        }
        return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
    }

    /**
     * 下载导入banner图片管理数据模板
     */
    @RequestMapping(value = "import/template")
    public String importFileTemplate(HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            String fileName = "banner图片管理数据导入模板.xlsx";
            List<Banner> list = Lists.newArrayList();
            new ExportExcel("banner图片管理数据", Banner.class, 1).setDataList(list).write(response, fileName).dispose();
            return null;
        } catch (Exception e) {
            addMessage(redirectAttributes, "导入模板下载失败！失败信息：" + e.getMessage());
        }
        return "redirect:" + Global.getAdminPath() + "/business/bannerimage/banner/?repage";
    }

}