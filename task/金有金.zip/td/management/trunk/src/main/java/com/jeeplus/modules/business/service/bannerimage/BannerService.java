package com.jeeplus.modules.business.service.bannerimage;

import com.jeeplus.common.persistence.Page;
import com.jeeplus.common.service.CrudService;
import com.jeeplus.modules.business.dao.bannerimage.BannerDao;
import com.jeeplus.modules.business.entity.bannerimage.Banner;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * banner图片管理Service
 *
 * @author 白鲁宁
 * @version 2016-04-06
 */
@Service
@Transactional(readOnly = true)
public class BannerService extends CrudService<BannerDao, Banner> {

    public Banner get(String id) {
        return super.get(id);
    }

    public List<Banner> findList(Banner banner) {
        return super.findList(banner);
    }

    public Page<Banner> findPage(Page<Banner> page, Banner banner) {
        return super.findPage(page, banner);
    }

    @Transactional(readOnly = false)
    public void save(Banner banner) {
        super.save(banner);
    }

    @Transactional(readOnly = false)
    public void delete(Banner banner) {
        super.delete(banner);
    }

}