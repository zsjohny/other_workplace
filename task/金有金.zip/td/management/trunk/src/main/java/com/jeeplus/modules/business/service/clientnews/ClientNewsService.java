package com.jeeplus.modules.business.service.clientnews;

import com.jeeplus.common.persistence.Page;
import com.jeeplus.common.service.CrudService;
import com.jeeplus.modules.business.dao.clientnews.ClientNewsDao;
import com.jeeplus.modules.business.entity.clientnews.ClientNews;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 媒体新闻Service
 *
 * @author luocx
 * @version 2016-04-18
 */
@Service
@Transactional(readOnly = true)
public class ClientNewsService extends CrudService<ClientNewsDao, ClientNews> {
    @Autowired
    private ClientNewsDao clientNewsDao;

    public ClientNews get(String id) {
        return super.get(id);
    }

    public List<ClientNews> findList(ClientNews clientNews) {
        return super.findList(clientNews);
    }

    public Page<ClientNews> findPage(Page<ClientNews> page, ClientNews clientNews) {
        return super.findPage(page, clientNews);
    }

    @Transactional(readOnly = false)
    public void save(ClientNews clientNews) {
        super.save(clientNews);
    }

    @Transactional(readOnly = false)
    public void delete(ClientNews clientNews) {
        super.delete(clientNews);
    }

    public int getCount(ClientNews clientNews) {
        return clientNewsDao.getCount(clientNews);
    }

    public int getMaxiId() {
        return clientNewsDao.getMaxiId();
    }

}