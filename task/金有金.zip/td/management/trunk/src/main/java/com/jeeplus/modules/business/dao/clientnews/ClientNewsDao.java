package com.jeeplus.modules.business.dao.clientnews;

import com.jeeplus.common.persistence.CrudDao;
import com.jeeplus.common.persistence.annotation.MyBatisDao;
import com.jeeplus.modules.business.entity.clientnews.ClientNews;

/**
 * 媒体新闻DAO接口
 *
 * @author luocx
 * @version 2016-04-18
 */
@MyBatisDao
public interface ClientNewsDao extends CrudDao<ClientNews> {
    public int getCount(ClientNews entity);

    public int getMaxiId();
}