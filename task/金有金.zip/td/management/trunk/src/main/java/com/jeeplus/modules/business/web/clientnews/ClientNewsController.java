package com.jeeplus.modules.business.web.clientnews;

import com.google.common.collect.Lists;
import com.jeeplus.common.config.Global;
import com.jeeplus.common.persistence.Page;
import com.jeeplus.common.utils.DateUtils;
import com.jeeplus.common.utils.MyBeanUtils;
import com.jeeplus.common.utils.OSSUpload;
import com.jeeplus.common.utils.StringUtils;
import com.jeeplus.common.utils.excel.ExportExcel;
import com.jeeplus.common.utils.excel.ImportExcel;
import com.jeeplus.common.web.BaseController;
import com.jeeplus.modules.business.entity.clientnews.ClientNews;
import com.jeeplus.modules.business.service.clientnews.ClientNewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 媒体新闻Controller
 *
 * @author luocx
 * @version 2016-04-18
 */
@Controller
@RequestMapping(value = "${adminPath}/business/clientnews/clientNews")
public class ClientNewsController extends BaseController {

    @Autowired
    private ClientNewsService clientNewsService;

    @ModelAttribute
    public ClientNews get(@RequestParam(required = false) String id) {
        ClientNews entity = null;
        if (StringUtils.isNotBlank(id)) {
            entity = clientNewsService.get(id);
        }
        if (entity == null) {
            entity = new ClientNews();
        }
        return entity;
    }

    /*
     * 写媒体新闻
     */
    @RequestMapping(value = {"sendNews"})
    public String sendNews(HttpServletRequest request, HttpServletResponse response, Model model) {

        // //查询总条数
        // ClientNews clientNews1 = new ClientNews();
        // clientNews1.setDelFlag("0");
        // model.addAttribute("newsBoxCount",
        // clientNewsService.getCount(clientNews1));

        // 查询已发布的
        ClientNews clientNews2 = new ClientNews();
        clientNews2.setDelFlag("0");
        clientNews2.setIsEnable("0");// 启用的
        model.addAttribute("newsComposeCount", clientNewsService.getCount(clientNews2));

        // 查询草稿箱条数
        ClientNews clientNews3 = new ClientNews();
        clientNews3.setIsEnable("1");// 草稿 未启用的
        model.addAttribute("newsDraftCount", clientNewsService.getCount(clientNews3));

        return "modules/business/clientnews/clientNewsSend";
    }

    /**
     * 媒体新闻列表页面
     */
    @RequestMapping(value = {"list", ""})
    public String list(ClientNews clientNews, HttpServletRequest request, HttpServletResponse response, Model model) {
        clientNews.setFromLogo("http");
        Page<ClientNews> page = clientNewsService.findPage(new Page<ClientNews>(request, response), clientNews);
        model.addAttribute("page", page);
        // 查询已发布的
        ClientNews clientNews2 = new ClientNews();
        clientNews2.setFromLogo("http");
        clientNews2.setDelFlag("0");
        clientNews2.setIsEnable("0");// 启用的
        model.addAttribute("newsComposeCount", clientNewsService.getCount(clientNews2));

        // 查询草稿箱条数
        ClientNews clientNews3 = new ClientNews();
        clientNews3.setFromLogo("http");
        clientNews3.setIsEnable("1");// 草稿 未启用的
        model.addAttribute("newsDraftCount", clientNewsService.getCount(clientNews3));
        return "modules/business/clientnews/clientNewsList";
    }

    /**
     * 查看，增加，编辑媒体新闻表单页面
     */
    @RequestMapping(value = "form")
    public String form(ClientNews clientNews, Model model) {
        model.addAttribute("clientNews", clientNews);
        return "modules/business/clientnews/clientNewsDraftDetail";
    }

    /**
     * 保存媒体新闻
     */
    @RequestMapping(value = "save")
    public String save(ClientNews clientNews, @RequestParam("file") MultipartFile[] file, Model model, RedirectAttributes redirectAttributes) throws Exception {
        if (!beanValidator(model, clientNews)) {
            return form(clientNews, model);
        }
        if (file[0].getSize() > 0) {
            String fromLogo = OSSUpload.uploadObject(file[0], "/clientNews");
            clientNews.setFromLogo(fromLogo);
        }
        if (file[1].getSize() > 0) {
            String thumbnail = OSSUpload.uploadObject(file[1], "/clientNews");
            clientNews.setThumbnail(thumbnail);
        }
        if (file[2].getSize() > 0) {
            String image = OSSUpload.uploadObject(file[2], "/clientNews");
            clientNews.setNewsUrl(image);
        }
        if (!clientNews.getIsNewRecord()) {// 编辑表单保存
            ClientNews t = clientNewsService.get(clientNews.getId());// 从数据库取出记录的值
            MyBeanUtils.copyBeanNotNull2Bean(clientNews, t);// 将编辑表单中的非NULL值覆盖数据库记录中的值
            clientNews.setClickCount("0");
            clientNewsService.save(t);// 保存
        } else {// 新增表单保存
            // 若为发布状态
            if (clientNews.getIsEnable().equals("0")) {
                // 保存发布时间
                clientNews.setDeliveryTime(DateUtils.getNewDate());
            }
            // ClientNews tt = clientNewsService.get(clientNews.getId());
            // String thumbnail = "";
            // String image = "";fromLogo
            if (file[0].getSize() > 0) {
                String fromLogo = OSSUpload.uploadObject(file[0], "/clientNews");
                clientNews.setFromLogo(fromLogo);
            } else {
                clientNews.setFromLogo("http://huangjinbao.oss-cn-hangzhou.aliyuncs.com/hjbsys/images/headImage.png");
            }
            if (file[1].getSize() > 0) {
                String thumbnail = OSSUpload.uploadObject(file[1], "/clientNews");
                clientNews.setThumbnail(thumbnail);
            } else {
                clientNews.setThumbnail("http://huangjinbao.oss-cn-hangzhou.aliyuncs.com/hjbsys/images/userHead.jpg");
            }
            if (file[2].getSize() > 0) {
                String image = OSSUpload.uploadObject(file[2], "/clientNews");
                clientNews.setNewsUrl(image);
            } else {
                clientNews.setNewsUrl("");
            }
            clientNews.setClickCount("0");
            // 查询resourseId 最大值 并加1 附在最新值中
            int resourceId = clientNewsService.getMaxiId();
            clientNews.setResourceId(resourceId + 1);
            clientNewsService.save(clientNews);// 保存
        }
        addMessage(redirectAttributes, "保存媒体新闻成功");
        return "redirect:" + Global.getAdminPath() + "/business/clientnews/clientNews/?repage";
    }

    /**
     * @param clientNews
     * @param model
     * @return
     * @author 白鲁宁 查看媒体新闻详情
     */
    @RequestMapping(value = "detail")
    public String detail(ClientNews clientNews, Model model) {
        // 查询对应ID新闻详情
        clientNews = clientNewsService.get(clientNews);
        model.addAttribute("clientNews", clientNews);

        // 查询已发布的
        ClientNews clientNews2 = new ClientNews();
        clientNews2.setDelFlag("0");
        clientNews2.setIsEnable("0");// 启用的
        model.addAttribute("newsComposeCount", clientNewsService.getCount(clientNews2));

        // 查询草稿箱条数
        ClientNews clientNews3 = new ClientNews();
        clientNews3.setIsEnable("1");// 草稿 未启用的
        model.addAttribute("newsDraftCount", clientNewsService.getCount(clientNews3));

        if (clientNews.getIsEnable() == null || clientNews.getIsEnable().equals("1")) {
            return "modules/business/clientnews/clientNewsDraftDetail";// 草稿箱
        }
        return "modules/business/clientnews/clientNewsDetail";
    }

    /**
     * 删除媒体新闻
     */
    @RequestMapping(value = "delete")
    public String delete(ClientNews clientNews, RedirectAttributes redirectAttributes) {
        clientNewsService.delete(clientNews);
        addMessage(redirectAttributes, "删除媒体新闻成功");
        return "redirect:" + Global.getAdminPath() + "/business/clientnews/clientNews/?repage";
    }

    /**
     * 批量删除媒体新闻
     */
    @RequestMapping(value = "deleteAll")
    public String deleteAll(String ids, RedirectAttributes redirectAttributes) {
        String idArray[] = ids.split(",");
        for (String id : idArray) {
            clientNewsService.delete(clientNewsService.get(id));
        }
        addMessage(redirectAttributes, "删除媒体新闻成功");
        return "redirect:" + Global.getAdminPath() + "/business/clientnews/clientNews/?repage";
    }

    /**
     * 导出excel文件
     */
    @RequestMapping(value = "export", method = RequestMethod.POST)
    public String exportFile(ClientNews clientNews, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            String fileName = "媒体新闻" + DateUtils.getDate("yyyyMMddHHmmss") + ".xlsx";
            Page<ClientNews> page = clientNewsService.findPage(new Page<ClientNews>(request, response, -1), clientNews);
            new ExportExcel("媒体新闻", ClientNews.class).setDataList(page.getList()).write(response, fileName).dispose();
            return null;
        } catch (Exception e) {
            addMessage(redirectAttributes, "导出媒体新闻记录失败！失败信息：" + e.getMessage());
        }
        return "redirect:" + Global.getAdminPath() + "/business/clientnews/clientNews/?repage";
    }

    /**
     * 导入Excel数据
     */
    @RequestMapping(value = "import", method = RequestMethod.POST)
    public String importFile(MultipartFile file, RedirectAttributes redirectAttributes) {
        try {
            int successNum = 0;
            ImportExcel ei = new ImportExcel(file, 1, 0);
            List<ClientNews> list = ei.getDataList(ClientNews.class);
            for (ClientNews clientNews : list) {
                clientNewsService.save(clientNews);
            }
            addMessage(redirectAttributes, "已成功导入 " + successNum + " 条媒体新闻记录");
        } catch (Exception e) {
            addMessage(redirectAttributes, "导入媒体新闻失败！失败信息：" + e.getMessage());
        }
        return "redirect:" + Global.getAdminPath() + "/business/clientnews/clientNews/?repage";
    }

    /**
     * 下载导入媒体新闻数据模板
     */
    @RequestMapping(value = "import/template")
    public String importFileTemplate(HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
            String fileName = "媒体新闻数据导入模板.xlsx";
            List<ClientNews> list = Lists.newArrayList();
            new ExportExcel("媒体新闻数据", ClientNews.class, 1).setDataList(list).write(response, fileName).dispose();
            return null;
        } catch (Exception e) {
            addMessage(redirectAttributes, "导入模板下载失败！失败信息：" + e.getMessage());
        }
        return "redirect:" + Global.getAdminPath() + "/business/clientnews/clientNews/?repage";
    }

}