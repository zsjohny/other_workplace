package com.jeeplus.common.sms;

import com.google.common.io.CharStreams;
import com.jeeplus.common.utils.StringUtils;
import org.apache.http.Consts;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.exolab.castor.mapping.Mapping;
import org.exolab.castor.mapping.MappingException;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class YrztMessageUtil {
    private static final String YRZT_PATH = "http://101.201.238.246/MessageTransferWebAppJs/servlet/messageTransferServiceServletByXml";
    private static final String USERNAME = "hjbhy";
    private static final String PASSWORD = "888888";
    private static final String RESULT_CODE = "resultCode";
    private static final String ERROR_CODE = "errorCode";
    private static final Logger logger = LoggerFactory.getLogger(YrztMessageUtil.class);

    private static CloseableHttpClient httpclient;
    private static RequestConfig requestConfig;
    private static Unmarshaller unmarshaller;

    static{
        requestConfig = RequestConfig
                .custom()
                .setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpclient = HttpClients
                .custom()
                .setRetryHandler(new DefaultHttpRequestRetryHandler())
                .build();
        Mapping mapping = new Mapping();
        try {
            mapping.loadMapping(YrztMessageUtil.class.getResource("/sms/yrztMessageMapping.xml"));
            unmarshaller = new Unmarshaller(YrztMessageResults.class);
            unmarshaller.setValidation(false);
            unmarshaller.setMapping(mapping);
        } catch (MappingException | IOException e) {
            logger.error("sendMessage() error: {}" + e.getMessage(), e);
        }
    }

    private static List<NameValuePair> getYrztSmsParams(String phone, String msg, String sendTime){
        List<NameValuePair> params = new ArrayList<>();
        params.add(new BasicNameValuePair("userName", USERNAME));
        params.add(new BasicNameValuePair("passWord", PASSWORD));
        params.add(new BasicNameValuePair("cmd", "sendMessage"));
        params.add(new BasicNameValuePair("contentType", "sms/mt"));
        params.add(new BasicNameValuePair("mobilePhone", phone));
        params.add(new BasicNameValuePair("body", msg));
        if (StringUtils.isNotBlank(sendTime)) {
            params.add(new BasicNameValuePair("scheduleDateStr", sendTime));
        }
        return params;
    }

    public static String sendMessage(String phone, String msg){
        return sendMessage(phone, msg, null);
    }

    public static String sendMessage(String phone, String msg, String sendTime){

        HttpPost httpPost = new HttpPost(YRZT_PATH);
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(getYrztSmsParams(phone, msg, sendTime), Consts.UTF_8);
        httpPost.setEntity(entity);
        httpPost.setConfig(requestConfig);

        try (CloseableHttpResponse httpResponse = httpclient.execute(httpPost);
             InputStream in = httpResponse.getEntity().getContent()) {
            String xml = CharStreams.toString(new InputStreamReader(in)).trim();

            logger.info(xml);

            YrztMessageResults messageResults = (YrztMessageResults) unmarshaller.unmarshal(
                    new StreamSource(new ByteArrayInputStream(xml.getBytes())));
            Map<String, String> results = messageResults.getResults();

            logger.info("resultCode: {}", results.get(RESULT_CODE));
            logger.debug("errorCode: {}", results.get(ERROR_CODE));

            return results.get(RESULT_CODE);
        } catch (IOException | MarshalException | ValidationException e) {
            logger.error("sendMessage() error: {}" + e.getMessage(), e);
        }
        return null;
    }
}
