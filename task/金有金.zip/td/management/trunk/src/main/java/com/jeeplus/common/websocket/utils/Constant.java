package com.jeeplus.common.websocket.utils;

public class Constant {
	
	public static final String _online_user_  = "_online_user_";
	public static final String _leave_user_  = "_leave_user_";
	public static final String _msg_ = "_msg_";

}
