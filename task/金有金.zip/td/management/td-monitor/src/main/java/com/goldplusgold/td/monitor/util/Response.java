package com.goldplusgold.td.monitor.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 统一处理response
 * <p>
 * Created by Ness on 2017/4/11.
 */
public class Response implements Serializable {


    //成功的标识
    private static final int SUCCESS_CODE = 200;
    //失败的标识
    private static final int ERROR_CODE = 400;


    /**
     * 返回成功标识
     *
     * @param data 需要返回的数据
     * @param <E>  返回给前端的数据
     * @return
     */
    public static <E> ResponseData success(E data) {
        ResponseData responseData = new ResponseData();
        responseData.data = data;
        responseData.code = SUCCESS_CODE;
        return responseData;

    }


    /**
     * 返回成功标识
     *
     * @param data 需要返回的数据
     * @param code 需要返回的状态
     * @param <E>  返回给前端的数据
     * @return
     */
    public static <E> ResponseData success(int code, E data) {
        ResponseData responseData = new ResponseData();
        responseData.data = data;
        responseData.code = code;
        return responseData;

    }


    /**
     * 返回成功标识
     *
     * @return
     */
    public static <E> ResponseData successByArray() {
        ResponseData responseData = new ResponseData();
        responseData.data = new ArrayList<>();
        responseData.code = SUCCESS_CODE;
        return responseData;

    }


    /**
     * 返回成功标识
     *
     * @return
     */
    public static <E> ResponseData successByMap() {
        ResponseData responseData = new ResponseData();
        responseData.data = new HashMap<>();
        responseData.code = SUCCESS_CODE;
        return responseData;

    }

    /**
     * 返回失败的标识
     *
     * @param data 需要返回的数据
     * @return
     */
    public static <E> ResponseData error(E data) {
        ResponseData responseData = new ResponseData();
        responseData.data = data;
        responseData.code = ERROR_CODE;
        return responseData;

    }


    /**
     * 返回失败的标识
     *
     * @param code 需要返回的code
     * @param data 需要返回的数据
     * @return
     */
    public static <E> ResponseData error(int code, E data) {
        ResponseData responseData = new ResponseData();
        responseData.data = data;
        responseData.code = code;
        return responseData;

    }


    /**
     * 返回失败的标识
     *
     * @return
     */
    public static <E> ResponseData errorByArray() {

        ResponseData responseData = new ResponseData();
        responseData.data = new ArrayList<>();
        responseData.code = ERROR_CODE;
        return responseData;

    }

    /**
     * 返回失败的标识
     *
     * @return
     */
    public static <E> ResponseData errorByMap() {
        ResponseData responseData = new ResponseData();
        responseData.data = new HashMap<>();
        responseData.code = ERROR_CODE;
        return responseData;

    }

    private static class ResponseData<T> extends Response {

        /**
         * 错误提示信息
         */
        private String msg="".intern();

        /**
         * 错误的参数代码
         */
        private int code;


        /**
         * 存储的数据
         */
        private T data;


        public String getMsg() {
            return msg;
        }

        public int getCode() {
            return code;
        }

        public T getData() {
            return data;
        }

        private ResponseData() {

        }
    }

    private Response() {

    }


    public static void main(String[] args) {
        System.out.println(Response.successByMap());
    }

    private Object readResolve() {
        return this;
    }

}
