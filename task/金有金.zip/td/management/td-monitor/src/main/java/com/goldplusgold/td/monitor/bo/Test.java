package com.goldplusgold.td.monitor.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Created by Ness on 2017/4/10.
 */
@Configuration
@Component
@ApiModel
public class Test {


    @JsonProperty("password")
    public String password;
    @Value("${test.name}")
    @JsonProperty("aest")
    public String name;

    @PostConstruct
    private void init() {
        System.err.println("_____________________");
        System.out.println(name);

    }

}
