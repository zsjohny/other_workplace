package com.goldplusgold.td.monitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by Ness on 2017/4/10.
 */
@SpringBootApplication
public class TestServer {
    public static void main(String[] args) {

        SpringApplication.run(TestServer.class,args);
    }

}
