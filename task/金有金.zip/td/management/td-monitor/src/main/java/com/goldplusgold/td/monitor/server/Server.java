package com.goldplusgold.td.monitor.server;

import com.goldplusgold.td.monitor.bo.Test;
import com.goldplusgold.td.monitor.util.Response;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Ness on 2017/4/10.
 */
@RestController
public class Server {

    @RequestMapping("/index")
//    @ApiOperation(notes = "getAccessibleGroups", httpMethod = "GET", value = "获取我可以访问的群组的列表")
    public Response index() {
        Test test = new Test();
        test.name = "355";
        test.password = "13515313";

        return Response.success(new Test[]{test, test});
    }
}
