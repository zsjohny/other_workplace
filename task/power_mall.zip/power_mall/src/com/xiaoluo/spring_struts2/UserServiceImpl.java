/**
 * 
 */
package com.xiaoluo.spring_struts2;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserServiceImpl.java, 2015年11月23日 下午3:40:35
 */
@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserDao userDao;

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public List<User> queryUser(int id) {
		List<User> userList = userDao.queryUser(id);
		return userList;
	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int adUser(User user) {
		int count = userDao.adUser(user);
		return count;
	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void deleteUserById(int id) {
		userDao.deleteUserById(id);

	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void updateUser(User user) {
		userDao.updateUser(user);

	}
}
