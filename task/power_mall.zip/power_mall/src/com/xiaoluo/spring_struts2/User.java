/**
 * 
 */
package com.xiaoluo.spring_struts2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.xiaoluo.spring_struts2.base.BaseModel;
import com.xiaoluo.spring_struts2.mapper.UserMapper;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: User.java, 2015年11月23日 下午1:59:24
 */

public class User implements BaseModel {

	private Integer id;
	private String name;
	private Integer age;

	/**
	 * @param id
	 * @param name
	 * @param age
	 */
	public User() {
		super();

	}

	/**
	 * @param id
	 * @param name
	 * @param age
	 */
	public User(Integer id, String name, Integer age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param age
	 *            the age to set
	 */
	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", age=" + age + "]";
	}

	public static void main(String[] args) {
		// 测试数据接口是否通过
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"classpath:applicationContext.xml");
		UserMapper userMapper = applicationContext.getBean(UserMapper.class);
		System.out.println(userMapper);

	}
}
