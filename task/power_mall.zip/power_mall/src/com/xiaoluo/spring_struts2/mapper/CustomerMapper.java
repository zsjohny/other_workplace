package com.xiaoluo.spring_struts2.mapper;

import java.util.List;

import com.xiaoluo.spring_struts2.customer.entity.Customer;

public interface CustomerMapper {

	int updateCustomerByShopperPhone(Customer customer);

	List<Customer> queryCustomerByShopperPhone(Customer customer);
}