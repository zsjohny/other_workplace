package com.xiaoluo.spring_struts2.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

public interface EditMerchandiseListMapper {
	void createEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryEditMerchandiseListById(Integer editMerchandiseListId);

	int updateEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryEditMerchandiseListByPhone(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryMerchandiseByEditMerchandiseListName(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListBySalesCount(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListByOrder(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryRecommondPicByPhone(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> findLocalMerchandiseByPhone(@Param("list") List<String> list,
			@Param("merchant") Merchant merchant);

	List<EditMerchandiseList> findToltalOrderByPhone(EditMerchandiseList editMerchandiseList);

	// 待用
	int deleteEditMerchandiseListByMerchantPhone(String merchantPhone);
}