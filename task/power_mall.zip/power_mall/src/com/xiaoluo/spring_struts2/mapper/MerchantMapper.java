package com.xiaoluo.spring_struts2.mapper;

import java.util.List;

import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

public interface MerchantMapper {
	int merchantLogin(Merchant merchant);

	void merchantValidate(Merchant merchant);

	Merchant queryMerchantByMerchantPhone(String editMerchandiseListId);

	void addMerchant(Merchant merchant);

	int updateMerchantByMerchantPhone(Merchant merchant);

	int resetMerchantValidateCount(Merchant merchant);

	Merchant checkIsRegistByPhone(Merchant merchant);

	int updateMerchantByUpload(Merchant merchant);

	int updateMerchantByLoginKey(Merchant merchant);

	List<Merchant> queryMerchantByArea(Merchant merchant);

	Merchant queryMerchantById(int id);

}