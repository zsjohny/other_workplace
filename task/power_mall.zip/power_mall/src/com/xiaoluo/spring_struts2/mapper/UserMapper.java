package com.xiaoluo.spring_struts2.mapper;

import java.util.List;

import com.xiaoluo.spring_struts2.User;

public interface UserMapper {
	int adUser(User user);

	List<User> queryUserById(int id);

	List<User> queryUserByAll();

	void deleteUserById(int id);

	void updateUser(User user);
}