package com.xiaoluo.spring_struts2.mapper;

import java.util.List;

import com.xiaoluo.spring_struts2.Merchant.entity.CustomerOrder;

public interface CustomerOrderMapper {

	CustomerOrder findOrderById(CustomerOrder customerOrder);

	int updateCustomerOrderById(CustomerOrder customerOrder);

	int createCustomerOrder(CustomerOrder customerOrder);

	List<CustomerOrder> queryAllByPhone(CustomerOrder customerOrder);

	List<CustomerOrder> querySatatusCountAllByPhone(CustomerOrder customerOrder);

}