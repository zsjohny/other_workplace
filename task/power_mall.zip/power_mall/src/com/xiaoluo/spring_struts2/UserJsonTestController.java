///**
// * 
// */
//package com.xiaoluo.spring_struts2;
//
//import java.util.List;
//
//import javax.annotation.Resource;
//
//import org.apache.struts2.convention.annotation.Action;
//import org.apache.struts2.convention.annotation.Actions;
//import org.apache.struts2.convention.annotation.InterceptorRef;
//import org.apache.struts2.convention.annotation.Namespace;
//import org.apache.struts2.convention.annotation.ParentPackage;
//import org.apache.struts2.convention.annotation.Result;
//import org.springframework.stereotype.Controller;
//
//import com.opensymphony.xwork2.ActionSupport;
//import com.opensymphony.xwork2.ModelDriven;
//import com.opensymphony.xwork2.Preparable;
//
///**
// * 
// * 
// * @author xiaoluo
// * @version $Id: UserController.java, 2015年11月23日 下午3:40:10
// */
//@ParentPackage("json-default")
//@Namespace("/demo")
//@InterceptorRef(value = "paramsPrepareParamsStack", params = {
//		"prepare.alwaysInvokePrepare", "false" })
//@Controller()
//public class UserJsonTestController extends ActionSupport implements ModelDriven<User>,
//		Preparable {
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 1L;
//	@Resource
//	private UserService userService;
//
//	// @Autowired
//	private User user;
//
//	// 返回为json
//	public List<User> users;
//
//	// /**
//	// * @return the user
//	// */
//	// public User getUser() {
//	// return user;
//	// }
//	//
//	// /**
//	// * @param user
//	// * the user to set
//	// */
//	//
//	// public void setUser(User user) {
//	// System.out.println("into user.....");
//	// this.user = user;
//	// }
//
//	// @Action(value = "addBook", results = {
//	// @Result(name = "success", type = "json", params = { "root", "book",
//	// "ignoreHierarchy", "false" }),
//	// @Result(name = "error", type = "json", params = { "root",
//	// "errorMessage" }) })
//	// @Actions({
//	// @Action(value = "testAction", results = { @Result(location =
//	// "/success.jsp") }),
//	// @Action(value = "testAction2", results = { @Result(location =
//	// "/success.jsp") }) })
//
//	// @Actions({ @Action(value = "addUser", results = { @Result(name =
//	// "success", location = "/WEB-INF/demo/login.jsp") }) })
//	// 约定限制已经解除，所以返回结果直接可以是WEB-INF目录下了+namespace/
//	@Actions({ @Action(value = "addUser", results = { @Result(name = "success", type = "json", params = {
//			"root", "users", "ignoreHierarchy", "true" }) }) })
//	// @Action(value = "addUser")
//	public String addUser() {
//
//		// root参数用于指定要序列化的根对象，如果省去这一配置，表示要序列化action中的所有属性
//		// ignoreHierarchy 为false时表示要序列化根对象的所有基类
//		// excludeProperties表示排除的序列化的属性
//		// includeProperties表示哪些属性被序列化
//
//		System.out.println(user);
//		// List<User> users = userService.queryUserByAll();
//		users = userService.queryUserByAll();
//		// Map<String, Object> map = new HashMap<String, Object>();
//		// map.put("user", users);
//		// 用json的返回形式代替这个值栈
//		// ActionContext.getContext().getValueStack().push(users);
//
//		// JSONObject jsonObject = new JSONObject();
//		// jsonObject.put("user", users);
//		// HttpServletResponse response = ServletActionContext.getResponse();
//		// try {
//		// PrintWriter printWriter = response.getWriter();
//		// printWriter.write(jsonObject.toString());
//		// printWriter.close();
//		// } catch (IOException e) {
//		// // TODO Auto-generated catch block
//		// e.printStackTrace();
//		// }
//		// mapJson = new HashMap<String, Object>();
//		// mapJson.put("user", users);
//		return SUCCESS;
//	}
//
//	public void prepareAddUser() {
//		user = new User();
//	}
//
//	/**
//	 * 
//	 * 
//	 * @param
//	 * @return
//	 */
//
//	@Override
//	public User getModel() {
//		System.out.println("modriven....");
//		return user;
//	}
//
//	/**
//	 * 
//	 * 
//	 * @param
//	 * @return
//	 */
//
//	@Override
//	public void prepare() throws Exception {
//		System.out.println("prepare......");
//	}
//
// }
