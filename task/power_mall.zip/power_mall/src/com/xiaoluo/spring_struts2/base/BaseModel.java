/**
 * 
 */
package com.xiaoluo.spring_struts2.base;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: BaseModel.java, 2015年11月24日 下午6:42:57
 */

public interface BaseModel {

}
