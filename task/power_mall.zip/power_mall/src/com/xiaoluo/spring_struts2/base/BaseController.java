/**
 * 
 */
package com.xiaoluo.spring_struts2.base;

import org.apache.struts2.convention.annotation.InterceptorRef;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: BaseController.java, 2015年11月24日 下午6:40:18
 */
@InterceptorRef(value = "paramsPrepareParamsStack", params = { "prepare.alwaysInvokePrepare", "false" })
@Controller
public class BaseController extends ActionSupport implements ModelDriven<BaseModel>, Preparable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 准备实体类对象
	protected BaseModel baseModel;

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void prepare() throws Exception {

	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public BaseModel getModel() {
		return baseModel;
	}

}
