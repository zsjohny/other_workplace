package com.xiaoluo.spring_struts2.msg;

import com.xiaoluo.spring_struts2.base.BaseController;

import cn.smssdk.SMSSDK;

public class MsgTest extends BaseController {
	public static void main(String[] args) {
		// SMSSDK.initSDK(, "5887b8134af8", "9cd46d6cf9908a297fbafeb75b7b19d3");

		SMSSDK.getVerificationCode("86", "15924179757");
	}
}
