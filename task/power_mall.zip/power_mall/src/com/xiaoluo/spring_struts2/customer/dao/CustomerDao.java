package com.xiaoluo.spring_struts2.customer.dao;

import java.util.List;

import com.xiaoluo.spring_struts2.customer.entity.Customer;

public interface CustomerDao {
	int updateCustomerByShopperPhone(Customer customer);

	List<Customer> queryCustomerByShopperPhone(Customer customer);
}
