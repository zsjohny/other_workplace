package com.xiaoluo.spring_struts2.customer.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.xiaoluo.spring_struts2.customer.dao.CustomerDao;
import com.xiaoluo.spring_struts2.customer.entity.Customer;
import com.xiaoluo.spring_struts2.mapper.CustomerMapper;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	@Resource
	private CustomerMapper customerMapper;

	@Override
	public int updateCustomerByShopperPhone(Customer customer) {

		return customerMapper.updateCustomerByShopperPhone(customer);
	}

	@Override
	public List<Customer> queryCustomerByShopperPhone(Customer customer) {
		return customerMapper.queryCustomerByShopperPhone(customer);
	}
}
