package com.xiaoluo.spring_struts2.customer.entity;

import com.xiaoluo.spring_struts2.base.BaseModel;

public class Customer implements BaseModel {

	private Integer customerId;

	private String orderInfos;

	private String shopperPhone;

	public String getShopperPhone() {
		return shopperPhone;
	}

	public void setShopperPhone(String shopperPhone) {
		this.shopperPhone = shopperPhone;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getOrderInfos() {
		return orderInfos;
	}

	public void setOrderInfos(String orderInfos) {
		this.orderInfos = orderInfos;
	}

}
