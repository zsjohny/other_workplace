package com.xiaoluo.spring_struts2.customer.service;

import java.util.List;

import com.xiaoluo.spring_struts2.customer.entity.Customer;

public interface CustomerService {
	int updateCustomerByShopperPhone(Customer customer);

	List<Customer> queryCustomerByShopperPhone(Customer customer);
}
