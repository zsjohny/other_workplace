package com.xiaoluo.spring_struts2.customer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.customer.dao.CustomerDao;
import com.xiaoluo.spring_struts2.customer.entity.Customer;
import com.xiaoluo.spring_struts2.customer.service.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Resource
	private CustomerDao customerDao;

	@Override
	public int updateCustomerByShopperPhone(Customer customer) {
		return customerDao.updateCustomerByShopperPhone(customer);
	}

	@Override
	public List<Customer> queryCustomerByShopperPhone(Customer customer) {
		return customerDao.queryCustomerByShopperPhone(customer);
	}

}
