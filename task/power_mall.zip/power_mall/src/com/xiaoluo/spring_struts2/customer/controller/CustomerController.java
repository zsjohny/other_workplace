package com.xiaoluo.spring_struts2.customer.controller;

import com.xiaoluo.spring_struts2.base.BaseController;

public class CustomerController extends BaseController {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
