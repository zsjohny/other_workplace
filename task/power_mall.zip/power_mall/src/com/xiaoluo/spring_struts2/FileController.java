/**
 * 
 */
package com.xiaoluo.spring_struts2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionSupport;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: FileController.java, 2015年11月25日 下午1:27:34
 */
@Namespace("/upload")
@Controller
@Result(name = "download", type = "stream", params = { "contentType",
		"application/octet-stream", "contentDisposition",
		" attachment;filename='${uploadFileName}'", "inputName", "downLoadFile" })
public class FileController extends ActionSupport {
	// 文件上传的name属性
	private File upload;
	// 文件上传的名称
	private String uploadFileName;
	// 文件上传的类型
	private String uploadContentType;

	/**
	 * @return the upload
	 */
	public File getUpload() {
		return upload;
	}

	/**
	 * @return the uploadFileName
	 */
	public String getUploadFileName() {
		return uploadFileName;
	}

	/**
	 * @return the uploadContentType
	 */
	public String getUploadContentType() {
		return uploadContentType;
	}

	/**
	 * @param upload
	 *            the upload to set
	 */
	public void setUpload(File upload) {
		this.upload = upload;
	}

	/**
	 * @param uploadFileName
	 *            the uploadFileName to set
	 */
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	/**
	 * @param uploadContentType
	 *            the uploadContentType to set
	 */
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 2648213319383308696L;

	// 上传
	@Action(value = "uploadFile", results = { @Result(name = "input", location = "success.jsp") })
	public String uploadFile() {
		try {

			BufferedInputStream bis = new BufferedInputStream(
					new FileInputStream(upload));

			BufferedOutputStream bos = new BufferedOutputStream(
					new FileOutputStream(new File(
							"C:\\Users\\pj\\Desktop\\test", uploadFileName)));

			byte[] cache = new byte[1024];
			int len = 0;
			while ((len = bis.read(cache)) != -1) {

				bos.write(cache, 0, len);
			}

			bos.close();
			bis.close();

		} catch (Exception e) {

		}
		return INPUT;

	}

	// 下载文件的流
	public InputStream getDownLoadFile() throws FileNotFoundException {
		// 命名中文名
		try {
			this.setUploadFileName(new String("新建文本文档r22.txt".getBytes(),
					"ISO8859-1"));

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		InputStream is = new FileInputStream(new File(
				"C:\\Users\\pj\\Desktop\\test\\新建文本文档.txt"));

		return is;

	}

	// 下载--返回到result中，在本类中用result接受
	@Action(value = "downLoadFile")
	public String downLoadFile() {
		return "download";

	}

	// 测试
	@Action(value = "test")
	public String test() {
		System.out.println("..........");

		return null;

	}
}
