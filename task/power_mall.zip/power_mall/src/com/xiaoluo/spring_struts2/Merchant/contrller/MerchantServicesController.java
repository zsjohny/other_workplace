/**
 * 
 */
package com.xiaoluo.spring_struts2.Merchant.contrller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;
import com.xiaoluo.spring_struts2.Merchant.service.MerchantService;
import com.xiaoluo.spring_struts2.base.BaseController;
import com.xiaoluo.spring_struts2.util.ByteConverHexString;
import com.xiaoluo.spring_struts2.util.Log4jUtil;
import com.xiaoluo.spring_struts2.util.RSACoder;

import net.sf.json.JSONObject;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: MerchantServicesController.java, 2015年12月2日 下午4:15:14
 */
@ParentPackage("json-default")
@Namespace("/merchant")
@Results(@Result(name = "download", type = "stream", params = { "contentType", "application/octet-stream",
		"contentDisposition", " attachment;filename='${recordUrlFileName}'", "inputName", "downloadMerchant" }))
public class MerchantServicesController extends BaseController {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// service
	@Resource
	private MerchantService merchantService;
	@Resource
	private MerchantDao merchantDao;
	private File recordUrl;

	private String recordUrlFileName;

	private String recordUrlContentType;

	private File merchantHead;

	private String merchantHeadlFileName;

	private String merchantHeadContentType;

	public File getMerchantHead() {
		return merchantHead;
	}

	public void setMerchantHead(File merchantHead) {
		this.merchantHead = merchantHead;
	}

	public String getMerchantHeadlFileName() {
		return merchantHeadlFileName;
	}

	public void setMerchantHeadlFileName(String merchantHeadlFileName) {
		this.merchantHeadlFileName = merchantHeadlFileName;
	}

	public String getMerchantHeadContentType() {
		return merchantHeadContentType;
	}

	public void setMerchantHeadContentType(String merchantHeadContentType) {
		this.merchantHeadContentType = merchantHeadContentType;
	}

	public File getRecordUrl() {
		return recordUrl;
	}

	public void setRecordUrl(File recordUrl) {
		this.recordUrl = recordUrl;
	}

	public String getRecordUrlFileName() {
		return recordUrlFileName;
	}

	public void setRecordUrlFileName(String recordUrlFileName) {
		this.recordUrlFileName = recordUrlFileName;
	}

	public String getRecordUrlContentType() {
		return recordUrlContentType;
	}

	public void setRecordUrlContentType(String recordUrlContentType) {
		this.recordUrlContentType = recordUrlContentType;
	}

	private Logger logger = Log4jUtil.init(MerchantServicesController.class);

	// 返回的类型
	public Map<String, String> Tips = new HashMap<>();

	private boolean checkParam(Merchant merchant) {
		boolean flag = false;

		if (merchant == null) {
			return flag;
		}
		if (merchant.getMerchantLoginPhone() == null) {
			return flag;
		}

		if (merchant.getMerchantLoginPhone() != null
				& merchant.getMerchantLoginPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {

			flag = true;
		}
		return flag;
	}

	/**
	 * 上传资料
	 *
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "uploadMerchant", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String uploadMerchant() {

		Merchant merchant = (Merchant) baseModel;
		if (!checkParam(merchant)) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}

		try {

			// 防止客户进行提前上传干扰服务--验证

			if (merchant.getLoginKey() == null) {

				Tips.put("STATUS", "KEY_EMPTY");
				return SUCCESS;
			}
			// MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAKyNeq6e287LbkmyRArAOlJ9SQebK7uZsTpBBMDdVAGGO4qHA0Z+VcSS0g+zG+h/WjJ2TDs3x0kCZwAhNEbFbG1Mhrc6EBDJCw8jEu9nLzsnCcVaKODxoGFtFJVgdTqmRiCWiHN1iKkGwk9Qr7kINijEGt05nizQeyA4O/Rpnv5vAgMBAAECgYA61GGnd3Hpp2IKrkSUhcVcqmpjtXvLkjLicZh1SQCDJIjYSf/L4PbM9mG4CJDTS9gsrDiBWBsRwUfsu2VfW6ADdGEsvChlyCIWpUJNQkJdCkTmUOf8EnCH1r/F79apDwFFHEV2U+M2cXf7gV+d5Eh4czJi1vUdwtqj/DyE6IJAQQJBANclSM8G2ikG1+1gE0XwwXoUxiOGLw0l0r6nG1xRjCcsUTVNnrAISZAhbU+WFJvSEjKx9YdvEqd812MKGVtAOcMCQQDNUadGxbsn8kPGO2aqAG5ZQFU2p63U75QBeVakB4hNTdMTBCxhfDi67nW9sitMg0oJodjVA7GrsU4pbCMKnzHlAkAwrkoMNiO09sxy9LNHtxNAOWUf8qPA2NcXtp4VRIpu7rMtWXPXpvhmOXoPcQkWvPDLMcM5suNIrJHb4hQctqqbAkAjQq2emuCcaJ+5EIR+F5rb2w+HVl6lHgvmAOefPefrlrz0HBhfGY1IlSFFVa7X8ggqBVCOrJa7rLSGqpqN/W79AkB6F0CR79qfQMp3av7iDltGCGayM2xZGfgd2voCLTqHoKvXsT7VLERUHHXIagU72VCw/4dLwFy3NfVx0ADsHMI7
			Merchant queryMerchantByMerchantPhone = merchantDao.queryMerchantByMerchantPhone(merchant);
			byte[] bs = ByteConverHexString.HexString2Bytes(merchant.getLoginKey());
			if (merchant.getLoginKey() == null) {
				Tips.put("STATUS", "KEY_EMPTY");
				return SUCCESS;
			}
			String outputStr = "";
			try {
				outputStr = new String(RSACoder.decryptByPrivateKey(bs, queryMerchantByMerchantPhone.getLoginKey()));
			} catch (Exception e) {
				Tips.put("STATUS", "KEY_ERROR");
				return SUCCESS;
			}
			if (!outputStr.equals(merchant.getMerchantLoginPhone())) {

				Tips.put("STATUS", "KEY_ERROR");
				return SUCCESS;

			}

			// String realPath =
			// ServletActionContext.getServletContext().getRealPath("")
			// + "WEB-INF\\uploadMerchant\\";
			String realPath = "D:\\workplaces\\app\\power_mall\\WebContent\\WEB-INF\\uploadMerchant\\";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calendar = Calendar.getInstance();

			File recordFile = new File(realPath + merchant.getMerchantLoginPhone() + "/recordFile");
			if (!recordFile.exists()) {
				recordFile.mkdirs();
			}
			File headPicFile = new File(realPath + merchant.getMerchantLoginPhone() + "/headFile");
			if (!headPicFile.exists()) {
				headPicFile.mkdirs();
			}
			String uuid = simpleDateFormat.format(calendar.getTime()) + "_" + UUID.randomUUID().toString();
			byte[] cache = new byte[1024];
			int len = 0;
			// 语音
			if (recordUrl != null) {

				File[] files = recordFile.listFiles();
				for (File file : files) {
					System.gc();
					file.delete();
				}

				try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(recordUrl));
						BufferedOutputStream bos = new BufferedOutputStream(
								new FileOutputStream(new File(recordFile.getPath(), uuid + ".amr")));) {

					while ((len = bis.read(cache)) != -1) {

						bos.write(cache, 0, len);
					}

				}
				merchant.setMerchantRecordUrl(recordFile.getPath() + "&" + uuid + ".amr");
			}
			// 背景图片
			if (merchantHead != null) {

				File[] files = headPicFile.listFiles();
				for (File file : files) {
					System.gc();
					file.delete();
				}
				try (BufferedInputStream bis2 = new BufferedInputStream(new FileInputStream(merchantHead));
						BufferedOutputStream bos2 = new BufferedOutputStream(
								new FileOutputStream(new File(headPicFile.getPath(), uuid + ".jpg")));) {

					while ((len = bis2.read(cache)) != -1) {

						bos2.write(cache, 0, len);
					}

				}
				merchant.setMerchantHeadUrl(headPicFile.getPath() + "&" + uuid + ".jpg");

			}

			merchantService.updateMerchantByUpload(merchant);
			Tips.put("STATUS", "OK");
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		} catch (Exception e) {
			logger.warn("商家用户上传录败:" + e.getMessage());
			Tips.put("STATUS", "ERROR");
		}
		return SUCCESS;

	}

	public void prepareUploadMerchant() {
		baseModel = new Merchant();
	}

	/*
	 * 下载
	 */
	@Action(value = "downloadBymerchantPhone")
	public String downloadByMerchantPhone() {
		Merchant merchant = (Merchant) baseModel;
		if (!checkParam(merchant)) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}

		return "download";
	}

	public void prepareDownloadByMerchantPhone() {
		baseModel = new Merchant();
	}

	public InputStream getDownloadMerchant() {
		Merchant merchant = (Merchant) baseModel;

		String remark = merchant.getRemark();
		merchant = merchantService.queryMerchantByMerchantPhone(merchant);
		InputStream is = null;

		if (merchant != null) {
			try {
				if ("0".equals(remark)) {
					if (merchant.getMerchantRecordUrl() != null) {
						this.setRecordUrlFileName(merchant.getMerchantRecordUrl().split("&")[1]);
						is = new FileInputStream(new File(merchant.getMerchantRecordUrl().replace("&", "\\")));
					}
				} else if ("1".equals(remark)) {
					if (merchant.getMerchantHeadUrl() != null) {
						this.setRecordUrlFileName(merchant.getMerchantHeadUrl().split("&")[1]);
						is = new FileInputStream(new File(merchant.getMerchantHeadUrl().replace("&", "\\")));
					}
				}
			} catch (FileNotFoundException e) {

			}
		}

		return is;

	}

	/**
	 * 商铺资料的加载
	 *
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "loadMerchant", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String loadMerchant() {

		Merchant merchant = (Merchant) baseModel;
		if (!checkParam(merchant)) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}
		try {
			merchant = merchantService.queryMerchantByMerchantPhone(merchant);
			JSONObject jsonObject = new JSONObject();

			jsonObject.put("merchantStoreName", merchant.getMerchantStoreName());
			jsonObject.put("merchantRecordDes", merchant.getMerchantRecordDes());

			Tips.put("STATUS", "OK");
			Tips.put("SOURCE", jsonObject.toString());

			System.out.println(Tips);
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");

		} catch (Exception e) {
			logger.warn("商家资料加载失败:" + e.getMessage());
			Tips.put("STATUS", "ERROR");
		}
		return SUCCESS;

	}

	public void prepareLoadMerchant() {
		baseModel = new Merchant();
	}

	/*
	 * 错误消息
	 */
	@Action(value = "errorPage", results =

	{ @Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })

	public String errorPage() {

		Tips.put("STATUS", "NOTCHECK");
		return SUCCESS;

	}

	// 测试
	@Action(value = "test")
	public String test() {
		System.out.println("..........");

		return null;

	}
}
