/**
 * 
 */
package com.xiaoluo.spring_struts2.Merchant.entity;

import com.xiaoluo.spring_struts2.base.BaseModel;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: Merchant.java, 2015年12月2日 下午4:26:17
 */

public class Merchant implements BaseModel {
	private Integer merchantId;
	private String merchantLoginName;
	private String merchantLoginPhone;
	private String merchantLoginPassword;
	private String merchantRealIp;
	private String merchantKey;
	private String secMerchantLoginKey;

	private int validateCount;
	private String validateCode;

	private String is_regist;

	private String merchantHeadUrl;

	private String merchantRecordUrl;

	private String merchantRecordDes;

	private String merchantStoreName;

	private String loginKey;

	// 下载标志
	private String remark;

	private String merchantLoginIdCard;
	// 地区
	private String province;

	private String city;
	private String country;

	private int starPage;
	private int starCount;
	private int count;

	private String picName;
	private String picId;

	public String getPicName() {
		return picName;
	}

	public void setPicName(String picName) {
		this.picName = picName;
	}

	public String getPicId() {
		return picId;
	}

	public void setPicId(String picId) {
		this.picId = picId;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getStarPage() {
		return starPage;
	}

	public void setStarPage(int starPage) {
		this.starPage = starPage;
	}

	public int getStarCount() {
		return starCount;
	}

	public void setStarCount(int starCount) {
		this.starCount = starCount;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		if (province.equals("不限")) {
			province = "";
		}
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		if (city.equals("不限")) {
			city = "";
		}
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		if (country.equals("不限")) {
			country = "";
		}
		this.country = country;
	}

	public String getMerchantLoginIdCard() {
		return merchantLoginIdCard;
	}

	public void setMerchantLoginIdCard(String merchantLoginIdCard) {
		this.merchantLoginIdCard = merchantLoginIdCard;
	}

	public String getLoginKey() {
		return loginKey;
	}

	public void setLoginKey(String loginKey) {
		this.loginKey = loginKey;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getMerchantRecordUrl() {
		return merchantRecordUrl;
	}

	public String getMerchantHeadUrl() {
		return merchantHeadUrl;
	}

	public void setMerchantHeadUrl(String merchantHeadUrl) {
		this.merchantHeadUrl = merchantHeadUrl;
	}

	public void setMerchantRecordUrl(String merchantRecordUrl) {
		this.merchantRecordUrl = merchantRecordUrl;
	}

	public String getMerchantRecordDes() {
		return merchantRecordDes;
	}

	public void setMerchantRecordDes(String merchantRecordDes) {
		this.merchantRecordDes = merchantRecordDes;
	}

	public String getMerchantStoreName() {
		return merchantStoreName;
	}

	public void setMerchantStoreName(String merchantStoreName) {
		this.merchantStoreName = merchantStoreName;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getIs_regist() {
		return is_regist;
	}

	public void setIs_regist(String is_regist) {
		this.is_regist = is_regist;
	}

	public String getValidateCode() {
		return validateCode;
	}

	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}

	public int getValidateCount() {
		return validateCount;
	}

	public void setValidateCount(int validateCount) {
		this.validateCount = validateCount;
	}

	public String getSecMerchantLoginKey() {
		return secMerchantLoginKey;
	}

	public void setSecMerchantLoginKey(String secMerchantLoginKey) {
		this.secMerchantLoginKey = secMerchantLoginKey;
	}

	public String getMerchantKey() {
		return merchantKey;
	}

	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}

	public String getMerchantLoginName() {
		return merchantLoginName;
	}

	public void setMerchantLoginName(String merchantLoginName) {
		this.merchantLoginName = merchantLoginName;
	}

	public String getMerchantLoginPhone() {
		return merchantLoginPhone;
	}

	public void setMerchantLoginPhone(String merchantLoginPhone) {
		this.merchantLoginPhone = merchantLoginPhone;
	}

	public String getMerchantLoginPassword() {
		return merchantLoginPassword;
	}

	public void setMerchantLoginPassword(String merchantLoginPassword) {
		this.merchantLoginPassword = merchantLoginPassword;
	}

	public String getMerchantRealIp() {
		return merchantRealIp;
	}

	public void setMerchantRealIp(String merchantRealIp) {
		this.merchantRealIp = merchantRealIp;
	}

	@Override
	public String toString() {
		return merchantLoginPhone;
	}

}
