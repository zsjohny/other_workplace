package com.xiaoluo.spring_struts2.Merchant.contrller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;

import com.xiaoluo.spring_struts2.Merchant.dao.EditMerchandiseListDao;
import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;
import com.xiaoluo.spring_struts2.base.BaseController;
import com.xiaoluo.spring_struts2.util.ByteConverHexString;
import com.xiaoluo.spring_struts2.util.Des16Util;
import com.xiaoluo.spring_struts2.util.DesUtil;
import com.xiaoluo.spring_struts2.util.GainRealIpUtil;
import com.xiaoluo.spring_struts2.util.Log4jUtil;
import com.xiaoluo.spring_struts2.util.RSACoder;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

//@Transactional
@ParentPackage("json-default")
@Namespace("/merchantLogin")
public class MerchantLoginController extends BaseController {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Logger logger = Log4jUtil.init(MerchantLoginController.class);

	@Autowired
	private MerchantDao merchantDao;

	@Autowired
	private EditMerchandiseListDao editMerchandiseListDao;

	// 商品订单载入
	@Action(value = "queryInfo", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String queryOrder() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null || editMerchandiseList.getMerchantPhone() == null) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}

			// 分页
			editMerchandiseList.setCount(10);
			editMerchandiseList.setStarCount(editMerchandiseList.getStarPage() == 0 ? 0
					: (editMerchandiseList.getStarPage() - 1) * editMerchandiseList.getCount());

			// 设置组队
			editMerchandiseList.setOrderSign("3");

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
					.queryEditMerchandiseListByPhone(editMerchandiseList);

			if (editMerchandiseLists == null) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			JSONArray jsonArray = new JSONArray();

			for (EditMerchandiseList eList : editMerchandiseLists) {
				String shopperPhones = eList.getShopperPhone();

				if (shopperPhones == null) {
					continue;

				}

				if (shopperPhones.indexOf(",") > -1) {

					for (String shopper : shopperPhones.split(",")) {

						if (StringUtils.isEmpty(shopper)) {
							continue;
						}
						JSONObject jsonObject = new JSONObject();

						jsonObject.put("merchandiseId", eList.getEditMerchandiseListId());
						jsonObject.put("customerPicUrl",
								eList.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1]
										.split(",")[0] + ".jpg");

						jsonObject.put("customerPhone", shopper.split("_")[0]);
						jsonObject.put("customerDate", shopper.split("_")[1]);
						jsonObject.put("customerOrder", shopper.split("_")[2]);
						jsonObject.put("customerStatus", shopper.split("_")[3]);

						jsonArray.add(jsonObject);
					}

				} else if (!"".equals(shopperPhones.trim())) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("merchandiseId", eList.getEditMerchandiseListId());
					jsonObject.put("customerPicUrl",
							eList.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1]
									.split(",")[0] + ".jpg");
					jsonObject.put("customerPhone", shopperPhones.split("_")[0]);
					jsonObject.put("customerDate", shopperPhones.split("_")[1]);
					jsonObject.put("customerOrder", shopperPhones.split("_")[2]);
					jsonObject.put("customerStatus", shopperPhones.split("_")[3]);
					jsonArray.add(jsonObject);
				}
			}

			// 返回订单数目
			int orderStaCount = 0;
			int orderRunCount = 0;
			int orderRefCount = 0;
			// 增加返回的订单总条数
			editMerchandiseLists = editMerchandiseListDao.findToltalOrderByPhone(editMerchandiseList);

			for (EditMerchandiseList eLi : editMerchandiseLists) {
				if (StringUtils.isEmpty(eLi.getShopperPhone())) {
					continue;
				}

				if (eLi.getShopperPhone().indexOf(",") > -1) {
					String[] arr = eLi.getShopperPhone().split(",");

					for (String str : arr) {
						if (StringUtils.isEmpty(str)) {
							continue;
						}

						if (str.indexOf("start") > -1) {
							orderStaCount++;
						} else if (str.indexOf("run") > -1) {
							orderRunCount++;
						} else if (str.indexOf("refund") > -1) {
							orderRefCount++;
						}

					}
				} else {

					if (eLi.getShopperPhone().indexOf("start") > -1) {
						orderStaCount++;
					} else if (eLi.getShopperPhone().indexOf("run") > -1) {
						orderRunCount++;
					} else if (eLi.getShopperPhone().indexOf("refund") > -1) {
						orderRefCount++;
					}

				}

			}

			Tips.put("STATUS", "OK");
			Tips.put("SOURCE", jsonArray);
			JSONArray array = new JSONArray();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("orderStaCount", orderStaCount);
			jsonObject.put("orderRunCount", orderRunCount);
			jsonObject.put("orderRefCount", orderRefCount);
			array.add(jsonObject);
			Tips.put("COUNT", array);
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;
	}

	public void prepareQueryOrder() {
		baseModel = new EditMerchandiseList();
	}

	private Integer id;
	private String name;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// 返回的类型
	public Map<String, Object> Tips = new HashMap<>();

	private boolean checkParam(Merchant merchant) {
		boolean flag = false;

		if (merchant == null) {
			return flag;
		}
		if (merchant.getMerchantLoginPhone() == null) {
			return flag;
		}

		if (merchant.getMerchantLoginPhone() != null
				& merchant.getMerchantLoginPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {

			flag = true;
		}
		return flag;
	}

	/**
	 * 获取验证码
	 *
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "gainCode", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String gainMessageValidate() {
		String merchantRealIp = GainRealIpUtil.gainRealIp(ServletActionContext.getRequest());
		Merchant merchant = (Merchant) baseModel;
		if (!checkParam(merchant)) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}

		Merchant checkMerchant = merchantDao.queryMerchantByMerchantPhone(merchant);
		int count = checkMerchant == null ? 0 : checkMerchant.getValidateCount();

		if (count > 5) {
			Tips.put("STATUS", "ERROR");
			Tips.put("SOURCE", "OVERCOUNT");

			return SUCCESS;

		}

		String phone = merchant.getMerchantLoginPhone();

		String num = "";
		for (int i = 0; i < 6; i++) {
			num += String.valueOf(((int) (Math.random() * 10)));
		}
		String sendRemark = "";
		// 短信接口
		// String msgCode = num + sendRemark + phone;

		if (!sendMsg(phone, num)) {

			Tips.put("STATUS", "ERROR");
			return SUCCESS;
		}

		merchant.setMerchantRealIp(merchantRealIp);

		merchant.setValidateCount(++count);

		merchant.setValidateCode(num);

		if (checkMerchant.getMerchantId() == null) {
			merchantDao.merchantValidate(merchant);

		} else {

			merchantDao.updateMerchantByMerchantPhone(merchant);
		}

		Tips.put("STATUS", "OK");
		Tips.put("SOURCE", num);
		return SUCCESS;

	}

	public void prepareGainMessageValidate() {
		baseModel = new Merchant();
	}

	private Boolean sendMsg(String phone, String sendCode) {
		Boolean flag = false;

		String Url = "http://121.199.16.178/webservice/sms.php?method=Submit";
		HttpClient client = new HttpClient();
		PostMethod method = new PostMethod(Url);

		// client.getParams().setContentCharset("GBK");
		client.getParams().setContentCharset("UTF-8");
		method.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=UTF-8");

		String content = new String("您的验证码是：" + sendCode + "。请不要把验证码泄露给其他人。");

		NameValuePair[] data = { // 提交短信
				new NameValuePair("account", "cf_wxhdcs"), new NameValuePair("password", "wxhdcs123"), // 密码可以使用明文密码或使用32位MD5加密
				// new NameValuePair("password",
				// util.StringUtil.MD5Encode("密码")),
				new NameValuePair("mobile", phone), new NameValuePair("content", content), };

		method.setRequestBody(data);

		try {
			client.executeMethod(method);

			String SubmitResult = method.getResponseBodyAsString();

			// System.out.println(SubmitResult);

			Document doc = DocumentHelper.parseText(SubmitResult);
			Element root = doc.getRootElement();

			String code = root.elementText("code");
			// String msg = root.elementText("msg");
			// String smsid = root.elementText("smsid");

			if ("2".equals(code)) {
				flag = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return flag;
	}

	/**
	 * 检测手机
	 *
	 * 
	 * @param
	 * @return
	 */

	@Action(value = "mLogin", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String merchantLogin() {
		try {

			Merchant merchant = (Merchant) baseModel;
			if (!checkParam(merchant)) {
				Tips.put("STATUS", "FORRBIEDN");
				return SUCCESS;
			}
			if (merchant.getValidateCode() != null && "".equals(merchant.getValidateCode())) {
				Tips.put("STATUS", "FORRBIEDN");
				return SUCCESS;
			}

			if (merchant.getMerchantLoginPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {

				Merchant checkMerchant = merchantDao.queryMerchantByMerchantPhone(merchant);

				if (checkMerchant == null) {
					Tips.put("STATUS", "UNEXIST");
					return SUCCESS;
				}

				if (!merchant.getValidateCode().equals(checkMerchant.getValidateCode())) {
					Tips.put("STATUS", "INCORRECT");
					return SUCCESS;
				}
				String password = UUID.randomUUID().toString();

				merchant.setMerchantLoginPassword(password);

				String[] randRom = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f",
						"g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y",
						"z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
						"S", "T", "U", "V", "W", "X", "Y", "Z" };

				String merchantKey = "";
				try {
					for (int i = 0; i < (int) (Math.random() * 30 + 8); i++) {
						merchantKey += randRom[(int) (Math.random() * 62 + 1)];
					}
				} catch (Exception e) {
					merchantKey = "xiaoluowannengmiyao";
				}

				merchant.setMerchantKey(merchantKey);

				int is_success = merchantDao.merchantLogin(merchant);
				if (is_success != 0) {

					Tips.put("STATUS", Des16Util.encrypt(DesUtil.encrypt(password, merchantKey),
							merchant.getMerchantLoginPhone()));
				} else {

					Tips.put("STATUS", "ERROR");
				}

			} else {
				Tips.put("STATUS", "您所填写的不是有效手机号!");

			}
		} catch (Exception e) {
			logger.warn("商家用户手机验证失败:" + e.getMessage());
			Tips.put("STATUS", "SYSTEMERROR");
		}
		return SUCCESS;

	}

	public void prepareMerchantLogin() {
		baseModel = new Merchant();
	}

	/**
	 * 登陆
	 *
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "addMerchant", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String addMerchant() {

		Merchant merchant = (Merchant) baseModel;
		if (!checkParam(merchant)) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}

		String password = "";
		Merchant checkMerchant = merchantDao.queryMerchantByMerchantPhone(merchant);
		try {

			password = DesUtil
					.decrypt(Des16Util.decrypt(merchant.getSecMerchantLoginKey().replace("\\", "").replace(" ", "+"),
							merchant.getMerchantLoginPhone()), checkMerchant.getMerchantKey());

			if ("".equals(password)) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			if (password.equals(checkMerchant.getMerchantLoginPassword())) {

				// 登陆密钥
				Map<String, Object> keyMap = RSACoder.initKey();

				String privateKey = RSACoder.getPrivateKey(keyMap);

				String str = ByteConverHexString.Bytes2HexString(RSACoder.encryptByPublicKey(
						merchant.getMerchantLoginPhone().getBytes(), RSACoder.getPublicKey(keyMap)));

				// byte[] bs = ByteConverHexString.HexString2Bytes(str);
				//
				// byte[] decodedData = RSACoder.decryptByPrivateKey(bs,
				// privateKey);

				// String outputStr = new String(decodedData);

				merchant.setLoginKey(privateKey);

				int len = merchantDao.updateMerchantByLoginKey(merchant);
				if (len != 0) {

					Tips.put("loginKey", str);

					Tips.put("STATUS", "OK");
				} else {
					Tips.put("STATUS", "ERROR");
				}
			} else {
				Tips.put("STATUS", "ERROR");

			}
		} catch (Exception e) {
			logger.warn("商家用户验登录败:" + e.getMessage());
			Tips.put("STATUS", "SYSTEMERROR");
		}
		return SUCCESS;

	}

	public void prepareAddMerchant() {
		baseModel = new Merchant();
	}

	/**
	 * 重置手势密码
	 *
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "resetGesture", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String resetIdCard() {

		Merchant merchant = (Merchant) baseModel;
		if (!checkParam(merchant) || merchant.getMerchantLoginIdCard() == null) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}

		if (!merchant.getMerchantLoginIdCard().matches(
				"^[1-9]\\d{7}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}$||^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}([0-9]|X)$")) {
			Tips.put("STATUS", "IDERROR");
			return SUCCESS;
		}

		try {
			Merchant checkMerchant = merchantDao.queryMerchantByMerchantPhone(merchant);

			if (checkMerchant != null) {

				if (checkMerchant.getMerchantLoginIdCard().endsWith(merchant.getMerchantLoginIdCard())) {
					Tips.put("STATUS", "OK");
					return SUCCESS;
				}
			}
			Tips.put("STATUS", "ERROR");
		} catch (

		Exception e)

		{
			logger.warn("商家用户重置身份:" + e.getMessage());
			Tips.put("STATUS", "SYSTEMERROR");
		}
		return SUCCESS;

	}

	public void prepareResetIdCard() {
		baseModel = new Merchant();
	}

	/**
	 * 重置验证登陆的次数
	 *
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "deleteCount", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }),
			@Result(name = "input", type = "redirectAction", params = { "actionName", "errorPage", "namespace",
					"/merchant" }) })
	public String deleteCount() {
		Merchant merchant = (Merchant) baseModel;
		if (merchant == null) {
			Tips.put("STATUS", "FORRBIEDN");
			return SUCCESS;
		}

		if (!("xiaoluo".equals(merchant.getMerchantLoginName())
				&& "879227577".equals(merchant.getMerchantLoginPassword()))) {
			Tips.put("STATUS", "ERROR");
			return SUCCESS;
		}

		int count = merchantDao.resetMerchantValidateCount(merchant);
		if (count != 0) {
			Tips.put("STATUS", "OK");
		} else {
			Tips.put("STATUS", "ERROR");
		}
		return SUCCESS;

	}

	public void prepareDeleteCount() {
		baseModel = new Merchant();
	}

	// 推荐商品的接口，根据id加载商品--权限问题，丢这里了

	// 根据Id加载商品
	@Action(value = "merchandiseLoadById", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String merchandiseLoadById() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
					.queryEditMerchandiseListById(editMerchandiseList);

			if (editMerchandiseLists == null) {
				Tips.put("STATUS", 301);
				return SUCCESS;

			}
			Tips.put("status", 300);

			List<String> disUrls = new ArrayList<String>();
			List<String> desUrls = new ArrayList<String>();

			// JSONArray jsonArray = new JSONArray();
			JSONObject jsonObject = new JSONObject();
			for (EditMerchandiseList eList : editMerchandiseLists) {

				String disUrl = eList.getEditMerchandiseListDisPicsUrl();
				String desUrl = eList.getEditMerchandiseListDesPicsUrl();
				JSONArray disPicArr = null;
				JSONArray desPicArr = null;
				if (disUrl != null) {

					String disPath = disUrl.replace("[", "").replace("]", "").split("&")[1];
					String[] disArr = null;
					if (disPath.indexOf(",") > -1) {
						disArr = disPath.split(",");

						for (String str : disArr) {

							disUrls.add("?id=" + eList.getEditMerchandiseListId() + "&name=" + str.trim() + ".jpg");

						}

						// Tips.put("DISURL", disUrls);
					} else {
						disPicArr = new JSONArray();
						disPicArr.add("?id=" + eList.getEditMerchandiseListId() + "&name=" + disPath.trim() + ".jpg");
						// Tips.put("DISURL", disPicArr);

					}

				} else {
					disPicArr = new JSONArray();
					disPicArr.add("");
					// Tips.put("DISURL", disPicArr);
				}

				if (desUrl != null) {
					String desPath = desUrl.replace("[", "").replace("]", "").split("&")[1];
					String[] desArr = null;

					if (desPath.indexOf(",") > -1) {

						desArr = desPath.split(",");
						for (String str : desArr) {

							desUrls.add("?id=" + eList.getEditMerchandiseListId() + "&name=" + str.trim() + ".jpg");
						}

						// Tips.put("DESURL", desUrls);
					} else {
						desPicArr = new JSONArray();
						desPicArr.add("?id=" + eList.getEditMerchandiseListId() + "&name=" + desPath.trim() + ".jpg");
						// Tips.put("DESURL", disPicArr);
					}

				} else {
					desPicArr = new JSONArray();
					desPicArr.add("");
					// Tips.put("DESURL", disPicArr);
				}

				jsonObject.put("editMerchandiseListId", eList.getEditMerchandiseListId());
				jsonObject.put("editMerchandiseListName", eList.getEditMerchandiseListName());
				jsonObject.put("editMerchandiseListPrice", eList.getEditMerchandiseListPrice());
				jsonObject.put("editMerchandiseListStock", eList.getEditMerchandiseListStock());
				jsonObject.put("editMerchandiseListIsPost", eList.getEditMerchandiseListIsPost());
				jsonObject.put("editMerchandiseListProductDesc", eList.getEditMerchandiseListProductDesc());
				jsonObject.put("salesCount", eList.getSalesCount());
				// jsonObject.put("editMerchandiseRecordUrl",
				// eList.getEditMerchandiseRecordUrl().split("&")[1]);
				jsonObject.put("merchantFloderName", eList.getMerchantFloderName());
				jsonObject.put("disPicUrl", disPicArr == null ? disUrls : disPicArr);
				jsonObject.put("desPicUrl", desPicArr == null ? desUrls : desPicArr);
				// 增加商家店铺信息的id
				Merchant merchant = new Merchant();
				merchant.setMerchantLoginPhone(eList.getMerchantPhone());
				merchant = merchantDao.queryMerchantByMerchantPhone(merchant);

				jsonObject.put("merchantId", merchant.getMerchantId());
				jsonObject.put("merchantStoreName",
						merchant.getMerchantStoreName() == null ? "" : merchant.getMerchantStoreName());

			}

			Tips.put("source", jsonObject);
		} catch (Exception e) {
			Tips.put("status", 301);
		}
		return SUCCESS;

	}

	public void prepareMerchandiseLoadById() {
		baseModel = new EditMerchandiseList();
	}

	// 商家在买家订单中查看商品的图片的问题---没有权限，在这里重新写个
	// 根据Id加载商品
	@Action(value = "download")
	public void download() {
		if (id == null || StringUtils.isEmpty(name)) {
			return;
		}
		EditMerchandiseList editMerchandiseList = new EditMerchandiseList();
		editMerchandiseList.setEditMerchandiseListId(id);

		List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
				.queryEditMerchandiseListById(editMerchandiseList);

		if (editMerchandiseLists == null) {
			return;
		}
		if (editMerchandiseLists.get(0).getEditMerchandiseListDisPicsUrl() != null) {
			File[] disFile = new File(editMerchandiseLists.get(0).getEditMerchandiseListDisPicsUrl().split("&")[0])
					.listFiles();
			if (disFile != null) {

				for (File file : disFile) {
					if (file.getName().equals((name == null ? "" : name))) {

						try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
								BufferedOutputStream fos = new BufferedOutputStream(
										ServletActionContext.getResponse().getOutputStream())) {
							// 设置下载的保存格式
							// response.setHeader("Content-Disposition",
							// "attachment;
							// filename=1.png");
							// response.setContentType("application/octet-stream;
							// charset=utf-8");
							byte[] bs = new byte[1024];
							int len = 0;
							while ((len = bis.read(bs)) != -1) {
								fos.write(bs, 0, len);
							}

						} catch (Exception e) {
						}
						return;
					}
				}
			}

		}
		if (editMerchandiseLists.get(0).getEditMerchandiseListDesPicsUrl() != null) {

			File[] desFile = new File(editMerchandiseLists.get(0).getEditMerchandiseListDesPicsUrl().split("&")[0])
					.listFiles();
			if (desFile != null) {

				for (File file : desFile) {
					if (file.getName().equals((name == null ? "" : name))) {

						try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
								BufferedOutputStream fos = new BufferedOutputStream(
										ServletActionContext.getResponse().getOutputStream())) {
							// 设置下载的保存格式
							// response.setHeader("Content-Disposition",
							// "attachment;
							// filename=1.png");
							// response.setContentType("application/octet-stream;
							// charset=utf-8");
							byte[] bs = new byte[1024];
							int len = 0;
							while ((len = bis.read(bs)) != -1) {
								fos.write(bs, 0, len);
							}

						} catch (Exception e) {
						}
						return;
					}
				}

			}
		}
		if (editMerchandiseLists.get(0).getEditMerchandiseRecordUrl() != null) {

			File[] recordFiles = new File(editMerchandiseLists.get(0).getEditMerchandiseRecordUrl().split("&")[0])
					.listFiles();
			if (recordFiles != null) {
				for (File file : recordFiles) {

					if (file.getName().equals((name == null ? "" : name))) {

						try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
								BufferedOutputStream fos = new BufferedOutputStream(
										ServletActionContext.getResponse().getOutputStream())) {
							// 设置下载的保存格式
							// response.setHeader("Content-Disposition",
							// "attachment;
							// filename=1.png");
							// response.setContentType("application/octet-stream;
							// charset=utf-8");
							byte[] bs = new byte[1024];
							int len = 0;
							while ((len = bis.read(bs)) != -1) {
								fos.write(bs, 0, len);
							}

						} catch (Exception e) {
						}
						return;
					}

				}
			}
		}

	}
}
