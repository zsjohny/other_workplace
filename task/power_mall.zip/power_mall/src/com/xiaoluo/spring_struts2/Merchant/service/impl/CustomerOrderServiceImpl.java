package com.xiaoluo.spring_struts2.Merchant.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.Merchant.dao.CustomerOrderDao;
import com.xiaoluo.spring_struts2.Merchant.entity.CustomerOrder;
import com.xiaoluo.spring_struts2.Merchant.service.CustomerOrderService;

@Service
@Transactional
public class CustomerOrderServiceImpl implements CustomerOrderService {
	@Resource
	private CustomerOrderDao customerOrderDao;

	@Override
	public int createCustomerOrder(CustomerOrder customerOrder) {

		return customerOrderDao.createCustomerOrder(customerOrder);
	}

	@Override
	public CustomerOrder findOrderByOrderNumberAndOrderTime(CustomerOrder customerOrder) {

		return customerOrderDao.findOrderByOrderNumberAndOrderTime(customerOrder);
	}

	@Override
	public int updateCustomerOrderById(CustomerOrder customerOrder) {

		return customerOrderDao.updateCustomerOrderById(customerOrder);
	}

	@Override
	public List<CustomerOrder> queryAllByPhone(CustomerOrder customerOrder) {

		return customerOrderDao.queryAllByPhone(customerOrder);
	}

	@Override
	public List<CustomerOrder> querySatatusCountAllByPhone(CustomerOrder customerOrder) {

		return customerOrderDao.querySatatusCountAllByPhone(customerOrder);
	}

}
