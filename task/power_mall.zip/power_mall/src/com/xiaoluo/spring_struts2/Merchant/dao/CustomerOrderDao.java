package com.xiaoluo.spring_struts2.Merchant.dao;

import java.util.List;

import com.xiaoluo.spring_struts2.Merchant.entity.CustomerOrder;

public interface CustomerOrderDao {
	int createCustomerOrder(CustomerOrder customerOrder);

	CustomerOrder findOrderByOrderNumberAndOrderTime(CustomerOrder customerOrder);

	int updateCustomerOrderById(CustomerOrder customerOrder);

	List<CustomerOrder> queryAllByPhone(CustomerOrder customerOrder);

	List<CustomerOrder> querySatatusCountAllByPhone(CustomerOrder customerOrder);
}
