/**
 * 
 */
package com.xiaoluo.spring_struts2.Merchant.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;
import com.xiaoluo.spring_struts2.mapper.MerchantMapper;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserDaoImpl.java, 2015年11月23日 下午4:15:56
 */
@Transactional
@Repository
public class MerchantDaoImpl implements MerchantDao {
	@Resource
	private MerchantMapper merchantMapper;

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int merchantLogin(Merchant merchant) {
		return merchantMapper.merchantLogin(merchant);

	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public Merchant queryMerchantByMerchantPhone(Merchant merchant) {

		return merchantMapper.queryMerchantByMerchantPhone(merchant.getMerchantLoginPhone());
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void addMerchant(Merchant merchant) {
		merchantMapper.addMerchant(merchant);

	}

	@Override
	public void merchantValidate(Merchant merchant) {
		merchantMapper.merchantValidate(merchant);

	}

	@Override
	public int updateMerchantByMerchantPhone(Merchant merchant) {

		return merchantMapper.updateMerchantByMerchantPhone(merchant);
	}

	@Override
	public int resetMerchantValidateCount(Merchant merchant) {

		return merchantMapper.resetMerchantValidateCount(merchant);
	}

	@Override
	public Merchant checkIsRegistByPhone(Merchant merchant) {

		return merchantMapper.checkIsRegistByPhone(merchant);
	}

	@Override
	public int updateMerchantByUpload(Merchant merchant) {

		return merchantMapper.updateMerchantByUpload(merchant);
	}

	@Override
	public int updateMerchantByLoginKey(Merchant merchant) {

		return merchantMapper.updateMerchantByLoginKey(merchant);
	}

	@Override
	public List<Merchant> queryMerchantByArea(Merchant merchant) {

		return merchantMapper.queryMerchantByArea(merchant);
	}

	@Override
	public Merchant queryMerchantById(int id) {

		return merchantMapper.queryMerchantById(id);
	}

}
