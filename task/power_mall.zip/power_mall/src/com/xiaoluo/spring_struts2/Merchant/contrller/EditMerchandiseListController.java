package com.xiaoluo.spring_struts2.Merchant.contrller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.xiaoluo.spring_struts2.Merchant.entity.CustomerOrder;
import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.service.CustomerOrderService;
import com.xiaoluo.spring_struts2.Merchant.service.EditMerchandiseListService;
import com.xiaoluo.spring_struts2.base.BaseController;
import com.xiaoluo.spring_struts2.customer.entity.Customer;
import com.xiaoluo.spring_struts2.customer.service.CustomerService;
import com.xiaoluo.spring_struts2.util.Log4jUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@ParentPackage("json-default")
@Namespace("/uploadEditMerchant")
//// 测试安卓文件上传
// @Scope(value = "default")

@Result(name = "download", type = "stream", params = { "contentType", "application/octet-stream", "contentDisposition",
		" attachment;filename='${fileName}'", "inputName", "downloadMerdinseFile" })
public class EditMerchandiseListController extends BaseController {
	@Resource
	private EditMerchandiseListService editMerchandiseListService;
	@Resource
	private CustomerService customerService;
	@Resource
	private CustomerOrderService customerOrderService;

	Logger logger = Log4jUtil.init(EditMerchandiseListController.class);

	public Map<String, Object> Tips = new HashMap<String, Object>();

	private File[] editMerchandiseListDisPics;
	private String[] editMerchandiseListDisPicsFileName;
	private String[] editMerchandiseListDisPicsContentType;

	// private List<File> editMerchandiseListDisPics;
	// private List<String> editMerchandiseListDisPicsFileName;
	// private List<String> editMerchandiseListDisPicsContentType;

	private File[] editMerchandiseListDesPics;
	private String[] editMerchandiseListDesPicsFileName;
	private String[] editMerchandiseListDesPicsContentType;

	private String fileId;

	private File editMerchandiseRecord;
	private String editMerchandiseRecordFileName;
	private String editMerchandiseRecordContentType;

	public File getEditMerchandiseRecord() {
		return editMerchandiseRecord;
	}

	public void setEditMerchandiseRecord(File editMerchandiseRecord) {
		this.editMerchandiseRecord = editMerchandiseRecord;
	}

	public String getEditMerchandiseRecordFileName() {
		return editMerchandiseRecordFileName;
	}

	public void setEditMerchandiseRecordFileName(String editMerchandiseRecordFileName) {
		this.editMerchandiseRecordFileName = editMerchandiseRecordFileName;
	}

	public String getEditMerchandiseRecordContentType() {
		return editMerchandiseRecordContentType;
	}

	public void setEditMerchandiseRecordContentType(String editMerchandiseRecordContentType) {
		this.editMerchandiseRecordContentType = editMerchandiseRecordContentType;
	}

	private String fileName;

	private String fileUrl;

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl.replace("\\", "\\");
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {

		this.fileName = fileName;

	}

	public File[] getEditMerchandiseListDisPics() {
		return editMerchandiseListDisPics;
	}

	public void setEditMerchandiseListDisPics(File[] editMerchandiseListDisPics) {
		this.editMerchandiseListDisPics = editMerchandiseListDisPics;
	}

	public String[] getEditMerchandiseListDisPicsFileName() {
		return editMerchandiseListDisPicsFileName;
	}

	public void setEditMerchandiseListDisPicsFileName(String[] editMerchandiseListDisPicsFileName) {
		this.editMerchandiseListDisPicsFileName = editMerchandiseListDisPicsFileName;
	}

	public String[] getEditMerchandiseListDisPicsContentType() {
		return editMerchandiseListDisPicsContentType;
	}

	public void setEditMerchandiseListDisPicsContentType(String[] editMerchandiseListDisPicsContentType) {
		this.editMerchandiseListDisPicsContentType = editMerchandiseListDisPicsContentType;
	}

	public File[] getEditMerchandiseListDesPics() {
		return editMerchandiseListDesPics;
	}

	// public List<File> getEditMerchandiseListDisPics() {
	// return editMerchandiseListDisPics;
	// }
	//
	// public void setEditMerchandiseListDisPics(List<File>
	// editMerchandiseListDisPics) {
	// this.editMerchandiseListDisPics = editMerchandiseListDisPics;
	// }
	//
	// public List<String> getEditMerchandiseListDisPicsFileName() {
	// return editMerchandiseListDisPicsFileName;
	// }
	//
	// public void setEditMerchandiseListDisPicsFileName(List<String>
	// editMerchandiseListDisPicsFileName) {
	// this.editMerchandiseListDisPicsFileName =
	// editMerchandiseListDisPicsFileName;
	// }
	//
	// public List<String> getEditMerchandiseListDisPicsContentType() {
	// return editMerchandiseListDisPicsContentType;
	// }
	//
	// public void setEditMerchandiseListDisPicsContentType(List<String>
	// editMerchandiseListDisPicsContentType) {
	// this.editMerchandiseListDisPicsContentType =
	// editMerchandiseListDisPicsContentType;
	// }

	public void setEditMerchandiseListDesPics(File[] editMerchandiseListDesPics) {
		this.editMerchandiseListDesPics = editMerchandiseListDesPics;
	}

	public String[] getEditMerchandiseListDesPicsFileName() {
		return editMerchandiseListDesPicsFileName;
	}

	public void setEditMerchandiseListDesPicsFileName(String[] editMerchandiseListDesPicsFileName) {
		this.editMerchandiseListDesPicsFileName = editMerchandiseListDesPicsFileName;
	}

	public String[] getEditMerchandiseListDesPicsContentType() {
		return editMerchandiseListDesPicsContentType;
	}

	public void setEditMerchandiseListDesPicsContentType(String[] editMerchandiseListDesPicsContentType) {
		this.editMerchandiseListDesPicsContentType = editMerchandiseListDesPicsContentType;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 上传
	@Action(value = "uploadFile", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String uploadEditMerchandise() {
		EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;

		if (editMerchandiseList.getEditMerchandiseListStock() == 0
				&& editMerchandiseList.getEditMerchandiseListPrice() == 0.0
				&& (fileName == null || "".equals(fileName))) {
			Tips.put("STATUS", "ERROR");
			return SUCCESS;

		}

		try {

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListById(editMerchandiseList);
			boolean flag = editMerchandiseLists != null && editMerchandiseLists.size() > 0;
			// String realPath =
			// ServletActionContext.getServletContext().getRealPath("");
			String realPath = "D:\\workplaces\\app\\power_mall\\WebContent\\";
			BufferedInputStream bis = null;
			BufferedOutputStream bos = null;
			List<String> dicPicsTokenIdList = new ArrayList<String>();
			List<String> desPicsTokenIdList = new ArrayList<String>();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calendar = Calendar.getInstance();

			String rootPath = realPath + "WEB-INF/uploadEditMerchant/" + editMerchandiseList.getMerchantPhone() + "/";

			if (flag) {
				rootPath = rootPath + editMerchandiseLists.get(0).getMerchantFloderName();
			} else {
				String merchantFloderName = String.valueOf(System.currentTimeMillis());

				rootPath = rootPath + merchantFloderName;

				editMerchandiseList.setMerchantFloderName(merchantFloderName);

			}
			File disPicsFile = new File(rootPath + "/DisPics");
			if (!disPicsFile.exists()) {
				disPicsFile.mkdirs();
			}

			File desPicsFile = new File(rootPath + "/DesPics");
			if (!desPicsFile.exists()) {
				desPicsFile.mkdirs();
			}

			if (editMerchandiseListDisPics != null) {
				if (flag) {
					File[] files = disPicsFile.listFiles();
					for (File file : files) {
						System.gc();
						file.delete();
					}
				}

				for (File file : editMerchandiseListDisPics) {
					if (file.exists()) {
						String uuid = simpleDateFormat.format(calendar.getTime()) + "_" + UUID.randomUUID().toString();

						bis = new BufferedInputStream(new FileInputStream(file));

						bos = new BufferedOutputStream(
								new FileOutputStream(new File(disPicsFile.getPath(), uuid + ".jpg")));
						dicPicsTokenIdList.add(uuid);

						byte[] cache = new byte[1024];
						int len = 0;
						while ((len = bis.read(cache)) != -1) {

							bos.write(cache, 0, len);
						}

						bos.close();
						bis.close();

					}

				}
				editMerchandiseList.setEditMerchandiseListDisPicsUrl(disPicsFile.getPath() + "&" + dicPicsTokenIdList);
			}

			if (editMerchandiseListDesPics != null) {

				if (flag) {
					File[] files = desPicsFile.listFiles();
					for (File file : files) {
						System.gc();
						file.delete();
					}
				}
				for (File file : editMerchandiseListDesPics) {
					if (file.exists()) {

						String uuid = simpleDateFormat.format(calendar.getTime()) + "_" + UUID.randomUUID().toString();

						bis = new BufferedInputStream(new FileInputStream(file));

						bos = new BufferedOutputStream(
								new FileOutputStream(new File(desPicsFile.getPath(), uuid + ".jpg")));
						desPicsTokenIdList.add(uuid);
						byte[] cache = new byte[1024];
						int len = 0;
						while ((len = bis.read(cache)) != -1) {

							bos.write(cache, 0, len);
						}

						bos.close();
						bis.close();

					}

				}

				editMerchandiseList.setEditMerchandiseListDesPicsUrl(desPicsFile.getPath() + "&" + desPicsTokenIdList);

			}

			// 推荐
			File recordFile = new File(rootPath + "/recordFile");
			if (!recordFile.exists()) {
				recordFile.mkdirs();
			}
			if (editMerchandiseRecord != null) {

				if (flag) {
					File[] files = recordFile.listFiles();
					for (File file : files) {
						System.gc();
						file.delete();
					}
				}

				// 先把之前的推荐商品给删除
				List<EditMerchandiseList> elLists = editMerchandiseListService
						.queryRecommondPicByPhone(editMerchandiseList);

				if (elLists == null || elLists.size() == 0) {
					Tips.put("STATUS", "ERROR");
					return SUCCESS;
				}
				String recordURl = "";
				for (EditMerchandiseList eList : elLists) {
					recordURl = eList.getEditMerchandiseRecordUrl();

					if (recordURl == null || recordURl.equals("")) {
						continue;

					}
					eList.setEditMerchandiseRecordUrl("");
					eList.setMerchantPhone(editMerchandiseList.getMerchantPhone());
					eList.setLoginKey(editMerchandiseList.getLoginKey());
					editMerchandiseListService.updateEditMerchandiseListById(eList);

				}
				// 重新上传新的推荐商品
				String uuid = simpleDateFormat.format(calendar.getTime()) + "_" + UUID.randomUUID().toString();

				bis = new BufferedInputStream(new FileInputStream(editMerchandiseRecord));

				bos = new BufferedOutputStream(new FileOutputStream(new File(recordFile.getPath(), uuid + ".jpg")));
				desPicsTokenIdList.add(uuid);
				byte[] cache = new byte[1024];
				int len = 0;
				while ((len = bis.read(cache)) != -1) {

					bos.write(cache, 0, len);
				}

				bos.close();
				bis.close();

				editMerchandiseList.setEditMerchandiseRecordUrl(recordFile.getPath() + "&" + uuid + ".jpg");
			}
			if (flag) {
				editMerchandiseListService.updateEditMerchandiseListById(editMerchandiseList);
				Tips.put("STATUS", "OK");
			} else {
				if (editMerchandiseRecord == null && editMerchandiseList.getEditMerchandiseListDisPicsUrl() != null) {

					editMerchandiseListService.createEditMerchandiseListById(editMerchandiseList);
					Tips.put("STATUS", "OK");
				} else {
					Tips.put("STATUS", "ERROR");
				}

			}

		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		} catch (Exception e) {
			logger.warn("商家编辑商品发布失败:" + e.getMessage());
			Tips.put("STATUS", "ERROR");
		}
		return SUCCESS;

	}

	public void prepareUploadEditMerchandise() {
		baseModel = new EditMerchandiseList();
	}

	// 商品的删除
	@Action(value = "deleteMerchandise", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String deleteMerchandise() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;

			if (editMerchandiseList == null) {
				Tips.put("STATUS", "FORBID");
			}

			editMerchandiseList.setIs_deledted("1");

			int count = editMerchandiseListService.updateEditMerchandiseListById(editMerchandiseList);

			if (count > 0) {
				Tips.put("STATUS", "OK");
				return SUCCESS;
			}

			Tips.put("STATUS", "ERROR");
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;

	}

	public void prepareDeleteMerchandise() {
		baseModel = new EditMerchandiseList();
	}

	// 根据Id加载商品
	@Action(value = "merchandiseLoadById", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String merchandiseLoadById() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListById(editMerchandiseList);

			if (editMerchandiseLists == null) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;

			}
			Tips.put("STATUS", "OK");

			List<String> disUrls = new ArrayList<String>();
			List<String> desUrls = new ArrayList<String>();

			JSONArray jsonArray = new JSONArray();

			for (EditMerchandiseList eList : editMerchandiseLists) {
				JSONObject jsonObject = new JSONObject();
				String disUrl = eList.getEditMerchandiseListDisPicsUrl();
				String desUrl = eList.getEditMerchandiseListDesPicsUrl();
				JSONArray disPicArr = null;
				if (disUrl != null) {

					String disPath = disUrl.replace("[", "").replace("]", "").split("&")[1];
					String[] disArr = null;
					if (disPath.indexOf(",") > -1) {
						disArr = disPath.split(",");

						for (String str : disArr) {

							disUrls.add(str.trim() + ".jpg");

						}

						Tips.put("DISURL", disUrls);
					} else {
						disPicArr = new JSONArray();
						disPicArr.add(disPath.trim() + ".jpg");
						Tips.put("DISURL", disPicArr);

					}

				} else {
					disPicArr = new JSONArray();
					disPicArr.add("");
					Tips.put("DISURL", disPicArr);
				}

				if (desUrl != null) {
					String desPath = desUrl.replace("[", "").replace("]", "").split("&")[1];
					String[] desArr = null;

					if (desPath.indexOf(",") > -1) {

						desArr = desPath.split(",");
						for (String str : desArr) {

							desUrls.add(str.trim() + ".jpg");
						}

						Tips.put("DESURL", desUrls);
					} else {
						disPicArr = new JSONArray();
						disPicArr.add(desPath.trim() + ".jpg");
						Tips.put("DESURL", disPicArr);
					}

				} else {
					disPicArr = new JSONArray();
					disPicArr.add("");
					Tips.put("DESURL", disPicArr);
				}

				jsonObject.put("editMerchandiseListId", eList.getEditMerchandiseListId());
				jsonObject.put("editMerchandiseListName", eList.getEditMerchandiseListName());
				jsonObject.put("editMerchandiseListPrice", eList.getEditMerchandiseListPrice());
				jsonObject.put("editMerchandiseListStock", eList.getEditMerchandiseListStock());
				jsonObject.put("editMerchandiseListIsPost", eList.getEditMerchandiseListIsPost());
				jsonObject.put("salesCount", eList.getSalesCount());
				jsonObject.put("editMerchandiseListProductDesc", eList.getEditMerchandiseListProductDesc());
				// jsonObject.put("editMerchandiseRecordUrl",
				// eList.getEditMerchandiseRecordUrl().split("&")[1]);
				jsonObject.put("merchantFloderName", eList.getMerchantFloderName());
				jsonArray.add(jsonObject);
			}

			Tips.put("SOURCE", jsonArray);
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;

	}

	public void prepareMerchandiseLoadById() {
		baseModel = new EditMerchandiseList();
	}

	// 商品的总加载
	@Action(value = "merchandiseLoad", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String merchandiseLoad() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;

			if (editMerchandiseList == null
					|| (editMerchandiseList.getSequence() == null && editMerchandiseList.getOrderSign() == null)) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}

			// 分页
			editMerchandiseList.setCount(10);
			editMerchandiseList.setStarCount(editMerchandiseList.getStarPage() == 0 ? 0
					: (editMerchandiseList.getStarPage() - 1) * editMerchandiseList.getCount());

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListByPhone(editMerchandiseList);

			if (editMerchandiseLists.size() > 0) {
				Tips.put("STATUS", "OK");

				JSONArray jsonArray = new JSONArray();
				JSONObject jsonObject = null;
				JSONArray jsonArrayList = new JSONArray();
				for (EditMerchandiseList edit : editMerchandiseLists) {
					jsonObject = new JSONObject();
					jsonObject.put("editMerchandiseListId", edit.getEditMerchandiseListId());
					jsonObject.put("disPicUrl",
							edit.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1]
									.split(",")[0] + ".jpg" + "}");
					jsonObject.put("editMerchandiseListName", edit.getEditMerchandiseListName());
					jsonObject.put("editMerchandiseListPrice", edit.getEditMerchandiseListPrice());
					jsonObject.put("salesCount", edit.getSalesCount());
					jsonArrayList.add(jsonObject);

				}
				jsonArray.add(jsonArrayList);
				Tips.put("SOURCE", jsonArray);

				return SUCCESS;
			}

			Tips.put("STATUS", "ERROR");
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;

	}

	public void prepareMerchandiseLoad() {
		baseModel = new EditMerchandiseList();
	}

	// 下载
	public InputStream getDownloadMerdinseFile() throws FileNotFoundException {
		// // 命名中文名
		// try {
		// this.setFileName(new String(fileName.getBytes(), "ISO8859-1"));
		//
		// } catch (UnsupportedEncodingException e) {
		// logger.warn("商家下载失败:" + e.getMessage());
		// }
		InputStream is = null;
		if (fileId == null) {
			return is;
		}
		EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
		editMerchandiseList.setEditMerchandiseListId(Integer.parseInt(fileId));

		List<EditMerchandiseList> editMerchandiseLists = null;
		Integer id = (!fileId.matches("\\d+")) ? 0 : Integer.parseInt(fileId);
		if (id != 0) {
			editMerchandiseLists = editMerchandiseListService.queryEditMerchandiseListById(editMerchandiseList);
		}

		if (editMerchandiseLists == null) {
			return is;
		}
		if (editMerchandiseLists.get(0).getEditMerchandiseListDisPicsUrl() != null) {
			File[] disFile = new File(editMerchandiseLists.get(0).getEditMerchandiseListDisPicsUrl().split("&")[0])
					.listFiles();
			if (disFile != null) {

				for (File file : disFile) {
					if (file.getName().equals((fileUrl == null ? "" : fileUrl))) {
						this.setFileName(file.getName());

						is = new FileInputStream(file);

					}
				}
			}

		}
		if (editMerchandiseLists.get(0).getEditMerchandiseListDesPicsUrl() != null) {

			File[] desFile = new File(editMerchandiseLists.get(0).getEditMerchandiseListDesPicsUrl().split("&")[0])
					.listFiles();
			if (desFile != null) {

				for (File file : desFile) {
					if (file.getName().equals((fileUrl == null ? "" : fileUrl))) {
						this.setFileName(file.getName());
						is = new FileInputStream(file);

					}
				}

			}
		}
		if (editMerchandiseLists.get(0).getEditMerchandiseRecordUrl() != null) {

			File[] recordFiles = new File(editMerchandiseLists.get(0).getEditMerchandiseRecordUrl().split("&")[0])
					.listFiles();
			if (recordFiles != null) {
				for (File file : recordFiles) {

					if (file.getName().equals((fileUrl == null ? "" : fileUrl))) {
						this.setFileName(file.getName());
						is = new FileInputStream(file);

					}

				}
			}
		}
		return is;

	}

	// 商品的查询
	@Action(value = "merchandiseQuery", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String queryMerchandiseByEditMerchandiseListName() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null || editMerchandiseList.getEditMerchandiseListName() == null) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}
			// 分页
			editMerchandiseList.setCount(10);
			editMerchandiseList.setStarCount(editMerchandiseList.getStarPage() == 0 ? 0
					: (editMerchandiseList.getStarPage() - 1) * editMerchandiseList.getCount());

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryMerchandiseByEditMerchandiseListName(editMerchandiseList);

			if (editMerchandiseLists != null && editMerchandiseLists.size() > 0) {

				Tips.put("STATUS", "OK");
				JSONArray jsonArray = new JSONArray();
				JSONObject jsonObject = null;
				for (EditMerchandiseList edit : editMerchandiseLists) {
					jsonObject = new JSONObject();
					jsonObject.put("editMerchandiseListId", edit.getEditMerchandiseListId());
					jsonObject.put("disPicUrl",
							edit.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1]
									.split(",")[0] + ".jpg" + "}");
					jsonObject.put("editMerchandiseListName", edit.getEditMerchandiseListName());
					jsonObject.put("editMerchandiseListPrice", edit.getEditMerchandiseListPrice());
					jsonObject.put("salesCount", edit.getSalesCount());
					jsonArray.add(jsonObject);
				}

				Tips.put("SOURCE", jsonArray);
				return SUCCESS;
			}

			Tips.put("STATUS", "ERROR");
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;

	}

	public void prepareQueryMerchandiseByEditMerchandiseListName() {
		baseModel = new EditMerchandiseList();
	}

	// 下载--返回到result中，在本类中用result接受
	@Action(value = "downloadMerdinse")
	public String downloadFile() {

		return "download";

	}

	public void prepareDownloadFile() {
		baseModel = new EditMerchandiseList();
	}

	// 商品订单载入
	@Action(value = "queryInfo", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String queryOrder() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null || editMerchandiseList.getMerchantPhone() == null) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}

			// 分页
			editMerchandiseList.setCount(10);
			editMerchandiseList.setStarCount(editMerchandiseList.getStarPage() == 0 ? 0
					: (editMerchandiseList.getStarPage() - 1) * editMerchandiseList.getCount());

			// 设置组队
			editMerchandiseList.setOrderSign("3");

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListByPhone(editMerchandiseList);

			if (editMerchandiseLists == null) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			JSONArray jsonArray = new JSONArray();

			for (EditMerchandiseList eList : editMerchandiseLists) {
				String shopperPhones = eList.getShopperPhone();

				if (shopperPhones == null) {
					continue;

				}

				if (shopperPhones.indexOf(",") > -1) {

					for (String shopper : shopperPhones.split(",")) {

						if (StringUtils.isEmpty(shopper)) {
							continue;
						}
						JSONObject jsonObject = new JSONObject();

						jsonObject.put("merchandiseId", eList.getEditMerchandiseListId());
						jsonObject.put("customerPicUrl",
								eList.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1]
										.split(",")[0] + ".jpg");

						jsonObject.put("customerPhone", shopper.split("_")[0]);
						jsonObject.put("customerDate", shopper.split("_")[1]);
						jsonObject.put("customerOrder", shopper.split("_")[2]);
						jsonObject.put("customerStatus", shopper.split("_")[3]);

						jsonArray.add(jsonObject);
					}

				} else if (!"".equals(shopperPhones.trim())) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("merchandiseId", eList.getEditMerchandiseListId());
					jsonObject.put("customerPicUrl",
							eList.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1]
									.split(",")[0] + ".jpg");
					jsonObject.put("customerPhone", shopperPhones.split("_")[0]);
					jsonObject.put("customerDate", shopperPhones.split("_")[1]);
					jsonObject.put("customerOrder", shopperPhones.split("_")[2]);
					jsonObject.put("customerStatus", shopperPhones.split("_")[3]);
					jsonArray.add(jsonObject);
				}
			}

			// 返回订单数目
			int orderStaCount = 0;
			int orderRunCount = 0;
			int orderRefCount = 0;
			// 增加返回的订单总条数
			editMerchandiseLists = editMerchandiseListService.findToltalOrderByPhone(editMerchandiseList);

			for (EditMerchandiseList eLi : editMerchandiseLists) {
				if (StringUtils.isEmpty(eLi.getShopperPhone())) {
					continue;
				}

				if (eLi.getShopperPhone().indexOf(",") > -1) {
					String[] arr = eLi.getShopperPhone().split(",");

					for (String str : arr) {
						if (StringUtils.isEmpty(str)) {
							continue;
						}

						if (str.indexOf("start") > -1) {
							orderStaCount++;
						} else if (str.indexOf("run") > -1) {
							orderRunCount++;
						} else if (str.indexOf("refund") > -1) {
							orderRefCount++;
						}

					}
				} else {

					if (eLi.getShopperPhone().indexOf("start") > -1) {
						orderStaCount++;
					} else if (eLi.getShopperPhone().indexOf("run") > -1) {
						orderRunCount++;
					} else if (eLi.getShopperPhone().indexOf("refund") > -1) {
						orderRefCount++;
					}

				}

			}

			Tips.put("STATUS", "OK");
			Tips.put("SOURCE", jsonArray);
			JSONArray array = new JSONArray();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("orderStaCount", orderStaCount);
			jsonObject.put("orderRunCount", orderRunCount);
			jsonObject.put("orderRefCount", orderRefCount);
			array.add(jsonObject);
			Tips.put("COUNT", array);
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;
	}

	public void prepareQueryOrder() {
		baseModel = new EditMerchandiseList();
	}

	// 商品订单发货
	@Action(value = "sendOrderInfo", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String sendOrderInfo() {

		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null
					|| editMerchandiseList.getEditMerchandiseListId() == 0 && fileName == null && !editMerchandiseList
							.getShopperPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}
			if (fileUrl == null) {
				fileUrl = "";
			}

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListById(editMerchandiseList);

			if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}
			String shopperPhones = editMerchandiseLists.get(0).getShopperPhone();
			String customerPhone = editMerchandiseList.getShopperPhone();
			if (StringUtils.isEmpty(shopperPhones)) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}
			if (shopperPhones.equals(customerPhone)) {
				Tips.put("STATUS", "OWNER");
				return SUCCESS;

			}
			// 13856368932_1453347408557_20160121402881ea526233b9015262418aad0001_start_"测试"*15924179758*"浙江省杭州市"*3*1*88
			String replaceRun = fileName + "_run";
			List<String> merchantStrs = null;
			// List<String> customerStrs = null;
			if (shopperPhones != null && shopperPhones.indexOf(editMerchandiseList.getShopperPhone()) > -1
					&& shopperPhones.indexOf(fileName) > -1) {
				if (shopperPhones.indexOf(",") > -1) {

					merchantStrs = new ArrayList<String>(Arrays.asList(shopperPhones.split(",")));

					for (int i = 0; i < merchantStrs.size(); i++) {
						String str = merchantStrs.get(i).trim();

						if (str.indexOf(fileName) > -1) {
							merchantStrs.remove(merchantStrs.get(i));
							merchantStrs.add(customerPhone + "_" + str.split("_")[1] + "_" + replaceRun + "_"
									+ str.split("_")[4] + "_" + editMerchandiseList.getSequence() + "_" + fileUrl);
						}

					}

					editMerchandiseList.setShopperPhone(
							merchantStrs.toString().replace("[", "").replace("]", "").replace(" ", ""));

				} else {
					editMerchandiseList.setShopperPhone(customerPhone + "_" + shopperPhones.split("_")[1] + "_"
							+ replaceRun + "_" + shopperPhones.split("_")[4] + "_" + editMerchandiseList.getSequence()
							+ "_" + fileUrl);
				}

				int count = editMerchandiseListService.updateEditMerchandiseListByOrder(editMerchandiseList);

				if (count == 0) {
					Tips.put("STATUS", "ERROR");
					return SUCCESS;
				}

			}
			/*
			 * editMerchandiseListId 所要发货商品的id fileName 发货产生的订单编号 shopperPhone
			 * 发货对应的买家的手机号 fileUrl 发货的物流编号 sequence 物流或物流的名称 merchantPhone
			 * 所要订单发货的商家的手机号 loginKey App传递参数
			 */
			// where isDeleted='0' and orderPhone=#{orderPhone} and orderNumber
			// =#{orderNumber} and orderTime = #{orderTime}

			// 买家订单状态--改变
			CustomerOrder customerOrder = new CustomerOrder();
			customerOrder.setOrderPhone(customerPhone);
			customerOrder.setOrderNumber(fileName);
			customerOrder.setMerchandiseId(editMerchandiseList.getEditMerchandiseListId());
			customerOrder = customerOrderService.findOrderByOrderNumberAndOrderTime(customerOrder);
			if (customerOrder == null) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			if (StringUtils.isNotEmpty(fileUrl)) {
				customerOrder.setOrderStream(fileUrl);
			}
			if (StringUtils.isNotEmpty(editMerchandiseList.getSequence())) {
				customerOrder.setOrderEms(editMerchandiseList.getSequence());
			}
			customerOrder.setOperateTime(new Date());
			customerOrder.setOrderStatus("run");
			// 更新数据库
			int is_success = customerOrderService.updateCustomerOrderById(customerOrder);
			if (is_success == 0) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			// changeTwo
			// Customer customer = new Customer();
			// customer.setShopperPhone(customerPhone);
			// List<Customer> customers =
			// customerService.queryCustomerByShopperPhone(customer);
			//
			// if (customers != null && customers.size() != 0) {
			//
			// String orderInfos = customers.get(0).getOrderInfos();
			// if ((customers != null && customers.size() != 0)
			// && (orderInfos != null && orderInfos.indexOf(fileName) > -1)) {
			//
			// if (orderInfos.indexOf(",") > -1) {
			// customerStrs = new
			// ArrayList<String>(Arrays.asList(orderInfos.split(",")));
			//
			// for (int i = 0; i < customerStrs.size(); i++) {
			// String str = customerStrs.get(i).trim();
			//
			// if (str.indexOf(fileName) > -1) {
			// customerStrs.remove(customerStrs.get(i));
			// customerStrs.add(editMerchandiseLists.get(0).getEditMerchandiseListId()
			// + "_"
			// + replaceRun + "_" + fileUrl + "_" +
			// editMerchandiseList.getSequence());
			// }
			//
			// }
			//
			// customer.setOrderInfos(
			// customerStrs.toString().replace("[", "").replace("]",
			// "").replace(" ", ""));
			// } else {
			// customer.setOrderInfos(editMerchandiseLists.get(0).getEditMerchandiseListId()
			// + "_" + replaceRun
			// + "_" + fileUrl + "_" + editMerchandiseList.getSequence());
			// }
			//
			// int is_succss =
			// customerService.updateCustomerByShopperPhone(customer);
			//
			// if (is_succss == 0) {
			// Tips.put("STATUS", "ERROR");
			// return SUCCESS;
			// }
			//
			// }
			//
			// }

			// 启动定时任务---7天后自定确定收货
			Timer timer = new Timer();
			final EditMerchandiseList eList = editMerchandiseList;
			final String fileNames = fileName;
			final String fileUrls = fileUrl;
			final String customerPhones = customerPhone;
			TimerTask timerTask = new TimerTask() {

				@Override
				public void run() {
					changeEval(eList, fileNames, fileUrls, customerPhones);
				}
			};
			timer.schedule(timerTask, 1000 * 60 * 60 * 24 * 7);

			Tips.put("STATUS", "OK");
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;

	}

	public void prepareSendOrderInfo() {
		baseModel = new EditMerchandiseList();
	}

	// 定时任务，改变确实收货功能
	public void changeEval(EditMerchandiseList editMerchandiseList, String fileNames, String fileUrls,
			String customerPhones) {

		if (editMerchandiseList == null || editMerchandiseList.getEditMerchandiseListId() == 0 && fileNames == null
				&& !editMerchandiseList.getShopperPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			return;

		}
		if (fileUrls == null) {
			fileUrls = "";
		}

		List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
				.queryEditMerchandiseListById(editMerchandiseList);

		if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
			return;
		}
		String shopperPhones = editMerchandiseLists.get(0).getShopperPhone();

		if (shopperPhones.equals(customerPhones)) {
			return;

		}

		String replaceRun = fileNames + "_end";
		List<String> merchantStrs = null;
		// List<String> customerStrs = null;
		if (shopperPhones != null && shopperPhones.indexOf(editMerchandiseList.getShopperPhone()) > -1
				&& shopperPhones.indexOf(fileNames) > -1) {
			if (shopperPhones.indexOf(",") > -1) {

				merchantStrs = new ArrayList<String>(Arrays.asList(shopperPhones.split(",")));

				for (int i = 0; i < merchantStrs.size(); i++) {
					String str = merchantStrs.get(i).trim();

					if (str.indexOf(fileNames) > -1) {
						merchantStrs.remove(merchantStrs.get(i));
						merchantStrs.add(customerPhones + "_" + str.split("_")[1] + "_" + replaceRun + "_"
								+ editMerchandiseList.getSequence() + "_" + fileUrls);
					}

				}

				editMerchandiseList
						.setShopperPhone(merchantStrs.toString().replace("[", "").replace("]", "").replace(" ", ""));

			} else {
				editMerchandiseList.setShopperPhone(customerPhones + "_" + shopperPhones.split("_")[1] + "_"
						+ replaceRun + "_" + editMerchandiseList.getSequence() + "_" + fileUrls);
			}

			int count = editMerchandiseListService.updateEditMerchandiseListByOrder(editMerchandiseList);

			if (count == 0) {
				return;
			}

		}

		// 买家端修改订单状态
		// 买家订单状态--改变
		CustomerOrder customerOrder = new CustomerOrder();
		customerOrder.setOrderPhone(customerPhones);
		customerOrder.setOrderNumber(fileNames);
		customerOrder.setMerchandiseId(editMerchandiseList.getEditMerchandiseListId());
		customerOrder = customerOrderService.findOrderByOrderNumberAndOrderTime(customerOrder);
		if (customerOrder == null) {
			return;
		}

		if (StringUtils.isNotEmpty(fileUrls)) {
			customerOrder.setOrderStream(fileUrls);
		}
		if (StringUtils.isNotEmpty(editMerchandiseList.getSequence())) {
			customerOrder.setOrderEms(editMerchandiseList.getSequence());
		}
		customerOrder.setOperateTime(new Date());
		customerOrder.setOrderStatus("end");
		// 更新数据库
		int is_success = customerOrderService.updateCustomerOrderById(customerOrder);
		if (is_success == 0) {
			return;
		}
		// // changeTwo
		// Customer customer = new Customer();
		// customer.setShopperPhone(customerPhones);
		// List<Customer> customers =
		// customerService.queryCustomerByShopperPhone(customer);
		//
		// if (customers != null && customers.size() != 0) {
		//
		// String orderInfos = customers.get(0).getOrderInfos();
		// if ((customers != null && customers.size() != 0)
		// && (orderInfos != null && orderInfos.indexOf(fileNames) > -1)) {
		//
		// if (orderInfos.indexOf(",") > -1) {
		// customerStrs = new
		// ArrayList<String>(Arrays.asList(orderInfos.split(",")));
		//
		// for (int i = 0; i < customerStrs.size(); i++) {
		// String str = customerStrs.get(i).trim();
		//
		// if (str.indexOf(fileNames) > -1) {
		// customerStrs.remove(customerStrs.get(i));
		// customerStrs.add(editMerchandiseLists.get(0).getEditMerchandiseListId()
		// + "_" + replaceRun
		// + "_" + fileUrls + "_" + editMerchandiseList.getSequence());
		// }
		//
		// }
		//
		// customer.setOrderInfos(customerStrs.toString().replace("[",
		// "").replace("]", "").replace(" ", ""));
		// } else {
		// customer.setOrderInfos(editMerchandiseLists.get(0).getEditMerchandiseListId()
		// + "_" + replaceRun
		// + "_" + fileUrls + "_" + editMerchandiseList.getSequence());
		// }
		//
		// customerService.updateCustomerByShopperPhone(customer);
		//
		// }
		//
		// }

		return;

	}

	// 商品推荐查询
	@Action(value = "queryRecommondPic", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String queryRecommondPic() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null || !editMerchandiseList.getMerchantPhone()
					.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryRecommondPicByPhone(editMerchandiseList);

			if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}
			String recordURl = "";
			for (EditMerchandiseList eList : editMerchandiseLists) {
				recordURl = eList.getEditMerchandiseRecordUrl();

				if (recordURl == null || recordURl.equals("")) {
					continue;

				}

				JSONObject jsonObject = new JSONObject();
				jsonObject.put("recommdId", eList.getEditMerchandiseListId());
				jsonObject.put("recommdPic",
						eList.getEditMerchandiseRecordUrl().replace("[", "").replace("]", "").split("&")[1]
								.split(",")[0]);

				Tips.put("STATUS", "OK");
				Tips.put("SOURCE", jsonObject);
				return SUCCESS;
			}
			Tips.put("STATUS", "EMPTY");
		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;
	}

	public void prepareQueryRecommondPic() {
		baseModel = new EditMerchandiseList();
	}

	// 订单详情查看
	@Action(value = "queryOrderInfo", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String queryOrderInfo() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null || !editMerchandiseList.getMerchantPhone()
					.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListById(editMerchandiseList);

			if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			EditMerchandiseList eList = editMerchandiseLists.get(0);
			JSONObject jsonObject = new JSONObject();

			String info = eList.getShopperPhone();
			if (StringUtils.isEmpty(info)) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			String[] orderInfos = null;

			if (info.indexOf(",") > -1) {
				orderInfos = info.split(",");
			} else {
				orderInfos = new String[] { info };
			}
			// 15924179757_1453188189593_20160119402881e85258b62c015258c40d9a0007_run_小洛*15924179757*杭州_申通快递_123456789
			// 13856368932_1453256465406_20160120402881ea525cca2a01525cd5dbfe0009_end__小洛*15924179757*杭州_申通快递_test
			for (String str : orderInfos) {
				if (StringUtils.isEmpty(str)) {
					continue;
				}

				// 移动客户端传入的订单编号
				if (str.indexOf(editMerchandiseList.getOrderSign()) > -1) {
					String[] orderS = str.split("_");
					// 判断发货时间
					if ("end".equals(orderS[3])) {
						jsonObject.put("orderStatus", "end");
						jsonObject.put("orderDatemine", "over");
					} else if ("start".equals(orderS[3])) {
						jsonObject.put("orderStatus", "start");
						jsonObject.put("orderDatemine", "");
					} else {
						Date nowDate = new Date();
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(new Date(Long.valueOf(orderS[1])));
						calendar.add(Calendar.DAY_OF_YEAR, 7);
						Date sendDate = calendar.getTime();
						if (nowDate.after(sendDate)) {
							jsonObject.put("orderStatus", "end");
							jsonObject.put("orderDatemine", "over");
						} else {
							long days = (sendDate.getTime() - nowDate.getTime()) / (1000 * 60 * 60 * 24);
							long hours = (sendDate.getTime() - nowDate.getTime() - days * 1000 * 60 * 60 * 24)
									/ (1000 * 60 * 60);
							long miutes = (sendDate.getTime() - nowDate.getTime() - days * 1000 * 60 * 60 * 24
									- hours * 1000 * 60 * 60) / (1000 * 60);

							jsonObject.put("orderStatus", orderS[3]);
							jsonObject.put("orderDatemine", days + "天" + hours + "小时" + miutes + "分");
						}
					}
					// 重新更改订单查询的详情---从表中customerOrder中-------------------------------------------------------------------------
					CustomerOrder customerOrder = new CustomerOrder();
					customerOrder.setOrderPhone(orderS[0]);
					customerOrder.setOrderNumber(orderS[2]);
					// 防止客户删掉评论这边查看不到，就把isDeleted设置为1
					customerOrder.setIsDeleted("1");
					customerOrder.setMerchandiseId(editMerchandiseList.getEditMerchandiseListId());
					customerOrder = customerOrderService.findOrderByOrderNumberAndOrderTime(customerOrder);
					if (customerOrder == null) {
						Tips.put("STATUS", "ERROR");
						return SUCCESS;
					}
					jsonObject.put("orderEms", StringUtils.isEmpty(customerOrder.getOrderEms()) == true ? ""
							: customerOrder.getOrderEms());
					jsonObject.put("orderStream", StringUtils.isEmpty(customerOrder.getOrderStream()) == true ? ""
							: customerOrder.getOrderStream());
					jsonObject.put("orderCusName", StringUtils.isEmpty(customerOrder.getOrderCusName()) == true ? ""
							: customerOrder.getOrderCusName());
					jsonObject.put("orderCusPhone", StringUtils.isEmpty(customerOrder.getOrderCusPhone()) == true ? ""
							: customerOrder.getOrderCusPhone());
					jsonObject.put("orderCusAddress", StringUtils.isEmpty(customerOrder.getOrderCusAddress()) == true
							? "" : customerOrder.getOrderCusAddress());
					jsonObject.put("orderMeCount", StringUtils.isEmpty(customerOrder.getOrderMeCount()) == true ? ""
							: customerOrder.getOrderMeCount());
					jsonObject.put("orderMePayTra", StringUtils.isEmpty(customerOrder.getOrderMePayTra()) == true ? ""
							: customerOrder.getOrderMePayTra());
					jsonObject.put("orderMePayMed", StringUtils.isEmpty(customerOrder.getOrderMePayMed()) == true ? ""
							: customerOrder.getOrderMePayMed());
					String path = eList.getEditMerchandiseListDisPicsUrl().split("&")[1].replace("[", "").replace("]",
							"");
					if (path.indexOf(",") > -1) {
						path = path.split(",")[0];
					}
					jsonObject.put("orderMeDisPic",
							"?id=" + eList.getEditMerchandiseListId() + "&name=" + path + ".jpg");
					jsonObject.put("orderMeName", eList.getEditMerchandiseListName());
					jsonObject.put("orderMePrice", eList.getEditMerchandiseListPrice());
					jsonObject.put("orderNumber", orderS[2]);
					jsonObject.put("orderPhone", orderS[0]);
					jsonObject.put("orderTime", orderS[1]);
					// -----------------------------------------------------------------------------------------------------------------------
					//
					// if (orderS.length > 6) {
					// jsonObject.put("orderEms", orderS[5]);
					// jsonObject.put("orderStream", orderS[6]);
					// } else {
					// jsonObject.put("orderEms", "");
					// jsonObject.put("orderStream", "");
					// }
					// String[] customerInfos = orderS[4].split("\\*");
					// if (customerInfos.length > 2) {
					//
					// jsonObject.put("orderCusName", customerInfos[0]);
					// jsonObject.put("orderCusPhone", customerInfos[1]);
					// jsonObject.put("orderCusAddress", customerInfos[2]);
					// jsonObject.put("orderMeCount", customerInfos[3]);
					// jsonObject.put("orderMePayTra",
					// customerInfos[4].equals("0") == true ? "" :
					// customerInfos[4]);
					// jsonObject.put("orderMePayMed", customerInfos[5]);
					// } else {
					//
					// jsonObject.put("orderCusName", "");
					// jsonObject.put("orderCusPhone", "");
					// jsonObject.put("orderCusAddress", "");
					// }
					// String path =
					// eList.getEditMerchandiseListDisPicsUrl().split("&")[1].replace("[",
					// "").replace("]",
					// "");
					// if (path.indexOf(",") > -1) {
					// path = path.split(",")[0];
					// }
					// jsonObject.put("orderMeDisPic",
					// "?id=" + eList.getEditMerchandiseListId() + "&name=" +
					// path + ".jpg");
					// jsonObject.put("orderMeName",
					// eList.getEditMerchandiseListName());
					// jsonObject.put("orderMePrice",
					// eList.getEditMerchandiseListPrice());
					// jsonObject.put("orderMeCount", "");
					// jsonObject.put("orderMePayTra", "");
					// jsonObject.put("orderMePayMed", "");
					// jsonObject.put("orderNumber", orderS[2]);
					// jsonObject.put("orderPhone", orderS[0]);
					// jsonObject.put("orderTime", orderS[1]);

				}
			}

			Tips.put("STATUS", "OK");
			Tips.put("SOURCE", jsonObject);
			return SUCCESS;

		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;
	}

	public void prepareQueryOrderInfo() {
		baseModel = new EditMerchandiseList();
	}

	// 订单物流号修改
	@Action(value = "updateOrderNumber", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String updateOrderNumber() {
		try {
			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
			if (editMerchandiseList == null
					|| !editMerchandiseList.getMerchantPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")
					|| StringUtils.isEmpty(editMerchandiseList.getShopperPhone()) || !editMerchandiseList
							.getCustomerPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
				Tips.put("STATUS", "FORBID");
				return SUCCESS;

			}

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListService
					.queryEditMerchandiseListById(editMerchandiseList);

			if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			EditMerchandiseList eList = editMerchandiseLists.get(0);

			String info = eList.getShopperPhone();
			if (StringUtils.isEmpty(info)) {
				Tips.put("STATUS", "ERROR");
				return SUCCESS;
			}

			String[] orderInfos = null;

			if (info.indexOf(",") > -1) {
				orderInfos = info.split(",");
			} else {
				orderInfos = new String[] { info };
			}

			String newInfo = "";

			// 13856368932_1453365717550_20160121402881ea526358ea01526358ea2f0000_run_"测试"*15924179758*"浙江省杭州市"*3*6*88_申通快递_test
			for (String str : orderInfos) {
				// 移动客户端传入的订单编号--shopper原来订单时间，ordersifn原来的订单号
				if (str.indexOf(editMerchandiseList.getShopperPhone()) > -1
						&& str.indexOf(editMerchandiseList.getOrderSign()) > -1) {
					str = str.replace(editMerchandiseList.getCustomerName() + "_" + editMerchandiseList.getSequence(),
							editMerchandiseList.getCustomerAddress() + "_" + editMerchandiseList.getIsRecommond());
				}
				newInfo += str + ",";

			}
			editMerchandiseList.setShopperPhone(newInfo);

			try {
				editMerchandiseListService.updateEditMerchandiseListByOrder(editMerchandiseList);

				// changeTwo,客户端修改
				Customer customer = new Customer();
				customer.setShopperPhone(editMerchandiseList.getCustomerPhone());
				List<Customer> customers = customerService.queryCustomerByShopperPhone(customer);
				// 114_20160119402881e85258b62c015258bda4c50002_start_申通快递_10010
				// 需要保存的订单号
				String infos = "";
				if ((customers != null && customers.size() != 0)) {
					// String cusInfos = customers.get(0).getOrderInfos();
					// if (cusInfos != null && !"".equals(cusInfos)) {
					//
					// if (cusInfos.indexOf(",") > -1) {
					// String[] arr = cusInfos.split(",");
					// for (String str : arr) {
					//
					// if (str.indexOf(editMerchandiseList.getOrderSign()) > -1
					// &&
					// str.indexOf(editMerchandiseList.getEditMerchandiseListId())
					// > -1) {
					// str = str.replace(
					// editMerchandiseList.getCustomerName() + "_"
					// + editMerchandiseList.getSequence(),
					// editMerchandiseList.getCustomerAddress() + "_"
					// + editMerchandiseList.getIsRecommond());
					// }
					// infos += str + ",";
					// }
					// }
					//
					// customer.setOrderInfos(infos);
					//
					// int is_succss =
					// customerService.updateCustomerByShopperPhone(customer);
					//
					// if (is_succss == 0) {
					// Tips.put("STATUS", "ERROR");
					// return SUCCESS;
					// }
					// }
					// 买家订单信息修改-----------------------------------------------------------------------------
					/*
					 * orderPhone=#{orderPhone} and orderNumber =#{orderNumber}
					 * and merchandiseId = #{merchandiseId} merchantPhone
					 * 所要订单载入的商家的手机号
					 * 
					 * customerPhone 商品订货人的手机号 orderSign 商品订单的订单号 shopperPhone
					 * 订单的时间 sequence 商家的原来的物流号 isRecommond 商品的修改的物流号
					 * customerName 商品的原来的快递或物流公司名称 customerAddress 修改的快递或物流公司名称
					 * editMerchandiseListId 商品的id
					 */

					CustomerOrder customerOrder = new CustomerOrder();
					customerOrder.setOrderPhone(editMerchandiseList.getCustomerPhone());
					customerOrder.setOrderNumber(editMerchandiseList.getOrderSign());
					customerOrder.setMerchandiseId(editMerchandiseList.getEditMerchandiseListId());
					customerOrder = customerOrderService.findOrderByOrderNumberAndOrderTime(customerOrder);
					if (customerOrder == null) {
						Tips.put("STATUS", "ERROR");
						return SUCCESS;
					}

					if (StringUtils.isNotEmpty(editMerchandiseList.getCustomerAddress())) {
						customerOrder.setOrderEms(editMerchandiseList.getCustomerAddress());
					}
					if (StringUtils.isNotEmpty(editMerchandiseList.getIsRecommond())) {
						customerOrder.setOrderStream(editMerchandiseList.getIsRecommond());
					}
					customerOrder.setOperateTime(new Date());
					// 更新数据库
					int is_success = customerOrderService.updateCustomerOrderById(customerOrder);
					if (is_success == 0) {
						Tips.put("STATUS", "ERROR");
						return SUCCESS;
					}
					// ------------------------------------------------------------------------
				} else {
					Tips.put("STATUS", "EMPTY");

				}

			} catch (Exception e) {
				Tips.put("STATUS", "ERROR");
			}

			Tips.put("STATUS", "OK");

			return SUCCESS;

		} catch (RuntimeException e) {
			Tips.put("STATUS", "KEY_ERROR");
		}
		return SUCCESS;
	}

	public void prepareUpdateOrderNumber() {
		baseModel = new EditMerchandiseList();
	}

	// 测试
	@Action(value = "test")
	public String test() {
		System.out.println("..........");

		return null;

	}

	public static void main(String[] args) {
		String string = "13856368932_1453256465406_20160120402881ea525cca2a01525cd5dbfe0009_start_'测试'*15924179758*'浙江省杭州市'*3*1*88_1234";

		string = string.replace("_1234", "_1235466");

		System.out.println(string);
	}

}
