package com.xiaoluo.spring_struts2.Merchant.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.Merchant.dao.CustomerOrderDao;
import com.xiaoluo.spring_struts2.Merchant.entity.CustomerOrder;
import com.xiaoluo.spring_struts2.mapper.CustomerOrderMapper;

@Transactional
@Repository
public class CustomerOrderImpl implements CustomerOrderDao {
	@Resource
	private CustomerOrderMapper customerOrderMapper;

	@Override
	public int createCustomerOrder(CustomerOrder customerOrder) {

		return customerOrderMapper.createCustomerOrder(customerOrder);
	}

	@Override
	public CustomerOrder findOrderByOrderNumberAndOrderTime(CustomerOrder customerOrder) {

		return customerOrderMapper.findOrderById(customerOrder);
	}

	@Override
	public int updateCustomerOrderById(CustomerOrder customerOrder) {

		return customerOrderMapper.updateCustomerOrderById(customerOrder);
	}

	@Override
	public List<CustomerOrder> queryAllByPhone(CustomerOrder customerOrder) {

		return customerOrderMapper.queryAllByPhone(customerOrder);
	}

	@Override
	public List<CustomerOrder> querySatatusCountAllByPhone(CustomerOrder customerOrder) {

		return customerOrderMapper.querySatatusCountAllByPhone(customerOrder);
	}
}
