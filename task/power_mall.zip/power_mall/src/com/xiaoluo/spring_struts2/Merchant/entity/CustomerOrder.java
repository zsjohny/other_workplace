package com.xiaoluo.spring_struts2.Merchant.entity;

import java.util.Date;

import com.xiaoluo.spring_struts2.base.BaseModel;

public class CustomerOrder implements BaseModel {

	private Integer customerOrderId;
	private Integer merchandiseId;
	private String orderStatus; // 为每个买家对应的订单状态：start是待发货，run是已发货 ，end是已确定收货
	private String orderDatemine;// 为每个买家对应的订单倒数时间,over是已经确定收货了,其余例如6天19小时23分--截取分钟倒计时
	private String orderEms;// 商品发货物流或快递公司
	private String orderStream; // 商品发货物流
	private String orderCusName; // 收货人姓名
	private String orderCusPhone; // 收货人手机
	private String orderCusAddress;// 收货人地址
	private String orderMeDisPic; // 商品展示图片地址
	private String orderMeName;// 商品的名称
	private String orderMePrice; // 商品的价格
	private String orderMeCount; // 商品的单价
	private String orderMePayTra;// 商品的运费
	private String orderMePayMed; // 商品的支付金额
	private String orderNumber; // 商品的订单号
	private String orderPhone; // 商品的订货人手机号
	private String orderTime; // 为每个买家购买的时间
	private String isDeleted;
	private Date creatTime;
	private Date operateTime;

	// 不是数据库的字段
	private int starCount;
	private int count;

	public int getStarCount() {
		return starCount;
	}

	public void setStarCount(int starCount) {
		this.starCount = starCount;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Integer getMerchandiseId() {
		return merchandiseId;
	}

	public void setMerchandiseId(Integer merchandiseId) {
		this.merchandiseId = merchandiseId;
	}

	public Integer getCustomerOrderId() {
		return customerOrderId;
	}

	public void setCustomerOrderId(Integer customerOrderId) {
		this.customerOrderId = customerOrderId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderDatemine() {
		return orderDatemine;
	}

	public void setOrderDatemine(String orderDatemine) {
		this.orderDatemine = orderDatemine;
	}

	public String getOrderEms() {
		return orderEms;
	}

	public void setOrderEms(String orderEms) {
		this.orderEms = orderEms;
	}

	public String getOrderStream() {
		return orderStream;
	}

	public void setOrderStream(String orderStream) {
		this.orderStream = orderStream;
	}

	public String getOrderCusName() {
		return orderCusName;
	}

	public void setOrderCusName(String orderCusName) {
		this.orderCusName = orderCusName;
	}

	public String getOrderCusPhone() {
		return orderCusPhone;
	}

	public void setOrderCusPhone(String orderCusPhone) {
		this.orderCusPhone = orderCusPhone;
	}

	public String getOrderCusAddress() {
		return orderCusAddress;
	}

	public void setOrderCusAddress(String orderCusAddress) {
		this.orderCusAddress = orderCusAddress;
	}

	public String getOrderMeDisPic() {
		return orderMeDisPic;
	}

	public void setOrderMeDisPic(String orderMeDisPic) {
		this.orderMeDisPic = orderMeDisPic;
	}

	public String getOrderMeName() {
		return orderMeName;
	}

	public void setOrderMeName(String orderMeName) {
		this.orderMeName = orderMeName;
	}

	public String getOrderMePrice() {
		return orderMePrice;
	}

	public void setOrderMePrice(String orderMePrice) {
		this.orderMePrice = orderMePrice;
	}

	public String getOrderMeCount() {
		return orderMeCount;
	}

	public void setOrderMeCount(String orderMeCount) {
		this.orderMeCount = orderMeCount;
	}

	public String getOrderMePayTra() {
		return orderMePayTra;
	}

	public void setOrderMePayTra(String orderMePayTra) {
		this.orderMePayTra = orderMePayTra;
	}

	public String getOrderMePayMed() {
		return orderMePayMed;
	}

	public void setOrderMePayMed(String orderMePayMed) {
		this.orderMePayMed = orderMePayMed;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderPhone() {
		return orderPhone;
	}

	public void setOrderPhone(String orderPhone) {
		this.orderPhone = orderPhone;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Date getCreatTime() {
		return creatTime;
	}

	public void setCreatTime(Date creatTime) {
		this.creatTime = creatTime;
	}

	public Date getOperateTime() {
		return operateTime;
	}

	public void setOperateTime(Date operateTime) {
		this.operateTime = operateTime;
	}

}
