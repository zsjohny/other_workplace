/**
 * 
 */
package com.xiaoluo.spring_struts2.Merchant.service;

import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserService.java, 2015年11月23日 下午3:40:22
 */

public interface MerchantService {
	int merchantLogin(Merchant merchant);

	Merchant queryMerchantByMerchantPhone(Merchant merchant);

	void addMerchant(Merchant merchant);

	void merchantValidate(Merchant merchant);

	int updateMerchantByMerchantPhone(Merchant merchant);

	int resetMerchantValidateCount(Merchant merchant);

	Merchant checkIsRegistByPhone(Merchant merchant);

	int updateMerchantByUpload(Merchant merchant);

	int updateMerchantByLoginKey(Merchant merchant);

	Merchant queryMerchantById(int id);
}
