/**
 * 
 */
package com.xiaoluo.spring_struts2.Merchant.dao;

import java.util.List;

import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserDao.java, 2015年11月23日 下午4:15:46
 */

public interface MerchantDao {
	int merchantLogin(Merchant merchant);

	Merchant queryMerchantByMerchantPhone(Merchant merchant);

	void addMerchant(Merchant merchant);

	void merchantValidate(Merchant merchant);

	int updateMerchantByMerchantPhone(Merchant merchant);

	int resetMerchantValidateCount(Merchant merchant);

	Merchant checkIsRegistByPhone(Merchant merchant);

	int updateMerchantByUpload(Merchant merchant);

	int updateMerchantByLoginKey(Merchant merchant);

	List<Merchant> queryMerchantByArea(Merchant merchant);

	Merchant queryMerchantById(int id);
}
