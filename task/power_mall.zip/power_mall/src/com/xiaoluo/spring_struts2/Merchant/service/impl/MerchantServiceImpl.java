/**
 * 
 */
package com.xiaoluo.spring_struts2.Merchant.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;
import com.xiaoluo.spring_struts2.Merchant.service.MerchantService;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserServiceImpl.java, 2015年11月23日 下午3:40:35
 */
@Service
@Transactional
public class MerchantServiceImpl implements MerchantService {
	@Resource
	private MerchantDao merchantDao;

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int merchantLogin(Merchant merchant) {
		return merchantDao.merchantLogin(merchant);

	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public Merchant queryMerchantByMerchantPhone(Merchant merchant) {

		return merchantDao.queryMerchantByMerchantPhone(merchant);

	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void addMerchant(Merchant merchant) {
		merchantDao.addMerchant(merchant);

	}

	@Override
	public void merchantValidate(Merchant merchant) {
		merchantDao.merchantValidate(merchant);

	}

	@Override
	public int updateMerchantByMerchantPhone(Merchant merchant) {
		return merchantDao.updateMerchantByMerchantPhone(merchant);
	}

	@Override
	public int resetMerchantValidateCount(Merchant merchant) {

		return merchantDao.resetMerchantValidateCount(merchant);
	}

	@Override
	public Merchant checkIsRegistByPhone(Merchant merchant) {

		return merchantDao.checkIsRegistByPhone(merchant);
	}

	@Override
	public int updateMerchantByUpload(Merchant merchant) {

		return merchantDao.updateMerchantByUpload(merchant);
	}

	@Override
	public int updateMerchantByLoginKey(Merchant merchant) {

		return merchantDao.updateMerchantByLoginKey(merchant);
	}

	@Override
	public Merchant queryMerchantById(int id) {

		return merchantDao.queryMerchantById(id);
	}

}
