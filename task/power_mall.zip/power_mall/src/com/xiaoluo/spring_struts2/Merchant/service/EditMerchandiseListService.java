package com.xiaoluo.spring_struts2.Merchant.service;

import java.util.List;

import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;

public interface EditMerchandiseListService {
	void createEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryEditMerchandiseListByPhone(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryMerchandiseByEditMerchandiseListName(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListBySalesCount(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListByOrder(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryRecommondPicByPhone(EditMerchandiseList editMerchandiseList);

	int deleteEditMerchandiseListByMerchantPhone(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> findToltalOrderByPhone(EditMerchandiseList editMerchandiseList);
}
