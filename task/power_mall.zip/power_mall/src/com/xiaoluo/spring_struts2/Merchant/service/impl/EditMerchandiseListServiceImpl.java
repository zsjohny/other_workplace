package com.xiaoluo.spring_struts2.Merchant.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.Merchant.dao.EditMerchandiseListDao;
import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.service.EditMerchandiseListService;

@Service
@Transactional
public class EditMerchandiseListServiceImpl implements EditMerchandiseListService {
	@Resource
	private EditMerchandiseListDao editMerchandiseListDao;

	@Override
	public void createEditMerchandiseListById(EditMerchandiseList editMerchandiseList) {
		editMerchandiseListDao.createEditMerchandiseListById(editMerchandiseList);

	}

	@Override
	public List<EditMerchandiseList> queryEditMerchandiseListById(EditMerchandiseList editMerchandiseList) {

		if (editMerchandiseList.getEditMerchandiseListId() == null) {
			return null;
		}
		List<EditMerchandiseList> list = editMerchandiseListDao.queryEditMerchandiseListById(editMerchandiseList);
		return list;
	}

	@Override
	public int updateEditMerchandiseListById(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListDao.updateEditMerchandiseListById(editMerchandiseList);

	}

	@Override
	public int deleteEditMerchandiseListByMerchantPhone(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListDao.deleteEditMerchandiseListByMerchantPhone(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> queryEditMerchandiseListByPhone(EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListDao.queryEditMerchandiseListByPhone(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> queryMerchandiseByEditMerchandiseListName(
			EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListDao.queryMerchandiseByEditMerchandiseListName(editMerchandiseList);
	}

	@Override
	public int updateEditMerchandiseListBySalesCount(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListDao.updateEditMerchandiseListBySalesCount(editMerchandiseList);
	}

	@Override
	public int updateEditMerchandiseListByOrder(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListDao.updateEditMerchandiseListByOrder(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> queryRecommondPicByPhone(EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListDao.queryRecommondPicByPhone(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> findToltalOrderByPhone(EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListDao.findToltalOrderByPhone(editMerchandiseList);
	}

}
