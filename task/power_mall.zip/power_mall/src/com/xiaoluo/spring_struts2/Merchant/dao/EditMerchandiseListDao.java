package com.xiaoluo.spring_struts2.Merchant.dao;

import java.util.List;

import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

public interface EditMerchandiseListDao {
	void createEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListById(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryEditMerchandiseListByPhone(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryMerchandiseByEditMerchandiseListName(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListBySalesCount(EditMerchandiseList editMerchandiseList);

	int updateEditMerchandiseListByOrder(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> queryRecommondPicByPhone(EditMerchandiseList editMerchandiseList);

	int deleteEditMerchandiseListByMerchantPhone(EditMerchandiseList editMerchandiseList);

	List<EditMerchandiseList> findLocalMerchandiseByPhone(List<String> list, Merchant merchant);

	List<EditMerchandiseList> findToltalOrderByPhone(EditMerchandiseList editMerchandiseList);
}
