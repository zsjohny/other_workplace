package com.xiaoluo.spring_struts2.Merchant.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.xiaoluo.spring_struts2.Merchant.dao.EditMerchandiseListDao;
import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;
import com.xiaoluo.spring_struts2.mapper.EditMerchandiseListMapper;

@Transactional
@Repository
public class EditMerchandiseListDaoImpl implements EditMerchandiseListDao {
	@Resource
	private EditMerchandiseListMapper editMerchandiseListMapper;

	@Override
	public void createEditMerchandiseListById(EditMerchandiseList editMerchandiseList) {
		editMerchandiseListMapper.createEditMerchandiseListById(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> queryEditMerchandiseListById(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListMapper.queryEditMerchandiseListById(editMerchandiseList.getEditMerchandiseListId());
	}

	@Override
	public int updateEditMerchandiseListById(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListMapper.updateEditMerchandiseListById(editMerchandiseList);

	}

	@Override
	public int deleteEditMerchandiseListByMerchantPhone(EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListMapper
				.deleteEditMerchandiseListByMerchantPhone(editMerchandiseList.getMerchantPhone());
	}

	@Override
	public List<EditMerchandiseList> queryEditMerchandiseListByPhone(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListMapper.queryEditMerchandiseListByPhone(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> queryMerchandiseByEditMerchandiseListName(
			EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListMapper.queryMerchandiseByEditMerchandiseListName(editMerchandiseList);
	}

	@Override
	public int updateEditMerchandiseListBySalesCount(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListMapper.updateEditMerchandiseListBySalesCount(editMerchandiseList);
	}

	@Override
	public int updateEditMerchandiseListByOrder(EditMerchandiseList editMerchandiseList) {
		return editMerchandiseListMapper.updateEditMerchandiseListByOrder(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> queryRecommondPicByPhone(EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListMapper.queryRecommondPicByPhone(editMerchandiseList);
	}

	@Override
	public List<EditMerchandiseList> findLocalMerchandiseByPhone(List<String> list, Merchant merchant) {

		return editMerchandiseListMapper.findLocalMerchandiseByPhone(list, merchant);
	}

	@Override
	public List<EditMerchandiseList> findToltalOrderByPhone(EditMerchandiseList editMerchandiseList) {

		return editMerchandiseListMapper.findToltalOrderByPhone(editMerchandiseList);
	}

}
