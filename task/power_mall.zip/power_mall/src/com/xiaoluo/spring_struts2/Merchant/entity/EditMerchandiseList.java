package com.xiaoluo.spring_struts2.Merchant.entity;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import com.xiaoluo.spring_struts2.base.BaseModel;

public class EditMerchandiseList implements BaseModel {

	private Integer editMerchandiseListId;
	private String merchantPhone;
	private String editMerchandiseListDisPicsUrl;// (列表详情的展示图片)
	private String editMerchandiseListName;// (列表详情的名称)
	private double editMerchandiseListPrice;// (列表详情的价格)
	private int editMerchandiseListStock;// (列表详情的库存)
	private String editMerchandiseListIsPost;// (列表详情的是否包邮)=ture or false
	private String editMerchandiseListProductDesc;// (列表详情的产品描述)
	private String editMerchandiseListDesPicsUrl;// (列表详情的描述图片)
	private String is_deledted;
	private String merchantFloderName;
	private String editMerchandiseRecordUrl;
	private String loginKey;

	private int starPage;
	private int starCount;
	private int count;
	private String orderSign;
	private String sequence;

	private int salesCount;

	private String shopperPhone;
	private String isRecommond;

	private String customerName;
	private String customerPhone;
	private String customerAddress;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getIsRecommond() {
		return isRecommond;
	}

	public void setIsRecommond(String isRecommond) {
		this.isRecommond = isRecommond;
	}

	public String getSequence() {
		return sequence;
	}

	public String getLoginKey() {
		return loginKey;
	}

	public void setLoginKey(String loginKey) {
		this.loginKey = loginKey;
	}

	public String getEditMerchandiseRecordUrl() {
		return editMerchandiseRecordUrl;
	}

	public void setEditMerchandiseRecordUrl(String editMerchandiseRecordUrl) {
		this.editMerchandiseRecordUrl = editMerchandiseRecordUrl;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public String getShopperPhone() {
		return shopperPhone;
	}

	public void setShopperPhone(String shopperPhone) {
		this.shopperPhone = shopperPhone;
	}

	public int getSalesCount() {
		return salesCount;
	}

	public void setSalesCount(int salesCount) {
		this.salesCount = salesCount;
	}

	public String getOrderSign() {
		return orderSign;
	}

	public void setOrderSign(String orderSign) {
		if (orderSign.trim().equals("")) {
			this.orderSign = null;
			return;
		}
		this.orderSign = orderSign;
	}

	public int getStarCount() {
		return starCount;
	}

	public void setStarCount(int starCount) {
		this.starCount = starCount;
	}

	public String getMerchantFloderName() {
		return merchantFloderName;
	}

	public int getStarPage() {
		return starPage;
	}

	public void setStarPage(int starPage) {
		this.starPage = starPage;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public void setMerchantFloderName(String merchantFloderName) {
		this.merchantFloderName = merchantFloderName;
	}

	public String getIs_deledted() {
		return is_deledted;
	}

	public void setIs_deledted(String is_deledted) {
		this.is_deledted = is_deledted;
	}

	public Integer getEditMerchandiseListId() {
		return editMerchandiseListId;
	}

	public void setEditMerchandiseListId(Integer editMerchandiseListId) {
		this.editMerchandiseListId = editMerchandiseListId;
	}

	public String getMerchantPhone() {
		return merchantPhone;
	}

	public void setMerchantPhone(String merchantPhone) {
		this.merchantPhone = merchantPhone;
	}

	public String getEditMerchandiseListDisPicsUrl() {
		return editMerchandiseListDisPicsUrl;
	}

	public void setEditMerchandiseListDisPicsUrl(String editMerchandiseListDisPicsUrl) {
		this.editMerchandiseListDisPicsUrl = editMerchandiseListDisPicsUrl;
	}

	public String getEditMerchandiseListName() {
		return editMerchandiseListName;
	}

	public void setEditMerchandiseListName(String editMerchandiseListName) {
		this.editMerchandiseListName = editMerchandiseListName;
	}

	public double getEditMerchandiseListPrice() {
		return editMerchandiseListPrice;
	}

	public void setEditMerchandiseListPrice(double editMerchandiseListPrice) {
		this.editMerchandiseListPrice = editMerchandiseListPrice;
	}

	public int getEditMerchandiseListStock() {
		return editMerchandiseListStock;
	}

	public void setEditMerchandiseListStock(int editMerchandiseListStock) {
		this.editMerchandiseListStock = editMerchandiseListStock;
	}

	public String getEditMerchandiseListIsPost() {
		return editMerchandiseListIsPost;
	}

	public void setEditMerchandiseListIsPost(String editMerchandiseListIsPost) {
		this.editMerchandiseListIsPost = editMerchandiseListIsPost;
	}

	public String getEditMerchandiseListProductDesc() {
		return editMerchandiseListProductDesc;
	}

	public void setEditMerchandiseListProductDesc(String editMerchandiseListProductDesc) {
		// 测试
		try {
			this.editMerchandiseListProductDesc = URLDecoder.decode(editMerchandiseListProductDesc, "utf-8");
		} catch (UnsupportedEncodingException e) {
		}
	}

	public String getEditMerchandiseListDesPicsUrl() {
		return editMerchandiseListDesPicsUrl;
	}

	public void setEditMerchandiseListDesPicsUrl(String editMerchandiseListDesPicsUrl) {
		this.editMerchandiseListDesPicsUrl = editMerchandiseListDesPicsUrl;
	}

	public static void main(String[] args) {
		System.out.println(System.currentTimeMillis());
	}
}
