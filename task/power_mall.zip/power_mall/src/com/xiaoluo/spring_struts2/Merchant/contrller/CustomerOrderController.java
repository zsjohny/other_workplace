package com.xiaoluo.spring_struts2.Merchant.contrller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.xiaoluo.spring_struts2.Merchant.dao.EditMerchandiseListDao;
import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.CustomerOrder;
import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;
import com.xiaoluo.spring_struts2.Merchant.service.CustomerOrderService;
import com.xiaoluo.spring_struts2.base.BaseController;
import com.xiaoluo.spring_struts2.customer.service.CustomerService;
import com.xiaoluo.spring_struts2.util.Log4jUtil;
import com.xiaoluo.spring_struts2.util.UUIDGenerator;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@ParentPackage("json-default")
@Namespace("/customerOrder")
public class CustomerOrderController extends BaseController {
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	@Resource
	private EditMerchandiseListDao editMerchandiseListDao;
	@Resource
	private MerchantDao merchantDao;
	@Resource
	private CustomerService customerService;
	@Resource
	private CustomerOrderService customerOrderService;
	Logger logger = Log4jUtil.init(EditMerchandiseListController.class);
	private Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {

		this.id = id;
	}

	private Integer code;

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public Map<String, Object> Tips = new HashMap<String, Object>();

	@Action(value = "saleCount", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String salesCount() {
		EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
		if (editMerchandiseList == null || editMerchandiseList.getEditMerchandiseListId() == 0) {
			Tips.put("STATUS", "FORBID");
			return SUCCESS;

		}
		if (editMerchandiseList.getMerchantPhone() == null
				|| !editMerchandiseList.getMerchantPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			Tips.put("STATUS", "FORBID");
			return SUCCESS;
		}

		List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
				.queryEditMerchandiseListById(editMerchandiseList);

		if (editMerchandiseLists == null) {
			Tips.put("STATUS", "ERROR");
			return SUCCESS;
		}

		if (editMerchandiseLists.size() == 0) {
			Tips.put("STATUS", "EMPTY");
			return SUCCESS;
		}

		if (editMerchandiseLists.get(0).getMerchantPhone().equals(editMerchandiseList.getMerchantPhone())) {
			Tips.put("STATUS", "OWNER");
			return SUCCESS;
		}

		int stockCount = editMerchandiseLists.get(0).getEditMerchandiseListStock();

		if (stockCount == 0) {
			Tips.put("STATUS", "SALEEMPTY");
			return SUCCESS;
		}
		double payCount = editMerchandiseList.getEditMerchandiseListPrice();
		double payTra = editMerchandiseList.getSalesCount();
		editMerchandiseList.setEditMerchandiseListStock(--stockCount);
		int salesCount = editMerchandiseLists.get(0).getSalesCount();
		editMerchandiseList.setSalesCount(++salesCount);
		// oderInfo
		String shopperPhone = editMerchandiseLists.get(0).getShopperPhone();

		if (shopperPhone != null && !"".equals(shopperPhone.trim())) {
			shopperPhone += ",";
		} else {
			shopperPhone = "";
		}
		long secondes = System.currentTimeMillis();
		String signId = new SimpleDateFormat("yyyyMMdd").format(new Date(secondes)) + UUIDGenerator.generate();

		shopperPhone += editMerchandiseList.getMerchantPhone() + "_" + secondes + "_" + signId + "_start" + "_"
				+ editMerchandiseList.getCustomerName() + "*" + editMerchandiseList.getCustomerPhone() + "*"
				+ editMerchandiseList.getCustomerAddress() + "*" + editMerchandiseList.getCount() + "*"
				+ editMerchandiseList.getSalesCount() + "*" + editMerchandiseList.getStarCount();

		editMerchandiseList.setShopperPhone(shopperPhone);

		// **********************存入到用户的信息列表中,需要修正**********************

		// Customer customer = new Customer();
		// customer.setShopperPhone(editMerchandiseList.getMerchantPhone());
		// List<Customer> customers =
		// customerService.queryCustomerByShopperPhone(customer);
		//
		// if ((customers != null && customers.size() != 0)) {
		// String orderInfos = customers.get(0).getOrderInfos();
		// if (orderInfos != null && !"".equals(orderInfos)) {
		//
		// customer.setOrderInfos(orderInfos + "," +
		// editMerchandiseLists.get(0).getEditMerchandiseListId() + "_"
		// + signId + "_start");
		// } else {
		//
		// customer.setOrderInfos(
		// editMerchandiseLists.get(0).getEditMerchandiseListId() + "_" + signId
		// + "_start");
		// }
		// }
		// int is_succss =
		// customerService.updateCustomerByShopperPhone(customer);
		//
		// if (is_succss == 0) {
		// Tips.put("STATUS", "ERROR");
		// return SUCCESS;
		// }
		// 修正买家订单下载后存在买家端的信息-------------------------------------------------------------------------
		/*
		 * editMerchandiseListId 所要对应的下单商品的id
		 * 
		 * merchantPhone 买家对应的电话号码
		 * 
		 * customerName 收货人的姓名 customerPhone 收货人的手机 customerAddress 收货人的地址
		 * 
		 * count 购买的个数 salesCount 购买的运费 starCount 支付的金钱数
		 */

		CustomerOrder customerOrder = new CustomerOrder();
		customerOrder.setCreatTime(new Date());
		customerOrder.setIsDeleted("0");
		customerOrder.setOrderStatus("start");
		customerOrder.setOrderCusAddress(editMerchandiseList.getCustomerAddress());
		customerOrder.setOrderCusName(editMerchandiseList.getCustomerName());
		customerOrder.setOrderCusPhone(editMerchandiseList.getCustomerPhone());
		customerOrder.setOrderMeCount(editMerchandiseList.getCount() + "");
		customerOrder.setOrderMePayTra(payTra + "");
		customerOrder.setOrderMePayMed(payCount + "");
		customerOrder.setMerchandiseId(editMerchandiseList.getEditMerchandiseListId());
		customerOrder.setOrderNumber(signId);
		customerOrder.setOrderPhone(editMerchandiseList.getMerchantPhone());
		customerOrder.setOrderTime(secondes + "");
		int is_succss = customerOrderService.createCustomerOrder(customerOrder);
		if (is_succss == 0) {
			Tips.put("STATUS", "ERROR");
			return SUCCESS;
		}

		// --------------------------------------------------------------------------------------------------------
try{
		int count = editMerchandiseListDao.updateEditMerchandiseListBySalesCount(editMerchandiseList);

		if (count == 0) {
			Tips.put("STATUS", "ERROR");
			return SUCCESS;
		}
}catch(Exception e){
System.out.println(e.getMessage());
}
		Tips.put("STATUS", "OK");
		return SUCCESS;

	}

	public void prepareSalesCount() {
		baseModel = new EditMerchandiseList();
	}

	@Action(value = "findMerchandise", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String findMerchandise() {

		Merchant merchant = (Merchant) baseModel;

		if (merchant == null) {
			Tips.put("status", 302);// 参数填写不正确

			return SUCCESS;
		}
		JSONArray jsonArray = new JSONArray();
		List<Merchant> queryMerchantByArea = merchantDao.queryMerchantByArea(merchant);

		if (queryMerchantByArea == null | queryMerchantByArea.size() == 0) {
			// Tips.put("status", 301);// 查询为空
			Tips.put("status", 300);// 状态ok
			Tips.put("source", jsonArray);// 资源

			return SUCCESS;
		}
		List<String> list = new ArrayList<>();
		for (Merchant me : queryMerchantByArea) {
			list.add(me.getMerchantLoginPhone());
		}

		merchant.setCount(10);

		merchant.setStarCount((merchant.getStarPage() - 1) * merchant.getCount());

		List<EditMerchandiseList> findLocalMerchandiseByPhone = editMerchandiseListDao.findLocalMerchandiseByPhone(list,
				merchant);
		if (findLocalMerchandiseByPhone == null | findLocalMerchandiseByPhone.size() == 0) {
			// Tips.put("status", 301);// 查询为空
			Tips.put("status", 300);// 状态ok
			Tips.put("source", jsonArray);// 资源

			return SUCCESS;
		}

		JSONObject jsonObject = null;
		for (EditMerchandiseList edit : findLocalMerchandiseByPhone) {
			jsonObject = new JSONObject();
			jsonObject.put("editMerchandiseListId", edit.getEditMerchandiseListId());
			String disPicUrl = edit.getEditMerchandiseListDisPicsUrl().replace("[", "").replace("]", "").split("&")[1];
			JSONArray array = new JSONArray();
			if (disPicUrl.indexOf(",") > -1) {

				String[] arr = disPicUrl.split(",");
				for (String str : arr) {
					disPicUrl = str;
					array.add("?picName=" + disPicUrl + "&picId=" + edit.getEditMerchandiseListId());
				}
				jsonObject.put("disPicUrl", array);
			} else {
				array.add("?picName=" + disPicUrl + "&picId=" + edit.getEditMerchandiseListId());
				jsonObject.put("disPicUrl", array);
			}

			// jsonObject.put("status", edit.getIsRecommond());
			jsonObject.put("editMerchandiseListName", edit.getEditMerchandiseListName());
			jsonObject.put("editMerchandiseListPrice", edit.getEditMerchandiseListPrice());
			jsonObject.put("editMerchandiseListIsPost", edit.getEditMerchandiseListIsPost());
			jsonObject.put("salesCount", edit.getSalesCount());
			jsonArray.add(jsonObject);
		}

		Tips.put("status", 300);// 状态ok
		Tips.put("source", jsonArray);// 资源

		return SUCCESS;

	}

	public void prepareFindMerchandise() {
		baseModel = new Merchant();
	}

	@Action(value = "disLocalMerchandisePic", results = @Result(name = "success", type = "json", params = { "root",
			"Tips", "ignoreHierarchy", "false" }) )
	public void disLocalMerchandisePic() {
		Merchant merchant = (Merchant) baseModel;

		if (merchant == null || StringUtils.isEmpty(merchant.getPicName()) || StringUtils.isEmpty(merchant.getPicId())
				|| !merchant.getPicId().matches("^\\d+$")) {
			Tips.put("status", 302);// 参数填写不正确

			return;
		}
		EditMerchandiseList editMerchandiseList = new EditMerchandiseList();
		editMerchandiseList.setEditMerchandiseListId(Integer.parseInt(merchant.getPicId()));
		List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
				.queryEditMerchandiseListById(editMerchandiseList);

		if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
			Tips.put("status", 302);// 查询为空

			return;
		}

		try (BufferedOutputStream bos = new BufferedOutputStream(ServletActionContext.getResponse().getOutputStream());
				BufferedInputStream bis = new BufferedInputStream(
						new FileInputStream(new File(editMerchandiseLists.get(0).getEditMerchandiseListDisPicsUrl()
								.replace("[", "").replace("]", "").split("&")[0], merchant.getPicName() + ".jpg")))) {

			byte[] bs = new byte[1024];
			int len = 0;
			while ((len = bis.read(bs)) != -1) {
				bos.write(bs, 0, len);
			}

		} catch (Exception e) {
		}

		return;

	}

	public void prepareDisLocalMerchandisePic() {
		baseModel = new Merchant();
	}

	// 查询快递所有的快递公司
	@Action(value = "findEmsAll", results = @Result(name = "success", type = "json", params = { "root", "Tips",
			"ignoreHierarchy", "false" }) )
	public String findEmsAll() {
		Properties properties = new Properties();
		JSONArray jsonArray = new JSONArray();
		try {
			properties.load(CustomerOrderController.class.getResourceAsStream("/ems.properties"));
			Enumeration<?> propertyNames = properties.propertyNames();
			while (propertyNames.hasMoreElements()) {
				Object nextElement = propertyNames.nextElement();
				String name = (String) nextElement;
				jsonArray.add(properties.getProperty(name));
			}
		} catch (Exception e) {
			Tips.put("ems", "error");
			return SUCCESS;
		}

		Tips.put("ems", jsonArray);

		return SUCCESS;
	}

	// 买家确定收货
	@Action(value = "sureReviced", results = @Result(name = "success", type = "json", params = { "root", "Tips",
			"ignoreHierarchy", "false" }) )
	public String sureReviced() {
		EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;
		if (editMerchandiseList == null || editMerchandiseList.getEditMerchandiseListId() == 0
				&& editMerchandiseList.getCustomerName() == null
				&& !editMerchandiseList.getShopperPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			Tips.put("status", 302);
			return SUCCESS;

		}

		if (editMerchandiseList == null || editMerchandiseList.getEditMerchandiseListId() == 0
				&& editMerchandiseList.getCustomerName() == null
				&& !editMerchandiseList.getShopperPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			Tips.put("status", 302);
			return SUCCESS;

		}

		/*
		 * editMerchandiseListId 确定收货商品的id customerName 确定收货的订单编号 shopperPhone
		 * 确定收货的买家的手机号 merchantFloderName 确定收货的物流编号 sequence 物流或物流的名称
		 * merchantPhone 确定收货的商家的手机号
		 */

		String customerPhone = editMerchandiseList.getShopperPhone();

		if (editMerchandiseList.getMerchantFloderName() == null) {
			editMerchandiseList.setMerchantFloderName("");
		}

		List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
				.queryEditMerchandiseListById(editMerchandiseList);

		if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
			Tips.put("status", 301);
			return SUCCESS;
		}
		String shopperPhones = editMerchandiseLists.get(0).getShopperPhone();

		if (shopperPhones.equals(editMerchandiseList.getShopperPhone())) {
			Tips.put("status", 301);
			return SUCCESS;

		}

		String replaceRun = customerPhone + "_" + editMerchandiseList.getIs_deledted() + "_"
				+ editMerchandiseList.getCustomerName();
		// List<String> merchantStrs = null;
		// List<String> customerStrs = null;
		if (shopperPhones != null && shopperPhones.indexOf(editMerchandiseList.getShopperPhone()) > -1
				&& shopperPhones.indexOf(editMerchandiseList.getCustomerName()) > -1
				&& shopperPhones.indexOf(editMerchandiseList.getIs_deledted()) > -1) {
			/*
			 * if (shopperPhones.indexOf(",") > -1) {
			 * 
			 * merchantStrs = new
			 * ArrayList<String>(Arrays.asList(shopperPhones.split(",")));
			 * 
			 * for (int i = 0; i < merchantStrs.size(); i++) { String str =
			 * merchantStrs.get(i).trim();
			 * 
			 * if (str.indexOf(editMerchandiseList.getCustomerName()) > -1) {
			 * merchantStrs.remove(merchantStrs.get(i));
			 * merchantStrs.add(editMerchandiseList.getShopperPhone() + "_" +
			 * str.split("_")[1] + "_" + replaceRun + "_" +
			 * editMerchandiseList.getSequence() + "_" +
			 * editMerchandiseList.getMerchantFloderName()); }
			 * 
			 * }
			 * 
			 * editMerchandiseList
			 * .setShopperPhone(merchantStrs.toString().replace("[",
			 * "").replace("]", "").replace(" ", ""));
			 * 
			 * } else { editMerchandiseList.setShopperPhone(editMerchandiseList.
			 * getShopperPhone() + "_" + shopperPhones.split("_")[1] + "_" +
			 * replaceRun + "_" + editMerchandiseList.getSequence() + "_" +
			 * editMerchandiseList.getMerchantFloderName()); }
			 */

			editMerchandiseList.setShopperPhone(shopperPhones.replace(replaceRun + "_run", replaceRun + "_end"));
			int count = editMerchandiseListDao.updateEditMerchandiseListByOrder(editMerchandiseList);

			if (count == 0) {
				Tips.put("status", 301);
				return SUCCESS;
			}

		}

		// 买家端修改订单状态
		// 买家订单状态--改变
		CustomerOrder customerOrder = new CustomerOrder();
		customerOrder.setOrderPhone(customerPhone);
		customerOrder.setOrderNumber(editMerchandiseList.getCustomerName());
		customerOrder.setMerchandiseId(editMerchandiseList.getEditMerchandiseListId());
		customerOrder = customerOrderService.findOrderByOrderNumberAndOrderTime(customerOrder);
		if (customerOrder == null) {
			Tips.put("status", 301);
			return SUCCESS;
		}

		customerOrder.setOperateTime(new Date());
		customerOrder.setOrderStatus("end");
		// 更新数据库
		int is_success = customerOrderService.updateCustomerOrderById(customerOrder);
		if (is_success == 0) {
			Tips.put("status", 301);
			return SUCCESS;
		}
		// // changeTwo
		// Customer customer = new Customer();
		// customer.setShopperPhone(editMerchandiseList.getShopperPhone());
		// List<Customer> customers =
		// customerService.queryCustomerByShopperPhone(customer);
		//
		// if (customers != null && customers.size() != 0) {
		//
		// String orderInfos = customers.get(0).getOrderInfos();
		// if ((customers != null && customers.size() != 0)
		// && (orderInfos != null &&
		// orderInfos.indexOf(editMerchandiseList.getCustomerName()) > -1)) {
		//
		// if (orderInfos.indexOf(",") > -1) {
		// customerStrs = new
		// ArrayList<String>(Arrays.asList(orderInfos.split(",")));
		//
		// for (int i = 0; i < customerStrs.size(); i++) {
		// String str = customerStrs.get(i).trim();
		//
		// if (str.indexOf(editMerchandiseList.getCustomerName()) > -1) {
		// customerStrs.remove(customerStrs.get(i));
		// customerStrs.add(editMerchandiseLists.get(0).getEditMerchandiseListId()
		// + "_" + replaceRun
		// + "_" + editMerchandiseList.getMerchantFloderName() + "_" +
		// editMerchandiseList.getSequence());
		// }
		//
		// }
		//
		// customer.setOrderInfos(customerStrs.toString().replace("[",
		// "").replace("]", "").replace(" ", ""));
		// } else {
		// customer.setOrderInfos(editMerchandiseLists.get(0).getEditMerchandiseListId()
		// + "_" + replaceRun
		// + "_" + editMerchandiseList.getMerchantFloderName() + "_" +
		// editMerchandiseList.getSequence());
		// }
		//
		// customerService.updateCustomerByShopperPhone(customer);
		//
		// }
		//
		// }
		Tips.put("status", 300);
		return SUCCESS;

	}

	public void prepareSureReviced() {
		baseModel = new EditMerchandiseList();
	}

	// 买家订单删除
	@Action(value = "deleteOrder", results = @Result(name = "success", type = "json", params = { "root", "Tips",
			"ignoreHierarchy", "false" }) )
	public String deleteOrder() {
		CustomerOrder customerOrder = (CustomerOrder) baseModel;
		if (customerOrder == null || customerOrder.getMerchandiseId() == 0
				&& !customerOrder.getOrderPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			Tips.put("status", 302);
			return SUCCESS;

		}

		customerOrder = customerOrderService.findOrderByOrderNumberAndOrderTime(customerOrder);
		if (customerOrder == null) {
			Tips.put("status", 301);
			return SUCCESS;
		}

		customerOrder.setOperateTime(new Date());
		customerOrder.setIsDeleted("1");
		// 更新数据库
		int is_success = customerOrderService.updateCustomerOrderById(customerOrder);
		if (is_success == 0) {
			Tips.put("status", 301);
			return SUCCESS;
		}

		Tips.put("status", 300);
		return SUCCESS;

	}

	public void prepareDeleteOrder() {
		baseModel = new CustomerOrder();
	}

	// 买家订单加载
	@Action(value = "loadOrder", results = @Result(name = "success", type = "json", params = { "root", "Tips",
			"ignoreHierarchy", "false" }) )
	public String loadOrder() {
		CustomerOrder customerOrder = (CustomerOrder) baseModel;
		if (customerOrder == null
				|| !customerOrder.getOrderPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			Tips.put("status", 302);
			return SUCCESS;

		}

		customerOrder.setCount(10);
		customerOrder.setStarCount(
				customerOrder.getStarCount() <= 0 ? 0 : (customerOrder.getStarCount() - 1) * customerOrder.getCount());

		List<CustomerOrder> cList = customerOrderService.queryAllByPhone(customerOrder);
		if (cList == null || cList.size() == 0) {
			Tips.put("status", 301);
			return SUCCESS;
		}
		JSONObject jsonObject = null;
		JSONArray jsonArray = new JSONArray();
		for (CustomerOrder cOrder : cList) {

			EditMerchandiseList editMerchandiseList = new EditMerchandiseList();
			editMerchandiseList.setEditMerchandiseListId(cOrder.getMerchandiseId());
			List<EditMerchandiseList> queryEditMerchandiseListById = editMerchandiseListDao
					.queryEditMerchandiseListById(editMerchandiseList);
			editMerchandiseList = queryEditMerchandiseListById.get(0);
			if (queryEditMerchandiseListById == null || queryEditMerchandiseListById.size() == 0) {
				continue;
			}
			jsonObject = new JSONObject();

			if ("end".equals(cOrder.getOrderStatus())) {
				jsonObject.put("orderStatus", "end");
				jsonObject.put("orderDatemine", "over");
			} else if ("start".equals(cOrder.getOrderStatus())) {
				jsonObject.put("orderStatus", "start");
				jsonObject.put("orderDatemine", "");
			} else {
				Date nowDate = new Date();
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(new Date(Long.valueOf(cOrder.getOrderTime())));
				calendar.add(Calendar.DAY_OF_YEAR, 7);
				Date sendDate = calendar.getTime();
				if (nowDate.after(sendDate)) {
					jsonObject.put("orderStatus", "end");
					jsonObject.put("orderDatemine", "over");
				} else {
					long days = (sendDate.getTime() - nowDate.getTime()) / (1000 * 60 * 60 * 24);
					long hours = (sendDate.getTime() - nowDate.getTime() - days * 1000 * 60 * 60 * 24)
							/ (1000 * 60 * 60);
					long miutes = (sendDate.getTime() - nowDate.getTime() - days * 1000 * 60 * 60 * 24
							- hours * 1000 * 60 * 60) / (1000 * 60);

					jsonObject.put("orderStatus", cOrder.getOrderStatus());
					jsonObject.put("orderDatemine", days + "天" + hours + "小时" + miutes + "分");
				}
			}

			jsonObject.put("orderEms", StringUtils.isEmpty(cOrder.getOrderEms()) == true ? "" : cOrder.getOrderEms());
			jsonObject.put("orderStream",
					StringUtils.isEmpty(cOrder.getOrderStream()) == true ? "" : cOrder.getOrderStream());
			jsonObject.put("orderCusName",
					StringUtils.isEmpty(cOrder.getOrderCusName()) == true ? "" : cOrder.getOrderCusName());
			jsonObject.put("orderCusPhone",
					StringUtils.isEmpty(cOrder.getOrderCusPhone()) == true ? "" : cOrder.getOrderCusPhone());
			jsonObject.put("orderCusAddress",
					StringUtils.isEmpty(cOrder.getOrderCusAddress()) == true ? "" : cOrder.getOrderCusAddress());
			jsonObject.put("orderMeCount",
					StringUtils.isEmpty(cOrder.getOrderMeCount()) == true ? "" : cOrder.getOrderMeCount());
			jsonObject.put("orderMePayTra",
					StringUtils.isEmpty(cOrder.getOrderMePayTra()) == true ? "" : cOrder.getOrderMePayTra());
			jsonObject.put("orderMePayMed",
					StringUtils.isEmpty(cOrder.getOrderMePayMed()) == true ? "" : cOrder.getOrderMePayMed());

			String path = editMerchandiseList.getEditMerchandiseListDisPicsUrl().split("&")[1].replace("[", "")
					.replace("]", "");
			if (path.indexOf(",") > -1) {
				path = path.split(",")[0];
			}
			jsonObject.put("orderMeDisPic",
					"?id=" + editMerchandiseList.getEditMerchandiseListId() + "&name=" + path + ".jpg");
			jsonObject.put("orderMeName", editMerchandiseList.getEditMerchandiseListName());
			jsonObject.put("orderMePrice", editMerchandiseList.getEditMerchandiseListPrice());
			jsonObject.put("orderNumber",
					StringUtils.isEmpty(cOrder.getOrderNumber()) == true ? "" : cOrder.getOrderNumber());
			jsonObject.put("orderPhone",
					StringUtils.isEmpty(cOrder.getOrderPhone()) == true ? "" : cOrder.getOrderPhone());
			jsonObject.put("orderTime",
					StringUtils.isEmpty(cOrder.getOrderTime()) == true ? "" : cOrder.getOrderTime());

			jsonArray.add(jsonObject);
		}

		// 增加各种状态的数量
		cList = customerOrderService.querySatatusCountAllByPhone(customerOrder);
		if (cList == null || cList.size() == 0) {
			Tips.put("status", 301);
			return SUCCESS;
		}
		int starCount = 0;
		int runCount = 0;
		int endCount = 0;

		for (CustomerOrder cOrder : cList) {
			if (cOrder == null) {
				continue;
			}

			if ("start".equals(cOrder.getOrderStatus())) {
				starCount++;
			} else if ("run".equals(cOrder.getOrderStatus())) {
				runCount++;
			} else if ("end".equals(cOrder.getOrderStatus())) {
				endCount++;
			}

		}
		jsonObject = new JSONObject();
		jsonObject.put("starCount", starCount);
		jsonObject.put("runCount", runCount);
		jsonObject.put("endCount", endCount);

		Tips.put("status", 300);
		Tips.put("source", jsonArray);
		Tips.put("count", jsonObject);
		return SUCCESS;

	}

	public void prepareLoadOrder() {
		baseModel = new CustomerOrder();
	}

	// // 买家进入商家店铺

	// 商家的商品的总加载
	@Action(value = "merchandiseLoad", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String merchandiseLoad() {
		try {

			if (id == null) {
				Tips.put("STATUS", 302);
				return SUCCESS;
			}

			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) baseModel;

			if (editMerchandiseList == null
					|| (editMerchandiseList.getSequence() == null && editMerchandiseList.getOrderSign() == null)) {
				Tips.put("STATUS", 302);
				return SUCCESS;

			}
			// 设置参数
			Merchant merchant = merchantDao.queryMerchantById(id);
			editMerchandiseList.setMerchantPhone(merchant.getMerchantLoginPhone());
			// 分页
			editMerchandiseList.setCount(10);
			editMerchandiseList.setStarCount(editMerchandiseList.getStarPage() == 0 ? 0
					: (editMerchandiseList.getStarPage() - 1) * editMerchandiseList.getCount());

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
					.queryEditMerchandiseListByPhone(editMerchandiseList);

			if (editMerchandiseLists.size() > 0) {
				Tips.put("status", 300);

				/*
				 * List<String> disUrls = new ArrayList<String>(); List<String>
				 * desUrls = new ArrayList<String>();
				 */
				JSONArray jsonArray = new JSONArray();
				JSONObject jsonObject = null;
				JSONArray jsonArrayList = new JSONArray();
				for (EditMerchandiseList edit : editMerchandiseLists) {

					// 加载图片
					String disUrl = edit.getEditMerchandiseListDisPicsUrl();
					String desUrl = edit.getEditMerchandiseListDesPicsUrl();
					/*
					 * JSONArray disPicArr = null; JSONArray desPicArr = null;
					 */
					String disPathFis = "";
					String desPathFis = "";
					if (disUrl != null) {

						String disPath = disUrl.replace("[", "").replace("]", "").split("&")[1];
						String[] disArr = null;

						if (disPath.indexOf(",") > -1) {
							disArr = disPath.split(",");

							disPathFis = "?id=" + edit.getEditMerchandiseListId() + "&name=" + disArr[0].trim()
									+ ".jpg";
									/*
									 * for (String str : disArr) {
									 * 
									 * disUrls.add("?id=" +
									 * edit.getEditMerchandiseListId() +
									 * "&name=" + str.trim() + ".jpg");
									 * 
									 * }
									 */

							// Tips.put("DISURL", disUrls);
						} else {
							/* disPicArr = new JSONArray(); */
							disPathFis = "?id=" + edit.getEditMerchandiseListId() + "&name=" + disPath.trim() + ".jpg";
							// Tips.put("DISURL", disPicArr);

						}

					} else {
						/*
						 * disPicArr = new JSONArray(); disPicArr.add("");
						 */
						disPathFis = "";
						// Tips.put("DISURL", disPicArr);
					}

					if (desUrl != null) {
						String desPath = desUrl.replace("[", "").replace("]", "").split("&")[1];
						String[] desArr = null;

						if (desPath.indexOf(",") > -1) {

							desArr = desPath.split(",");
							desPathFis = "?id=" + edit.getEditMerchandiseListId() + "&name=" + desArr[0].trim()
									+ ".jpg";

							/*
							 * for (String str : desArr) {
							 * 
							 * desUrls.add("?id=" +
							 * edit.getEditMerchandiseListId() + "&name=" +
							 * str.trim() + ".jpg"); }
							 */

							// Tips.put("DESURL", desUrls);
						} else {
							desPathFis = "?id=" + edit.getEditMerchandiseListId() + "&name=" + desPath.trim() + ".jpg";
							// Tips.put("DESURL", disPicArr);
						}

					} else {
						/*
						 * desPicArr = new JSONArray(); desPicArr.add("");
						 */
						desPathFis = "";
						// Tips.put("DESURL", disPicArr);
					}

					jsonObject = new JSONObject();
					jsonObject.put("editMerchandiseListId", edit.getEditMerchandiseListId());
					jsonObject.put("disPicUrl", disPathFis);
					jsonObject.put("desPicUrl", desPathFis);
					jsonObject.put("editMerchandiseListName", edit.getEditMerchandiseListName());
					jsonObject.put("editMerchandiseListPrice", edit.getEditMerchandiseListPrice());
					jsonObject.put("salesCount", edit.getSalesCount());
					jsonArrayList.add(jsonObject);
					if (jsonArrayList.size() == 2) {
						jsonArray.add(jsonArrayList);
						jsonArrayList = new JSONArray();
					}
				}
				Tips.put("SOURCE", jsonArray);

				return SUCCESS;
			}

			Tips.put("status", 301);
		} catch (Exception e) {
			Tips.put("status", 301);
		}
		return SUCCESS;

	}

	public void prepareMerchandiseLoad() {
		baseModel = new EditMerchandiseList();
	}

	// 买家查看商家的推荐商品
	// 商品推荐查询
	@Action(value = "queryRecommondPicById", results = {
			@Result(name = "success", type = "json", params = { "root", "Tips", "ignoreHierarchy", "false" }) })
	public String queryRecommondPicById() {
		try {
			if (id == null) {
				Tips.put("status", 302);
				return SUCCESS;
			}

			// 设置参数
			Merchant merchant = merchantDao.queryMerchantById(id);

			EditMerchandiseList editMerchandiseList = new EditMerchandiseList();
			editMerchandiseList.setMerchantPhone(merchant.getMerchantLoginPhone());

			List<EditMerchandiseList> editMerchandiseLists = editMerchandiseListDao
					.queryRecommondPicByPhone(editMerchandiseList);

			if (editMerchandiseLists == null || editMerchandiseLists.size() == 0) {
				Tips.put("status", 303);
				return SUCCESS;
			}
			String recordURl = "";
			for (EditMerchandiseList eList : editMerchandiseLists) {
				recordURl = eList.getEditMerchandiseRecordUrl();

				if (recordURl == null || recordURl.equals("")) {
					continue;

				}

				String picUrl = eList.getEditMerchandiseRecordUrl().replace("[", "").replace("]", "").split("&")[1];

				if (picUrl.indexOf(",") > -1) {
					picUrl = picUrl.split(",")[0];
				}

				JSONObject jsonObject = new JSONObject();
				jsonObject.put("recommdId", eList.getEditMerchandiseListId());
				jsonObject.put("recommdPic", "?id=" + eList.getEditMerchandiseListId() + "&name=" + picUrl);

				Tips.put("status", 300);
				Tips.put("source", jsonObject);
				return SUCCESS;
			}
			Tips.put("status", 303);
		} catch (Exception e) {
			Tips.put("STATUS", 303);
		}
		return SUCCESS;
	}

	@Action(value = "download")
	public void download() {
		if (id == null || code == null) {
			return;
		}

		Merchant merchant = merchantDao.queryMerchantById(id);

		if (code == 0) {
			if (merchant.getMerchantHeadUrl() != null) {

				File file = new File(merchant.getMerchantHeadUrl().split("&")[0],
						merchant.getMerchantHeadUrl().split("&")[1]);
				if (file.exists()) {
					try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
							BufferedOutputStream fos = new BufferedOutputStream(
									ServletActionContext.getResponse().getOutputStream())) {
						byte[] bs = new byte[1024];
						int len = 0;
						while ((len = bis.read(bs)) != -1) {
							fos.write(bs, 0, len);
						}
						fos.close();

					} catch (Exception e) {
					}

				}

			}
		}
		if (code == 1) {
			if (merchant.getMerchantRecordUrl() != null) {

				File file = new File(merchant.getMerchantRecordUrl().split("&")[0],
						merchant.getMerchantRecordUrl().split("&")[1]);
				if (file.exists()) {
					try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
							BufferedOutputStream fos = new BufferedOutputStream(
									ServletActionContext.getResponse().getOutputStream())) {
						byte[] bs = new byte[1024];
						int len = 0;
						while ((len = bis.read(bs)) != -1) {
							fos.write(bs, 0, len);
						}
						fos.close();
					} catch (Exception e) {
					}

				}

			}
		}
	}

	public static void main(String[] args) {

		Properties properties = new Properties();
		JSONArray jsonArray = new JSONArray();
		try {

			properties.load(CustomerOrderController.class.getResourceAsStream("/ems.properties"));
			Enumeration<?> propertyNames = properties.propertyNames();
			while (propertyNames.hasMoreElements()) {
				Object nextElement = propertyNames.nextElement();
				String name = (String) nextElement;
				jsonArray.add(properties.getProperty(name));
			}
		} catch (Exception e) {

		}
		System.out.println(jsonArray);
	}

}
