/**
 * 
 */
package com.xiaoluo.spring_struts2.util;

import java.util.Map;

import org.apache.struts2.util.StrutsTypeConverter;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: MerchantPhoneConverString.java, 2015年12月3日 下午12:54:00
 */

public class Merchant_PhoneStrConverPhoneInt extends StrutsTypeConverter {

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public Object convertFromString(Map arg0, String[] arg1, Class arg2) {
		if (arg2 == Integer.class) {

			return Integer.parseInt(arg1[0]);
		}

		return arg1;
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public String convertToString(Map arg0, Object arg1) {
		return arg1 + "";
	}

}
