/**
 * 
 */
package com.xiaoluo.spring_struts2.util;

import org.springframework.util.DefaultPropertiesPersister;

import merchantLogin.key.merchant;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: LoginName.java, 2015年12月3日 上午10:47:09
 */

public class LoginName extends DefaultPropertiesPersister {
	/**
	 * 
	 */
	public LoginName() {
		new merchant();
	}
}
