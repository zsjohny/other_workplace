/**
 * 
 */
package com.xiaoluo.spring_struts2.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * 
 * 
 * @author wb-pengjian.d
 * @version $Id: Log4jUtil.java, 2015-10-27
 */

public class Log4jUtil {

	public static Logger init(Class<?> className) {
		// 获得logger
		Logger logger = Logger.getLogger(className);

		// 读取log4j的日志配置的位置

		String saveLog = "D:\\workplaces\\app\\power_mall\\WebContent\\properties\\log4j.properties";
		// 设置log4j的保存日志参数
		System.setProperty("saveLog", "D:\\workplaces\\app\\power_mall\\WebContent\\properties\\log\\log.properties");
		// 读取配置
		Properties properties = new Properties();
		try {
			properties.load(new BufferedReader(new InputStreamReader(new FileInputStream(
					"D:\\workplaces\\app\\power_mall\\WebContent\\properties\\merchantParam.properties"))));

			// 设置发送日志的名称
			System.setProperty("username",
					DesUtil.decrypt(properties.getProperty("dbName"), properties.getProperty("dbKey")));
			// 设置发送日志的密码
			System.setProperty("password",
					DesUtil.decrypt(properties.getProperty("dbPassword"), properties.getProperty("dbKey")));
			// 设置发送日志的主题
			System.setProperty("subject",
					DesUtil.decrypt(properties.getProperty("dbSubject"), properties.getProperty("dbKey")));

			// 设置发送日志的host
			System.setProperty("host",
					DesUtil.decrypt(properties.getProperty("dbHost"), properties.getProperty("dbKey")));
			// 设置发送的邮箱地址ַ
			System.setProperty("emailTo",
					DesUtil.decrypt(properties.getProperty("dbEmailTo"), properties.getProperty("dbKey")));
			// 设置到日志初始化
			PropertyConfigurator.configure(saveLog);

		} catch (Exception e) {
			logger.warn("log4j初始化出错" + e.getMessage());
		}

		// 返回日志
		return logger;
	}

}
