package com.xiaoluo.spring_struts2.util;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.EditMerchandiseList;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

// 代表aop执行的顺序的问题，值越小越优先--可以用于验证和写日志的顺序先后
@Order(1)
@Aspect
@Component
public class SpringAopUtil {
	@Resource
	private MerchantDao merchantDao;

	// logger日志结合打印
	Logger logger = Log4jUtil.init(SpringAopUtil.class);

	// 前置通知，*包含任意个位置的..任意参数
	@Before(value = "execution(public *  com.xiaoluo.spring_struts2.Merchant.service.impl.EditMerchandiseListServiceImpl.*(.. ))")
	public void beforeValidation(JoinPoint joinPoint) {

		Object[] args = joinPoint.getArgs();
		for (Object object : args) {

			EditMerchandiseList editMerchandiseList = (EditMerchandiseList) object;

			if (editMerchandiseList.getLoginKey() == null) {

				throw new RuntimeException("ERROR");
			}

			Merchant merchant = new Merchant();
			merchant.setMerchantLoginPhone(editMerchandiseList.getMerchantPhone());
			merchant = merchantDao.queryMerchantByMerchantPhone(merchant);

			byte[] bs = ByteConverHexString.HexString2Bytes(editMerchandiseList.getLoginKey());
			if (merchant.getLoginKey() == null) {
				throw new RuntimeException("ERROR");
			}
			String outputStr = "";
			try {
				outputStr = new String(RSACoder.decryptByPrivateKey(bs, merchant.getLoginKey()));

			} catch (Exception e) {
				throw new RuntimeException("ERROR");

			}
			if (!outputStr.equals(editMerchandiseList.getMerchantPhone())) {

				throw new RuntimeException("ERROR");

			}

		}

		// logger.warn("into validation..");
	}

	// 后置通知
	// JoinPoint代表切入点
	// @After(value = "execution(public *
	// com.xiaoluo.spring_struts2.Merchant.contrller.EditMerchandiseListController.*(..
	// ))")
	// public void afterValidation(JoinPoint joinPoint) {
	//
	// logger.warn("end of validation....");
	// // String methodName = joinPoint.getSignature().getName();
	// // System.out.println(methodName);
	// }

	/*
	 * // 环绕通知
	 *
	 * @Around(value = "execution(public * com.aop.proxy.Shopping.*(.. )) )")
	 * public Object aroundValidation(ProceedingJoinPoint point) { // 执行方法
	 * Object object = null;
	 *
	 * try { // 相当于前置通知 System.out.println("into globalHandle..."); object =
	 * point.proceed(); // 相当于后置返回通知 } catch (Throwable e) { // 相当于异常通知 } //
	 * 相当于后置通知 return point;
	 *
	 * }
	 */

}
