/**
 * 
 */
package com.xiaoluo.spring_struts2.util;

import javax.annotation.Resource;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;
import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: Validator.java, 2015年11月24日 下午8:29:30
 */

public class Validator extends FieldValidatorSupport {
	@Resource
	private MerchantDao merchantDao;

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void validate(Object object) throws ValidationException {
		// 获得传进的参数
		String fieldName = getFieldName();

		// 获得传进的值
		Object value = this.getFieldValue(fieldName, object);
		if (value != null && String.valueOf(value).matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			Merchant merchant = new Merchant();
			merchant.setMerchantLoginPhone(String.valueOf(value));

			merchant = merchantDao.checkIsRegistByPhone(merchant);
			if (merchant == null) {
				addFieldError(fieldName, object);
				return;
			}

			if (!"0".equals(merchant.getIs_regist())) {
				addFieldError(fieldName, object);
			}
		}
	}
}
