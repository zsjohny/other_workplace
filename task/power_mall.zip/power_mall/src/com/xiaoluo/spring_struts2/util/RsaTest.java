package com.xiaoluo.spring_struts2.util;

import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author 梁栋
 * @version 1.0
 * @since 1.0
 */
public class RsaTest {
	private String publicKey;
	private String privateKey;

	@Before
	public void setUp() throws Exception {
		Map<String, Object> keyMap = RSACoder.initKey();

		publicKey = RSACoder.getPublicKey(keyMap);
		privateKey = RSACoder.getPrivateKey(keyMap);
		System.err.println("公钥: \n\r" + publicKey);
		System.err.println("私钥： \n\r" + privateKey);
	}

	@Test
	public void test() throws Exception {
		System.err.println("公钥加密——私钥解密");
		String inputStr = "abc";
		byte[] data = inputStr.getBytes();

		byte[] encodedData = RSACoder.encryptByPublicKey(data, publicKey);
		String str = ByteConverHexString.Bytes2HexString(encodedData);

		byte[] bs = ByteConverHexString.HexString2Bytes(str);

		byte[] decodedData = RSACoder.decryptByPrivateKey(bs, privateKey);

		String outputStr = new String(decodedData);

		System.err.println("加密前: " + inputStr + "\n\r" + "解密后: " + outputStr);
		Assert.assertEquals(inputStr, outputStr);

	}
	// MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIKJU/ST2PnMMzEQQ3q+U8KV9r+aFK/KLKKWoxDPaIV/Wt0zvLKsnO3jTtiVnn4JNg3XKlcc8mQftAyRbrEh5tHy5v/wCWQh8PnWoqjCOgMqtRXbzSmV5SDgJmHBEvkG2mwmM+p4F08hhEAlofwc2JULkjvTKrkgwdIM15G7dwpPAgMBAAECgYA+L5fsWwaxseLtS7cp4UPb3j9HderG+ASdjC+w0W4UsuAhowURBYRZG8GzEkwH9PFoVImaKHMc2bGXjyzxe5oO2WZ385ro61Za8PzTjX27OZ2S6SCjUWhTyzWF/fRzkGo6oB771U+t9CqtR2q0GauabCCQb1ZBJdd36MI1tvDMMQJBAMyWNe+OCwyBovgpbP0VwPvKzWamOFyU3s1rzdtGGlOpbjZQ5yDJLGN9bq8aDpHhaeDSXsiXLxkeamAl2W+Mk6kCQQCjVzLCbaZ8a3Vo5roEUTo+Qh8C1COTyni8TWX1o2Z2RR0LIyR/ckC4qK7cIemOBKf96gNVlKiWyDLb6i/N+2k3AkAPdWot57W+BC2kQr0RgotKe1B56SVpGXacXwD3CJ0EpVDGmeZc+9Z2zguG/5kKPNYbPsoarhHI/BtdmH6NhznBAkBwTCXwuDQq/DInYeFn0HSLkygA6Npg5GXniAreO23ZSCD0pD+Wg3Vtv0MgwwvwgNECZ93M+7yAlbkpqrMdGYk3AkEAvZsTjErT5xa+W/ipB4GqACd06cB15zn3oI8vMVnZRd2UnEp6sm5kmdCbvf+EVZ8pKSayiIo0KZC3bN9os8pPTg==

	// MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJ1TCIdkhAWfIIIqmKRu+plkXC+dTNuS/JT/8xl35QsgzwIKhH7OwXk24FVZrd5ZqD9i7cjG/4GwS/wK4u2p+aA/lgI4QohZ+zVNrKCoayCyfdE2NUuKPU8zeCXixls+3tWI8Z6wGGYlK721pa+9LFj9i0JaViSi3ObC8mY+D44vAgMBAAECgYAZehnWeyOaGXPVQHqpnkM81fDL0ShiIoJ+ypgelrjjvXNofDWKp4bTT1yy1av/ZvuFEEs7iWZVJSyY61ZmcHE5DEjjg+OICdc+Ji/ytIEGvvERMQAl6Pn/ArHr4GjzDE9Z1vG/2gNbgsAtFwc5WcOI7BINexlnQwu/tU80qE0AEQJBAP+u6XyTVR8SK5RzOe1GDNZiAkEbyrnpCjQAqLIqRX/xRbv7TmqnlYnIrKG+3Aw+xwkvzcZpOotZqCnX+qvctOcCQQCdhO1wz4AYjgET5OH0xvlgFMMEBcYo4YZHG9zALyp74pU4h3sXpz6AVJLYgd6w1ZOzZibnRH2I7llra19OIut5AkEAyFysUdgvA0s85XcqdLrJQpLJS3ZY9jkdqsS9bejcT7eluvrjZ4buE2wzhAjJ7bqgRJ22dn5tx1e6BRhgMp+hDwJBAJjBZw4GfF/TnmHvjdy19PJjT/efrdrJUlG1SG+rjdSUGEe4wvteOfNzkPCbiR0OEe1g/As81UyscFUGzGbW4GkCQEaBD9AAWgX6MsbTBiq3WYNAGjOO0bYfTL5bCAyCqCBoJaRgFTsYMD3jzTjGAo42JqXahTkx3evLNJZiDchgmnU=

	@Test
	public void testSign() throws Exception {
		System.err.println("私钥加密——公钥解密");
		String inputStr = "sign";
		byte[] data = inputStr.getBytes();

		byte[] encodedData = RSACoder.encryptByPrivateKey(data, privateKey);

		byte[] decodedData = RSACoder.decryptByPublicKey(encodedData, publicKey);

		String outputStr = new String(decodedData);
		System.err.println("加密前: " + inputStr + "\n\r" + "解密后: " + outputStr);
		Assert.assertEquals(inputStr, outputStr);

		System.err.println("私钥签名——公钥验证签名");
		// 产生签名
		String sign = RSACoder.sign(encodedData, privateKey);
		System.err.println("签名:\r" + sign);

		// 验证签名
		boolean status = RSACoder.verify(encodedData, publicKey, sign);
		System.err.println("状态:\r" + status);
		Assert.assertTrue(status);

	}

}
