package com.xiaoluo.spring_struts2.util;

import javax.annotation.Resource;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.xiaoluo.spring_struts2.Merchant.dao.MerchantDao;
import com.xiaoluo.spring_struts2.Merchant.entity.Merchant;

@Order(2)
@Aspect
@Component
public class MerchantSpringAopUtil {
	@Resource
	private MerchantDao merchantDao;

	@Before(value = "execution(public * com.xiaoluo.spring_struts2.Merchant.service.impl.MerchantServiceImpl.*(..))")
	public void checkKey(JoinPoint joinPoint) {
		Object[] args = joinPoint.getArgs();
		for (Object obj : args) {
			Merchant merchant = (Merchant) obj;

			if (merchant.getLoginKey() == null) {

				throw new RuntimeException("ERROR");
			}
			// MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAKyNeq6e287LbkmyRArAOlJ9SQebK7uZsTpBBMDdVAGGO4qHA0Z+VcSS0g+zG+h/WjJ2TDs3x0kCZwAhNEbFbG1Mhrc6EBDJCw8jEu9nLzsnCcVaKODxoGFtFJVgdTqmRiCWiHN1iKkGwk9Qr7kINijEGt05nizQeyA4O/Rpnv5vAgMBAAECgYA61GGnd3Hpp2IKrkSUhcVcqmpjtXvLkjLicZh1SQCDJIjYSf/L4PbM9mG4CJDTS9gsrDiBWBsRwUfsu2VfW6ADdGEsvChlyCIWpUJNQkJdCkTmUOf8EnCH1r/F79apDwFFHEV2U+M2cXf7gV+d5Eh4czJi1vUdwtqj/DyE6IJAQQJBANclSM8G2ikG1+1gE0XwwXoUxiOGLw0l0r6nG1xRjCcsUTVNnrAISZAhbU+WFJvSEjKx9YdvEqd812MKGVtAOcMCQQDNUadGxbsn8kPGO2aqAG5ZQFU2p63U75QBeVakB4hNTdMTBCxhfDi67nW9sitMg0oJodjVA7GrsU4pbCMKnzHlAkAwrkoMNiO09sxy9LNHtxNAOWUf8qPA2NcXtp4VRIpu7rMtWXPXpvhmOXoPcQkWvPDLMcM5suNIrJHb4hQctqqbAkAjQq2emuCcaJ+5EIR+F5rb2w+HVl6lHgvmAOefPefrlrz0HBhfGY1IlSFFVa7X8ggqBVCOrJa7rLSGqpqN/W79AkB6F0CR79qfQMp3av7iDltGCGayM2xZGfgd2voCLTqHoKvXsT7VLERUHHXIagU72VCw/4dLwFy3NfVx0ADsHMI7
			Merchant queryMerchantByMerchantPhone = merchantDao.queryMerchantByMerchantPhone(merchant);
			byte[] bs = ByteConverHexString.HexString2Bytes(merchant.getLoginKey());
			if (merchant.getLoginKey() == null) {
				throw new RuntimeException("ERROR");
			}
			String outputStr = "";
			try {
				outputStr = new String(RSACoder.decryptByPrivateKey(bs, queryMerchantByMerchantPhone.getLoginKey()));
			} catch (Exception e) {
				throw new RuntimeException("ERROR");
			}
			if (!outputStr.equals(merchant.getMerchantLoginPhone())) {

				throw new RuntimeException("ERROR");

			}

		}

	}

	public static void main(String[] args) {
		String data = "78BDEF56F5FB0FEC6BEC82ED1FEA48221415CBF7949E5530DB8212B72F58F7E9E14EB7696A3E2F6408ED895D1A5EFC96664AB4D701E5946211F970CDB46532161958536C3F2B7EBE2EA692C8E7E6F05A6980A53277DD3157331B0651DFA88FDE7760F13401475BD7FB62042F06EC025A011EBC2C1DC06A0C985CEF16DF2C59F4";

		byte[] bs = ByteConverHexString.HexString2Bytes(data);
		RSACoder.decryptByPrivateKey(bs,
				"78BDEF56F5FB0FEC6BEC82ED1FEA48221415CBF7949E5530DB8212B72F58F7E9E14EB7696A3E2F6408ED895D1A5EFC96664AB4D701E5946211F970CDB46532161958536C3F2B7EBE2EA692C8E7E6F05A6980A53277DD3157331B0651DFA88FDE7760F13401475BD7FB62042F06EC025A011EBC2C1DC06A0C985CEF16DF2C59F4");

	}

}
