/**
 * 
 */
package com.xiaoluo.spring_struts2;

import java.util.List;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserService.java, 2015年11月23日 下午3:40:22
 */

public interface UserService {
	int adUser(User user);

	List<User> queryUser(int id);

	void deleteUserById(int id);

	void updateUser(User user);
}
