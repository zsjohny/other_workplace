/**
 * 
 */
package com.xiaoluo.spring_struts2;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.xiaoluo.spring_struts2.mapper.UserMapper;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserDaoImpl.java, 2015年11月23日 下午4:15:56
 */
@Repository
public class UserDaoImpl implements UserDao {
	@Resource
	private UserMapper userMapper;

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public List<User> queryUser(int id) {
		List<User> users = null;
		if (id == 0) {
			users = userMapper.queryUserByAll();
		} else {
			users = userMapper.queryUserById(id);
		}

		return users;
	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int adUser(User user) {
		int count = userMapper.adUser(user);
		return count;
	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void deleteUserById(int id) {
		userMapper.deleteUserById(id);

	}

	/**
	 * 
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void updateUser(User user) {
		userMapper.updateUser(user);

	}
}
