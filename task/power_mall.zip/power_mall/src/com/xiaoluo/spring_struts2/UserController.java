/**
 * 
 */
package com.xiaoluo.spring_struts2;

import java.util.List;

import javax.annotation.Resource;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.xiaoluo.spring_struts2.base.BaseController;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserController.java, 2015年11月24日 下午6:39:14
 */
@ParentPackage("json-default")
@Namespace("/demo")
public class UserController extends BaseController {

	private static final long serialVersionUID = 1L;
	// service
	@Resource
	private UserService userService;
	// 返回的类型
	public List<User> users;

	// 新增
	@Action(value = "addUser", results = { @Result(location = "index.jsp"),
			@Result(name = "error", location = "error.jsp"), @Result(name = "input", location = "index.jsp") })
	public String addUser() {

		if (baseModel != null) {
			User user = (User) baseModel;
			if ("".equals(user.getName()) || user.getAge() == null) {
				return ERROR;
			}

		}

		if (userService.adUser((User) baseModel) != 0) {
			return SUCCESS;
		}

		return ERROR;
	}

	public void prepareAddUser() {
		baseModel = new User();
	}

	// 显示所有
	@Action(value = "viewUserList", results = {
			@Result(type = "json", params = { "root", "users", "ignoreHierarchy", "false" }) })
	public String viewUserList() {

		int id = ((User) baseModel).getId() == null ? 0 : ((User) baseModel).getId();

		users = userService.queryUser(id);

		return SUCCESS;

	}

	public void prepareViewUserList() {
		baseModel = new User();
	}

	// 删除
	@Action(value = "deleteUserById", results = { @Result(location = "index.jsp") })
	public String deleteUserById() {

		userService.deleteUserById(((User) baseModel).getId());
		return SUCCESS;

	}

	public void prepareDeleteUserById() {
		baseModel = new User();
	}

	// 修改
	@Action(value = "updateUser", results = { @Result(location = "index.jsp") })
	public String updateUser() {
		userService.updateUser((User) baseModel);
		return SUCCESS;

	}

	public void prepareUpdateUser() {
		baseModel = new User();
	}

	/**
	 * 
	 * 检查参数
	 * 
	 * @param
	 * @return
	 */
	@Action(value = "checkParam", results = { @Result(name = "input", location = "index.jsp"),
			@Result(name = "chainDo", type = "chain", params = { "actionName", "addUser" }) })
	public String checkParam() {

		return "chainDo";

	}

	public void prepareCheckParam() {
		baseModel = new User();

	}

}
