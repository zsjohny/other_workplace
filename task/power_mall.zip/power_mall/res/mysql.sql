
   select 
	     editMerchandiseListId ,editMerchandiseListDisPicsUrl,editMerchandiseListName,editMerchandiseListPrice,editMerchandiseListStock,editMerchandiseListIsPost,editMerchandiseListProductDesc,editMerchandiseListDesPicsUrl,merchantFloderName
	            from  eidtMerchandiseList
				where 
				   editMerchandiseListName like '%h%'  and  
			     is_deledted ='0'