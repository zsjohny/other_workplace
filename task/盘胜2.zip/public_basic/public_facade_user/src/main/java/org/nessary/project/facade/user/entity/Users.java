package org.nessary.project.facade.user.entity;

import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.annotion.table.Transient;
import org.nessary.project.utils.operate.DbHandler;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 用户权限表
 * Created by Ness on 2017/2/15.
 */
@Table("t_users")
public class Users implements Serializable{

    /**
     * 用户的自增Id
     */
    @Id
    private Integer id;

    @Column(commit = "伪Id")
    private String uuid;

    @Column(commit = "用户的姓名")
    private String userName;

    @Column(commit = "用户的密码")
    private String userPassword;


    @Column(commit = "用户对应的路径权限")
    private String urlPathPermis;

    @Column(commit = "角色权限")
    private String rolesPermis;

    @Column(commit = "创建时间",dateGeneStrategy = DbHandler.DateGeneStrategy.UPDATE)
    private Timestamp createTime;

    @Column(commit = "是否删除 true是 false不是")
    private Boolean deleted;

    @Transient
    private String test;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUrlPathPermis() {
        return urlPathPermis;
    }

    public void setUrlPathPermis(String urlPathPermis) {
        this.urlPathPermis = urlPathPermis;
    }

    public String getRolesPermis() {
        return rolesPermis;
    }

    public void setRolesPermis(String rolesPermis) {
        this.rolesPermis = rolesPermis;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
}
