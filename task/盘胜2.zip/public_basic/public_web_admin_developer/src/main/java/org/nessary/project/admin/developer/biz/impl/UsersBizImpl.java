package org.nessary.project.admin.developer.biz.impl;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.nessary.project.admin.developer.biz.UsersBiz;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.http.Iptools;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * 权限的用户业务处理层实现层
 * <p>
 * Created by Ness on 2017/2/19.
 */
@Component
public class UsersBizImpl implements UsersBiz {
    /**
     * 日志文件
     */
    private Logger logger = LoggerFactory.getLogger(UsersBizImpl.class);

    /**
     * 用户登录
     *
     * @param request      请求
     * @param userName     用户名
     * @param userPassword 用户密码
     * @return
     */
    @Override
    public Response loadByUserName(HttpServletRequest request, String userName, String userPassword) {
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
            logger.warn("Ip={},下的用户={},输入的 userPassword={} 某一个参数为空", request, userName, userPassword);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        logger.info("ip={}下的用户={},开始进行登录", Iptools.gainRealIp(request), userName);

        Subject subject = registerLogin(userName, userPassword);
        Boolean xxxx = checkPermissionBySubject("xxxx", subject);
        System.out.println("xxxx"+xxxx);
        Boolean ss = checkPermissionBySubject("user.*", subject);
        System.out.println("user.*:"+ss);

        logger.info("ip={}下的用户={},结束进行登录", Iptools.gainRealIp(request), userName);
        return null;
    }


    /**
     * 根据用户名和密码检测当前登录的权限
     *
     * @param userPermission 权限名称
     * @param subject        当前用户
     * @return
     */
    public Boolean checkPermissionBySubject(String userPermission, Subject subject) {
        Boolean flag = false;
        if (Regular.checkEmpty(userPermission, null) || subject == null) {
            return flag;
        }
        flag = subject.isPermitted(userPermission);
        return flag;
    }

    /**
     * 根据用户名和密码注册登录
     *
     * @param userName     用户名
     * @param userPassword 用户密码
     */
    public Subject registerLogin(String userName, String userPassword) {
        Subject subject = SecurityUtils.getSubject();
        if (Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
            return subject;
        }

        UsernamePasswordToken token = new UsernamePasswordToken(userName, userPassword);
        subject.login(token);
        return subject;
    }

    /**
     * 根据当前用户获取session
     *
     * @param subject 当前用户
     * @return
     */
    public Session getSessionBySubject(Subject subject) {
        Session session = null;
        if (subject == null) {
            return session;
        }
        session = subject.getSession();
        return session;
    }


}
