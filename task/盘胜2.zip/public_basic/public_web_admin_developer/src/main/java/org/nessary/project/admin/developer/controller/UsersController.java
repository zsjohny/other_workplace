package org.nessary.project.admin.developer.controller;

import org.apache.shiro.authz.annotation.RequiresGuest;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.nessary.project.admin.developer.biz.UsersBiz;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.annotion.Author;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Ness on 2017/2/19.
 */
@RestController
@RequestMapping("/users")
public class UsersController {
    /**
     * 日志文件
     */
    private Logger logger = LoggerFactory.getLogger(UsersController.class);

    @Autowired
    private UsersBiz usersBiz;


    /**
     * 用户登录
     *
     * @param request      请求
     * @param userName     用户名
     * @param userPassword 用户密码
     * @return
     */
    @RequestMapping("/login")
    public Response loadByUserName(HttpServletRequest request, String userName, String userPassword) {


        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
            logger.warn("Ip={},下的用户={},输入的 userPassword={} 某一个参数为空", request, userName, userPassword);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }


        return usersBiz.loadByUserName(request, userName, userPassword);
    }


    @RequiresRoles("ssssss")
    @RequestMapping("/test")
    public Response testByAnnotation() {
        return Response.success();
    }

    @RequiresPermissions({"user.*"})
    @RequestMapping("/test2")
    @Author
    public Response tes2tByAnnotation() {

        return Response.success();
    }

    @RequiresUser
    @RequestMapping("/test3")
    public Response tes3tByAnnotation(String userName) {
        return Response.success();
    }

    @RequiresGuest
    @RequestMapping("/test4")
    public Response tes34tByAnnotation() {


        return Response.success();
    }

    @RequiresPermissions("user1.*")
    @RequestMapping("/test5")
    public Response testSpringEl() {
        System.out.println("author success...");
        return Response.success();
    }


}
