package org.nessary.project.admin.developer.biz;

import org.nessary.project.utils.operate.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * 权限的用户业务处理层
 * Created by Ness on 2017/2/19.
 */
public interface UsersBiz{

    Response loadByUserName(HttpServletRequest request, String userName, String userPassword);
}
