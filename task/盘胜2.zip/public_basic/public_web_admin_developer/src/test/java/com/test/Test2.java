package com.test;

import java.util.*;

/**
 * Created by Ness on 2017/2/26.
 */
public class Test2 {
   static class a{
        private String name;

       public String getName() {
           return name;
       }

       public void setName(String name) {
           this.name = name;
       }

       @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof a)) return false;

            a a = (a) o;
            System.out.println("into222");
            return true;
        }

       @Override
       public int hashCode() {
           System.out.println("1111111");
           return 1;
       }
   }

    public static void main(String[] args) {
        Set<a> list = new HashSet<>();
        a b = new a();
        b.setName("222");
        list.add(b);
        a c = new a();
        c.setName("3333");
        list.add(c);
        System.out.println(list.size());

    }

}
