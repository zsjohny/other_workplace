package com.test;

/**
 * Created by Ness on 2017/2/25.
 */

public class TestClass {
    @TestAnnotation("456")
    public void TestMain() {
        System.out.println("into");
    }

    @TestAnnotation1("789")
    private String testField;


}
