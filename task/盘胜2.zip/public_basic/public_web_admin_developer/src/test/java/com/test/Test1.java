package com.test;

import javassist.*;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.StringMemberValue;
import org.junit.Test;

import java.io.*;

/**
 * Created by Ness on 2017/2/25.
 */
public class Test1 {

    @Test
    public void ReadTest() throws NotFoundException {
        ClassPool pool = ClassPool.getDefault();
        //获取要修改的类的所有信息
        CtClass ct = pool.get("com.test.TestClass");
        //获取类中的方法
        CtMethod[] cms = ct.getDeclaredMethods();
        //获取第一个方法（因为只有一个方法）
        CtMethod cm = cms[0];
        System.out.println("方法名称====" + cm.getName());
        //获取方法信息
        MethodInfo methodInfo = cm.getMethodInfo();
        //获取类里的em属性
        CtField cf = ct.getField("testField");
        //获取属性信息
        FieldInfo fieldInfo = cf.getFieldInfo();
        System.out.println("属性名称===" + cf.getName());


        //获取注解属性
        AnnotationsAttribute attribute = (AnnotationsAttribute) fieldInfo.getAttribute(AnnotationsAttribute.visibleTag);
        System.out.println(attribute);
        //获取注解
        Annotation annotation = attribute.getAnnotation("com.test.TestAnnotation1");

        System.out.println(annotation);
        //获取注解的值
        String text = ((StringMemberValue) annotation.getMemberValue("value")).getValue();
        System.out.println("注解名称===" + text);

    }

    @Test
    public void UpdateTest() throws NotFoundException, IOException, CannotCompileException, InterruptedException, NoSuchFieldException, IllegalAccessException, InstantiationException {

        ClassPool pool = ClassPool.getDefault();
        //获取需要修改的类
        CtClass ct = pool.get("com.test.TestClass");

        //获取类里的所有方法
        CtMethod[] cms = ct.getDeclaredMethods();
        CtMethod cm = cms[0];
        System.out.println("方法名称====" + cm.getName());

        MethodInfo minInfo = cm.getMethodInfo();
        //获取类里的em属性
        CtField cf = ct.getField("testField");

        FieldInfo fieldInfo = cf.getFieldInfo();

        System.out.println("属性名称===" + cf.getName());

        ConstPool cp = fieldInfo.getConstPool();
        //获取注解信息
        AnnotationsAttribute attribute2 = new AnnotationsAttribute(cp, AnnotationsAttribute.visibleTag);
        Annotation annotation = new Annotation("com.test.TestAnnotation1", cp);


        //修改名称为unitName的注解
        annotation.addMemberValue("value", new StringMemberValue("basic-entity", cp));
        attribute2.setAnnotation(annotation);
        minInfo.addAttribute(attribute2);

        //打印修改后方法
        Annotation annotation2 = attribute2.getAnnotation("com.test.TestAnnotation1");
        String text = ((StringMemberValue) annotation2.getMemberValue("value")).getValue();
        Thread.sleep(300);
        System.out.println("修改后的注解名称===" + text);


        ct.writeFile(Thread.currentThread().getContextClassLoader().getResource("").getPath().substring(1));
//        ct.toBytecode(new DataOutputStream(new ObjectOutputStream(new FileOutputStream("C:\\workplace\\dubbo\\public_basic\\public_web_admin_developer\\target\\test-classes\\com\\test\\TestClass.class"))));
//        Thread.sleep(2000);
//        String testField = TestClass.class.getDeclaredField("testField").getAnnotation(TestAnnotation1.class).value();
//        System.out.println(testField);
        System.out.println();

//        ReadTest();
    }
}
