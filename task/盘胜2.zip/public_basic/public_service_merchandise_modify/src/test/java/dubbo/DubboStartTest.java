package dubbo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Ness on 2017/2/8.
 */
public class DubboStartTest {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("classpath:user/app_root.xml");

        context.start();

        System.err.println("startup ok");

        while (true) {
            synchronized (DubboStartTest.class) {
                try {
                    DubboStartTest.class.wait();
                } catch (InterruptedException e) {
                    System.err.println(e);
                    context.stop();
                }
            }
        }

    }
}
