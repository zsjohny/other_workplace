package org.nessary.project.service.merchandiseModify.facade;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.nessary.project.facade.merchandise.entity.MerchStockAndPrice;
import org.nessary.project.facade.merchandise.entity.Merchandise;
import org.nessary.project.facade.merchandise.entity.MerchandiseStandard;
import org.nessary.project.facade.merchandise.entity.OrderEntity;
import org.nessary.project.facade.merchandise.entity.OrderStatusCounts;
import org.nessary.project.facade.merchandise.service.MerchandiseFacade;
import org.nessary.project.service.merchandiseModify.mapper.MerchandiseMapper;
import org.nessary.project.utils.conver.DataConverUtils;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.math.Arith;
import org.nessary.project.utils.operate.Response;
import org.nessary.project.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.common.json.JSONObject;
import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;

/**
 * 用户的服务实现层
 * Created by Ness on 2017/2/8.
 */
@Service
@Component
public class MachandiseFacadeImpl implements MerchandiseFacade {
	@Autowired
	MerchandiseMapper merchMapper;

	private Logger logger = LoggerFactory.getLogger(MachandiseFacadeImpl.class);

    public static void main(String[] args){
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:service/merchandiseModify/app_root.xml");
        MerchandiseFacade MerchandiseFacadeImpl = context.getBean("machandiseFacadeImpl", MerchandiseFacade.class);
        MerchandiseFacadeImpl.loadOrdersByStatusAndMerchandiseUuid("92194912083c306b0bdb9b948cc44c36469372635",null,null,null);
    }
    @Override
    
    public void test001(){
    	
    }
    
    
    
    /**
     * 改变订单状态
     */
    public Response changeOrderStatusByMerchandiser(String merchandiserUuid, String orderNo, Integer status){
    	
    	if(merchandiserUuid == null){
    		logger.warn("merchandiserUuid==null!");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(orderNo == null){
    		logger.warn("orderNo==null!");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(status == null){
    		logger.warn("status==null!");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	Map <String, Object> paramsMap = new HashMap<>();
    	paramsMap.put("merchandiserUuid", merchandiserUuid);
    	paramsMap.put("orderNo", orderNo);
    	paramsMap.put("status", status);
    	int result = merchMapper.loadSingleOrderStatus(orderNo);
    	switch (status){
    	case 3: 
    		if(result != 2){
    			logger.warn("准备将订单改为已发货，但是之前的订单状态并不为待发货！请检查");
    			return Response.error("准备将订单改为已发货，但是之前的订单状态并不为待发货！请检查");
    		}
    		
    		if(merchMapper.changeOrderStatusByMerchandiser(paramsMap)>0){
    			return Response.success("发货成功!");
    		}else{
    			return Response.error("发货失败！");
    		}
    		
    	case 5: 
    		if(result != 1){
    			logger.warn("准备取消订单，但是之前的订单状态并不为待付款！请检查");
    			return Response.error("准备取消订单，但是之前的订单状态并不为待付款！请检查");
    		}
    		if(merchMapper.changeOrderStatusByMerchandiser(paramsMap)>0){
    			return Response.success("取消订单成功！");
    		}else{
    			return Response.error("取消订单失败！");
    		}
    		
    	default: return Response.error("传递的status不为3或者5，请检查！");
    	}
    }
   
    
    /**
     * 修改订单中的留言
     */
    
    public Response updateOrderInfo_message(String orderNo, String message){
    	
    	if(orderNo == null){
    		logger.warn("orderNo为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(message == null){
    		logger.warn("message为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	Map<String,String> paramsMap = new HashMap<>();
    	paramsMap.put("orderNo", orderNo);
    	paramsMap.put("orderMessage", message);
    	
    	int i = merchMapper.updateOrderInfo_message(paramsMap);
    	if(i > 0){
    		return Response.success();
    	}else{
    		return Response.error("更新失败！");
    	}
    }
    
    
    
    /**
     * 单个订单详情
     */
    public Response showSingleOrder(String orderNo){
    	
    	List<OrderEntity> orderList = merchMapper.loadSingleOrderDetail(orderNo);
    	
    	OrderEntity order = null;
    	
    	if(orderList!=null){
    		order = orderList.get(0);
    	}
    	JSONObject json = new JSONObject();
    	json.put("content", order);
    	
    	
    	return Response.success(json);
    }
    
    
    
    /**
     *按不同状态查询某一商家的订单数据
     */
    @Override
    
    public Response loadOrdersByStatusAndMerchandiseUuid(String merchandiserUuid, Integer status, Integer page, Integer size){
    	
    	if(merchandiserUuid == null){
    		logger.warn("查询商家订单时，merchandiserUuid为空");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	Map <String, Object> paramsMap = new HashMap<>();
    	
    	paramsMap.put("merchandiserUuid", merchandiserUuid);
    	paramsMap.put("status", status);
    	if(page == null || page <= 0){
    		page = 0;
    	}else{
    		page--;
    	}
    	if(size == null || size <= 0){
    		size = 20;
    	}
    	paramsMap.put("begin", page * size);
    	paramsMap.put("size", size);
    	
    	List<OrderEntity> orderList = merchMapper.loadOrdersByStatusAndMerchandiseUuid(paramsMap);
    	if(orderList != null){
    OrderEntity oe = null;
    for(int i = 0; i < orderList.size(); i++){
    	oe = orderList.get(i);
    	if(oe != null){
//    		oe.setMerchNameStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchName()));
//    		oe.setMerchPicStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchPic()));
//    		oe.setMerchPriceStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchPrice()));
//    		oe.setMerchQuantityStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchQuantity()));
//    		oe.setMerchSpecStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchSpec()));
//    		oe.setMerchStandardIndexStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchStandardIndex()));
//    		oe.setMerchUuidStringArr(DataConverUtils.byteArr2StringArr(oe.getMerchUuid()));
    	}
    	
    }
    	}	
    	System.out.println(JSON.toJSONString(orderList));
    	return null;
    }
    
    
    
    /**
     * 同一商家不同状态下的订单数目
     */
    @Override
    public Response loadOrderStatusCount(String merchandiserUuid){
    	if(merchandiserUuid == null){
    		merchandiserUuid = "92194912083c306b0bdb9b948cc44c36469372635";
    	}
    	Map<String, String> paramsMap = new HashMap<>();
    	paramsMap.put("merchandiserUuid", merchandiserUuid);
    	List<OrderStatusCounts> oscList = merchMapper.loadOrderStatusCount(paramsMap);
    	oscList.forEach(item->{
    		System.out.println(item.toString());
    	});
    	return Response.success(oscList);
    }
    
    
    
    
    
    
    /**
     * 更改已付款订单中的商品规格
     * @param orderNo 订单号
     * @param merchUuid 商品id
     * @param newIndex 要改的商品规格
     * @param oldIndex 老的商品规格 
     */
    @Override
    public Response editOrderInfo_merchIndex(String orderNo, String merchUuid, String newIndex , String oldIndex){
    	
    	if(orderNo == null){
    		logger.warn("修改订单中商品规格时，订单号为空");
    		
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	if(merchUuid == null){
    		logger.warn("修改订单中商品规格时，订单号{}传入的merchUuid为空",orderNo);
    		
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	if(newIndex == null){
    		logger.warn("修改订单中商品规格时，订单号{}传入的newIndex为空",orderNo);
    		
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	if(oldIndex == null){
    		logger.warn("修改订单中商品规格时，订单号{}传入的oldIndex为空",orderNo);
    		
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(oldIndex.equals(newIndex)){
    		logger.warn("前后传入的索引相同！",orderNo);
    		
    		return Response.error("前后传入的索引相同！");
    	}
    	
    	List<OrderEntity> orderList = merchMapper.loadOrderInfo_merchUuidArr(orderNo);
    	
    	if(orderList == null || orderList.size() == 0 || orderList.get(0) == null){
    		
    		logger.warn("根据订单编号{}取不到订单数据！",orderNo);
    		
    		return Response.error("orderNo找不到订单数据！");
    	}
    	
    	OrderEntity order = orderList.get(0);
    	
    	if(order.getStatus()==null || order.getStatus()!=2){
    		logger.warn("订单状态为空或者不处于已付款待发货状态！");
    		return Response.error("订单状态为空或者不处于已付款待发货状态！");
    	}
    	
    	String[] merchUuidStrArr = DataConverUtils.byteArr2StringArr(order.getMerchUuid());
    	
    	if(merchUuidStrArr == null){
    		
    		logger.warn("根据订单编号{}取不到merchUuidStrArr！",orderNo);
    		
    		return Response.error("根据订单编号" + orderNo + "取不到merchUuidStrArr！");
    		
    	}
    	Integer resultIndex = null;
    	for(int i=0; i<merchUuidStrArr.length; i++){
    		if(merchUuid.equals(merchUuidStrArr[i])){
    			resultIndex = i;
    			break;
    		}
    		
    	}
    	if(resultIndex == null){
    		return Response.error("数据库中订单号为"+orderNo+"的订单找不到id为"+merchUuid+"的商品");
    	}
    	
    	String[] merchIndexStrArr = DataConverUtils.byteArr2StringArr(order.getMerchStandardIndex());
    	
    	if(merchIndexStrArr == null){
    		
    		logger.warn("根据订单编号{}取不到merchIndexStrArr！",orderNo);
    		
    		return Response.error("根据订单编号" + orderNo + "取不到merchIndexStrArr！");
    		
    	}
    	String index = merchIndexStrArr[resultIndex];
//    	String[] test = new String []{
//    			"0@2","2@0"
//    	};
//    	order.setMerchStandardIndex(DataConverUtils.stringArr2ByteArr(test));
//    	order.setOrderNo(orderNo);
//    	merchMapper.updateOrderInfo_merchIndexArr(order);
//    	return null;
    	if(index == null){
    		logger.warn("查询出的index为空！");
    		return Response.error("数据库中订单号为"+orderNo+"的订单找不到id为"+merchUuid+"的商品中index为"+merchIndexStrArr[resultIndex]+"的规格数据");
    	}
    	index = index.replace("@", ",");
    	if(!oldIndex.equals(index)){
    		logger.warn("传入的oldIndex{}和数据库中原来的Index{}不一致！",oldIndex,index);
    		return Response.error("从数据库中订单号为"+orderNo+"的订单,id为"+merchUuid+"的商品的数据库的index为"+index+"与oldIndex"+oldIndex+"不一致！");
    	}
    	Map<String,String> paramsMap = new HashMap<>();
    	paramsMap.put("merchStandardIndex", index);
    	paramsMap.put("merchUuid", merchUuid);
    	Double priceOld = merchMapper.loadMerchPriceByUuidAndIndex(paramsMap);
    	paramsMap.put("merchStandardIndex", newIndex);
    	Double priceNew = merchMapper.loadMerchPriceByUuidAndIndex(paramsMap);
    	if(priceOld == null || priceNew == null || Math.abs(Arith.subtract(2, priceOld, priceNew))>0.001){
    		logger.warn("要改的规格和原来的规格对应的价格不一致！(原来的：{}要改的：{})更改失败！",priceOld,priceNew);
    		return Response.error("根据订单编号" + orderNo + "进行修改规格时，查不到价格数据或者前后价格一致！");
    	}
    	newIndex = newIndex.replace(",", "@");
    	merchIndexStrArr[resultIndex] = newIndex;
    	byte[] merchIndexByteArr = DataConverUtils.stringArr2ByteArr(merchIndexStrArr);
    	order.setMerchStandardIndex(merchIndexByteArr);
    	order.setOrderNo(orderNo);
    	if(merchMapper.updateOrderInfo_merchIndexArr(order)>0){
    		return Response.success();
    	}else{
    		return Response.error("修改失败！对数据库的修改条目为0！");
    	}
    	
    	//判断库存 加减库存
    	
    	
    	
    	
    }
    
    
    
    
    /**
     * 编辑订单中的收货地址
     * @param orderNo 订单编号
     * @param receiveAddressDetail 收货地址
     */
    @Override
    public Response editOrderInfo_address(String orderNo, String receiveAddressDetail, String merchandiserUuid){
    	
    	
    	/**
    	 *测试数据
    	 */
    	orderNo = "2017021218286428415224665902245036761798";
    	
    	receiveAddressDetail = "测试修改地址";
    	
    	
    	if(orderNo == null){
    		logger.warn("修改订单收货地址时，orderNo为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(receiveAddressDetail == null){
    		logger.warn("修改订单收货地址时，receiveAddressDetail为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	OrderEntity order = new OrderEntity();
    	order.setOrderNo(orderNo);
    	order.setReceiveAddressDetail(receiveAddressDetail);
    	order.setDeletedPersonUuid(merchandiserUuid);
    	order.setUpdateTime(new Date());
    	int i = merchMapper.editOrderInfo_address(order);
    	
    	if( i>0 ){
    		return Response.success();
    	}else{
    		return Response.error("修改地址失败！");
    	}
    }
    
    
    
    /**
     * 添加新商品
     */
    @Override
    @Transactional
    public Response addNewMerchandise(String data){
    	/**
    	 * 测试数据
    	 */
    	Merchandise merch = null;
    	if(data == null){
    		String [] topCategoryName = new String[]{
        			"颜色","尺寸"
        	};
        	String [][] secondCategoryName = new String [][]{
        			new String []{
        					"黄色","蓝色","黑色"
        			},
        			new String []{
        					"s","m","x","xl"
        			}
        	};
        	
        	List<MerchStockAndPrice> mcapList = new ArrayList<>();
        	MerchStockAndPrice msap_1 = new MerchStockAndPrice();
        	msap_1.setMerchStandardIndex("0,1");
        	msap_1.setMerchUuid(UserUtils.generateUUid());
        	msap_1.setPrice(123.00);
        	msap_1.setStock(121);
        	mcapList.add(msap_1);
        	MerchStockAndPrice msap_2 = new MerchStockAndPrice();
        	msap_2.setMerchStandardIndex("0,0");
        	msap_2.setMerchUuid(msap_1.getMerchUuid());
        	msap_2.setPrice(11112.00);
        	msap_2.setStock(111);
        	mcapList.add(msap_2);
        	MerchandiseStandard ms = new MerchandiseStandard();
        	ms.setTopCategoryNameByteArr(DataConverUtils.stringArr2ByteArr(topCategoryName));
        	ms.setSecondCateGoryNameByteArr(DataConverUtils.stringArr2ByteArr(secondCategoryName[0]));
        	ms.setSecondCateGoryNameByteArr_2(DataConverUtils.stringArr2ByteArr(secondCategoryName[1]));
        	ms.setMcapList(mcapList);
        	ms.setMerchUuid(msap_1.getMerchUuid());
        	String mdata = "[{\"uuid\":\"750208120775038e9ea8721d97f8403ee01093ce7\",\"headPicsStr\":[\"http://tgi12.jia.com/116/307/16307875.jpg\",\"http://tgi12.jia.com/116/307/16307875.jpg\"],\"merchArea\":\"东莞11111\",\"merchAreaCityId\":\"\",\"merchAreaProvinceId\":\"\",\"merchLog\":\"http://sucai.dabaoku.com/meishu/logo/077cy.jpg\",\"merchName\":\"随机生成名字0\"}]";
        	merch = JSON.parseArray(mdata,Merchandise.class).get(0);
        	merch.setMerchandiseStandard(ms);
        	merch.setUuid(msap_1.getMerchUuid());
    	}else{
    		List <Merchandise> merchandiseList  = JSON.parseArray(data,Merchandise.class);
        	
        	if (merchandiseList == null || merchandiseList.size() == 0){
        		logger.warn("商品列表为空或者size为0");
        		return Response.response(ResponseType.EMPTY_CODE.getCode());
        	}
        	
        	merch = merchandiseList.get(0);
        	if(merch == null){
        		logger.warn("list.get(0)==null");
        		return Response.response(ResponseType.EMPTY_CODE.getCode());
        	}
    	}
    	
    	
    	
    	
    	
    	merchMapper.addNewMerchandise(merch);
    	ArrayList<MerchandiseStandard> msList = new ArrayList<>();
    	msList.add(merch.getMerchandiseStandard());
    	return this.dealWithMerchandiseStandard(msList, false);
    	
    }
    
    /**
     * 处理商品规格的增和改
     * @param merchandiseList
     * @param modify
     * @return
     */
    
    private Response dealWithMerchandiseStandard(List<MerchandiseStandard> merchandiseList, Boolean modify){
    	if(merchandiseList == null || merchandiseList.size() != 1 || merchandiseList.get(0) == null){
    		logger.warn("规格数据解析失败，规格数据列表为空或者size不为1");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(modify == null ){
    		logger.warn("modify为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	MerchandiseStandard ms = merchandiseList.get(0);
    		if(ms == null){
    			logger.warn("商品规格数据解析为空！");
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		if(ms.getMerchUuid() == null){
    			logger.warn("商品规格数据解析错误，原因是商品id传入为空！");
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		if(ms.getTopCategoryName() == null || ms.getSecondCateGoryName() == null){
    			logger.warn("商品{}规格数据解析失败，TopCategoryName或者SecondCateGoryName为空！", ms.getMerchUuid());
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		if(ms.getTopCategoryName().length !=1 && ms.getTopCategoryName().length !=2){
    			logger.warn("商品{}规格数据解析失败，TopCategoryName长度不为1或2", ms.getMerchUuid());
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		if(ms.getTopCategoryName().length == 1){
    			if(ms.getSecondCateGoryName().length!=1){
    				logger.warn("商品{}规格数据解析失败，TopCategoryName长度为1但是SecondCateGoryName长度不为1", ms.getMerchUuid());
        			return Response.response(ResponseType.EMPTY_CODE.getCode());
    			}
    			ms.setSecondCateGoryNameByteArr(DataConverUtils.stringArr2ByteArr(ms.getSecondCateGoryName()[0]));
    		}
    		if(ms.getTopCategoryName().length == 2){
    			if(ms.getSecondCateGoryName().length!=2){
    				logger.warn("商品{}规格数据解析失败，TopCategoryName长度为2但是SecondCateGoryName长度不为2", ms.getMerchUuid());
        			return Response.response(ResponseType.EMPTY_CODE.getCode());
    			}
    			ms.setSecondCateGoryNameByteArr(DataConverUtils.stringArr2ByteArr(ms.getSecondCateGoryName()[0]));
    			ms.setSecondCateGoryNameByteArr_2(DataConverUtils.stringArr2ByteArr(ms.getSecondCateGoryName()[1]));
    		}
    		
    		/**
    		 * 先更改MerchandiseStandard表中的 topCategoryNameByteArr，secondCateGoryNameByteArr， secondCateGoryNameByteArr_2
    		 * 这里要判断一下，里面是否有，有的话修改，没有的话删除
    		 */
    		
    		if(merchMapper.countMerchandiseStandardByMerchUuid(ms.getMerchUuid())==0){
    			merchMapper.addMerchandiseStandardByteArr(ms);
    		}else{
    			merchMapper.updateMerchandiseStandardByteArr(ms);
    		}
    		
    		
    		

    		/**
    		 * 再取出其中的merchStockAndPrice的list，判断，modify为true的话一个一个的更新，modify如果为false，把之前的全删掉，重新添加
    		 */
    	if(modify){
    		
    		if(ms.getMcapList() == null || ms.getMcapList().size() == 0){
    			logger.warn("商品{}规格数据解析失败，其中的McapList为空", ms.getMerchUuid());
    			return Response.response(ResponseType.EMPTY_CODE.getCode());
    		}
    		ms.getMcapList().forEach(item->{
    			merchMapper.updateTotalMerchStockAndPrice(item);
    		});
    		
    	}else{
    		merchMapper.deleteMerchStockAndPriceByMerchUuid(ms.getMerchUuid());
    		Map <String,String> recheckMap = new HashMap<>();
    		for (MerchStockAndPrice msap : ms.getMcapList()){
    			if(msap == null){
    			continue;
    			}
    			
    			msap.setCreateTime(Timestamp.from(Instant.now()));
    			
    			if(msap.getMerchUuid() == null || !msap.getMerchUuid().equals(ms.getMerchUuid())){
    				logger.warn("MerchStockAndPrice列表中的merchUuid为空或者与Merchandise中的不相同！");
    				continue;
    			}
    			//防止传入同一商品相同规格的进来
    			recheckMap.put("merchUuid", msap.getMerchUuid());
    			recheckMap.put("merchStandardIndex", msap.getMerchStandardIndex());
    			if(merchMapper.countMerchStockAndPriceCount(recheckMap)==0){
    				merchMapper.addMerchStockAndPriceByMerchUuid(msap);
    			}
    	}
    	}
    	return Response.success();
    }
    
    
    /**
     * 修改商品规格
     */ 
    @Override
    public Response updateMerchandiseStandard(String data, String merchandiserUuid, Boolean modify){
    	/**
    	 * 测试数据
    	 */
    	if(data == null){
    		String [] topCategoryName = new String[]{
        			"颜色","尺寸"
        	};
        	String [][] secondCategoryName = new String [][]{
        			new String []{
        					"黄色","蓝色","黑色"
        			},
        			new String []{
        					"s","m","x","xl"
        			}
        	};
        	
        	List<MerchStockAndPrice> mcapList = new ArrayList<>();
        	MerchStockAndPrice msap_1 = new MerchStockAndPrice();
        	msap_1.setMerchStandardIndex("0,1");
        	msap_1.setMerchUuid("16920022021afe1edd779f06995b4087f08c99c3e");
        	msap_1.setPrice(123.00);
        	msap_1.setStock(121);
        	mcapList.add(msap_1);
        	MerchStockAndPrice msap_2 = new MerchStockAndPrice();
        	msap_2.setMerchStandardIndex("0,0");
        	msap_2.setMerchUuid("16920022021afe1edd779f06995b4087f08c99c3e");
        	msap_2.setPrice(11112.00);
        	msap_2.setStock(111);
        	mcapList.add(msap_2);
        	
        	Object [] objarr = new Object[1];
        	
        	Map paramsMap = new HashMap<>();
        	
        	paramsMap.put("merchUuid", "16920022021afe1edd779f06995b4087f08c99c3e");
        	
        	paramsMap.put("topCategoryName", topCategoryName);
        	
        	paramsMap.put("secondCategoryName", secondCategoryName);
        	
        	paramsMap.put("mcapList",mcapList);
        	
        	objarr[0] = paramsMap;
        	
        	data = JSON.toJSONString(objarr);
        	
//        	logger.warn("data为空！");
//        	return Response.response(ResponseType.EMPTY_CODE.getCode());
        	
    	}
    	
    	
    	List <MerchandiseStandard> merchandiseList  = JSON.parseArray(data,MerchandiseStandard.class);
    	return this.dealWithMerchandiseStandard(merchandiseList, modify);

    	
    }
    
    
    
    
    
    
    /**
     * 商家端修改商品基本信息（可能属性不全，待增加）
     * 
     */
    @Override
    public Response updateMerchandiseDetail(String data){
    	data = "[{\"uuid\":\"750208120775038e9ea8721d97f8403ee01093ce7\",\"headPicsStr\":[\"http://tgi12.jia.com/116/307/16307875.jpg\",\"http://tgi12.jia.com/116/307/16307875.jpg\"],\"merchArea\":\"东莞11111\",\"merchAreaCityId\":\"\",\"merchAreaProvinceId\":\"\",\"merchLog\":\"http://sucai.dabaoku.com/meishu/logo/077cy.jpg\",\"merchName\":\"随机生成名字0\"}]";
    	List<Merchandise> merchList = JSON.parseArray(data, Merchandise.class);
    	merchList.forEach(item->{
    		item.setHeadPics(DataConverUtils.stringArr2ByteArr(item.getHeadPicsStr()));
    		merchMapper.updateMerchandiseDetail(item);
    	});
    	return null;
    }
    
    /**
     * 商品编辑页面详情展示
     * @param uuid 商品的uuid
     */
    @Override
    public Response loadMerchandiseDetail(String uuid){
    	
    	uuid = "750208120775038e9ea8721d97f8403ee01093ce7";
    	
    	List <Merchandise> merchList = merchMapper.loadMerchandiseDetail(uuid);
    	
    	merchList.forEach(item->{
    		item.setHeadPicsStr(DataConverUtils.byteArr2StringArr(item.getHeadPics()));
    	});
    	
    	System.out.println(JSON.toJSONString(merchList));
    	
    	JSONObject json = new JSONObject();
    	json.put("content", merchList);
    	
    	return Response.success(json);
    	
    }
    /**
     * 商品批量下架
     */
    @Override
    public Response offShelvedMerchList(String data, String merchandiserUuid){
    	if(merchandiserUuid == null){
    		logger.warn("下架商品的时候，商家id为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());	
    	}
   data = "[{'uuid':'750208120775038e9ea8721d97f8403ee01093ce7','merchBelongToUuid':'393957120066be447fd3c52088174087d224b3abd'}]";
    	List<Merchandise> mcapList = JSON.parseArray(data,Merchandise.class);
    	if( mcapList == null || mcapList.size() == 0){
    		logger.warn("批量下架商品的时候，传入的data解析成的列表为空");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());	
    	}
    	for(Merchandise m : mcapList){
    		if(m != null && m.getMerchBelongToUuid()!=null && merchandiserUuid.equals(m.getMerchBelongToUuid())){
    			merchMapper.offShelvedMerchList(m.getUuid());
    		}
    	}
    	return Response.success();
    }
    
    
    /**
     * 商品库存全部置满
     */
    
    
    @Override
    public Response fullfilAllMerchStock(String data, Integer stock){
    	data = "[{'merchStandardIndex':'0,0','merchUuid':'16920022021afe1edd779f06995b4087f08c99c3e','price':62,'stock':203}"
    			+ ",{'merchStandardIndex':'0,1','merchUuid':'9263202205162b7aef88317db0504094ac4c17aff','price':62,'stock':203}]";
    	if(data == null){
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	if(stock == null){
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	List<MerchStockAndPrice> mcapList = JSON.parseArray(data,MerchStockAndPrice.class);
    	if(mcapList == null || mcapList.size() == 0){
    		logger.warn("传入的data数据解析为MerchStockAndPrice列表为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	Map paramMap = new HashMap<>();
    	paramMap.put("stock", 10001);
    	mcapList.forEach(item->{
    		paramMap.put("merchUuid", item.getMerchUuid());
    		merchMapper.fullfilAllMerchStock(paramMap);
    	});
    	
    	
    	
    	
    	return Response.success();
    }
    
    /**
     * 修改商品规格中的库存和价格
     */
    @Override
    public Response updateMerchStockAndPrice(String data){
    	data = "[{'merchStandardIndex':'0,0','merchUuid':'16920022021afe1edd779f06995b4087f08c99c3e','price':62,'stock':203}"
    			+ ",{'merchStandardIndex':'0,1','merchUuid':'16920022021afe1edd779f06995b4087f08c99c3e','price':62,'stock':203}]";
    	if(data == null){
    		logger.warn("data为null！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	
    	List<MerchStockAndPrice> mcapList = JSON.parseArray(data,MerchStockAndPrice.class);
    	
    	if(mcapList == null || mcapList.size() == 0){
    		logger.warn("传入的data数据解析为MerchStockAndPrice列表为空！");
    		return Response.response(ResponseType.EMPTY_CODE.getCode());
    	}
    	mcapList.forEach(item->{
    		merchMapper.updateTotalMerchStockAndPrice(item);
    	});
    	
    	return Response.success();
    	
    }
    
    
    
    
    
    
    
/**
 * 商家商品列表（暂时只查询三个参数，商品名称，商品首图，商品价格）
 * @param merchandiserUuid 商家id
 * @param page 页数
 * @param size 每页商品数目
 */
	@Override
	public Response findAllMyMerchandise(String merchandiserUuid, Integer page, Integer size){
		
		if(merchandiserUuid == null){
			//return Response.response(ResponseType.EMPTY_CODE.getCode());
		}
		Map <String,Object> paramMap = new HashMap<>();
		paramMap.put("merchBelongToUuid", merchandiserUuid);
		if(page == null || page <= 0 ){
			page = 0;
		}else{
			page = page -1;
		}
		if(size == null || size <=0){
			size = 20;
		}
		paramMap.put("begin", page*size);
		paramMap.put("size", size);
		return Response.success(merchMapper.findAllMyMerchandise(paramMap));
	}



}
