package org.nessary.project.service.merchandiseModify.mapper;

import java.util.List;
import java.util.Map;

import org.nessary.project.facade.merchandise.entity.MerchStockAndPrice;
import org.nessary.project.facade.merchandise.entity.Merchandise;
import org.nessary.project.facade.merchandise.entity.MerchandiseStandard;
import org.nessary.project.facade.merchandise.entity.OrderEntity;
import org.nessary.project.facade.merchandise.entity.OrderStatusCounts;
import org.springframework.data.repository.query.Param;

public interface MerchandiseMapper {
	List<Merchandise> findAllMyMerchandise(Map paramMap);
	void updateTotalMerchStockAndPrice(MerchStockAndPrice msap);
	void fullfilAllMerchStock(Map paramMap);
	void offShelvedMerchList(@Param("uuid") String uuid);
	List<Merchandise> loadMerchandiseDetail(@Param("uuid") String uuid);
	void updateMerchandiseDetail(Merchandise m);
	void updateMerchandiseStandardByteArr(MerchandiseStandard ms);
	
	void addMerchStockAndPriceByMerchUuid(MerchStockAndPrice ms);
	void deleteMerchStockAndPriceByMerchUuid(@Param("merchUuid") String merchUuid);
	int countMerchStockAndPriceCount(Map recheckMap);
	void addNewMerchandise(Merchandise m);
	int countMerchandiseStandardByMerchUuid(@Param("merchUuid") String merchUuid);
	void addMerchandiseStandardByteArr(MerchandiseStandard ms);
	int editOrderInfo_address(OrderEntity o);
	List<OrderEntity> loadOrderInfo_merchUuidArr(@Param("orderNo") String orderNo);
	Double loadMerchPriceByUuidAndIndex(Map paramsMap);
	int updateOrderInfo_merchIndexArr(OrderEntity order);
	List<OrderStatusCounts> loadOrderStatusCount(Map paramsMap);
	List<OrderEntity> loadOrdersByStatusAndMerchandiseUuid(Map paramsMap);
	List<OrderEntity> loadSingleOrderDetail(String orderNo);
	int updateOrderInfo_message(Map m);
	int changeOrderStatusByMerchandiser(Map m);
	int loadSingleOrderStatus(String m);
}
