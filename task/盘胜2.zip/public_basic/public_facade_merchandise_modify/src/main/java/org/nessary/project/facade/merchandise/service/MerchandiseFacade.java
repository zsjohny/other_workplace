package org.nessary.project.facade.merchandise.service;

import java.util.List;

//import org.nessary.project.utils.operate.Response;
import org.nessary.project.utils.operate.Response;

public interface MerchandiseFacade {


	//Response findAllMyMerchandise(String merchandiserUuid, Integer page, Integer size);

	void test001();

	Response findAllMyMerchandise(String merchandiserUuid, Integer page, Integer size);

	Response updateMerchStockAndPrice(String data);

	Response fullfilAllMerchStock(String data, Integer stock);

	Response offShelvedMerchList(String data, String merchandiserUuid);

	Response loadMerchandiseDetail(String uuid);

	Response updateMerchandiseDetail(String data);


	Response updateMerchandiseStandard(String data, String merchandiserUuid, Boolean modify);

	Response addNewMerchandise(String data);


	Response editOrderInfo_address(String orderNo, String receiveAddressDetail, String merchandiserUuid);

	Response editOrderInfo_merchIndex(String orderNo, String merchUuid, String newIndex, String oldIndex);

	Response loadOrderStatusCount(String merchandiserUuid);

	Response loadOrdersByStatusAndMerchandiseUuid(String merchandiserUuid, Integer status, Integer page, Integer size);

}
