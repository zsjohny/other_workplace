package org.nessary.project.facade.merchandise.entity;

public class OrderStatusCounts {
	
	private Integer status;
	private int count;
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "OrderStatusCounts [status=" + status + ", count=" + count + "]";
	}
	
	
}
