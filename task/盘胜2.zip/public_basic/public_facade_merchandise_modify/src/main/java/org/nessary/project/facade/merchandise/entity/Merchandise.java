package org.nessary.project.facade.merchandise.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 商品类型
 * Created by Ness on 2016/12/16.
 */
public class Merchandise implements Serializable{
    private static final long serialVersionUID = -3917672792365545341L;
    private Long id;

    private String uuid;

    /**
     * 商品的图标
     */
    private String merchLog;

    private Integer offShelve;
    
    /**
     * 轮播图的介绍
     */
    private String[] headPicsStr;
    
    private byte[] headPics;
    
    /**
     * 商品名称
     */
    private String merchName;

    /**
     * 商品的运输类型----目前放到商品里面
     */
    private String mechCarriageCate;

    private Integer mechCarriageCateId;

    /**
     * 所属分类
     */
    private String merchBelogClass;

    /**
     * 所属分类的父Id
     */
    private String merchaBelogClassParentId;

    /**
     * 所属分类的id
     */
    private String merchanBelogCLassId;


    /**
     * 是否是新的产品
     */
    private String merchIsNew;


    /**
     * 属性的标识 热门 快手党 精品搭配
     */
    private String merchQuality;


    /**
     * 所属属性的Id
     */
    private String merchQualityId;


    /**
     * 商品的价格
     */
    private Double merchPrice;


    /**
     * 商品的折扣价
     */
    private Double merchDisPrice;


    /**
     * 商品已经卖的数量
     */
    private Integer merchHaveSaleTotalCount;

    /**
     * 商品已经月的数量
     */
    private Integer merchHaveSaleMonthCount;

    /**
     * 商品的地区
     */
    private String merchArea;


    /**
     * 商品的地区的省Id
     */
    private String merchAreaProvinceId;

    /**
     * 商品的地区的城市Id
     */
    private String merchAreaCityId;

    /**
     * 商品的地区的区域Id
     */
    private String merchAreaDistId;


    /**
     * 商品所拥有的优势
     */
    private String[] merchHavDistange;

    /**
     * 图片的产品参数
     */
    private String merchProParam;

    /**
     * 商品的图文详情
     */
    private byte[] merchantDetails;
    
    private String [] merchantDetailsStringArr;

    /**
     * 所属谁的商品
     */
    private String merchBelongToUuid;

    /**
     * 首页活动的描述
     */
    private String merchActiveDes;

    /**
     * 抢购的活动描述
     */
    private String purcaseDes;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;


    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;
    
    /**
     * 收藏
     */
    
    private Boolean collection;
    
    /**
     * 商品详情中的文字描述
     */
    private String merchDetailDescriptions;
    
    
    private MerchandiseStandard merchandiseStandard;
    
    
    /**
     * 购买人数
     */
    private Integer buyNNT;
    

    public static int COLLGATE = 0;
    public static int SALE_COUNT = 1;
    public static int SALE_PRICE = 2;
    public static int SORT_ASC = 0;
    public static int SORT_DESC = 1;


    public Long getId() {
        return id;
    }

    public String getPurcaseDes() {
        return purcaseDes;
    }

    public void setPurcaseDes(String purcaseDes) {
        this.purcaseDes = purcaseDes;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getMerchLog() {
        return merchLog;
    }

    public void setMerchLog(String merchLog) {
        this.merchLog = merchLog;
    }
    
    

    public Integer getOffShelve() {
		return offShelve;
	}

	public void setOffShelve(Integer offShelve) {
		this.offShelve = offShelve;
	}

	public String getMerchName() {
        return merchName;
    }

    public void setMerchName(String merchName) {
        this.merchName = merchName;
    }

    public String getMerchBelogClass() {
        return merchBelogClass;
    }

    public void setMerchBelogClass(String merchBelogClass) {
        this.merchBelogClass = merchBelogClass;
    }

    public String getMerchaBelogClassParentId() {
        return merchaBelogClassParentId;
    }

    public void setMerchaBelogClassParentId(String merchaBelogClassParentId) {
        this.merchaBelogClassParentId = merchaBelogClassParentId;
    }

    public String getMerchanBelogCLassId() {
        return merchanBelogCLassId;
    }

    public void setMerchanBelogCLassId(String merchanBelogCLassId) {
        this.merchanBelogCLassId = merchanBelogCLassId;
    }

    public String getMerchIsNew() {
        return merchIsNew;
    }

    public void setMerchIsNew(String merchIsNew) {
        this.merchIsNew = merchIsNew;
    }

    public String getMerchQuality() {
        return merchQuality;
    }

    public void setMerchQuality(String merchQuality) {
        this.merchQuality = merchQuality;
    }

    public String getMerchQualityId() {
        return merchQualityId;
    }

    public void setMerchQualityId(String merchQualityId) {
        this.merchQualityId = merchQualityId;
    }

    public Double getMerchPrice() {
        return merchPrice;
    }

    public void setMerchPrice(Double merchPrice) {
        this.merchPrice = merchPrice;
    }

    public Double getMerchDisPrice() {
        return merchDisPrice;
    }

    public void setMerchDisPrice(Double merchDisPrice) {
        this.merchDisPrice = merchDisPrice;
    }

    public Integer getMerchHaveSaleTotalCount() {
        return merchHaveSaleTotalCount;
    }

    public void setMerchHaveSaleTotalCount(Integer merchHaveSaleTotalCount) {
        this.merchHaveSaleTotalCount = merchHaveSaleTotalCount;
    }

    public Integer getMerchHaveSaleMonthCount() {
        return merchHaveSaleMonthCount;
    }

    public void setMerchHaveSaleMonthCount(Integer merchHaveSaleMonthCount) {
        this.merchHaveSaleMonthCount = merchHaveSaleMonthCount;
    }

    public String getMerchArea() {
        return merchArea;
    }

    public void setMerchArea(String merchArea) {
        this.merchArea = merchArea;
    }

    public String getMerchAreaProvinceId() {
        return merchAreaProvinceId;
    }

    public void setMerchAreaProvinceId(String merchAreaProvinceId) {
        this.merchAreaProvinceId = merchAreaProvinceId;
    }

    public String getMerchAreaCityId() {
        return merchAreaCityId;
    }

    public void setMerchAreaCityId(String merchAreaCityId) {
        this.merchAreaCityId = merchAreaCityId;
    }

    public String getMerchAreaDistId() {
        return merchAreaDistId;
    }

    public void setMerchAreaDistId(String merchAreaDistId) {
        this.merchAreaDistId = merchAreaDistId;
    }

    public String[] getMerchHavDistange() {
        return merchHavDistange;
    }

    public void setMerchHavDistange(String[] merchHavDistange) {
        this.merchHavDistange = merchHavDistange;
    }

    public String getMerchProParam() {
        return merchProParam;
    }

    public void setMerchProParam(String merchProParam) {
        this.merchProParam = merchProParam;
    }


    public byte[] getMerchantDetails() {
		return merchantDetails;
	}

	public void setMerchantDetails(byte[] merchantDetails) {
		this.merchantDetails = merchantDetails;
	}

	public String[] getMerchantDetailsStringArr() {
		return merchantDetailsStringArr;
	}

	public void setMerchantDetailsStringArr(String[] merchantDetailsStringArr) {
		this.merchantDetailsStringArr = merchantDetailsStringArr;
	}

	public String getMerchBelongToUuid() {
        return merchBelongToUuid;
    }

    public void setMerchBelongToUuid(String merchBelongToUuid) {
        this.merchBelongToUuid = merchBelongToUuid;
    }

    public String getMerchActiveDes() {
        return merchActiveDes;
    }

    public void setMerchActiveDes(String merchActiveDes) {
        this.merchActiveDes = merchActiveDes;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getMechCarriageCate() {
        return mechCarriageCate;
    }

    public void setMechCarriageCate(String mechCarriageCate) {
        this.mechCarriageCate = mechCarriageCate;
    }

    
    
    
    public MerchandiseStandard getMerchandiseStandard() {
		return merchandiseStandard;
	}

	public void setMerchandiseStandard(MerchandiseStandard merchandiseStandard) {
		this.merchandiseStandard = merchandiseStandard;
	}

	public String getMerchDetailDescriptions() {
		return merchDetailDescriptions;
	}

	public void setMerchDetailDescriptions(String merchDetailDescriptions) {
		this.merchDetailDescriptions = merchDetailDescriptions;
	}

	public Integer getMechCarriageCateId() {
        return mechCarriageCateId;
    }

    public void setMechCarriageCateId(Integer mechCarriageCateId) {
        this.mechCarriageCateId = mechCarriageCateId;
    }
    public Boolean getCollection() {
		return collection;
	}

	public void setCollection(Boolean collection) {
		this.collection = collection;
	}
	public Integer getBuyNNT() {
		return buyNNT;
	}

	public void setBuyNNT(Integer buyNNT) {
		this.buyNNT = buyNNT;
	}
	public Merchandise(){
		
	}

	public String[] getHeadPicsStr() {
		return headPicsStr;
	}

	public void setHeadPicsStr(String[] headPicsStr) {
		this.headPicsStr = headPicsStr;
	}

	public byte[] getHeadPics() {
		return headPics;
	}

	public void setHeadPics(byte[] headPics) {
		this.headPics = headPics;
	}

	public Merchandise(String merchaBelogClassParentId, String merchanBelogCLassId) {
		super();
		this.merchaBelogClassParentId = merchaBelogClassParentId;
		this.merchanBelogCLassId = merchanBelogCLassId;
	}

	public Merchandise(String uuid, String merchLog, String merchName, Double merchPrice) {
		super();
		this.uuid = uuid;
		this.merchLog = merchLog;
		this.merchName = merchName;
		this.merchPrice = merchPrice;
	}
}
