package org.nessary.project.facade.merchandise.entity;


import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 商品的规格属性
 * Created by Ness on 2016/12/19.
 */
public class MerchandiseStandard {
    private Integer id;

    /**
     * uuid
     */
    private String uuid;

    /**
     * 一级分类的组成 存储格式 简单的数据 [xxx,xxx,xxx]
     */
    private String[] topCategoryName;

    /**
     * 二级分类的组成 存储格式 一个大数组嵌套单个小数组(小数组是对应 一级分类的索引) eg [ [xx,xx,xx] ,[xx,xx,xx] ]
     */
    private String[][] secondCateGoryName;

    /**
     * 对应商品价格  存储格式 一个大数组嵌套单个小数组 （小数组是对应 二级分类的索引) eg [ [xxx,xxx,xxx] ,[xxx,xxx,xxx] ] 当小组数里面有-1 表示不存在改价格
     */
    private String[][] prices;
    
    
    private byte[] topCategoryNameByteArr;
    
    
    private byte[] secondCateGoryNameByteArr;

    private byte[] secondCateGoryNameByteArr_2;

    /**
     * 对应的库存 存储格式  一个大数组嵌套单个小数组 （小数组是对应 二级分类的索引) eg [ [xx,xx,xx] ,[xxx,xx,xx] ] 当小组数里面有-1 表示不存在改价格
     */
   
    private String[][] stocks;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;
    
    private String merchUuid;

    /**
     * 是否删除 true是删除 false不是
     */
    private Boolean deleted;

    
    private String merchLog;
    
    
    private List<MerchStockAndPrice> mcapList;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
    public String[] getTopCategoryName() {
        return topCategoryName;
    }

    public void setTopCategoryName(String[] topCategoryName) {
        this.topCategoryName = topCategoryName;
    }
    
    public String[][] getSecondCateGoryName() {
        return secondCateGoryName;
    }

    public void setSecondCateGoryName(String[][] secondCateGoryName) {
        this.secondCateGoryName = secondCateGoryName;
    }
    
    
    
    
    public byte[] getTopCategoryNameByteArr() {
		return topCategoryNameByteArr;
	}

	public void setTopCategoryNameByteArr(byte[] topCategoryNameByteArr) {
		this.topCategoryNameByteArr = topCategoryNameByteArr;
	}
	


	public byte[] getSecondCateGoryNameByteArr() {
		return secondCateGoryNameByteArr;
	}

	public void setSecondCateGoryNameByteArr(byte[] secondCateGoryNameByteArr) {
		this.secondCateGoryNameByteArr = secondCateGoryNameByteArr;
	}

	public String[][] getPrices() {
        return prices;
    }

    public void setPrices(String[][] prices) {
        this.prices = prices;
    }
    public String[][] getStocks() {
        return stocks;
    }

    public void setStocks(String[][] stocks) {
        this.stocks = stocks;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
    
    
    public String getMerchUuid() {
		return merchUuid;
	}

	public void setMerchUuid(String merchUuid) {
		this.merchUuid = merchUuid;
	}

	public String getMerchLog() {
		return merchLog;
	}

	public void setMerchLog(String merchLog) {
		this.merchLog = merchLog;
	}
	
	
	
	

	public List<MerchStockAndPrice> getMcapList() {
		return mcapList;
	}

	public void setMcapList(List<MerchStockAndPrice> mcapList) {
		this.mcapList = mcapList;
	}
	
	

	public byte[] getSecondCateGoryNameByteArr_2() {
		return secondCateGoryNameByteArr_2;
	}

	public void setSecondCateGoryNameByteArr_2(byte[] secondCateGoryNameByteArr_2) {
		this.secondCateGoryNameByteArr_2 = secondCateGoryNameByteArr_2;
	}

	public MerchandiseStandard(String[][] secondCateGoryName) {
		super();
		this.secondCateGoryName = secondCateGoryName;
	}

	public MerchandiseStandard() {
		super();
	}

	
	
	
	
}
