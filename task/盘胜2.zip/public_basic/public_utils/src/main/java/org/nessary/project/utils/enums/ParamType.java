package org.nessary.project.utils.enums;

/**
 * 各类长度的判断
 * Created by Ness on 2016/12/5.
 */
public enum ParamType {
    NAME(20), AGE(10),PASS(8),EMAIL(16),UID(10),UUID(10),TOKEN(10);
    private int length;

    ParamType(int length) {
        this.length = length;
    }

    public int getLegalLength() {
        return length;
    }
}
