package org.nessary.project.utils.operate;

import com.alibaba.fastjson.JSON;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.annotion.ServiceInvoke;
import org.nessary.project.utils.http.Iptools;
import org.nessary.project.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * 权限拦截
 * Created by Ness on 2016/12/14.
 */
// 代表aop执行的顺序的问题，值越小越优先--可以用于验证和写日志的顺序先后
@Order(1)
@Aspect
public class AuthValidate implements HandlerExceptionResolver, ApplicationListener<ContextRefreshedEvent> {

    private UserUtils userUtils;
    private static Logger logger = LoggerFactory.getLogger(AuthValidate.class);
    private String TOURIST_URI = "tourist.do";

    @Autowired
    private HttpServletRequest request;

    private int ACCESS_FORBIDDEN_TIMES = 10;
    private int ACCESS_INTERVAL_TIMES = 60000;

    private static Boolean NOT_INIT = true;
    private static Map<String, String> _allowAccessMethodMap;

    private final String SPLIT = "/";
    private final String METHOD_ACTION = ".do";


    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        synchronized (AuthValidate.class) {
            if (NOT_INIT) {
                _allowAccessMethodMap = new HashMap<>();
                Map<String, Object> beansWithAnnotation = contextRefreshedEvent.getApplicationContext().getBeansWithAnnotation(RestController.class);

                for (Object bean : beansWithAnnotation.values()) {
                    if (bean == null) {
                        continue;

                    }

                    Method[] methods = bean.getClass().getMethods();

                    for (Method method : methods) {
                        if (method == null) {
                            continue;

                        }
                        ServiceInvoke annotation = method.getAnnotation(ServiceInvoke.class);

                        if (annotation != null) {
                            _allowAccessMethodMap.put(annotation.value() + METHOD_ACTION, annotation.value() + METHOD_ACTION);
                        }

                    }

                }
                _allowAccessMethodMap = Collections.unmodifiableMap(_allowAccessMethodMap);

                NOT_INIT = false;
            }

        }
    }

    /**
     * 访问记录
     */
    private class AccessRecord {
        /**
         * 第一次访问时间
         */
        private Long firstAccessTime;

        /**
         * 访问的次数
         */
        private Integer accessTImes;

        public Long getFirstAccessTime() {
            return firstAccessTime;
        }

        public void setFirstAccessTime(Long firstAccessTime) {
            this.firstAccessTime = firstAccessTime;
        }

        public Integer getAccessTImes() {
            return accessTImes;
        }

        public void setAccessTImes(Integer accessTImes) {
            this.accessTImes = accessTImes;
        }

        @Override
        public String toString() {
            return "AccessRecord{" +
                    "firstAccessTime=" + firstAccessTime +
                    ", accessTImes=" + accessTImes +
                    '}';
        }
    }

    private ConcurrentHashMap<String, AccessRecord> ipInterfact = new ConcurrentHashMap<>();

    public UserUtils getUserUtils() {
        return userUtils;
    }

    public void setUserUtils(UserUtils userUtils) {
        this.userUtils = userUtils;
    }

    // 前置通知，*包含任意个位置的..任意参数
    // @Before(value = "execution(public * org.finace.user.controller.*.*.*(.. ))")
    @Before(value = "execution(@org.nessary.project.utils.annotion.Author * *(..))")
    public void beforeValidation(JoinPoint joinPoint) {

        if (userUtils == null) {
            throw new RuntimeException("userUtils初始化不能为null");
        }

        //ip的拦截--
        String ip = Iptools.gainRealIp(request);

        String[] urls = request.getRequestURI().split(SPLIT);
        //判断是否是内部访问方法
        String method = _allowAccessMethodMap.get(urls[urls.length - 1]);
        if (!Regular.checkEmpty(method, null)) {
            logger.info("ip {} 正在访问 内部方法 {} ", ip, method);
            request.setAttribute("invoke", "invoke");
            return;
        }


        if (Regular.checkEmpty(ip, null)) {
            logger.warn("空Ip地址正在进行访问......");
            request.setAttribute("forbidden", true);
        } else {

            AccessRecord accessRecord = ipInterfact.get(ip);

            if (accessRecord == null || System.currentTimeMillis() - accessRecord.getFirstAccessTime() > ACCESS_INTERVAL_TIMES) {
                accessRecord = new AccessRecord();
                accessRecord.setAccessTImes(0);
                accessRecord.setFirstAccessTime(System.currentTimeMillis());
            }

            AtomicInteger atomiInteger = new AtomicInteger(accessRecord.getAccessTImes());
            accessRecord.setAccessTImes(atomiInteger.incrementAndGet());

            if (accessRecord.getFirstAccessTime() - System.currentTimeMillis() < ACCESS_INTERVAL_TIMES && accessRecord.getAccessTImes() > ACCESS_FORBIDDEN_TIMES) {
                logger.warn("ip{} 时间间隔 {} 毫秒 访问了 {} 次 ,已拦截 ", ip, accessRecord.getFirstAccessTime() - System.currentTimeMillis(), accessRecord.getAccessTImes());
                request.setAttribute("forbidden", true);
                System.out.println("11111111");
            } else {
                request.setAttribute("forbidden", false);
            }

            ipInterfact.put(ip, accessRecord);

        }


        String token = request.getHeader("token");
        String uid = request.getHeader("uid");
        //排除游客模式
        if (!request.getRequestURI().endsWith(TOURIST_URI)) {
            if (!userUtils.checkValid(token, uid)) {
                logger.warn("用户{},ip={},id=[], 没有权限访问", token, Iptools.gainRealIp(request), uid);
                request.setAttribute("byAccess", false);
            } else {
                request.setAttribute("uuid", userUtils.getUuid(token));

                request.setAttribute("byAccess", true);
            }
        }

    }


    /*  // 返回通知
      // JoinPoint代表切入点
      @AfterReturning(pointcut = "execution(public * com.ouliao.controller.*.*.*(.. ))", returning = "object")
      public void afterValidation(JoinPoint joinPoint, Object object) {

      }*/
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object o, Exception e) {
        try {
            logger.warn("方法{},出现异常", request.getRequestURI(), e);
            response.setStatus(HttpServletResponse.SC_OK);
            response.getOutputStream().write(JSON.toJSONBytes(Response.error()));
        } catch (IOException e1) {

        }
        return null;
    }


}
