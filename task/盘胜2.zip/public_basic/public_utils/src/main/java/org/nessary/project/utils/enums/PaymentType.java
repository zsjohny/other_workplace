package org.nessary.project.utils.enums;

public enum PaymentType {
	
	BALANCE_PAYMENT("balance_payment");
	
	 private String key;

	 PaymentType(String key) {
	        this.key = key;
	    }

	    public String getName() {
	        return key;
	    }

}
