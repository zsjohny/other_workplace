package org.nessary.project.utils.prop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.Properties;

/**
 * 默认数据加载
 * Created by Ness on 2016/12/8.
 */
public class DataProperties extends PropertyPlaceholderConfigurer {
    private Properties properties;

    @Override
    protected Properties mergeProperties() throws IOException {
        properties = super.mergeProperties();

        return properties;
    }

    /**
     * 接收jms信息
     */
    public class inner{
        void doMessage(String key,Object value){
            if (key.equals("")||value.equals("")){
                return;
            }
            if (value!=properties.getProperty(key)) {
                properties.setProperty(key, String.valueOf(value));
            }
        }
    }



    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
       DataProperties s = (DataProperties) context.getBean("dataProperties");
        System.out.println(s.getProperty("test"));
    }
}
