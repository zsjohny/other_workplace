package org.nessary.project.utils.concurrent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 多线程执行任务
 * <p>
 * Created by Ness on 2017/1/5.
 */
public class ExecutorService implements DisposableBean {
    private Logger logger = LoggerFactory.getLogger(ExecutorService.class);

    private ThreadPoolExecutor poolExecutor;

    private int MULTIPLE = 2;
    private int LIVE_TILE = 200;
    private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();


    /**
     * 初始化pool线程
     */ {
        int cpuCount = Runtime.getRuntime().availableProcessors();

        poolExecutor = new ThreadPoolExecutor(cpuCount >> MULTIPLE, cpuCount, LIVE_TILE, TimeUnit.MILLISECONDS, queue, new ExcutorThreadFactory(), new DealWithTask());

    }


    /**
     * 添加执行任务
     *
     * @param task
     */
    public void addTask(ExecutorTask task) {
        poolExecutor.execute(task);
    }


    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:public.utils/app_*.xml");

        ExecutorService service = new ExecutorService();

        for (int i = 0; i < 100; i++) {

            final int a = i;
            service.addTask(new ExecutorTask() {
                @Override
                public void doJob() {
                    System.out.println("into:" + a);
                }
            });
        }


    }

    private class DealWithTask implements RejectedExecutionHandler {
        private final AtomicInteger incrementId = new AtomicInteger(0);

        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            if (!executor.isShutdown()) {
                logger.warn("开始开辟新的线程执行失败的任务{}", r);
                new Thread(new ThreadGroup("new finace group" + incrementId.getAndDecrement()), r).start();
                logger.warn("结束开辟新的线程执行失败的任务{}", r);
            }

        }
    }


    private class ExcutorThreadFactory implements ThreadFactory {

        private final ThreadGroup group;

        private final AtomicLong threadCount = new AtomicLong(0);
        private final StringBuilder bulid = new StringBuilder("finace");

        {
            SecurityManager manager = System.getSecurityManager();
            group = (manager == null ? Thread.currentThread().getThreadGroup() : manager.getThreadGroup());
        }


        @Override
        public Thread newThread(Runnable r) {
            bulid.substring(0, "finace".length());
            Thread thread = new Thread(group, r, bulid.append(threadCount.incrementAndGet()).toString());
            if (thread.isDaemon()) {
                thread.setDaemon(false);
            }
            thread.setPriority(Thread.NORM_PRIORITY);

            return thread;
        }
    }


    @Override
    public void destroy() throws Exception {
        if (!poolExecutor.isShutdown()) {
            poolExecutor.shutdown();
            logger.info("关闭线程组success");

        }
    }
}
