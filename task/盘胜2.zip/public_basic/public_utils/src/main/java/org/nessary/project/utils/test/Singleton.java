package org.nessary.project.utils.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.jar.JarInputStream;
import java.util.zip.ZipEntry;

/**
 * Created by Ness on 2017/1/2.
 */
public class Singleton {


}


