package org.nessary.project.utils.annotion.table;

import java.lang.annotation.*;

/**
 * Created by Ness on 2017/2/16.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Table {
    String value() ;

}
