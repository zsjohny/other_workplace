package org.nessary.project.utils.operate;

import com.alibaba.fastjson.JSON;
import org.nessary.project.utils.annotion.Author;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by Ness on 2016/12/15.
 */
public class AuthInterpect implements HandlerInterceptor {

    private String TOURIST_URI = "tourist.do";

    @Override
    @Author
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {

        //IP重复和没有Ip的拦截
        Object obj = request.getAttribute("forbidden");
        if (obj == null || (Boolean) obj) {
//            response.getOutputStream().write(JSON.toJSONBytes(Response.forbitten()));
//            return false;
//测试放开

        }

        //排除内部方法
        Object invoke = request.getAttribute("invoke");
        if (invoke != null) {
            return true;
        }

        //排除游客模式
        if (!request.getRequestURI().endsWith(TOURIST_URI)) {
            obj = request.getAttribute("byAccess");
            if (obj != null) {
                Boolean flag = (Boolean) obj;
                if (!flag) {
                    response.getOutputStream().write(JSON.toJSONBytes(Response.noAuthor()));
                    return false;
                }
            }
        }

        return true;
    }


    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }


}
