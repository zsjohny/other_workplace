package org.nessary.project.utils.enums;

/**
 * 发送消息的提示
 * Created by Ness on 2016/12/8.
 */
public enum NotifyType {
    SEND_EAMIL(0), SEND_SMS(1);
    private Integer key;

    NotifyType(Integer key) {
        this.key = key;
    }


    public Integer getType() {
        return key;
    }

}
