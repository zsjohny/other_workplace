package org.nessary.project.utils.push

import java.sql.Timestamp

/**
 * Created by Ness on 2017/2/8.
 */
class Push {
    private Integer id;

    /**
     * 发送的设备
     */
    private Integer sendDeviceType;

    /**
     * 发送的设备编号
     */
    private String deviceNum;


    /**
     * 关联用户的id
     */
    private String uuid;

    /**
     * 发送的消息主题
     */
    private String sendTopic;

    /**
     * 发送的消息内容
     */
    private String sendContent;

    /**
     * 创建时间
     */
    private Timestamp createTime;

    /**
     * 是否删除 false不是  true删除
     */
    private Boolean deleted;

    /**
     * 修改时间
     */
    private Timestamp updateTime;Integer getId() {
        return id
    }

    void setId(Integer id) {
        this.id = id
    }

    Integer getSendDeviceType() {
        return sendDeviceType
    }

    void setSendDeviceType(Integer sendDeviceType) {
        this.sendDeviceType = sendDeviceType
    }

    String getDeviceNum() {
        return deviceNum
    }

    void setDeviceNum(String deviceNum) {
        this.deviceNum = deviceNum
    }

    String getUuid() {
        return uuid
    }

    void setUuid(String uuid) {
        this.uuid = uuid
    }

    String getSendTopic() {
        return sendTopic
    }

    void setSendTopic(String sendTopic) {
        this.sendTopic = sendTopic
    }

    String getSendContent() {
        return sendContent
    }

    void setSendContent(String sendContent) {
        this.sendContent = sendContent
    }

    Timestamp getCreateTime() {
        return createTime
    }

    void setCreateTime(Timestamp createTime) {
        this.createTime = createTime
    }

    Boolean getDeleted() {
        return deleted
    }

    void setDeleted(Boolean deleted) {
        this.deleted = deleted
    }

    Timestamp getUpdateTime() {
        return updateTime
    }

    void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime
    }
}
