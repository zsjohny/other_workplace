package org.nessary.project.utils.screct;

import javax.crypto.Cipher;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * RSA加密类
 */
public class RsaUtils {


    /**
     * 初始化秘钥组
     *
     * @return
     */
    public static Map<String, String> initKeys() {
        Map<String, String> map = new HashMap<>();
        try {
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
            keyPairGen.initialize(1024);
            KeyPair keyPair = keyPairGen.generateKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();
            PublicKey publicKey = keyPair.getPublic();
            map.put("publicKey", Base64.getEncoder().encodeToString(publicKey.getEncoded()));
            map.put("privateKey", Base64.getEncoder().encodeToString(privateKey.getEncoded()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return map;
    }

    public static void main(String[] args) {
        Map<String, String> stringStringMap = initKeys();
        String publicKey = stringStringMap.get("publicKey");
        String privateKey = stringStringMap.get("privateKey");
        System.out.println("BKoV9zRTQ8MrY2IB9O776TqUxb6FRviylo0dkMOp5Vk+:Mzk4MDM1YWEtODI2OS00ZGE5LWE3NTEtODI1NzlkMDhmNGYxMTQ4NDIwMDgxNjMzNA==k115".length());
        String str = encrypt("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDE0EVd1qXZ/76G6T7/aIxCByyh7HeRXDPvCQJp/Bxx//RvLOhcTCkwyQAOEXpAHd5VeQbgRUi0OumeHs2FdwVAE7LOsyU4Uf13wM8F5mCXTwGc5Tn+vFgt+kALEnOQ+/MoXssTZee8ztxYRWhiyzrTpYaHKjldssKCp9E+9wbZuQIDAQAB", "BKoV9zRTQ8MrY2IB9O776TqUxb6FRviylo0dkMOp5Vk+:Mzk4MDM1YWEtODI2OS00ZGE5LWE3NTEtODI1NzlkMDhmNGYxMTQ4NDIwMDgxNjMzNA==k115");
        System.out.println(privateKey);
//        String result = decrypt(privateKey, str);
//        System.out.println(result);

    }


    /**
     * 加密
     *
     * @param key    加密的公钥
     * @param encrty 加密对象
     * @return
     */
    public static String encrypt(String key, String encrty) {
        String result = "";
        if (key == null || key.length() == 0) {
            return result;
        }
        try {
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(key));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key publicKey = keyFactory.generatePublic(x509KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            result = Base64.getEncoder().encodeToString(cipher.doFinal(encrty.getBytes()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return result;
    }

    /**
     * 解密
     *
     * @param key    加密秘钥
     * @param decrty 待解密的对象
     * @return
     */
    public static String decrypt(String key, String decrty) {
        String result = "";
        if (key == null || key.length() == 0) {
            return result;
        }

        try {
            // 取得私钥
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(key));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            result = new String(cipher.doFinal(Base64.getDecoder().decode(decrty)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return result;
    }

}
