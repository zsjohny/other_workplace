package org.nessary.project.utils.cache;

import com.alibaba.fastjson.JSONObject;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.CacheType;
import org.nessary.project.utils.http.HttpTools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import java.io.*;
import java.util.*;

import static org.nessary.project.utils.Regular.Regular.checkEmpty;


/**
 * 避免统一的调度和配置问题，简化开发流程
 * Created by Ness on 2016/12/7.
 */
public class CacheTemplete implements InitializingBean, BeanFactoryAware, DisposableBean {

    private BeanFactory factory;
    private Logger logger = LoggerFactory.getLogger(CacheTemplete.class);
    private String BEAN_NAME = new StringBuilder("Jedis").append(System.currentTimeMillis()).toString();
    private Properties properties = new Properties();
    private ShardedJedisPool shardedJedisPool;

    protected ThreadLocal<ShardedJedis> jedis = new ThreadLocal<>();

    private static int MAX_TOTAL_LINK_COUNT;

    protected void openCaceTemplete() {

        if (MAX_TOTAL_LINK_COUNT == shardedJedisPool.getNumActive()) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {

            }
            openCaceTemplete();
        } else {
            jedis.set(shardedJedisPool.getResource());

        }

    }


    protected void closeCacheTemplete() {

        if (jedis != null && jedis.get() != null) {
            //判定是否为空闲的时间
            jedis.get().disconnect();
            jedis.get().close();
        }

    }


    /**
     * 发送错误消息
     *
     * @param msg 错误提示
     */
    protected void sendReport(String msg) {
        logger.info("开始发送错误报告{}", msg);
        new Thread(() -> {
            HttpTools.sendReport("805687116@qq.com", msg);
            logger.info("结束发送错误报告{}", msg);
        }).start();

    }

    /**
     * 为了充分利用 字节流的安全和字符串的安全
     * 根据序列化存储对象
     *
     * @param key   存储的key
     * @param value 存储的字节数据对象
     */
    public Boolean setCacheForSerialize(String key, Object value) {
        Boolean flag = false;
        if (checkEmpty(key, null) || value == null) {
            return flag;
        }
        ObjectOutputStream oos = null;
        ByteArrayOutputStream baos = null;


        try {
            openCaceTemplete();
            baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            oos.writeObject(value);

            byte[] saveByte = baos.toByteArray();
            jedis.get().set(key.getBytes(), saveByte);

            flag = true;
            logger.info("redis存储序列化对象success,key{},value{}", key, value);
        } catch (Exception e) {
            logger.warn("redis存储序列化对象出错,key{},value{}", key, value, e);
            sendReport("redis存储序列化对象出错");
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException e) {
                    logger.warn("redis存储oos Io异常", e);
                }
            }

            if (baos != null) {
                try {
                    baos.close();
                } catch (IOException e) {
                    logger.warn("redis存储baos Io异常", e);
                }
            }

            closeCacheTemplete();
        }

        return flag;
    }


    /**
     * 取出 根据序列化存储对象
     *
     * @param key 存储的key
     */
    public Object getCacheForSerialize(String key) {
        Object obj = null;
        if (checkEmpty(key, null)) {
            return obj;
        }
        ByteArrayInputStream bais = null;
        ObjectInputStream bis = null;


        try {
            openCaceTemplete();

            byte[] bytes = jedis.get().get(key.getBytes());
            if (bytes == null) {
                return obj;
            }

            bais = new ByteArrayInputStream(bytes);
            bis = new ObjectInputStream(bais);


            obj = bis.readObject();

            logger.info("redis取出序列化对象success,key{}", key);

        } catch (Exception e) {
            sendReport("redis取出序列化对象出错");
            logger.warn("redis取出序列化对象出错,key{}", key, e);
        } finally {
            if (bais != null) {
                try {
                    bais.close();
                } catch (IOException e) {
                    logger.warn("redis取出oos Io异常", e);
                }
            }

            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    logger.warn("redis取出baos Io异常", e);
                }
            }
            closeCacheTemplete();
        }

        return obj;
    }

    private final String DEFAULT_ID = "1";

    /**
     * 设置默认的自增Id的初始化值
     *
     * @param key   自增Id的参数
     * @param value 默认值
     */
    public void setDefaultIncrementId(String key, String value) {
        if (checkEmpty(value, null) || checkEmpty(key, null)) {
            return;
        }
        try {
            openCaceTemplete();
            jedis.get().set(key, value);
            logger.info("redis设置 {} value {}  success", key, value);
        } catch (Exception e) {
            sendReport("redis设置 {} value {}  error" + e);
            logger.info("redis设置 {} value {}  error", key, value);
        } finally {
            closeCacheTemplete();
        }

    }

    /**
     * 获取自增数
     *
     * @param key 自增的key
     * @return
     */
    public Long getIncrementId(String key) {
        Long result = 0l;

        if (checkEmpty(key, null)) {
            return result;
        }
        try {
            openCaceTemplete();

            if (!jedis.get().exists(key)) {
                jedis.get().set(key, DEFAULT_ID);
            }

            result = jedis.get().incr(key);

            logger.info("redis获取{} 自增 success", key);
        } catch (Exception e) {
            sendReport("redis获取{} 自增 success" + e);
            logger.warn("redis获取{} 自增 success", key, e);
        } finally {
            closeCacheTemplete();
        }

        return result;

    }

    /**
     * 单个存储
     *
     * @param key
     * @param value
     * @return
     */
    public Boolean setCache(String key, String value) {
        Boolean flag = false;

        if (checkEmpty(key, null) || checkEmpty(value, null)) {
            return flag;
        }
        try {
            openCaceTemplete();
            jedis.get().setnx(key, value);
            flag = true;
            logger.info("redis存储success,key{},value{}", key, value);
        } catch (Exception e) {
            sendReport("redis存储单个出错");
            logger.warn("redis存储出错,key{},value{}", key, value, e);
        } finally {
            closeCacheTemplete();
        }

        return flag;

    }


    /**
     * 存储失效的值
     *
     * @param key
     * @param value
     * @param seconds 失效时间(单位为秒)
     * @return
     */
    public Boolean setCacheForExper(String key, String value, int seconds) {
        Boolean flag = false;

        if (checkEmpty(key, null) || checkEmpty(value, null)) {
            return flag;
        }
        if (seconds == 0) {
            seconds = 30;
        }
        try {
            openCaceTemplete();
            jedis.get().setex(key, seconds, value);
            flag = true;
            logger.info("redis存储success,key{},value{}", key, value);
        } catch (Exception e) {
            sendReport("redis存储单个失效时间出错");
            logger.warn("redis存储出错,key{},value{}", key, value, e);
        } finally {
            closeCacheTemplete();
        }

        return flag;

    }


    /**
     * 存储map
     *
     * @param hashKey map的存储的key
     * @param key     map中的key
     * @param value   map中的value
     * @return
     */
    public Boolean setCacheForHash(String hashKey, String key, String value) {
        Boolean flag = false;

        if (checkEmpty(hashKey, null) || checkEmpty(key, null) || checkEmpty(value, null)) {
            return flag;
        }

        try {
            openCaceTemplete();
            jedis.get().hset(hashKey, key, value);
            flag = true;
            logger.info("redis存储map success,hashKey{},key{},value{} ", hashKey, key, value);
        } catch (Exception e) {
            sendReport("redis存储map对象出错");
            logger.warn("redis存储map出错,hashKey{},key{},value{}", hashKey, key, value, e);
        } finally {
            closeCacheTemplete();
        }

        return flag;

    }


    /**
     * 存储所有map
     *
     * @param hashKey map的存储的key
     * @param keMap   需要批量存储的键值对
     * @return
     */
    public Boolean setCacheForHashAll(String hashKey, Map<String, String> keMap) {
        Boolean flag = false;

        if (checkEmpty(hashKey, null) || checkEmpty(keMap, null)) {
            return flag;
        }

        try {
            openCaceTemplete();

            Set<Map.Entry<String, String>> entries = keMap.entrySet();

            for (Map.Entry<String, String> entry : entries) {
                try {
                    jedis.get().hset(hashKey, entry.getKey(), entry.getValue());
                } catch (Exception ex) {
                    logger.warn("单个redis存储出错,hashKey{},keMap{}", entry.getKey(), entry.getValue(), ex);
                }
            }
            flag = true;
            logger.info("redis存储所有map success,hashKey{},keMap{}", hashKey, keMap);
        } catch (Exception e) {
            sendReport("redis存储所有map对象出错");
            logger.warn("redis存储所有map出错,hashKey{},keMap{}", hashKey, keMap, e);
        } finally {
            closeCacheTemplete();
        }

        return flag;

    }


    /**
     * 获取map
     *
     * @param hashKey map的存储的key
     * @param key     map中的key
     * @return
     */
    public String getCacheForHash(String hashKey, String key) {
        String value = "";

        if (checkEmpty(hashKey, null) || checkEmpty(key, null)) {
            return value;
        }

        try {
            openCaceTemplete();
            value = jedis.get().hget(hashKey, key);
            if (value == null) {
                value = "";
            }
            logger.info("redis获取map success,hashKey{},key{}", hashKey, key);
        } catch (Exception e) {
            sendReport("redis获取map对象出错");
            logger.warn("redis获取map出错,hashKey{},key{}", hashKey, key, e);
        } finally {
            closeCacheTemplete();
        }

        return value;

    }


    /**
     * 获取所有map
     *
     * @param hashKey map的存储的key
     * @return
     */
    public Map<String, String> getCacheForHashAll(String hashKey) {

        Map<String, String> value = new HashMap<>();

        if (checkEmpty(hashKey, null)) {
            return value;
        }

        try {

            openCaceTemplete();
            value = jedis.get().hgetAll(hashKey);
            if (value == null) {
                value = new HashMap<>();
            }
            logger.info("redis获取所有map success ,hashKey{}", hashKey);
        } catch (Exception e) {
            sendReport("redis获取所有map对象出错");
            logger.warn("redis获取所有map出错,hashKey{}", hashKey, e);
        } finally {
            closeCacheTemplete();
        }

        return value;


    }


    /**
     * 获取值
     *
     * @param key
     * @return
     */
    public String getCache(String key) {
        String value = "";

        if (checkEmpty(key, null)) {
            return value;
        }


        try {
            openCaceTemplete();
            value = jedis.get().get(key);
            if (value == null) {
                value = "";
            }
            logger.info("redis获取单个对象success,key{}", key);
        } catch (Exception e) {
            sendReport("redis获取单个对象出错");
            logger.warn("redis获取单个对象出错,key{}", key, e);
        } finally {
            closeCacheTemplete();
        }

        return value;

    }


    /**
     * 检测某个值是否存在
     *
     * @param key
     * @return
     */
    public Boolean exist(String key) {
        Boolean flag = false;

        if (checkEmpty(key, null)) {
            return flag;
        }
        try {
            openCaceTemplete();
            flag = jedis.get().exists(key);
            if (flag) {
                logger.info("redis检测值存在success,key{}", key);
            } else {
                logger.info("redis未检测值存在,key{}", key);
            }

        } catch (Exception e) {
            sendReport("redis检测值存在出错");
            logger.warn("redis检测值存在出错,key{}", key, e);
        } finally {
            closeCacheTemplete();
        }
        return flag;

    }


    /**
     * 删除hash的值
     *
     * @param hashKey map的存储的key
     * @param key     map中的key ,为 null时候全部删除
     * @return
     */
    public Boolean deleteCacheHash(String hashKey, String key) {
        Boolean flag = false;

        if (checkEmpty(hashKey, null)) {
            return flag;
        }
        try {
            openCaceTemplete();
            flag = jedis.get().exists(hashKey);
            if (!flag) {
                logger.warn("redis删除不存在,hashKey={},key{}", hashKey, key);
                return flag;
            }
            if (key == null) {
                Map<String, String> allMap = jedis.get().hgetAll(hashKey);
                if (Regular.checkEmpty(allMap, null)) {
                    logger.warn("redis删除Map不存在,hashKey={},key{}", hashKey, key);
                    return flag;
                }
                while (allMap.keySet().iterator().hasNext()) {
                    jedis.get().hdel(hashKey, allMap.keySet().iterator().next());
                }

            } else {
                jedis.get().hdel(hashKey, key);
            }

            logger.info("redis删除success,hashKey={},key{}", hashKey, key);
            flag = true;
        } catch (Exception e) {
            sendReport("redis删除Map出错");
            logger.warn("redis删除出错,hashKey={},key{}", hashKey, key, e);
        } finally {
            closeCacheTemplete();
        }
        return flag;

    }


    /**
     * 删除普通缓存的值
     *
     * @param key 缓存的key
     * @return
     */
    public Boolean deleteCache(String key) {
        Boolean flag = false;

        if (checkEmpty(key, null)) {
            return flag;
        }
        try {
            openCaceTemplete();
            flag = jedis.get().exists(key);
            if (!flag) {
                logger.warn("redis删除不存在,key{}", key);
                return flag;
            }

            jedis.get().del(key);

            logger.info("redis删除success,key{}", key);
            flag = true;

        } catch (Exception e) {
            sendReport("redis删除普通对象出错");
            logger.warn("redis删除出错,key{}", key, e);
        } finally {
            closeCacheTemplete();
        }
        return flag;

    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.factory = beanFactory;
    }


    protected void initResourse() {
        try {
            properties.load(CacheTemplete.class.getClassLoader().getResourceAsStream("public.utils/defaultLink.properties"));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        initResourse();

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(ShardedJedisPool.class);
        JedisPoolConfig config = new JedisPoolConfig();
        MAX_TOTAL_LINK_COUNT = Integer.parseInt(properties.getProperty("redis.pool.maxTotal"));
        config.setMaxTotal(MAX_TOTAL_LINK_COUNT);
        config.setMaxIdle(Integer.parseInt(properties.getProperty("redis.pool.maxIdle")));
        config.setMinIdle(Integer.parseInt(properties.getProperty("redis.pool.minIdle")));
        config.setMaxWaitMillis(Integer.parseInt(properties.getProperty("redis.pool.maxWaitMillis")));
        config.setLifo(Boolean.valueOf(properties.getProperty("redis.lifo")));
        /**
         * 测试时候开发这两个属性，正式环境为了性能关闭 break释放资源的问题  每次ping时候 都会进行释放 资源l浪费
         * ---------------------------------------------------------------------------------------------
         */
        config.setTestOnBorrow(Boolean.parseBoolean(properties.getProperty("redis.testOnAccess")));
        config.setTestOnReturn(Boolean.parseBoolean(properties.getProperty("redis.testOnReturn")));
        /**
         * ---------------------------------------------------------------------------------------------
         * */

        builder.setLazyInit(true);
        builder.addConstructorArgValue(config);

        JedisShardInfo info = new JedisShardInfo(properties.getProperty("redis.link.host"), Integer.parseInt(properties.getProperty("redis.link.port")));
        info.setPassword(properties.getProperty("redis.link.pass"));

        List<JedisShardInfo> infos = new ArrayList<>();
        infos.add(info);
        builder.addConstructorArgValue(infos);
        DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) factory;
        beanFactory.registerBeanDefinition(BEAN_NAME, builder.getRawBeanDefinition());
        shardedJedisPool = (ShardedJedisPool) factory.getBean(BEAN_NAME);


    }


    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:public.utils/app_*.xml");
        CacheTemplete sender = (CacheTemplete) context.getBean("cacheTemplete");

        if (1 == 1) {
            sender.setCache("test", "test");
            Long incermentId = sender.getIncrementId("jkjjd");
            System.out.println(incermentId);
//            Address address = new Address();
//            address.setUuid("asfdfsdfasdfskdfhsakjhgfdhgbds");
//            sender.setCacheForSerialize("sss", address);
//            Object ss = sender.getCacheForSerialize("sss");
//            address = (Address) ss;
//            System.out.println(address.getUuid());

            return;
        }

        if (1 == 1) {
            Map<String, String> cacheForHashAll = sender.getCacheForHashAll(CacheType.PURCASE_GROUP.getValue());
            System.out.println(cacheForHashAll);
            return;
        }

        JSONObject json = new JSONObject();
        json.put("111", 222);
        json.put("222", 333);
        sender.setCacheForSerialize("11", json);

        Object cacheForSerialize = sender.getCacheForSerialize("11");
        json = (JSONObject) cacheForSerialize;
        System.out.println(json.get("222"));
        System.out.println(sender.exist("11"));
     /*   sender.setCacheForHash("11", "11", "22");
        sender.setCache("11", "22");*/
       /* CacheTemplete cacheTemplete = new CacheTemplete();
        cacheTemplete.initResourse();*/

    }


    @Override
    public void destroy() throws Exception {
        closeCacheTemplete();
        if (!shardedJedisPool.isClosed()) {
            shardedJedisPool.close();
            logger.info("redis缓存关闭");
        }
    }
}
