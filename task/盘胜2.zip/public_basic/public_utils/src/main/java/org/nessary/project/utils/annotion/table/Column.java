package org.nessary.project.utils.annotion.table;

import org.nessary.project.utils.operate.DbHandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 表格的长度值
 * Created by Ness on 2017/2/16.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {

    long value() default 0;

    String commit() default "";

    DbHandler.DateGeneStrategy dateGeneStrategy() default DbHandler.DateGeneStrategy.DEFAULT;

}
