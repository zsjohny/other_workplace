package org.nessary.project.utils.jms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Ness on 2016/12/6.
 */
public class Test1 implements JmsListenter {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:public.utils/app_*.xml");
        Test1 sender = (Test1) context.getBean("jmsListenter");

    }

    @Override
    public void onMsg(String msg) {
        System.out.println(msg);

    }
}
