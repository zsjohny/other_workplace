package org.nessary.project.utils.screct;

import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.cache.CacheTemplete;
import org.nessary.project.utils.enums.CacheType;
import org.nessary.project.utils.enums.ParamType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 用户调用数据
 * Created by Ness on 2016/12/13.
 */
public class UserUtils {

    private CacheTemplete cacheTemplete;
    private Logger logger = LoggerFactory.getLogger(UserUtils.class);
    private String LINK_SPACE = ":";

    private long INVALID_SECONDS = 86400000;


    private static final Lock setAuthLock = new ReentrantLock();
    private static final Lock checkAuthLock = new ReentrantLock();


    /**
     * 设置安全的过期时间
     *
     * @param uuid 账户的UUid
     * @param pass 账户的密码
     * @param uid  唯一标识
     */
    public String setAuthExper(String uuid, String pass, String uid) {

        String passEncrty = "";
        if (cacheTemplete == null || Regular.checkEmpty(uuid, ParamType.UUID) || Regular.checkEmpty(pass, ParamType.PASS) || Regular.checkEmpty(uid, ParamType.UID)) {
            logger.info("用户设置安全时间,参数不符合规范:uuid={},pass={},uid={}", uuid, pass, uid);
            return passEncrty;
        }


        try {
            setAuthLock.lock();

            logger.info("用户{}开始设置安全时间,参数为:pass={},uid={}", uuid, pass, uid);

            StringBuilder builder = new StringBuilder(uuid);
            builder.append(LINK_SPACE);
            builder.append(pass);
            builder.append(LINK_SPACE);
            builder.append(System.currentTimeMillis());
            builder.append(LINK_SPACE);
            builder.append(uid);


            String encrypt = DesUtil.encrypt(builder.toString(), uuid);

            Map<String, String> initKeys = RsaUtils.initKeys();
            builder.delete(0, builder.length());
            builder.append(encrypt);
            builder.append(LINK_SPACE);
            builder.append(initKeys.get("publicKey"));

            String _serverInfos = builder.toString();

            cacheTemplete.setCacheForHash(CacheType.USER_GROUP.getValue(), uuid, Base64.getEncoder().encodeToString(builder.toString().getBytes()));

            builder.delete(0, builder.length());
            builder.append(pass);
            builder.append(LINK_SPACE);
            builder.append(uuid);

            passEncrty = builder.toString();

            String rsaResult = RsaUtils.encrypt(initKeys.get("publicKey"), passEncrty);


            builder.delete(0, builder.length());
            builder.append(rsaResult);
            builder.append(LINK_SPACE);
            builder.append(initKeys.get("privateKey"));
            passEncrty = DesUtil.encrypt(builder.toString(), uid);
            builder.delete(0, builder.length());

            builder.append(passEncrty);
            builder.append(LINK_SPACE);
            builder.append(_serverInfos);

            passEncrty = Base64.getEncoder().encodeToString(builder.toString().getBytes());

            logger.info("用户{}结束设置安全时间,参数为:pass={},uid={}", uuid, pass, uid);

        } catch (Exception e) {
            logger.warn("用户{}设置安全时间失败,参数:pass={},uid={}", e, uuid, pass, uid);
        } finally {
            setAuthLock.unlock();
        }

        return passEncrty;

    }


    /**
     * 清空所有失效认证
     */
    public void clearInvalidAuth() {


        try {
            if (cacheTemplete == null) {
                logger.warn("cacheTemplete为null");
                return;
            }
            logger.info("开始清理失效缓存");
            Map<String, String> cacheForHashAll = cacheTemplete.getCacheForHashAll(CacheType.USER_GROUP.getValue());
            String[] _saveInfo;
            long interval;
            if (cacheForHashAll.isEmpty()) {
                logger.info("未检测到缓存");
                return;
            }

            for (Map.Entry<String, String> entry : cacheForHashAll.entrySet()) {
                _saveInfo = DesUtil.decrypt(new String(Base64.getDecoder().decode(entry.getValue())).split(LINK_SPACE)[0], entry.getKey()).split(LINK_SPACE);

                interval = Long.parseLong(_saveInfo[2]) - System.currentTimeMillis();
                if (interval > INVALID_SECONDS) {
                    cacheTemplete.deleteCacheHash(CacheType.USER_GROUP.getValue(), _saveInfo[0]);
                    logger.info("成功清理失效缓存{}", entry.getKey());
                }
            }

            logger.info("结束清理失效缓存");

        } catch (Exception e) {
            logger.warn("清理失效缓存失败", e);
        }


        return;

    }


    /**
     * 检查账号是否有效
     *
     * @param token 前端所传的认证
     * @param uid   唯一标识
     */
    public Boolean checkValid(String token, String uid) {


        Boolean validFlag = false;
        if (cacheTemplete == null || Regular.checkEmpty(token, ParamType.TOKEN) || Regular.checkEmpty(uid, ParamType.UID)) {
            logger.warn("校验用户是否有效,所传参数不符合规范,token={},uid={}", token, uid);
            return validFlag;
        }


        try {
            checkAuthLock.lock();

            logger.info("开始校验用户{}是否有效,token={}", uid, token);

            //获取uuid
            byte[] decode = Base64.getDecoder().decode(token);


            //client的uui+desResult+rsaPublickKey
            String[] _orginal = new String(decode).split(LINK_SPACE);

            String[] _transferInfo = DesUtil.decrypt(_orginal[0], uid).split(LINK_SPACE);

            if (Regular.checkEmpty(_transferInfo, null)) {
                logger.warn("校验用户{}传入token失败,token={}", uid, token);
                return validFlag;
            }


            //获取数字信息
            String[] _rsaResult = RsaUtils.decrypt(_transferInfo[1], _transferInfo[0]).split(LINK_SPACE);

            if (Regular.checkEmpty(_rsaResult, null) || Regular.checkEmpty(_rsaResult[1], ParamType.UUID)) {
                logger.warn("校验用户{}输入解密失败,token={},uuid={}", uid, token, _transferInfo[1]);
                return validFlag;
            }


            //检测账号是否存在
            String _saveInfoStr = cacheTemplete.getCacheForHash(CacheType.USER_GROUP.getValue(), _rsaResult[1]);


            if (Regular.checkEmpty(_saveInfoStr, null)) {
                logger.warn("校验用户{}为空,token={}", uid, token);
                return validFlag;
            }

            //解密文件
            String[] _orginalInfo = new String(Base64.getDecoder().decode(_saveInfoStr)).split(LINK_SPACE);

            //uuid+pass+time+uid
            String[] _saveInfo = DesUtil.decrypt(_orginalInfo[0], _rsaResult[1]).split(LINK_SPACE);


            //先比对公钥是否正确
            if (!_orginalInfo[1].equals(_orginal[2])) {
                logger.warn("校验用户{}传入的公钥不正确,token={},uuid={}", uid, token, _saveInfo[0]);
                return validFlag;
            }

            //用户传递的token
            String[] _userInfo = DesUtil.decrypt(_orginal[1], _rsaResult[1]).split(LINK_SPACE);


            if (Regular.checkEmpty(_userInfo, null) || Regular.checkEmpty(_userInfo[0], ParamType.UUID)) {
                logger.warn("校验用户{}传入的token异常,token={},uuid={}", uid, token, _userInfo[0]);
                return validFlag;
            }


            //判断是否失效
            long interval = Long.parseLong(_saveInfo[2]) - System.currentTimeMillis();
            if (interval > INVALID_SECONDS) {
                logger.warn("校验用户{},存储时间超时{},token={},uuid={}", uid, interval, token, _saveInfo[0]);
                cacheTemplete.deleteCacheHash(CacheType.USER_GROUP.getValue(), _transferInfo[0]);
                return validFlag;
            }

            //判断密码是否正确
            if (!_userInfo[1].equals(_saveInfo[1])) {
                logger.warn("校验用户{},密码不正确,输入密码{},token={},uuid={}", uid, _transferInfo[1], token, _saveInfo[0]);
                return validFlag;
            }

            //判断密码是否为同一个标识符
            if (!uid.equals(_saveInfo[3])) {
                logger.warn("校验用户{},标识符不正确,输入字符{},token={},uuid={}", uid, uid, token, _saveInfo[0]);
                return validFlag;
            }

            //判断是否为同一uuid
            if (!_userInfo[0].equals(_saveInfo[0])) {
                logger.warn("校验用户{},传入的uuid不一致,输入密码{},token={},uuid={}", uid, _transferInfo[1], token, _saveInfo[0]);
                return validFlag;
            }

            //判断是否为同一时间
            if (!_userInfo[2].equals(_saveInfo[2])) {
                logger.warn("校验用户{},传入的时间不一致,输入密码{},token={},uuid={}", uid, _transferInfo[1], token, _saveInfo[0]);
                return validFlag;
            }

            //判断是否为同-标识
            if (!_userInfo[3].equals(_saveInfo[3])) {
                logger.warn("校验用户{},传入的标识,输入密码{},token={},uuid={}", uid, _transferInfo[1], token, _saveInfo[0]);
                return validFlag;
            }


            validFlag = true;
            //赋值UUID
            setUuid(token, _userInfo[0]);

            logger.info("结束校验用户{}是否有效,token={}", uid, token);

        } catch (Exception e) {
            logger.warn("校验用户{}是否有效出错,token={}", uid, token, e);
        } finally {
            checkAuthLock.unlock();

        }


        return validFlag;

    }

    /**
     * 用户的uuid
     */
    private ThreadLocal<ConcurrentHashMap<String, String>> uuid = new ThreadLocal<ConcurrentHashMap<String, String>>() {
        @Override
        protected ConcurrentHashMap<String, String> initialValue() {
            return new ConcurrentHashMap<>();
        }
    };

    public String getUuid(String token) {

        String uid = uuid.get().get(token);
        uuid.get().remove(token);
        return uid;
    }

    public void setUuid(String token, String uuid) {
        this.uuid.get().put(token, uuid);
    }

    /**
     * 生成UUid
     *
     * @return
     */
    public static String generateUUid() {

        StringBuilder builder = new StringBuilder(UUID.randomUUID().toString());
        builder.append(System.currentTimeMillis());
        return Base64.getEncoder().encodeToString(builder.toString().getBytes());
    }

    private static String DEFAULT_KEY = "20161210";

    /**
     * 生成密码
     *
     * @return
     */
    public static String generatePass() {
        StringBuilder builder = new StringBuilder(UUID.randomUUID().toString());
        builder.append(System.currentTimeMillis());
        return DesUtil.encrypt(Base64.getEncoder().encodeToString(builder.toString().getBytes()), DEFAULT_KEY);

    }


    private static AtomicLong atomicLong = new AtomicLong();

    /**
     * 生成自增Id
     *
     * @return
     */
    public static String generateIncrementId() {

        while (atomicLong.compareAndSet(0, 1)) {

            String idBefore = UUID.randomUUID().toString().replaceAll("-", "");
            String idAfter = Instant.now().toString().replaceAll("[-:]", "").replaceAll("[.Z]", "");
            StringBuilder builder = new StringBuilder(idBefore.substring(0, idBefore.length() / 2));
            builder.append(idBefore.substring(idBefore.length() / 2, idBefore.length()));
            builder.append(idAfter.substring(idAfter.length() / 2, idAfter.length()));
            atomicLong.set(0);
            return builder.reverse().toString();
        }

        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
        }
        return generateIncrementId();

    }

    private static String name = "default";

    /**
     * 生成无序姓名
     *
     * @return
     */
    public static String generateName() {
        synchronized (name) {

            StringBuilder builder = new StringBuilder(Instant.now().toString().replaceAll("[-:]", "").replaceAll("[.TZ]", ""));
            try {
                TimeUnit.MICROSECONDS.sleep(5);
            } catch (InterruptedException e) {
            }
            return builder.reverse().toString();
        }
    }


    private static ThreadLocal<LongAdder> adder = new ThreadLocal<LongAdder>() {
        @Override
        protected LongAdder initialValue() {
            return new LongAdder();
        }
    };
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddssSSS");
    private static int MAX_ORDER_LENGTH = 40;
    private static Random random = new Random();

    /**
     * 生成订单号
     *
     * @return
     */
    public static String generateOrderNo() {
        StringBuilder bulid = new StringBuilder();
        adder.get().increment();
        while (adder.get().intValue() == 1) {

            LocalDateTime time = LocalDateTime.now();
            String format = time.format(formatter);
            String id = UUID.randomUUID().toString().replaceAll("-", "").replaceAll("[a-zA-Z]+", "");
            bulid.append(format);
            bulid.append(id);
            if (bulid.length() < MAX_ORDER_LENGTH) {
                int len = MAX_ORDER_LENGTH - bulid.length();
                for (int i = 0; i < len; i++) {

                    bulid.append(random.nextInt(10));
                }
            }
            adder.get().reset();
        }

        return bulid.toString();

    }


    public static void main(String[] args) {


        if (1 == 1) {


            if (2 == 2) {
                ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
                UserUtils userUtils = (UserUtils) context.getBean("userUtils");

                for (int j = 0; j < 5; j++) {
                    new Thread(() -> {
                        for (int i = 0; i < 1000; i++) {


//                            String s = HttpTools.doGet("http://127.0.0.1:8080/user/login/load/tourist.do", "name=13835177730&uid=00000000-3ecc-0dc8-d107-ac420033c587&code=666666");
//
//                            JSONObject jsonObject = JSONObject.parseObject(s);
//                            String token = (String) jsonObject.getJSONObject("data").get("token");

                            String token = userUtils.setAuthExper("25143313541354135413541541354", "12345678912346", "00000000-3ecc-0dc8-d107-ac420033c587");

                            Boolean aBoolean = userUtils.checkValid(token, "00000000-3ecc-0dc8-d107-ac420033c587");
                            if (!aBoolean) {
                                System.out.println(Thread.currentThread().getName() + ":error");
                            }

                        }


                    }).start();
                }

                return;
            }

            for (int k = 0; k <= 4; k++) {
                new Thread(() -> {
                    List<String> list = new ArrayList<>();
                    Set<String> set = new HashSet<>();
                    for (int i = 0; i < 100000; i++) {
                        String str = generateIncrementId();
                        list.add(str);
                        set.add(str);
                        if (list.size() > 0 && list.size() != set.size()) {
                            System.out.println("have Not equal");
                            System.out.println("list " + list);
                            System.out.println("set " + set.toArray());

                        }

                    }
                }).start();
            }


          /*  UserUtils userUtils = new UserUtils();
            userUtils.cacheTemplete = new CacheTemplete();
            userUtils.checkValid("dE9ldGJTQzljNzRCb2lCSHY5YlpnajcrU0ZDQ2RxVmpwUkZhaE8vMTV2a2RKL0poODF0cFcyN0ZXS2h2N25OTjVjMjBZQWhpR2VSTG9QVDdvckU2bVB3d1NaSUVrUzVsMkVrTVA3WmxXNTAzcnI1alZwdncxNHBvVGFGL0VpS0xtS0IyVGxFendXSCtUMUdnWFh4NXMrK3ZHMWI4MVRjVVJnc3RHc0kxRk5wNjFrTWdYemIzb09QMHBGdisvUVN3L0s4US9TYnpsMThIMEV6b3p2OWhNcHZ2eXlEc0hlWitXSk9JdjFhcGljRHdoVER5aEFZWU0zc09lVXJucWNtYzR4SFAzU285YStyejlvTmVwWFRuQWtWZTlYY3BmVEt6bGl4SVoyVGlzMnZsMHdQbDR3OG15T0dkbjh0U0VyZEprMWt2RHVxeVhUUGRyTnh0M3Q2YlBqRlhiazJUZmluZHdxWVkwRHhJSFdVaFBxa1JNQUxSR09IeXo0UVUyWUwxRjNTZEg0VkxlVE1tclhIdFlmMXlBRjJueEtFb1hpc0tpdXRic1gzcmRjMk8xOUloeThUOVBTdlZaT3ZobXRudlp2UFpUWGxBVHFEZGJHWml5SEVVbUt3STlGRUxBK3Z5RGtBd1pHNnRFN0FNQ1B3Z21MN1U0em4zZWxOY1lPK2RqU2owNTIyenE5VE5PVGk1TSs2VVY5dmcxK3lucTVTVXpXcXJQQUNBTGwvQU5mL3MvQU9XYmdBbDFWcXo4ZkovSDQySDlEY05zTy9hSjNOcWJQOFR2SGhSVUhjb09KTFdGRDZVRWM1S0QwVUtPRXlvTXhUbi9JcmhWcjNvZ3RORUFWeFFpU0FqK1lraENNMnd1TFFSOG50RDYyK2ZmYjZhcG84cmFjZ2lTNFU2RFAwZzJnM3pDdWxaL0JHbXZVWjROVHhtaWVTSWxoQUJMSHJKSCtuQjJpdlJYR2c5ZUxBcVdDcDNTSUFwY0YyM2t0L3g1ekVYTTlFb0ZVMTMwKzBrNCtCcEFXUmh2S1RyS3RsVUl3bWF6ZmUwNnlYanJEOXdxejdBQ2pyNWgyS1NBeERNM1grWlVHVnlPalZSdXpoeDdUam5aRVkrdVFPUFc2N05vSnhDa0E2TEpkTVNyeUs4azAvVDVZV1NzOWVTbDJXd2dSU1hSbFVVd1RjVWVqU010ZERuWS9ZWXY2dXFiL1g2Z3FlUDBPdHAxbnFGNXpjZXJNNTFKZkE0QTFsdGtlRWFPTDFuc0NsYzczTTU1TVF2QmJENHJsUHhuV1hqeUlVZGZJNDA1MlIwK2dXdmhIRDZsSjUrMFZ4Y085S1A2aXkrMEs5dDRGMmpTcmk5SW9Zbk5JZVJManlXSmJuK1c4dTJpVzZidzcxL1h0MkVXUTRJSkdVTmZXVHhmNjlheUtxRklQYlI3bi9QSGtpaTlObGE2QkM2eWhZTE5uWWQyQU14R3E5Slp0MGxGalk5dUxXTUlJZzd6NVp1Y2U2MkVYQkNoZUNtN2JWV25DbnBRL0NmMUtZZ2MxeWxGWTBZZjVYbm8rcnFrRkJ5emxrVWFIUUFiV2hEZGZWYmVvdldFUk9vd3ZJQkM5eGJQWkE0MEJXSXhjWlZKVlNJdGhNdk50dTlDVmVlOCthcFExVFZ4UjkrZU5ERThXNmhVM3ZhNjlpVEZDRkFvemFydjAwN0ZTRk4rTlVaUXdFenhsakhPbWpORDBXbkxTcHoyVS9nc1dUWjhQSWk3em1Wb1RBWHhHT25iSUhubXJMVmtJQW1iN3hVVDBvZTM3bXVrRUo3Yi9jSGF1SElFZz09OkNWdjY3VGo0MzdEdHptQ3JsWE1PaDYrc21YdGVUTzI5UHVvUG16QnpSdU5SckJ1UElzY1BlYnhlTVFiUjNFd09NVUdaT2hGV2xyZURMTC9Gckp3eTFJaWdPQ21QTHU3amdSMEtiTjNrdHdVN25lYzEyM1FJUDRUc1V5ZEs4cy9idEgwbEEwZVBSQ1B2RC9yenhrd1NBelRLczNIWEJ0ZTBpcTR6OGVyOXRuN3hZNDVoTUhYTmtVYlpPNDlxR3h5WlBJQWR0N0ROMHRNPTpNSUdmTUEwR0NTcUdTSWIzRFFFQkFRVUFBNEdOQURDQmlRS0JnUUNNZnRZbS9zOVBBdUQwVnJoeHE3K0h0b2NwZDU5TnJEeElpMUppZWZTeGJjTkE3VVlhVEpxRlhPcFZYU0EzZVRvR1ZaRXpLckp5WXA2UEJ1SUEyL2lvNkQxcFpxYmE2dE9qT09KN1VOdTlDcEgwVmxTTFZuSDdLNmpQd3NqV1d4R1BWK29oMWo5MzhKZENFVkhVOUdZUHdNQnVSL0VkQXZic0NXZE1oVzhibHdJREFRQUI", "FD255312-0010-44EE-A621-933DD791C3D9");
           */
            return;
        }

        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:app_*.xml");
        UserUtils userUtils = (UserUtils) context.getBean("userUtils");
//        userUtils.clearInvalidAuth();
        String uuid = UserUtils.generateUUid();
        String pass = DesUtil.encrypt("12345", "13856368932");
        System.err.println("原始uuid:" + uuid);
        System.err.println("原始密码:" + "12345");
        System.err.println("原始加密后密码:" + pass);
        System.err.println("原始uid:" + "11111111111111111");
        String s = userUtils.setAuthExper(uuid, pass, "11111111111111111");
        System.out.println("--------------------------------------");
        System.out.println("加密后密码：" + s);
        System.out.println("--------------------------------------");
        System.out.println("--------------------------------------");
//        String str = userUtils.setAuthExper("1111111111111111", "22222222222222222", "222222222222222222");
        System.out.println(s);
        System.err.println(userUtils.checkValid(s, "11111111111111111"));

//        rJeMJHhjOI+sl4wkeGM4j/XS1OGtr2L8
    }

    public CacheTemplete getCacheTemplete() {
        return cacheTemplete;
    }

    public void setCacheTemplete(CacheTemplete cacheTemplete) {
        this.cacheTemplete = cacheTemplete;
    }

}
