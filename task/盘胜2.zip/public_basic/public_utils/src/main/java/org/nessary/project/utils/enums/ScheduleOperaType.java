package org.nessary.project.utils.enums;

/**
 * jms通知定时任务的操作类型
 * Created by Ness on 2016/12/8.
 */
public enum ScheduleOperaType {
    ADD_TASK, UPDATE_TASK, DELETE_TASK, STARTNOW_TASK;

}
