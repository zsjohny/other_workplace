package org.nessary.project.utils.jms;

/**
 * jsm监听器
 * Created by Ness on 2016/12/6.
 */
public interface JmsListenter {


    void onMsg(String msg);
}