package org.nessary.project.utils.jms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Ness on 2016/12/6.
 */
public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:public.utils/app_*.xml");
        JmsSender sender = (JmsSender) context.getBean("jmsSender");
        sender.sendMsg("sss");


    }
}
