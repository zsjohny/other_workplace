package org.nessary.project.utils.enums;

/**
 * 缓存的hash的key
 * Created by Ness on 2016/12/8.
 */
public enum CacheType {
    NOTUFY_GROUP("notify:group"), USER_GROUP("user:group"), ORDER_GROUP("order:group"), PURCASE_GROUP("purcase:group"),IS_SET_PURCASE("is:set:purcase"),CACHE_DEVIDE(":");
    private String key;



    CacheType(String key) {
        this.key = key;
    }

    public String getValue() {
        return key;
    }
}
