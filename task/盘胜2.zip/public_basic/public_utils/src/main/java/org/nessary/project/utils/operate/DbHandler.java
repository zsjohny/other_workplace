package org.nessary.project.utils.operate;

import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.annotion.table.Transient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import javax.sql.DataSource;
import java.io.*;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

/**
 * 数据的自动生成的迭代
 * Created by Ness on 2017/2/16.
 */
public class DbHandler implements InitializingBean {
    private Logger log = LoggerFactory.getLogger(DbHandler.class);

    private final int outOR_HIGH_GRADE = 4;
    private final int outOR_JUNIOR_GRADE = 1;

    private Boolean showSql = true;

    private Boolean alwaysInit = true;

    public String fileName = "build.xml";

    private static Boolean LOADING = true;

    private static Boolean delAndNewTables = false;
    private final static String EXISTS = " exists ";
    private final static String NOT_EXISTS = " not exists ";


    private DataSource dataSource;

    private final String DATASOURCE_outOR_MSG = "dataSource was not empty";
    private final String CONNECT_outOR_MSG = "connect was not empty";
    private final String PACKAGEBASE_outOR_MSG = "packageBase was not empty";
    private final String ID_outOR_MSG = "@Id annotation was not empty";
    private final String DB_NAME = "db.sql";
    private final String DEFAULT_FILE_PREFIX = "file:";
    private final int NOT_DEFAULT_LENGTH = -1;
    private final int NOT__ASIGN_LENGTH = -2;


    /**
     * 包的路径
     */
    private String packageBase;

    @Override
    public void afterPropertiesSet() throws Exception {
        if (LOADING) {
            synchronized (this) {
                if (!alwaysInit) {
                    log.info("本次不初始化实体类和表格映射");
                    return;
                }

                createSql();
                excuteSql();
                LOADING = false;
            }
        }


    }

    /**
     * 生成新的sql语句
     *
     * @param file sql存储文件
     * @param list 扫描类的list
     * @throws Exception
     */
    private void autoNewSql(File file, List<Class<?>> list) throws Exception {
        if (list == null || list.isEmpty() || file == null) {
            return;
        }

        StringBuffer sql = new StringBuffer();

        list.forEach((Class<?> x) -> {
            Table table = x.getAnnotation(Table.class);
            if (table != null) {

                if (sql.length() > 0) {
                    sql.append("\n");
                }
                sql.append("create table if ");
                if (delAndNewTables) {

                    sql.append(EXISTS);

                } else {

                    sql.append(NOT_EXISTS);

                }

                sql.append("`");
                sql.append(table.value());
                sql.append("` ( ");

                Field[] fields = x.getDeclaredFields();
                String id = "";
                Connection connect;
                PreparedStatement statement;
                try {
                    connect = getConnect(dataSource);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                StringBuilder sqlBuild;
                StringBuilder commSql;
                StringBuilder updateSql = new StringBuilder();
                for (Field filed : fields) {


                    if (filed.getAnnotation(Transient.class) != null) {
                        continue;
                    }
                    commSql = new StringBuilder();
                    String type = filed.getType().getName();
                    if (filed.getAnnotation(Id.class) != null) {
                        sql.append(TableAttribute.getIdCommit(filed.getName(), type));
                        id = filed.getName();
                        continue;
                    }

                    sql.append("`");
                    sql.append(filed.getName());
                    sql.append("` ");
                    commSql.append(TableAttribute.getColumn(type));
                    commSql.append("(");

                    Column column = filed.getAnnotation(Column.class);
                    if (column != null) {
                        if (TableAttribute.getLength(type) == NOT_DEFAULT_LENGTH) {
                            commSql.delete(commSql.length() - 1, commSql.length());

                            commSql.append(TableAttribute.getDefaultNull());


                        } else if (TableAttribute.getLength(type) == NOT__ASIGN_LENGTH) {
                            commSql.delete(commSql.length() - 1, commSql.length());

                            DateGeneStrategy dateGeneStrategy = column.dateGeneStrategy();
                            if (dateGeneStrategy != DateGeneStrategy.DEFAULT) {
                                //判断是否有默认时间
                                commSql.append(dateGeneStrategy.getDefaultValue());
                            } else {
                                throw new RuntimeException(System.err.append(String.format("className %s 的属性 %s 为TimeStamp 必须有默认值", x.getName(), filed.getName())).toString());
                            }

                        } else {
                            commSql.append(column.value() == 0 ? TableAttribute.getLength(type) : column.value());
                            commSql.append(") ");
                            commSql.append(TableAttribute.getDefaultNull());

                        }

                        commSql.append(TableAttribute.getCommit(column.commit()));


                    } else {
                        if (TableAttribute.getLength(type) == NOT_DEFAULT_LENGTH) {
                            commSql.delete(commSql.length() - 1, commSql.length());

                            commSql.append(TableAttribute.getDefaultNull());


                        } else if (TableAttribute.getLength(type) == NOT__ASIGN_LENGTH) {
                            commSql.delete(commSql.length() - 1, commSql.length());

                            DateGeneStrategy dateGeneStrategy = column.dateGeneStrategy();
                            if (dateGeneStrategy != DateGeneStrategy.DEFAULT) {
                                //判断是否有默认时间
                                commSql.append(dateGeneStrategy.getDefaultValue());
                            } else {
                                throw new RuntimeException(System.out.append(String.format("className %s 的属性 %s 为TimeStamp 必须有默认值 %n", x.getName(), filed.getName())).toString());
                            }

                        } else {
                            commSql.append(TableAttribute.getLength(type));
                            commSql.append(") ");
                            commSql.append(TableAttribute.getDefaultNull());
                        }


                        commSql.append(TableAttribute.getDefaultCommit());

                    }

                    //分别赋予sql
                    sql.append(commSql.toString());

                    try {


                        sqlBuild = new StringBuilder("desc ");
                        sqlBuild.append(table.value());
                        sqlBuild.append("  ");
                        sqlBuild.append(filed.getName());

                        statement = connect.prepareStatement(sqlBuild.toString());
                        ResultSet resultSet = statement.executeQuery();

                        if (!resultSet.next()) {

                            updateSql.append("alter table  ");
                            updateSql.append(table.value());
                            updateSql.append(" add ");
                            updateSql.append(filed.getName());
                            updateSql.append(" ");
                            updateSql.append(commSql.delete(commSql.length() - 1, commSql.length()));
                            updateSql.append("; \n");


                        }

                    } catch (SQLException e) {

                        if (!e.getMessage().endsWith("doesn't exist")) {
                            throw new RuntimeException(e);
                        }
                    }


                }

                if (id.isEmpty()) {
                    throw new RuntimeException(System.out.append(x.getName()).append(" ").append(ID_outOR_MSG).append(" \n").toString());
                }

                try {
                    closeConnect(connect);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                sql.append(TableAttribute.getPrimaryId(id));
                sql.append("\n");
                sql.append(updateSql);


            }
        });


        if (sql.length() != 0) {

            OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(file, true));
            osw.write(sql.toString());
            osw.close();

        }


    }


    /**
     * 生成sql
     */
    private void createSql() throws Exception {
        if (dataSource == null) {
            throw new RuntimeException(System.out.append(DATASOURCE_outOR_MSG).append(" \n").toString());
        }
        Connection connect = getConnect(dataSource);

        if (connect == null) {
            throw new RuntimeException(System.out.append(CONNECT_outOR_MSG).append(" \n").toString());
        }
        if (packageBase == null || packageBase.isEmpty()) {
            throw new RuntimeException(System.out.append(PACKAGEBASE_outOR_MSG).append(" \n").toString());
        }
        log.info("开始扫描{}包下面的表格实体类", packageBase);
        List<Class<?>> classNameList = new ArrayList<>();
        //判断是否是多个包名
        String[] packageToScannerArr;
        if (packageBase.contains(",")) {
            packageToScannerArr = packageBase.split(",");
        } else {
            packageToScannerArr = new String[]{
                    packageBase
            };
        }
        for (String packName : packageToScannerArr) {
            if (packName.contains(".")) {
                packName = packName.replaceAll("\\.", "/");
            }
            URL resource = Thread.currentThread().getContextClassLoader().getResource(packName);
            if (resource == null) {
                throw new RuntimeException(String.format("packageName %s was incorrect package %n", packName));
            }
            String path = resource.getFile();

            if (path == null || path.isEmpty()) {
                throw new RuntimeException(String.format("packageName %s was not exist %n", packName));
            }

            if (path.contains("%20")) {
                path = path.replaceAll("%20", " ");
            }
            if (path.contains("file:")) {
                path = path.substring(5);
            }
            //jar包
            if (path.contains("!")) {
                path = path.split("!")[0];

                //获取jar内的包名
                JarInputStream inputStream = new JarInputStream(new FileInputStream(path));
                JarEntry nextJarEntry = inputStream.getNextJarEntry();
                String className = "";
                while (nextJarEntry != null) {
                    className = nextJarEntry.getName();
                    if (className.startsWith(packName) && className.endsWith(".class")) {
                        className = className.split("\\.")[0].replaceAll("/", ".");
                        classNameList.add(Class.forName(className));
                    }
                    nextJarEntry = inputStream.getNextJarEntry();
                }

                inputStream.close();
            } else {
                //获取不是jar内的包名
                File files = new File(path);
                if (files == null || !files.isDirectory()) {
                    throw new RuntimeException(String.format("packageName %s was not directory %n", packName));
                }
                File[] fileArr = files.listFiles();
                //开头的包名
                String startClassName = packName.split("/")[0];

                URLClassLoader urlClassLoader;
                String[] classNameArr;
                StringBuilder builder;

                for (File childFile : fileArr) {
                    classNameArr = childFile.getAbsolutePath().split(startClassName);
                    urlClassLoader = new URLClassLoader(new URL[]{
                            new URL(DEFAULT_FILE_PREFIX + classNameArr[0])
                    });
                    builder = new StringBuilder();
                    builder.append(startClassName);
                    builder.append(classNameArr[1].replaceAll("\\\\", "."));

                    //去除.class
                    classNameList.add(urlClassLoader.loadClass(builder.substring(0, builder.length() - 6)));

                }

            }

        }


        //生产sql文件
        String filePath = DbHandler.class.getClassLoader().getResource("").getPath();
        if (filePath.contains("%20")) {
            filePath = filePath.replaceAll("%20", " ");
        }
        filePath = filePath.substring(1);


        File file = new File(filePath, DB_NAME);

        if (file.exists()) {
            file.delete();
        }
        file.createNewFile();

        autoNewSql(file, classNameList);

        log.info("结束扫描{}包下面的表格实体类", packageBase);
    }


    /**
     * 执行sql
     */
    private void excuteSql() {

        File configFile = null;

        OutputStream os = null;
        InputStream is =
                DbHandler.class.getClassLoader().getResourceAsStream(fileName);

        try {

            if (is == null || is.available() == 0) {
                throw new RuntimeException(System.out.append("cannot open ").append(fileName).append(" it`s was not exist ").append("\n").toString());
            }

            String path = DbHandler.class.getClassLoader().getResource("").getPath();

            if (path.contains("%20")) {
                path = path.replaceAll("%20", " ");
            }

            path = path.substring(1);

            configFile = new File(path, fileName);

            if (configFile.exists()) {
                configFile.delete();
            }
            configFile.createNewFile();
            os = new FileOutputStream(configFile);
            byte[] by = new byte[1024];
            int len = 0;
            while ((len = is.read(by)) > 0) {

                os.write(by, 0, len);
                os.flush();
            }


        } catch (Exception e) {

            throw new RuntimeException(e);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }


        log.info("开始进行数据库导入操作");

        Project project = new Project();


        //设定日志记录
        DefaultLogger logger = new DefaultLogger();
        //设定输入流
        logger.setErrorPrintStream(System.err);
        logger.setOutputPrintStream(System.out);
        //设定错误级别
        logger.setMessageOutputLevel(showSql ? outOR_HIGH_GRADE : outOR_JUNIOR_GRADE);

        //绑定日志
        project.addBuildListener(logger);

        //开始构建
        project.fireBuildStarted();

        //初始化
        project.init();

        //开始工程帮助
        ProjectHelper helper = ProjectHelper.getProjectHelper();

        //进行解析数据
        helper.parse(project, configFile);

        //进行执行任务
        project.executeTarget(project.getDefaultTarget());

        //结束输出
        project.fireBuildFinished(null);


        log.info("进行数据库导入操做success....");


    }


    public enum DateGeneStrategy {
        DEFAULT(""), CREATE(" NULL DEFAULT CURRENT_TIMESTAMP  "), UPDATE(" NOT NULL ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
        private String value;

        DateGeneStrategy(String value) {
            this.value = value;
        }

        public String getDefaultValue() {
            return value;
        }

    }

    private enum TableAttribute {
        DATE("java.util.Date", "Date", -1), TIMESTAMP("java.sql.Timestamp", "TIMESTAMP", -2), LONG("java.lang.Long", "bigint", 11), DOUBLE("java.lang.Double", "double", 11), INTEGER("java.lang.Integer", "int", 11), STRING("java.lang.String", "varchar", 2 << 8), BOOLEAN("java.lang.Boolean", "bit", 1);
        private String key;
        private String columnName;
        private int value;

        TableAttribute(String key, String columnName, int value) {
            this.key = key;
            this.columnName = columnName;
            this.value = value;
        }

        public int getLength() {
            return value;
        }


        public static int getLength(String key) {

            if (key == null || key.isEmpty()) {
                return 0;
            }
            TableAttribute[] values = TableAttribute.values();

            for (TableAttribute deault : values) {

                if (deault.key.equals(key)) {

                    return deault.value;
                }
            }

            return 0;
        }

        public static String getNotNull() {
            return "NOT NULL ";
        }

        public static String getDefaultNull() {
            return " DEFAULT NULL ";
        }

        public static String getDefaultCommit() {
            return ",";
        }


        public static String getPrimaryId(String key) {
            StringBuilder builder = new StringBuilder("PRIMARY KEY (`");
            builder.append(key);
            builder.append("`) ");
            builder.append(" ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
            return builder.toString();
        }


        public static String getCommit(String value) {
            StringBuilder builder = new StringBuilder(" COMMENT '");
            builder.append(value);
            builder.append("' ,");
            return builder.toString();
        }

        public static String getIdCommit(String value, String type) {
            StringBuilder builder = new StringBuilder("`");
            builder.append(value);
            builder.append("` ");
            builder.append(getColumn(type));
            builder.append(" (");
            builder.append(getLength(type));
            builder.append(") ");
            builder.append("NOT NULL  AUTO_INCREMENT , ");
            return builder.toString();
        }


        public static String getColumn(String key) {

            if (key == null || key.isEmpty()) {
                return "";
            }
            TableAttribute[] values = TableAttribute.values();

            for (TableAttribute deault : values) {
                if (deault.key.equals(key)) {
                    return deault.columnName;
                }
            }

            return "";
        }

    }


    /**
     * 获取链接
     *
     * @param source
     * @return
     * @throws Exception
     */
    private Connection getConnect(DataSource source) throws Exception {
        if (source == null) {
            return null;
        }
        return source.getConnection();

    }

    /**
     * 关闭连接
     *
     * @param connection
     * @throws SQLException
     */
    private void closeConnect(Connection connection) throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }



    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }


    public void setPackageBase(String packageBase) {
        this.packageBase = packageBase;
    }


    public void setShowSql(Boolean showSql) {
        this.showSql = showSql;
    }


    public void setAlwaysInit(Boolean alwaysInit) {
        this.alwaysInit = alwaysInit;
    }
}
