package org.nessary.project.service.admin.dev.mapper;

import org.nessary.project.facade.admin.dev.entity.Users;
import org.springframework.transaction.annotation.Transactional;

/**
 * users的mapper
 * Created by Ness on 2017/2/18.
 */
@Transactional(rollbackFor = Exception.class)
public interface UsersMapper {
    /**
     * 存储Users的实体类
     *
     * @param users users的对象
     */
    void saveUsers(Users users);

    /**
     * 通过姓名查找 user用户
     *
     * @param userName 用户姓名
     * @return
     */
    Users findUsersByUserName(String userName);

    /**
     * 根据用户名检测是否存在
     *
     * @param userName 用户名
     * @return
     */
    int checkUsersExistByUsersName(String userName);

    void register(String uuid,String userName, String userPassword);

    /**
     * 根据用户名查找用户角色Id
     */
    int findRolesIdByName(String name);
}
