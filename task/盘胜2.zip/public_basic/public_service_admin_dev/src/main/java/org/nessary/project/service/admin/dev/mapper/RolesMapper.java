package org.nessary.project.service.admin.dev.mapper;

import org.nessary.project.facade.admin.dev.entity.Roles;

import java.util.List;

/**
 * roles的mapper
 * Created by Administrator on 2017/2/22 0022.
 */
public interface RolesMapper {
    /**
     * 增加角色
     */
    void saveRoles(String rolesName);
    /**
     * 修改角色
     */
    void changeRoles(String rolesName, int rolesId);
    /**
     * 根据Id查角色
     */
    Roles findRolesById(int id);
    /**
     * 角色列表
     */
    List<Roles> listRoles();
    /**
     * 删除角色
     */
    void delRoles(String RolesName);
}
