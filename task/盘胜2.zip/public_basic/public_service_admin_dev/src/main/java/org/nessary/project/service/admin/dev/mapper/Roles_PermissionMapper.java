package org.nessary.project.service.admin.dev.mapper;

import java.util.List;

/**
 * Created by Administrator on 2017/2/23 0023.
 */
public interface Roles_PermissionMapper {
    /**
     * 通过角色Id查找权限id
     */
    List findPermissionId(int rolesId);
    /**
     * 增加角色权限
     */
    void savePermission(int rolesId, int permissionId);
    /**
     * 删除角色权限
     */
    void delPermission(int rolesId, int permissionId);
}
