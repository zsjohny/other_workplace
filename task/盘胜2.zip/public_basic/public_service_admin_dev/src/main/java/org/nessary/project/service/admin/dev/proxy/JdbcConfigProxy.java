package org.nessary.project.service.admin.dev.proxy;

import org.nessary.project.facade.admin.dev.entity.JdbcConfig;
import org.nessary.project.service.admin.dev.mapper.JdbcConfigMapper;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by 97947 on 2017/2/27.
 * jdbcConfig代理层
 */
@Component
@Transactional
public class JdbcConfigProxy {
    @Autowired
    private JdbcConfigMapper jdbcConfigMapper;

    public List<JdbcConfig> findAllJdbcConfig() {
        return jdbcConfigMapper.findAllJdbcConfig();
    }

    public JdbcConfig findJdbcById(Integer id) {
        if (Regular.checkEmpty(id,null)){
            return null;
        }
        return jdbcConfigMapper.findJdbcById(id);
    }

    public void addJdbc(String uuid,String url, String initUrl, String user, String pass, Integer initSize, Integer maxSize, Integer minSize, Integer waitTime, Integer checkTime, Integer minInitTime) {
        if (Regular.checkEmpty(url,null)||Regular.checkEmpty(initUrl,null)||Regular.checkEmpty(user,null)||Regular.checkEmpty(pass,null)||Regular.checkEmpty(initSize,null)||Regular.checkEmpty(maxSize,null)||Regular.checkEmpty(minSize,null)||Regular.checkEmpty(waitTime,null)||Regular.checkEmpty(checkTime,null)||Regular.checkEmpty(minInitTime,null)){
            return;
        }
        jdbcConfigMapper.addJdbc(uuid,url,initUrl,user,pass,initSize,maxSize,minSize,waitTime,checkTime,minInitTime);
    }

    public void deleteJdbc(Integer id,Boolean deleted) {
        if (Regular.checkEmpty(deleted,null) ||Regular.checkEmpty(id,null)){
            return;
        }
        jdbcConfigMapper.deleteJdbc(id,deleted);
    }

    public void updateUrl(Integer id, String url) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(url,null)){
            return ;
        }
        jdbcConfigMapper.updateUrl(id,url);
    }

    public void updateInitUrl(Integer id, String initUrl) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(initUrl,null)){
            return;
        }
        jdbcConfigMapper.updateInitUrl(id,initUrl);
    }

    public void updateUser(Integer id, String user) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(user,null)){
            return;
        }
        jdbcConfigMapper.updateUser(id,user);
    }

    public void updatePass(Integer id, String pass) {

        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(pass,null)){
            return;
        }
        jdbcConfigMapper.updatePass(id,pass);
    }

    public void updateInitSize(Integer id, Integer initSize) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(initSize,null)){
            return;
        }
        jdbcConfigMapper.updateInitSize(id,initSize);
    }

    public void updateMaxSize(Integer id, Integer maxSize) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(maxSize,null)){
            return;
        }
        jdbcConfigMapper.updateMaxSize(id,maxSize);
    }

    public void updateMinSize(Integer id, Integer minSize) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(minSize,null)){
            return;
        }
        jdbcConfigMapper.updateMinSize(id,minSize);
    }

    public void updateWaitTime(Integer id, Integer waitTime) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(waitTime,null)){
            return;
        }
        jdbcConfigMapper.updateWaitTime(id,waitTime);
    }

    public void updateCheckTime(Integer id, Integer checkTime) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(checkTime,null)){
            return;
        }
        jdbcConfigMapper.updateCheckTime(id,checkTime);
    }

    public void updateMinInitTime(Integer id, Integer minInitTime) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(minInitTime,null)){
            return;
        }
        jdbcConfigMapper.updateMinInitTime(id,minInitTime);
    }
}
