package org.nessary.project.service.admin.dev.facade;

import org.nessary.project.facade.admin.dev.entity.Users;
import org.nessary.project.facade.admin.dev.service.UsersFacade;
import org.nessary.project.service.admin.dev.mapper.UsersMapper;
import org.nessary.project.service.admin.dev.proxy.RolesProxy;
import org.nessary.project.service.admin.dev.proxy.UsersProxy;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * users权限类的实现类
 * Created by Ness on 2017/2/18.
 */
@Component
@Service
//@Transactiona
public class UsersFacadeImpl implements UsersFacade {
//    @Autowired
//    private UsersMapper usersMapper;

    @Autowired
    UsersProxy usersProxy;

    @Autowired
    RolesProxy rolesProxy;

    /**
     * 存储Users的实体类
     *
     * @param users users的对象
     */
//    @Override
//    public void saveUsers(Users users) {
//        if (users == null) {
//            return;
//        }
//        usersProxy.saveUsers(users);
//
//    }

    /**
     * 通过姓名查找 user用户
     *
     * @param userName 用户姓名
     * @return
     */
//    @Override
//    public Users findUsersByUserName(String userName) {
//        if (Regular.checkEmpty(userName, null)) {
//            return null;
//        }
//
//        return  usersProxy.findUsersByUserName(userName);
//    }

    /**
     * 根据用户名检测是否存在
     *
     * @param userName 用户名
     * @return
     */
//    @Override
//    public Boolean checkUsersExistByUsersName(String userName) {
//        if (Regular.checkEmpty(userName, null)) {
//            return false;
//        }
//        int count = usersMapper.checkUsersExistByUsersName(userName);
//        return count == 0;
//    }

    @Override
    public void register(String uuid, String userName, String userPassword) {
        if (Regular.checkEmpty(uuid, null) || Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
            return;
        }
        usersProxy.register(uuid,userName,userPassword);
    }

    /**
     * 根据用户查找角色
     */
    @Override
    public String findRolesByName(String name){
        return usersProxy.findRolesByName(name);
    }

    /**
     * 根据用户名查询权限
     * @param userName
     * @return
     */
    @Override
    public Set<String> findPermissionByName(String userName){
        return rolesProxy.findPermissionByRole(usersProxy.findUsersByUserName(userName).getRolesId());
    }

    /**
     * 存储Users的实体类
     *
     * @param users users的对象
     */
    @Override
    public void saveUsers(Users users) {
        if (users == null) {
            return;
        }

        usersProxy.saveUsers(users);


    }

    /**
     * 通过姓名查找 user用户
     *
     * @param userName 用户姓名
     * @return
     */
    @Override
    public Users findUsersByUserName(String userName) {
        if (Regular.checkEmpty(userName, null)) {
            return null;
        }

        return usersProxy.findUsersByUserName(userName);
    }

    /**
     * 根据用户名检测是否存在
     *
     * @param userName 用户名
     * @return
     */
    @Override
    public Boolean checkUsersExistByUsersName(String userName) {
        if (Regular.checkEmpty(userName, null)) {
            return false;
        }
        return usersProxy.checkUsersExistByUsersName(userName);
    }
//    public static void main(String[] args) {
//        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:service/admin/dev/app_root.xml");
//        UsersFacadeImpl usersFacadeImpl = context.getBean("usersFacadeImpl", UsersFacadeImpl.class);
//        Users users = new Users();
//        users.setRolesPermis("ss");
//        usersFacadeImpl.saveUsers(users);
//        System.err.println("success");
//    }

}
