package org.nessary.project.service.admin.dev.mapper;

import org.nessary.project.facade.admin.dev.entity.Permission;

import java.util.List;
import java.util.Set;

/**
 * Created by 97947 on 2017/2/22.
 */
public interface PermissionMapper {

    List<Permission> findAllPermission();

    Permission findPermissionById(Integer id);

    void addPermission(String permissionName);

    void deletePermission(String permissionName,String descriptions);

    void updatePermission(String permissionName);

    Set<String> findPermissionByIdList(List idList);

}
