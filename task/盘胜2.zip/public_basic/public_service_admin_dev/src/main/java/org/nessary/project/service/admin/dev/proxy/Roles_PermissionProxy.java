package org.nessary.project.service.admin.dev.proxy;

import org.nessary.project.service.admin.dev.mapper.Roles_PermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Roles_Permission权限类的代理层
 * Created by Ness on 2017/2/18.
 */
@Component
@Transactional

public class Roles_PermissionProxy {
    @Autowired
    private Roles_PermissionMapper roles_permissionMapper;
    /**
     * 通过角色Id查找权限id
     */
    List findPermissionId(int rolesId){
        return  roles_permissionMapper.findPermissionId(rolesId);
    }
    /**
     * 增加角色权限
     */
    void savePermission(int rolesId,int permissionId){
        roles_permissionMapper.savePermission(rolesId,permissionId);
        return;
    }
    /**
     * 删除角色权限
     */
    void delPermission(int rolesId,int permissionId){
        roles_permissionMapper.delPermission(rolesId, permissionId);
        return;
    }

}
