package org.nessary.project.service.admin.dev.facade;

import org.nessary.project.facade.admin.dev.entity.JmsConfig;
import org.nessary.project.facade.admin.dev.service.JmsConfigFacade;
import org.nessary.project.service.admin.dev.proxy.JmsConfigProxy;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Huang Yangfeng on 2017/2/25.
 */
@Component
@Service
public class JmsConfigFacadeImpl implements JmsConfigFacade {
    @Autowired
    private JmsConfigProxy jmsConfigProxy;
    @Override
    public List<JmsConfig> findAllJms() {
        return jmsConfigProxy.findAllJms();
    }

    @Override
    public JmsConfig findJmsById(Integer id) {
        if (Regular.checkEmpty(id,null)){
            return null;
        }
        return jmsConfigProxy.findJmsById(id);
    }

    @Override
    public void addJms(String uuid, String url, String name, String pass, String scheduleAcceptTask, String scheduleEndTask) {
        if (Regular.checkEmpty(url,null)||Regular.checkEmpty(name,null)||Regular.checkEmpty(pass,null)||Regular.checkEmpty(scheduleAcceptTask,null)||Regular.checkEmpty(scheduleEndTask,null)){
            return;
        }
        jmsConfigProxy.addJms(uuid,url,name,pass,scheduleAcceptTask,scheduleEndTask);
    }

    @Override
    public void delete(Integer id, Boolean deleted) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(deleted,null)){
            return;
        }
        jmsConfigProxy.delete(id,deleted);
    }

    @Override
    public void updateUrl(Integer id, String url) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(url,null)){
            return;
        }
        jmsConfigProxy.updateUrl(id,url);
    }

    @Override
    public void updateName(Integer id, String name) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(name,null)){
            return;
        }
        jmsConfigProxy.updateName(id,name);
    }

    @Override
    public void updatePass(Integer id, String pass) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(pass,null)){
            return;
        }
        jmsConfigProxy.updatePass(id,pass);
    }

    @Override
    public void updateScheduleAcceptTask(Integer id, String secheduleAcceptTask) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(secheduleAcceptTask,null)){
            return;
        }
        jmsConfigProxy.updateScheduleAcceptTask(id,secheduleAcceptTask);
    }

    @Override
    public void updateScheduleEndTask(Integer id, String scheduleEndTask) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(scheduleEndTask,null)){
            return;
        }
        jmsConfigProxy.updateScheduleEndTask(id,scheduleEndTask);
    }
}
