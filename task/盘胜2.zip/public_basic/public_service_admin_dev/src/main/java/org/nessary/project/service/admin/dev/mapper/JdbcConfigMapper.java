package org.nessary.project.service.admin.dev.mapper;

import org.nessary.project.facade.admin.dev.entity.JdbcConfig;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by 97947 on 2017/2/23.
 */
@Transactional(rollbackFor = Exception.class)
public interface JdbcConfigMapper {

    List<JdbcConfig> findAllJdbcConfig();

    JdbcConfig findJdbcById(Integer id);

    void addJdbc(String uuid,String url, String initUrl, String user, String pass, Integer initSize, Integer maxSize, Integer minSize, Integer waitTime, Integer checkTime, Integer minInitTime);

    void deleteJdbc(Integer id,Boolean deleted);

    void updateUrl( Integer id, String url);

    void updateInitUrl(Integer id,String initUrl);

    void updateUser(Integer id,String user);

    void updatePass(Integer id,String pass);

    void updateInitSize(Integer id,Integer initSize);

    void updateMaxSize(Integer id,Integer maxSize);

    void updateMinSize(Integer id,Integer minSize);

    void updateWaitTime(Integer id,Integer waitTime);

    void updateCheckTime(Integer id,Integer checkTime);

    void updateMinInitTime(Integer id,Integer minInitTime);

}
