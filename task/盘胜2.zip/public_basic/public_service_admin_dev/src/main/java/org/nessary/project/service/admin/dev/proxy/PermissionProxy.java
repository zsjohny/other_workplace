package org.nessary.project.service.admin.dev.proxy;

import org.nessary.project.facade.admin.dev.entity.Permission;
import org.nessary.project.service.admin.dev.mapper.PermissionMapper;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by 97947 on 2017/2/27.
 * Permission权限代理层
 */
@Component
@Transactional
public class PermissionProxy {
    @Autowired
    PermissionMapper permissionMapper;

    public List<Permission> findAllPermission() {

        return permissionMapper.findAllPermission();
    }

    public Permission findPermissionById(Integer id){
        if (Regular.checkEmpty(id,null)){
            return null;
        }
        return permissionMapper.findPermissionById(id);
    }

    public void addPermission(String permissionName) {
        if (Regular.checkEmpty(permissionName,null)){
            return;
        }
        permissionMapper.addPermission(permissionName);
    }

    public void deletePermission(String permissionName, String descriptions) {
        if (Regular.checkEmpty(permissionName,null) || Regular.checkEmpty(descriptions,null)){
            return;
        }
        permissionMapper.deletePermission(permissionName,descriptions);
    }

    public void updatePermission(String permissionName) {
        if (Regular.checkEmpty(permissionName,null)){
            return;
        }
        permissionMapper.updatePermission(permissionName);
    }
}
