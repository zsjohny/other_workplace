package org.nessary.project.service.admin.dev.mapper;

import org.nessary.project.facade.admin.dev.entity.JmsConfig;

import java.util.List;

/**
 * Created by Huang Yangfeng on 2017/2/25.
 */
public interface JmsConfigMapper {

    List<JmsConfig> findAllJms();

    JmsConfig findJmsById(Integer id);

    void addJms(String uuid,String url,String name,String pass,String scheduleAcceptTask,String scheduleEndTask);

    void delete(Integer id ,Boolean deleted);

    void updateUrl(Integer id,String url);

    void updateName(Integer id,String name);

    void updatePass(Integer id,String pass);

    void updateScheduleAcceptTask(Integer id,String secheduleAcceptTask);

    void updateScheduleEndTask(Integer id , String scheduleEndTask);
}
