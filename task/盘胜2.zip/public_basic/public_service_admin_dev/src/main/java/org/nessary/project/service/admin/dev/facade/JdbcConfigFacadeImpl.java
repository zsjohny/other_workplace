package org.nessary.project.service.admin.dev.facade;

import org.nessary.project.facade.admin.dev.entity.JdbcConfig;
import org.nessary.project.facade.admin.dev.service.JdbcConfigFacade;
import org.nessary.project.service.admin.dev.proxy.JdbcConfigProxy;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by 97947 on 2017/2/23.
 * jdbcConfig权限实现层
 */

@Component
@Service
public class JdbcConfigFacadeImpl implements JdbcConfigFacade {

    @Autowired
    private JdbcConfigProxy jdbcConfigProxy;

    @Override
    public List<JdbcConfig> findAllJdbcConfig() {
        return jdbcConfigProxy.findAllJdbcConfig();
    }

    @Override
    public JdbcConfig findJdbcById(Integer id) {
        if (Regular.checkEmpty(id,null)){
            return null;
        }
        return jdbcConfigProxy.findJdbcById(id);
    }

    @Override
    public void addJdbc(String uuid,String url, String initUrl, String user, String pass, Integer initSize, Integer maxSize, Integer minSize, Integer waitTime, Integer checkTime, Integer minInitTime) {
        if (Regular.checkEmpty(url,null)||Regular.checkEmpty(initUrl,null)||Regular.checkEmpty(user,null)||Regular.checkEmpty(pass,null)||Regular.checkEmpty(initSize,null)||Regular.checkEmpty(maxSize,null)||Regular.checkEmpty(minSize,null)||Regular.checkEmpty(waitTime,null)||Regular.checkEmpty(checkTime,null)||Regular.checkEmpty(minInitTime,null)){
            return;
        }
        jdbcConfigProxy.addJdbc(uuid,url,initUrl,user,pass,initSize,maxSize,minSize,waitTime,checkTime,minInitTime);
    }

    @Override
    public void deleteJdbc(Integer id,Boolean deleted) {

        if (Regular.checkEmpty(deleted,null) ||Regular.checkEmpty(id,null)){
            return;
        }
        jdbcConfigProxy.deleteJdbc(id,deleted);
    }

    @Override
    public void updateUrl(Integer id, String url) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(url,null)){
            return ;
        }
        jdbcConfigProxy.updateUrl(id,url);
    }

    @Override
    public void updateInitUrl(Integer id, String initUrl) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(initUrl,null)){
            return;
        }
        jdbcConfigProxy.updateInitUrl(id,initUrl);
    }

    @Override
    public void updateUser(Integer id, String user) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(user,null)){
            return;
        }
        jdbcConfigProxy.updateUser(id,user);
    }

    @Override
    public void updatePass(Integer id, String pass) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(pass,null)){
            return;
        }
        jdbcConfigProxy.updatePass(id,pass);
    }

    @Override
    public void updateInitSize(Integer id, Integer initSize) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(initSize,null)){
            return;
        }
        jdbcConfigProxy.updateInitSize(id,initSize);
    }

    @Override
    public void updateMaxSize(Integer id, Integer maxSize) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(maxSize,null)){
            return;
        }
        jdbcConfigProxy.updateMaxSize(id,maxSize);
    }

    @Override
    public void updateMinSize(Integer id, Integer minSize) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(minSize,null)){
            return;
        }
        jdbcConfigProxy.updateMinSize(id,minSize);
    }

    @Override
    public void updateWaitTime(Integer id, Integer waitTime) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(waitTime,null)){
            return;
        }
        jdbcConfigProxy.updateWaitTime(id,waitTime);
    }

    @Override
    public void updateCheckTime(Integer id, Integer checkTime) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(checkTime,null)){
            return;
        }
        jdbcConfigProxy.updateCheckTime(id,checkTime);
    }

    @Override
    public void updateMinInitTime(Integer id, Integer minInitTime) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(minInitTime,null)){
            return;
        }
        jdbcConfigProxy.updateMinInitTime(id,minInitTime);
    }
}
