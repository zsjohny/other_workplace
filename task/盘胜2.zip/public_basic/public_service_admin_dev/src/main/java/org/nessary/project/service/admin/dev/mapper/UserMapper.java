package org.nessary.project.service.admin.dev.mapper;

import org.nessary.project.facade.admin.dev.entity.User;

import java.util.List;

public interface UserMapper {

    List<User> findUserAllByDeleted();

    void saveUser(User user);

}