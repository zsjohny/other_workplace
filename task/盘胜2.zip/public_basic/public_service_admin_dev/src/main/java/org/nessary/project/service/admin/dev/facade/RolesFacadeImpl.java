package org.nessary.project.service.admin.dev.facade;

import com.alibaba.dubbo.config.annotation.Service;
import org.nessary.project.facade.admin.dev.entity.Roles;
import org.nessary.project.facade.admin.dev.service.RolesFacade;
import org.nessary.project.service.admin.dev.proxy.PermissionProxy;
import org.nessary.project.service.admin.dev.proxy.RolesProxy;
import org.nessary.project.service.admin.dev.proxy.Roles_PermissionProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 *
 * Created by Administrator on 2017/2/22 0022.
 */
@Component
@Service
@Transactional
public class RolesFacadeImpl implements RolesFacade {
    @Autowired
    private RolesProxy rolesProxy;
    @Autowired
    private Roles_PermissionProxy roles_permissionProxy;
    @Autowired
    private PermissionProxy permissionProxy;
    /**
     * 存储roles实体
     */
    @Override
    public void saveRoles(String rolesName){
        if (rolesName == null) {
            return;
        }
        rolesProxy.saveRoles(rolesName);
    }
    /**
     * 修改roles实体
     */
    @Override
    public void changeRoles(String rolesName,int rolesId){
        if (rolesName == null||rolesId == 0) {
            return;
        }
        rolesProxy.changeRoles(rolesName,rolesId);
    }
    /**
     * 根据角色名查找角色
     */
    @Override
    public Roles findRolesById(int id){
        return rolesProxy.findRolesById(id);
    }

    /**
     * 角色列表
     */
    @Override
    public List<Roles> listRoles(){
        return rolesProxy.listRoles();
    }
    /**
     * 删除角色
     */
    public void delRoles(String rolesName){
        rolesProxy.delRoles(rolesName);
        return;
    }

    /**
     * 通过角色查询角色权限
     */
    public Set<String> findPermissionByRole(int rolesId){
        return rolesProxy.findPermissionByRole(rolesId);
    }

    /**
     * 增加角色权限
     */
    public void savePermission(int rolesId,int  permissionId){
       rolesProxy.savePermission(rolesId,permissionId);
       return;
    }

    /**
     * 删除角色权限
     */
    public void delPermission(int rolesId,int permissionId){
        rolesProxy.delPermission(rolesId,permissionId);
        return;
    }
}
