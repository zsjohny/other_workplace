package org.nessary.project.service.admin.dev.facade;

import org.nessary.project.facade.admin.dev.entity.Permission;
import org.nessary.project.facade.admin.dev.service.PermissionFacade;
import org.nessary.project.service.admin.dev.proxy.PermissionProxy;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by 97947 on 2017/2/22.
 * Permission权限类实现层
 */
@Component
@Service
public class PermissionFacadeImpl implements PermissionFacade {

    @Autowired
    private PermissionProxy permissionProxy;
    @Override
    public List<Permission> findAllPermission() {

        return permissionProxy.findAllPermission();
    }

    @Override
    public Permission findPermissionById(Integer id){
        if (Regular.checkEmpty(id,null)){
            return null;
        }
        return permissionProxy.findPermissionById(id);
    }

    @Override
    public void addPermission(String permissionName) {
        if (Regular.checkEmpty(permissionName,null)){
            return;
        }
        permissionProxy.addPermission(permissionName);
    }

    @Override
    public void deletePermission(String permissionName, String descriptions) {
        if (Regular.checkEmpty(permissionName,null)){
            return;
        }
        permissionProxy.deletePermission(permissionName,descriptions);
    }

    @Override
    public void updatePermission(String permissionName) {
        if (Regular.checkEmpty(permissionName,null)){
            return;
        }
        permissionProxy.updatePermission(permissionName);
    }
}
