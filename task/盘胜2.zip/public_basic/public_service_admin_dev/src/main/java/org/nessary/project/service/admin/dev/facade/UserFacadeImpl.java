package org.nessary.project.service.admin.dev.facade;

import com.alibaba.dubbo.config.annotation.Service;
import org.nessary.project.facade.admin.dev.entity.User;
import org.nessary.project.facade.admin.dev.service.UserFacade;
import org.nessary.project.service.admin.dev.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 用户的服务实现层
 * Created by Ness on 2017/2/8.
 */
@Component
@Service
@Transactional
public class UserFacadeImpl implements UserFacade {
    @Autowired
    UserMapper userMapper;

    /**
     * 进行保存User
     *
     * @param user user实体类
     */
    @Override
    public void saveUser(User user) {
        userMapper.saveUser(user);
    }


    /**
     * 查找所有的 user
     *
     * @param deleted 是否删除 true 是 false 不是
     * @return
     */
    @Override
    public List<User> findUserAllByDeleted(Boolean deleted) {
        //目前用不到
        System.out.println(userMapper.findUserAllByDeleted().size());
        return userMapper.findUserAllByDeleted();
    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:service/admin/dev/app_root.xml");
        UserFacade userFacadeImpl = context.getBean("userFacadeImpl", UserFacade.class);
        System.out.println(userFacadeImpl.findUserAllByDeleted(false).size());
    }

}
