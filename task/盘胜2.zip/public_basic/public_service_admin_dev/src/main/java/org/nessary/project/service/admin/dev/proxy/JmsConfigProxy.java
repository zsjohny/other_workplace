package org.nessary.project.service.admin.dev.proxy;

import org.nessary.project.facade.admin.dev.entity.JmsConfig;
import org.nessary.project.service.admin.dev.mapper.JmsConfigMapper;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by 97947 on 2017/2/27.
 * jmsConfig权限代理层
 */
@Component
@Transactional
public class JmsConfigProxy {

    @Autowired
    JmsConfigMapper jmsConfigMapper;

    public List<JmsConfig> findAllJms() {
        return jmsConfigMapper.findAllJms();
    }

    public JmsConfig findJmsById(Integer id)
    {
        if (Regular.checkEmpty(id,null)){
            return null;
        }
        return jmsConfigMapper.findJmsById(id);
    }

    public void addJms(String uuid, String url, String name, String pass, String scheduleAcceptTask, String scheduleEndTask) {
        if (Regular.checkEmpty(url,null)||Regular.checkEmpty(name,null)||Regular.checkEmpty(pass,null)||Regular.checkEmpty(scheduleAcceptTask,null)||Regular.checkEmpty(scheduleEndTask,null)){
            return;
        }
        jmsConfigMapper.addJms(uuid,url,name,pass,scheduleAcceptTask,scheduleEndTask);
    }

    public void delete(Integer id, Boolean deleted) {

        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(deleted,null)){
            return;
        }
        jmsConfigMapper.delete(id,deleted);
    }

    public void updateUrl(Integer id, String url) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(url,null)){
            return;
        }
        jmsConfigMapper.updateUrl(id,url);
    }

    public void updateName(Integer id, String name) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(name,null)){
            return;
        }
        jmsConfigMapper.updateName(id,name);
    }

    public void updatePass(Integer id, String pass) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(pass,null)){
            return;
        }
        jmsConfigMapper.updatePass(id,pass);
    }

    public void updateScheduleAcceptTask(Integer id, String secheduleAcceptTask) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(secheduleAcceptTask,null)){
            return;
        }
        jmsConfigMapper.updateScheduleAcceptTask(id,secheduleAcceptTask);
    }

    public void updateScheduleEndTask(Integer id, String scheduleEndTask) {
        if (Regular.checkEmpty(id,null)||Regular.checkEmpty(scheduleEndTask,null)){
            return;
        }
        jmsConfigMapper.updateScheduleEndTask(id,scheduleEndTask);
    }
}
