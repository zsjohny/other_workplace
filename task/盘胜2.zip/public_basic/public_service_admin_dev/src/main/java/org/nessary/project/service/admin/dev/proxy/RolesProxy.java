package org.nessary.project.service.admin.dev.proxy;

import org.nessary.project.facade.admin.dev.entity.Roles;
import org.nessary.project.service.admin.dev.mapper.PermissionMapper;
import org.nessary.project.service.admin.dev.mapper.RolesMapper;
import org.nessary.project.service.admin.dev.mapper.Roles_PermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 * roles权限类的代理层
 * Created by Ness on 2017/2/18.
 */
@Component
@Transactional

public class RolesProxy {
    @Autowired
    private RolesMapper rolesMapper;
    @Autowired
    private Roles_PermissionMapper roles_permissionMapper;
    @Autowired
    private PermissionMapper permissionMapper;
    /**
     * 存储roles实体
     */
    public void saveRoles(String rolesName){
        if (rolesName == null) {
            return;
        }
        rolesMapper.saveRoles(rolesName);
    }
    /**
     * 修改roles实体
     */
    public void changeRoles(String rolesName,int rolesId){
        if (rolesName == null||rolesId == 0) {
            return;
        }
        rolesMapper.changeRoles(rolesName,rolesId);
    }
    /**
     * 根据角色名查找角色
     */
    public Roles findRolesById(int id){
        Roles roles = rolesMapper.findRolesById(id);
        return roles;
    }

    /**
     * 角色列表
     */
    public List<Roles> listRoles(){
        List<Roles> rolesList = rolesMapper.listRoles();
        return rolesList;
    }
    /**
     * 删除角色
     */
    public void delRoles(String rolesName){
        rolesMapper.delRoles(rolesName);
        return;
    }

    /**
     * 通过角色查询角色权限
     */
    public Set<String> findPermissionByRole(int rolesId){
        List<Integer> permissionIdList = roles_permissionMapper.findPermissionId(rolesId);
        Set<String> set = permissionMapper.findPermissionByIdList(permissionIdList);
        return set;
    }

    /**
     * 增加角色权限
     */
    public void savePermission(int rolesId,int  permissionId){
        roles_permissionMapper.savePermission(rolesId,permissionId);
        return;
    }

    /**
     * 删除角色权限
     */
    public void delPermission(int rolesId,int permissionId){
        roles_permissionMapper.delPermission(rolesId,permissionId);
        return;
    }
}
