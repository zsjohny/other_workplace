package dubbo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.net.MalformedURLException;

/**
 * Created by Ness on 2017/2/8.
 */
public class DubboStartTest {
    public static void main(String[] args) throws ClassNotFoundException, MalformedURLException {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("classpath:user/app_root.xml");

        context.start();

        System.err.println("startup ok");

        while (true) {
            synchronized (DubboStartTest.class) {
                try {
                    DubboStartTest.class.wait();
                } catch (InterruptedException e) {
                    System.err.println(e);
                    context.stop();
                }
            }
        }

    }
}
