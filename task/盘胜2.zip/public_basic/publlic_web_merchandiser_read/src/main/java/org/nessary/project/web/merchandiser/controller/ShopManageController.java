package org.nessary.project.web.merchandiser.controller;

public class ShopManageController {

}
