package org.nessary.project.web.user.biz;

import org.nessary.project.utils.operate.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * 用户信息的业务处理层
 * Created by Ness on 2017/2/8.
 */
public interface UserInfoBiz {
    Response findUserAll(HttpServletRequest request);

}
