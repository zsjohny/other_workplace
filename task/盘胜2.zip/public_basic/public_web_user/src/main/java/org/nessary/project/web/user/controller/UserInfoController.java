package org.nessary.project.web.user.controller;

import org.nessary.project.utils.annotion.ServiceInvoke;
import org.nessary.project.utils.http.HttpTools;
import org.nessary.project.utils.operate.Response;
import org.nessary.project.web.user.biz.UserInfoBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 用户信息的controller
 * Created by Ness on 2017/2/8.
 */
@RestController
@RequestMapping("/userInfo")
public class UserInfoController {

    @Autowired
    private UserInfoBiz userInfoBiz;

    @RequestMapping("/findUserInfoAll")
    @ServiceInvoke("findUserInfoAll")
    public Response findUserAll(HttpServletRequest request) {

        return userInfoBiz.findUserAll(request);

    }



}
