package org.nessary.project.web.user.biz.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.nessary.project.facade.user.entity.User;
import org.nessary.project.facade.user.service.UserFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.http.Iptools;
import org.nessary.project.utils.operate.Response;
import org.nessary.project.web.user.biz.UserInfoBiz;
import org.nessary.project.web.user.enums.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 业务处理层
 * Created by Ness on 2017/2/8.
 */
@Component
public class UserInfoBizImpl implements UserInfoBiz {

    @Autowired
    private UserFacade userFacade;

    private Logger logger = LoggerFactory.getLogger(UserInfoBizImpl.class);

    @Override
    public Response findUserAll(HttpServletRequest request) {
        try {
            if (request == null) {
                logger.warn("检测到客户端传入request 为空");
                return Response.response(ResponseType.EMPTY_CODE.getCode());
            }
            logger.info("Ip{} 开始查询所有的用户信息", Iptools.gainRealIp(request));

            List<User> users = userFacade.findUserAllByDeleted(UserType.EXIST.getValue());


            User test = new User();
            test.setUuid("111");
            userFacade.saveUser(test);

            if (Regular.checkEmpty(users, null)) {
                logger.warn("Ip {} 查询所有的用户信息为空", Iptools.gainRealIp(request));
                return Response.response(ResponseType.EMPTY_QUERY.getCode());

            }


            JSONObject jsonObject;
            JSONArray jsonArray = new JSONArray();
            for (User user : users) {
                if (user == null) {
                    continue;

                }

                jsonObject = new JSONObject();
                jsonObject.put("id", user.getId());
                jsonObject.put("uuid", user.getUuid());
                jsonArray.add(jsonObject);
            }
            logger.info("Ip{} 结束查询所有的用户信息", Iptools.gainRealIp(request));

            return Response.success(jsonArray);

        } catch (Exception e) {
            System.out.println(e);
            logger.info("Ip {} 查询所有的用户出错 ", Iptools.gainRealIp(request), e);
        }


        return Response.fail();

    }

}
