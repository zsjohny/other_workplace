package org.nessary.project.web.user.enums;

/**
 * 用户类型
 * Created by Ness on 2017/2/8.
 */
public enum UserType {
    EXIST(false), NOT_EXIST(true);
    private boolean value;

    UserType(boolean value) {
        this.value = value;
    }

    public boolean getValue() {
        return value;
    }
}
