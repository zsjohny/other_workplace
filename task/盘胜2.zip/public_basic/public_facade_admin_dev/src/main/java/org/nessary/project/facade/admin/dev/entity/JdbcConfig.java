package org.nessary.project.facade.admin.dev.entity;

import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.operate.DbHandler;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * Created by 97947 on 2017/2/23.
 */
@Table("t_jdbc_config")
public class JdbcConfig implements Serializable {
    @Id
    private Integer id;

    @Column(commit = "伪Id")
    private String uuid;

    @Column(commit = "数据库连接地址")
    private String url;

    @Column(commit = "数据库初始化地址")
    private String initUrl;

    @Column(commit = "数据库用户名")
    private String user;

    @Column(commit = "数据库密码")
    private String pass;

    @Column(commit = "初始化连接")
    private Integer initSize;

    @Column(commit = "配置初始化最大")
    private Integer maxSize;

    @Column(commit = "配置初始化最小")
    private Integer minSize;

    @Column(commit = "配置获取连接等待超时的时间,以毫秒为单位")
    private Integer waitTime;

    @Column(commit = "配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒")
    private Integer checkTime;

    @Column(commit = "配置一个连接在池中最小生存的时间，单位是毫秒")
    private Integer minInitTime;

    @Column(commit = "创建时间",dateGeneStrategy = DbHandler.DateGeneStrategy.CREATE)
    private Timestamp createTime;

    @Column(commit = "最后修改时间",dateGeneStrategy = DbHandler.DateGeneStrategy.UPDATE)
    private Timestamp gmtModifiedTime;

    @Column(commit = "是否删除")
    private Boolean deleted;

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getGmtModifiedTime() {
        return gmtModifiedTime;
    }

    public void setGmtModifiedTime(Timestamp gmtModifiedTime) {
        this.gmtModifiedTime = gmtModifiedTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getInitUrl() {
        return initUrl;
    }

    public void setInitUrl(String initUrl) {
        this.initUrl = initUrl;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Integer getInitSize() {
        return initSize;
    }

    public void setInitSize(Integer initSize) {
        this.initSize = initSize;
    }

    public Integer getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(Integer maxSize) {
        this.maxSize = maxSize;
    }

    public Integer getMinSize() {
        return minSize;
    }

    public void setMinSize(Integer minSize) {
        this.minSize = minSize;
    }

    public Integer getWaitTime() {
        return waitTime;
    }

    public void setWaitTime(Integer waitTime) {
        this.waitTime = waitTime;
    }

    public Integer getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Integer checkTime) {
        this.checkTime = checkTime;
    }

    public Integer getMinInitTime() {
        return minInitTime;
    }

    public void setMinInitTime(Integer minInitTime) {
        this.minInitTime = minInitTime;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

}
