package org.nessary.project.facade.admin.dev.service;


import org.nessary.project.facade.admin.dev.Response.PermissionResponse;
import org.nessary.project.facade.admin.dev.entity.Permission;

import java.util.List;

/**
 * Created by 97947 on 2017/2/22.
 */
public interface PermissionFacade {

    //查询所有用户权限
    List<Permission> findAllPermission();

    Permission findPermissionById(Integer id);

    void addPermission(String permissionName);

    void deletePermission(String permissionName,String descriptions);

    void updatePermission(String permissionName);
}
