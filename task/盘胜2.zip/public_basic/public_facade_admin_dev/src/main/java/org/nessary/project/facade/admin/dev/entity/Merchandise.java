package org.nessary.project.facade.admin.dev.entity;

import java.sql.Blob;

/**
 * Created by Ness on 2017/2/10.
 */
public class Merchandise {
    private byte[] headPics;

    public byte[] getHeadPics() {
        return headPics;
    }

    public void setHeadPics(byte[] headPics) {
        this.headPics = headPics;
    }
}
