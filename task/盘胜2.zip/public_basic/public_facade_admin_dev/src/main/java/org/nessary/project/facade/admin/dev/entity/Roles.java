package org.nessary.project.facade.admin.dev.entity;

import com.alibaba.fastjson.annotation.JSONField;
import org.apache.commons.net.ntp.TimeStamp;
import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.operate.DbHandler;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;
import java.security.Timestamp;
import java.util.Date;

/**
 * Created by 97947 on 2017/2/20.
 */

/**
 * 用户角色表
 */
@Table("t_roles")
public class Roles implements Serializable {
    /**
     * 用户Id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(commit = "角色伪Id")
    private String uuid;

    @Column(commit = "角色名称")
    private String name;

    @Column(commit = "创建时间",dateGeneStrategy = DbHandler.DateGeneStrategy.CREATE)
    private Timestamp createTime;

    @Column(commit = "最后修改时间",dateGeneStrategy = DbHandler.DateGeneStrategy.UPDATE)
    private Timestamp gmtModified;

    @Column(commit = "是否删除 true是 false不是")
    private Boolean deleted;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Timestamp gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
