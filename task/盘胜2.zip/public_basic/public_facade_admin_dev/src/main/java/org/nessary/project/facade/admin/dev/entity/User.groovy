package org.nessary.project.facade.admin.dev.entity

/**
 * User实体类
 * Created by Ness on 2017/2/8.
 */
class User implements Serializable {
    /**
     * 自增Id
     */
    private Integer id

    /**
     * 用户的自增I伪d
     */
    private String uuid



    /**
     * 是否删除  true 是  false不是
     */
    private Boolean deleted

    Integer getId() {
        return id
    }

    void setId(Integer id) {
        this.id = id
    }

    String getUuid() {
        return uuid
    }

    void setUuid(String uuid) {
        this.uuid = uuid
    }

    Boolean getDeleted() {
        return deleted
    }

    void setDeleted(Boolean deleted) {
        this.deleted = deleted
    }
}
