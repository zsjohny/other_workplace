package org.nessary.project.facade.admin.dev.service;

import org.nessary.project.facade.admin.dev.entity.User;

import java.util.List;

/**
 * user的服务层
 * Created by Ness on 2017/2/8.
 */
public interface UserFacade {
    /**
     * 保存user
     *
     * @param user
     */
    void saveUser(User user);

    /**
     * 根据是否删除查询所有User
     *
     * @param deleted 是否删除 true 是 false 不是
     * @return
     */
    List<User> findUserAllByDeleted(Boolean deleted);

}
