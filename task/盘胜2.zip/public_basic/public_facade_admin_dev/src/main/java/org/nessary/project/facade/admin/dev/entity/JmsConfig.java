package org.nessary.project.facade.admin.dev.entity;

import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.operate.DbHandler;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by 97947 on 2017/2/23.
 */
@Table("t_jms_config")
public class JmsConfig implements Serializable{

    @Id
    private Integer id;

    @Column(commit = "伪Id")
    private String uuid;

    @Column(commit = "jsm地址")
    private String url;

    @Column(commit = "jms用户名")
    private String name;

    @Column(commit = "jms密码")
    private String pass;

    @Column(commit = "接受任务时间表")
    private String scheduleAcceptTask;

    @Column(commit = "结束任务时间表")
    private String scheduleEndTask;

    @Column(commit = "创建时间",dateGeneStrategy = DbHandler.DateGeneStrategy.CREATE)
    private Timestamp createTime;

    @Column(commit = "最后修改时间",dateGeneStrategy = DbHandler.DateGeneStrategy.UPDATE)
    private Timestamp gmtModifiedTime;

    @Column(commit = "是否删除 是 true 否 false")
    private Boolean deleted;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getScheduleAcceptTask() {
        return scheduleAcceptTask;
    }

    public void setScheduleAcceptTask(String scheduleAcceptTask) {
        this.scheduleAcceptTask = scheduleAcceptTask;
    }

    public String getScheduleEndTask() {
        return scheduleEndTask;
    }

    public void setScheduleEndTask(String scheduleEndTask) {
        this.scheduleEndTask = scheduleEndTask;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getGmtModifiedTime() {
        return gmtModifiedTime;
    }

    public void setGmtModifiedTime(Timestamp gmtModifiedTime) {
        this.gmtModifiedTime = gmtModifiedTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
