package org.nessary.project.facade.admin.dev.service;

import org.nessary.project.facade.admin.dev.entity.Roles;

import java.util.List;
import java.util.Set;

/**
 * 角色权限控制
 * Created by Administrator on 2017/2/22 0022.
 */
public interface RolesFacade {
    /**
     * 增加角色
     */
    void saveRoles(String rolesName);

    /**
     * 修改角色
     */
    void changeRoles(String rolesName, int rolesId);

    /**
     * 根据角色id查角色
     */
    Roles findRolesById(int id);

    /**
     * 角色列表
     */
    List<Roles> listRoles();

    /**
     * 删除角色
     */
    void delRoles(String name);

    /**
     * 查询角色权限
     */
    Set<String> findPermissionByRole(int rolesId);

    /**
     * 增加角色权限
     */
    void savePermission(int rolesId, int permissinId);

    /**
     * 删除角色权限
     */
    void delPermission(int rolesId, int permissinId);
}