package org.nessary.project.facade.admin.dev.Response;

/**
 * Created by 97947 on 2017/2/22.
 */
public class PermissionResponse {
    private Integer id; //id

    private String uuid; //伪Id

    private String permissionName;  //权限描述

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
