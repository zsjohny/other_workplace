package org.nessary.project.facade.admin.dev.entity;

import org.nessary.project.utils.annotion.table.Table;

/**
 * Created by Ness on 2017/2/18.
 */
//@Table("t_test")
public class Test {

}
