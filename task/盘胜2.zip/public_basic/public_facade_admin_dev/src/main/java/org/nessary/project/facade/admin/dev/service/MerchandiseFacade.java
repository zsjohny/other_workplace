package org.nessary.project.facade.admin.dev.service;

import org.nessary.project.facade.admin.dev.entity.Merchandise;

import java.util.List;

/**
 * Created by Ness on 2017/2/10.
 */
public interface MerchandiseFacade {
    List<Merchandise> findAll();
}
