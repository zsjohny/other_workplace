package org.nessary.project.facade.admin.dev.entity;

/**
 * Created by 97947 on 2017/2/20.
 */

import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.operate.DbHandler;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 管理员权限表
 */
@Table("t_permission")
public class Permission implements Serializable{
    /**
     * 用户自增Id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(commit = "伪Id")
    private String uuid;

    @Column(commit = "删除理由描述")
    private String descriptions;

    @Column(commit = "创建时间",dateGeneStrategy = DbHandler.DateGeneStrategy.CREATE)
    private Timestamp createTime;

    @Column(commit = "最后修改时间",dateGeneStrategy = DbHandler.DateGeneStrategy.UPDATE)
    private Timestamp gmtModifiedTime;

    @Column(commit = "权限名称")
    private String permissionName;

    @Column(commit = "是否删除,是 true ，否 false")
    private Boolean deleted;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getGmtModifiedTime() {
        return gmtModifiedTime;
    }

    public void setGmtModifiedTime(Timestamp gmtModifiedTime) {
        this.gmtModifiedTime = gmtModifiedTime;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }
}
