package org.nessary.project.service.user.proxy;

import org.nessary.project.facade.user.entity.Merchandise;
import org.nessary.project.service.user.mapper.MerchandiseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 商家服务的代理层
 * Created by Ness on 2017/2/10.
 */
@Component
@Transactional
public class MerchandiseProxy {
    @Autowired
    private MerchandiseMapper merchandiseMapper;

    public List<Merchandise> findAll() {
        return merchandiseMapper.findAll();
    }

    public MerchandiseMapper getMerchandiseMapper() {
        return merchandiseMapper;
    }

    public void setMerchandiseMapper(MerchandiseMapper merchandiseMapper) {
        this.merchandiseMapper = merchandiseMapper;
    }
}
