package org.nessary.project.service.user.proxy;

import org.nessary.project.facade.user.entity.User;
import org.nessary.project.service.user.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 用户的服务代理层
 * Created by Ness on 2017/2/8.
 */
@Component
@Transactional
public class UserProxy {
    @Autowired
    UserMapper userMapper;

    /**
     * 进行保存User
     *
     * @param user user实体类
     */
    public void saveUser(User user) {
        userMapper.saveUser(user);
    }


    /**
     * 查找所有的 user
     *
     * @param deleted 是否删除 true 是 false 不是
     * @return
     */
    public List<User> findUserAllByDeleted(Boolean deleted) {
        //目前用不到
        System.out.println(userMapper.findUserAllByDeleted().size());
        return userMapper.findUserAllByDeleted();
    }

}
