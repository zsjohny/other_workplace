package org.nessary.project.service.user.facade;

import com.alibaba.dubbo.config.annotation.Service;
import org.nessary.project.facade.user.entity.User;
import org.nessary.project.facade.user.service.UserFacade;
import org.nessary.project.service.user.proxy.UserProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 用户的服务实现层
 * Created by Ness on 2017/2/8.
 */
@Component
@Service
public class UserFacadeImpl implements UserFacade {
    @Autowired
    UserProxy userProxy;

    /**
     * 进行保存User
     *
     * @param user user实体类
     */
    @Override
    public void saveUser(User user) {
        userProxy.saveUser(user);
    }


    /**
     * 查找所有的 user
     *
     * @param deleted 是否删除 true 是 false 不是
     * @return
     */
    @Override
    public List<User> findUserAllByDeleted(Boolean deleted) {

        return userProxy.findUserAllByDeleted(deleted);
    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:service/user/app_root.xml");
        UserFacade userFacadeImpl = context.getBean("userFacadeImpl", UserFacade.class);
        System.out.println(userFacadeImpl.findUserAllByDeleted(false).size());
    }

}
