package org.nessary.project.service.user.facade;

import com.alibaba.dubbo.config.annotation.Service;
import org.nessary.project.facade.user.entity.Merchandise;
import org.nessary.project.facade.user.service.MerchandiseFacade;
import org.nessary.project.service.user.proxy.MerchandiseProxy;
import org.nessary.project.utils.conver.DataConverUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Ness on 2017/2/10.
 */
@Component
@Service
public class MerchandiseFacadeImpl implements MerchandiseFacade {
    @Autowired
    private MerchandiseProxy merchandiseMapper;

    @Override
    public List<Merchandise> findAll() {
        return merchandiseMapper.findAll();
    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:service/user/app_root.xml");
        MerchandiseFacade test = context.getBean("merchandiseFacadeImpl", MerchandiseFacade.class);
        List<Merchandise> all = test.findAll();
        for (Merchandise s : all) {
            String[] strings = DataConverUtils.byteArr2StringArr(s.getHeadPics());
            System.out.println(strings[0]);
        }
    }


}
