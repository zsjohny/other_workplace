package org.nessary.project.service.user.mapper;

import org.nessary.project.facade.user.entity.Merchandise;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Ness on 2017/2/10.
 */


public interface MerchandiseMapper {
    List<Merchandise> findAll();
}
