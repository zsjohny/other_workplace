package org.nessary.project.service.user.mapper;

import org.nessary.project.facade.user.entity.User;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface UserMapper {

    List<User> findUserAllByDeleted();

    void saveUser(User user);

}