package org.nessary.project.service.user.proxy;

import org.nessary.project.facade.user.entity.Users;
import org.nessary.project.service.user.mapper.UsersMapper;
import org.nessary.project.utils.Regular.Regular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * users权限类的代理层
 * Created by Ness on 2017/2/18.
 */
@Component
@Transactional
public class UsersProxy {
    @Autowired
    private UsersMapper usersMapper;


    /**
     * 存储Users的实体类
     *
     * @param users users的对象
     */
    public void saveUsers(Users users) {
        if (users == null) {
            return;
        }

        usersMapper.saveUsers(users);
        String str = null;
        str.isEmpty();

    }

    /**
     * 通过姓名查找 user用户
     *
     * @param userName 用户姓名
     * @return
     */
    public Users findUsersByUserName(String userName) {
        if (Regular.checkEmpty(userName, null)) {
            return null;
        }

        return usersMapper.findUsersByUserName(userName);
    }

    /**
     * 根据用户名检测是否存在
     *
     * @param userName 用户名
     * @return
     */
    public Boolean checkUsersExistByUsersName(String userName) {
        if (Regular.checkEmpty(userName, null)) {
            return false;
        }
        int count = usersMapper.checkUsersExistByUsersName(userName);
        return count == 0;
    }


}
