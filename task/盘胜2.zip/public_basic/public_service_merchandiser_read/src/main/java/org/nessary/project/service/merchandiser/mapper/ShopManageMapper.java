package org.nessary.project.service.merchandiser.mapper;

public interface ShopManageMapper {
	
	
}
