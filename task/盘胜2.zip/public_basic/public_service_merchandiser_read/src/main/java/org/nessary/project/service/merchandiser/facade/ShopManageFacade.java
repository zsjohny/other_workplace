package org.nessary.project.service.merchandiser.facade;

public class ShopManageFacade {

}
