package org.nessary.project.admin.dev.biz;

/**
 * Created by 97947 on 2017/2/22.
 */

import org.nessary.project.utils.operate.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * 权限管理
 */
public interface PermissionBiz {

    Response findAllPermission(HttpServletRequest request);

    Response findPermissionById(HttpServletRequest request,Integer id);

    Response addPermission(HttpServletRequest request,String permissionName);

    Response deletePermission(HttpServletRequest request,String permissionName,String descriptions);

    Response updatePermission(HttpServletRequest request,String permissionName);
}
