package org.nessary.project.admin.dev.biz.impl;

import org.nessary.project.admin.dev.biz.PermissionBiz;
import org.nessary.project.facade.admin.dev.Response.PermissionResponse;
import org.nessary.project.facade.admin.dev.entity.Permission;
import org.nessary.project.facade.admin.dev.service.PermissionFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by 97947 on 2017/2/22.
 */

/**
 *
 */
@Component
public class PermissionBizImpl implements PermissionBiz{
    private Logger logger = LoggerFactory.getLogger(PermissionBizImpl.class);

    @Autowired
    PermissionFacade facade;


    @Override
    public Response findAllPermission(HttpServletRequest request) {
        if (request == null){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        List<Permission> responses = facade.findAllPermission();
        return Response.success(responses);
    }

    @Override
    public Response findPermissionById(HttpServletRequest request,Integer id) {
        if (request==null || Regular.checkEmpty(id,null)){
            logger.info("id为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        Permission permission = facade.findPermissionById(id);
        return Response.success(permission);
    }

    @Override
    public Response addPermission(HttpServletRequest request, String permissionName) {
        if (request == null || Regular.checkEmpty(permissionName,null)){
            logger.info("权限名称为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        facade.addPermission(permissionName);
        return Response.success();
    }

    @Override
    public Response deletePermission(HttpServletRequest request, String permissionName,String descriptions) {
        if (request == null || Regular.checkEmpty(permissionName,null) ||Regular.checkEmpty(descriptions,null)){
            logger.info("权限名称为空或者删除理由为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        facade.deletePermission(permissionName,descriptions);
        return Response.success();
    }

    @Override
    public Response updatePermission(HttpServletRequest request, String permissionName) {
        if (request == null || Regular.checkEmpty(permissionName,null)){
            Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        facade.updatePermission(permissionName);
        return Response.success();
    }
}
