package org.nessary.project.admin.dev.biz.impl;

import org.nessary.project.admin.dev.biz.JdbcConfigBiz;
import org.nessary.project.facade.admin.dev.entity.JdbcConfig;
import org.nessary.project.facade.admin.dev.service.JdbcConfigFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.jms.JmsSender;
import org.nessary.project.utils.operate.Response;
import org.nessary.project.utils.screct.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by 97947 on 2017/2/23.
 */
@Component
public class JdbcConfigBizImpl implements JdbcConfigBiz{

    @Autowired
    private JdbcConfigFacade jdbcConfigFacade;

    @Autowired
    private JmsSender jmsSender;


    @Override
    public Response findAllJdbcConfig(HttpServletRequest request) {
        List<JdbcConfig> list =jdbcConfigFacade.findAllJdbcConfig();
        return Response.success(list);
    }

    @Override
    public Response findJdbcById(HttpServletRequest request, Integer id) {
        if (request == null || Regular.checkEmpty(id,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        JdbcConfig jdbcConfig = jdbcConfigFacade.findJdbcById(id);
        return Response.success(jdbcConfig);
    }

    @Override
    public Response addJdbc(HttpServletRequest request,String url,String initUrl,String user,String pass,Integer initSize,Integer maxSize,Integer minSize,Integer waitTime,Integer checkTime,Integer minInitTime) {
        if (request == null || Regular.checkEmpty(url,null)||Regular.checkEmpty(initUrl,null)||Regular.checkEmpty(user,null)||Regular.checkEmpty(pass,null)||Regular.checkEmpty(initSize,null)||Regular.checkEmpty(maxSize,null)||Regular.checkEmpty(minSize,null)||Regular.checkEmpty(waitTime,null)||Regular.checkEmpty(checkTime,null)||Regular.checkEmpty(minInitTime,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        String uuid = UserUtils.generateUUid();
        jdbcConfigFacade.addJdbc(uuid,url,initUrl,user,pass,initSize,maxSize,minSize,waitTime,checkTime,minInitTime);
        return Response.success();
    }

    @Override
    public Response deleteJdbc(HttpServletRequest request, Integer id, Boolean deleted) {
        if (request == null || Regular.checkEmpty(deleted,null) ||Regular.checkEmpty(id,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("deleted",deleted);


        jdbcConfigFacade.deleteJdbc(id,deleted);
        return Response.success();
    }

    @Override
    public Response updateUrl(HttpServletRequest request, Integer id, String url) {
        if (request == null || Regular.checkEmpty(id,null)||Regular.checkEmpty(url,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("url",url);

        jdbcConfigFacade.updateUrl(id,url);
        return Response.success();
    }

    @Override
    public Response updateInitUrl(HttpServletRequest request, Integer id, String initUrl) {
        if (request == null ||Regular.checkEmpty(id,null)||Regular.checkEmpty(initUrl,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("initUrl",initUrl);

        jdbcConfigFacade.updateInitUrl(id,initUrl);
        return Response.success();
    }

    @Override
    public Response updateUser(HttpServletRequest request, Integer id, String user) {

        if (request==null||Regular.checkEmpty(id,null)||Regular.checkEmpty(user,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("user",user);

        jdbcConfigFacade.updateUser(id,user);

        return Response.success();
    }

    @Override
    public Response updatePass(HttpServletRequest request, Integer id, String pass) {

        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(pass,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("pass",pass);

        jdbcConfigFacade.updatePass(id,pass);
        return Response.success();
    }

    @Override
    public Response updateInitSize(HttpServletRequest request, Integer id, Integer initSize) {
        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(initSize,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("initSize",initSize);

        jdbcConfigFacade.updateInitSize(id,initSize);
        return Response.success();
    }

    @Override
    public Response updateMaxSize(HttpServletRequest request, Integer id, Integer maxSize) {
        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(maxSize,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("maxiSize",maxSize);

        jdbcConfigFacade.updateMaxSize(id,maxSize);
        return Response.success();
    }

    @Override
    public Response updateMinSize(HttpServletRequest request, Integer id, Integer minSize) {
        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(minSize,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("minSize",minSize);

        jdbcConfigFacade.updateMinSize(id,minSize);
        return Response.success();
    }

    @Override
    public Response updateWaitTime(HttpServletRequest request, Integer id, Integer waitTime) {
        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(waitTime,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("waitTime",waitTime);

        jdbcConfigFacade.updateWaitTime(id,waitTime);
        return Response.success();
    }

    @Override
    public Response updateCheckTime(HttpServletRequest request, Integer id, Integer checkTime) {
        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(checkTime,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("checkTime",checkTime);

        jdbcConfigFacade.updateCheckTime(id,checkTime);
        return Response.success();
    }

    @Override
    public Response updateMinInitTime(HttpServletRequest request, Integer id, Integer minInitTime) {
        if (request== null||Regular.checkEmpty(id,null)||Regular.checkEmpty(minInitTime,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsSender.sendMapMsg("minInitTime",minInitTime);

        jdbcConfigFacade.updateMinInitTime(id,minInitTime);
        return Response.success();
    }
}
