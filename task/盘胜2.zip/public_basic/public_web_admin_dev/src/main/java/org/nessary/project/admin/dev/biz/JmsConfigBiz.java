package org.nessary.project.admin.dev.biz;

import org.nessary.project.utils.operate.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Huang Yangfeng on 2017/2/25.
 */
public interface JmsConfigBiz {
    Response findAllJms(HttpServletRequest request);

    Response findJmsById(HttpServletRequest request,Integer id);

    Response addJms(HttpServletRequest request,String url,String name,String pass,String scheduleAcceptTask,String scheduleEndTask);

    Response delete(HttpServletRequest request,Integer id ,Boolean deleted);

    Response updateUrl(HttpServletRequest request,Integer id,String url);

    Response updateName(HttpServletRequest request,Integer id,String name);

    Response updatePass(HttpServletRequest request,Integer id,String pass);

    Response updateScheduleAcceptTask(HttpServletRequest request,Integer id,String secheduleAcceptTask);

    Response updateScheduleEndTask(HttpServletRequest request,Integer id , String scheduleEndTask);
}
