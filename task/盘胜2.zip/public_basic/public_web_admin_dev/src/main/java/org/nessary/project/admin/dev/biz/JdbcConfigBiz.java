package org.nessary.project.admin.dev.biz;

import org.nessary.project.utils.operate.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 97947 on 2017/2/23.
 */
public interface JdbcConfigBiz {

    Response findAllJdbcConfig(HttpServletRequest request);

    Response findJdbcById(HttpServletRequest request,Integer id);

    Response addJdbc(HttpServletRequest request,String url,String initUrl,String user,String pass,Integer initSize,Integer maxSize,Integer minSize,Integer waitTime,Integer checkTime,Integer minInitTime);

    Response deleteJdbc(HttpServletRequest request,Integer id,Boolean deleted);

    Response updateUrl(HttpServletRequest request,Integer id,String url);

    Response updateInitUrl(HttpServletRequest request,Integer id,String initUrl);

    Response updateUser(HttpServletRequest request,Integer id,String user);

    Response updatePass(HttpServletRequest request,Integer id,String pass);

    Response updateInitSize(HttpServletRequest request,Integer id,Integer initSize);

    Response updateMaxSize(HttpServletRequest request,Integer id,Integer maxSize);

    Response updateMinSize(HttpServletRequest request,Integer id,Integer minSize);

    Response updateWaitTime(HttpServletRequest request,Integer id,Integer waitTime);

    Response updateCheckTime(HttpServletRequest request,Integer id,Integer checkTime);

    Response updateMinInitTime(HttpServletRequest request ,Integer id,Integer minInitTime);
}
