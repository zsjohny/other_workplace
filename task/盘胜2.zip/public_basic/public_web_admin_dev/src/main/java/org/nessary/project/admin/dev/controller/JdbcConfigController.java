package org.nessary.project.admin.dev.controller;

import com.sun.org.apache.regexp.internal.RE;
import org.nessary.project.admin.dev.biz.JdbcConfigBiz;
import org.nessary.project.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 97947 on 2017/2/23.
 */

/**
 * 数据库配置
 */
@RestController
@RequestMapping(value = "jdbc",produces = "application/JSON,charset=UTF-8")
public class JdbcConfigController {

    @Autowired
    JdbcConfigBiz jdbcConfigBiz;

    /**
     * 查询所有数据库配置
     * @param request
     * @return
     */
    @RequestMapping(value = "all",method = RequestMethod.GET)
    public Response findAllJdbcConfig(HttpServletRequest request){
        return jdbcConfigBiz.findAllJdbcConfig(request);
    }


    @RequestMapping(value = "jdbc",method = RequestMethod.POST)
    public Response findJdbcById(HttpServletRequest request,Integer id){
        return jdbcConfigBiz.findJdbcById(request,id);
    }

    /**
     * 添加完整的数据库配置
     * @param request
     * @param url 数据库链接
     * @param initUrl 初始化链接
     * @param user 用户名
     * @param pass 密码
     * @param initSize 初始化大小
     * @param maxSize 配置初始化最大连接数
     * @param minSize 最小连接数
     * @param waitTime 等待时间
     * @param checkTime 每隔多久检测一次
     * @param minInitTime 最小生产时间
     * @return
     */
    @RequestMapping(value = "add",method = RequestMethod.POST)
    public Response addJdbc(HttpServletRequest request,String url,String initUrl,String user,String pass,Integer initSize,Integer maxSize,Integer minSize,Integer waitTime,Integer checkTime,Integer minInitTime){
        return jdbcConfigBiz.addJdbc(request,url,initUrl,user,pass,initSize,maxSize,minSize,waitTime,checkTime,minInitTime);
    }

    /**
     * 根据Id删除
     * @param request
     * @param deleted
     * @return
     */
    @RequestMapping(value = "delete",method = RequestMethod.POST)
    public Response deleteJdbc(HttpServletRequest request,Integer id,Boolean deleted){
        return jdbcConfigBiz.deleteJdbc(request,id,deleted);
    }

    /**
     * 更新 url
     * @param request
     * @param id
     * @param url
     * @return
     */
    @RequestMapping(value = "update_url",method = RequestMethod.POST)
    public Response updateUrl(HttpServletRequest request,Integer id,String url){
        return jdbcConfigBiz.updateUrl(request,id,url);
    }

    /**
     * 更新initUrl
     * @param request
     * @param id
     * @param initUrl
     * @return
     */
    @RequestMapping(value = "update_init_url",method = RequestMethod.POST)
    public Response updateInitUrl(HttpServletRequest request,Integer id,String initUrl){
        return jdbcConfigBiz.updateInitUrl(request,id,initUrl);
    }

    /**
     * 更新数据库登录名
     * @param request
     * @param id
     * @param user
     * @return
     */
    @RequestMapping(value = "updateUser",method = RequestMethod.POST)
    public Response updateUser(HttpServletRequest request,Integer id,String user){
        return jdbcConfigBiz.updateUser(request,id,user);
    }

    /**
     * 更新数据库登录密码
     */
    @RequestMapping(value = "updatePass",method = RequestMethod.POST)
    public Response updatePass(HttpServletRequest request,Integer id,String pass){
        return jdbcConfigBiz.updatePass(request,id,pass);
    }

    /**
     * 更新 初始化链接 单位毫秒
     */
    @RequestMapping(value = "update_init_size",method = RequestMethod.POST)
    public Response updateInitSize(HttpServletRequest request,Integer id,Integer initSize){
        return jdbcConfigBiz.updateInitSize(request,id,initSize);
    }

    /**
     * 更新 初始化最大链接 单位毫秒
     */
    @RequestMapping(value = "update_max_size",method = RequestMethod.POST)
    public Response updateMaxSize(HttpServletRequest request,Integer id,Integer maxSize){
        return  jdbcConfigBiz.updateMaxSize(request,id,maxSize);
    }

    /**
     * 更新 初始化最小链接大小 单位毫秒
     */
    @RequestMapping(value = "update_min_size",method = RequestMethod.POST)
    public Response updateMinSize(HttpServletRequest request,Integer id,Integer minSize){
        return  jdbcConfigBiz.updateMinSize(request,id,minSize);
    }

    /**
     * 更新 等待时间 单位毫秒
     */
    @RequestMapping(value = "update_wait_time",method = RequestMethod.POST)
    public Response updateWaitTime(HttpServletRequest request,Integer id,Integer waitTime){
        return jdbcConfigBiz.updateWaitTime(request,id,waitTime);
    }

    /**
     *更新  每隔多久检测一次
     */
    @RequestMapping(value = "update_check_time",method = RequestMethod.POST)
    public Response updateCheckTime(HttpServletRequest request,Integer id,Integer checkTime){
        return  jdbcConfigBiz.updateCheckTime(request,id,checkTime);
    }

    /**
     * 更新最小生存时间
     */
    @RequestMapping(value = "update_min_init_time",method = RequestMethod.POST)
    public Response updateMinInitTime(HttpServletRequest request ,Integer id,Integer minInitTime){
        return jdbcConfigBiz.updateMinInitTime(request,id,minInitTime);
    }
}
