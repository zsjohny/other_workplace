package org.nessary.project.admin.dev.biz.impl;

import org.nessary.project.admin.dev.biz.JmsConfigBiz;
import org.nessary.project.facade.admin.dev.entity.JmsConfig;
import org.nessary.project.facade.admin.dev.service.JmsConfigFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.nessary.project.utils.screct.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by Huang Yangfeng on 2017/2/25.
 */
public class JmsConfigBizImpl implements JmsConfigBiz {

    @Autowired
    private JmsConfigFacade jmsConfigFacade;
    @Override
    public Response findAllJms(HttpServletRequest request) {
        List<JmsConfig> list =jmsConfigFacade.findAllJms();
        return Response.success(list);
    }

    @Override
    public Response findJmsById(HttpServletRequest request, Integer id) {
        if (request == null || Regular.checkEmpty(id,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        JmsConfig jmsConfig = jmsConfigFacade.findJmsById(id);
        return Response.success(jmsConfig);
    }

    @Override
    public Response addJms(HttpServletRequest request, String url, String name, String pass, String scheduleAcceptTask, String scheduleEndTask) {
        if (request == null||Regular.checkEmpty(url,null)||Regular.checkEmpty(name,null)||Regular.checkEmpty(pass,null)||Regular.checkEmpty(scheduleAcceptTask,null)||Regular.checkEmpty(scheduleEndTask,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        String uuid= UserUtils.generateUUid();
        jmsConfigFacade.addJms(uuid,url,name,pass,scheduleAcceptTask,scheduleEndTask);
        return Response.success();
    }

    @Override
    public Response delete(HttpServletRequest request, Integer id, Boolean deleted) {
        if (request == null|| Regular.checkEmpty(id,null)||Regular.checkEmpty(deleted,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsConfigFacade.delete(id,deleted);
        return Response.success();
    }

    @Override
    public Response updateUrl(HttpServletRequest request, Integer id, String url) {
        if (request == null|| Regular.checkEmpty(id,null)||Regular.checkEmpty(url,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsConfigFacade.updateUrl(id,url);
        return Response.success();
    }

    @Override
    public Response updateName(HttpServletRequest request, Integer id, String name) {
        if (request == null|| Regular.checkEmpty(id,null)||Regular.checkEmpty(name,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsConfigFacade.updateName(id,name);
        return Response.success();
    }

    @Override
    public Response updatePass(HttpServletRequest request, Integer id, String pass) {
        if (request == null|| Regular.checkEmpty(id,null)||Regular.checkEmpty(pass,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsConfigFacade.updatePass(id,pass);
        return Response.success();
    }

    @Override
    public Response updateScheduleAcceptTask(HttpServletRequest request, Integer id, String secheduleAcceptTask) {
        if (request == null|| Regular.checkEmpty(id,null)||Regular.checkEmpty(secheduleAcceptTask,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsConfigFacade.updateScheduleAcceptTask(id,secheduleAcceptTask);
        return Response.success();
    }

    @Override
    public Response updateScheduleEndTask(HttpServletRequest request, Integer id, String scheduleEndTask) {
        if (request == null|| Regular.checkEmpty(id,null)||Regular.checkEmpty(scheduleEndTask,null)){
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        jmsConfigFacade.updateScheduleEndTask(id,scheduleEndTask);
        return Response.success();
    }
}
