package org.nessary.project.admin.dev.controller;

import org.nessary.project.admin.dev.biz.JmsConfigBiz;
import org.nessary.project.utils.operate.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Huang Yangfeng on 2017/2/25.
 */

@RestController
@RequestMapping(value = "jms",produces = "application/JSON,charset=UTF-8")
public class JmsConfigController {

    @Autowired
    private JmsConfigBiz jmsConfigBiz;

    @RequestMapping("/all")
    public Response findAllJms(HttpServletRequest request){
        return jmsConfigBiz.findAllJms(request);
    }
    @RequestMapping("/jms")
    public Response findJmsById(HttpServletRequest request,Integer id){
        return jmsConfigBiz.findJmsById(request,id);
    };
    @RequestMapping("/add")
    public Response addJms(HttpServletRequest request,String url,String name,String pass,String scheduleAcceptTask,String scheduleEndTask){
        return jmsConfigBiz.addJms(request,url,name,pass,scheduleAcceptTask,scheduleEndTask);
    };
    @RequestMapping("/delete")
    public Response delete(HttpServletRequest request,Integer id ,Boolean deleted){
        return jmsConfigBiz.delete(request,id,deleted);
    };
    @RequestMapping("/update_url")
    public Response updateUrl(HttpServletRequest request,Integer id,String url){
        return jmsConfigBiz.updateUrl(request,id,url);
    };
    @RequestMapping("/update_name")
    public Response updateName(HttpServletRequest request,Integer id,String name){
        return jmsConfigBiz.updateName(request,id,name);
    };
    @RequestMapping("/update_pass")
    public Response updatePass(HttpServletRequest request,Integer id,String pass){
        return jmsConfigBiz.updatePass(request,id,pass);
    };
    @RequestMapping("/update_accept")
    public Response updateScheduleAcceptTask(HttpServletRequest request,Integer id,String secheduleAcceptTask){
        return jmsConfigBiz.updateScheduleAcceptTask(request,id,secheduleAcceptTask);
    };
    @RequestMapping("/update_end")
    public Response updateScheduleEndTask(HttpServletRequest request,Integer id , String scheduleEndTask){
        return jmsConfigBiz.updateScheduleEndTask(request,id,scheduleEndTask);
    };

}
