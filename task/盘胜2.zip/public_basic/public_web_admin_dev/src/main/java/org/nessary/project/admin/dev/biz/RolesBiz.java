package org.nessary.project.admin.dev.biz;

import org.nessary.project.utils.operate.Response;
import sun.tools.jconsole.InternalDialog;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Administrator on 2017/2/24 0024.
 */
public interface RolesBiz {
    /**
     * 角色列表
     */
    Response rolesList(HttpServletRequest request, String userName);
    /**
     * 新增角色
     */
    Response addRoles(HttpServletRequest request, String userName, String rolesName);
    /**
     * 删除角色
     */
    Response delRoles(HttpServletRequest request, String userName, String rolesName);
    /**
     * 修改角色
     */
    Response changeRoles(HttpServletRequest request, String userName, String rolesName, int rolesId);
    /**
     * 角色权限增加
     */
    Response addPermission(HttpServletRequest request, String userName, int rolesId, int permissionId);
    /**
     * 角色权限删除
     */
    Response delPermission(HttpServletRequest request, String userName, int rolesId, int permissionId);
    /**
     * 角色权限查询
     */
    Response findPermission(HttpServletRequest request, String userName, int rolesId);
}
