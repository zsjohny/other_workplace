package org.nessary.project.admin.dev.controller;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import org.apache.shiro.authz.annotation.RequiresGuest;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.nessary.project.admin.dev.biz.UsersBiz;
import org.nessary.project.utils.code.RandomCodeUtil;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Created by Ness on 2017/2/19.
 */
@RestController
@RequestMapping("/users")
public class UsersController {
    /**
     * 日志文件
     */
    private Logger logger = LoggerFactory.getLogger(UsersController.class);

    @Autowired
    private UsersBiz usersBiz;


    /**
     * 用户登录
     *
     * @param request      请求
     * @param userName     用户名
     * @param userPassword 用户密码
     * @return
     */
    @RequestMapping("/login")
    public Response loadByUserName(HttpServletRequest request, String userName, String userPassword) {

//        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
//            logger.warn("Ip={},下的用户={},输入的 userPassword={} 某一个参数为空", request, userName, userPassword);
//            return Response.response(ResponseType.EMPTY_CODE.getCode());
//        }
        return usersBiz.loadByUserName(request, userName, userPassword);
    }

    /**
     * 注册
     */
    @RequestMapping("register")
    public Response register(HttpServletRequest request,String userName,String userPassword){
        return usersBiz.register(request,userName,userPassword);
    }
    /**
     * 获取验证码
     * @param req
     * @param resp
     * @throws IOException
     */
    @RequestMapping("/code")
    public void getCode(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        RandomCodeUtil rdnu = RandomCodeUtil.Instance();
        // 取得随机字符串放入Session中
        HttpSession session = req.getSession();
        session.setAttribute("RANDOMCODE", rdnu.getString());
        // 禁止图像缓存。
        resp.setHeader("Pragma", "no-cache");
        resp.setHeader("Cache-Control", "no-cache");
        resp.setDateHeader("Expires", 0);

        resp.setContentType("image/jpeg");

        // 将图像输出到Servlet输出流中。
//        ServletOutputStream sos = resp.getOutputStream();
        //将图片转换为base64输出
        ByteArrayOutputStream sos = new ByteArrayOutputStream();
        ImageIO.write(rdnu.getBuffImg(), "jpeg", sos);
        byte[] bytes = sos.toByteArray();
        String base64bytes = Base64.encode(bytes);
        String src = "data:image/png;base64," + base64bytes;
        resp.getWriter().println(src);
        sos.close();
    }

    /**
     * 用户退出
     * @param request
     * @return
     */
    @RequestMapping("/logout")
    public Response logout(HttpServletRequest request){
        return usersBiz.logout(request);
    }

    @RequiresRoles("test")
    @RequestMapping("/test")
    public Response testByAnnotation() {
        return Response.success();
    }

    @RequiresPermissions({"user1.*"})
    @RequestMapping("/test2")
    public Response tes2tByAnnotation() {
        return Response.success();
    }

    @RequiresUser
    @RequestMapping("/test3")
    public Response tes3tByAnnotation(String userName) {
        return Response.success();
    }

    @RequiresGuest
    @RequestMapping("/test4")
    public Response tes34tByAnnotation( ){
        return Response.success();
    }



}
