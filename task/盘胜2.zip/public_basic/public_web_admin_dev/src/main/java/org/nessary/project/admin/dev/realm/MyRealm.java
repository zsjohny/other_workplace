package org.nessary.project.admin.dev.realm;


import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.nessary.project.facade.admin.dev.entity.Users;
import org.nessary.project.facade.admin.dev.service.UsersFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.cache.CacheTemplete;
import org.nessary.project.utils.jms.JmsSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * 自定义的realm实现
 * Created by Ness on 2017/2/15.
 */
public class MyRealm extends AuthorizingRealm {

    private Logger logger = LoggerFactory.getLogger(MyRealm.class);

    @Autowired
    private UsersFacade usersFacade;

    @Autowired
    private CacheTemplete cacheTemplete;

    private final String USER_KEY = "admin.dev";

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        String userName = (String) principalCollection.getPrimaryPrincipal();
        System.out.println(principalCollection.getRealmNames());
        System.out.println(userName);
        logger.info("用户{} 开始进行授权", userName);
        Users user = getUserByUserName(userName);
        SimpleAuthorizationInfo authorizationInfo = null;
        if (user != null) {
            authorizationInfo = new SimpleAuthorizationInfo();
            Set<String> set = usersFacade.findPermissionByName(user.getUserName());
            authorizationInfo.addStringPermissions(set);
            authorizationInfo.addRole(usersFacade.findRolesByName(user.getUserName()));
        }

        logger.info("用户{} 结束进行授权", userName);

        return authorizationInfo;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {

        String userName = (String) authenticationToken.getPrincipal();

        //仅一次登录有效
        DefaultWebSecurityManager securityManager = (DefaultWebSecurityManager)SecurityUtils.getSecurityManager();
        DefaultWebSessionManager sessionManager = (DefaultWebSessionManager)securityManager.getSessionManager();
        Collection<Session> sessions = sessionManager.getSessionDAO().getActiveSessions();//获取当前已登录的用户session列表
        for(Session session:sessions){
            //清除该用户以前登录时保存的session
            if(userName.equals(String.valueOf(session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY)))){
                //调用socket完成
                Thread thread = new Thread(){
                    @Override
                    public void run(){
                        JmsSender jmsSender = new JmsSender();
                        jmsSender.sendMsg("url");
                    }
                };
                thread.start();
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //清除
                sessionManager.getSessionDAO().delete(session);
            }
        }


        logger.info("用户{} 开始进行校验登录", userName);
        Users user = getUserByUserName(userName);
        AuthenticationInfo authenticationInfo = null;
        if (user != null) {
            authenticationInfo = new SimpleAuthenticationInfo(user.getUserName(), user.getUserPassword(),getName());
        }
        logger.info("用户{} 结束进行校验登录", userName);
        return authenticationInfo;
    }


    /**
     * 根据用户名获取用户权限
     *
     * @param userName 用户名
     * @return
     */
    private Users getUserByUserName(String userName) {
        Users users = null;
        if (Regular.checkEmpty(userName, null)) {
            return users;
        }
        String key = USER_KEY + userName;
        //缓存到本地
        Object object = cacheTemplete.getCacheForSerialize(key);
        if (object == null) {
            users = usersFacade.findUsersByUserName(userName);
            if (users != null) {
                cacheTemplete.setCacheForSerialize(key, users);
            }

        } else {
            users = (Users) object;
        }
        return users;
    }


}
