package org.nessary.project.admin.dev.controller;

import org.nessary.project.admin.dev.biz.PermissionBiz;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;


/**
 * Created by 97947 on 2017/2/22.
 */

/**
 * 权限管理
 */
@RestController
@RequestMapping(value = "permission",produces = "application/JSON,charset=UTF-8")
public class PermissionController {

    @Autowired
    PermissionBiz permissionBiz;

    private Logger logger = LoggerFactory.getLogger(PermissionController.class);
    /**
     * 查询所有权限
     */
    @RequestMapping(value = "find_all",method = RequestMethod.GET)
    public Response findAllPermission(HttpServletRequest request){
        return permissionBiz.findAllPermission(request);
    }

    /**
     *根据权限id查询
     */
    @RequestMapping(value = "find_id",method = RequestMethod.POST)
    public Response findPermissionById(HttpServletRequest request,Integer id){

        return permissionBiz.findPermissionById(request,id);
    }

    /**
     * 添加权限
     */
    @RequestMapping(value = "add",method = RequestMethod.POST)
    public Response addPermission(HttpServletRequest request,String permissionName){
        return permissionBiz.addPermission(request,permissionName);
    }

    /**
     * 删除权限
     */
    @RequestMapping(value = "delete",method = RequestMethod.POST)
    public Response deletePermission(HttpServletRequest request,String permissionName,String descriptions){
        return permissionBiz.deletePermission(request,permissionName,descriptions);
    }

    /**
     * 修改权限
     */
    @RequestMapping(value = "update",method = RequestMethod.POST)
    public Response updatePermission(HttpServletRequest request,String permissionName){
        return permissionBiz.updatePermission(request,permissionName);
    }
}
