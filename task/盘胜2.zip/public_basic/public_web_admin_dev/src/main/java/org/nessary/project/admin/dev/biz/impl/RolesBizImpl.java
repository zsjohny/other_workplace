package org.nessary.project.admin.dev.biz.impl;

import org.nessary.project.admin.dev.biz.RolesBiz;
import org.nessary.project.facade.admin.dev.service.RolesFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Administrator on 2017/2/24 0024.
 */
@Component
public class RolesBizImpl implements RolesBiz{
    /**
     * 日志文件
     */
    private Logger logger = LoggerFactory.getLogger(UsersBizImpl.class);
    @Autowired
    private RolesFacade rolesFacade;
    /**
     * 角色列表
     */
    public Response rolesList(HttpServletRequest request, String userName){
        if (request == null || Regular.checkEmpty(userName, null)) {
            logger.warn("Ip={},下的用户={}, 某一个参数为空", request, userName);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
       return Response.success(rolesFacade.listRoles());
    }
    /**
     * 新增角色
     */
    public Response addRoles(HttpServletRequest request, String userName, String rolesName){
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(rolesName, null)) {
            logger.warn("Ip={},下的用户={},新增角色={}", request, userName, rolesName);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        rolesFacade.saveRoles(rolesName);
        return null;
    }
    /**
     * 删除角色
     */
    public Response delRoles(HttpServletRequest request, String userName, String rolesName){
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(rolesName, null)) {
            logger.warn("Ip={},下的用户={},删除角色={}", request, userName, rolesName);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        rolesFacade.delRoles(rolesName);
        return null;
    }
    /**
     * 修改角色
     */
    public Response changeRoles(HttpServletRequest request, String userName, String rolesName,int rolesId){
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(rolesName, null)|| Regular.checkEmpty(rolesId, null)) {
            logger.warn("Ip={},下的用户={},修改角色={}", request, userName, rolesName);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        rolesFacade.changeRoles(rolesName,rolesId);
        return null;
    }
    /**
     * 角色权限增加
     */
    public Response addPermission(HttpServletRequest request, String userName,int rolesId,int permissionId){
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(rolesId, null)|| Regular.checkEmpty(permissionId, null)) {
            logger.warn("Ip={},下的用户={},为角色={}增加权限={}", request, userName, rolesId,permissionId);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        rolesFacade.savePermission(rolesId,permissionId);
        return null;
    }
    /**
     * 角色权限删除
     */
    public Response delPermission(HttpServletRequest request, String userName,int rolesId,int permissionId){
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(rolesId, null)|| Regular.checkEmpty(permissionId, null)) {
            logger.warn("Ip={},下的用户={},删除角色={}权限={}", request, userName, rolesId,permissionId);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        rolesFacade.delPermission(rolesId,permissionId);
        return null;
    }
    /**
     * 角色权限查询
     */
    public Response findPermission(HttpServletRequest request, String userName,int rolesId){
        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(rolesId, null)) {
            logger.warn("Ip={},下的用户={},查询角色={}权限", request, userName, rolesId);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        return Response.success(rolesFacade.findPermissionByRole(rolesId));
    }
}
