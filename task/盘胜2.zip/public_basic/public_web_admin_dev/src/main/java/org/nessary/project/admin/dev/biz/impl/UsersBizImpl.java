package org.nessary.project.admin.dev.biz.impl;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.nessary.project.admin.dev.biz.UsersBiz;
import org.nessary.project.admin.dev.utils.MD5;
import org.nessary.project.facade.admin.dev.service.UsersFacade;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.cache.CacheTemplete;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.nessary.project.utils.screct.RsaUtils;
import org.nessary.project.utils.screct.UserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * 权限的用户业务处理层实现层
 * <p>
 * Created by Ness on 2017/2/19.
 */
@Component
public class UsersBizImpl implements UsersBiz {

    @Autowired
    CacheTemplete cacheTemplete;


    @Autowired
    private UsersFacade usersFacade;
    /**
     * 日志文件
     */
    private Logger logger = LoggerFactory.getLogger(UsersBizImpl.class);


    private final String USER_KEY = "admin.dev";
    /**
     * 用户登录
     *
     * @param request      请求
     * @param userName     用户名
     * @param userPassword 用户密码
     * @return
     */
    @Override
    public Response loadByUserName(HttpServletRequest request, String userName, String userPassword) {

        if (request == null || Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
            logger.warn("Ip={},下的用户={},输入的 userPassword={} ,验证码 code={} 某一个参数为空", request, userName, userPassword);
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }

//        logger.info("ip={}下的用户={},开始进行登录", Iptools.gainRealIp(request), userName);

//        Subject subject = registerLogin(userName, userPassword);
//        Boolean xxxx = checkPermissionBySubject("xxxx", subject);
//        System.out.println("xxxx"+xxxx);
//        Boolean ss = checkPermissionBySubject("user.*", subject);
//        System.out.println("user.*:"+ss);

//        logger.info("ip={}下的用户={},结束进行登录", Iptools.gainRealIp(request), userName);
        return Response.success();
    }

    @Override
    public Response register(HttpServletRequest request, String userName, String userPassword) {
        if (request == null||Regular.checkEmpty(userName,null) || Regular.checkEmpty(userPassword,null)){
            logger.warn("用户名或密码为空");
            return Response.response(ResponseType.EMPTY_CODE.getCode());
        }
        userName = RsaUtils.decrypt("key",userName);
        userPassword = RsaUtils.decrypt("key",userPassword);
        userPassword = String.format("%s#%s", userName,userPassword);
        userPassword = MD5.encryption(userPassword);

        String uuid = UserUtils.generateUUid();
        usersFacade.register(uuid,userName,userPassword);


        return Response.success();
    }

    /**
     * 退出
     * @param request
     * @return
     */
    @Override
    public Response logout(HttpServletRequest request) {
       Subject subject = SecurityUtils.getSubject();

       if (subject == null){
           Response.error("该退出的用户不存在");
       }

       SecurityUtils.getSubject().logout();
       return Response.success();

    }


    /**
     * 根据用户名和密码检测当前登录的权限
     *
     * @param userPermission 权限名称
     * @param subject        当前用户
     * @return
     */
    public Boolean checkPermissionBySubject(String userPermission, Subject subject) {
        Boolean flag = false;
        if (Regular.checkEmpty(userPermission, null) || subject == null) {
            return flag;
        }
        flag = subject.isPermitted(userPermission);
        return flag;
    }



    /**
     * 根据用户名和密码注册登录
     *
     * @param userName     用户名
     * @param userPassword 用户密码
     */
    public Subject registerLogin(String userName, String userPassword) {
        Subject subject = SecurityUtils.getSubject();
        if (Regular.checkEmpty(userName, null) || Regular.checkEmpty(userPassword, null)) {
            return subject;
        }

        UsernamePasswordToken token = new UsernamePasswordToken(userName, userPassword);
        subject.login(token);
        return subject;
    }

    /**
     * 根据当前用户获取session
     *
     * @param subject 当前用户
     * @return
     */
    public Session getSessionBySubject(Subject subject) {
        Session session = null;
        if (subject == null) {
            return session;
        }
        session = subject.getSession();
        return session;
    }


}
