package org.nessary.project.admin.dev.controller;

import org.apache.shiro.authz.annotation.RequiresGuest;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.nessary.project.admin.dev.biz.RolesBiz;
import org.nessary.project.admin.dev.biz.UsersBiz;
import org.nessary.project.utils.Regular.Regular;
import org.nessary.project.utils.enums.ResponseType;
import org.nessary.project.utils.operate.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Ness on 2017/2/19.
 */
@RestController
@RequestMapping("/roles")
public class RolesController {
    /**
     * 日志文件
     */
    private Logger logger = LoggerFactory.getLogger(RolesController.class);

    @Autowired
    private RolesBiz rolesBiz;

    @RequiresRoles("admin")
    @RequestMapping("/rolesList")
    public Response rolesList(HttpServletRequest request, String userName) {
        return rolesBiz.rolesList(request, userName);
    }

    @RequiresRoles("admin")
    @RequestMapping("/addRoles")
    public Response addRoles(HttpServletRequest request, String userName,String rolesName) {
        return rolesBiz.addRoles(request, userName,rolesName);
    }

    @RequiresRoles("admin")
    @RequestMapping("/delRoles")
    public Response delRoles(HttpServletRequest request, String userName,String rolesName) {
        return rolesBiz.delRoles(request, userName,rolesName);
    }
    @RequiresRoles("admin")
    @RequestMapping("/changeRoles")
    public Response changeRoles(HttpServletRequest request, String userName, String rolesName,int rolesId) {
        return rolesBiz.changeRoles(request, userName,rolesName,rolesId);
    }

    @RequiresRoles("admin")
    @RequestMapping("/addPermission")
    public Response addPermission(HttpServletRequest request, String userName,int rolesId,int permissionId) {
        return rolesBiz.addPermission(request, userName,rolesId,permissionId);
    }

    @RequiresRoles("admin")
    @RequestMapping("/delPermission")
    public Response delPermission(HttpServletRequest request, String userName,int rolesId,int permissionId) {
        return rolesBiz.delPermission(request, userName,rolesId,permissionId);
    }

    @RequiresRoles("admin")
    @RequestMapping("/findPermission")
    public Response findPermission(HttpServletRequest request, String userName,int rolesId) {
        return rolesBiz.findPermission(request, userName,rolesId);
    }
}
