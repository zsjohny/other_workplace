package org.nessary.project.facade.merchandiser.service;

import org.nessary.project.facade.merchandiser.entity.MerchandiserAudit;
import org.nessary.project.utils.operate.Response;

public interface ShopManageServer {
	
	Response AuditMessage(MerchandiserAudit merchandiseAudit);
	
}
