package org.nessary.project.facade.merchandiser.entity;

import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;

@Table("merchandiserAudit")
public class MerchandiserAudit {

	/**
	 * 自增Id
	 */
	@Id
	private Integer id;
	
	/**
	 * 用户的uuid
	 */
	@Column(commit="用户的uuid")
	private String userUuid;
	
	
	/**
	 * 自身的uuid
	 */
	@Column(commit="自身的uuid")
	private String uuid;
	
	/**
	 * 商店名称
	 */
	@Column(commit="商店名称")
	private String name;
	
	/**
	 * 联系人
	 */
	@Column(commit="联系人")
	private String linkman;
	
	/**
	 * 身份证号
	 */
	@Column(commit="身份证号")
	private String IDnumber;
	
	/**
	 * 省份证图（正面）
	 */
	@Column(commit="省份证图(正面)")
	private String provinceJPGJust;
	
	/**
	 * 省份证图（反面）
	 */
	@Column(commit="省份证图(反面)")
	private String provinceJPGAgainst;
	
	/**
	 * 身份证图（正面）
	 */
	@Column(commit="身份证图(正面)")
	private String IDnumberJPGJust;
	
	/**
	 * 地址
	 */
	@Column(commit="地址")
	private String site;
	
	/**
	 * 所在地区
	 */
	@Column(commit="所在地区")
	private String US;
	
	/**
	 * 详细地址
	 */
	@Column(commit="详细地址")
	private String address;
	
	/**
	 * 创建时间
	 */
	@Column(commit="创建时间")
	private String createTime;
	
	/**
	 * 修改时间
	 */
	@Column(commit="修改时间")
	private String modificationTime;
	
	/**
	 * 删除时间
	 */
	@Column(commit="删除时间")
	private String deletedTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLinkman() {
		return linkman;
	}

	public void setLinkman(String linkman) {
		this.linkman = linkman;
	}

	public String getIDnumber() {
		return IDnumber;
	}

	public void setIDnumber(String iDnumber) {
		IDnumber = iDnumber;
	}

	public String getProvinceJPGJust() {
		return provinceJPGJust;
	}

	public void setProvinceJPGJust(String provinceJPGJust) {
		this.provinceJPGJust = provinceJPGJust;
	}

	public String getProvinceJPGAgainst() {
		return provinceJPGAgainst;
	}

	public void setProvinceJPGAgainst(String provinceJPGAgainst) {
		this.provinceJPGAgainst = provinceJPGAgainst;
	}

	public String getIDnumberJPGJust() {
		return IDnumberJPGJust;
	}

	public void setIDnumberJPGJust(String iDnumberJPGJust) {
		IDnumberJPGJust = iDnumberJPGJust;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getUS() {
		return US;
	}

	public void setUS(String uS) {
		US = uS;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(String modificationTime) {
		this.modificationTime = modificationTime;
	}

	public String getDeletedTime() {
		return deletedTime;
	}

	public void setDeletedTime(String deletedTime) {
		this.deletedTime = deletedTime;
	}
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	
	
}
