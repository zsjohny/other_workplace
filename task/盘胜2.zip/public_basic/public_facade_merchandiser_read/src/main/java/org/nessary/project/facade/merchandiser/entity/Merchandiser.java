package org.nessary.project.facade.merchandiser.entity;

import java.io.Serializable;
import java.util.Date;

import org.nessary.project.utils.annotion.table.Column;
import org.nessary.project.utils.annotion.table.Id;
import org.nessary.project.utils.annotion.table.Table;
import org.nessary.project.utils.annotion.table.Transient;

/**
 * 商家
 * Created by Ness on 2016/12/16.
 */
@Table("merchandiser")
public class Merchandiser implements Serializable {
	
    private static final long serialVersionUID = 2372944851452709074L;
    @Id
    private Integer id;

    @Column(commit="商家的uuid")
    private String uuid;

    /**
     * 卖家头像
     */
    @Column(commit="卖家头像")
    private String headPic;


    /**
     * 卖家的名称
     */
    @Column(commit="卖家的名称")
    private String name;

    /**
     * 全部商品数量
     */
    @Column(commit="商品数量")
    private Integer merchTotalPro;

    /**
     * 全部浏览量
     */
    @Column(commit="全部浏览量")
    private Long merchTotalVIew;

    /**
     * 宝贝描述分数
     */
    @Column(commit="宝贝描述分数")
    private Double merchGoodsDesScore;

    /**
     * 卖家服务分数
     */
    @Column(commit="卖家服务分数")
    private Double merchSellerServScore;

    /**
     * 物流服务分数
     */
    @Column(commit="物流服务分数")
    private Double merchLogisServScore;

    /**
     * 拥有的评价数
     */
    @Column(commit="拥有的评价数")
    private Long merchHaveTotalRemark;

    /**
     * 拥有的好评数
     */
    @Column(commit="拥有的好评数")
    private Long merchReceivedSeveral;

    /**
     * 销售量
     */
    @Column(commit="销售量")
    private Long salesVolume;

    /**
     * 商家的手机号
     */
    @Column(commit="商家的手机号")
    private String phone;
    /**
     * 登陆时间
     */
    @Column(commit="登录时间")
    private Date loadTime;

    /**
     * 创建时间
     */
    @Column(commit="创建时间")
    private Date createTime;

    /**
     * 修改时间
     */
    @Column(commit="修改时间")
    private Date updateTime;


    /**
     * 是否删除 true是删除 false不是
     */
    @Column(commit="是否删除")
    private Boolean deleted;


    /**
     * 轮播图
     */
    @Column(commit="轮播图")
    private String carrouselJpg;
    /**
     * 粉丝量
     */
    @Column(commit="粉丝量")
    private Integer beanAmount;

    /**
     * 店家等级
     */
    @Column(commit="商店等级")
    private String merchandiserRank;

    /**
     * 关注
     */
    @Column(commit="关注")
    private Integer attention;

    /**
     * 收藏
     */
    @Column(commit="收藏")
    private Boolean collection;

    /**
     * 关联父类的ID
     */
    @Column(commit="关联父类Id")
    private byte[] fatherId;

    /**
     * 关联子类的ID
     */
    @Column(commit="关联子类Id")
    private byte[] sunId;
    
    /**
     * 关联的商品id
     */
    @Column(commit="关联商品id")
    private byte[] merchandiseId;
    
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getHeadPic() {
        return headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMerchTotalPro() {
        return merchTotalPro;
    }

    public void setMerchTotalPro(Integer merchTotalPro) {
        this.merchTotalPro = merchTotalPro;
    }

    public Long getMerchTotalVIew() {
        return merchTotalVIew;
    }

    public void setMerchTotalVIew(Long merchTotalVIew) {
        this.merchTotalVIew = merchTotalVIew;
    }

    public Double getMerchGoodsDesScore() {
        return merchGoodsDesScore;
    }

    public void setMerchGoodsDesScore(Double merchGoodsDesScore) {
        this.merchGoodsDesScore = merchGoodsDesScore;
    }

    public Double getMerchSellerServScore() {
        return merchSellerServScore;
    }

    public void setMerchSellerServScore(Double merchSellerServScore) {
        this.merchSellerServScore = merchSellerServScore;
    }

    public Double getMerchLogisServScore() {
        return merchLogisServScore;
    }

    public void setMerchLogisServScore(Double merchLogisServScore) {
        this.merchLogisServScore = merchLogisServScore;
    }

    public Long getMerchHaveTotalRemark() {
        return merchHaveTotalRemark;
    }

    public void setMerchHaveTotalRemark(Long merchHaveTotalRemark) {
        this.merchHaveTotalRemark = merchHaveTotalRemark;
    }

    public Long getMerchReceivedSeveral() {
        return merchReceivedSeveral;
    }

    public void setMerchReceivedSeveral(Long merchReceivedSeveral) {
        this.merchReceivedSeveral = merchReceivedSeveral;
    }

    public Long getSalesVolume() {
        return salesVolume;
    }

    public void setSalesVolume(Long salesVolume) {
        this.salesVolume = salesVolume;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Date getLoadTime() {
        return loadTime;
    }

    public void setLoadTime(Date loadTime) {
        this.loadTime = loadTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

	public String getCarrouselJpg() {
		return carrouselJpg;
	}

	public void setCarrouselJpg(String carrouselJpg) {
		this.carrouselJpg = carrouselJpg;
	}

	public Integer getBeanAmount() {
        return beanAmount;
    }

    public void setBeanAmount(Integer beanAmount) {
        this.beanAmount = beanAmount;
    }

    public String getMerchandiserRank() {
        return merchandiserRank;
    }

    public void setMerchandiserRank(String merchandiserRank) {
        this.merchandiserRank = merchandiserRank;
    }

    public Integer getAttention() {
        return attention;
    }

    public void setAttention(Integer attention) {
        this.attention = attention;
    }

    public Boolean getCollection() {
        return collection;
    }

    public void setCollection(Boolean collection) {
        this.collection = collection;
    }

    public byte[] getFatherId() {
        return fatherId;
    }

    public void setFatherId(byte[] fatherId) {
        this.fatherId = fatherId;
    }

    public byte[] getSunId() {
        return sunId;
    }

    public void setSunId(byte[] sunId) {
        this.sunId = sunId;
    }
    
    

    public byte[] getMerchandiseId() {
		return merchandiseId;
	}
    public void setMerchandiseId(byte[] merchandiseId){
		this.merchandiseId = merchandiseId;
	}

	public static long getSerialversionuid() {
        return serialVersionUID;
    }

	public Merchandiser() {
        super();
    }
    
    public Merchandiser(String uuid, String headPic, String name, Long merchReceivedSeveral) {
        super();
        this.uuid = uuid;
        this.headPic = headPic;
        this.name = name;
        this.merchReceivedSeveral = merchReceivedSeveral;
    }

	public Merchandiser(Integer id,String uuid){
		super();
		this.id = id;
		this.uuid = uuid;
	}

	public Merchandiser(Integer id, byte[] fatherId, byte[] sunId) {
		super();
		this.id = id;
		this.fatherId = fatherId;
		this.sunId = sunId;
	}
    
    

}
