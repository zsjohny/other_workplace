// package com.xiaoluo.service;
//
// import java.util.List;
//
// import com.xiaoluo.entity.Customer;
//
// public interface SSHService {
// void createCustomerByCusual(Customer customer);
//
// List<Customer> queryCustomer();
// }
