// package com.xiaoluo.springdata;
//
// import java.util.List;
//
// import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.repository.RepositoryDefinition;
//
// import com.xiaoluo.entity.Customer;
//
//// 可以使用这个注解替代集成Repository的类--其中domainClass是指传递的实体类，idClass是指传递的实体类所生成id的类
// @RepositoryDefinition(domainClass = Customer.class, idClass = Integer.class)
// public interface SSHRepository {
// // 获取查询的时候如果用采取的规定的严格遵守
// /*
// * * 在 Repository 子接口中声明方法 1. 不是随便声明的. 而需要符合一定的规范 2. 查询方法以 find | read | get
// * 开头 3. 涉及条件查询时，条件的属性用条件关键字连接 4. 要注意的是：条件属性以首字母大写。 5. 支持属性的级联查询.
// * 若当前类有符合条件的属性, 则优先使用, 而不使用级联属性. 若需要使用级联属性, 则属性之间使用 _ 进行连接
// */
//
// @Query("from Customer where customerName like %?1%")
// List<Customer> queryAllByCustomerName(String customerName);
//
// }
