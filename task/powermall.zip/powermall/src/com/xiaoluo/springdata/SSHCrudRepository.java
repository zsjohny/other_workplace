// package com.xiaoluo.springdata;
//
// import org.springframework.data.repository.CrudRepository;
//
// import com.xiaoluo.entity.Customer;
//
// public interface SSHCrudRepository extends CrudRepository<Customer, Integer>
// {
//
// }
