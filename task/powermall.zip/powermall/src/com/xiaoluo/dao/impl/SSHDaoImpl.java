// package com.xiaoluo.dao.impl;
//
// import java.util.List;
//
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Repository;
// import org.springframework.transaction.annotation.Transactional;
//
// import com.xiaoluo.dao.SSHDao;
// import com.xiaoluo.entity.Customer;
// import com.xiaoluo.springdata.SSHCrudRepository;
//
// @Repository
// @Transactional
// public class SSHDaoImpl implements SSHDao {
// @Autowired
// private SSHCrudRepository sshCrudRepository;
//
// public void createCustomerByCusual(Customer customer) {
// sshCrudRepository.save(customer);
// }
//
// @Override
// public List<Customer> queryCustomer() {
// return (List<Customer>) sshCrudRepository.findAll();
//
// }
//
// }
