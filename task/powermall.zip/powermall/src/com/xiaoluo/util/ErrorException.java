package com.xiaoluo.util;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

public class ErrorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ErrorException(HttpServletResponse response) {
		try {
			response.sendRedirect("http://192.168.1.104:8080/powermall/error/errorMsg.action");
			return;
		} catch (IOException e) {

		}
	}

}
