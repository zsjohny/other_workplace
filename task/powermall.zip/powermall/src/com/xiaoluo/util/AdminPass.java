package com.xiaoluo.util;

public enum AdminPass {
	adminName("adminName", "13693118950"), adminPass("adminPass", "admin");
	private String key;
	private String value;

	private AdminPass(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public static String getValue(String key) {
		if (key != null) {

			for (AdminPass adminPass : AdminPass.values()) {
				if (adminPass.getKey().equals(key)) {
					return adminPass.getValue();
				}
			}

		}
		return key;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
