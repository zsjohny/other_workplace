package com.xiaoluo.entity

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.Table
import javax.persistence.Id;

/*
*
 * Created by xiaoluo on 2015/12/16.

*/

@Table(name = "merchandiseOrder" )
@Entity
class EditMerchaniseList {

    Integer eidtId;


    String merchandiseOrder;

    @Column(name = "edit_Id")
    @GeneratedValue
    @Id
    Integer getEidtId() {
        return eidtId
    }

    void setEidtId(Integer eidtId) {
        this.eidtId = eidtId
    }

    @Column(name = "merchandise_order")
    String getMerchandiseOrder() {
        return merchandiseOrder
    }

    void setMerchandiseOrder(String merchandiseOrder) {
        this.merchandiseOrder = merchandiseOrder
    }
}
