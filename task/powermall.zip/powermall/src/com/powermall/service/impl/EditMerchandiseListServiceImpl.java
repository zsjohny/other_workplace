package com.powermall.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.powermall.dao.EditMerchandiseListDao;
import com.powermall.entity.EditMerchandiseList;
import com.powermall.entity.RecommondMerchandise;
import com.powermall.service.EditMerchandiseListService;

@Transactional
@Service
public class EditMerchandiseListServiceImpl implements EditMerchandiseListService {
	@Autowired
	private EditMerchandiseListDao editMerchandiseListDao;

	@Override
	public Iterable<EditMerchandiseList> findMerchandiseAllByPhone(int startPage, int pageSize) {

		return editMerchandiseListDao.findMerchandiseAllByPhone(startPage, pageSize);
	}

	@Override
	public long findCount() {

		return editMerchandiseListDao.findCount();
	}

	@Override
	public void saveRecommond(RecommondMerchandise recommondMerchandise) {
		editMerchandiseListDao.saveRecommond(recommondMerchandise);

	}

	@Override
	public void updateMerchandiseByRecommond(String status, Integer id) {
		editMerchandiseListDao.updateMerchandiseByRecommond(status, id);

	}

	@Override
	public EditMerchandiseList findMerchandiseById(Integer id) {

		return editMerchandiseListDao.findMerchandiseById(id);
	}

	@Override
	public RecommondMerchandise findRecommondMerchandiseById(Integer id) {

		return editMerchandiseListDao.findRecommondMerchandiseById(id);
	}

	@Override
	public void deleteRecommondById(Integer id) {
		editMerchandiseListDao.deleteRecommondById(id);

	}

	@Override
	public Iterable<RecommondMerchandise> findRecommondByCode(int page, int size) {

		return editMerchandiseListDao.findRecommondByCode(page, size);
	}

	@Override
	public List<RecommondMerchandise> findRecommondByCode() {

		return editMerchandiseListDao.findRecommondByCode();
	}

	@Override
	public EditMerchandiseList findEditMerchandiseById(Integer id) {

		return editMerchandiseListDao.findEditMerchandiseById(id);
	}

}
