package com.powermall.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.powermall.dao.MerchantDao;
import com.powermall.entity.Merchant;
import com.powermall.service.MerchantService;

/**
 * Created by xiaoluo on 2015/12/22.
 */
@Service
@Transactional
public class MerchantServiceImpl implements MerchantService {
	@Autowired
	private MerchantDao merchantDao;

	@Override
	public void createMerchantByAdmin(Merchant merchant) {
		merchantDao.createMerchantByAdmin(merchant);
	}

	@Override
	public Merchant queryMerchant(String phone) {
		return merchantDao.queryMerchant(phone);
	}

	@Override
	public List<Merchant> queryMertchantByAll() {
		return merchantDao.queryMertchantByAll();
	}

	@Override
	public List<Merchant> queryMertchantPhoneById(Integer id) {

		return merchantDao.queryMertchantPhoneById(id);
	}
}
