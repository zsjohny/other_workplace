package com.powermall.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.powermall.dao.CarriageDao;
import com.powermall.entity.Carriage;
import com.powermall.entity.form.CarriageForm;
import com.powermall.service.CarriageService;

@Service
@Transactional
public class CarriageServiceImpl implements CarriageService {
	@Autowired
	private CarriageDao carriageDao;

	@Override
	public Boolean eidtCarriage(CarriageForm carriageForm) {
		return carriageDao.eidtCarriage(carriageForm);

	}

	@Override
	public List<Carriage> queryByMerchantPhone(String merchantPhone) {

		return carriageDao.queryByMerchantPhone(merchantPhone);
	}

	@Override
	public Boolean deleteCarriage(Integer carriageId, String merchantPhone) {
		return carriageDao.deleteCarriage(carriageId, merchantPhone);

	}

}
