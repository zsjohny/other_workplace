package com.powermall.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.powermall.dao.ShoppingCarDao;
import com.powermall.entity.ShoppingCar;
import com.powermall.service.ShoppingCarService;

@Transactional
@Service
public class ShoppingCarServiceImpl implements ShoppingCarService {
	@Resource
	private ShoppingCarDao shoppingCarDao;

	@Override
	public List<ShoppingCar> findOderInfosByAll(String phone) {

		return shoppingCarDao.findOderInfosByAll(phone);
	}

	@Override
	public void deleteOrder(Integer id) {
		shoppingCarDao.deleteOrder(id);
	}

	@Override
	public void saveOrderInfo(ShoppingCar shoppingCar) {
		shoppingCarDao.saveOrderInfo(shoppingCar);

	}

	@Override
	public Integer findCountById(String phone) {

		return shoppingCarDao.findCountById(phone);
	}

}
