package com.powermall.service;

import java.util.List;

import com.powermall.entity.Carriage;
import com.powermall.entity.form.CarriageForm;

public interface CarriageService {
	Boolean eidtCarriage(CarriageForm carriageForm);

	List<Carriage> queryByMerchantPhone(String merchantPhone);

	Boolean deleteCarriage(Integer carriageId, String merchantPhone);
}
