package com.powermall.service;

import java.util.List;

import com.powermall.entity.EditMerchandiseList;
import com.powermall.entity.RecommondMerchandise;

public interface EditMerchandiseListService {
	Iterable<EditMerchandiseList> findMerchandiseAllByPhone(int startPage, int pageSize);

	long findCount();

	void saveRecommond(RecommondMerchandise recommondMerchandise);

	public void updateMerchandiseByRecommond(String status, Integer id);

	public EditMerchandiseList findMerchandiseById(Integer id);

	public Iterable<RecommondMerchandise> findRecommondByCode(int page, int size);

	public List<RecommondMerchandise> findRecommondByCode();

	public RecommondMerchandise findRecommondMerchandiseById(Integer id);

	public void deleteRecommondById(Integer id);

	EditMerchandiseList findEditMerchandiseById(Integer id);
}
