package com.powermall.service;

import java.util.List;

import com.powermall.entity.ShoppingCar;

public interface ShoppingCarService {

	List<ShoppingCar> findOderInfosByAll(String phone);

	void deleteOrder(Integer id);

	void saveOrderInfo(ShoppingCar shoppingCar);

	Integer findCountById(String phone);
}
