package com.powermall.service;

import java.util.List;

import com.powermall.entity.Merchant;

/**
 * Created by xiaoluo on 2015/12/22.
 */
public interface MerchantService {
	void createMerchantByAdmin(Merchant merchant);

	Merchant queryMerchant(String phone);

	List<Merchant> queryMertchantByAll();

	List<Merchant> queryMertchantPhoneById(Integer id);
}
