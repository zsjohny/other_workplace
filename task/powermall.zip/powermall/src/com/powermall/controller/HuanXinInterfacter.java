package com.powermall.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.powermall.entity.HuanXin;
import com.powermall.entity.Merchant;
import com.powermall.repository.HuanXinCrudRepository;
import com.powermall.repository.HuanXinRepository;
import com.powermall.repository.MerchantRepository;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
public class HuanXinInterfacter {
	@Autowired
	private HuanXinCrudRepository huanXinCrudRepository;
	@Autowired
	private HuanXinRepository huanXinRepository;
	@Autowired
	private MerchantRepository merchantRepository;

	@ResponseBody
	@RequestMapping(value = "loadAccount")
	public JSONObject loadMerchantData(@RequestParam("uid") Long uid, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();

		Merchant merchant = merchantRepository.queryMerchant(uid + "");
		Integer ids = null;
		if (merchant != null) {
			ids = merchant.getMerchantId();
		} else {
			try {
				ids = Integer.parseInt(uid + "");
			} catch (NumberFormatException e) {
				ids = (int) ((Math.random() * 100));
				e.printStackTrace();
			}
		}

		HuanXin huanXin = huanXinRepository.queryIsExist(ids);

		if (huanXin != null) {
			jsonObject.put("code", 200);
			jsonObject.put("name", huanXin.getHuaXinName());

			return jsonObject;
		}

		HttpClient httpClient = HttpClients.createDefault();
		HttpPost post = new HttpPost("https://a1.easemob.com/030511/xiangwei/users");

		String name = System.currentTimeMillis() + "";
		String pass = "powermall";
		JSONObject json = new JSONObject();
		json.put("username", name);
		json.put("password", pass);

		try {
			StringEntity entity = new StringEntity(json.toString());
			entity.setContentEncoding("utf-8");
			entity.setContentType("application/json");
			post.setEntity(entity);

			HttpResponse response = httpClient.execute(post);
			HttpEntity entitys = response.getEntity();
			String data = EntityUtils.toString(entitys);
			json = JSONObject.fromObject(data);
			JSONArray array = JSONArray.fromObject(json.get("entities"));

			json = JSONObject.fromObject(array.get(0));
			String id = (String) json.get("uuid");
			if (StringUtils.isNotEmpty(id)) {
				huanXin = new HuanXin();
				huanXin.setCreatTime(new Date());
				huanXin.setHuaXinUUid(id);
				huanXin.setHuaXinName(name);
				huanXin.setOwnerId(ids);
				huanXin.setPass(pass);
				huanXinCrudRepository.save(huanXin);
			}
			jsonObject.put("code", 200);
			jsonObject.put("name", name);
		} catch (Exception e) {
			jsonObject.put("code", 201);
		}
		return jsonObject;

	}

}
