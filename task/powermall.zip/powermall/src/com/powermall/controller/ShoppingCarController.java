package com.powermall.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.powermall.entity.Carriage;
import com.powermall.entity.EditMerchandiseList;
import com.powermall.entity.Merchant;
import com.powermall.entity.ShoppingCar;
import com.powermall.entity.form.CarriageForm;
import com.powermall.entity.form.ShoppingCarForm;
import com.powermall.service.CarriageService;
import com.powermall.service.EditMerchandiseListService;
import com.powermall.service.MerchantService;
import com.powermall.service.ShoppingCarService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@RequestMapping("/order")
@Controller
public class ShoppingCarController {
	@Autowired
	private CarriageService carriageService;
	@Autowired
	private ShoppingCarService shoppingCarService;
	@Autowired
	private EditMerchandiseListService editMerchandiseListService;
	@Autowired
	private MerchantService merchantService;

	@ResponseBody
	@RequestMapping(value = "{phone}/find")
	public JSONObject findOderInfosByAll(@PathVariable(value = "phone") String phone) {
		JSONObject jsonObject = new JSONObject();
		JSONObject json = null;
		if (StringUtils.isEmpty(phone) || !phone.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			jsonObject.put("status", 302);
			return jsonObject;
		}
		JSONArray jsonArray = new JSONArray();
		try {
			List<ShoppingCar> lists = shoppingCarService.findOderInfosByAll(phone);
			Integer count = shoppingCarService.findCountById(phone);

			for (ShoppingCar shoppingCar : lists) {
				EditMerchandiseList editMerchandiseList = null;
				if (shoppingCar == null) {
					continue;
				}

				editMerchandiseList = editMerchandiseListService
						.findEditMerchandiseById(shoppingCar.getMerchandiseId());

				if (editMerchandiseList == null) {
					continue;
				}
				json = new JSONObject();
				List<String> disUrls = new ArrayList<String>();

				// 加载商品描述图片
				String disUrl = editMerchandiseList.getEditMerchandiseListDisPicsUrl();

				JSONArray disPicArr = null;

				if (StringUtils.isNotEmpty(disUrl)) {

					String disPath = disUrl.replace("[", "").replace("]", "").split("&")[1];
					String[] disArr = null;
					if (disPath.indexOf(",") > -1) {
						disArr = disPath.split(",");

						disUrls.add("?id=" + editMerchandiseList.getEditMerchandiseListId() + "&name="
								+ disArr[0].trim() + ".jpg");

					} else {
						disPicArr = new JSONArray();
						disPicArr.add("?id=" + editMerchandiseList.getEditMerchandiseListId() + "&name="
								+ disPath.trim() + ".jpg");

					}

				} else {
					disPicArr = new JSONArray();
					disPicArr.add("");
				}

				// -----------editMerchandiseListId 为商品的id需要隐藏
				// -----------editMerchandiseListName 为商品的名称
				// -----------editMerchandiseListPrice 为商品的价格
				// -----------editMerchandiseListStock 为商品的库存
				// -----------editMerchandiseListIsPost 为商品的是否被包邮
				// ,true是可以包邮，false是不可以包邮
				// -----------editMerchandiseListProductDesc 为商品的描述
				// -----------salesCount 为商品的销量
				// -----------merchantFloderName 为商品的对应的下载所传的fileId需要隐藏
				// -----------disPicUrl 这里面展示的是轮播的一系列的名称是数组
				// -----------desPicUrl 这里面展示的是详情的一系列的名称是数组
				// -----------merchantId 商家的id信息
				// -----------merchantStoreName 商家的店铺名称

				json.put("editMerchandiseListId", editMerchandiseList.getEditMerchandiseListId() == null ? ""
						: editMerchandiseList.getEditMerchandiseListId());
				json.put("editMerchandiseListName",
						StringUtils.isEmpty(editMerchandiseList.getEditMerchandiseListName()) ? ""
								: editMerchandiseList.getEditMerchandiseListName());
				json.put("editMerchandiseListPrice", editMerchandiseList.getEditMerchandiseListPrice() == null ? ""
						: editMerchandiseList.getEditMerchandiseListPrice());
				json.put("editMerchandiseListStock", editMerchandiseList.getEditMerchandiseListStock() == null ? ""
						: editMerchandiseList.getEditMerchandiseListStock());
				json.put("editMerchandiseListIsPost",
						StringUtils.isEmpty(editMerchandiseList.getEditMerchandiseListIsPost()) ? ""
								: editMerchandiseList.getEditMerchandiseListIsPost());
				json.put("editMerchandiseListProductDesc",
						StringUtils.isEmpty(editMerchandiseList.getEditMerchandiseListProductDesc()) ? ""
								: editMerchandiseList.getEditMerchandiseListProductDesc());
				json.put("salesCount",
						editMerchandiseList.getSalesCount() == null ? "" : editMerchandiseList.getSalesCount());
				json.put("disPicUrl", disPicArr);
				Merchant queryMerchant = merchantService.queryMerchant(editMerchandiseList.getMerchantPhone());
				json.put("merchantId", queryMerchant.getMerchantId());
				json.put("merchantStoreName", queryMerchant.getMerchantStoreName());

				jsonArray.add(json);
			}
			// 加载同一商家
			jsonObject.put("status", 300);
			jsonObject.put("count", count);
			jsonObject.put("source", jsonArray);
		} catch (Exception e) {
			jsonObject.put("status", 300);
			jsonObject.put("source", jsonArray);
		}

		return jsonObject;

	}

	// 查看购物车的数量
	@ResponseBody
	@RequestMapping(value = "{phone}/viewCount")
	public JSONObject viewCount(@PathVariable(value = "phone") String phone) {
		JSONObject jsonObject = new JSONObject();
		JSONObject json = null;
		if (StringUtils.isEmpty(phone) || !phone.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			jsonObject.put("status", 302);
			return jsonObject;
		}
		JSONArray jsonArray = new JSONArray();
		try {
			List<ShoppingCar> lists = shoppingCarService.findOderInfosByAll(phone);
			Integer count = shoppingCarService.findCountById(phone);

			for (ShoppingCar shoppingCar : lists) {
				EditMerchandiseList editMerchandiseList = null;
				if (shoppingCar == null) {
					continue;
				}

				editMerchandiseList = editMerchandiseListService
						.findEditMerchandiseById(shoppingCar.getMerchandiseId());

				if (editMerchandiseList == null) {
					continue;
				}
				json = new JSONObject();
				List<String> disUrls = new ArrayList<String>();

				// 加载商品描述图片
				String disUrl = editMerchandiseList.getEditMerchandiseListDisPicsUrl();

				JSONArray disPicArr = null;

				if (StringUtils.isNotEmpty(disUrl)) {

					String disPath = disUrl.replace("[", "").replace("]", "").split("&")[1];
					String[] disArr = null;
					if (disPath.indexOf(",") > -1) {
						disArr = disPath.split(",");

						disUrls.add("?id=" + editMerchandiseList.getEditMerchandiseListId() + "&name="
								+ disArr[0].trim() + ".jpg");

					} else {
						disPicArr = new JSONArray();
						disPicArr.add("?id=" + editMerchandiseList.getEditMerchandiseListId() + "&name="
								+ disPath.trim() + ".jpg");

					}

				} else {
					disPicArr = new JSONArray();
					disPicArr.add("");
				}

				// -----------editMerchandiseListId 为商品的id需要隐藏
				// -----------editMerchandiseListName 为商品的名称
				// -----------editMerchandiseListPrice 为商品的价格
				// -----------editMerchandiseListStock 为商品的库存
				// -----------editMerchandiseListIsPost 为商品的是否被包邮
				// ,true是可以包邮，false是不可以包邮
				// -----------editMerchandiseListProductDesc 为商品的描述
				// -----------salesCount 为商品的销量
				// -----------merchantFloderName 为商品的对应的下载所传的fileId需要隐藏
				// -----------disPicUrl 这里面展示的是轮播的一系列的名称是数组
				// -----------desPicUrl 这里面展示的是详情的一系列的名称是数组
				// -----------merchantId 商家的id信息
				// -----------merchantStoreName 商家的店铺名称

				json.put("editMerchandiseListId", editMerchandiseList.getEditMerchandiseListId() == null ? ""
						: editMerchandiseList.getEditMerchandiseListId());
				json.put("editMerchandiseListName",
						StringUtils.isEmpty(editMerchandiseList.getEditMerchandiseListName()) ? ""
								: editMerchandiseList.getEditMerchandiseListName());
				json.put("editMerchandiseListPrice", editMerchandiseList.getEditMerchandiseListPrice() == null ? ""
						: editMerchandiseList.getEditMerchandiseListPrice());
				json.put("editMerchandiseListStock", editMerchandiseList.getEditMerchandiseListStock() == null ? ""
						: editMerchandiseList.getEditMerchandiseListStock());
				json.put("editMerchandiseListIsPost",
						StringUtils.isEmpty(editMerchandiseList.getEditMerchandiseListIsPost()) ? ""
								: editMerchandiseList.getEditMerchandiseListIsPost());
				json.put("editMerchandiseListProductDesc",
						StringUtils.isEmpty(editMerchandiseList.getEditMerchandiseListProductDesc()) ? ""
								: editMerchandiseList.getEditMerchandiseListProductDesc());
				json.put("salesCount",
						editMerchandiseList.getSalesCount() == null ? "" : editMerchandiseList.getSalesCount());
				json.put("disPicUrl", disPicArr);
				Merchant queryMerchant = merchantService.queryMerchant(editMerchandiseList.getMerchantPhone());
				json.put("merchantId", queryMerchant.getMerchantId());
				json.put("merchantStoreName", queryMerchant.getMerchantStoreName());

				jsonArray.add(json);
			}
			// 加载同一商家
			jsonObject.put("status", 300);
			jsonObject.put("count", count);
			jsonObject.put("source", jsonArray);
		} catch (Exception e) {
			jsonObject.put("status", 300);
			jsonObject.put("source", jsonArray);
		}

		return jsonObject;

	}

	@ResponseBody
	@RequestMapping(value = "{id}/delete")
	public JSONObject deleteOrder(@PathVariable(value = "id") Integer id) {
		JSONObject jsonObject = new JSONObject();
		if (id == null) {
			jsonObject.put("status", 302);
			return jsonObject;
		}
		try {
			shoppingCarService.deleteOrder(id);
			jsonObject.put("status", 300);
		} catch (Exception e) {
			jsonObject.put("status", 301);
		}

		return jsonObject;

	}

	@ResponseBody
	@RequestMapping(value = "save")
	public JSONObject saveOrderInfo(ShoppingCarForm shoppingCarForm) {
		JSONObject jsonObject = new JSONObject();
		if (shoppingCarForm == null
				|| !shoppingCarForm.getCustomerPhone().matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {
			jsonObject.put("status", 302);
			return jsonObject;
		}

		try {

			// 判断是否超出了数量
			Integer count = shoppingCarService.findCountById(shoppingCarForm.getCustomerPhone());

			if (count >= 20) {
				jsonObject.put("status", 314);
				return jsonObject;
			}

			ShoppingCar shoppingCar = new ShoppingCar();
			BeanUtils.copyProperties(shoppingCar, shoppingCarForm);
			shoppingCar.setIsDeleted("0");
			shoppingCar.setCreatTime(new Date());
			EditMerchandiseList findEditMerchandiseById = editMerchandiseListService
					.findEditMerchandiseById(shoppingCar.getMerchandiseId());
			Merchant queryMerchant = merchantService.queryMerchant(shoppingCar.getCustomerPhone());

			if (findEditMerchandiseById == null || queryMerchant == null) {
				shoppingCarService.saveOrderInfo(shoppingCar);
				jsonObject.put("status", 300);
			} else {
				jsonObject.put("status", 301);
			}

		} catch (Exception e) {
			jsonObject.put("status", 301);
		}

		return jsonObject;

	}

	// 买家接口查询运费

	@ResponseBody
	@RequestMapping("/queryCarriageByCustomer")
	public JSONObject loadCarriageByCustomer(@RequestParam(value = "id", defaultValue = "") Integer id,
			@RequestParam(value = "address", defaultValue = "") String address) {

		JSONArray jArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		if (id == null || StringUtils.isEmpty(address)) {
			jsonObject.put("status", 302);
			return jsonObject;
		}

		List<Merchant> queryMertchantPhoneById = merchantService.queryMertchantPhoneById(id);

		if (queryMertchantPhoneById == null || queryMertchantPhoneById.size() == 0) {
			jsonObject.put("status", 303);
			return jsonObject;
		}

		List<Carriage> queryByMerchantPhone = carriageService
				.queryByMerchantPhone(queryMertchantPhoneById.get(0).getMerchantLoginPhone());
		JSONObject json = new JSONObject();
		if (queryByMerchantPhone != null && queryByMerchantPhone.size() != 0) {
			jsonObject.put("status", 300);
			for (Carriage carriage : queryByMerchantPhone) {
				if (carriage == null) {
					continue;
				}
				String[] carriages = null;
				if (carriage.getCarriageCity().indexOf(",") > -1) {
					carriages = carriage.getCarriageCity().split(",");
				} else {

					carriages = new String[] { carriage.getCarriageCity() };
				}

				for (String str : carriages) {
					if (StringUtils.isEmpty(str)) {
						continue;
					}

					if (address.equals(str)) {
						json.put("carriageCity", str);
						json.put("carriageFirstCount", carriage.getCarriageFirstCount());
						json.put("carriageFirstPay", carriage.getCarriageFirstPay());
						json.put("carriageLastPay", carriage.getCarriageLastPay());
						json.put("carriageLastCount", carriage.getCarriageLastCount());
						jArray.add(json);
						jsonObject.put("source", jArray);
						return jsonObject;
					}

					if ("default".equals("")) {
						json.put("carriageCity", str);
						json.put("carriageFirstCount", carriage.getCarriageFirstCount());
						json.put("carriageFirstPay", carriage.getCarriageFirstPay());
						json.put("carriageLastPay", carriage.getCarriageLastPay());
						json.put("carriageLastCount", carriage.getCarriageLastCount());
						jArray.add(json);
						jsonObject.put("source", jArray);
						return jsonObject;
					}
				}

			}
			jsonObject.put("source", jArray);
		} else {
			json.put("carriageCity", "default");
			json.put("carriageFirstCount", "1");
			json.put("carriageFirstPay", "8");
			json.put("carriageLastCount", "1");
			json.put("carriageLastPay", "2");
			jsonObject.put("status", 300);

		}

		return jsonObject;
	}

	// 测试多个json
	@ResponseBody
	@RequestMapping(value = "eidtCarriage", method = RequestMethod.POST)
	public JSONObject eidtCarriage(@RequestBody List<CarriageForm> carriageForms, @RequestParam("name") String name) {

		System.out.println(name);
		JSONObject jsonObject = new JSONObject();

		Boolean flag = false;

		try {
			for (CarriageForm carriageForm : carriageForms) {
				System.out.println(carriageForm);
				flag = carriageService.eidtCarriage(carriageForm);

			}
		} catch (Exception e) {
			flag = false;
		}

		if (flag) {
			jsonObject.put("STATUS", "OK");
		} else {
			jsonObject.put("STATUS", "ERROR");
		}
		return jsonObject;

	}
}
