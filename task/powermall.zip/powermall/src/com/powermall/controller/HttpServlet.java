package com.powermall.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspsmart.upload.SmartUpload;

/**
 * Servlet implementation class HttpServlet
 */

public class HttpServlet extends javax.servlet.http.HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		SmartUpload smartUpload = new SmartUpload();
		String msg = request.getParameter("msg");
		// out.print(msg);
		try {
			smartUpload.initialize(this.getServletConfig(), request, response);
			smartUpload.upload();
			com.jspsmart.upload.File smartFile = smartUpload.getFiles().getFile(0);

			System.out.println(smartFile.getFieldName());
			if (!smartFile.isMissing()) {
				String saveFileName = "images/" + smartFile.getFileName();
				smartFile.saveAs(saveFileName, smartUpload.SAVE_VIRTUAL);
				out.print("ok:" + saveFileName + ", msg:" + smartUpload.getRequest().getParameter("msg"));
			} else {
				out.print("missing...");
			}
		} catch (Exception e) {
			out.print(e + "," + msg);
		}
		out.flush();
		out.close();
		doGet(request, response);
	}

}
