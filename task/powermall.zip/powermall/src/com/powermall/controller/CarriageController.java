package com.powermall.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.powermall.entity.Carriage;
import com.powermall.entity.Merchant;
import com.powermall.entity.form.CarriageForm;
import com.powermall.service.CarriageService;
import com.powermall.service.MerchantService;
import com.xiaoluo.util.ByteConverHexString;
import com.xiaoluo.util.ErrorException;
import com.xiaoluo.util.RSACoder;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@RequestMapping("/carriage")
@Controller
public class CarriageController {
	@Autowired
	private CarriageService carriageService;
	@Autowired
	private MerchantService merchantService;

	@ModelAttribute
	public void checkParams(@RequestParam(value = "merchantPhone", defaultValue = "") String merchantPhone,
			@RequestParam(value = "loginKey", defaultValue = "") String loginKey, HttpServletResponse response) {
		if (merchantPhone != null && merchantPhone.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {

			Merchant merchant = merchantService.queryMerchant(merchantPhone);

			if (loginKey == null || merchant == null) {

				try {
					throw new ErrorException(response);

				} catch (ErrorException e1) {
					return;
				}
			}
			if (!"0".equals(merchant.getIsRegist())) {
				try {
					throw new ErrorException(response);

				} catch (ErrorException e1) {
					return;
				}
			}

			String outputStr = "";
			try {
				byte[] bs = ByteConverHexString.HexString2Bytes(loginKey);

				byte[] decodedData = RSACoder.decryptByPrivateKey(bs, merchant.getLoginKey());

				outputStr = new String(decodedData);
			} catch (Exception e) {
				try {
					throw new ErrorException(response);
				} catch (ErrorException e1) {
					return;
				}
			}
			if (outputStr.equals(merchantPhone)) {

				return;
			}

		}
		try {
			throw new ErrorException(response);
		} catch (ErrorException e1) {
			return;
		}

	}

	@ResponseBody
	@RequestMapping(value = "eidtCarriage", method = RequestMethod.POST)
	public JSONObject eidtCarriage(@Validated CarriageForm carriageForm, BindingResult result) {
		JSONObject jsonObject = new JSONObject();
		JSONArray jArrayy = new JSONArray();
		if (result.hasErrors()) {
			List<ObjectError> allErrors = result.getAllErrors();
			for (ObjectError objectError : allErrors) {
				jArrayy.add(objectError.getDefaultMessage());

			}
			jsonObject.put("STATUS", "PRARMSINCORRECT");
			jsonObject.put("SOURCE", jArrayy);
			return jsonObject;
		}
		Boolean flag = carriageService.eidtCarriage(carriageForm);

		if (flag) {
			jsonObject.put("STATUS", "OK");
		} else {
			jsonObject.put("STATUS", "ERROR");
		}
		return jsonObject;

	}

	@ResponseBody
	@RequestMapping("/queryCarriage")
	public JSONObject loadCarriage(
			@RequestParam(value = "merchantPhone", defaultValue = "", required = false) String merchantPhone) {
		JSONArray jArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();

		List<Carriage> queryByMerchantPhone = carriageService.queryByMerchantPhone(merchantPhone);
		if (queryByMerchantPhone != null && queryByMerchantPhone.size() != 0) {
			jsonObject.put("STATUS", "OK");
			for (Carriage carriage : queryByMerchantPhone) {
				JSONObject json = new JSONObject();
				json.put("carriageId", carriage.getCarriageId());
				json.put("carriageCity", carriage.getCarriageCity());
				json.put("carriageCity", carriage.getCarriageCity());
				json.put("carriageFirstCount", carriage.getCarriageFirstCount());
				json.put("carriageFirstPay", carriage.getCarriageFirstPay());
				json.put("carriageLastPay", carriage.getCarriageLastPay());
				json.put("carriageLastCount", carriage.getCarriageLastCount());
				jArray.add(json);
			}
			jsonObject.put("SOURCE", jArray);
		} else {
			JSONObject json = new JSONObject();
			json.put("carriageCity", "default");
			json.put("carriageFirstCount", "1");
			json.put("carriageFirstPay", "8");
			json.put("carriageLastCount", "1");
			json.put("carriageLastPay", "2");
			jsonObject.put("STATUS", "OK");
		}

		return jsonObject;
	}

	@ResponseBody
	@RequestMapping("/deleteCarriage")
	public JSONObject deleteCarriage(@RequestParam(value = "id") Integer carriageId,
			@RequestParam(value = "merchantPhone", defaultValue = "") String merchantPhone) {
		JSONObject jsonObject = new JSONObject();
		if (carriageId != null) {
			Boolean flag = carriageService.deleteCarriage(carriageId, merchantPhone);
			if (flag) {
				jsonObject.put("STATUS", "OK");
			} else {
				jsonObject.put("STATUS", "ISEXIST");
			}

		} else {
			jsonObject.put("STATUS", "ERROR");

		}
		return jsonObject;

	}

	// 测试多个json的上传
	/*
	 * @ResponseBody
	 * 
	 * @RequestMapping(value = "creatCarriage", method = RequestMethod.POST)
	 * public JSONObject eidtCarriage(@RequestBody List<CarriageForm>
	 * carriageForms) { JSONObject jsonObject = new JSONObject();
	 * 
	 * Boolean flag = false;
	 * 
	 * try { for (CarriageForm carriageForm : carriageForms) { flag =
	 * carriageService.eidtCarriage(carriageForm);
	 * 
	 * } } catch (Exception e) { flag = false; }
	 * 
	 * if (flag) { jsonObject.put("STATUS", "OK"); } else {
	 * jsonObject.put("STATUS", "ERROR"); } return jsonObject;
	 * 
	 * }
	 */

	@ResponseBody
	@RequestMapping(value = "creatCarriage", method = RequestMethod.POST)
	public JSONObject eidtCarriage(@RequestParam("data") String data) {

		JSONObject jsonObject = new JSONObject();
		List<CarriageForm> carriageForms = new ArrayList<>();
		if (StringUtils.isEmpty(data)) {
			jsonObject.put("STATUS", "ERROR");
		}

		JSONArray jArray = JSONArray.fromObject(data);

		for (int i = 0; i < jArray.size(); i++) {
			JSONObject json = JSONObject.fromObject(jArray.get(i));
			CarriageForm cForm = new CarriageForm();
			cForm.setCarriageCity((String) json.get("carriageCity"));
			cForm.setMerchantPhone((String) json.get("merchantPhone"));
			cForm.setCarriageFirstCount(Integer.parseInt(json.get("carriageFirstCount") + ""));
			cForm.setCarriageFirstPay(Double.parseDouble(json.get("carriageFirstPay") + ""));
			cForm.setCarriageLastCount(Integer.parseInt(json.get("carriageLastCount") + ""));
			cForm.setCarriageLastPay(Double.parseDouble(json.get("carriageLastPay") + ""));

			carriageForms.add(cForm);
		}

		Boolean flag = false;

		try {
			for (CarriageForm carriageForm : carriageForms) {
				flag = carriageService.eidtCarriage(carriageForm);

			}
		} catch (Exception e) {
			flag = false;
		}

		if (flag) {
			jsonObject.put("STATUS", "OK");
		} else {
			jsonObject.put("STATUS", "ERROR");
		}
		return jsonObject;

	}
}
