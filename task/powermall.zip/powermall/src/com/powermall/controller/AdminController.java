package com.powermall.controller;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.powermall.entity.EditMerchandiseList;
import com.powermall.entity.Merchant;
import com.powermall.entity.RecommondMerchandise;
import com.powermall.service.EditMerchandiseListService;
import com.powermall.service.MerchantService;
import com.xiaoluo.util.AdminPass;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Created by xiaoluo on 2015/12/22.
 */

// http://localhost:8080/powermall/test.action
@Controller
public class AdminController {
	@Autowired
	private MerchantService merchantService;
	@Autowired
	private EditMerchandiseListService editMerchandiseListService;

	private String FORWARD = "forward:";

	@RequestMapping(value = "loadInfo", method = RequestMethod.POST)
	public String loadMerchantData(@RequestParam("name") String merchantName,
			@RequestParam("phone") String merchantPhone, @RequestParam("IdCard") String merchantIdCard,
			@RequestParam(value = "province", defaultValue = "") String province,
			@RequestParam(value = "city", defaultValue = "") String city,
			@RequestParam(value = "country", defaultValue = "") String country, HttpServletRequest request) {

		String adminPass = (String) request.getSession().getAttribute(AdminPass.getValue("adminName"));
		if (adminPass == null || adminPass.equals("adminPass")) {
			request.setAttribute("errorMsg", "密码和用户名不正确");
			return "index";
		}

		if (merchantName != null && merchantIdCard != null && merchantPhone != null) {

			if (merchantIdCard.matches(
					"^[1-9]\\d{7}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}$||^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}([0-9]|X)$")
					&& merchantPhone.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$")) {

				Merchant merchant = null;

				merchant = merchantService.queryMerchant(merchantPhone);

				if (merchant == null) {
					merchant = new Merchant();
				}

				merchant.setMerchantLoginPhone(merchantPhone);

				merchant.setMerchantLoginIdCard(merchantIdCard);
				merchant.setMerchantLoginName(merchantName);
				merchant.setIsDeleted("0");
				merchant.setIsRegist("0");
				merchant.setOperateTime(new Date());
				merchant.setProvince(province);
				merchant.setCity(city);
				merchant.setCountry(country);
				merchant.setOperator(AdminPass.getValue("adminName"));
				merchantService.createMerchantByAdmin(merchant);

				request.setAttribute("successMsg", "认证成功!!");
				return "creatMerchant";

			}

		}
		request.setAttribute("errorMsg", "网络异常");
		return "errorPage";
	}

	// http://localhost:8080/powermall/displayMerchant.action
	// 展示所有暂时不需要---开放了
	@RequestMapping(value = "displayMerchant")
	public String dispayMechantList(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
			HttpServletRequest request, ModelMap modelMap) {

		// 管理员密码session暂时不用
		String adminPass = (String) request.getSession().getAttribute("manager");
		// String adminPass = "";
		if (adminPass != null && "admin".equals(adminPass)) {
			int pageSize = 10;
			// int startPage = (pageNum - 1) * pageSize;
			int startPage = pageNum - 1;

			Iterable<EditMerchandiseList> eLists = editMerchandiseListService.findMerchandiseAllByPhone(startPage,
					pageSize);
			if (eLists == null) {
				request.setAttribute("errorMsg", "查询无结果");
				return "errorPage";
			}
			List<EditMerchandiseList> list = new ArrayList<>();
			Iterator<EditMerchandiseList> iterator = eLists.iterator();

			while (iterator.hasNext()) {
				EditMerchandiseList next = iterator.next();
				if (next != null) {
					if (next.getIsDeleted().equals("1")) {
						continue;
					}

					String downloadUrl = "http://192.168.1.104:8048/powermall/download.action?path=";
					String infoPath = next.getEditMerchandiseListDisPicsUrl();
					if (!StringUtils.isEmpty(infoPath)) {

						infoPath = infoPath.split("&")[0] + infoPath.split("&")[1].split(",") == null
								? downloadUrl + next.getEditMerchandiseListDisPicsUrl().split("&")[0] + File.separator
										+ infoPath.split("&")[1].replace("[", "").replace("]", "") + ".jpg"
								: downloadUrl + next.getEditMerchandiseListDisPicsUrl().split("&")[0] + File.separator
										+ infoPath.split("&")[1].split(",")[0].replace("[", "").replace("]", "")
										+ ".jpg";

					}

					next.setEditMerchandiseListDisPicsUrl(infoPath);
					list.add(next);
				}
			}

			if (list.size() == 0) {
				modelMap.addAttribute("lists", list);
				modelMap.addAttribute("count", 0);
				return "loadIndex";
			}

			modelMap.addAttribute("lists", list);

			long findCount = editMerchandiseListService.findCount();

			if (findCount == 0) {
				request.setAttribute("errorMsg", "总数查询异常");
				return "errorPage";
			}
			modelMap.addAttribute("startPage", startPage);
			modelMap.addAttribute("count", findCount / pageSize + 1);

			return "loadIndex";
		}
		request.setAttribute("errorMsg", "密码已经失效");
		return "errorPage";

	}

	// 接受推荐的商品
	@RequestMapping(value = "recommndMerchandise")
	public String recommndMerchandise(@RequestParam(value = "recommond") String recommond,
			@RequestParam(value = "nowPage", defaultValue = "1") int nowPage, @RequestParam("file") MultipartFile file,
			ModelMap modelMap, HttpServletRequest request) {
		// 管理员密码session暂时不用
		String adminPass = (String) request.getSession().getAttribute("manager");
		// String adminPass = "";
		if (adminPass != null && "admin".equals(adminPass)) {
			if (StringUtils.isEmpty(recommond) || recommond.indexOf("+") == -1) {
				modelMap.addAttribute("msg", "还没输入商品id!!");
				return FORWARD + "/displayMerchant.action?pageNum=" + nowPage;
			}

			Integer id = Integer.parseInt(recommond.substring(0, recommond.indexOf("+")));
			File saveFile = new File("D:\\workplaces\\app\\powermall\\WebRoot\\WEB-INF\\upload", id + "");
			if (!saveFile.exists()) {
				saveFile.mkdirs();
			} else {
				File[] files = saveFile.listFiles();
				for (File f : files) {
					if (f.exists()) {
						System.gc();
						f.delete();
					}
				}

			}

			String fileName = UUID.randomUUID().toString() + ".jpg";
			try {
				file.transferTo(new File(saveFile.getPath(), fileName));

			} catch (Exception e) {

			}

			EditMerchandiseList findMerchandiseById = editMerchandiseListService.findMerchandiseById(id);
			if (findMerchandiseById == null) {
				modelMap.addAttribute("msg", "没有该商品!!");
				return FORWARD + "/displayMerchant.action?pageNum=" + nowPage;

			}
			if (findMerchandiseById != null && "true".equals(findMerchandiseById.getIsRecommond())) {
				// 已经上传
				modelMap.addAttribute("msg", "已经推荐过此产品!!");
				return FORWARD + "/displayMerchant.action?pageNum=" + nowPage;

			}

			RecommondMerchandise recommondMerchandise = new RecommondMerchandise();

			recommondMerchandise.setMerchandiseId(id);

			if (recommond.substring(recommond.indexOf("+") + 1).equals("0")) {
				recommondMerchandise.setRecommondMerchandisePicUrlAndId(saveFile.getPath() + "&" + fileName);
				recommondMerchandise.setCode("0");
			} else {
				recommondMerchandise.setRecommondMerchandiseHomeUrlAndId(saveFile.getPath() + "&" + fileName);
				recommondMerchandise.setCode("1");
			}

			editMerchandiseListService.saveRecommond(recommondMerchandise);

			editMerchandiseListService.updateMerchandiseByRecommond("true", id);
			modelMap.addAttribute("msg", "推荐成功!!");
			return FORWARD + "/displayMerchant.action?pageNum=" + nowPage;

		}
		request.setAttribute("errorMsg", "密码已经失效");
		return "errorPage";
	}

	// 删除推荐
	@RequestMapping(value = "cancelMerchant")
	public String cancelMerchant(@RequestParam(value = "id") Integer id,
			@RequestParam(value = "nowPage", defaultValue = "1") int nowPage, HttpServletRequest request,
			ModelMap modelMap) {

		// 管理员密码session暂时不用
		String adminPass = (String) request.getSession().getAttribute("manager");
		// String adminPass = "";
		if (adminPass != null && "admin".equals(adminPass)) {

			if (id == null) {
				modelMap.addAttribute("msg", "取消推荐失败!!");
				return FORWARD + "/displayMerchant.action?pageNum=" + nowPage;
			}
			try {
				editMerchandiseListService.deleteRecommondById(id);
				editMerchandiseListService.updateMerchandiseByRecommond("", id);
				modelMap.addAttribute("msg", "取消成功!!");
			} catch (Exception e) {
				modelMap.addAttribute("msg", "取消失败!!");
			}

			return "loadIndex";
		}
		request.setAttribute("errorMsg", "密码已经失效");
		return "errorPage";

	}

	@ResponseBody
	// 提供下载的预览接口
	// @RequestMapping(value = "disPic", method = RequestMethod.POST)
	@RequestMapping(value = "disPic")
	public JSONObject disPic(@RequestParam(value = "key", required = false) String key,
			@RequestParam(value = "code", defaultValue = "0") Integer code,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page) {
		JSONObject jsonObject = new JSONObject();
		// if (StringUtils.isEmpty(key)) {
		// jsonObject.put("status", 302);// 参数不对----这里是检验key，暂时不进行安全性
		// return jsonObject;
		// }
		if (code == null) {
			jsonObject.put("status", 302);// 参数不对----这里是检验key，暂时不进行安全性
			return jsonObject;
		}

		jsonObject.put("status", 300);
		JSONArray jsonArray = new JSONArray();

		if (code == 0) {

			List<RecommondMerchandise> findRecommondByCodes = editMerchandiseListService.findRecommondByCode();

			if (findRecommondByCodes == null || findRecommondByCodes.size() == 0) {
				// jsonObject.put("status", 301);// 查询为空
				jsonObject.put("source", jsonArray);
				return jsonObject;
			}
			JSONObject source = new JSONObject();
			for (RecommondMerchandise r : findRecommondByCodes) {

				if (StringUtils.isNotEmpty(r.getRecommondMerchandisePicUrlAndId())) {
					source.put("editMerchandiseListId", r.getMerchandiseId());
				}
				jsonArray.add(source);
			}

		}
		if (code == 1) {

			Iterable<RecommondMerchandise> findRecommondByCode = editMerchandiseListService
					.findRecommondByCode(page - 1, 10);

			if (findRecommondByCode == null) {
				// jsonObject.put("status", 301);// 查询为空
				jsonObject.put("source", jsonArray);
				return jsonObject;
			}

			Iterator<RecommondMerchandise> iterator = findRecommondByCode.iterator();
			JSONObject source = new JSONObject();
			while (iterator.hasNext()) {

				RecommondMerchandise recommondMerchandise = iterator.next();
				if (recommondMerchandise == null) {
					continue;
				}

				if (StringUtils.isNotEmpty(recommondMerchandise.getRecommondMerchandiseHomeUrlAndId())) {
					source.put("editMerchandiseListId", recommondMerchandise.getMerchandiseId());
					jsonArray.add(source);
				}

			}
		}
		jsonObject.put("source", jsonArray);

		return jsonObject;

	}

	// 提供下载的图片展示接口
	// @RequestMapping(value = "downloadRecommond", method = RequestMethod.POST)
	@RequestMapping(value = "downloadRecommond")
	public void downloadRecommond(@RequestParam("id") Integer id, HttpServletResponse response) {

		// JSONObject jsonObject = new JSONObject();
		if (id == null) {
			// jsonObject.put("status", 302);// 参数不对
			return;
		}
		File file = null;
		RecommondMerchandise findRecommondMerchandiseById = editMerchandiseListService.findRecommondMerchandiseById(id);

		if (findRecommondMerchandiseById == null) {
			// jsonObject.put("status", 301);// 查询为空
			return;
		}
		if (StringUtils.isNotEmpty(findRecommondMerchandiseById.getRecommondMerchandisePicUrlAndId())) {
			file = new File(findRecommondMerchandiseById.getRecommondMerchandisePicUrlAndId().split("&")[0],
					findRecommondMerchandiseById.getRecommondMerchandisePicUrlAndId().split("&")[1]);
		}

		if (StringUtils.isNotEmpty(findRecommondMerchandiseById.getRecommondMerchandiseHomeUrlAndId())) {
			file = new File(findRecommondMerchandiseById.getRecommondMerchandiseHomeUrlAndId().split("&")[0],
					findRecommondMerchandiseById.getRecommondMerchandiseHomeUrlAndId().split("&")[1]);
		}

		if (!file.exists()) {
			// jsonObject.put("status", 301);// 查询为空
			return;
		}

		try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
				BufferedOutputStream fos = new BufferedOutputStream(response.getOutputStream())) {
			// 设置下载的保存格式
			// response.setHeader("Content-Disposition", "attachment;
			// filename=1.png");
			// response.setContentType("application/octet-stream;
			// charset=utf-8");
			byte[] bs = new byte[1024];
			int len = 0;
			while ((len = bis.read(bs)) != -1) {
				fos.write(bs, 0, len);
			}

		} catch (Exception e) {
		}

		return;

	}

	// 提供查看推荐商品信息
	@RequestMapping(value = "adminPass", method = RequestMethod.POST)
	public String checkAdmin(@RequestParam(value = "name", defaultValue = "") String adminName,
			@RequestParam(value = "pass", defaultValue = "") String adminPass, HttpServletRequest request) {
		if (!(adminName.matches("^((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\\d{8}$"))) {

			request.setAttribute("errorMsg", "密码或用户名不正确");
			return "index";
		}

		if (adminName.equals(AdminPass.getValue("adminName")) && adminPass.equals(AdminPass.getValue("adminPass"))) {
			HttpSession session = request.getSession();
			session.setAttribute(adminName, adminPass);
			request.setAttribute("phone", adminName);

			//// 展示所有，进行操作--暂时不开放
			// return REDIRECT + "/displayMerchant.action";

			return "creatMerchant";

		}

		if ("15924179757".equals(adminName) && "admin".equals(adminPass)) {
			HttpSession session = request.getSession();
			session.setAttribute("manager", adminPass);

			//// 展示所有，进行操作--暂时不开放
			// return REDIRECT + "/displayMerchant.action";
			return FORWARD + "/displayMerchant.action?pageNum=" + 1;

		}

		return "errorPage";

	}

	/*
	 * 测试
	 */
	@RequestMapping(value = "test", method = RequestMethod.POST)
	public String query(@RequestBody Test test) {

		System.out.println("into....." + test);
		return "suuccess";

	}

	/*
	 * 测试
	 */
	// @RequestMapping(value = "upload")
	// public String upload(@RequestParam("editMerchandiseRecord")
	// CommonsMultipartFile file) {
	//
	// System.out.println(file.getSize());
	// System.out.println("into.....");
	// return "suuccess";
	//
	// }
	@RequestMapping(value = "upload")
	public String upload(@RequestParam("file") MultipartFile[] files) {

		try {
			for (MultipartFile file : files) {
				file.transferTo(new File("C:\\Users\\Administrator\\Desktop\\test", file.getOriginalFilename()));
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		System.out.println("into.....");
		return "suuccess";

	}

	@RequestMapping(value = "download")
	public void download(@RequestParam(value = "path", required = false) String path, HttpServletResponse response) {

		if (StringUtils.isEmpty(path)) {
			path = "C:\\Users\\Administrator\\Desktop\\1.png";
		}

		File file = new File(path);

		if (!file.exists()) {
			path = "C:\\Users\\Administrator\\Desktop\\1.png";
			file = new File(path);
		}

		try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
				BufferedOutputStream fos = new BufferedOutputStream(response.getOutputStream())) {
			// 设置下载的保存格式
			// response.setHeader("Content-Disposition", "attachment;
			// filename=1.png");
			// response.setContentType("application/octet-stream;
			// charset=utf-8");
			byte[] bs = new byte[1024];
			int len = 0;
			while ((len = bis.read(bs)) != -1) {
				fos.write(bs, 0, len);
			}

		} catch (Exception e) {
		}

		try {
			BufferedImage source = ImageIO.read(file);
			BufferedOutputStream fos = new BufferedOutputStream(response.getOutputStream());
			fos.write(source.getWidth());
			fos.close();
		} catch (Exception e) {
		}

	}

	@RequestMapping(value = "down")
	public ResponseEntity<byte[]> down() {
		HttpHeaders headers = new HttpHeaders();
		byte[] bytes = null;

		try {
			// 设定下载的格式
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			headers.setContentDispositionFormData("attachment",
					new String("中文乱码测试的.jpg".getBytes("utf-8"), "iso8859-1"));

			bytes = FileUtils.readFileToByteArray(new File("C:\\Users\\Administrator\\Desktop\\1.png"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<byte[]>(bytes, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "uploadTest")
	public String upload(HttpServletRequest request) {
		// 创建文件项目工厂对象
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// 设置缓冲区大小为 5M
		factory.setSizeThreshold(1024 * 1024 * 5);
		// 获取系统默认的临时文件保存路径，该路径为Tomcat根目录下的temp文件夹
		String temp = System.getProperty("java.io.tmpdir");
		// 设置临时文件夹为temp
		factory.setRepository(new File(temp));
		// 用工厂实例化上传组件,ServletFileUpload 用来解析文件上传请求
		ServletFileUpload servletFileUpload = new ServletFileUpload(factory);

		List<FileItem> list;
		try {
			list = servletFileUpload.parseRequest(request);
			System.out.println(list);
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "suuccess";

	}

	public static void main(String[] args) {

	}

}
