package com.powermall.controller;

public class Test {
	private String province;

	private String city;
	private String country;

	private int starPage;

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getStarPage() {
		return starPage;
	}

	public void setStarPage(int starPage) {
		this.starPage = starPage;
	}

	@Override
	public String toString() {
		return "Test [province=" + province + ", city=" + city + ", country=" + country + ", starPage=" + starPage
				+ "]";
	}

}
