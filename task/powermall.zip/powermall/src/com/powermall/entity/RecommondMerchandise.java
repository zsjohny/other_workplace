package com.powermall.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class RecommondMerchandise {

	private Integer id;
	// 推荐的动态浏览id
	private Integer merchandiseId;
	private String recommondMerchandisePicUrlAndId;
	private String recommondMerchandiseHomeUrlAndId;

	private String code;

	@GeneratedValue
	@Id
	public Integer getId() {
		return id;
	}

	public Integer getMerchandiseId() {
		return merchandiseId;
	}

	public void setMerchandiseId(Integer merchandiseId) {
		this.merchandiseId = merchandiseId;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(length = 2000)
	public String getRecommondMerchandisePicUrlAndId() {
		return recommondMerchandisePicUrlAndId;
	}

	public void setRecommondMerchandisePicUrlAndId(String recommondMerchandisePicUrlAndId) {
		this.recommondMerchandisePicUrlAndId = recommondMerchandisePicUrlAndId;
	}

	@Column(length = 2000)
	public String getRecommondMerchandiseHomeUrlAndId() {
		return recommondMerchandiseHomeUrlAndId;
	}

	public void setRecommondMerchandiseHomeUrlAndId(String recommondMerchandiseHomeUrlAndId) {
		this.recommondMerchandiseHomeUrlAndId = recommondMerchandiseHomeUrlAndId;
	}

	@Column(length = 4)
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
