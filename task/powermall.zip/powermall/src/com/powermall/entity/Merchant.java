/**
 *
 */
package com.powermall.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author xiaoluo
 * @version $Id: Merchant.java, 2015年12月2日 下午4:26:17
 */
@Table(name = "merchant")
@Entity
public class Merchant {

	private Integer merchantId;
	private String merchantLoginName;
	private String merchantLoginPhone;
	private String merchantLoginIdCard;
	private String isRegist;
	private String isDeleted;
	private Date operateTime;
	private String operator;

	private String loginKey;

	// 地区
	private String province;

	private String city;
	private String country;

	// 店铺的名称
	private String merchantStoreName;

	@Column(length = 16)
	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	@Column(length = 40)
	public String getMerchantStoreName() {
		return merchantStoreName;
	}

	public void setMerchantStoreName(String merchantStoreName) {
		this.merchantStoreName = merchantStoreName;
	}

	@Column(length = 16)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(length = 16)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLoginKey() {
		return loginKey;
	}

	public void setLoginKey(String loginKey) {
		this.loginKey = loginKey;
	}

	@GeneratedValue
	@Id
	public Integer getMerchantId() {
		return merchantId;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Date getOperateTime() {
		return operateTime;
	}

	public void setOperateTime(Date operateTime) {
		this.operateTime = operateTime;
	}

	@Column(name = "is_deleted")
	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getMerchantLoginName() {
		return merchantLoginName;
	}

	public void setMerchantLoginName(String merchantLoginName) {
		this.merchantLoginName = merchantLoginName;
	}

	public String getMerchantLoginPhone() {
		return merchantLoginPhone;
	}

	@Column(name = "is_regist")
	public String getIsRegist() {
		return isRegist;
	}

	public void setIsRegist(String isRegist) {
		this.isRegist = isRegist;
	}

	public void setMerchantLoginPhone(String merchantLoginPhone) {
		this.merchantLoginPhone = merchantLoginPhone;
	}

	public String getMerchantLoginIdCard() {
		return merchantLoginIdCard;
	}

	public void setMerchantLoginIdCard(String merchantLoginIdCard) {
		this.merchantLoginIdCard = merchantLoginIdCard;
	}

}
