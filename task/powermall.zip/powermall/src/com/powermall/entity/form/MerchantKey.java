package com.powermall.entity.form;

public class MerchantKey {
	private String merchantPhone;
}
