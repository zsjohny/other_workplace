package com.powermall.entity.form;

public class ShoppingCarForm {

	private Integer merchandiseId;

	private Integer merchantId;

	private String customerPhone;

	public Integer getMerchandiseId() {
		return merchandiseId;
	}

	public void setMerchandiseId(Integer merchandiseId) {
		this.merchandiseId = merchandiseId;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

}
