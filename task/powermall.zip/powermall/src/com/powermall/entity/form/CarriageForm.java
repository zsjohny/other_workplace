package com.powermall.entity.form;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class CarriageForm {
	private Integer carriageId;

	@Size(min = 1, max = 40, message = "所填的城市不能超过50字")
	@NotEmpty(message = "所填的城市不能为空")
	private String carriageCity;

	private Double carriageFirstPay;

	private Double carriageLastPay;

	private String merchantPhone;
	private Integer carriageFirstCount;

	private Integer carriageLastCount;

	public Integer getCarriageId() {
		return carriageId;
	}

	public void setCarriageId(Integer carriageId) {
		this.carriageId = carriageId;
	}

	public String getMerchantPhone() {
		return merchantPhone;
	}

	public void setMerchantPhone(String merchantPhone) {
		this.merchantPhone = merchantPhone;
	}

	public String getCarriageCity() {
		return carriageCity;
	}

	public void setCarriageCity(String carriageCity) {
		this.carriageCity = carriageCity;
	}

	public Double getCarriageFirstPay() {
		return carriageFirstPay;
	}

	public void setCarriageFirstPay(Double carriageFirstPay) {
		this.carriageFirstPay = carriageFirstPay;
	}

	public Double getCarriageLastPay() {
		return carriageLastPay;
	}

	public void setCarriageLastPay(Double carriageLastPay) {
		this.carriageLastPay = carriageLastPay;
	}

	public Integer getCarriageFirstCount() {
		return carriageFirstCount;
	}

	public void setCarriageFirstCount(Integer carriageFirstCount) {
		this.carriageFirstCount = carriageFirstCount;
	}

	public Integer getCarriageLastCount() {
		return carriageLastCount;
	}

	public void setCarriageLastCount(Integer carriageLastCount) {
		this.carriageLastCount = carriageLastCount;
	}

	@Override
	public String toString() {
		return "CarriageForm [carriageCity=" + carriageCity + ", carriageFirstPay=" + carriageFirstPay
				+ ", carriageLastPay=" + carriageLastPay + "]";
	}

}
