package com.powermall.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Table(name = "eidtMerchandiseList")
@Entity
public class EditMerchandiseList {

	private Integer editMerchandiseListId;
	private String merchantPhone;
	private String editMerchandiseListDisPicsUrl;// (列表详情的展示图片)
	private String editMerchandiseListName;// (列表详情的名称)
	private Double editMerchandiseListPrice;// (列表详情的价格)
	private Integer editMerchandiseListStock;// (列表详情的库存)
	private String editMerchandiseListIsPost;// (列表详情的是否包邮)=ture or false
	private String editMerchandiseListProductDesc;// (列表详情的产品描述)
	private String editMerchandiseListDesPicsUrl;// (列表详情的描述图片)
	private String isDeleted;
	private String merchantFloderName;
	private String editMerchandiseRecordUrl;
	private String loginKey;

	private Integer starPage;
	private Integer starCount;
	private Integer count;
	private String orderSign;
	private String sequence;

	private Integer salesCount;

	private String shopperPhone;

	private String isRecommond;

	@GeneratedValue
	@Column(name = "editMerchandiseListId")
	@Id
	public Integer getEditMerchandiseListId() {
		return editMerchandiseListId;
	}
	// editMerchandiseListId bigInteger 4 0 0 -1 0 0 0 0 -1 0
	// merchantPhone varchar 16 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0
	// editMerchandiseListDisPicsUrl varchar 4000 0 -1 0 0 0 0 0 utf8
	// utf8_general_ci 0 0
	// editMerchandiseListName varchar 64 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0
	// 0
	// editMerchandiseListPrice double 6 3 -1 0 0 0 0 0 0 0
	// editMerchandiseListStock Integer 8 0 -1 0 0 0 0 0 0 0
	// editMerchandiseListIsPost varchar 8 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0
	// 0
	// editMerchandiseListProductDesc varchar 32 0 -1 0 0 0 0 0 utf8
	// utf8_general_ci 0 0
	// editMerchandiseListDesPicsUrl varchar 4000 0 -1 0 0 0 0 0 utf8
	// utf8_general_ci 0 0
	// is_deledted varchar 2 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0
	// merchantFloderName varchar 32 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0
	// createTime date 0 0 -1 0 0 0 0 0 0 0
	// modifyTime date 0 0 -1 0 0 0 0 0 0 0
	// editMerchandiseRecordUrl varchar 512 0 -1 0 0 0 0 0 utf8 utf8_general_ci
	// 0 0
	// salesCount Integer 10 0 -1 0 0 0 0 0 0 0
	// shopperPhone mediumtext 0 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0
	// loginKey varchar 1024 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0
	// merchantLoginName varchar 255 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0
	// remark mediumtext 0 0 -1 0 0 0 0 0 utf8 utf8_general_ci 0 0

	public void setEditMerchandiseListId(Integer editMerchandiseListId) {
		this.editMerchandiseListId = editMerchandiseListId;
	}

	@Column(name = "merchantPhone", length = 11)
	public String getMerchantPhone() {
		return merchantPhone;
	}

	public void setMerchantPhone(String merchantPhone) {
		this.merchantPhone = merchantPhone;
	}

	@Column(name = "editMerchandiseListDisPicsUrl", length = 4000)
	public String getEditMerchandiseListDisPicsUrl() {
		return editMerchandiseListDisPicsUrl;
	}

	public void setEditMerchandiseListDisPicsUrl(String editMerchandiseListDisPicsUrl) {
		this.editMerchandiseListDisPicsUrl = editMerchandiseListDisPicsUrl;
	}

	@Column(name = "editMerchandiseListName", length = 64)
	public String getEditMerchandiseListName() {
		return editMerchandiseListName;
	}

	public void setEditMerchandiseListName(String editMerchandiseListName) {
		this.editMerchandiseListName = editMerchandiseListName;
	}

	@Column(name = "editMerchandiseListPrice", length = 6)
	public Double getEditMerchandiseListPrice() {
		return editMerchandiseListPrice;
	}

	public void setEditMerchandiseListPrice(Double editMerchandiseListPrice) {
		this.editMerchandiseListPrice = editMerchandiseListPrice;
	}

	@Column(name = "editMerchandiseListStock", length = 8)
	public Integer getEditMerchandiseListStock() {
		return editMerchandiseListStock;
	}

	public void setEditMerchandiseListStock(Integer editMerchandiseListStock) {
		this.editMerchandiseListStock = editMerchandiseListStock;
	}

	@Column(name = "editMerchandiseListIsPost", length = 8)
	public String getEditMerchandiseListIsPost() {
		return editMerchandiseListIsPost;
	}

	public void setEditMerchandiseListIsPost(String editMerchandiseListIsPost) {
		this.editMerchandiseListIsPost = editMerchandiseListIsPost;
	}

	@Column(name = "editMerchandiseListProductDesc", length = 32)
	public String getEditMerchandiseListProductDesc() {
		return editMerchandiseListProductDesc;
	}

	public void setEditMerchandiseListProductDesc(String editMerchandiseListProductDesc) {
		this.editMerchandiseListProductDesc = editMerchandiseListProductDesc;
	}

	@Column(name = "editMerchandiseListDesPicsUrl", length = 4000)
	public String getEditMerchandiseListDesPicsUrl() {
		return editMerchandiseListDesPicsUrl;
	}

	public void setEditMerchandiseListDesPicsUrl(String editMerchandiseListDesPicsUrl) {
		this.editMerchandiseListDesPicsUrl = editMerchandiseListDesPicsUrl;
	}

	@Column(name = "merchantFloderName", length = 32)
	public String getMerchantFloderName() {
		return merchantFloderName;
	}

	@Column(name = "is_deledted", length = 4)
	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public void setMerchantFloderName(String merchantFloderName) {
		this.merchantFloderName = merchantFloderName;
	}

	@Column(name = "editMerchandiseRecordUrl", length = 512)
	public String getEditMerchandiseRecordUrl() {
		return editMerchandiseRecordUrl;
	}

	public void setEditMerchandiseRecordUrl(String editMerchandiseRecordUrl) {
		this.editMerchandiseRecordUrl = editMerchandiseRecordUrl;
	}

	@Transient
	// @Column(name = "loginKey", length = 1024)
	public String getLoginKey() {
		return loginKey;
	}

	public void setLoginKey(String loginKey) {
		this.loginKey = loginKey;
	}

	@Transient
	public Integer getStarPage() {
		return starPage;
	}

	public void setStarPage(Integer starPage) {
		this.starPage = starPage;
	}

	@Transient
	public Integer getStarCount() {
		return starCount;
	}

	public void setStarCount(Integer starCount) {
		this.starCount = starCount;
	}

	@Transient
	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	@Transient
	public String getOrderSign() {
		return orderSign;
	}

	public void setOrderSign(String orderSign) {
		this.orderSign = orderSign;
	}

	@Transient
	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	@Column(name = "salesCount", length = 10)
	public Integer getSalesCount() {
		return salesCount;
	}

	public void setSalesCount(Integer salesCount) {
		this.salesCount = salesCount;
	}

	@Column(name = "shopperPhone", length = 129996)
	public String getShopperPhone() {
		return shopperPhone;
	}

	public void setShopperPhone(String shopperPhone) {
		this.shopperPhone = shopperPhone;
	}

	@Column(length = 4, name = "isRecommond")
	public String getIsRecommond() {
		return isRecommond;
	}

	public void setIsRecommond(String isRecommond) {
		this.isRecommond = isRecommond;
	}

}
