package com.powermall.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "carriage")
@Entity
public class Carriage {
	private Integer carriageId;

	private String carriageCity;

	private Integer carriageFirstCount;
	private Double carriageFirstPay;

	private Integer carriageLastCount;
	private Double carriageLastPay;

	private String merchantPhone;
	private String isDeleted;
	private Date createTime;
	private Date modifyTime;

	@Column(name = "carriage_id")
	@GeneratedValue
	@Id
	public Integer getCarriageId() {
		return carriageId;
	}

	public void setCarriageId(Integer carriageId) {
		this.carriageId = carriageId;
	}

	@Column(name = "carriage_city", length = 50)
	public String getCarriageCity() {
		return carriageCity;
	}

	public void setCarriageCity(String carriageCity) {
		this.carriageCity = carriageCity;
	}

	@Column(name = "carriage_first_pay")
	public Double getCarriageFirstPay() {
		return carriageFirstPay;
	}

	public void setCarriageFirstPay(Double carriageFirstPay) {
		this.carriageFirstPay = carriageFirstPay;
	}

	@Column(name = "carriage_last_pay")
	public Double getCarriageLastPay() {
		return carriageLastPay;
	}

	public void setCarriageLastPay(Double carriageLastPay) {
		this.carriageLastPay = carriageLastPay;
	}

	@Column(name = "is_deleted")
	public String getIsDeleted() {
		return isDeleted;
	}

	@Column(name = "merchant_phone")
	public String getMerchantPhone() {
		return merchantPhone;
	}

	public void setMerchantPhone(String merchantPhone) {
		this.merchantPhone = merchantPhone;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	@Column(name = "create_Time")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "modify_Time")
	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Integer getCarriageFirstCount() {
		return carriageFirstCount;
	}

	public void setCarriageFirstCount(Integer carriageFirstCount) {
		this.carriageFirstCount = carriageFirstCount;
	}

	public Integer getCarriageLastCount() {
		return carriageLastCount;
	}

	public void setCarriageLastCount(Integer carriageLastCount) {
		this.carriageLastCount = carriageLastCount;
	}

	@Override
	public String toString() {
		return "Carriage [carriageId=" + carriageId + ", carriageCity=" + carriageCity + ", carriageFirstPay="
				+ carriageFirstPay + ", carriageLastPay=" + carriageLastPay + "]";
	}

}
