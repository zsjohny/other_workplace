package com.powermall.entity.conver;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;

import com.powermall.entity.Carriage;
import com.powermall.entity.form.CarriageForm;

public class CarriageFormConverDataSource {

	public static Carriage formConverData(CarriageForm carriageForm)
			throws IllegalAccessException, InvocationTargetException {
		Carriage carriage = new Carriage();

		if (carriageForm == null) {
			return carriage;
		}

		BeanUtils.copyProperties(carriage, carriageForm);
		return carriage;
	}

}
