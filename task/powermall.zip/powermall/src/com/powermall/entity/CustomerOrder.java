package com.powermall.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "customerorder")
@Entity
public class CustomerOrder {

	private Integer customerOrderId;
	private Integer merchandiseId;
	private String orderStatus; // 为每个买家对应的订单状态：start是待发货，run是已发货 ，end是已确定收货
	private String orderDatemine;// 为每个买家对应的订单倒数时间,over是已经确定收货了,其余例如6天19小时23分--截取分钟倒计时
	private String orderEms;// 商品发货物流或快递公司
	private String orderStream; // 商品发货物流
	private String orderCusName; // 收货人姓名
	private String orderCusPhone; // 收货人手机
	private String orderCusAddress;// 收货人地址
	private Double orderMeDisPic; // 商品展示图片地址
	private String orderMeName;// 商品的名称
	private Double orderMePrice; // 商品的价格
	private Integer orderMeCount; // 商品的单价
	private String orderMePayTra;// 商品的运费
	private String orderMePayMed; // 商品的支付金额
	private String orderNumber; // 商品的订单号
	private String orderPhone; // 商品的订货人手机号
	private String orderTime; // 为每个买家购买的时间
	private String isDeleted;
	private Date creatTime;
	private Date operateTime;

	@GeneratedValue
	@Id
	public Integer getCustomerOrderId() {
		return customerOrderId;
	}

	public void setCustomerOrderId(Integer customerOrderId) {
		this.customerOrderId = customerOrderId;
	}

	@Column(length = 12)
	public String getOrderStatus() {
		return orderStatus;
	}

	public Integer getMerchandiseId() {
		return merchandiseId;
	}

	public void setMerchandiseId(Integer merchandiseId) {
		this.merchandiseId = merchandiseId;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Column(length = 32)
	public String getOrderDatemine() {
		return orderDatemine;
	}

	public void setOrderDatemine(String orderDatemine) {
		this.orderDatemine = orderDatemine;
	}

	@Column(length = 98)
	public String getOrderEms() {
		return orderEms;
	}

	public void setOrderEms(String orderEms) {
		this.orderEms = orderEms;
	}

	@Column(length = 102)
	public String getOrderStream() {
		return orderStream;
	}

	public void setOrderStream(String orderStream) {
		this.orderStream = orderStream;
	}

	@Column(length = 52)
	public String getOrderCusName() {
		return orderCusName;
	}

	public void setOrderCusName(String orderCusName) {
		this.orderCusName = orderCusName;
	}

	@Column(length = 11)
	public String getOrderCusPhone() {
		return orderCusPhone;
	}

	public void setOrderCusPhone(String orderCusPhone) {
		this.orderCusPhone = orderCusPhone;
	}

	@Column(length = 102)
	public String getOrderCusAddress() {
		return orderCusAddress;
	}

	public void setOrderCusAddress(String orderCusAddress) {
		this.orderCusAddress = orderCusAddress;
	}

	@Column(length = 15)
	public String getOrderMeName() {
		return orderMeName;
	}

	@Column(length = 6)
	public Double getOrderMeDisPic() {
		return orderMeDisPic;
	}

	public void setOrderMeDisPic(Double orderMeDisPic) {
		this.orderMeDisPic = orderMeDisPic;
	}

	public void setOrderMeName(String orderMeName) {
		this.orderMeName = orderMeName;
	}

	@Column(length = 6)
	public Double getOrderMePrice() {
		return orderMePrice;
	}

	public void setOrderMePrice(Double orderMePrice) {
		this.orderMePrice = orderMePrice;
	}

	@Column(length = 4)
	public Integer getOrderMeCount() {
		return orderMeCount;
	}

	public void setOrderMeCount(Integer orderMeCount) {
		this.orderMeCount = orderMeCount;
	}

	public String getOrderMePayTra() {
		return orderMePayTra;
	}

	public void setOrderMePayTra(String orderMePayTra) {
		this.orderMePayTra = orderMePayTra;
	}

	@Column(length = 512)
	public String getOrderMePayMed() {
		return orderMePayMed;
	}

	public void setOrderMePayMed(String orderMePayMed) {
		this.orderMePayMed = orderMePayMed;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	@Column(length = 11)
	public String getOrderPhone() {
		return orderPhone;
	}

	public void setOrderPhone(String orderPhone) {
		this.orderPhone = orderPhone;
	}

	@Column(length = 52)
	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	@Column(length = 4)
	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Date getCreatTime() {
		return creatTime;
	}

	public void setCreatTime(Date creatTime) {
		this.creatTime = creatTime;
	}

	public Date getOperateTime() {
		return operateTime;
	}

	public void setOperateTime(Date operateTime) {
		this.operateTime = operateTime;
	}

}
