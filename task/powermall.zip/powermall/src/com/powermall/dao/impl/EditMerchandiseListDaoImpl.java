package com.powermall.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Repository;

import com.powermall.dao.EditMerchandiseListDao;
import com.powermall.entity.EditMerchandiseList;
import com.powermall.entity.RecommondMerchandise;
import com.powermall.repository.EditMerchandiseListPageRepository;
import com.powermall.repository.EditMerchandiseListRepository;
import com.powermall.repository.MerchandiseRepository;
import com.powermall.repository.RecommondMerchandiseCrudRepository;
import com.powermall.repository.RecommondMerchandisePageRepository;
import com.powermall.repository.RecommondMerchandiseRepository;

@Repository
public class EditMerchandiseListDaoImpl implements EditMerchandiseListDao {
	@Resource
	private EditMerchandiseListPageRepository editMerchandiseListPageRepository;
	@Resource
	private EditMerchandiseListRepository editMerchandiseListRepository;
	@Resource
	private RecommondMerchandiseCrudRepository recommondMerchandiseCrudRepository;
	@Resource
	private RecommondMerchandiseRepository recommondMerchandiseRepository;
	@Resource
	private RecommondMerchandisePageRepository recommondMerchandisePageRepository;
	@Resource
	private MerchandiseRepository merchandiseRepository;

	public Iterable<EditMerchandiseList> findMerchandiseAllByPhone(int startPage, int pageSize) {
		// int starPage = (startPage - 1) * pageSize;
		// return
		// editMerchandiseListRepository.finAllByEditMerchandise(starPage,
		// pageSize);

		Sort sort = new Sort(Direction.ASC, "isDeleted");
		Pageable pageable = new PageRequest(startPage, pageSize, sort);
		// Pageable pageable = new PageRequest(startPage, pageSize);
		return editMerchandiseListPageRepository.findAll(pageable);

	}

	@Override
	public long findCount() {

		// return editMerchandiseListPageRepository.count();
		return editMerchandiseListRepository.finAllByEditMerchandise();
	}

	public void saveRecommond(RecommondMerchandise recommondMerchandise) {
		recommondMerchandiseCrudRepository.save(recommondMerchandise);

	}

	public Iterable<RecommondMerchandise> findRecommondByCode(int page, int size) {
		Sort sort = new Sort(Direction.DESC, "code");
		Pageable pageable = new PageRequest(page, size, sort);
		return recommondMerchandisePageRepository.findAll(pageable);
	}

	public List<RecommondMerchandise> findRecommondByCode() {

		return recommondMerchandiseRepository.findRecommondByCode();
	}

	public EditMerchandiseList findMerchandiseById(Integer id) {
		return editMerchandiseListPageRepository.findOne(id);
	}

	public void updateMerchandiseByRecommond(String status, Integer id) {

		merchandiseRepository.updateMerchandiseByRecommond(status, id);

	}

	public RecommondMerchandise findRecommondMerchandiseById(Integer id) {
		return recommondMerchandiseRepository.findRecommondMerchandiseById(id);
	}

	public void deleteRecommondById(Integer id) {
		recommondMerchandiseRepository.deleteRecommondById(id);
	}

	@Override
	public EditMerchandiseList findEditMerchandiseById(Integer id) {

		return editMerchandiseListRepository.findEditMerchandiseById(id);
	}

}
