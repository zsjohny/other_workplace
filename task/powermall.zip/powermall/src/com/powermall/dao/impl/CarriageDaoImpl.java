package com.powermall.dao.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.powermall.dao.CarriageDao;
import com.powermall.entity.Carriage;
import com.powermall.entity.conver.CarriageFormConverDataSource;
import com.powermall.entity.form.CarriageForm;
import com.powermall.repository.CarriageCrudRepository;
import com.powermall.repository.CarriageRepository;

@Repository
public class CarriageDaoImpl implements CarriageDao {
	@Resource
	private CarriageCrudRepository carriageCrudRepository;
	@Resource
	private CarriageRepository carriageRepository;

	@Override
	public Boolean eidtCarriage(CarriageForm carriageForm) {
		try {
			Carriage carriage = CarriageFormConverDataSource.formConverData(carriageForm);
			if (carriage == null) {
				return false;
			}
			carriage.setIsDeleted("0");

			if (carriage.getCarriageId() == 0) {
				carriage.setCreateTime(new Date());

			} else {
				Carriage queryCarriage = carriageRepository.queryCarriageById(carriage.getCarriageId(),
						carriage.getMerchantPhone());

				if (queryCarriage == null) {
					return false;
				}
				carriage.setCreateTime(queryCarriage.getCreateTime());
				carriage.setModifyTime(new Date());

			}

			carriageCrudRepository.save(carriage);

		} catch (Exception e) {

		}
		return true;
	}

	@Override
	public List<Carriage> queryByMerchantPhone(String merchantPhone) {

		return carriageRepository.queryCarriageByMerchantPhone(merchantPhone);
	}

	@Override
	public Boolean deleteCarriage(Integer carriageId, String merchantPhone) {
		Carriage carriage = carriageRepository.queryCarriageById(carriageId, merchantPhone);
		if (carriage == null) {
			return false;
		} else {
			carriageRepository.deleteCarriageById(carriageId, merchantPhone);
			return true;
		}

	}

}
