package com.powermall.dao.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.powermall.dao.ShoppingCarDao;
import com.powermall.entity.ShoppingCar;
import com.powermall.repository.ShoppingCarPageRepository;
import com.powermall.repository.ShoppingCarRepository;

@Repository
public class ShoppingCarDaoImpl implements ShoppingCarDao {
	@Resource
	private ShoppingCarPageRepository shoppingCarPageRepository;
	@Resource
	private ShoppingCarRepository shoppingCarRepository;

	@Override
	public List<ShoppingCar> findOderInfosByAll(String phone) {

		return shoppingCarRepository.findOderInfosByAll(phone);
	}

	@Override
	public void deleteOrder(Integer id) {

		Date date = new Date();
		shoppingCarRepository.deleteOrder(id, date);
	}

	@Override
	public void saveOrderInfo(ShoppingCar shoppingCar) {
		shoppingCarPageRepository.save(shoppingCar);
	}

	@Override
	public Integer findCountById(String phone) {

		return shoppingCarRepository.findCountById(phone);
	}

}
