package com.powermall.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.powermall.dao.MerchantDao;
import com.powermall.entity.Merchant;
import com.powermall.repository.MerchantCrudRepository;
import com.powermall.repository.MerchantRepository;

/**
 * Created by xiaoluo on 2015/12/22.
 */
@Repository
public class MerchantDaoImpl implements MerchantDao {
	@Autowired
	private MerchantCrudRepository merchantCrudRepository;
	@Autowired
	private MerchantRepository merchantRepository;

	@Override
	public void createMerchantByAdmin(Merchant merchant) {

		merchantCrudRepository.save(merchant);
	}

	@Override
	public Merchant queryMerchant(String phone) {

		return merchantRepository.queryMerchant(phone);
	}

	@Override
	public List<Merchant> queryMertchantByAll() {

		return merchantRepository.queryMertchantByAll();
	}

	@Override
	public List<Merchant> queryMertchantPhoneById(Integer id) {

		return merchantRepository.queryMertchantPhoneById(id);
	}
}
