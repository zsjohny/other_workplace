package com.powermall.dao;

import java.util.List;

import com.powermall.entity.ShoppingCar;

public interface ShoppingCarDao {

	List<ShoppingCar> findOderInfosByAll(String phone);

	void deleteOrder(Integer id);

	void saveOrderInfo(ShoppingCar shoppingCar);

	Integer findCountById(String phone);
}
