package com.powermall.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.powermall.entity.Carriage;

public interface CarriageRepository extends Repository<Carriage, Integer> {
	@Query("from Carriage  where merchantPhone = ?1 and isDeleted = '0'")
	List<Carriage> queryCarriageByMerchantPhone(String merchantPhone);

	@Modifying
	@Query("update Carriage set isDeleted = '1' where  carriageId=:id  and merchantPhone =:phone")
	void deleteCarriageById(@Param("id") Integer carriageId, @Param("phone") String merchantPhone);

	@Query("from Carriage  where carriageId =:id and isDeleted = '0' and merchantPhone =:phone")
	Carriage queryCarriageById(@Param("id") Integer carriageId, @Param("phone") String merchantPhone);

}
