package com.powermall.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.powermall.entity.HuanXin;

public interface HuanXinCrudRepository extends JpaRepository<HuanXin, Integer> {

}
