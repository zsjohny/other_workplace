package com.powermall.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;

import com.powermall.entity.HuanXin;

@RepositoryDefinition(domainClass = HuanXin.class, idClass = Integer.class)
public interface HuanXinRepository {
	@Query("from HuanXin where ownerId=?1 ")
	HuanXin queryIsExist(Integer ownerId);
}
