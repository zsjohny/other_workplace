package com.powermall.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.powermall.entity.ShoppingCar;

public interface ShoppingCarPageRepository extends JpaRepository<ShoppingCar, Integer> {

}
