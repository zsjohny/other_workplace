package com.powermall.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.powermall.entity.RecommondMerchandise;

public interface RecommondMerchandisePageRepository extends JpaRepository<RecommondMerchandise, Integer> {

}
