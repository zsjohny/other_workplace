package com.powermall.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.powermall.entity.EditMerchandiseList;

//@RepositoryDefinition(domainClass = EditMerchandiseList.class, idClass = Integer.class)
public interface MerchandiseRepository extends Repository<EditMerchandiseList, Integer> {
	@Modifying
	@Query("update EditMerchandiseList set isRecommond =:status where  editMerchandiseListId=:id ")
	public void updateMerchandiseByRecommond(@Param("status") String status, @Param("id") Integer id);

}
