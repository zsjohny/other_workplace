package com.powermall.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.powermall.entity.EditMerchandiseList;

//@RepositoryDefinition(domainClass =, idClass = )
public interface EditMerchandiseListPageRepository extends JpaRepository<EditMerchandiseList, Integer> {

}
