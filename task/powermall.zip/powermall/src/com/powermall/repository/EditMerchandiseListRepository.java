package com.powermall.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;

import com.powermall.entity.EditMerchandiseList;

@RepositoryDefinition(domainClass = EditMerchandiseList.class, idClass = Integer.class)
public interface EditMerchandiseListRepository {
	@Query(" select count(*) from EditMerchandiseList where is_deledted ='0' ")
	Integer finAllByEditMerchandise();

	@Query(" from EditMerchandiseList where editMerchandiseListId=? and is_deledted ='0' ")
	EditMerchandiseList findEditMerchandiseById(Integer id);
}
