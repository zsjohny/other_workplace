package com.powermall.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;

import com.powermall.entity.ShoppingCar;

@RepositoryDefinition(domainClass = ShoppingCar.class, idClass = Integer.class)
public interface ShoppingCarRepository {

	@Query("from ShoppingCar where  customerPhone =:phone and  isDeleted ='0' ")
	List<ShoppingCar> findOderInfosByAll(@Param("phone") String phone);

	@Modifying
	@Query("update ShoppingCar set isDeleted ='1' ,modifyTime =:date where  shoppingCarId =:id   ")
	void deleteOrder(@Param("id") Integer id, @Param("date") Date date);

	@Query(" select count(shoppingCarId) from ShoppingCar where  customerPhone =:phone and  isDeleted ='0' ")
	Integer findCountById(@Param("phone") String phone);
}
