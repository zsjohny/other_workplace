package com.powermall.repository;

import org.springframework.data.repository.CrudRepository;

import com.powermall.entity.Carriage;

public interface CarriageCrudRepository extends CrudRepository<Carriage, Integer> {

}
