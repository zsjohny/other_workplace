package com.powermall.repository;

import com.powermall.entity.Merchant;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by xiaoluo on 2015/12/22.
 */
public interface MerchantCrudRepository extends CrudRepository<Merchant,Integer> {

}
