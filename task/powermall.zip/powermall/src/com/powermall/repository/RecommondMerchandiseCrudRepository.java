package com.powermall.repository;

import org.springframework.data.repository.CrudRepository;

import com.powermall.entity.RecommondMerchandise;

public interface RecommondMerchandiseCrudRepository extends CrudRepository<RecommondMerchandise, Integer> {

}
