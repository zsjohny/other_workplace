package com.powermall.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.powermall.entity.RecommondMerchandise;

public interface RecommondMerchandiseRepository extends Repository<RecommondMerchandise, Integer> {
	@Query("from RecommondMerchandise where merchandiseId =? ")
	RecommondMerchandise findRecommondMerchandiseById(Integer id);

	@Modifying
	@Query("delete from RecommondMerchandise where  merchandiseId=:id ")
	public void deleteRecommondById(@Param("id") Integer id);

	@Query("from RecommondMerchandise where code ='0' ")
	List<RecommondMerchandise> findRecommondByCode();

}
