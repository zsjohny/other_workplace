package com.powermall.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;

import com.powermall.entity.Merchant;

/**
 * Created by xiaoluo on 2015/12/22.
 */
@RepositoryDefinition(domainClass = Merchant.class, idClass = Integer.class)
public interface MerchantRepository {

	@Query("from Merchant where merchantLoginPhone=?1 and is_deleted='0'")
	Merchant queryMerchant(String phone);

	@Query("from Merchant where is_deleted='0'")
	List<Merchant> queryMertchantByAll();

	@Query("from Merchant where is_deleted='0' and merchantId=?")
	List<Merchant> queryMertchantPhoneById(Integer id);

}
