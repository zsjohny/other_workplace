// Place your Spring DSL code here

import com.gugu.UserService

beans = {

    userService(UserService)
}
