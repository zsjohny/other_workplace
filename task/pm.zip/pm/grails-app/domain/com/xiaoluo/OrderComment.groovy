package com.xiaoluo

class OrderComment {
    String customerPhone
    String customerContent
    String customerOrderInfo
    Long merchandiseId
    String isDeleted
    static mapping = {
        customerPhone length: 11
        customerContent length: 50
        customerOrderInfo length: 100
        isDeleted length: 4


    }
    static constraints = {
        customerPhone(nullable: true)
        customerContent(nullable: true)
        customerOrderInfo(nullable: true)
        merchandiseId(nullable: true)
        isDeleted(nullable: true)

    }
}
