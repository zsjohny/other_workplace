package com.xiaoluo

class GoodsAddress {

    String customerName
    String customerPhone
    String customerArea
    String customerAddress
    String consigneePhone
    String defaultAddress
    String isDeleted
    static mapping = {


    }

    static constraints = {
        customerName(nullable: true)
        customerPhone(nullable: true)
        customerArea(nullable: true)
        customerAddress(nullable: true)
        consigneePhone(nullable: true)
        defaultAddress(nullable: true)
        isDeleted(nullable: true)
    }
}
