package com.xiaoluo

class EidtMerchandiselist {

    String remark
    String isDeleted
    String shopperPhone
    static mapping = {
        version false
        table 'eidtmerchandiselist'
        id column: 'editMerchandiseListId'
        isDeleted column: 'is_deledted'
        shopperPhone column: 'shopperPhone', length: 26777216
        remark column: 'remark', length: 16777216

    }
    static constraints = {
        shopperPhone(nullable: true)
        remark(nullable: true)
        isDeleted(nullable: true)
    }
}
