package com.xiaoluo

class Customer {
    //原版中信息

    String orderInfos
    Date createTime
    Date modifyTime
    String is_deledted

    //新增的关联
    String customerPhone
    String customerHeadUrl
    String customerNickName
    String customerSex
    String customerPassword
    String customerHome

    //积分
    Integer customerScore
    String customerUseDays
    String nowDay

    static mapping = {
        version false
        table 'customer'
        id column: 'customerId'
        orderInfos column: 'orderInfos', length: 4080
        customerPhone column: 'customerPhone', length: 11
        createTime column: 'createTime'
        modifyTime column: 'modifyTime'
        is_deledted column: 'is_deledted'


    }

    static constraints = {


        orderInfos(nullable: true)
        createTime(nullable: true)
        modifyTime(nullable: true)
        is_deledted(nullable: true)
        customerPhone(nullable: true)
        customerHeadUrl(nullable: true)
        customerNickName(nullable: true)
        customerSex(nullable: true)
        customerPassword(nullable: true)
        customerHome(nullable: true)
        customerScore(nullable: true)
        customerUseDays(nullable: true)
        nowDay(nullable: true)
    }
}
