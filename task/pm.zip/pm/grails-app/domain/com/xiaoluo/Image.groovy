package com.xiaoluo

class Image {
    byte[] imageFile
    static constraints = {
        imageFile maxSize: 1024 * 1024 * 2
    }
}
