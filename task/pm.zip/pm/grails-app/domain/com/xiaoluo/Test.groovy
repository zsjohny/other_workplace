package com.xiaoluo

class Test {
    String name
    String gender
    static constraints = {
    }


}
