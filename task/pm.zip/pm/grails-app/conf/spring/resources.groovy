// Place your Spring DSL code here

import com.xiaoluo.CustomerService
import com.xiaoluo.EidtMerchandiselistService
import com.xiaoluo.GoodsAddressService

beans = {
    //添加service的注入
    customerService(CustomerService)

    goodsAddressService(GoodsAddressService)

    eidtMerchandiselistService(EidtMerchandiselistService)

}
