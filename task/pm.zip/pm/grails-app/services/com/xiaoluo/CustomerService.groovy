package com.xiaoluo

import grails.transaction.Transactional
import org.apache.commons.lang.StringUtils

@Transactional
class CustomerService {
    //新增和修改
    def save = {
        customer ->

//            def queryCustomer = Customer.findAll("from Customer c where c.customerPhone =?  ", [customer.getCustomerPhone()])
            def result
            //自定义查询的时候，所查看的字段都是实体类的字段
            Customer queryCustomer = Customer.find("from Customer c where c.id =?  and  c.customerPhone =? and c.is_deledted='0' ", [customer.getId(), customer.getCustomerPhone()])
            if (queryCustomer) {


                customer.getVersion() ? queryCustomer.setVersion(customer.getVersion()) : ''
                customer.getCreateTime() ? queryCustomer.setCreateTime(customer.getCreateTime()) : ''
                customer.getCustomerHeadUrl() ? queryCustomer.setCustomerHeadUrl(customer.getCustomerHeadUrl()) : ''
                customer.getCustomerHome() ? queryCustomer.setCustomerHome(customer.getCustomerHome()) : ''
                customer.getCustomerNickName() ? queryCustomer.setCustomerNickName(customer.getCustomerNickName()) : ''
                customer.setCustomerPassword() ? queryCustomer.setCustomerPassword(customer.getCustomerPassword()) : ''
                customer.getCustomerPhone() ? queryCustomer.setCustomerPhone(customer.getCustomerPhone()) : ''
                customer.getCustomerScore() ? queryCustomer.setCustomerScore(customer.getCustomerScore()) : ''
                customer.getCustomerSex() ? queryCustomer.setCustomerSex(customer.getCustomerSex()) : ''
                customer.getCustomerUseDays() ? queryCustomer.setCustomerUseDays(customer.getCustomerUseDays()) : ''
                customer.getModifyTime() ? queryCustomer.setModifyTime(customer.getModifyTime()) : ''
                customer.getOrderInfos() ? queryCustomer.setOrderInfos(customer.getOrderInfos()) : ''
                customer.getNowDay() ? queryCustomer.setNowDay(customer.getNowDay()) : ''

                if (!(StringUtils.isEmpty(queryCustomer.getCustomerHeadUrl()))) {

                    //只保存当前图片
                    def filePath = queryCustomer.getCustomerHeadUrl().substring(0, queryCustomer.getCustomerHeadUrl().lastIndexOf('\\'))
                    def fileName = queryCustomer.getCustomerHeadUrl().substring(queryCustomer.getCustomerHeadUrl().lastIndexOf('\\') + 1)

                    File[] fils = new File(filePath).listFiles()

                    fils.each {
                        if (!(it.getName().equals(fileName))) {
                            System.gc()
                            it.delete()
                        }

                    }
                }
                result = queryCustomer.save()

                return result
            }

            def checkPhoneIsExist = Customer.findAll("from Customer c where c.customerPhone =?  and c.is_deledted='0' ", [customer.getCustomerPhone()])

            if (checkPhoneIsExist == null || checkPhoneIsExist.size() == 0) {
                result = customer.save()
            } else {
                if (!(StringUtils.isEmpty(customer.getCustomerHeadUrl()))) {
                    //只保存服务图片
                    def filePath = customer.getCustomerHeadUrl().substring(0, customer.getCustomerHeadUrl().lastIndexOf('\\'))
                    def fileName = customer.getCustomerHeadUrl().substring(customer.getCustomerHeadUrl().lastIndexOf('\\') + 1)

                    File[] fils = new File(filePath).listFiles()


                    fils.each {


                        if (it.getName().equals(fileName)) {

                            System.gc()
                            it.delete()
                        }

                    }


                    result = null
                }
            }

            result


    }

    //根据手机号查询
    def queryCustomerByPhone = {
        Customer customer = Customer.find("from Customer c where c.customerPhone =:phone  and c.is_deledted='0'", [phone: it])
        customer

    }


}
