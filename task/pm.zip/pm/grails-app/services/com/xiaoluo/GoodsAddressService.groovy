package com.xiaoluo

import grails.transaction.Transactional

@Transactional
class GoodsAddressService {

    def createGoodsAddress = {
        goodsAddress ->

            def save
            def checkPhoneIsExist = Customer.findAll("from Customer c where c.customerPhone =?  and c.is_deledted='0' ", [goodsAddress.getConsigneePhone()])

            if (checkPhoneIsExist == null || checkPhoneIsExist.size() == 0) {
                return save
            }

            GoodsAddress queryGoods = GoodsAddress.find("from GoodsAddress g where g.id=:id and g.consigneePhone=:phone and g.isDeleted='0' ", [id: goodsAddress.getId(), phone: goodsAddress.getConsigneePhone()])

            if (queryGoods) {
                goodsAddress.getVersion() ? queryGoods.setVersion(goodsAddress.getVersion()) : ''
                goodsAddress.getCustomerName() ? queryGoods.setCustomerName(goodsAddress.getCustomerName()) : ''
                goodsAddress.getCustomerPhone() ? queryGoods.setCustomerPhone(goodsAddress.getCustomerPhone()) : ''
                goodsAddress.getCustomerAddress() ? queryGoods.setCustomerAddress(goodsAddress.getCustomerAddress()) : ''
                goodsAddress.getCustomerArea() ? queryGoods.setCustomerArea(goodsAddress.getCustomerArea()) : ''
                goodsAddress.getConsigneePhone() ? queryGoods.setConsigneePhone(goodsAddress.getConsigneePhone()) : ''
                goodsAddress.getDefaultAddress() ? queryGoods.setDefaultAddress(goodsAddress.getDefaultAddress()) : ''
                goodsAddress.getIsDeleted() ? queryGoods.setIsDeleted(goodsAddress.getIsDeleted()) : ''


                if ('0'.equals(goodsAddress.getDefaultAddress()) == true) {
                    GoodsAddress.executeUpdate("update GoodsAddress g set g.defaultAddress ='1' where g.consigneePhone=:phone and g.isDeleted='0' ", [phone: goodsAddress.getConsigneePhone()])

                    save = GoodsAddress.executeUpdate("update GoodsAddress g set g.defaultAddress ='0' where g.id=:id and g.consigneePhone=:phone and g.isDeleted='0' ", [id: goodsAddress.getId(), phone: goodsAddress.getConsigneePhone()])
                    println save
                    return save;
                }

                save = queryGoods.save()
                return save;
            }

            if ('1'.equals(goodsAddress.getIsDeleted()) == true || goodsAddress.getDefaultAddress() != null) {
                return save
            }
            save = goodsAddress.save()
            save

    }
    //载入收货地址
    def loadAddressByPhone = {
        List<GoodsAddress> all = GoodsAddress.findAll("from GoodsAddress g where g.consigneePhone=:phone and g.isDeleted='0'", [phone: it])
        //如果是一个则设置为默认地址
        if (all != null && all.size() == 1) {
            if (!'0'.equals(all.get(0).getDefaultAddress())) {
                GoodsAddress.executeUpdate("update GoodsAddress g set g.defaultAddress ='0' where g.consigneePhone=:phone and g.isDeleted='0' ", [phone: all.get(0).getConsigneePhone()])
                all.get(0).setDefaultAddress('0')
            }
        }

        all

    }

    //查询默认收货地址
    def loadDefaultAddressByPhone = {

        List<GoodsAddress> all = GoodsAddress.findAll("from GoodsAddress g where g.consigneePhone=:phone and g.isDeleted='0'", [phone: it])

        if (all == null || all.size() == 0) {
            return all
        }
        //如果是一个则设置为默认地址
        if (all != null && all.size() == 1) {
            if (!'0'.equals(all.get(0).getDefaultAddress())) {
                GoodsAddress.executeUpdate("update GoodsAddress g set g.defaultAddress ='0' where g.consigneePhone=:phone and g.isDeleted='0' ", [phone: all.get(0).getConsigneePhone()])
                all.get(0).setDefaultAddress('0')
            }

            return all.get(0)
        }


        GoodsAddress.find("from GoodsAddress g where g.consigneePhone=:phone and g.isDeleted='0' and g.defaultAddress='0'", [phone: it])

    }
    //加载所有的地址
    def loadAllAddressByPhone = {

    }
}
