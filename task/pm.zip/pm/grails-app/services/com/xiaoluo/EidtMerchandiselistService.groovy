package com.xiaoluo

import grails.transaction.Transactional
import net.minidev.json.JSONArray
import net.minidev.json.JSONObject
import org.apache.commons.lang.StringUtils

@Transactional
class EidtMerchandiselistService {

    //评价订单
    def remarkOrder = {
        eidtMerchandiselist, phone, info, content ->
            def save

            //评价之前查询是购买过或者是已经是收货状态，并且状态限制是一次

            Customer customer = Customer.find("from Customer c where c.customerPhone =?  and c.is_deledted='0' ", [phone])

            if (customer == null) {
                return 3
            }

            String orderInfo = customer.getOrderInfos();

            if (StringUtils.isEmpty(orderInfo)) {

                return save
            }

            int flag = 0

            int infect = 0
            //此为多个订单的情况
            if (orderInfo.indexOf(',') > -1) {

                String[] arr = orderInfo.split(',')

                StringBuilder sb = new StringBuilder()

                for (String it : arr) {


                    if (!StringUtils.isBlank(it)) {


                        flag = 0

                        if (it.indexOf(eidtMerchandiselist.getId() + '') > -1) {
                            flag = 1
                        }

                        if (it.indexOf(eidtMerchandiselist.getId() + '') > -1 && it.indexOf('run') > -1 && it.indexOf(info) > -1) {
                            flag = 2
                            infect = 1
                            //并且把订单改成已经评价过
                            if (it.indexOf('finishedCommont') > -1) {

                                return 4
                            }


                        }

                        //订单还没发货
                        if (it.indexOf(eidtMerchandiselist.getId() + '') > -1 && it.indexOf('start') > -1 && it.indexOf(info) > -1) {

                            flag = 10
                        }


                    }
                    flag == 2 ? sb.append(it + '_finishedCommont,') : sb.append(it + ',')
                }

                customer.setOrderInfos(sb.toString())
                customer.save()
            } else {

                //此为一个订单的情况
                if (orderInfo.indexOf(eidtMerchandiselist.getId() + '') > -1 && orderInfo.indexOf('run') > -1 && orderInfo.indexOf(info) > -1) {
                    flag = 2
                    if (orderInfo.indexOf('finishedCommont') > -1) {

                        return 4
                    }

                    customer.setOrderInfos(orderInfo + '_finishedCommont')
                    customer.save()
                }
                //订单还没发货
                if (orderInfo.indexOf(eidtMerchandiselist.getId() + '') > -1 && orderInfo.indexOf('start') > -1 && orderInfo.indexOf(info) > -1) {
                    flag = 10

                }


            }
            //根据flag标记判断是否是已经收获，并且可以评论
            if (infect == 0) {

                switch (flag) {
                    case 0:
                        return flag
                    case 1:
                        return flag
                    case 10:
                        return flag


                }
            }
            /*   EidtMerchandiselist queryEditMerchandiselist = EidtMerchandiselist.find("from EidtMerchandiselist e where e.id=? and e.isDeleted='0'", [eidtMerchandiselist.getId()])
               if (queryEditMerchandiselist == null || StringUtils.isEmpty(queryEditMerchandiselist.getRemark())) {

                   //判断商家对应有没有客户信息
                   if (StringUtils.isEmpty(queryEditMerchandiselist.getShopperPhone()) || queryEditMerchandiselist.getShopperPhone().indexOf(phone) == -1 && queryEditMerchandiselist.getShopperPhone().indexOf(info) == -1) {

                       //对用户订单进行还原
                       String orderInfos = customer.getOrderInfos()
                       if (orderInfos.indexOf(',') > -1) {
                           String[] arr = orderInfos.split(',')

                           StringBuilder sb = new StringBuilder()

                           for (String it : arr) {


                               if (!StringUtils.isBlank(it)) {

                                   if (it.indexOf(eidtMerchandiselist.getId() + '') > -1 && it.indexOf('_finishedCommont') > -1) {
                                       sb.append(it.replace('_finishedCommont', '') + ',')
                                   } else {
                                       sb.append(it + ',')
                                   }


                               }
                           }
                           customer.setOrderInfos(sb.toString())
                       } else {
                           customer.setOrderInfos(customer.getOrderInfos().replace('_finishedCommont', ''))

                       }

                       customer.save()
                       return 9

                   }

                   //这是在原来的EidtMerchandiseList表中的字段remark中增加评论，考虑分页的问题
                   String[] arr = queryEditMerchandiselist.getRemark().split('、')
                   if (arr == null || arr.size() == 0) {
                       arr.each {
                           flag = 4
                           if (it.indexOf(phone) > -1 && it.indexOf(info) > -1) {
                               flag = 5
                           }

                       }
                   }
                   switch (flag) {
                       case 4:
                           return flag
                   }

                   eidtMerchandiselist.getRemark() ? queryEditMerchandiselist.setRemark(eidtMerchandiselist.getRemark()) : ''









                   save = queryEditMerchandiselist.save()
                   return save
               }

               //不考虑分页的时候，进行订单的拼接过程
               String str = queryEditMerchandiselist.getRemark() + '、' + eidtMerchandiselist.getRemark()
               queryEditMerchandiselist.setRemark(str)
               save = queryEditMerchandiselist.save()
               save*/

            //本案中考虑增加分页留言
            EidtMerchandiselist queryEditMerchandiselist = EidtMerchandiselist.find("from EidtMerchandiselist e where e.id=? and e.isDeleted='0'", [eidtMerchandiselist.getId()])

            //判断商家对应有没有客户信息
            if (queryEditMerchandiselist == null || StringUtils.isEmpty(queryEditMerchandiselist.getShopperPhone())
                    || queryEditMerchandiselist.getShopperPhone().indexOf(phone) == -1 || queryEditMerchandiselist.getShopperPhone().indexOf(info) == -1) {

                //对用户订单进行还原
                String orderInfos = customer.getOrderInfos()
                if (orderInfos.indexOf(',') > -1) {
                    String[] arr = orderInfos.split(',')

                    StringBuilder sb = new StringBuilder()

                    for (String it : arr) {


                        if (!StringUtils.isBlank(it)) {

                            if (it.indexOf(eidtMerchandiselist.getId() + '') > -1 && it.indexOf('_finishedCommont') > -1) {
                                sb.append(it.replace('_finishedCommont', '') + ',')
                            } else {
                                sb.append(it + ',')
                            }


                        }
                    }
                    customer.setOrderInfos(sb.toString())
                } else {
                    customer.setOrderInfos(customer.getOrderInfos().replace('_finishedCommont', ''))

                }

                customer.save()
                if (queryEditMerchandiselist == null) {
                    return 11
                }
                return 9

            }

            //商家有对应的信息，那就继续进行操作订单信息
            List<OrderComment> orderComments = OrderComment.findAll("from OrderComment o where o.isDeleted='0' and  merchandiseId =:id", [id: eidtMerchandiselist.getId()])
            OrderComment orderComment = new OrderComment()
            flag = 0
            //没有该商户的评价
            if (orderComments != null && orderComments.size() != 0) {
                orderComments.each {
                    println it.getCustomerOrderInfo().equals(info)
                    if (it.getCustomerOrderInfo().equals(info) == true) {
                        flag = 4
                    }
                }
            }

            switch (flag) {
                case 4:
                    return flag
            }

            orderComment.setCustomerPhone(phone)
            orderComment.setCustomerContent(content)
            orderComment.setCustomerOrderInfo(info)
            orderComment.setMerchandiseId(eidtMerchandiselist.getId())
            orderComment.setIsDeleted('0')
            save = orderComment.save()


            save

    }
    //载入买家订单
    def findOrderInfoByPhone = {

        Customer customer = Customer.find("from Customer c where c.customerPhone =?  and c.is_deledted='0' ", [it])

        if (customer == null || StringUtils.isEmpty(customer.getOrderInfos())) {
            return 0
        }

        JSONObject jsonObject

        JSONArray jsonArray = new JSONArray()

        String[] arr = customer.getOrderInfos().split(',')

        arr.each {
            String[] infoArr = it.split('_')
            jsonObject = new JSONObject()
            jsonObject.put('merchandiseId', infoArr[0])
            jsonObject.put('orderInfo', infoArr[1].trim())
            jsonObject.put('orderStatus', infoArr[2].trim())
            jsonObject.put('orderNumber', infoArr[3] ? infoArr[3].equals('finishedCommont') == true ? '' : infoArr[3].trim() : '')
            jsonArray.add(jsonObject)
        }

        jsonArray


    }

//查看特定商品评价信息
    def viewCommmentById = {

        id, pageNum ->
            /*
             //之前的没有分页，直接在EidtMerchandiseList中增加的Remark字段
             EidtMerchandiselist queryEditMerchandiselist = EidtMerchandiselist.find("from EidtMerchandiselist e where e.id=? and e.isDeleted='0'", [Long.parseLong(id)])

              if (queryEditMerchandiselist == null) {
                  return 0
              }

              if (StringUtils.isEmpty(queryEditMerchandiselist.getRemark())) {
                  return 1
              }
              String[] arr = queryEditMerchandiselist.getRemark().split('、')

              if (arr == null) {
                  return 1
              }

              JSONArray jsonArray
              JSONArray resultArr = new JSONArray()
              arr.each {
                  jsonArray = new JSONArray()
                  String[] strArr = it.split(',')
                  jsonArray.add('customerPhone:' + strArr[0].substring(15, 16) + '*********' + strArr[0].reverse().substring(0, 1))
                  jsonArray.add(strArr[1])
                  jsonArray.add(strArr[2].replace(']', ''))
                  resultArr.add(jsonArray)
              }

              resultArr*/

            //分页查看订单
//            List<OrderComment> orderComments = OrderComment.findAll("from OrderComment o where o.isDeleted='0' and  merchandiseId =:id", [id: Long.parseLong(id)], [sort: "customer_content", order: "desc"])
//            List<OrderComment> orderComments = OrderComment.list(sort: "id", order: "desc")

            int pageSize = 2
            pageNum = (pageNum - 1) * pageSize
            List<OrderComment> orderComments = OrderComment.findAllByIsDeletedAndMerchandiseId('0', Long.parseLong(id), [sort: "id", order: "asc", max: pageSize, offset: pageNum])
            if (orderComments == null || orderComments.size() == 0) {

                return 1
            }
            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObject

            orderComments.each {
                jsonObject = new JSONObject()
                jsonObject.put('id', it.getId())
                jsonObject.put('customerPhone', it.getCustomerPhone().substring(0, 1) + '*********' + it.getCustomerPhone().reverse().substring(0, 1))
                jsonObject.put('customerContent', it.getCustomerContent())
                jsonObject.put('customerOrderInfo', it.getCustomerOrderInfo())
                jsonArray.add(jsonObject)
            }
            /* jsonObject = new JSONObject()
             jsonObject.put("pageNum", pageNum)
             jsonArray.add(jsonObject)*/
            jsonArray
    }

}
