package com.xiaoluo

import grails.transaction.Transactional
import net.minidev.json.JSONArray
import net.minidev.json.JSONObject
import org.apache.commons.lang.StringUtils

@Transactional
class GoodsAddressController {

    def goodsAddressService

    //查询成功
    private static int QUERY_SUCCESS = 300
    //查询为空
//    private static int QUERY_EMPTY = 301
    //参数错误
    private static int PARAMS_INCONRRECT = 302
    //查询错误
    private static int QUERY_ERROR = 303

    //管理收货地址
    def createGoodsAddress = {

        if (((StringUtils.isEmpty(params.customerAddress) || StringUtils.isEmpty(params.customerName) || StringUtils.isEmpty(params.customerArea) || StringUtils.isEmpty(params.customerPhone) || (!(params.customerPhone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/))) && StringUtils.isEmpty(params.deleted)&&StringUtils.isEmpty(params.defaultAddress))
                || params.consigneePhone == null || !(params.consigneePhone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }



        GoodsAddress goodsAddress = new GoodsAddress(params)

        params.deleted ? goodsAddress.setIsDeleted('1') : goodsAddress.setIsDeleted('0')

        def save = goodsAddressService.createGoodsAddress(goodsAddress)

        save ? render(contentType: "application/json") {
            status = QUERY_SUCCESS

        } : render(contentType: "application/json") {
            status = QUERY_ERROR
        }

    }

    //查询收货地址
    def loadAddressByPhone = {
        if (params.phone == null || !(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        List<GoodsAddress> all = goodsAddressService.loadAddressByPhone(params.phone)

        /*  if (all == null || all.size() == 0) {
              render(contentType: "application/json") {
                  status = QUERY_EMPTY
              }
              return

          }*/

        JSONObject jsonObject
        JSONArray array = new JSONArray()

        if (all == null || all.size() == 0) {
            render(contentType: "application/json") {
                status = QUERY_SUCCESS
                source = array
            }
            return
        }


        all.each {
            jsonObject = new JSONObject()
            jsonObject.put('customerId', it.getId() ?: '')
            jsonObject.put('customerName', it.getCustomerName() ?: '')
            jsonObject.put('customerPhone', it.getCustomerPhone() ?: '')
            jsonObject.put('customerAddress', it.getCustomerAddress() ?: '')
            jsonObject.put('isCustomerAddress', it.getDefaultAddress().equals("0") == true ? true : false)
            jsonObject.put('customerArea', it.getCustomerArea() ?: '')

            array.add(jsonObject)
        }

        render(contentType: "application/json") {
            status = QUERY_SUCCESS
            source =
                    array


        }


    }
    //查询默认收货地址
    def loadDefaultAddressByPhone = {
        if (params.phone == null || !(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        def result = goodsAddressService.loadDefaultAddressByPhone(params.phone)

        result ? render(contentType: "application/json") {
            status = QUERY_SUCCESS
            source = {
                customerId = result.getId() ?: ''
                customerName = result.getCustomerName() ?: ''
                customerPhone = result.getCustomerPhone() ?: ''
                customerAddress = result.getCustomerAddress() ?: ''
                customerArea = result.getCustomerArea() ?: ' '
            }

        } : render(contentType: "application/json") {
            status = QUERY_SUCCESS
            source = {

            }
        }
        /*  render(contentType: "application/json") {
              status = QUERY_SUCCESS
              source = {
                  customerId = goodsAddress.getId() ?: ''
                  customerName = goodsAddress.getCustomerName() ?: ''
                  customerPhone = goodsAddress.getCustomerPhone() ?: ''
                  customerAddress = goodsAddress.getCustomerAddress() ?: ''
                  customerArea = goodsAddress.getCustomerArea() ?: ' '
              }

          }*/

    }

}
