package com.xiaoluo

import grails.transaction.Transactional
import org.apache.commons.lang.StringUtils

@Transactional
class EidtMerchandiselistController {

    def eidtMerchandiselistService
    //查询成功
    private static int QUERY_SUCCESS = 300
    //查询为空
//    private static int QUERY_EMPTY = 301
    //参数错误
    private static int PARAMS_INCONRRECT = 302
    //查询错误
    private static int QUERY_ERROR = 303
    //用户不存在该订单
    private static int ORDER_RUNNING = 304
    //用户没下过订单
    private static int ORDER_EMPRY = 305
    //字段过少
    private static int FIELD_ESIZE = 306
    //重复操作
    private static int OPERATE_AGAIN = 307
    //商家不存在该订单
    private static int MERCHANTINFO_EMPTY = 308
    //正在进行
    private static int ORDER_NOTEXIST = 309
    //商家id不存在
    private static int MERCHANDISE_EMPTY = 310

    //评论订单
    def remarkOrder = {

        if (StringUtils.isEmpty(params.phone) || !(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)
                || StringUtils.isEmpty(params.content) || StringUtils.isEmpty(params.id) || StringUtils.isEmpty(params.orderInfo)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        if (params.orderInfo.toString().length() < 30 || params.content.toString().length() < 10) {
            render(contentType: "application/json") {
                status = FIELD_ESIZE
            }
            return
        }

        EidtMerchandiselist eidtMerchandiselist = new EidtMerchandiselist()
        eidtMerchandiselist.setId(Long.parseLong(params.id))
        eidtMerchandiselist.setIsDeleted('0')
        eidtMerchandiselist.setRemark('[customerPhone:' + params.phone + ',customerContent:' + params.content + ',customerOrderInfo:' + params.orderInfo + ']');

        def save = eidtMerchandiselistService.remarkOrder(eidtMerchandiselist, params.phone, params.orderInfo, params.content)


        switch (save) {
            case 0:
                render(contentType: "application/json") {
                    status = ORDER_EMPRY

                }
                return
            case 1:
                render(contentType: "application/json") {
                    status = ORDER_RUNNING

                }
                return
            case 3:
                /* render(contentType: "application/json") {
                     status = QUERY_EMPTY

                 }*/
                render(contentType: "application/json") {
                    status = QUERY_SUCCESS
                    source = ''

                }
                return
            case 4:
                render(contentType: "application/json") {
                    status = OPERATE_AGAIN

                }
                return
            case 9:
                render(contentType: "application/json") {
                    status = MERCHANTINFO_EMPTY

                }
                return
            case 10:
                render(contentType: "application/json") {
                    status = ORDER_NOTEXIST

                }
                return case 11:
            render(contentType: "application/json") {
                status = MERCHANDISE_EMPTY

            }
            return
        }

        save ? render(contentType: "application/json") {
            status = QUERY_SUCCESS

        } : render(contentType: "application/json") {
            status = QUERY_ERROR
        }
    }

    //买家订单查询
    def findOrderInfoByPhone = {

        if (StringUtils.isEmpty(params.phone) || !(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }


        def result = eidtMerchandiselistService.findOrderInfoByPhone(params.phone)

       result == 0 == true ? render(contentType: "application/json") {
           status = QUERY_SUCCESS
           source={

           }
         } : render(contentType: "application/json") {
             status = QUERY_SUCCESS
             source = result

         }
        /*    render(contentType: "application/json") {
              status = QUERY_SUCCESS
              source = result ?: ''

          }*/

    }
    //评论查看-----不需要权限
    def viewCommmentById = {


        if (params.id == null || !(params.id ==~ /\d+/) || params.int("pageNum") == null || params.int("pageNum") < 1) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        def result = eidtMerchandiselistService.viewCommmentById(params.id, params.int("pageNum"))


        switch (result) {
            case 0:
                render(contentType: "application/json") {
                    status = QUERY_ERROR
                }
                break
            case 1:
                /* render(contentType: "application/json") {
                     status = QUERY_EMPTY
                 }*/
                render(contentType: "application/json") {
                    status = QUERY_SUCCESS
                    source ={

                    }

                }
                break
            default:
                render(contentType: "application/json") {
                    status = QUERY_SUCCESS
                    source = result

                }
        }

    }
}
