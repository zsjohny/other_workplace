package com.xiaoluo

import grails.transaction.Transactional
import org.apache.commons.lang.StringUtils
import org.springframework.web.multipart.MultipartFile

@Transactional()
class CustomerController {
    def customerService

    //查询成功
    private static int QUERY_SUCCESS = 300
    //查询为空
    // private static int QUERY_EMPTY = 301
    //参数错误
    private static int PARAMS_INCONRRECT = 302
    //查询错误
    private static int QUERY_ERROR = 303
    //错误提交
    private static int SUBMIT_AGAIN = 0

    static allowedMethods = [

            uploadCustomer: "POST", loadCustomer: "GET"
    ]

    def index() {

        //chain(controller: 'customer', action: 'uploadCustomer')


    }
    //客户个人资料上传和更新
    def uploadCustomer = {


        if (!params.customerHead) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        MultipartFile headFile = request.getFile("customerHead")


        if (headFile.size == 0 || StringUtils.isEmpty(params.customerPhone)) {

            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        if (!(params.customerPhone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {

            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
            return
        }

        String path = grailsAttributes.getApplicationContext().getResource("/file/").getFile().toString()
        def filePath = new File(path + "//" + params.customerPhone)

        if (!filePath.exists()) {
            filePath.mkdirs()

        }

        File uploadFile = new File(filePath.getPath(), System.currentTimeMillis() + ".jpg")

        headFile.transferTo(uploadFile)

        def customer = new Customer(params)

        customer.setCustomerHeadUrl(uploadFile.getAbsolutePath())
        customer.setIs_deledted('0')

        if (params.id) {
            customer.setModifyTime(new Date())
            customer.setId(Long.parseLong(params.id))
            if (params.version && params.version ==~ /\d+/) {
                customer.setVersion(Long.parseLong(params.version))

            } else {
                render(contentType: "application/json") {
                    status = PARAMS_INCONRRECT

                }
                return

            }


        } else {
            customer.setCreateTime(new Date())
        }

        def save = customerService.save(customer)

        save ? render(contentType: "application/json") {
            status = QUERY_SUCCESS

        } : render(contentType: "application/json") {
            status = QUERY_ERROR
        }


    }

    //客户资料加载
    def loadCustomer= {
        if (!(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {

            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT

            }
            return
        }

        Customer result = customerService.queryCustomerByPhone(params.phone)
        /* result ? render(contentType: "application/json") {
             status = QUERY_SUCCESS
             source = {
                 customerId = result.getId() ?: '' + ''
                 customerHead = result.getCustomerHeadUrl().substring(result.getCustomerHeadUrl().lastIndexOf('\\') + 2) ?: ''
                 customerNickName = result.getCustomerNickName() ?: ''
                 customerSex = result.getCustomerSex() ?: ''
             }


         } : render(contentType: "application/json") {
             status = QUERY_EMPTY
         }*/
        result ? render(contentType: "application/json") {
            status = QUERY_SUCCESS
            source = {
                customerId = result.getId() ?: '' + ''
                customerHead = result.getCustomerHeadUrl()? result.getCustomerHeadUrl().substring(result.getCustomerHeadUrl().lastIndexOf('\\') + 2) : ''
                customerNickName = result.getCustomerNickName() ?: ''
                customerSex = result.getCustomerSex() ?: ''
            }


        } : render(contentType: "application/json") {
            status = QUERY_SUCCESS
            source = {

            }

        }


    }
    //客户资料下载
    def downloadPic = {

        if (!(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT
            }
        }





        Customer result = customerService.queryCustomerByPhone(params.phone)
        if (result) {

            File downLoadFile = new File(result.getCustomerHeadUrl());

            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(downLoadFile));
            BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
            String fileName = downLoadFile.getName()
            //设置下载的文件的格式
            response.setHeader("Content-Disposition", "attachment;filename=${fileName}")
            response.setContentType("application/octet-stream;charset=utf-8")

            byte[] bytes = new byte[1024]
            int len = 0

            while ((len = bis.read(bytes)) != -1) {
                bos.write(bytes, 0, len)

            }
            bos.close()
            bis.close()
            return

        }

        /*  render(contentType: "application/json") {
              status = QUERY_EMPTY
          }*/


    }
    private static int WEEKDAY = 7

    //客户签到
    def signOn = {

        //初始化再次签到信息
        SUBMIT_AGAIN = 0

        if ((!(params.customerPhone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/)) || StringUtils.isEmpty(params.customerScore)) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT

            }
            return
        }



        Customer result = customerService.queryCustomerByPhone(params.customerPhone)



        if (result) {

            Customer customer = new Customer(params)


            Calendar calendar = Calendar.getInstance()

//            calendar.set(Calendar.DAY_OF_WEEK, --WEEKDAY)
//            calendar.set(Calendar.DAY_OF_WEEK, 5)

            String day = calendar.get(Calendar.DAY_OF_WEEK)
            if ('7'.equals(day) == false) {
                day = Integer.parseInt(day) - 1

            }


            customer.setNowDay(day)
            result.getCustomerScore() ? customer.setCustomerScore(result.getCustomerScore() + customer.getCustomerScore()) : ''
            result.getCustomerUseDays() ? result.getCustomerUseDays().trim().equals('1,2,3,4,5,6,7,') == true ? result.getNowDay().equals(day) == true ? SUBMIT_AGAIN = 304 : customer.setCustomerUseDays(day) : result.getCustomerUseDays().indexOf(day) > -1 ? SUBMIT_AGAIN = 304 : customer.setCustomerUseDays(result.getCustomerUseDays() + ',' + day) : customer.setCustomerUseDays(day)



            if (SUBMIT_AGAIN == 304) {
                render(contentType: "application/json") {
                    status = SUBMIT_AGAIN

                }
                return
            }

            //把所存的天数排序
            String[] arr = customer.getCustomerUseDays().split(',')
            if (arr != null & arr.size() > 1) {
                String str = ''
                List<String> list = new ArrayList<>();
                arr.each {
                    list.add(it)

                }

                for (i in 1..<8) {

                    list.each {

                        if (i.toString().equals(it) == true) {
                            str += i + ','
                        }

                    }
                }
                customer.setCustomerUseDays(str.trim())
            }
            def save = customerService.save(customer)

            /* save ? render(contentType: "application/json") {
                 status = QUERY_SUCCESS
                 localDay = day
                 useDay = customer.getCustomerUseDays()

                 userCore = customer.getCustomerScore()

             } : render(contentType: "application/json") {
                 status = QUERY_EMPTY
             }*/

            save ? render(contentType: "application/json") {
                status = QUERY_SUCCESS
                source = {
                    localDay = day ?: ''
                    useDay = customer.getCustomerUseDays() ?: ''

                    userCore = customer.getCustomerScore() ?: ''

                }

            } : render(contentType: "application/json") {
                status = QUERY_SUCCESS
                source = {


                }
            }
            return

        }

        /*render(contentType: "application/json") {
            status = QUERY_EMPTY
        }
*/

    }

    //展示签到内容
    def displaySignOnInfo = {

        if ((!(params.phone ==~ /((13[0-9])|(15[^4,\\D])|(18[0,2,5-9]))\d{8}/))) {
            render(contentType: "application/json") {
                status = PARAMS_INCONRRECT

            }
            return
        }


        Customer result = customerService.queryCustomerByPhone(params.phone)

        /* if (result) {

             render(contentType: "application/json") {
                 status = QUERY_SUCCESS
                 source = {
                     socre = result.getCustomerScore() ?: '' + ''
                     days = result.getCustomerUseDays() ?: ''

                 }

             }


         } else {

             render(contentType: "application/json") {
                 status = QUERY_EMPTY
             }

         }*/
        if (result) {

            render(contentType: "application/json") {
                status = QUERY_SUCCESS
                source = {
                    socre = result.getCustomerScore() ?: '' + ''
                    days = result.getCustomerUseDays() ?: ''

                }

            }


        } else {

            render(contentType: "application/json") {
                status = QUERY_SUCCESS
                source = {

                }
            }


        }

    }

    //


}
