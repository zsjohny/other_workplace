/**
 *
 */
package com.ouliao.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ouliao.controller.OuLiaoSayController;
import com.ouliao.controller.UserCallMarkController;
import com.ouliao.domain.ServiceRecordTime;
import com.ouliao.domain.User;
import com.ouliao.domain.UserConcern;
import com.ouliao.domain.UserSayContent;
import com.ouliao.repository.OuLiaoRepository;
import com.ouliao.service.OuLiaoService;
import com.ouliao.service.ServiceRecordTimeService;
import com.ouliao.service.UserConcernService;
import com.ouliao.service.UserSayService;
import com.xiaoluo.util.Des16Util;
import com.xiaoluo.util.DesIosAndAndroid;

import net.sf.json.JSONObject;

/**
 * @author xiaoluo
 * @version $Id: OuLiaoAdminController.java, 2016年2月22日 上午10:04:57
 */
@Controller
@RequestMapping(value = "user/admin")
public class OuLiaoAdminController {
    @Autowired
    private OuLiaoService ouLiaoService;
    @Autowired
    private UserSayService userSayService;
    @Autowired
    private ServiceRecordTimeService serviceRecordTimeService;
    @Autowired
    private OuLiaoRepository ouLiaoRepository;
    @Autowired
    private UserConcernService userConcernService;
    private static String FORWARD = "forward:";

    @RequestMapping(value = "userAdmin/login")
    public String login() {
        return "load";
    }

    // 展示管理页面
    @RequestMapping(value = "userAdmin/recommondDis")
    public String recommondDis(@RequestParam(value = "startCount", defaultValue = "1") Integer startCount,
                               HttpServletRequest request) {
        try {
            // 加载数量配置
            Properties properties = new Properties();
            properties.load(OuLiaoSayController.class.getClassLoader().getResourceAsStream("paramsSet.properties"));

            Integer pageCount = Integer.valueOf(properties.getProperty("contarctUserCount"));

            Object object = ouLiaoService.queryUserIsContractByAll(startCount - 1, pageCount, "userId");

            List<User> list = new ArrayList<>();

            if (object instanceof Page) {
                Page<User> users = (Page) object;

                for (User us : users) {

                    list.add(us);

                }

            }

            JSONObject json = null;
            List<JSONObject> lists = new ArrayList<>();
            String url = properties.getProperty("downloadHead");
            for (User us : list) {
                json = new JSONObject();
                json.put("id", us.getUserId());
                json.put("name", us.getUserNickName());
                json.put("phone", us.getUserPhone());
                json.put("author", us.getUserAuth());
                json.put("order", us.getUserOwnerOrder() == null ? "" : us.getUserOwnerOrder());
                String headUrl = us.getUserHeadPic();
                if (StringUtils.isEmpty(headUrl)) {
                    headUrl = "985595";
                } else {
                    headUrl = headUrl.split("\\.")[0];
                }

                json.put("url", url + us.getUserId() + "/" + headUrl + "/head/download");

                lists.add(json);
            }
            request.setAttribute("count", ouLiaoService.queryUserContractCountByIsDeleted() / pageCount + 1);
            request.setAttribute("data", lists);
            request.setAttribute("isQuery", "false");
            request.setAttribute("startPage", startCount);
        } catch (Exception e) {
            request.setAttribute("msg", "网络加载失败！！");

        }
        return "recommondDis";
    }

    // 展示搜索页面
    @RequestMapping(value = "userAdmin/queryDis")
    public String queryDis(@RequestParam(value = "startCount", defaultValue = "1") Integer startCount,
                           @RequestParam("word") String word, HttpServletRequest request) {
        try {
            // 加载数量配置
            Properties properties = new Properties();
            properties.load(OuLiaoSayController.class.getClassLoader().getResourceAsStream("paramsSet.properties"));

            Integer pageCount = Integer.valueOf(properties.getProperty("contarctUserCount"));

            List<User> users = ouLiaoService.queryUserContractByUserNickNameOrUserAuth((startCount - 1), pageCount,
                    word);

            JSONObject json = null;
            List<JSONObject> lists = new ArrayList<>();

            String url = properties.getProperty("downloadHead");
            for (User us : users) {
                if (us == null) {
                    continue;
                }
                json = new JSONObject();
                json.put("id", us.getUserId());
                json.put("name", us.getUserNickName());
                json.put("phone", us.getUserPhone());
                json.put("author", us.getUserAuth());
                json.put("order", us.getUserOwnerOrder() == null ? "" : us.getUserOwnerOrder());
                String headUrl = us.getUserHeadPic();
                if (StringUtils.isEmpty(headUrl)) {
                    headUrl = "985595";
                } else {
                    headUrl = headUrl.split("\\.")[0];
                }

                json.put("url", url + us.getUserId() + "/" + headUrl + "/head/download");

                lists.add(json);
            }
            request.setAttribute("count",
                    ouLiaoRepository.queryUserContractCountByUserNickNameOrUserAuth(word) / pageCount + 1);
            request.setAttribute("isQuery", "true");
            request.setAttribute("data", lists);
            request.setAttribute("startPage", startCount);
        } catch (Exception e) {
            request.setAttribute("msg", "网络加载失败！！");

        }
        return "recommondDis";
    }

    // 进行推荐
    @RequestMapping(value = "userAdmin/recommond")
    public String recommond(@RequestParam("recommond") String recommond,
                            @RequestParam(value = "nowPage", defaultValue = "1") Integer startCount, HttpServletRequest request) {

        try {
            String isRecommond = recommond.split(",")[1];
            Integer id = Integer.parseInt(recommond.split(",")[0]);

            User user = ouLiaoService.queryUserByUserId(id);

            if (user == null) {
                request.setAttribute("msg", "账号不存在！！");
                return "recommondDis";
            }
            String isOrder = "";
            if ("0".equals(isRecommond)) {

                isOrder = "true";
            } else {
                isOrder = "false";
            }

            ouLiaoService.updateIsRecommondUserId(isOrder, id);

            request.setAttribute("msg", "推荐成功！！");

            return FORWARD + "/user/admin/userAdmin/recommondDis?startCount=" + startCount;

        } catch (Exception e) {
            request.setAttribute("msg", "网络加载失败！！");
            return FORWARD + "/user/admin/userAdmin/recommondDis?startCount=" + 1;
        }
    }

    @RequestMapping(value = "userAdmin/author")
    public String regUser(@RequestParam("phone") String phone,
                          @RequestParam(value = "name", required = false) String name, @RequestParam("author") String author,
                          ModelMap modelMap) {
        User user = null;
        try {
            if (!phone.matches("^1(4[57]|3[0-9]|5([0-3]|[5-9])|7([0-1]|[6-8])|8[0-9])\\d{8}$")) {
                modelMap.addAttribute("successMsg", "参数填写不正确!!");
                return "load";
            }
            // 加载数量配置
            Properties properties = new Properties();
            properties.load(new InputStreamReader(
                    OuLiaoSayController.class.getClassLoader().getResourceAsStream("paramsSet.properties"), "utf-8"));

            user = ouLiaoService.queryUserByPhone(phone);
            String callTimeWeek = properties.getProperty("callTime");

            String callTime = properties.getProperty("ouliaoTime");
            if (user != null) {
                String nickName = "";

                if (StringUtils.isEmpty(name)) {
                    nickName = user.getUserPhone();
                } else {
                    nickName = name;
                }
                // 防止替换用户设置的价格
                Double cost = 1.00;
                if (user.getUserCallCost() != null && user.getUserCallCost() != 0) {
                    cost = user.getUserCallCost();
                }
                if (StringUtils.isNotEmpty(user.getUserCallTimeWeek())) {
                    callTimeWeek = user.getUserCallTimeWeek();
                }
                if (StringUtils.isNotEmpty(user.getUserCallTime())) {
                    callTime = user.getUserCallTime();
                }

                ouLiaoService.updateUserAuthByUserPhone(callTimeWeek, callTime, nickName, author, cost, phone);
            } else {

                user = new User();
                user.setUserPhone(phone);
                user.setUserNum(UUID.randomUUID().toString());
                user.setUserCreateTime(new Date());
                user.setUserAuth(author);
                // 统一费用
                user.setUserCallCost(1.00);
                user.setUserCallTimeWeek(callTimeWeek);
                user.setUserCallTime(callTime);
                // 默认设置昵称
                String nickName = "";

                if (StringUtils.isEmpty(name)) {
                    nickName = phone;
                } else {
                    nickName = name;
                }
                user.setUserNickName(nickName);
                user.setUserContract("true");
                user.setIsDeleted("0");

                // 默认生成签名
                user.setUserSign(properties.getProperty("signDefault"));

                if (!ouLiaoService.regUser(user)) {
                    modelMap.addAttribute("successMsg", "认证失败,数据不存在!!");
                    return "load";
                }

                User us = ouLiaoService.queryUserByPhone(phone);

                // 默认设置有十分钟的通话时间
                ServiceRecordTime serviceRecordTime = new ServiceRecordTime();
                serviceRecordTime.setCreatTime(new Date());
                serviceRecordTime.setUserCallTime(600l);
                serviceRecordTime.setUserId(us.getUserId());
                serviceRecordTime.setIsSysSend("true");
                serviceRecordTimeService.createServiceRecordTime(serviceRecordTime);

                // 默认发表说说
                UserSayContent userSayContent = new UserSayContent();
                userSayContent.setUserCreateTime(new Date());
                userSayContent.setIsDeleted("0");
                userSayContent.setUserId(us.getUserId());
                userSayContent.setUserContent(properties.getProperty("contentDefault"));
                userSayService.createUserSayContentByUserId(userSayContent);

                // 添加默认客服关注
                us = ouLiaoService.queryUserByPhone(properties.getProperty("ouliaoService"));
                if (us == null) {
                    // 设置默认客服
                    us = new User();
                    us.setUserPhone(properties.getProperty("ouliaoService"));
                    us.setUserNickName(properties.getProperty("ouliaoNickName"));
                    String uuid = UUID.randomUUID().toString();
                    us.setUserNum(uuid);
                    us.setUserCreateTime(new Date());
                    us.setIsDeleted("0");
                    us.setUserMoney(5000.0);
                    us.setUserCallCost(0.00);
                    us.setUserSign(properties.getProperty("ouliaoSign"));
                    String pass = DesIosAndAndroid.encryptDES(properties.getProperty("ouliaoPass"),
                            properties.getProperty("ouliaoService"));
                    us.setUserPass(pass);
                    us.setUserContract("true");
                    us.setUserKey(Des16Util.encrypt(pass, uuid));
                    us.setUserCallTime(properties.getProperty("ouliaoTime"));
                    us.setUserCallTimeWeek(properties.getProperty("callTime"));
                    ouLiaoService.regUser(us);

                    us = ouLiaoService.queryUserByPhone(properties.getProperty("ouliaoService"));
                }

                UserConcern userConcern = new UserConcern();
                userConcern.setUserOnfocusId(us.getUserId());
                userConcern.setUserId(user.getUserId());
                userConcern.setIsDeleted("0");
                userConcern.setUserCreateTime(new Date());
                userConcern.setUserModifyTime(new Date());
                userConcern = userConcernService.createUserConcern(userConcern);

            }
            modelMap.addAttribute("successMsg", "认证成功!!");
        } catch (Exception e) {
            modelMap.addAttribute("successMsg", "认证失败,网络请求失败!!");
        }
        return "load";
    }

    // 上传配置
    @RequestMapping(value = "userAdmin/uploadPro")
    public String uploadPro(@RequestParam("file") MultipartFile file, ModelMap modelMap) {
        try {
            Properties properties = new Properties();
            properties.load(new InputStreamReader(
                    UserCallMarkController.class.getClassLoader().getResourceAsStream("paramsSet.properties"),
                    "utf-8"));

            File fileSave = new File(properties.getProperty("msgPath"));

            if (fileSave.exists()) {

                BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream(), "utf-8"));
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                Properties prop = new Properties();
                prop.load(new BufferedInputStream(new FileInputStream(fileSave)));
                byte[] b = new byte[1024];

                String str = "";
                int count = prop.size() + 1;
                while ((str = br.readLine()) != null) {
                    count++;
                    prop.setProperty(count + "",
                            new String(str.getBytes("utf-8"), "utf-8") + "&" + simpleDateFormat.format(new Date()));

                }
                OutputStream os = new FileOutputStream(fileSave);
                prop.store(os, "xiaoluo");
                os.close();
                System.gc();
            } else {

                file.transferTo(new File(properties.getProperty("msgPath")));
            }
            modelMap.addAttribute("successMsg", "上传成功!!");
        } catch (Exception e) {
            modelMap.addAttribute("successMsg", "上传失败,网络请求失败!!");
        }
        return "load";
    }


    //取消认证
    @RequestMapping(value = "userAdmin/cancelAuthor")
    public String cancelAuthor(@RequestParam("id") Integer id,
                               @RequestParam(value = "nowPage", defaultValue = "1") Integer startCount, HttpServletRequest request) {

        try {


            User user = ouLiaoService.queryUserByUserId(id);

            if (user == null) {
                request.setAttribute("msg", "账号不存在！！");
                return "recommondDis";
            }

            ouLiaoService.updateUserAuthorAndUserContractByUserId(user.getUserId());
            request.setAttribute("msg", "取消认证成功！！");

            return FORWARD + "/user/admin/userAdmin/recommondDis?startCount=" + startCount;

        } catch (Exception e) {
            request.setAttribute("msg", "网络加载失败！！");
            return FORWARD + "/user/admin/userAdmin/recommondDis?startCount=" + 1;
        }
    }


}
