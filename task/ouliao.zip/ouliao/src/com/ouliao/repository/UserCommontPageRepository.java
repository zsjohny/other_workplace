/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ouliao.domain.UserCommont;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserCommontPageRepository.java, 2016年2月20日 上午10:57:35
 */
public interface UserCommontPageRepository
		extends JpaRepository<UserCommont, Integer>, JpaSpecificationExecutor<UserCommont> {

}
