/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ouliao.domain.ServiceRecordTime;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: ServiceRecordTimePageRepository.java, 2016年3月10日 下午5:20:56
 */

public interface ServiceRecordTimePageRepository
		extends JpaRepository<ServiceRecordTime, Integer>, JpaSpecificationExecutor<ServiceRecordTime> {

}
