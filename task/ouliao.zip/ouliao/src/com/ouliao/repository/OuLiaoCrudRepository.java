package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.User;

/**
 * Created by p on 2016/2/18.
 */
public interface  OuLiaoCrudRepository  extends CrudRepository<User,Integer>{
}
