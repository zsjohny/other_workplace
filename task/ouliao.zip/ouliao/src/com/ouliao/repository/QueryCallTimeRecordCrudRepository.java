/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.QueryCallTimeRecord;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: QueryCallTimeRecordCrudRepository.java, 2016年3月17日 下午8:42:41
 */

public interface QueryCallTimeRecordCrudRepository extends CrudRepository<QueryCallTimeRecord, Integer> {

}
