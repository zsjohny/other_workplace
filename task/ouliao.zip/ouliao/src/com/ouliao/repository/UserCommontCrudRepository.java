/**
 *
 */
package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.UserCommont;

/**
 * @author xiaoluo
 * @version $Id: UserCommontCrudRepository.java, 2016年2月19日 下午6:44:42
 */

public interface UserCommontCrudRepository extends CrudRepository<UserCommont, Integer> {

}
