package com.ouliao.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;

import com.ouliao.domain.HuanXin;

@RepositoryDefinition(domainClass = HuanXin.class, idClass = Integer.class)
public interface HuanXinRepository {
	@Query("from HuanXin where ownerId=?1 ")
	HuanXin queryIsExist(Integer ownerId);

	@Query("from HuanXin where huaXinName=?1 ")
	HuanXin queryHuanXinByName(String huaXinName);
}
