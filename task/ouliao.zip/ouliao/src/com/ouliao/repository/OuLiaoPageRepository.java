/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ouliao.domain.User;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: OuLiaoPageRepository.java, 2016年2月24日 下午3:56:20
 */

public interface OuLiaoPageRepository extends JpaRepository<User, Integer>, JpaSpecificationExecutor<User> {

}
