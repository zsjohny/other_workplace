/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.UserSayContent;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserSayCrudRepository.java, 2016年2月19日 下午7:50:06
 */

public interface UserSayContentCrudRepository extends CrudRepository<UserSayContent, Integer> {

}
