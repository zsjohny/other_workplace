/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ouliao.domain.UserCallRoom;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserCallRoomCrudRepository.java, 2016年3月1日 下午6:13:09
 */

public interface UserCallRoomCrudRepository extends JpaRepository<UserCallRoom, Integer> {

}
