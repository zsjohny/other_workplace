/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.UserSupportSay;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserSupportSayCrudRepository.java, 2016年2月19日 下午9:23:03
 */

public interface UserSupportSayCrudRepository extends CrudRepository<UserSupportSay, Integer> {

}
