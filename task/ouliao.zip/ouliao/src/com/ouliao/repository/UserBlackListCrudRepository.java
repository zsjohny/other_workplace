/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.UserBlackList;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserBlackListCrudRepository.java, 2016年2月23日 下午6:11:47
 */

public interface UserBlackListCrudRepository extends CrudRepository<UserBlackList, Integer> {

}
