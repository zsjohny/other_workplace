package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ouliao.domain.HuanXin;

public interface HuanXinCrudRepository extends JpaRepository<HuanXin, Integer> {

}
