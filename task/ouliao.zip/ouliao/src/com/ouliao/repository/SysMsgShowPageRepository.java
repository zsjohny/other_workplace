/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ouliao.domain.SysMsgShow;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: SysMsgShowPageRepository.java, 2016年3月13日 下午6:57:40
 */

public interface SysMsgShowPageRepository
		extends JpaRepository<SysMsgShow, Long>, JpaSpecificationExecutor<SysMsgShow> {

}
