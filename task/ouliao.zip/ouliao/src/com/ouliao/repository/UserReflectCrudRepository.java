/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ouliao.domain.UserReflect;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserReflectRepository.java, 2016年2月26日 下午1:24:24
 */

public interface UserReflectCrudRepository
 extends JpaRepository<UserReflect, Integer> {

}
