/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ouliao.domain.GeTuiMapper;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: GeTuiMapperRepository.java, 2016年2月29日 下午10:31:48
 */

public interface GeTuiMapperCrudRepository extends JpaRepository<GeTuiMapper, Integer> {


}
