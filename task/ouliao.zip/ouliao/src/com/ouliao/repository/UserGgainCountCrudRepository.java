/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ouliao.domain.UserGainCount;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: useGgainCountCrudRepository.java, 2016年2月18日 下午11:04:51   
 */

public interface UserGgainCountCrudRepository extends CrudRepository<UserGainCount, Integer> {

}
