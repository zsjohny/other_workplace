/**
 * 
 */
package com.ouliao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ouliao.domain.UserCallMark;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserCallMarkCrudRepository.java, 2016年2月27日 上午7:29:58
 */

public interface UserCallMarkPageRepository
		extends JpaRepository<UserCallMark, Integer>, JpaSpecificationExecutor<UserCallMark> {

}
