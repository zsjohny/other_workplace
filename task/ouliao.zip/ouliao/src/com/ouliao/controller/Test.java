package com.ouliao.controller;

import com.xiaoluo.util.DesIosAndAndroid;
import redis.clients.jedis.Jedis;

/**
 * Created by nessary on 16-5-4.
 */
public class Test {

    public static void main(String[] args) {
        System.out.println(DesIosAndAndroid.encryptDES("7D6BC901", "64D3C0B8EF619EE52F4AD14E6E2444BE"));

        System.out.println(DesIosAndAndroid.decryptDES("/FXn0ygWQb/vBpll8GrNQw==", "64D3C0B8EF619EE52F4AD14E6E2444BE"));
    }
}
