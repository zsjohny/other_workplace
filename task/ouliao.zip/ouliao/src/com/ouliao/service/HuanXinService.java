/**
 * 
 */
package com.ouliao.service;

import com.ouliao.domain.HuanXin;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: HuanXinService.java, 2016年3月16日 下午9:45:06   
 */

public interface HuanXinService {
	void saveHuanXin(HuanXin huanXin);

	HuanXin queryIsExist(Integer ownerId);

	HuanXin queryHuanXinByName(String huaXinName);
}
