/**
 * 
 */
package com.ouliao.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ouliao.domain.UserReflect;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserReflectCrudService.java, 2016年2月26日 下午1:29:32
 */

public interface UserReflectService {
	void creatUserReflect(UserReflect userReflect);

	Long queryReflectCountByAll();

	int updateIsDeletedByUserReflectId(List<Integer> ids);

	List<UserReflect> queryUserReflectAllByIsDeleted();

	Page<UserReflect> queryUserReflectWithDrawByUserId(Integer starPage, Integer pageNum, Integer userId);

	List<UserReflect> queryUserReflectWithAllDrawByUserId(Integer userId);
}
