/**
 * 
 */
package com.ouliao.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ouliao.domain.UserBlackList;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserBlackListService.java, 2016年2月23日 下午6:28:13
 */

public interface UserBlackListService {
	int updateUserBlackListByUserBlackListId(String isDeleted, Integer userBlackListId);

	UserBlackList createUserBlackList(UserBlackList userBlackList);

	UserBlackList queryUserIsBlackListById(Integer userId, Integer userBlackId);

	Page<UserBlackList> queryUserBlackListByUserBlackId(Integer startPage, Integer pageSize, Integer userBlackId);

	Integer queryBlackListCountByUserId(Integer userId);

	int updateUserBlackListIsDeletedAllByUserBlackByIds(Integer userId, List<Integer> ids);
}
