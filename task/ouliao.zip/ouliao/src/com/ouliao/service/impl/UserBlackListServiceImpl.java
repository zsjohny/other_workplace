/**
 * 
 */
package com.ouliao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ouliao.dao.UserBlackListDao;
import com.ouliao.domain.UserBlackList;
import com.ouliao.service.UserBlackListService;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserBlackListServiceImpl.java, 2016年2月23日 下午6:28:30
 */
@Service
@Transactional
public class UserBlackListServiceImpl implements UserBlackListService {
	@Autowired
	private UserBlackListDao userBlackListDao;

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int updateUserBlackListByUserBlackListId(String isDeleted, Integer userBlackListId) {
		return userBlackListDao.updateUserBlackListByUserBlackListId(isDeleted, userBlackListId);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public UserBlackList createUserBlackList(UserBlackList userBlackList) {
		return userBlackListDao.createUserBlackList(userBlackList);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public UserBlackList queryUserIsBlackListById(Integer userId, Integer userBlackId) {
		return userBlackListDao.queryUserIsBlackListById(userId, userBlackId);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public Page<UserBlackList> queryUserBlackListByUserBlackId(Integer startPage, Integer pageSize,
			Integer userBlackId) {
		return userBlackListDao.queryUserBlackListByUserBlackId(startPage, pageSize, userBlackId);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public Integer queryBlackListCountByUserId(Integer userId) {
		return userBlackListDao.queryBlackListCountByUserId(userId);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int updateUserBlackListIsDeletedAllByUserBlackByIds(Integer userId, List<Integer> ids) {
		return userBlackListDao.updateUserBlackListIsDeletedAllByUserBlackByIds(userId, ids);
	}

}
