/**
 *
 */
package com.ouliao.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import com.ouliao.dao.UserConcernDao;
import com.ouliao.domain.UserConcern;
import com.ouliao.repository.UserConcernPageRepository;
import com.ouliao.repository.UserConcernRepository;

/**
 *
 *
 * @author xiaoluo
 * @version $Id: UserConcernDaoImpl.java, 2016年2月23日 下午9:56:25
 */
@Repository
public class UserConcernDaoImpl implements UserConcernDao {

	@Autowired
	private UserConcernRepository userConcernRepository;
	@Autowired
	private UserConcernPageRepository userConcernPageRepository;

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public int updateUserConcernByUserConcernId(String isDeleted, Integer userConcernId) {

		return userConcernRepository.updateUserConcernByUserConcernId(isDeleted, userConcernId);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public UserConcern createUserConcern(UserConcern userConcern) {

		return userConcernPageRepository.save(userConcern);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public UserConcern queryUserIsConcernById(Integer userId, Integer userOnfocusId) {

		return userConcernRepository.queryUserIsConcernById(userId, userOnfocusId);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public Page<UserConcern> queryUserConcernByUserConcernId(Integer startPage, Integer pageSize,
															 Integer userConcernId) {
		final Integer id = userConcernId;
		Specification<UserConcern> specification = new Specification<UserConcern>() {

			@Override
			public Predicate toPredicate(Root<UserConcern> root, CriteriaQuery<?> cq, CriteriaBuilder cb) {

				List<Predicate> list = new ArrayList<>();
				list.add(cb.equal(root.get("isDeleted").as(String.class), "0"));
				list.add(cb.equal(root.get("userId").as(Integer.class), id));

				return cq.where(list.toArray(new Predicate[list.size()])).getRestriction();
			}
		};
		Sort sort = new Sort(Direction.DESC, "userModifyTime");

		Pageable pageable = new PageRequest(startPage, pageSize, sort);

		return userConcernPageRepository.findAll(specification, pageable);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public List<UserConcern> queryUserConcernedByUserConcernId(Integer startPage, Integer pageSize,
															   Integer userConcernedId) {
		// final Integer id = userConcernedId;
		// Specification<UserConcern> specification = new
		// Specification<UserConcern>() {
		//
		// @Override
		// public Predicate toPredicate(Root<UserConcern> root, CriteriaQuery<?>
		// cq, CriteriaBuilder cb) {
		//
		// List<Predicate> list = new ArrayList<>();
		// list.add(cb.equal(root.get("isDeleted").as(String.class), "0"));
		// list.add(cb.equal(root.get("userOnfocusId").as(Integer.class), id));
		//
		// return cq.where(list.toArray(new
		// Predicate[list.size()])).getRestriction();
		// }
		// };
		// Sort sort = new Sort(Direction.DESC, "userModifyTime");
		//
		// Pageable pageable = new PageRequest(startPage, pageSize, sort);
		//
		// return userConcernPageRepository.findAll(specification, pageable);
		return userConcernRepository.queryUserConcernedByUserConcernId(userConcernedId, (startPage - 1) * pageSize,
				pageSize);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public Integer queryUserConcernByUserId(Integer userId) {
		return userConcernRepository.queryUserConcernByUserId(userId);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public Integer queryUserConcernedByUserOnfocusId(Integer userOnfocusId) {
		return userConcernRepository.queryUserConcernedByUserOnfocusId(userOnfocusId);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public List<Integer> queryUserConcerndByOrder(Integer startPage, Integer pageSize) {

		// select userId from userconcern where isDeleted='0' group by userId
		// ORDER BY count(*) DESC
		// Specification<UserConcern> specification = new
		// Specification<UserConcern>() {
		//
		// @Override
		// public Predicate toPredicate(Root<UserConcern> root, CriteriaQuery<?>
		// cq, CriteriaBuilder cb) {
		// // cq.multiselect(root.get("userId"));
		// // cb.equal(root.get("isDeleted").as(String.class), "0");
		// // cq.groupBy(root.get("userId"));
		// //
		// // cq.orderBy(cb.desc(root.get("count(*)")));
		// cq.multiselect(root.get("userId"));
		// cb.equal(root.get("isDeleted").as(String.class), "0");
		// cq.groupBy(root.get("userId"));
		// cq.orderBy(cb.desc("count(*)"));
		// return cq.getRestriction();
		// }
		// };
		//
		// Pageable pageable = new PageRequest(startPage, pageSize);
		//
		// return userConcernPageRepository.findAll(specification, pageable);

		return userConcernRepository.queryUserConcerndByOrder(startPage, pageSize);

	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public List<UserConcern> queryUserConcerndAllByUserId(Integer userId) {
		return userConcernRepository.queryUserConcerndAllByUserId(userId);
	}

	/**
	 *
	 *
	 * @param
	 * @return
	 */

	@Override
	public List<UserConcern> queryUserConcerndedAllByUserId(Integer useredId) {
		return userConcernRepository.queryUserConcerndedAllByUserId(useredId);
	}

	@Override
	public List<UserConcern> queryUserConcerneAlldByUserOnfocusId(Integer userOnfocusId) {
		return userConcernRepository.queryUserConcerneAlldByUserOnfocusId(userOnfocusId);
	}

	@Override
	public List<UserConcern> queryUserConcerneAlldByUserConcernId(Integer userId) {
		return userConcernRepository.queryUserConcerneAlldByUserConcernId(userId);
	}

}
