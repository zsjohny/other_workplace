/**
 * 
 */
package com.ouliao.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ouliao.dao.ServiceRecordTimeDao;
import com.ouliao.domain.ServiceRecordTime;
import com.ouliao.repository.ServiceRecordTimePageRepository;
import com.ouliao.repository.ServiceRecordTimeRepository;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: ServiceRecordTimeImpl.java, 2016年3月10日 下午5:19:28
 */
@Repository
public class ServiceRecordTimeDaoImpl implements ServiceRecordTimeDao {
	@Autowired
	private ServiceRecordTimeRepository serviceRecordTimeRepository;
	@Autowired
	private ServiceRecordTimePageRepository serviceRecordTimePageRepository;

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public void createServiceRecordTime(ServiceRecordTime serviceRecordTime) {

		serviceRecordTimePageRepository.save(serviceRecordTime);

	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int updateUserCallTimeByUserId(Long userCallTime, Integer userId) {
		return serviceRecordTimeRepository.updateUserCallTimeByUserId(userCallTime, userId);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public ServiceRecordTime queryUserRecordIsExistByUserId(Integer userId) {
		return serviceRecordTimeRepository.queryUserRecordIsExistByUserId(userId);
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */

	@Override
	public int deleteSysSendByUserId(Integer userId) {
		return serviceRecordTimeRepository.deleteSysSendByUserId(userId);
	}
}
