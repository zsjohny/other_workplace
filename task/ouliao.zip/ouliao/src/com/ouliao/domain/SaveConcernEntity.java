/**
 * 
 */
package com.ouliao.domain;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: SaveConcernEntity.java, 2016年3月12日 下午10:38:29
 */

public class SaveConcernEntity {
	private String userPhone;
	private String userOnfocusPhone;

	/**
	 * @return the userPhone
	 */
	public String getUserPhone() {
		return userPhone;
	}

	/**
	 * @return the userOnfocusPhone
	 */
	public String getUserOnfocusPhone() {
		return userOnfocusPhone;
	}

	/**
	 * @param userPhone
	 *            the userPhone to set
	 */
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	/**
	 * @param userOnfocusPhone
	 *            the userOnfocusPhone to set
	 */
	public void setUserOnfocusPhone(String userOnfocusPhone) {
		this.userOnfocusPhone = userOnfocusPhone;
	}



}
