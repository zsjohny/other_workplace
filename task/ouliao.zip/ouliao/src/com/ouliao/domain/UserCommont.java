/**
 * 
 */
package com.ouliao.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * 
 * @author xiaoluo
 * @version $Id: UserCommont.java, 2016年2月19日 下午4:01:29
 */
@Entity
@Table(name = "userCommont")
public class UserCommont {
	private Integer userCommontId;
	private Integer userId;
	private Integer replyUserId;
	private Integer userSayContentId;
	private String userCommont;
	private String isDeleted;
	private Date userCreateTime;
	private Date userModifyTime;

	@Id
	@GeneratedValue
	/**
	 * @return the userCommontId
	 */
	public Integer getUserCommontId() {
		return userCommontId;
	}

	/**
	 * @return the replyUserId
	 */
	public Integer getReplyUserId() {
		return replyUserId;
	}

	/**
	 * @param replyUserId
	 *            the replyUserId to set
	 */
	public void setReplyUserId(Integer replyUserId) {
		this.replyUserId = replyUserId;
	}

	/**
	 * @return the userId
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * @return the userSayContentId
	 */
	public Integer getUserSayContentId() {
		return userSayContentId;
	}

	/**
	 * @param userSayContentId
	 *            the userSayContentId to set
	 */
	public void setUserSayContentId(Integer userSayContentId) {
		this.userSayContentId = userSayContentId;
	}

	@Column(length = 512)
	/**
	 * @return the userCommont
	 */
	public String getUserCommont() {
		return userCommont;
	}

	/**
	 * @param userCommontId
	 *            the userCommontId to set
	 */
	public void setUserCommontId(Integer userCommontId) {
		this.userCommontId = userCommontId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * @param userCommont
	 *            the userCommont to set
	 */
	public void setUserCommont(String userCommont) {
		this.userCommont = userCommont;
	}

	@Column(length = 6)
	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @return the userCreateTime
	 */
	public Date getUserCreateTime() {
		return userCreateTime;
	}

	/**
	 * @return the userModifyTime
	 */
	public Date getUserModifyTime() {
		return userModifyTime;
	}

	/**
	 * @param isDeleted
	 *            the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @param userCreateTime
	 *            the userCreateTime to set
	 */
	public void setUserCreateTime(Date userCreateTime) {
		this.userCreateTime = userCreateTime;
	}

	/**
	 * @param userModifyTime
	 *            the userModifyTime to set
	 */
	public void setUserModifyTime(Date userModifyTime) {
		this.userModifyTime = userModifyTime;
	}

}
