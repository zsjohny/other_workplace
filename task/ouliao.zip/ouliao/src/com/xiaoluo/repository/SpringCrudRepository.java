package com.xiaoluo.repository;

import org.springframework.data.repository.CrudRepository;

import com.xiaoluo.entity.Customer;

public interface SpringCrudRepository extends CrudRepository<Customer, Integer> {

}
