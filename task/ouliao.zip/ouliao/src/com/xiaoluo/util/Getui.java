package com.xiaoluo.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.impl.SingleMessage;
import com.gexin.rp.sdk.base.impl.Target;
import com.gexin.rp.sdk.base.payload.APNPayload;
import com.gexin.rp.sdk.exceptions.RequestException;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.APNTemplate;
import com.gexin.rp.sdk.template.NotificationTemplate;
import com.gexin.rp.sdk.template.TransmissionTemplate;

public class Getui {

    static String appId = "as04Xnd2SZ6vLW4KuuRtN2";
    static String appkey = "hg5ux6rzlL7ReQjRLMfk97";
    static String master = "f8wt6G4oPZAozCRRAWdeq9";
    static String CID = "40d8dd66c0d23da2aac34605f41b0951";
    static String Alias = "";
    static String host = "http://sdk.open.api.igexin.com/apiex.htm";
    static String url = "http://sdk.open.api.igexin.com/serviceex";

    public static String SendAndroid(String msg, String cid) {
        IGtPush push = new IGtPush(host, appkey, master);

        // 透传
        TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(appId);
        template.setAppkey(appkey);
        // 透传消息设置，1为强制启动应用，客户端接收到消息后就会立即启动应用；2为等待应用启动
        template.setTransmissionType(2);
        template.setTransmissionContent(msg);

        // NotificationTemplate template = null;
        // try {
        // template = NotificationTemplateDemo(msg);
        // } catch (Exception e1) {
        // e1.printStackTrace();
        // }

        SingleMessage message = new SingleMessage();
        message.setOffline(true);
        message.setOfflineExpireTime(1000 * 60 * 7);
        message.setData(template);

        List<Target> targets = new ArrayList<Target>();
        Target target1 = new Target();
        Target target2 = new Target();
        target1.setAppId(appId);
        target1.setClientId(cid);

        try {
            IPushResult ret = push.pushMessageToSingle(message, target1);
            return ret.getResponse().toString();
        } catch (RequestException e) {
            String requstId = e.getRequestId();
            IPushResult ret = push.pushMessageToSingle(message, target1, requstId);

            return ret.getResponse().toString();
        }
    }

    public static NotificationTemplate NotificationTemplateDemo(String msg) throws Exception {
        NotificationTemplate template = new NotificationTemplate();
        template.setAppId(appId);
        template.setAppkey(appkey);
        template.setTitle("");
        template.setText("");
        template.setLogo("icon.png");
        template.setTransmissionType(1);
        template.setTransmissionContent(msg);
        return template;
    }

    public static String SendIos(String msg, String cid, String tips) {
        IGtPush push = new IGtPush(host, appkey, master);
        TransmissionTemplate template = null;
        try {
            template = getTemplate(msg, tips);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        SingleMessage message = new SingleMessage();
        message.setOffline(true);
        message.setOfflineExpireTime(1000 * 60 * 7);
        message.setData(template);

        List<Target> targets = new ArrayList<Target>();
        Target target1 = new Target();
        Target target2 = new Target();
        target1.setAppId(appId);
        target1.setClientId(cid);
        try {
            IPushResult ret = push.pushMessageToSingle(message, target1);
            return ret.getResponse().toString();
        } catch (RequestException e) {
            String requstId = e.getRequestId();
            IPushResult ret = push.pushMessageToSingle(message, target1, requstId);

            return ret.getResponse().toString();
        }

    }

    public static void main(String[] args) {

        Map<String, Object> map = new HashMap<>();
        map.put("callSatus", "start");
        map.put("acceptId", 947);
        map.put("acceptName", "我是魏晓堃");
        map.put("acceptUrl", "http://139.196.40.11:18887/ouliao/user/download/setUser/947/1461067401414/head/download");
        map.put("acceptAuthor", "");
        map.put("acceptIsContract", "false");
        map.put("acceptRoom", 947);
        map.put("acceptPhoneId", 771);

        for (int i = 0; i < 10; i++)

        {
            SendIos(map.toString(), "ad6b20c176919b72829341d263a1b2f6", "test");
            SendAndroid(map.toString(), "4e7c9d3249f799e1817574e6daf908ef");

        }

    }

    public static TransmissionTemplate getTemplate(String msg, String tips) {
        TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(appId);
        template.setAppkey(appkey);
        template.setTransmissionContent(msg);
        template.setTransmissionType(2);
        if (StringUtils.isNotEmpty(tips)) {
            APNPayload payload = new APNPayload();
            payload.setBadge(0);
            payload.setContentAvailable(1);
            payload.setSound("default");
            payload.setCategory("$由客户端定义");
            payload.setAlertMsg(new APNPayload.SimpleAlertMsg(tips));
            // 字典模式使用下者
            // payload.setAlertMsg(getDictionaryAlertMsg());
            template.setAPNInfo(payload);
        }
        return template;

    }

    public static String IosApns(String msg, String lockTips, String devicen_token) {
        try {
            IGtPush push = new IGtPush(url, appkey, master);
            APNTemplate t = new APNTemplate();
            APNPayload apnpayload = new APNPayload();
            apnpayload.setSound("");
            APNPayload.DictionaryAlertMsg alertMsg = new APNPayload.DictionaryAlertMsg();
            alertMsg.setTitle(msg);
            alertMsg.setBody(msg);
            alertMsg.setTitleLocKey("偶聊");
            alertMsg.setActionLocKey(lockTips);

            //设置铃声
            apnpayload.setSound("ringingWithCallComing.mp3");

            apnpayload.setAlertMsg(alertMsg);

            t.setAPNInfo(apnpayload);
            SingleMessage sm = new SingleMessage();
            sm.setData(t);
            IPushResult ret0 = push.pushAPNMessageToSingle(appId, devicen_token, sm);

            return (String) ret0.getResponse().get("result");
        } catch (Exception e) {

        }

        return null;

    }

}