package com.xiaoluo.dao;

import java.util.List;

import com.xiaoluo.entity.Customer;

public interface SSHDao {
	void createCustomerByCusual(Customer customer);

	List<Customer> queryCustomer();
}
