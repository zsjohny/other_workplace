package com.finace.miscroservice.getway.push;

import com.finace.miscroservice.commons.utils.DesUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import static com.finace.miscroservice.commons.utils.DesUtil.KEY;

public class Client {


    public static void main(String[] args) throws InterruptedException {


        EventLoopGroup group = new NioEventLoopGroup(1);

        Bootstrap bootstrap = new Bootstrap();


        ChannelFuture future = bootstrap.group(group).channel(NioSocketChannel.class).handler(new ChannelInitializer<SocketChannel>() {
            @Override
            protected void initChannel(SocketChannel ch) throws Exception {
                ChannelPipeline pipeline = ch.pipeline();
                pipeline.addLast(new JSONDecoder());
                pipeline.addLast(new JSONEncoder());
                pipeline.addLast(new ClientHandler());

            }


        }).connect("192.168.89.1", 1020).sync();


        Channel channel = future.channel();

        channel.writeAndFlush(DesUtil.encrypt(System.currentTimeMillis() + ":" + "a", KEY));

    }


}
